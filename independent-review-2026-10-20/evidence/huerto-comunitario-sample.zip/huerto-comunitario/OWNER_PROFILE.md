# Owner Profile

- **Owner/decision authority:** [name or role]
- **Relevant expertise:** [short list]
- **Current growth areas:** [short list]
- **Communication:** [language, depth, style]

Calibration only. This file does not override the constitution, project scope, safety rules, or recorded decisions.

---

_Seeded by accreatio for **Huerto comunitario**. Replace the placeholders above with your own calibration; this file never overrides the constitution, project scope, or safety rules._
