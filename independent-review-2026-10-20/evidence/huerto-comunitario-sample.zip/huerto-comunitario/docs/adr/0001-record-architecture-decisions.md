# ADR [NNNN] — [Decision title]

**Estado:** PROPUESTO | ACEPTADO | SUPERADO (por ADR [NNNN])
**Fecha:** [YYYY-MM-DD]

## Contexto

[What constraint or problem forces a decision here — budget, team size, load, compliance, an existing invariant this must not break. Be concrete: numbers, not adjectives.]

## Decisión

[The decision, stated as a set of concrete, checkable choices — not a vague direction. Someone should be able to read this and know exactly what was and wasn't chosen.]

## Alternativas consideradas

[What else was on the table and why it lost — this is what stops the same debate from repeating in six months.]

## Consecuencias

[What this decision makes easier, what it makes harder or forecloses, and what it costs — money, complexity, migration effort later if reversed.]

---

_First ADR for **Huerto comunitario**: record here why this project exists and which architecture was chosen. Replace this note with the real decision._
