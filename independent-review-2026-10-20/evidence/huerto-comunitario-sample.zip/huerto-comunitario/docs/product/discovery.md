# Discovery

## Context

Una app local para que veinte vecinos reserven turnos de riego del huerto y vean las tareas pendientes. El problema actual es que coordinan por mensajes y duplican los turnos.

## Constraints

Cero servicios de pago. Primera version para Windows; sin datos personales salvo nombres elegidos por los vecinos.
