# [Project] — Audit Checklist (Full/high-risk profile)

The default gate between applicable Design work and Coding for a Full/high-risk project. A Lean project may omit it unless its risk changes or the owner requests an independent audit. Generalized from a real project's audit pattern that caught real gaps before any code existed. Not a self-review — the auditor should not be the same session/context that authored the design being audited. Run it as an independent pass: a fresh AI session with no memory of writing the design (a new conversation, a review subagent, a provider's dedicated review tool), the project owner, or both.

## Scope of this audit

[State exactly what's in scope — usually all of `docs/master.md`, its ADRs, and `docs/product/discovery.md`. If this is a partial re-audit after fixing prior findings, say so explicitly instead of re-running the full scope silently.]

## Checklist

- [ ] Every business rule in `docs/master.md` is either fully specified or explicitly listed as pending a sponsor decision — nothing left for an implementer to invent silently.
- [ ] Every decision requiring sponsor/stakeholder approval is listed as such, not assumed resolved.
- [ ] `docs/product/discovery.md`'s open-questions table is fully resolved, or each remaining row is explicitly deferred with an owner and a named phase — not silently dropped.
- [ ] Security/access-control model reviewed; gaps are logged as findings, not silently accepted.
- [ ] Concurrency protocol (if this project has contended resources) reviewed against the specific resources this project actually touches — not assumed adequate by analogy.
- [ ] Budget/infrastructure plan checked against known constraints (see `docs/architecture/` and any Ruta A/B assumption stated in `docs/master.md`).
- [ ] No contradiction between `docs/master.md` and any subordinate doc (ADRs, `docs/product/discovery.md`) — if one exists, `docs/master.md` should already say so per the Contradiction Engine discipline, not leave it implicit.
- [ ] Nothing in the design assumes an external system's behavior that hasn't actually been verified (see any PoC results in `docs/product/discovery.md`).

## Findings

List every finding, most severe first. A clean audit still states "no findings" explicitly — silence isn't evidence of a check having run.

| Severity | Finding | Why it matters | Resolution |
|---|---|---|---|
| BLOCKER / MAJOR / MINOR / OBSERVATION | | | OPEN / RESOLVED / ACCEPTED (with reason) |

- **BLOCKER** — Coding cannot start until this is resolved.
- **MAJOR** — should be resolved before Coding starts; proceeding with it open is a sponsor decision, not a default.
- **MINOR** — can be resolved during Coding without re-auditing, but must be tracked, not forgotten.
- **OBSERVATION** — worth noting, doesn't block anything.

## Verdict

`PASS` / `PASS_WITH_OBSERVATIONS` / `FAIL` — [date] — auditor: [who/what performed this].

**A PASS verdict is not authorization to start Coding.** It's evidence that informs the sponsor's go/no-go — the explicit human GO required by `docs/delivery/orchestration-loop.md` still has to happen separately and explicitly, even after a clean audit. If this project runs under `toolkit/orchestrator/` Mode 1/2, invoking the independent Audit step and advancing Design→Coding are separate `HUMAN_ONLY` actions. The engine enforces those action boundaries; it does not judge the content of this verdict — see `toolkit/orchestrator/GATE_MODEL.md`.
