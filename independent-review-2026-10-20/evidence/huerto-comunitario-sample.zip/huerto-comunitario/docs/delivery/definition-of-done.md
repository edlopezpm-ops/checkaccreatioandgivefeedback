# [Project] — Definition of Done, per phase

> Subordinate to `../master.md`.

## General principle

"Done" never means "it compiles" or "the document reads well." It means there is real evidence, verifiable by someone other than whoever did the work.

## Phase — Design

A design increment is done when:

- The corresponding document exists, is self-contained for its critical rules, and doesn't present anything as implemented that's only designed.
- Every change or removal of a previously-active rule updates the live document; a durable non-obvious decision gets an ADR, and git keeps the history.
- Every decision requiring stakeholder approval is listed as such — never assumed.
- No ambiguity remains that would force a future implementer to invent a business, security, isolation, or authorization rule on their own.

## Phase — Build

A build increment is done when:

- The functionality declared in scope works for the golden path and the failure paths identified during design.
- At least one automated test fails without the change and passes with it.
- Every new access-controlled resource has its access rule enforced server-side, with at least one test proving isolation between two real distinct actors (users/tenants/customers) where relevant.
- Every permission-restricted operation has at least one test proving a user without the permission fails and a user with it (by role or explicit override) succeeds.
- No critical rule (price, balance, availability, authorization) was computed or trusted client-side.
- Domain documentation (`master.md` and affected subordinate docs) was updated to reflect exactly what was built — no more, no less.
- Nothing outside the declared scope was modified.
- A human actually ran it once, not just read the diff.

## Phase — Test

A test increment is done when:

- The relevant tests (unit, access-control, concurrency, integration, E2E, VTP — Volume Test Plan, scripted transaction-volume simulation, not manual — backup/restore, security, UAT — as applicable) actually ran, with real output attached to the report — not simulated or described from memory.
- Every expected negative test (one actor reading another's data, an unauthorized user attempting a restricted action, an overselling attempt, editing an immutable record) actually fails as expected, verified with the real corresponding role/credential — never only as a superuser/admin.
- Any finding gets logged as a risk or fixed before closing the increment — never discarded to preserve a favorable verdict.

## Phase — Deploy

A deploy increment is done when:

- The documented pipeline ran end to end, including explicit human approval before touching production.
- There's post-deployment health evidence (login, a minimal flow, at least two realistic test actors) in the deployed environment.
- Actual observed cost was compared against the sizing/budget doc — any deviation gets documented, not ignored.
- A verified rollback plan exists, not just an assumed one.

## Cross-cutting rule

No increment in any phase is declared done if the relevant tests ran only with superuser/admin privileges, or if isolation between at least two real distinct actors wasn't verified when the increment touches any actor-owned resource.
