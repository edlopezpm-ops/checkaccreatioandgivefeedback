# [Project] — orchestration loop

> Subordinate to `../master.md`. This is the Full/high-risk increment loop; use it in every applicable phase. Each increment ends with an explicit go/no-go from whoever owns that decision. Under Mode 0/1 (see `toolkit/orchestrator/GATE_MODEL.md`) that decision is always human. Mode 2 currently provides the deterministic gate boundary only; a project must not claim an autonomous persistent loop unless it has separately implemented one.

## Mandatory loop per increment

1. Read `../master.md` and the ADRs that apply to this increment.
2. Declare the exact scope of the increment — what's in, and what's explicitly *not* in.
3. Identify dependencies (which prior increments must already be closed) and risks (security, isolation between tenants/customers, cross-role authorization, concurrency, budget).
4. Present a concrete plan before writing anything.
5. **Wait for explicit sponsor/stakeholder authorization when the increment involves implementation** — a finished design document is not that authorization.
6. Execute **only** the scope declared in step 2 — do not expand the increment mid-flight. **Exception — signed scope amendment:** if the AI identifies, mid-increment, that something beyond the declared scope is genuinely necessary, it may recommend the amendment, but never execute it on its own judgment. The sponsor reviews the specific recommendation and either declines it (default) or explicitly signs and confirms it (e.g. "Tienes mi autorización firmada: [name] [date]" or equivalent unambiguous confirmation) — only then does the amended scope become executable, and it gets logged as an explicit amendment to step 2's original declaration, not folded in silently. This is not a loophole for "expand scope by default and ask forgiveness" — the default remains declining, per this step's main rule; it's a recorded, deliberate exception mechanism, not a softening of it.
7. Run real tests (not simulated) for the increment.
8. Explicitly review: security, isolation, cross-role authorization, concurrency (if applicable), and budget — don't assume "tests passed" means these dimensions are covered.
9. Update affected documentation in the same cycle, not afterward.
10. Report with real evidence (actual test output, not assertions) following `definition-of-done.md`.
11. Wait for explicit GO/NO-GO from the sponsor/stakeholder on the increment's outcome.
12. **Do not automatically start the next increment.** Every increment ends with the sponsor deciding whether to continue — not with the agent deciding by inertia. Under Mode 2, "the agent deciding by inertia" is precisely what the gate engine exists to prevent: a phase-boundary or otherwise-`HUMAN_ONLY` increment is refused outright if the sponsor's decision isn't already recorded; a `RUNTIME_AUTO` in-phase increment may proceed on the orchestrator's proposal, but that's the engine executing a pre-approved policy, not the agent deciding anything for itself. See `toolkit/orchestrator/GATE_MODEL.md`.

## Why this loop exists

A large increment that "seems" done isn't verifiable by a human; a small increment with real evidence is. The loop keeps every increment small enough that a sponsor can actually verify it, rather than trusting that "it was done well."

## Relationship to lifecycle phases

Design → Build → Test → Deploy is the higher-level governance. This page's loop is the cycle *inside* each increment. It doesn't replace the phase/status and gates recorded in `../master.md`.
