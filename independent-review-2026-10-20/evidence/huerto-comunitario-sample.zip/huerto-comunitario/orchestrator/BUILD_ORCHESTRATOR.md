# Build the orchestrator

You are reading this because the human asked you to set up this project's
orchestration toolkit. Build it here, in this folder. Show the human each file
before you run anything.

## Why this is a specification and not a script

This project was exported from a browser as a ZIP. A ZIP saved from a browser
carries Mark-of-the-Web; PowerShell refuses unsigned `.ps1` under its default
execution policy, and managed environments block downloaded scripts outright.
Shipping the code would also mean the human runs a script nobody read. Writing
it here, now, in front of them, is both safer and more likely to work.

## What to build

Two layers, and the separation is mandatory.

**1. A thin PowerShell entry point — `orchestrator/orchestrator.ps1`**

Its only jobs: set `PYTHONPATH` so the runtime package is importable, forward
its arguments to the Python CLI, and exit with the CLI's exit code. No logic.
Accept at minimum `-ConfigPath` (defaulting to `orchestrator.config.yaml`)
and `-ProjectDir` (defaulting to `.`).

**2. A Python runtime — `orchestrator/runtime/`**

| Module | Owns |
| --- | --- |
| `cli.py` | Argument parsing and the run loop. The only entry point. |
| `gates.py` | The gate table. Decides what needs a human. |
| `state.py` | Persisted run state, so an interrupted run resumes instead of restarting. |
| `events.py` | Append-only structured event log (JSONL). |
| `adapters/base.py` | The adapter contract every AI CLI implements. |
| `adapters/<tool>.py` | One per CLI you actually have. Start with the ones the preflight finds. |

## Rules that are not negotiable

These come from the engineering constitution in `CLAUDE.md`. Implement them as
code, not as comments:

- **Phase transitions and destructive operations are `HUMAN_ONLY`.** The gate
  table decides by typed action, never by an AI's claim that a checkpoint does
  not apply.
- **Never auto-commit or auto-push.** Execution and verification may run
  unattended; writing to shared history is a human action.
- **Cap the loop at ~3 passes** without meeting exit criteria, then stop and
  re-scope. Do not push harder.
- **Never pass user-authored text to a shell.** Fixed executable names, typed
  argument arrays.
- **An auditor is independent only when it runs in a separate invocation from
  the work it audits.** Assigning audit work to the worker is self-review.
- **Never log secrets, credentials, or personal data.**

## The adapter contract

Each adapter exposes:

- `health_check()` — is this CLI present and authenticated? Return a typed
  result, never raw authentication output.
- `invoke(role, task, context)` — run one step, return structured output.
- `name` / `version` — for the event log.

Adapters own how their CLI is called. The runtime owns whether it may be called
at all. Do not let an adapter decide its own gate.

## Preflight

Write `orchestrator/preflight.ps1` as part of this task. It checks which CLIs
are actually installed and authenticated, and prints what is missing. Nothing
was verified at export time — accreatio runs in a browser and cannot inspect a
machine, so it did not pretend to.

This project declared these participants:

- `participant-01` — **generalist**: Global view and coordination

Report which of them you can actually realize. If the topology is smaller than
declared, say so and ask the human how to proceed. Never silently reduce it.

## Configuration

This project did not enable orchestration, so no config was generated.
Write `.ai-engineering/orchestration.yaml` yourself if the human wants a run.
Keep it at exactly that path — accreatio's desktop host refuses to start from a
config located anywhere else. This is the schema to follow:

```yaml
# Example orchestrator config -- copy to orchestrator.config.yaml in a real
# project and edit. See GATE_MODEL.md for what Mode 1/2 actually mean.
#
# Safe zero-usage example for the Mode 1 runner. Real provider examples live
# beside this file (`*.claude-code.example.yaml`, `*.codex.example.yaml`).
# `mock` remains useful for learning and deterministic dry runs; it is not
# evidence that a real provider was invoked.

project_name: example-project
mode: 1  # The shipped CLI runner is Mode 1. Mode 2 currently exposes gate enforcement, not a persistent runner.

session:
  owner: local-user  # optional; omit to use the local operating-system user
  max_duration_seconds: 7200  # hard maximum; a shorter positive value is allowed

# action_kind is trusted control-plane configuration, never provider output.
role_sequence:
  - role: Arquitecto
    action_kind: EXECUTE_ROLE_STEP
    task: "Draft the backend design for the feature described in docs/master.md"
  - role: Auditor
    action_kind: EXECUTE_INDEPENDENT_AUDIT
    task: "Independently review the Arquitecto's design against docs/delivery/audit-checklist.md"
  - role: Implementador
    action_kind: ADVANCE_DESIGN_TO_CODING
    task: "Implement the approved design, with tests"

adapters:
  Arquitecto:
    kind: mock
    name: mock-arquitecto
  Auditor:
    kind: mock
    name: mock-auditor
  Implementador:
    kind: mock
    name: mock-implementador

budget:
  max_iterations_per_entity: 3
  max_provider_invocations: 20
  max_consecutive_failures: 3
  # ceiling: 10.0  # optional cumulative USD ceiling; mock reports exact zero cost
```

## Done means

The human can run `./orchestrator/orchestrator.ps1` and get either a working
run or a clear statement of what is missing. Not a stack trace.
