import type { Locale } from "./types";

export const termsHref = (locale: Locale): string =>
  `/legal/terms${locale === "es" ? "-es" : ""}.html?lang=${locale}`;

export const legalHref = (
  document: "privacy" | "cookies" | "faq",
  locale: Locale,
): string => `/legal/${document}.html?lang=${locale}`;
