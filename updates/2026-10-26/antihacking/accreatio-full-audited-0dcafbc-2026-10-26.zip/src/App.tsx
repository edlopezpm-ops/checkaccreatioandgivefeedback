import {
  useEffect,
  useCallback,
  useMemo,
  useRef,
  useState,
  type ReactNode,
  type ComponentType,
} from "react";
import { ShieldCheck, Check, Play, Save, X, History } from "lucide-react";
import {
  generatePrompt,
  buildExecutionPreview,
  defaultRoleTask,
  planActions,
  slugify,
  validateProject,
} from "./core";
import type {
  ParticipantInstance,
  ExecutionRequest,
  ExecutionResult,
  GithubStatus,
  HistoryEntry,
  Locale,
  OrchestrationDecision,
  OrchestrationPreflightResult,
  OrchestrationRunSnapshot,
  PreferredIde,
  ProjectDefinition,
  ProviderAvailability,
  CanonicalRole,
  Settings,
  WebAttachment,
} from "./types";
import { defaultOrchestration } from "./types";
import brandMark from "./assets/accreatio-mark.svg";
import {
  allocateParticipantId,
  CANONICAL_ROLES,
  validateAttachmentSet,
} from "../shared/domain";
import {
  buildWebExport,
  resolveWebAttachments,
  validateWebProject,
} from "./webExport";
import {
  DEFAULT_PROVIDER_ID,
  PROVIDER_REGISTRY,
  availabilityById,
  unsupportedHostAvailability,
  type ProviderAvailabilityReason,
} from "../shared/providerRegistry";
import { bridge } from "./bridge";
import { clearWebExportRecovery } from "./bridge/web";
import { buildLocalDataExport } from "./localDataExport";
import {
  AttachmentSecurityError,
  prepareAttachment,
} from "./attachmentSecurity";
import {
  clearDraftHandoff,
  saveDraftHandoff,
  takeDraftHandoff,
} from "./account/draftHandoff";
import {
  clearDraft,
  bindAccountDraft,
  purgeAccountDraft,
  loadDraftWithWarnings,
  loadOnboardingPreference,
  saveDraft,
  saveOnboardingCompletion,
} from "./draftStore";
import type { Attachment } from "./types";
import {
  WebExperienceIntro,
  type DraftState,
} from "./components/WebExperience";
import { Mode1ConfigurationDialog } from "./components/mode1/Mode1ConfigurationDialog";
import { AppFrame, type AppDestination } from "./components/AppFrame";
import { Onboarding } from "./components/Onboarding";
import {
  GuidedCreation,
  GuidedBasics,
  GuidedTeam,
} from "./components/creation/GuidedCreation";
import { GuidedAttachments } from "./components/creation/GuidedAttachments";
import {
  canMoveToQuestion,
  guidedQuestions,
  questionInvalid,
  questionStage,
  stageQuestion,
  type GuidedQuestion,
} from "./components/creation/guidedFlow";
import {
  creationFocusTarget,
  focusCreationTarget,
  TeamStage,
} from "./components/creation/TeamStage";
import { DeliveryStage } from "./components/creation/DeliveryStage";
import { ReviewStage } from "./components/creation/ReviewStage";
import { SummaryDrawer } from "./components/creation/SummaryDrawer";
import { OutcomePanel } from "./components/creation/OutcomePanel";
import type {
  CreationStage,
  StageState,
} from "./components/creation/StageNavigation";
import { AccountShell } from "./components/account/AccountShell";
import { DEFAULT_ACCOUNT_FEATURE_CONFIG } from "./account/contracts";
import { createMockAccountProvider } from "./account/mockProvider";
import { AboutExperience } from "./components/AboutExperience";
import {
  AboutPopover,
  type AboutSection,
} from "./components/help/AboutPopover";
import { HelpDialog } from "./components/help/HelpDialog";
import type { HelpTopic } from "./components/help/HelpTips";
const inactiveAccountProvider = createMockAccountProvider();
const defineTranslations = <T extends Record<string, string>>(value: {
  es: T;
  en: { [K in keyof T]: string };
}) => value;
const tr = defineTranslations({
  es: {
    new: "Nuevo proyecto",
    settings: "Configuración",
    history: "Historial",
    orchestrationCenter: "Orquestación",
    about: "Acerca de",
    title: "Crea tu proyecto",
    tag: "De la idea a un inicio estructurado.",
    name: "Nombre del proyecto",
    phase: "Fase actual",
    context: "Contexto conocido",
    constraints: "Restricciones",
    route: "Ruta",
    agents: "Participantes planificados",
    agentsSub: "Define de 1 a 6 participantes; los roles pueden repetirse",
    action: "Acción esperada",
    destination: "Carpeta destino",
    attach: "Fuentes de discovery",
    attachHelp: "Hasta 20 archivos · 20 MiB cada uno · 100 MiB en total",
    dry: "Dry-run",
    git: "Inicializar Git",
    remote: "Crear en GitHub",
    ide: "Abrir IDE",
    start: "START",
    review: "Revisar y ejecutar",
    prompt: "Vista previa del prompt",
    copy: "Copiar",
    plan: "Qué haremos",
    save: "Guardar cambios",
    saved: "Guardado",
    locations: "Ubicaciones",
    tools: "Herramientas",
    language: "Idioma",
    theme: "Tema",
    connect: "Conectar GitHub",
    connected: "Conectado",
    notConnected: "No conectado",
    confirm: "Confirmar ejecución",
    cancel: "Cancelar",
    execute: "Ejecutar ahora",
    success: "Proyecto preparado",
    failed: "La ejecución se detuvo",
    local: "100% local",
    emptyHistory: "Aún no hay proyectos ejecutados.",
    license: "Licencia privada y gratuita",
    privacy:
      "accreatio procesa proyectos y documentos localmente. La analítica de uso y la investigación requieren elecciones opcionales independientes.",
    aboutVersion: "Versión",
    aboutSecurity: "Seguridad",
    aboutSecurityCopy:
      "Renderer aislado, IPC limitado, adjuntos permitidos por lista, sin interpolación de shell, escrituras versionadas, firma local de auditoría y sin credenciales incorporadas.",
    aboutDocuments: "Documentos",
    aboutWebDocumentsCopy:
      "Privacy Policy, FAQ y Terms of Service están disponibles abajo como borradores versionados. About y las publicaciones del Blog son públicos; crear proyectos requiere acceso autorizado. La revisión legal formal sigue pendiente.",
    aboutDesktopDocumentsCopy:
      "Consulta Privacy Policy, FAQ y Terms of Service en la carpeta docs del proyecto. Requieren revisión legal antes de una publicación web.",
    aboutLegalDocuments: "Documentos legales",
    aboutCopyright:
      "Todos los derechos reservados. Uso privado autorizado gratuito; la redistribución y reventa requieren permiso escrito.",
    aboutCopyrightRole: "titular de los derechos de autor y licenciante",
    aboutClosingLabel: "Principios del producto accreatio",
    aboutClosingPrinciples:
      "Punto de partida local-first para proyectos · generación determinista · privacidad bajo tu control",
  },
  en: {
    new: "New project",
    settings: "Settings",
    history: "History",
    orchestrationCenter: "Orchestration",
    about: "About",
    title: "Create your project",
    tag: "From idea to a structured beginning.",
    name: "Project name",
    phase: "Current phase",
    context: "Known context",
    constraints: "Constraints",
    route: "Route",
    agents: "Planned participants",
    agentsSub: "Define 1–6 participants; canonical roles may repeat",
    action: "Expected action",
    destination: "Destination folder",
    attach: "Discovery sources",
    attachHelp: "Up to 20 files · 20 MiB each · 100 MiB total",
    dry: "Dry run",
    git: "Initialize Git",
    remote: "Create on GitHub",
    ide: "Open IDE",
    start: "START",
    review: "Review and execute",
    prompt: "Prompt preview",
    copy: "Copy",
    plan: "What will happen",
    save: "Save changes",
    saved: "Saved",
    locations: "Locations",
    tools: "Tools",
    language: "Language",
    theme: "Theme",
    connect: "Connect GitHub",
    connected: "Connected",
    notConnected: "Not connected",
    confirm: "Confirm execution",
    cancel: "Cancel",
    execute: "Execute now",
    success: "Project prepared",
    failed: "Execution stopped",
    local: "100% local",
    emptyHistory: "No executed projects yet.",
    license: "Private, free license",
    privacy:
      "accreatio processes projects and documents locally. Usage analytics and research require independent optional choices.",
    aboutVersion: "Version",
    aboutSecurity: "Security",
    aboutSecurityCopy:
      "Sandboxed renderer, isolated IPC, allow-listed attachments, no shell interpolation, versioned writes, local audit signature, and no embedded credentials.",
    aboutDocuments: "Documents",
    aboutWebDocumentsCopy:
      "The Privacy Policy, FAQ, and Terms of Service are available below as versioned drafts. About and published Blog posts are public; project creation requires authorized access. Formal legal review remains pending.",
    aboutDesktopDocumentsCopy:
      "See the Privacy Policy, FAQ, and Terms of Service in the project docs folder. They require legal review before a public web release.",
    aboutLegalDocuments: "Legal documents",
    aboutCopyright:
      "All rights reserved. Free for authorized private use; redistribution and resale require written permission.",
    aboutCopyrightRole: "copyright holder and licensor",
    aboutClosingLabel: "accreatio product principles",
    aboutClosingPrinciples:
      "Local-first project launch point · deterministic generation · privacy under your control",
  },
});
const settings0: Settings = {
  baseFolder: "",
  toolkitPath: "",
  futureProjectsPath: "",
  defaultBranch: "main",
  preferredIde: "VS Code",
  theme: "dark",
  locale: "es",
  confirmBeforeRun: true,
};
const WEB_THEME_KEY = "accreatio:theme";
const loadWebTheme = (): Settings["theme"] => {
  try {
    return window.localStorage.getItem(WEB_THEME_KEY) === "dark"
      ? "dark"
      : "light";
  } catch {
    return "light";
  }
};
const responsibilities: Record<CanonicalRole, { es: string; en: string }> = {
  generalist: {
    es: "Visión global y coordinación",
    en: "Global view and coordination",
  },
  architect: { es: "Diseño: qué y por qué", en: "Design: what and why" },
  implementer: {
    es: "Implementación y pruebas",
    en: "Implementation and testing",
  },
  auditor: { es: "Revisión independiente", en: "Independent review" },
};
const participant = (
  id = "participant-01",
  role: CanonicalRole = "generalist",
  locale: Locale = "es",
): ParticipantInstance => ({
  id,
  role,
  label: responsibilities[role][locale],
});
const project0: ProjectDefinition = {
  name: "",
  phase: "idea",
  context: "",
  restrictions: "",
  route: "local",
  action: "tracking",
  destination: "",
  participants: [participant()],
  attachments: [],
  initializeGit: false,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: true,
  orchestration: defaultOrchestration(),
};
const webProject0 = (): ProjectDefinition => ({
  ...project0,
  participants: project0.participants.map((item) => ({
    ...item,
    label: responsibilities[item.role].en,
  })),
  action: "repository",
  destination: "browser-download",
  attachments: [],
});
export interface AppExtraDestinationContext {
  locale: Locale;
  onStart: () => void;
  version: string;
}

export interface AppExtraDestination {
  id: string;
  labels: Record<Locale, string>;
  render: (context: AppExtraDestinationContext) => ReactNode;
}

export interface AppProps {
  extraDestination?: AppExtraDestination;
  accountBoundary?: ComponentType<{
    children: ReactNode;
    locale: Locale;
    active: boolean;
    onBack: () => void;
    onBeforeSignIn: (redirect?: boolean) => Promise<void>;
    onAccountReady: (identity: {
      ownerKey: string;
      sessionKey: string;
    }) => Promise<void>;
    onSuspendAccount: () => void;
    onClearAccount: (identity: {
      ownerKey: string;
      sessionKey: string;
    }) => Promise<void>;
    transientAttachmentCount: number;
    accountMenuTarget: HTMLElement | null;
    onRequireSignIn: () => void;
    onSessionChange: (
      authenticated: boolean,
      canUseBlog: boolean,
      enabledProviders?: readonly ("google" | "github" | "email-code")[],
    ) => void;
  }>;
}

const NoAccountBoundary = ({
  children,
}: {
  children: ReactNode;
  locale: Locale;
  active: boolean;
}) => <>{children}</>;

export function App({
  extraDestination,
  accountBoundary: AccountBoundary = NoAccountBoundary,
}: AppProps = {}) {
  const [webAuthenticated, setWebAuthenticated] = useState(false);
  const [enabledSignInProviders, setEnabledSignInProviders] = useState<
    readonly ("google" | "github" | "email-code")[]
  >([]);
  const [accountMenuTarget, setAccountMenuTarget] =
    useState<HTMLDivElement | null>(null);
  const [welcomeStep, setWelcomeStep] = useState<1 | 2>(1);
  const localeExplicitlyChosen = useRef(
    bridge.kind === "web" &&
      ["es", "en"].includes(
        new URLSearchParams(window.location.search).get("lang") ?? "",
      ),
  );
  const accountSessionChanged = useCallback(
    (
      authenticated: boolean,
      _canUseBlog: boolean,
      methods?: readonly ("google" | "github" | "email-code")[],
    ) => {
      setWebAuthenticated(authenticated);
      if (methods) setEnabledSignInProviders(methods);
    },
    [],
  );
  const initialOnboarding = useMemo(() => loadOnboardingPreference(), []);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [aboutSection, setAboutSection] = useState<AboutSection>("info");
  const [helpTopic, setHelpTopic] = useState<HelpTopic | null>(null);
  const closeAbout = useCallback(() => setAboutOpen(false), []);
  const [tab, setTab] = useState<AppDestination>("new"),
    [p, setProject] = useState(() =>
      bridge.kind === "web" ? webProject0() : project0,
    ),
    [s, setS] = useState<Settings>(() =>
      bridge.kind === "web"
        ? {
            ...settings0,
            locale:
              new URLSearchParams(window.location.search).get("lang") === "es"
                ? "es"
                : "en",
            theme: loadWebTheme(),
          }
        : settings0,
    ),
    [confirm, setConfirm] = useState(false),
    [running, setRunning] = useState(false),
    [result, setResult] = useState<ExecutionResult | null>(null),
    [copied, setCopied] = useState(false),
    [saved, setSaved] = useState(false),
    [gh, setGh] = useState<GithubStatus>({
      installed: false,
      authenticated: false,
    }),
    [history, setHistory] = useState<HistoryEntry[]>([]),
    [hostMessage, setHostMessage] = useState<string | null>(null),
    [providers, setProviders] = useState<ProviderAvailability | null>(() =>
      bridge.kind === "web" ? unsupportedHostAvailability() : null,
    ),
    [checkingProviders, setCheckingProviders] = useState(false),
    [draftReady, setDraftReady] = useState(bridge.kind !== "web"),
    [draftState, setDraftState] = useState<DraftState>(
      bridge.kind === "web" ? "loading" : "saved",
    ),
    [mode1DialogOpen, setMode1DialogOpen] = useState(false),
    [webAttachments, setWebAttachments] = useState<WebAttachment[]>([]),
    [inspectingAttachments, setInspectingAttachments] = useState(false),
    [rejectedAttachments, setRejectedAttachments] = useState<
      { id: string; name: string; reason: string }[]
    >([]),
    [restoredAttachmentCount, setRestoredAttachmentCount] = useState(0),
    [pendingOperationId, setPendingOperationId] = useState<string | null>(null),
    [showOnboarding, setShowOnboarding] = useState(
      () =>
        (new URLSearchParams(window.location.search).get("view") ===
          "welcome" ||
          !initialOnboarding.completed) &&
        !(
          bridge.kind === "web" &&
          new URLSearchParams(window.location.search).get("account") ===
            "continue"
        ),
    ),
    [onboardingStorageAvailable, setOnboardingStorageAvailable] = useState(
      initialOnboarding.storageAvailable,
    ),
    [creationQuestion, setQuestion] = useState<GuidedQuestion>("name"),
    [attemptedStages, setAttemptedStages] = useState<CreationStage[]>([]),
    [stageFeedback, setStageFeedback] = useState<string | null>(null);
  const creationStage = questionStage(creationQuestion);
  const mode1TriggerRef = useRef<HTMLButtonElement>(null);
  const reviewGateRef = useRef(false);
  const executionGateRef = useRef(false);
  const pendingRequestRef = useRef<ExecutionRequest | null>(null);
  const executionTriggerRef = useRef<HTMLButtonElement>(null);
  const executionDialogRef = useRef<HTMLDialogElement>(null);
  const isWeb = bridge.kind === "web";
  const draftReadyRef = useRef(draftReady);
  const workspaceGeneration = useRef(0);
  const attachmentSelectionRef = useRef<symbol | null>(null);
  const workspaceIdentity = useRef<{
    ownerKey: string;
    sessionKey: string;
  } | null>(null);
  const workspaceLoaded = useRef(false);
  const oauthReturn = useRef(
    bridge.kind === "web" &&
      new URLSearchParams(window.location.search).get("auth") === "success",
  );
  const saveSequence = useRef(0);
  const latestDraft = useRef({
    project: p,
    question: creationQuestion,
    locale: s.locale,
    hasReviewed: false,
    missingFiles: restoredAttachmentCount,
  });
  latestDraft.current = {
    project: p,
    question: creationQuestion,
    locale: s.locale,
    hasReviewed: attemptedStages.includes("review"),
    missingFiles: restoredAttachmentCount,
  };
  const suspendAccount = useCallback(() => {
    workspaceGeneration.current++;
    clearWebExportRecovery();
    draftReadyRef.current = false;
    setWebAuthenticated(false);
    setDraftReady(false);
    setConfirm(false);
    setRunning(false);
    pendingRequestRef.current = null;
    reviewGateRef.current = false;
    executionGateRef.current = false;
    setPendingOperationId(null);
  }, []);
  const resetAccountWorkspace = useCallback(() => {
    clearDraftHandoff();
    suspendAccount();
    workspaceIdentity.current = null;
    workspaceLoaded.current = false;
    saveSequence.current++;
    const project = webProject0();
    latestDraft.current = {
      project,
      question: "name",
      locale: latestDraft.current.locale,
      hasReviewed: false,
      missingFiles: 0,
    };
    setProject(project);
    setWebAttachments([]);
    setRejectedAttachments([]);
    setRestoredAttachmentCount(0);
    setResult(null);
    setCopied(false);
    setSaved(false);
    setQuestion("name");
    setAttemptedStages([]);
    setStageFeedback(null);
    setHostMessage(null);
  }, [suspendAccount]);
  const clearAccountWorkspace = useCallback(
    async (identity: { ownerKey: string; sessionKey: string }) => {
      const current = workspaceIdentity.current;
      if (
        !current ||
        current.ownerKey !== identity.ownerKey ||
        current.sessionKey !== identity.sessionKey
      )
        return;
      resetAccountWorkspace();
      await purgeAccountDraft();
    },
    [resetAccountWorkspace],
  );
  const adoptAccountWorkspace = useCallback(
    async (identity: { ownerKey: string; sessionKey: string }) => {
      const handoff = oauthReturn.current
        ? takeDraftHandoff(identity.ownerKey)
        : null;
      oauthReturn.current = false;
      const previous = workspaceIdentity.current;
      if (
        workspaceLoaded.current &&
        draftReadyRef.current &&
        previous?.ownerKey === identity.ownerKey &&
        previous.sessionKey === identity.sessionKey
      )
        return;
      const preserve =
        workspaceLoaded.current && previous?.ownerKey === identity.ownerKey;
      if (!preserve) resetAccountWorkspace();
      else suspendAccount();
      const generation = workspaceGeneration.current;
      let storageProblem = false;
      try {
        if (handoff && !preserve) {
          await bindAccountDraft(handoff);
          await bindAccountDraft(identity, true);
        } else await bindAccountDraft(identity, preserve);
      } catch (error) {
        if (
          !(error instanceof Error) ||
          !["draft_storage_unavailable", "draft_newer_version"].includes(
            error.message,
          )
        )
          throw error;
        // Verified accounts may edit a blank in-memory project. Never read
        // cached answers when their storage context could not be established.
        storageProblem = true;
      }
      if (generation !== workspaceGeneration.current)
        throw new Error("draft_session_changed");
      if (!preserve && !storageProblem) {
        const migration = await loadDraftWithWarnings(webProject0());
        if (generation !== workspaceGeneration.current)
          throw new Error("draft_session_changed");
        if (migration) {
          const project = {
            ...migration.project,
            action: "repository" as const,
            destination: "browser-download",
            attachments: [],
          };
          const navigation = migration.navigation;
          const restoredLocale =
            navigation && !localeExplicitlyChosen.current
              ? navigation.locale
              : latestDraft.current.locale;
          const questions = guidedQuestions(
            project.phase,
            true,
            navigation?.question as GuidedQuestion,
          );
          const question =
            navigation &&
            questions.includes(navigation.question as GuidedQuestion)
              ? (navigation.question as GuidedQuestion)
              : "name";
          latestDraft.current = {
            project,
            question,
            locale: restoredLocale,
            hasReviewed: navigation?.hasReviewed ?? false,
            missingFiles: migration.transientAttachmentCount,
          };
          setProject(project);
          setQuestion(question);
          setRestoredAttachmentCount(migration.transientAttachmentCount);
          setAttemptedStages(navigation?.hasReviewed ? ["review"] : []);
          if (navigation && !localeExplicitlyChosen.current) {
            setS((current) => ({ ...current, locale: restoredLocale }));
            const url = new URL(window.location.href);
            url.searchParams.set("lang", restoredLocale);
            window.history.replaceState(
              null,
              "",
              url.pathname + url.search + url.hash,
            );
          }
          // Restore only after matching the verified session. Do not expose
          // internal question IDs in an intrusive banner above the editor.
          setHostMessage(
            migration.warnings.includes("invalidDraftRecovered")
              ? restoredLocale === "es"
                ? "No se pudo restaurar el borrador guardado porque contenía datos no válidos. Se abrió un borrador vacío."
                : "The saved draft contained invalid data and could not be restored. A blank draft was opened."
              : null,
          );
        }
      }
      workspaceIdentity.current = identity;
      workspaceLoaded.current = true;
      draftReadyRef.current = true;
      setDraftReady(true);
      setDraftState(storageProblem ? "error" : "saved");
    },
    [resetAccountWorkspace, suspendAccount],
  );
  useEffect(() => {
    if (!isWeb) return;
    const invalidated = (event: Event) => {
      resetAccountWorkspace();
      window.dispatchEvent(
        new Event(
          (event as Event & { sessionEnded?: boolean }).sessionEnded
            ? "accreatio:account-ended"
            : "accreatio:account-recheck",
        ),
      );
    };
    window.addEventListener("accreatio:draft-invalidated", invalidated);
    return () =>
      window.removeEventListener("accreatio:draft-invalidated", invalidated);
  }, [isWeb, resetAccountWorkspace]);
  const persistCurrentDraft = () => {
    if (!isWeb || !draftReadyRef.current) return Promise.resolve();
    const current = latestDraft.current;
    const sequence = ++saveSequence.current;
    setDraftState("saving");
    return saveDraft(
      current.project,
      {
        question: current.question,
        hasReviewed: current.hasReviewed,
        locale: current.locale,
      },
      current.project.attachments.length + current.missingFiles,
    )
      .then(() => {
        if (sequence === saveSequence.current) setDraftState("saved");
      })
      .catch((error: unknown) => {
        if (sequence === saveSequence.current) setDraftState("error");
        throw error;
      });
  };
  const setP = (
    value:
      ProjectDefinition | ((previous: ProjectDefinition) => ProjectDefinition),
  ) => {
    const next =
      typeof value === "function" ? value(latestDraft.current.project) : value;
    latestDraft.current.project = next;
    setProject(next);
    void persistCurrentDraft().catch(() => undefined);
  };
  const setCreationQuestion = (question: GuidedQuestion) => {
    latestDraft.current.question = question;
    setQuestion(question);
    void persistCurrentDraft().catch(() => undefined);
  };
  useEffect(() => {
    if (!isWeb) return;
    const navigate = () => {
      void persistCurrentDraft().catch(() => undefined);
      const search = new URLSearchParams(window.location.search);
      const view = search.get("view");
      const language = search.get("lang");
      if (language === "es" || language === "en")
        setS((settings) => ({ ...settings, locale: language }));
      if (view === "welcome") {
        setShowOnboarding(true);
        setTab("new");
      } else if (view === "about") {
        setAboutOpen(true);
        setTab("new");
        setShowOnboarding(!initialOnboarding.completed);
        const url = new URL(window.location.href);
        url.searchParams.set(
          "view",
          initialOnboarding.completed ? "project" : "welcome",
        );
        window.history.replaceState(
          null,
          "",
          url.pathname + url.search + url.hash,
        );
      } else if (view === extraDestination?.id) {
        setTab(view);
        setShowOnboarding(false);
      } else if (view === "project") {
        setTab("new");
        setShowOnboarding(false);
      } else if (!view) {
        const initialView =
          search.get("account") === "continue" || initialOnboarding.completed
            ? "project"
            : "welcome";
        search.set("view", initialView);
        search.set("lang", language === "es" ? "es" : "en");
        window.history.replaceState(
          null,
          "",
          window.location.pathname +
            "?" +
            search.toString() +
            window.location.hash,
        );
        setTab("new");
        setShowOnboarding(initialView === "welcome");
      }
      if (
        /^#about-(faq|terms|operation|security|orchestration)$/.test(
          window.location.hash,
        )
      ) {
        setAboutSection(window.location.hash === "#about-faq" ? "faq" : "info");
        setAboutOpen(true);
      }
    };
    navigate();
    window.addEventListener("hashchange", navigate);
    window.addEventListener("popstate", navigate);
    return () => {
      window.removeEventListener("hashchange", navigate);
      window.removeEventListener("popstate", navigate);
    };
  }, [isWeb]);
  const navigateView = (view: string, locale = s.locale, hash = "") => {
    if (!isWeb) return;
    const url = new URL(window.location.href);
    url.searchParams.set("view", view);
    url.searchParams.set("lang", locale);
    url.searchParams.delete("post");
    url.hash = hash;
    window.history.pushState(null, "", url.pathname + url.search + url.hash);
  };
  const openProjectHelp = (topic: HelpTopic) => {
    setAboutOpen(false);
    setHelpTopic(topic);
  };
  const openWelcome = () => {
    void persistCurrentDraft().catch(() => undefined);
    setWelcomeStep(1);
    setTab("new");
    setShowOnboarding(true);
    setAboutOpen(false);
    navigateView("welcome");
  };
  useEffect(() => {
    if (!isWeb) return;
    const params = new URLSearchParams(window.location.search);
    if (tab === extraDestination?.id && params.has("post")) return;
    const view = showOnboarding ? "welcome" : tab === "new" ? "project" : tab;
    const es = s.locale === "es";
    const section =
      view === "about"
        ? es
          ? "Acerca de"
          : "About"
        : view === extraDestination?.id
          ? extraDestination.labels[s.locale]
          : view === "project"
            ? result
              ? es
                ? "Resultado"
                : "Result"
              : !webAuthenticated
                ? es
                  ? "Acceso"
                  : "Sign in"
                : creationStage === "review"
                  ? es
                    ? "Revisión"
                    : "Review"
                  : es
                    ? "Proyecto"
                    : "Project"
            : es
              ? "Inicio"
              : "Home";
    const title = `accreatio | ${section}`;
    const description = es
      ? "Ordena tu idea, sus límites y los materiales que ya tienes. Descarga un ZIP para continuar con tu asistente de programación. Beta web gratuita."
      : "Organize your idea, constraints, and supporting material. Download a ZIP to continue with your coding assistant. Free web beta.";
    const canonical = `https://accreatio.com/?view=${view}&lang=${s.locale}`;
    document.title = title;
    document
      .querySelector('link[rel="canonical"]')
      ?.setAttribute("href", canonical);
    for (const [selector, content] of [
      ['meta[name="description"]', description],
      ['meta[property="og:title"]', title],
      ['meta[property="og:description"]', description],
      ['meta[property="og:url"]', canonical],
      ['meta[property="og:locale"]', es ? "es_ES" : "en_US"],
    ])
      document.querySelector(selector)?.setAttribute("content", content);
  }, [
    isWeb,
    tab,
    showOnboarding,
    s.locale,
    webAuthenticated,
    creationStage,
    result,
    extraDestination,
  ]);
  useEffect(() => {
    if (!isWeb) return;
    if (!webAuthenticated) {
      setConfirm(false);
      setPendingOperationId(null);
      pendingRequestRef.current = null;
      reviewGateRef.current = false;
    }
  }, [isWeb, webAuthenticated]);
  const t = tr[s.locale];
  const navigationIds: AppDestination[] = isWeb
    ? ["new", ...(extraDestination ? [extraDestination.id] : []), "about"]
    : ["new", "orchestrationCenter", "settings", "history", "about"];
  const navigationLabels: Record<string, string> = {
    new: t.new,
    orchestrationCenter: t.orchestrationCenter,
    settings: t.settings,
    history: t.history,
    about: t.about,
  };
  const navigation = navigationIds.map((id) => ({
    id,
    label:
      id === extraDestination?.id
        ? extraDestination.labels[s.locale]
        : navigationLabels[id],
  }));
  const shellStatus =
    isWeb && !webAuthenticated
      ? {
          label:
            s.locale === "es" ? "Verifica tu sesión" : "Verify your session",
        }
      : running
        ? {
            label: s.locale === "es" ? "Creando" : "Creating",
            detail: p.name || t.title,
          }
        : result
          ? {
              label: result.ok ? t.success : t.failed,
              detail: result.projectPath,
              tone: result.ok ? ("success" as const) : ("warning" as const),
            }
          : isWeb && draftState === "loading"
            ? {
                label:
                  s.locale === "es" ? "Cargando borrador" : "Loading draft",
              }
            : isWeb && draftState === "saving"
              ? {
                  label:
                    s.locale === "es" ? "Guardando borrador" : "Saving draft",
                }
              : isWeb && draftState === "error"
                ? {
                    label:
                      s.locale === "es"
                        ? "El borrador necesita atención"
                        : "Draft needs attention",
                    tone: "warning" as const,
                  }
                : tab === "new"
                  ? {
                      label: isWeb
                        ? s.locale === "es"
                          ? "Borrador guardado localmente"
                          : "Draft saved locally"
                        : s.locale === "es"
                          ? "Proyecto sin ejecutar"
                          : "Project not run",
                      detail: isWeb
                        ? s.locale === "es"
                          ? "Salida: ZIP"
                          : "Output: ZIP"
                        : p.dryRun
                          ? "Dry run"
                          : undefined,
                    }
                  : {
                      label:
                        tab === extraDestination?.id
                          ? extraDestination.labels[s.locale]
                          : (navigationLabels[tab] ?? t.about),
                    };
  const reportHostError = (error: unknown) =>
    setHostMessage(
      error instanceof Error
        ? error.message
        : s.locale === "es"
          ? "No compatible con este entorno"
          : "Not supported in this host",
    );
  const completeOnboarding = () => {
    setOnboardingStorageAvailable(saveOnboardingCompletion());
    setShowOnboarding(false);
    setTab("new");
    navigateView("project");
  };
  useEffect(() => {
    if (isWeb) return;
    bridge
      .loadSettings()
      .then((v) => {
        setS(v);
        setP((x) => ({ ...x, destination: v.baseFolder }));
      })
      .catch(reportHostError);
    refresh();
  }, []);
  useEffect(() => {
    const theme = s.theme;
    document.documentElement.dataset.theme = theme;
    document.documentElement.lang = s.locale;
    document
      .querySelector<HTMLMetaElement>('meta[name="theme-color"]')
      ?.setAttribute("content", theme === "dark" ? "#242726" : "#e8eae7");
  }, [s.locale, s.theme]);
  const toggleTheme = () => {
    const theme = s.theme === "dark" ? "light" : "dark";
    if (isWeb) {
      try {
        window.localStorage.setItem(WEB_THEME_KEY, theme);
      } catch {
        // Theme changes remain available when browser storage is unavailable.
      }
    }
    setS((current) => ({ ...current, theme }));
  };
  const flushDraftBeforeSignIn = async (redirect = false) => {
    // A new login must never inherit a marker left by a failed logout cleanup.
    clearDraftHandoff(undefined, true);
    // First sign-in has no private draft to flush. A suspended, verified owner
    // may still flush before a controlled OAuth redirect.
    if (!workspaceLoaded.current) return;
    if (!draftReadyRef.current) {
      const current = latestDraft.current;
      await saveDraft(
        current.project,
        {
          question: current.question,
          hasReviewed: current.hasReviewed,
          locale: current.locale,
        },
        current.project.attachments.length + current.missingFiles,
      );
      if (redirect && workspaceIdentity.current)
        saveDraftHandoff(workspaceIdentity.current);
      return;
    }
    await persistCurrentDraft();
    if (redirect && workspaceIdentity.current)
      saveDraftHandoff(workspaceIdentity.current);
  };
  useEffect(() => {
    if (!p.orchestration.enabled) return;
    const reconciled = p.participants.map((planned) => {
      const existing = p.orchestration.participants.find(
        (configured) => configured.participantId === planned.id,
      );
      return (
        existing ?? {
          participantId: planned.id,
          provider: DEFAULT_PROVIDER_ID,
          task: defaultRoleTask(planned.role, p.name),
        }
      );
    });
    if (
      JSON.stringify(reconciled) !==
      JSON.stringify(p.orchestration.participants)
    )
      setP({
        ...p,
        orchestration: { ...p.orchestration, participants: reconciled },
      });
  }, [p.participants, p.name, p.orchestration.enabled]);
  const refresh = () => {
    if (isWeb) return;
    bridge.githubStatus().then(setGh).catch(reportHostError);
    bridge.loadHistory().then(setHistory).catch(reportHostError);
  };
  const newWebDraft = async () => {
    if (!isWeb) return;
    const accepted = window.confirm(
      s.locale === "es"
        ? `¿Descartar el borrador actual${webAttachments.length ? ` y quitar ${webAttachments.length} archivo(s) local(es)` : ""} y empezar uno nuevo?`
        : `Discard the current draft${webAttachments.length ? ` and remove ${webAttachments.length} selected local file(s)` : ""} and start a new one?`,
    );
    if (!accepted) return;
    const generation = workspaceGeneration.current;
    try {
      await clearDraft();
    } catch {
      setDraftState("error");
      return;
    }
    if (generation !== workspaceGeneration.current) return;
    clearWebExportRecovery();
    latestDraft.current.missingFiles = 0;
    setP(webProject0());
    setWebAttachments([]);
    setRejectedAttachments([]);
    setRestoredAttachmentCount(0);
    setResult(null);
    setCreationQuestion("name");
    setAttemptedStages([]);
    setStageFeedback(null);
    setDraftState("saved");
  };
  const checkProviders = () => {
    setCheckingProviders(true);
    bridge
      .checkProviders()
      .then((results) => {
        availabilityById(results);
        setProviders(results);
        setHostMessage(null);
      })
      .catch((error) => {
        setProviders(null);
        reportHostError(error);
      })
      .finally(() => setCheckingProviders(false));
  };
  const providerReason = (reasonCode: ProviderAvailabilityReason) =>
    ({
      es: {
        ready: "Disponible",
        cli_not_found: "CLI no encontrada",
        not_logged_in: "Inicio de sesión requerido",
        unsupported_auth_mode:
          "Usa una suscripción compatible, no una clave API",
        auth_status_unreadable: "No se pudo verificar el inicio de sesión",
        host_cannot_detect:
          "Este navegador no puede verificar la instalación ni el inicio de sesión local",
      },
      en: {
        ready: "Available",
        cli_not_found: "CLI not found",
        not_logged_in: "Sign-in required",
        unsupported_auth_mode: "Use a supported subscription, not an API key",
        auth_status_unreadable: "Could not verify sign-in",
        host_cannot_detect:
          "This browser cannot check local installation or sign-in",
      },
    })[s.locale][reasonCode];
  const prompt = useMemo(() => {
    const issues = isWeb ? validateWebProject(p, s) : validateProject(p, s);
    if (
      issues.context === "contextTooLong" ||
      issues.restrictions === "restrictionsTooLong"
    )
      return s.locale === "es"
        ? "Reduce el texto señalado para generar la vista previa."
        : "Shorten the highlighted text to generate the preview.";
    return generatePrompt(p, s.locale);
  }, [p, s.locale]);
  const actions = useMemo(() => planActions(p, s), [p, s]);
  useEffect(() => {
    if (!isWeb) return;
    const download = async () => {
      const generation = workspaceGeneration.current;
      try {
        const files = buildLocalDataExport(
          draftReadyRef.current ? p : null,
          s,
          draftReadyRef.current ? webAttachments : [],
          restoredAttachmentCount,
        );
        const { downloadZip } = await import("client-zip");
        const blob = await downloadZip(
          files.map((file) => ({ name: file.path, input: file.input })),
        ).blob();
        if (generation !== workspaceGeneration.current)
          throw new Error("local_context_changed");
        const url = URL.createObjectURL(blob),
          link = document.createElement("a");
        link.href = url;
        link.download = "accreatio-local-data.zip";
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        window.dispatchEvent(
          new CustomEvent("accreatio:local-data-result", {
            detail: { ok: true },
          }),
        );
      } catch {
        window.dispatchEvent(
          new CustomEvent("accreatio:local-data-result", {
            detail: { ok: false },
          }),
        );
      }
    };
    window.addEventListener("accreatio:download-local-data", download);
    return () =>
      window.removeEventListener("accreatio:download-local-data", download);
  }, [isWeb, p, s, webAttachments, restoredAttachmentCount]);
  useEffect(() => {
    if (!isWeb) return;
    const feature = aboutOpen
      ? "about"
      : showOnboarding
        ? "onboarding"
        : tab === "new"
          ? "creation"
          : tab === "about"
            ? "about"
            : null;
    if (!feature) return;
    const at = performance.now();
    window.dispatchEvent(
      new CustomEvent("accreatio:usage", {
        detail: {
          kind: "usage",
          feature,
          outcome: "opened",
          durationBand: "instant",
        },
      }),
    );
    return () => {
      const elapsed = (performance.now() - at) / 60000;
      window.dispatchEvent(
        new CustomEvent("accreatio:usage", {
          detail: {
            kind: "usage",
            feature,
            outcome: "left",
            durationBand:
              elapsed < 1
                ? "under-minute"
                : elapsed < 5
                  ? "1-5-minutes"
                  : elapsed < 15
                    ? "5-15-minutes"
                    : "15-plus-minutes",
          },
        }),
      );
    };
  }, [isWeb, tab, showOnboarding, aboutOpen]);
  const executionPreview = useMemo(() => {
    let manifest: string[] = [];
    if (isWeb && p.action !== "tracking") {
      try {
        if (Object.keys(validateWebProject(p, s)).length) return null;
        manifest = buildWebExport(p, s, webAttachments, {
          appVersion: __APP_VERSION__,
        }).map(({ path }) => path);
      } catch {
        // Validation blocks Review; keep the preview projection side-effect free.
      }
    }
    try {
      return buildExecutionPreview(p, s, isWeb ? "web" : "desktop", manifest);
    } catch {
      return null;
    }
  }, [isWeb, p, s, webAttachments]);
  const errors: Record<string, string> = isWeb
      ? {
          ...validateWebProject(p, s),
          ...(restoredAttachmentCount > 0
            ? { attachments: "reselectAttachments" }
            : {}),
        }
      : validateProject(p, s),
    valid = !Object.keys(errors).length;
  const currentQuestionInvalid = questionInvalid(creationQuestion, errors);
  useEffect(() => {
    if (!currentQuestionInvalid) setStageFeedback(null);
  }, [currentQuestionInvalid]);
  const stageInvalid = (stage: CreationStage) =>
    stage === "foundation"
      ? Boolean(errors.name || errors.attachments)
      : stage === "context"
        ? Boolean(errors.context || errors.restrictions)
        : stage === "team"
          ? Boolean(
              errors.participants || errors.orchestration || errors.funding,
            )
          : stage === "delivery"
            ? Boolean(
                errors.destination ||
                errors.tracking ||
                errors.openIde ||
                errors.createRemote,
              )
            : false;
  const stageComplete = (stage: CreationStage) =>
    stage === "foundation"
      ? Boolean(p.name.trim()) && !errors.name && !errors.attachments
      : stage === "context"
        ? Boolean(p.context.trim()) && !errors.context
        : stage === "team"
          ? !stageInvalid("team") && p.participants.length > 0
          : stage === "delivery"
            ? !stageInvalid("delivery") &&
              (isWeb ||
                p.action === "tracking" ||
                Boolean(p.destination.trim()))
            : false;
  const stageOrder = [
    "foundation",
    "context",
    "team",
    "delivery",
    "review",
  ] as const;
  // A stage the user has never opened cannot advertise itself as complete:
  // the defaults (one participant, a browser ZIP destination) would otherwise
  // mark Team and Delivery done before they were ever seen.
  const stageReached = (stage: CreationStage) =>
    stageOrder.indexOf(stage) < stageOrder.indexOf(creationStage) ||
    attemptedStages.includes(stage);
  // Field errors appear once the user has tried to leave the stage, not while
  // a field they have not reached yet is merely still empty.
  const visibleErrors = attemptedStages.includes(creationStage) ? errors : {};
  const stageStates = Object.fromEntries(
    stageOrder.map((stage) => [
      stage,
      stage === creationStage
        ? "current"
        : attemptedStages.includes(stage) && stageInvalid(stage)
          ? "attention"
          : stageReached(stage) && stageComplete(stage)
            ? "complete"
            : "upcoming",
    ]),
  ) as Record<CreationStage, StageState>;
  const changeCreationQuestion = (next: GuidedQuestion) => {
    if (next === creationQuestion) return;
    setAttemptedStages((current) =>
      current.includes(creationStage) ? current : [...current, creationStage],
    );
    if (!canMoveToQuestion(creationQuestion, next, errors)) {
      if (creationStage === "review") return;
      setStageFeedback(
        s.locale === "es"
          ? "Revisa el campo señalado para continuar."
          : "Check the highlighted field to continue.",
      );
      const firstInvalidId = creationFocusTarget(creationStage, errors);
      requestAnimationFrame(() => {
        const target = document.getElementById(firstInvalidId);
        for (
          let parent = target?.parentElement;
          parent;
          parent = parent.parentElement
        ) {
          if (parent instanceof HTMLDetailsElement) parent.open = true;
        }
        focusCreationTarget(firstInvalidId);
      });
      return;
    }
    setStageFeedback(null);
    setCreationQuestion(next);
  };
  const changeCreationStage = (next: CreationStage) =>
    changeCreationQuestion(stageQuestion(next));
  const changeProjectPhase = (phase: ProjectDefinition["phase"]) => {
    if (
      isWeb &&
      phase === "idea" &&
      webAttachments.length &&
      !window.confirm(
        s.locale === "es"
          ? `Cambiar a Idea quita ${webAttachments.length} archivo(s) de esta pestaña.`
          : `Changing to Idea removes ${webAttachments.length} file(s) held in this tab.`,
      )
    )
      return false;
    if (isWeb && phase === "idea") {
      setWebAttachments([]);
      setRejectedAttachments([]);
      setRestoredAttachmentCount(0);
      latestDraft.current.missingFiles = 0;
    }
    setP({ ...p, phase, attachments: phase === "idea" ? [] : p.attachments });
    return true;
  };
  const errorText = (code?: string) =>
    code
      ? (
          {
            es: {
              required: "Campo obligatorio.",
              reselectAttachments:
                "Vuelve a seleccionar los archivos pendientes o confirma que continuarás sin ellos.",
              invalid: "Valor no válido.",
              participantCount: "Define entre 1 y 6 participantes.",
              webNameLength: "Usa un máximo de 50 caracteres.",
              contextTooLong:
                "Usa un máximo de 20.000 caracteres para tu idea.",
              restrictionsTooLong:
                "Usa un máximo de 10.000 caracteres para tus límites.",
              webParticipantCount: "Define entre 1 y 4 participantes.",
              duplicateParticipantRole:
                "Elige un rol diferente para cada participante.",
              invalidParticipantIdentity:
                "Revisa los ID y etiquetas de participantes.",
              duplicateParticipantIdentity:
                "Cada ID de participante debe ser único.",
              invalidOrchestrationParticipants:
                "Revisa cada participante, tarea, proveedor y límite de Mode 1.",
              funding_invalid: "Revisa la política de financiación.",
              api_not_supported:
                "La API de pago no está disponible: ningún proveedor/perfil puede imponer un límite de coste acumulado exacto.",
              orchestrationContractUnsupported:
                "La topología es válida, pero no es compatible con el contrato AEKR actual. Usa Mode 0/manual o configura de 1 a 4 roles únicos.",
            },
            en: {
              required: "Required field.",
              reselectAttachments:
                "Reselect the missing files or confirm you will continue without them.",
              invalid: "Invalid value.",
              participantCount: "Define between 1 and 6 participants.",
              webNameLength: "Use no more than 50 characters.",
              contextTooLong:
                "Use no more than 20,000 characters for your idea.",
              restrictionsTooLong:
                "Use no more than 10,000 characters for your boundaries.",
              webParticipantCount: "Define between 1 and 4 participants.",
              duplicateParticipantRole:
                "Choose a different role for each participant.",
              invalidParticipantIdentity: "Review participant IDs and labels.",
              duplicateParticipantIdentity:
                "Each participant ID must be unique.",
              invalidOrchestrationParticipants:
                "Review every Mode 1 participant, task, provider, and limit.",
              funding_invalid: "Review the funding policy.",
              api_not_supported:
                "Paid API is unavailable: no provider/profile can enforce an exact cumulative cost ceiling.",
              orchestrationContractUnsupported:
                "The topology is valid, but unsupported by the current AEKR contract. Use Mode 0/manual or configure 1–4 unique roles.",
            },
          }[s.locale] as Record<string, string>
        )[code] || code
      : undefined;
  const choose = async (
    k: "destination" | "baseFolder" | "toolkitPath" | "futureProjectsPath",
  ) => {
    const v = await bridge.chooseFolder().catch((error) => {
      reportHostError(error);
      return null;
    });
    if (!v) return;
    if (k === "destination") setP({ ...p, destination: v });
    else if (k === "toolkitPath")
      setS({
        ...s,
        toolkitPath: v,
        futureProjectsPath: s.futureProjectsPath || `${v}\\future_projects`,
      });
    else setS({ ...s, [k]: v });
  };
  const attach = async () => {
    if (
      attachmentSelectionRef.current ||
      reviewGateRef.current ||
      executionGateRef.current ||
      (isWeb && !draftReadyRef.current)
    )
      return;
    const selection = Symbol("attachment-selection");
    attachmentSelectionRef.current = selection;
    setInspectingAttachments(true);
    const generation = workspaceGeneration.current;
    const attachmentSnapshot = latestDraft.current.project.attachments;
    const selectionPhase = latestDraft.current.project.phase;
    const selectionCurrent = () =>
      attachmentSelectionRef.current === selection &&
      generation === workspaceGeneration.current &&
      draftReadyRef.current &&
      latestDraft.current.project.attachments === attachmentSnapshot &&
      latestDraft.current.project.phase === selectionPhase;
    try {
      const files = await bridge.chooseAttachments().catch((error) => {
        reportHostError(error);
        return [];
      });
      if (isWeb) {
        if (!selectionCurrent()) return;
        const candidates = files.filter(
          (file): file is WebAttachment => "blob" in file,
        );
        const accepted = [...webAttachments];
        const rejected: { id: string; name: string; reason: string }[] = [];
        for (const candidate of candidates) {
          const issues = validateAttachmentSet([
            ...accepted.map(({ name, size, extension }) => ({
              name,
              size,
              extension,
            })),
            {
              name: candidate.name,
              size: candidate.size,
              extension: candidate.extension,
            },
          ]);
          const issue =
            issues.find((entry) => entry.index === accepted.length) ??
            issues.find(
              (entry) =>
                entry.code === "tooManyFiles" || entry.code === "totalTooLarge",
            );
          if (issue)
            rejected.push({
              id: candidate.id,
              name: candidate.name,
              reason: issue.code,
            });
          else {
            try {
              const blob = await prepareAttachment(
                candidate.blob,
                candidate.name,
              );
              if (!selectionCurrent()) return;
              const prepared = { ...candidate, blob, size: blob.size };
              const preparedIssues = validateAttachmentSet([
                ...accepted,
                prepared,
              ]);
              const preparedIssue = preparedIssues.find(
                (entry) =>
                  entry.index === accepted.length ||
                  entry.code === "tooManyFiles" ||
                  entry.code === "totalTooLarge",
              );
              if (preparedIssue)
                rejected.push({
                  id: candidate.id,
                  name: candidate.name,
                  reason: preparedIssue.code,
                });
              else accepted.push(prepared);
            } catch (error) {
              if (!selectionCurrent()) return;
              rejected.push({
                id: candidate.id,
                name: candidate.name,
                reason:
                  error instanceof AttachmentSecurityError
                    ? error.code
                    : "unavailable",
              });
            }
          }
        }
        if (!selectionCurrent()) return;
        setWebAttachments(accepted);
        setRejectedAttachments(rejected);
        const missing = Math.max(
          0,
          latestDraft.current.missingFiles -
            (accepted.length - webAttachments.length),
        );
        setRestoredAttachmentCount(missing);
        latestDraft.current.missingFiles = missing;
        setP((current) => ({
          ...current,
          attachments: accepted.map(({ name, size, extension }) => ({
            name,
            size,
            extension,
          })),
        }));
        return;
      }
      const desktopFiles = files.filter(
        (file): file is Attachment => "path" in file,
      );
      const existingDesktop = p.attachments.filter(
        (file): file is Attachment => "path" in file,
      );
      setP({
        ...p,
        attachments: [...existingDesktop, ...desktopFiles].filter(
          (v, i, a) => a.findIndex((x) => x.path === v.path) === i,
        ),
      });
    } finally {
      if (attachmentSelectionRef.current === selection) {
        attachmentSelectionRef.current = null;
        setInspectingAttachments(false);
      }
    }
  };
  const addParticipant = () => {
    setP((current) => {
      if (isWeb && current.participants.length >= 4) return current;
      const role = isWeb
        ? CANONICAL_ROLES.find(
            (candidate) =>
              !current.participants.some((entry) => entry.role === candidate),
          )
        : "generalist";
      const id = allocateParticipantId(current.participants);
      if (!id || !role) return current;
      return {
        ...current,
        participants: [
          ...current.participants,
          participant(id, role, isWeb ? s.locale : "es"),
        ],
      };
    });
  };
  const closeConfirmation = () => {
    if (running) return;
    setConfirm(false);
    setPendingOperationId(null);
    pendingRequestRef.current = null;
    reviewGateRef.current = false;
    queueMicrotask(() => executionTriggerRef.current?.focus());
  };
  const openExecutionConfirmation = (definition: ProjectDefinition) => {
    if (
      (isWeb && !webAuthenticated) ||
      reviewGateRef.current ||
      running ||
      attachmentSelectionRef.current
    )
      return;
    if (
      Object.keys(
        isWeb
          ? validateWebProject(definition, s)
          : validateProject(definition, s),
      ).length
    )
      return;
    executionTriggerRef.current =
      document.activeElement instanceof HTMLButtonElement
        ? document.activeElement
        : null;
    reviewGateRef.current = true;
    const operationId = crypto.randomUUID();
    pendingRequestRef.current = {
      operationId,
      definition: structuredClone(definition),
      settings: structuredClone(s),
      ...(isWeb && webAttachments.length ? { webAttachments } : {}),
    };
    setPendingOperationId(operationId);
    setConfirm(true);
  };
  const reviewExecution = () => openExecutionConfirmation(p);
  const downloadZipFromResult = () => {
    if (
      !isWeb ||
      !result?.ok ||
      result.outcome !== "dry-run" ||
      !valid ||
      running ||
      attachmentSelectionRef.current ||
      reviewGateRef.current
    )
      return;
    const definition = { ...p, dryRun: false };
    setP(definition);
    openExecutionConfirmation(definition);
  };
  const copyPrompt = async () => {
    await navigator.clipboard.writeText(prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  };
  const downloadPrompt = () => {
    const url = URL.createObjectURL(
      new Blob([prompt], { type: "text/markdown;charset=utf-8" }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = `${slugify(p.name) || "project"}-prompt.md`;
    link.click();
    URL.revokeObjectURL(url);
  };
  const execute = async () => {
    if ((isWeb && !webAuthenticated) || executionGateRef.current) return;
    const request = pendingRequestRef.current;
    if (!request || request.operationId !== pendingOperationId) return;
    executionGateRef.current = true;
    const generation = workspaceGeneration.current;
    setRunning(true);
    setResult(null);
    setConfirm(false);
    try {
      const r = await bridge.execute(request).catch((error) => ({
        operationId: request.operationId,
        ok: false,
        dryRun: request.definition.dryRun,
        completed: [],
        logs: [],
        outcome: "failure" as const,
        steps: [],
        artifacts: [],
        error:
          error instanceof Error ? error.message : "Not supported in this host",
      }));
      if (isWeb && generation !== workspaceGeneration.current) return;
      setResult(r);
      if (isWeb && !request.definition.dryRun)
        window.dispatchEvent(
          new CustomEvent("accreatio:usage", {
            detail: {
              kind: "usage",
              feature: "export",
              outcome: r.ok ? "completed" : "error",
              durationBand: "instant",
            },
          }),
        );
      refresh();
    } finally {
      if (isWeb && generation !== workspaceGeneration.current) return;
      executionGateRef.current = false;
      reviewGateRef.current = false;
      pendingRequestRef.current = null;
      setPendingOperationId(null);
      setRunning(false);
      setConfirm(false);
      queueMicrotask(() => executionTriggerRef.current?.focus());
    }
  };
  useEffect(() => {
    if (!confirm) return;
    const dialog = executionDialogRef.current;
    if (!dialog) return;
    if (!dialog.open) dialog.showModal();
    dialog.querySelector<HTMLButtonElement>(".modal-actions .confirm")?.focus();
    const onCancel = (event: Event) => {
      event.preventDefault();
      if (!running) closeConfirmation();
    };
    dialog.addEventListener("cancel", onCancel);
    return () => {
      dialog.removeEventListener("cancel", onCancel);
      if (dialog.open) dialog.close();
    };
  }, [confirm, running]);
  return (
    <>
      <AccountShell
        config={DEFAULT_ACCOUNT_FEATURE_CONFIG}
        provider={inactiveAccountProvider}
      />
      <AppFrame
        atmosphere={
          showOnboarding
            ? "home"
            : tab === "about" || tab === extraDestination?.id
              ? "about"
              : tab !== "new"
                ? "quiet"
                : running || result
                  ? "export"
                  : creationStage === "review"
                    ? "review"
                    : "creation"
        }
        currentDestination={tab}
        floatingDestinationOpen={aboutOpen ? "about" : undefined}
        webFooter={isWeb}
        transitionKey={
          showOnboarding
            ? "welcome"
            : tab !== "new"
              ? tab
              : isWeb && !webAuthenticated
                ? "sign-in"
                : running
                  ? "creating"
                  : result
                    ? "outcome"
                    : `project-${creationQuestion}`
        }
        locale={s.locale}
        navigation={navigation}
        newProjectAccessory={
          isWeb ? (
            <div className="account-nav-slot" ref={setAccountMenuTarget} />
          ) : undefined
        }
        onBrandActivate={openWelcome}
        onDestinationChange={async (destination) => {
          if (isWeb && destination === "about") {
            setAboutSection("info");
            setAboutOpen((open) => !open);
            return;
          }
          await persistCurrentDraft().catch(() => undefined);
          setAboutOpen(false);
          setTab(destination);
          setShowOnboarding(false);
          navigateView(destination === "new" ? "project" : destination);
        }}
        onLocaleToggle={() => {
          localeExplicitlyChosen.current = true;
          const locale = s.locale === "es" ? "en" : "es";
          setS({ ...s, locale });
          latestDraft.current.locale = locale;
          void persistCurrentDraft().catch(() => undefined);
          if (isWeb) {
            const url = new URL(window.location.href);
            url.searchParams.set("lang", locale);
            window.history.replaceState(
              null,
              "",
              url.pathname + url.search + url.hash,
            );
          }
        }}
        onThemeToggle={toggleTheme}
        status={shellStatus}
        tagline={t.tag}
        theme={s.theme}
        wrapContent={(children) => (
          <AccountBoundary
            locale={s.locale}
            active={tab === "new" && !showOnboarding}
            onSessionChange={accountSessionChanged}
            onAccountReady={adoptAccountWorkspace}
            onSuspendAccount={suspendAccount}
            onClearAccount={clearAccountWorkspace}
            onBeforeSignIn={flushDraftBeforeSignIn}
            transientAttachmentCount={webAttachments.length}
            accountMenuTarget={accountMenuTarget}
            onRequireSignIn={() => {
              setTab("new");
              setShowOnboarding(false);
              setAboutOpen(false);
            }}
            onBack={() => {
              setWelcomeStep(2);
              setShowOnboarding(true);
            }}
          >
            {isWeb && tab === "new" && !showOnboarding && !draftReady ? (
              <main className="onboarding draft-loading" aria-busy="true">
                <section className="onboarding-card">
                  <p role="status">
                    {s.locale === "es" ? "Cargando borrador" : "Loading draft"}
                  </p>
                </section>
              </main>
            ) : (
              children
            )}
          </AccountBoundary>
        )}
      >
        {showOnboarding ? (
          <Onboarding
            isWeb={isWeb}
            locale={s.locale}
            initialStep={welcomeStep}
            onComplete={completeOnboarding}
            storageAvailable={onboardingStorageAvailable}
            tagline={t.tag}
          />
        ) : (
          hostMessage && (
            <div className="inline-error" role="alert">
              {hostMessage}
            </div>
          )
        )}
        {!showOnboarding &&
          (tab === "new" ? (
            running || result ? (
              <OutcomePanel
                onHelp={isWeb && webAuthenticated ? openProjectHelp : undefined}
                onDownloadZip={downloadZipFromResult}
                downloadZipDisabled={running || !valid}
                isWeb={isWeb}
                locale={s.locale}
                onBackToReview={() => {
                  setResult(null);
                  setCreationQuestion("review");
                }}
                onCopyPath={() => {
                  if (result?.projectPath)
                    void navigator.clipboard.writeText(result.projectPath);
                }}
                onOpenOrchestration={() => setTab("orchestrationCenter")}
                result={result}
                running={running}
              />
            ) : (
              <GuidedCreation
                isWeb={isWeb}
                onHelp={isWeb && webAuthenticated ? openProjectHelp : undefined}
                current={creationQuestion}
                feedback={stageFeedback}
                hasReviewed={attemptedStages.includes("review")}
                locale={s.locale}
                onMove={changeCreationQuestion}
                project={p}
                toolbar={
                  <>
                    <div className="entry-actions">
                      <span className="privacy">
                        <ShieldCheck size={15} />
                        {isWeb
                          ? s.locale === "es"
                            ? "PWA local · beta"
                            : "Local PWA · beta"
                          : t.local}
                      </span>
                    </div>
                    {isWeb && (
                      <WebExperienceIntro
                        locale={s.locale}
                        draftState={draftState}
                        onNewDraft={newWebDraft}
                      />
                    )}
                  </>
                }
              >
                {creationQuestion === "name" ||
                creationQuestion === "phase" ||
                creationQuestion === "context" ||
                creationQuestion === "restrictions" ||
                creationQuestion === "route" ? (
                  <GuidedBasics
                    isWeb={isWeb}
                    current={creationQuestion}
                    errorText={errorText}
                    errors={visibleErrors}
                    locale={s.locale}
                    onChange={setP}
                    onMove={changeCreationQuestion}
                    onPhaseChange={changeProjectPhase}
                    project={p}
                  />
                ) : creationQuestion === "attachments" ? (
                  <GuidedAttachments
                    errorText={errorText}
                    errors={visibleErrors}
                    isWeb={isWeb}
                    inspectingAttachments={inspectingAttachments}
                    locale={s.locale}
                    onAddAttachments={attach}
                    onChange={setP}
                    onDismissRestoredAttachments={() => {
                      if (attachmentSelectionRef.current) return;
                      setRestoredAttachmentCount(0);
                      latestDraft.current.missingFiles = 0;
                      void persistCurrentDraft().catch(() => undefined);
                    }}
                    onPhaseChange={changeProjectPhase}
                    onRemoveAttachment={(index) => {
                      if (attachmentSelectionRef.current) return;
                      setP({
                        ...p,
                        attachments: p.attachments.filter(
                          (_, itemIndex) => itemIndex !== index,
                        ),
                      });
                      if (isWeb)
                        setWebAttachments(
                          webAttachments.filter(
                            (_, itemIndex) => itemIndex !== index,
                          ),
                        );
                    }}
                    onRemoveRejectedAttachment={(id) => {
                      if (attachmentSelectionRef.current) return;
                      setRejectedAttachments(
                        rejectedAttachments.filter((item) => item.id !== id),
                      );
                    }}
                    project={p}
                    rejectedAttachments={rejectedAttachments}
                    restoredAttachmentCount={restoredAttachmentCount}
                    webAttachments={webAttachments}
                  />
                ) : creationStage === "team" ? (
                  <>
                    <GuidedTeam
                      isWeb={isWeb}
                      locale={s.locale}
                      project={p}
                      invalid={questionInvalid("team", visibleErrors)}
                    >
                      <TeamStage
                        errorText={errorText}
                        errors={visibleErrors}
                        isWeb={isWeb}
                        locale={s.locale}
                        onAddParticipant={addParticipant}
                        onChange={setP}
                        onConfigureMode1={() => setMode1DialogOpen(true)}
                        mode1TriggerRef={mode1TriggerRef}
                        project={p}
                        responsibilities={responsibilities}
                      />
                      {isWeb && (
                        <>
                          <label htmlFor="advanced-route">
                            {s.locale === "es" ? "Ruta" : "Working approach"}
                          </label>
                          <select
                            id="advanced-route"
                            value={p.route}
                            onChange={(event) =>
                              setP({
                                ...p,
                                route: event.target
                                  .value as ProjectDefinition["route"],
                              })
                            }
                          >
                            <option value="local">
                              {s.locale === "es"
                                ? "Herramientas locales"
                                : "Local tools"}
                            </option>
                            <option value="vendor">
                              {s.locale === "es"
                                ? "Plataforma gestionada"
                                : "Managed platform"}
                            </option>
                            <option value="mixed">
                              {s.locale === "es" ? "Combinada" : "Mixed"}
                            </option>
                          </select>
                          <DeliveryStage
                            embedded
                            errorText={errorText}
                            errors={visibleErrors}
                            isWeb
                            locale={s.locale}
                            onBrowseDestination={() => undefined}
                            onChange={setP}
                            onOpenSettings={() => undefined}
                            project={p}
                          />
                        </>
                      )}
                    </GuidedTeam>
                    {mode1DialogOpen && (
                      <Mode1ConfigurationDialog
                        locale={s.locale}
                        projectName={p.name}
                        participants={p.participants}
                        orchestration={p.orchestration}
                        providers={providers}
                        checkingProviders={checkingProviders}
                        hostKind={
                          bridge.kind === "electron" ? "electron" : "web"
                        }
                        onCheckProviders={checkProviders}
                        providerReasonText={providerReason}
                        responsibilityLabel={(role) =>
                          responsibilities[role][s.locale]
                        }
                        onSave={(config) =>
                          setP({ ...p, orchestration: config })
                        }
                        onClose={() => {
                          setMode1DialogOpen(false);
                          mode1TriggerRef.current?.focus();
                        }}
                      />
                    )}
                  </>
                ) : creationStage === "delivery" ? (
                  <DeliveryStage
                    errorText={errorText}
                    errors={visibleErrors}
                    isWeb={isWeb}
                    locale={s.locale}
                    onBrowseDestination={() => choose("destination")}
                    onChange={setP}
                    onOpenSettings={() => setTab("settings")}
                    project={p}
                  />
                ) : (
                  <ReviewStage
                    isWeb={isWeb}
                    actions={actions}
                    copied={copied}
                    locale={s.locale}
                    onChange={setP}
                    onConfirm={reviewExecution}
                    onCopy={copyPrompt}
                    onDownload={downloadPrompt}
                    onStageChange={changeCreationStage}
                    preview={executionPreview}
                    project={p}
                    prompt={prompt}
                    running={running || inspectingAttachments}
                    stageStates={stageStates}
                    valid={valid}
                  />
                )}
                {creationStage !== "review" && (
                  <SummaryDrawer
                    current={creationQuestion}
                    isWeb={isWeb}
                    locale={s.locale}
                    project={p}
                  />
                )}
              </GuidedCreation>
            )
          ) : tab === "orchestrationCenter" ? (
            <OrchestrationCenter
              locale={s.locale}
              toolkitPath={s.toolkitPath}
              projects={history}
              latestProjectPath={result?.projectPath}
            />
          ) : tab === "settings" ? (
            <SettingsPage
              s={s}
              setS={setS}
              choose={choose}
              gh={gh}
              refresh={refresh}
              saved={saved}
              save={async () => {
                const saved = await bridge
                  .saveSettings(s)
                  .then(() => true)
                  .catch((error) => {
                    reportHostError(error);
                    return false;
                  });
                if (!saved) return;
                setSaved(true);
                setTimeout(() => setSaved(false), 1200);
              }}
              t={t}
              reportHostError={reportHostError}
            />
          ) : tab === "history" ? (
            <HistoryPage
              entries={history}
              onStart={() => setTab("new")}
              t={t}
            />
          ) : extraDestination && tab === extraDestination.id ? (
            extraDestination.render({
              locale: s.locale,
              version: __APP_VERSION__,
              onStart: () => {
                setTab("new");
                setShowOnboarding(false);
                navigateView("project");
              },
            })
          ) : (
            <About
              t={t}
              isWeb={isWeb}
              locale={s.locale}
              enabledSignInProviders={enabledSignInProviders}
              onHome={openWelcome}
              onStart={() => {
                setTab("new");
                setAboutOpen(false);
                navigateView("project");
              }}
            />
          ))}
        {confirm && (
          <dialog
            ref={executionDialogRef}
            className="modal"
            aria-labelledby="execution-confirm-title"
            aria-busy={running}
          >
            <button
              type="button"
              className="close"
              aria-label={s.locale === "es" ? "Cerrar" : "Close"}
              disabled={running}
              onClick={closeConfirmation}
            >
              <X />
            </button>
            <span className="modal-icon">
              <img src={brandMark} alt="" />
            </span>
            <h2 id="execution-confirm-title">
              {isWeb
                ? s.locale === "es"
                  ? "Confirmar exportación"
                  : "Confirm export"
                : t.confirm}
            </h2>
            <p>
              <strong>{p.name}</strong> ·{" "}
              {p.dryRun
                ? s.locale === "es"
                  ? "Solo revisión"
                  : "Review only"
                : isWeb
                  ? s.locale === "es"
                    ? "Preparar un ZIP de repositorio"
                    : "Prepare a repository ZIP"
                  : p.action === "both"
                    ? s.locale === "es"
                      ? "Crear repositorio y tracking"
                      : "Create repository and tracking"
                    : s.locale === "es"
                      ? `Crear ${p.action === "tracking" ? "tracking" : "repositorio"}`
                      : `Create ${p.action}`}
            </p>
            <div className={`execution-mode ${p.dryRun ? "dry-run" : "live"}`}>
              <strong>
                {p.dryRun
                  ? "Dry run"
                  : s.locale === "es"
                    ? "Creación real"
                    : "Create now"}
              </strong>
              <span>
                {p.dryRun
                  ? s.locale === "es"
                    ? "No se creará nada."
                    : "Nothing will be created."
                  : s.locale === "es"
                    ? "Se producirán los elementos siguientes."
                    : "The following items will be produced."}
              </span>
            </div>
            {executionPreview && (
              <>
                <div className="target preview-destinations">
                  <small>
                    {isWeb
                      ? "ZIP"
                      : s.locale === "es"
                        ? "Destinos"
                        : "Destinations"}
                  </small>
                  {executionPreview.artifacts
                    .filter(({ kind }) =>
                      ["repository", "tracking", "zip"].includes(kind),
                    )
                    .map((artifact) => (
                      <code key={`${artifact.kind}-${artifact.destination}`}>
                        {artifact.displayName}: {artifact.destination}
                      </code>
                    ))}
                </div>
                <details className="preview-items">
                  <summary>
                    {executionPreview.artifacts.length}{" "}
                    {s.locale === "es"
                      ? "elementos previstos"
                      : "planned items"}
                  </summary>
                  <ul>
                    {executionPreview.artifacts.map((artifact, index) => (
                      <li
                        key={`${artifact.kind}-${artifact.destination}-${index}`}
                      >
                        <code>{artifact.destination}</code>
                      </li>
                    ))}
                  </ul>
                </details>
                <ul className="preview-limitations">
                  <li>
                    {p.dryRun
                      ? isWeb
                        ? s.locale === "es"
                          ? "No se construirá ningún ZIP ni se solicitará una descarga."
                          : "No ZIP will be built and no download will be requested."
                        : s.locale === "es"
                          ? "No se creará ningún archivo, directorio, remoto, inicio de IDE ni entrada de historial."
                          : "No file, directory, remote, IDE launch, or history entry will be created."
                      : isWeb
                        ? s.locale === "es"
                          ? "El navegador puede bloquear, renombrar, mover o cancelar la descarga."
                          : "The browser may block, rename, relocate, or cancel the download."
                        : s.locale === "es"
                          ? "Los nombres existentes usan la siguiente copia versionada disponible."
                          : "Existing filenames use the next available versioned copy."}
                  </li>
                  {isWeb && p.action === "both" && (
                    <li>
                      {s.locale === "es"
                        ? "Ambos crea el mismo ZIP de repositorio; el tracking del navegador no está disponible."
                        : "Both creates the same repository ZIP; browser tracking is not available."}
                    </li>
                  )}
                  {!isWeb && p.createRemote && p.action !== "tracking" && (
                    <li>
                      {s.locale === "es"
                        ? "GitHub crea un remoto; no se realiza push."
                        : "GitHub creates a remote; no push is performed."}
                    </li>
                  )}
                </ul>
              </>
            )}
            {isWeb && webAttachments.length > 0 && (
              <div className="attachment-confirmation">
                <p>
                  {p.dryRun
                    ? s.locale === "es"
                      ? "Solo revisión: no se creará ni descargará un ZIP; los archivos permanecerán en esta pestaña."
                      : "Review only: no ZIP will be built or downloaded; selected files remain in this tab."
                    : s.locale === "es"
                      ? `Crear el ZIP localmente con ${webAttachments.length} archivo(s).`
                      : `Build the ZIP locally with ${webAttachments.length} attachment(s).`}
                </p>
                <ul>
                  {resolveWebAttachments(
                    webAttachments,
                    slugify(p.name) || "new-project",
                  ).map((entry) => (
                    <li key={entry.source.id}>{entry.archiveName}</li>
                  ))}
                </ul>
                {rejectedAttachments.length > 0 && (
                  <p>
                    {s.locale === "es"
                      ? "Los archivos con error no se incluirán."
                      : "Files with errors will not be included."}
                  </p>
                )}
              </div>
            )}
            <div className="modal-actions">
              {running && (
                <span role="status">
                  {isWeb
                    ? s.locale === "es"
                      ? "Exportando…"
                      : "Exporting…"
                    : s.locale === "es"
                      ? "Ejecutando…"
                      : "Executing…"}
                </span>
              )}
              <button
                type="button"
                disabled={running}
                onClick={closeConfirmation}
              >
                {t.cancel}
              </button>
              <button
                type="button"
                className="confirm"
                disabled={running}
                onClick={execute}
              >
                <Play />
                {running
                  ? isWeb
                    ? s.locale === "es"
                      ? "Exportando…"
                      : "Exporting…"
                    : s.locale === "es"
                      ? "Ejecutando…"
                      : "Executing…"
                  : p.dryRun
                    ? s.locale === "es"
                      ? "Ejecutar revisión seca"
                      : "Run dry review"
                    : isWeb
                      ? s.locale === "es"
                        ? "Preparar ZIP"
                        : "Prepare ZIP"
                      : p.action === "tracking"
                        ? s.locale === "es"
                          ? "Crear tracking"
                          : "Create tracking"
                        : p.action === "repository"
                          ? s.locale === "es"
                            ? "Crear repositorio"
                            : "Create repository"
                          : s.locale === "es"
                            ? "Crear ambos"
                            : "Create both"}
              </button>
            </div>
          </dialog>
        )}
      </AppFrame>
      {isWeb && aboutOpen && (
        <AboutPopover
          locale={s.locale}
          authenticated={webAuthenticated}
          initialSection={aboutSection}
          enabledSignInProviders={enabledSignInProviders}
          onClose={closeAbout}
        />
      )}
      {isWeb && webAuthenticated && helpTopic && (
        <HelpDialog
          locale={s.locale}
          topic={helpTopic}
          onClose={() => setHelpTopic(null)}
        />
      )}
    </>
  );
}
function Field({
  icon,
  title,
  subtitle,
  error,
  children,
  tall,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle?: string;
  error?: string;
  children: React.ReactNode;
  // Every other field's content is one short row, so the icon/label
  // vertically centers against it by design. This one field's content is
  // a multi-part panel -- centering against its full height puts the
  // label in the middle of it, not at the top. Top-align just this field.
  tall?: boolean;
}) {
  return (
    <div
      className={`field ${error ? "invalid" : ""} ${tall ? "field-tall" : ""}`}
    >
      <span className="field-icon">{icon}</span>
      <div className="field-label">
        <strong>{title}</strong>
        {subtitle && <small>{subtitle}</small>}
      </div>
      <div className="control">
        {children}
        {error && <em>{error}</em>}
      </div>
    </div>
  );
}
function Seg({
  options,
  value,
  onChange,
}: {
  options: [string, string][];
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="segment">
      {options.map(([v, l]) => (
        <button
          type="button"
          key={v}
          className={v === value ? "selected" : ""}
          aria-pressed={v === value}
          onClick={() => onChange(v)}
        >
          {l}
        </button>
      ))}
    </div>
  );
}
function Toggle({
  active,
  disabled,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  disabled?: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      className={active ? "selected" : ""}
      aria-pressed={active}
      onClick={onClick}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}
function OrchestrationCenter({
  locale,
  toolkitPath,
  projects,
  latestProjectPath,
}: {
  locale: Locale;
  toolkitPath: string;
  projects: HistoryEntry[];
  latestProjectPath?: string;
}) {
  const es = locale === "es";
  const initialProject = latestProjectPath || projects[0]?.path || "";
  const [toolkitDir, setToolkitDir] = useState(toolkitPath);
  const [projectDir, setProjectDir] = useState(initialProject);
  const [configPath, setConfigPath] = useState(
    initialProject
      ? `${initialProject}/.ai-engineering/orchestration.yaml`
      : "",
  );
  const [preflight, setPreflight] =
    useState<OrchestrationPreflightResult | null>(null);
  const [snapshot, setSnapshot] = useState<OrchestrationRunSnapshot | null>(
    null,
  );
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const request = { toolkitDir, projectDir, configPath };
  const report = (error: unknown) =>
    setMessage(error instanceof Error ? error.message : String(error));
  const refreshSnapshot = () =>
    bridge.orchestrationSnapshot().then(setSnapshot).catch(report);

  useEffect(() => {
    const timer = window.setInterval(refreshSnapshot, 1500);
    refreshSnapshot();
    return () => window.clearInterval(timer);
  }, []);

  const selectProject = (value: string) => {
    setProjectDir(value);
    setConfigPath(value ? `${value}/.ai-engineering/orchestration.yaml` : "");
    setPreflight(null);
  };
  const run = async (action: "preflight" | "start" | "resume") => {
    setBusy(true);
    setMessage(null);
    try {
      const result =
        action === "preflight"
          ? await bridge.orchestrationPreflight(request)
          : await bridge.orchestrationStart({
              ...request,
              newWorkSession: action === "resume",
            });
      setPreflight(result);
      if (action !== "preflight") await refreshSnapshot();
    } catch (error) {
      report(error);
    } finally {
      setBusy(false);
    }
  };
  const decide = async (decision: OrchestrationDecision) => {
    const descriptions: Record<OrchestrationDecision, [string, string]> = {
      approve: ["Aprobar este paso", "Approve this step"],
      reject: ["Rechazar este paso", "Reject this step"],
      "changes-requested": ["Solicitar cambios", "Request changes"],
      pause: ["Pausar la sesión", "Pause the session"],
      escalate: ["Escalar la sesión", "Escalate the session"],
      terminate: ["Terminar la sesión", "Terminate the session"],
    };
    if (
      !window.confirm(
        `${descriptions[decision][es ? 0 : 1]}?\n\n${
          es
            ? "Esta decisión se enviará al gate humano actual y no puede retirarse."
            : "This decision will be sent to the current human gate and cannot be withdrawn."
        }`,
      )
    )
      return;
    setBusy(true);
    setMessage(null);
    try {
      await bridge.orchestrationDecide(decision);
      await refreshSnapshot();
    } catch (error) {
      report(error);
    } finally {
      setBusy(false);
    }
  };
  const cancel = async () => {
    if (
      !window.confirm(
        es
          ? "¿Solicitar cancelación? El estado y el journal de AEKR se conservarán."
          : "Request cancellation? AEKR state and journal will be preserved.",
      )
    )
      return;
    setBusy(true);
    try {
      await bridge.orchestrationCancel();
      await refreshSnapshot();
    } catch (error) {
      report(error);
    } finally {
      setBusy(false);
    }
  };
  const waiting = snapshot?.lifecycle === "WAITING_HUMAN_APPROVAL";

  return (
    <div className="orchestration-center-page">
      <div className="settings-title">
        <div>
          <h1>{es ? "Centro de Orquestación" : "Orchestration Center"}</h1>
          <p>
            {es
              ? "Control local y human-gated del runtime Mode 1 de AEKR."
              : "Local, human-gated control of the AEKR Mode 1 runtime."}
          </p>
        </div>
        {snapshot && (
          <span
            className={`orchestration-state ${snapshot.lifecycle.toLowerCase()}`}
          >
            {snapshot.lifecycle.replaceAll("_", " ")}
          </span>
        )}
      </div>
      <div className="orchestration-center-grid">
        <section className="panel orchestration-launch-card">
          <h2>{es ? "Preparar sesión" : "Prepare session"}</h2>
          <label>
            <span>{es ? "Proyecto creado" : "Created project"}</span>
            <select
              value={projectDir}
              onChange={(event) => selectProject(event.target.value)}
            >
              <option value="">
                {es ? "Selecciona un proyecto" : "Select a project"}
              </option>
              {projects.map((entry) => (
                <option key={entry.id} value={entry.path}>
                  {entry.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>
              {es
                ? "Directorio del orchestrator AEKR"
                : "AEKR orchestrator directory"}
            </span>
            <input
              value={toolkitDir}
              onChange={(event) => {
                setToolkitDir(event.target.value);
                setPreflight(null);
              }}
            />
          </label>
          <label>
            <span>
              {es ? "Configuración revisada" : "Reviewed configuration"}
            </span>
            <input
              value={configPath}
              onChange={(event) => {
                setConfigPath(event.target.value);
                setPreflight(null);
              }}
            />
          </label>
          <div className="orchestration-center-actions">
            <button
              type="button"
              disabled={busy || !toolkitDir || !projectDir || !configPath}
              onClick={() => run("preflight")}
            >
              <ShieldCheck /> {es ? "Verificar" : "Preflight"}
            </button>
            <button
              type="button"
              className="confirm"
              disabled={busy || !preflight}
              onClick={() => run("start")}
            >
              <Play /> {es ? "Iniciar Mode 1" : "Start Mode 1"}
            </button>
            {snapshot &&
              ["PAUSED", "BLOCKED", "TIMED_OUT", "FAILED"].includes(
                snapshot.lifecycle,
              ) && (
                <button
                  type="button"
                  disabled={busy || !preflight}
                  onClick={() => run("resume")}
                >
                  <Play />
                  {es ? "Reanudar en nueva sesión" : "Resume in new session"}
                </button>
              )}
          </div>
          <p className="capability-note">
            {es
              ? "accreatio inicia únicamente el CLI conocido con argumentos validados. No hay terminal genérico, auto-commit, auto-push ni aprobación masiva."
              : "accreatio starts only the known CLI with validated arguments. There is no generic terminal, auto-commit, auto-push, or batch approval."}
          </p>
          {message && (
            <p className="inline-error" role="alert">
              {message}
            </p>
          )}
        </section>
        <section className="panel orchestration-session-card">
          <h2>{es ? "Sesión actual" : "Current session"}</h2>
          {!snapshot ? (
            <p className="empty-state">
              {es ? "No hay estado AEKR cargado." : "No AEKR state is loaded."}
            </p>
          ) : (
            <>
              <dl className="orchestration-facts">
                <div>
                  <dt>Run</dt>
                  <dd>
                    <code>{snapshot.run_id}</code>
                  </dd>
                </div>
                <div>
                  <dt>{es ? "Sesión de trabajo" : "Work session"}</dt>
                  <dd>
                    <code>{snapshot.work_session_id}</code>
                  </dd>
                </div>
                <div>
                  <dt>{es ? "Paso" : "Step"}</dt>
                  <dd>{snapshot.current_step_index + 1}</dd>
                </div>
                <div>
                  <dt>{es ? "Revisión" : "Revision"}</dt>
                  <dd>{snapshot.revision}</dd>
                </div>
              </dl>
              {snapshot.active_attempt && (
                <div className="orchestration-evidence">
                  <strong>
                    {snapshot.active_attempt.phase.replaceAll("_", " ")}
                  </strong>
                  {snapshot.active_attempt.result_status && (
                    <span>{snapshot.active_attempt.result_status}</span>
                  )}
                  {snapshot.active_attempt.result_summary && (
                    <pre>{snapshot.active_attempt.result_summary}</pre>
                  )}
                  <small>Attempt: {snapshot.active_attempt.attempt_id}</small>
                  {snapshot.active_attempt.action_digest && (
                    <small>
                      Digest: {snapshot.active_attempt.action_digest}
                    </small>
                  )}
                </div>
              )}
              {waiting && (
                <div className="orchestration-gate">
                  <strong>
                    {es
                      ? "Decisión humana requerida"
                      : "Human decision required"}
                  </strong>
                  <p>
                    {es
                      ? "Revisa la evidencia anterior antes de responder. Cada decisión requiere confirmación individual."
                      : "Review the evidence above before responding. Every decision requires individual confirmation."}
                  </p>
                  <div>
                    {(
                      [
                        "approve",
                        "changes-requested",
                        "reject",
                        "pause",
                        "escalate",
                        "terminate",
                      ] as OrchestrationDecision[]
                    ).map((decision) => (
                      <button
                        type="button"
                        key={decision}
                        disabled={busy}
                        onClick={() => decide(decision)}
                      >
                        {decision.replaceAll("-", " ")}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {["RUNNING", "WAITING_HUMAN_APPROVAL"].includes(
                snapshot.lifecycle,
              ) && (
                <button
                  type="button"
                  className="orchestration-cancel"
                  disabled={busy}
                  onClick={cancel}
                >
                  <X /> {es ? "Solicitar cancelación" : "Request cancellation"}
                </button>
              )}
            </>
          )}
          {preflight && (
            <details className="orchestration-durable">
              <summary>{es ? "Evidencia durable" : "Durable evidence"}</summary>
              <p>
                <strong>State</strong>
                <code>{preflight.statePath}</code>
              </p>
              <p>
                <strong>Journal</strong>
                <code>{preflight.logPath}</code>
              </p>
            </details>
          )}
        </section>
      </div>
    </div>
  );
}
function SettingsPage({
  s,
  setS,
  choose,
  gh,
  refresh,
  saved,
  save,
  t,
  reportHostError,
}: {
  s: Settings;
  setS: (x: Settings) => void;
  choose: (x: "baseFolder" | "toolkitPath" | "futureProjectsPath") => void;
  gh: GithubStatus;
  refresh: () => void;
  saved: boolean;
  save: () => void;
  t: typeof tr.es;
  reportHostError: (error: unknown) => void;
}) {
  const es = s.locale === "es";
  return (
    <div className="settings-page">
      <div className="settings-title">
        <div>
          <h1>{t.settings}</h1>
          <p>{t.privacy}</p>
        </div>
        <button type="button" className="save" onClick={save}>
          {saved ? <Check /> : <Save />}
          {saved ? t.saved : t.save}
        </button>
      </div>
      <section className="panel settings-card">
        <h2>{t.locations}</h2>
        {(
          [
            ["baseFolder", es ? "Carpeta de proyectos" : "Projects folder"],
            ["toolkitPath", "Toolkit"],
            ["futureProjectsPath", "future_projects"],
          ] as const
        ).map(([k, l]) => (
          <label className="setting" key={k}>
            <span>
              <strong>{l}</strong>
              <small>{s[k] || "—"}</small>
            </span>
            <button type="button" onClick={() => choose(k)}>
              {es ? "Elegir" : "Browse"}
            </button>
          </label>
        ))}
      </section>
      <section className="panel settings-card">
        <h2>{t.tools}</h2>
        <div className="settings-grid">
          <label>
            <span>{es ? "Rama inicial" : "Initial branch"}</span>
            <input
              value={s.defaultBranch}
              onChange={(e) => setS({ ...s, defaultBranch: e.target.value })}
            />
          </label>
          <label>
            <span>IDE</span>
            <select
              value={s.preferredIde}
              onChange={(e) =>
                setS({ ...s, preferredIde: e.target.value as PreferredIde })
              }
            >
              <option>VS Code</option>
              <option value="File Explorer">
                {es ? "Explorador de archivos" : "File Explorer"}
              </option>
            </select>
          </label>
          <label>
            <span>{t.language}</span>
            <select
              value={s.locale}
              onChange={(e) => setS({ ...s, locale: e.target.value as Locale })}
            >
              <option value="es">Español</option>
              <option value="en">English (US)</option>
            </select>
          </label>
          <label>
            <span>{t.theme}</span>
            <select
              value={s.theme}
              onChange={(e) =>
                setS({ ...s, theme: e.target.value as "dark" | "light" })
              }
            >
              <option value="dark">{es ? "Oscuro" : "Dark"}</option>
              <option value="light">{es ? "Claro" : "Light"}</option>
            </select>
          </label>
        </div>
      </section>
      <section className="panel settings-card">
        <h2>GitHub</h2>
        <p>
          {gh.installed
            ? gh.authenticated
              ? `${t.connected}: ${gh.login}`
              : t.notConnected
            : es
              ? "GitHub CLI no está instalado"
              : "GitHub CLI not installed"}
        </p>
        {gh.installed && !gh.authenticated && (
          <button
            type="button"
            className="save"
            onClick={async () => {
              const connected = await bridge
                .connectGithub()
                .then(() => true)
                .catch((error) => {
                  reportHostError(error);
                  return false;
                });
              if (!connected) return;
              setTimeout(refresh, 4000);
            }}
          >
            {t.connect}
          </button>
        )}
      </section>
    </div>
  );
}
function HistoryPage({
  entries,
  onStart,
  t,
}: {
  entries: HistoryEntry[];
  onStart: () => void;
  t: typeof tr.es;
}) {
  return (
    <div className="settings-page">
      <div className="settings-title">
        <div>
          <h1>{t.history}</h1>
          <p>
            {t === tr.es
              ? "Registro local de ejecuciones · sin sincronización cloud"
              : "Local execution ledger · no cloud sync"}
          </p>
        </div>
      </div>
      <section className="panel settings-card history-list">
        {!entries.length ? (
          <div className="empty-state">
            <History aria-hidden="true" />
            <h2>{t.emptyHistory}</h2>
            <p>
              {t === tr.es
                ? "El historial se completa después de ejecutar un proyecto en esta aplicación de escritorio; no se sincroniza desde la nube."
                : "History fills after you run a project in this desktop app; it is not restored from cloud sync."}
            </p>
            <button type="button" className="secondary" onClick={onStart}>
              {t === tr.es
                ? "Crear tu primer proyecto"
                : "Create your first project"}
            </button>
          </div>
        ) : (
          entries.map((e) => (
            <article key={e.id}>
              <History />
              <div>
                <strong>{e.name}</strong>
                <small>{e.path}</small>
              </div>
              <time>{new Date(e.createdAt).toLocaleString()}</time>
            </article>
          ))
        )}
      </section>
    </div>
  );
}
function About({
  t,
  isWeb,
  locale,
  onHome,
  onStart,
  enabledSignInProviders,
}: {
  t: typeof tr.es;
  isWeb: boolean;
  locale: Locale;
  onHome(): void;
  onStart(): void;
  enabledSignInProviders?: readonly ("google" | "github" | "email-code")[];
}) {
  return (
    <div className="about-page">
      <AboutExperience
        enabledSignInProviders={enabledSignInProviders}
        facts={{
          versionLabel: t.aboutVersion,
          version: __APP_VERSION__,
          license: t.license,
          privacy: t.privacy,
          securityTitle: t.aboutSecurity,
          security: t.aboutSecurityCopy,
          documentsTitle: t.aboutDocuments,
          documents: isWeb
            ? t.aboutWebDocumentsCopy
            : t.aboutDesktopDocumentsCopy,
          legalDocumentsLabel: t.aboutLegalDocuments,
          copyrightRole: t.aboutCopyrightRole,
          copyright: t.aboutCopyright,
          closingLabel: t.aboutClosingLabel,
          closingPrinciples: t.aboutClosingPrinciples,
        }}
        isWeb={isWeb}
        locale={locale}
        onHome={onHome}
        onStart={onStart}
      />
    </div>
  );
}
