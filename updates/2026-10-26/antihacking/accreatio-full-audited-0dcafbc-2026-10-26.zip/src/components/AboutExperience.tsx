import { legalHref, termsHref } from "../legal";
import brandMark from "../assets/accreatio-mark.svg";
import { PublicContent, type PublicContentSection } from "./PublicContent";
import {
  WebProjectInformation,
  type PublicSignInProvider,
} from "./WebProjectInformation";

export interface AboutAdministrativeFacts {
  readonly versionLabel: string;
  readonly version: string;
  readonly license: string;
  readonly privacy: string;
  readonly securityTitle: string;
  readonly security: string;
  readonly documentsTitle: string;
  readonly documents: string;
  readonly legalDocumentsLabel: string;
  readonly copyrightRole: string;
  readonly copyright: string;
  readonly closingLabel: string;
  readonly closingPrinciples: string;
}

export function AboutExperience({
  facts,
  isWeb,
  locale,
  onHome,
  onStart,
  enabledSignInProviders,
}: {
  facts: AboutAdministrativeFacts;
  isWeb: boolean;
  locale: "es" | "en";
  onHome(): void;
  onStart(): void;
  enabledSignInProviders?: readonly PublicSignInProvider[];
}) {
  const es = locale === "es";
  const sections: PublicContentSection[] = [
    {
      id: "about-operation",
      title: es ? "Cómo funciona" : "How it works",
      content: (
        <>
          <ol className="about-steps">
            <li>
              <strong>{es ? "Describe" : "Describe"}</strong>
              <span>
                {es
                  ? "Comparte el propósito y el contexto que ya conoces."
                  : "Share the purpose and context you already know."}
              </span>
            </li>
            <li>
              <strong>{es ? "Organiza" : "Organize"}</strong>
              <span>
                {es
                  ? "accreatio convierte tus decisiones en un prompt y un plan deterministas."
                  : "accreatio turns your decisions into a deterministic prompt and plan."}
              </span>
            </li>
            <li>
              <strong>{es ? "Lleva tu proyecto" : "Take your project"}</strong>
              <span>
                {isWeb
                  ? es
                    ? "Descarga el ZIP, extráelo, abre la carpeta en tu editor y sigue START.md."
                    : "Download the ZIP, extract it, open the folder in your editor, and follow START.md."
                  : es
                    ? "accreatio es solo web. Descarga el ZIP desde la beta web."
                    : "accreatio is web-only. Download the ZIP from the web beta."}
              </span>
            </li>
          </ol>
          <p>
            {isWeb
              ? es
                ? "El contenido de tu proyecto se procesa en este navegador. El acceso y la cuota utilizan un servicio de cuenta separado. Si compartes después el ZIP con otro servicio, se aplican sus condiciones y controles."
                : "Your project content is processed in this browser. Sign-in and allowance use a separate account service. If you later share the ZIP with another service, its terms and controls apply."
              : facts.privacy}
          </p>
        </>
      ),
    },
    {
      id: "about-security",
      title: facts.securityTitle,
      content: (
        <>
          <p>
            {isWeb
              ? es
                ? "El navegador prepara el ZIP sin enviar el contenido del proyecto a los servidores de accreatio. Solo admite DOCX, PDF, PNG y JPEG tras comprobar localmente su estructura y funciones activas; las imágenes se decodifican y se vuelven a codificar. Hay límites de tamaño y complejidad. Esta comprobación no certifica la ausencia de malware. El servicio de cuenta verifica las sesiones y autoriza la cuota de exportación por separado."
                : "The browser prepares the ZIP without sending project content to accreatio servers. Only DOCX, PDF, PNG and JPEG are admitted after local structure and active-feature checks; images are decoded and re-encoded. Size and complexity limits apply. Inspection does not certify the absence of malware. The separate account service verifies sessions and authorizes export allowance."
              : facts.security}
          </p>
          <p className="about-limit">
            {es
              ? "Estos son límites operativos del producto, no una certificación de seguridad o cumplimiento. Revisa los archivos antes de compartirlos."
              : "These are product operating limits, not a security or compliance certification. Review files before sharing them."}
          </p>
        </>
      ),
    },
    {
      id: "about-orchestration",
      title: es
        ? "Orquestación con control humano"
        : "Human-controlled orchestration",
      content: (
        <p>
          {isWeb
            ? es
              ? "La preparación básica no exige orquestación. Puedes incluir instrucciones opcionales para coordinar herramientas después, con configuración en tu equipo. Inspecciona esas instrucciones antes de ejecutarlas. Los roles describen el reparto futuro; no contratan ni ejecutan agentes desde la web."
              : "Basic preparation does not require orchestration. You can include optional instructions to coordinate tools later, with configuration on your machine. Inspect those instructions before running them. Roles describe future work; they do not hire or run agents from the web."
            : es
              ? "El prototipo de escritorio es obsoleto y nunca se publicó. La web prepara instrucciones opcionales para herramientas que configures después en tu equipo."
              : "The desktop prototype is obsolete and was never released. The web prepares optional instructions for tools you configure later on your machine."}
        </p>
      ),
    },
  ];

  return (
    <article className="about-experience" aria-labelledby="about-product-title">
      <header className="about-hero">
        <button
          type="button"
          className="about-brand-link"
          onClick={onHome}
          aria-label={es ? "Ir al inicio de accreatio" : "Go to accreatio home"}
        >
          <img src={brandMark} alt="" />
          <span className="visually-hidden">accreatio</span>
        </button>
        <p className="about-eyebrow">
          {es
            ? "De una idea a un inicio claro"
            : "From an idea to a clear beginning"}
        </p>
        <h1 id="about-product-title">accreatio</h1>
        <p className="about-lede">
          {es
            ? "Un punto de partida local-first que ayuda a describir, organizar y llevarte un proyecto preparado para continuar."
            : "A local-first launch point that helps you describe, organize, and take a project that is ready to continue."}
        </p>
        <p className="about-release">
          {facts.versionLabel} {facts.version} · {facts.license}
        </p>
        {
          <p>
            {es
              ? "accreatio es solo web. El prototipo de escritorio es obsoleto, nunca se publicó y nunca se publicará."
              : "accreatio is web-only. The desktop prototype is obsolete, was never released, and will never be released."}
          </p>
        }
      </header>

      <PublicContent sections={sections} />

      {isWeb ? (
        <WebProjectInformation
          locale={locale}
          enabledSignInProviders={enabledSignInProviders}
        />
      ) : (
        <section className="about-faq" aria-labelledby="about-faq-title">
          <h2 id="about-faq-title">FAQ</h2>
          <details>
            <summary>
              {es ? "¿Necesito una cuenta?" : "Do I need an account?"}
            </summary>
            <p>
              {es
                ? "Puedes leer About y el Blog de la web sin iniciar sesión; para preparar proyectos en la beta web, elige un método de acceso habilitado. El prototipo de escritorio está retirado."
                : "You can read About and the Blog on the web without signing in; to prepare projects in the web beta, choose an enabled sign-in method. The desktop prototype is retired."}
            </p>
          </details>
          <details>
            <summary>
              {es
                ? "¿accreatio ejecuta AI en la nube?"
                : "Does accreatio run cloud AI?"}
            </summary>
            <p>
              {es
                ? "No. La web prepara instrucciones opcionales; tú configuras y controlas después las herramientas locales."
                : "No. The web prepares optional instructions; you configure and control local tools later."}
            </p>
          </details>
          <details>
            <summary>
              {es
                ? "¿Qué ocurre si ya existe un archivo?"
                : "What happens when a file exists?"}
            </summary>
            <p>
              {es
                ? "Las escrituras producen copias versionadas; no reemplazan el archivo existente."
                : "Writes produce versioned copies; they do not replace the existing file."}
            </p>
          </details>
        </section>
      )}

      <section
        className="about-administration"
        aria-labelledby="about-administration-title"
      >
        <h2 id="about-administration-title">
          {es ? "Información y documentos" : "Information and documents"}
        </h2>
        <h3>{facts.documentsTitle}</h3>
        <p>
          {isWeb
            ? es
              ? "Los Términos y la Política de privacidad enlazados son los documentos aplicables de la beta web. Cada documento indica su versión. La revisión legal formal sigue pendiente."
              : "The linked Terms and Privacy Policy are the applicable web beta documents. Each document records its version. Formal legal review remains pending."
            : facts.documents}
        </p>
        {isWeb && (
          <>
            <p>
              {es
                ? "Privacidad, soporte y seguridad: "
                : "Privacy, support and security: "}
              <a href="mailto:aekr@aekr.io">aekr@aekr.io</a>.
            </p>
            <nav className="legal-links" aria-label={facts.legalDocumentsLabel}>
              <a
                href={legalHref("privacy", locale)}
                target="_blank"
                rel="noopener noreferrer"
              >
                {es ? "Política de privacidad" : "Privacy Policy"}
              </a>
              <a
                href={termsHref(locale)}
                target="_blank"
                rel="noopener noreferrer"
              >
                {es ? "Términos" : "Terms"}
              </a>
              <a
                href={legalHref("faq", locale)}
                target="_blank"
                rel="noopener noreferrer"
              >
                FAQ
              </a>
              <a
                href={legalHref("cookies", locale)}
                target="_blank"
                rel="noopener noreferrer"
              >
                {es ? "Cookies y almacenamiento" : "Cookies and storage"}
              </a>
            </nav>
          </>
        )}
        <h3>Copyright</h3>
        <p>
          © 2026 Ed Lopez, {facts.copyrightRole}. {facts.copyright}
        </p>
      </section>

      <footer className="about-product-close" aria-label={facts.closingLabel}>
        <div>
          <strong>accreatio</strong>
          <p>{facts.closingPrinciples}</p>
        </div>
        <button type="button" onClick={onStart}>
          {es ? "Crear un proyecto" : "Create a project"}
        </button>
      </footer>
    </article>
  );
}
