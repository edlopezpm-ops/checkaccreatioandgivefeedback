import { ShieldCheck } from "lucide-react";
import type { Locale } from "../../types";
import type { HelpTopic } from "../help/HelpTips";

export type ProjectHelpSection = HelpTopic;

export function ProjectHelp({
  locale,
  onOpen,
  topic,
  reassure = false,
}: {
  locale: Locale;
  onOpen: (section: ProjectHelpSection) => void;
  topic: ProjectHelpSection;
  reassure?: boolean;
}) {
  const es = locale === "es";
  return (
    <div className="project-help">
      <a
        className="project-help__link"
        href="#project-help"
        aria-haspopup="dialog"
        onClick={(event) => {
          event.preventDefault();
          onOpen(topic);
        }}
      >
        {es ? "ayuda" : "help"}
      </a>
      {reassure && (
        <p className="guided-creation__reassurance">
          <ShieldCheck aria-hidden="true" />
          {es
            ? "Puedes volver y cambiar tus respuestas. Tú confirmas al final."
            : "You can go back and change your answers. You confirm at the end."}
        </p>
      )}
    </div>
  );
}
