import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { ArrowLeft, ArrowRight, Mail } from "lucide-react";
import type { Locale } from "../../types";
import { FormationMark } from "../FormationMark";
import { WebAccountMenu } from "./WebAccountMenu";
import { AccountPolicyFields } from "./AccountPolicyFields";
import { SharedCaptcha } from "./SharedCaptcha";
import { ACCOUNT_COOKIES_NOTICE_VERSION } from "../../../shared/accountPolicy";
import {
  AccountError,
  accountPolicyAuthorization,
  authorizeWebExport,
  canUseWebBlog,
  cancelGoogleSignIn,
  closeWebAccount,
  loadWebAccount,
  loadWebAccountData,
  loadWebAuthMethods,
  loadGoogleSignInStatus,
  requestEmailCode,
  saveWebAccountPolicy,
  startProviderSignIn,
  verifyEmailCode,
  type AccountAvailability,
  type EmailChallenge,
  type WebAccount,
} from "../../account/webClient";
import type {
  GoogleAuthTransaction,
  WebAuthMethods,
  WebIdentityProvider,
  WebVerificationAction,
} from "../../account/contracts";
import {
  clearWebExportRecovery,
  hasWebExportRecovery,
  retryWebExport,
  setWebAuthorizer,
} from "../../bridge/web";

function accountMessage(failure: unknown, es: boolean): string {
  const code = failure instanceof AccountError ? failure.code : "";
  if (code === "captcha_required" || code === "captcha_invalid")
    return es
      ? "Completa de nuevo la verificación compartida y elige Google o GitHub."
      : "Complete the shared verification again, then choose Google or GitHub.";
  if (code === "captcha_unavailable")
    return es
      ? "La verificación no está disponible ahora. Vuelve a intentarlo; tu borrador se conserva."
      : "Verification is unavailable right now. Try again; your draft is preserved.";
  if (code === "account_suspended")
    return es
      ? "El acceso al servicio está suspendido temporalmente. Puedes usar «Mis datos y eliminación de cuenta» para gestionar tu cuenta existente."
      : "Service access is temporarily suspended. Use Account data and deletion to manage your existing account.";
  if (
    [
      "request_rate_limited",
      "sign_in_rate_limited",
      "rights_rate_limited",
    ].includes(code)
  )
    return es
      ? "Hay demasiadas solicitudes. Espera antes de volver a intentarlo; tu borrador se conserva."
      : "Too many requests. Wait before trying again; your draft is preserved.";
  if (code === "abuse_guard_unavailable")
    return es
      ? "No se pudo comprobar la disponibilidad del servicio. Vuelve a intentarlo; tus datos locales se conservan."
      : "Service availability could not be checked. Try again; your local work is preserved.";
  if (code === "policy_authorization_outdated")
    return es
      ? "Hay una versión nueva de los avisos. Guarda tu borrador y recarga accreatio para revisarla."
      : "The notices have a newer version. Save your draft and reload accreatio to review it.";
  if (
    code === "policy_authorization_required" ||
    code === "invalid_policy_authorization"
  )
    return es
      ? "Revisa los avisos de privacidad y los términos antes de continuar con tu cuenta."
      : "Review the privacy notice and terms before continuing with your account.";
  if (code === "reauthentication_required")
    return es
      ? "Vuelve a iniciar sesión para descargar tus datos o eliminar tu cuenta. Tu borrador y archivos siguen en esta pestaña."
      : "Sign in again to download your account data or delete your account. Your draft and files are still in this tab.";
  if (code === "identity_conflict")
    return es
      ? "No se pueden fusionar cuentas. Entra con tu método habitual y conecta el otro proveedor desde tu cuenta. Si ya pertenece a otra cuenta, no se puede transferir."
      : "Accounts cannot be merged. Sign in with your usual method and connect the other provider from your account. A method belonging to another account cannot be transferred.";
  if (code === "verified_email_required")
    return es
      ? "Verifica tu correo principal en el proveedor y vuelve a intentarlo. Para una cuenta nueva con Google, usa Gmail o Google Workspace. No se ha creado una cuenta parcial."
      : "Verify your primary email at the provider, then try again. For a new Google account, use Gmail or Google Workspace. No partial account was created.";
  if (code === "provider_cancelled")
    return es
      ? "Cancelaste la autorización. Puedes volver a intentarlo; tu borrador se conserva."
      : "Authorization was cancelled. You can try again; your draft is preserved.";
  if (code === "provider_permission_required")
    return es
      ? "GitHub no pudo compartir el correo verificado. Revisa el permiso de correo de la aplicación o usa tu otro método de acceso."
      : "GitHub could not share your verified email. Check the app's email permission or use your other sign-in method.";
  if (code === "provider_authorization_invalid")
    return es
      ? "La autorización venció o ya no es válida. Inicia el acceso de nuevo; tu borrador se conserva."
      : "Authorization expired or is no longer valid. Start sign-in again; your draft is preserved.";
  if (
    [
      "github_unavailable",
      "google_unavailable",
      "provider_unavailable",
    ].includes(code)
  )
    return es
      ? "Este método no está disponible ahora. Usa otro método conectado a tu cuenta o vuelve a intentarlo; tu borrador se conserva."
      : "This method is unavailable right now. Use another method connected to your account or try again; your draft is preserved.";
  if (code === "popup_blocked")
    return es
      ? "Permite una ventana para acceder y vuelve a intentarlo. Tus archivos siguen en esta pestaña; no la cierres."
      : "Allow a window for sign-in, then try again. Your files are still in this tab; keep it open.";
  if (code === "draft_not_saved")
    return es
      ? "No pudimos guardar los últimos cambios. No hemos abierto el proveedor. Tu borrador sigue en esta pestaña; libera espacio o vuelve a intentarlo."
      : "We could not save your latest changes. The provider was not opened. Your draft is still in this tab; free some space or try again.";
  if (code === "oidc_expired")
    return es
      ? "El acceso ha vencido. Vuelve a intentarlo; tu borrador y archivos siguen en esta pestaña."
      : "Sign-in expired. Try again; your draft and files are still in this tab.";
  if (code === "oidc_failed")
    return es
      ? "No se completó el acceso. Puedes volver a intentarlo o usar tu método habitual y conectar el otro proveedor desde tu cuenta; tu borrador se conserva."
      : "Sign-in did not complete. Try again or use your usual method and connect the other provider from your account; your draft is preserved.";
  if (code === "invalid_email")
    return es
      ? "Escribe un correo válido para recibir tu código."
      : "Enter a valid email address to receive your code.";
  if (code === "otp_invalid" || code === "invalid_otp_request")
    return es
      ? "El código no es válido o ha vencido. Revisa el último correo o solicita otro código."
      : "This code is invalid or expired. Check your latest email or request another code.";
  if (code === "otp_rate_limited")
    return es
      ? "Espera antes de volver a intentarlo. Tu borrador se conserva."
      : "Please wait before trying again. Your draft is preserved.";
  if (code === "otp_delivery_unavailable")
    return es
      ? "No pudimos enviar el correo. Vuelve a intentarlo en unos minutos."
      : "We could not send the email. Please try again in a few minutes.";
  if (code === "beta_capacity")
    return es
      ? "La beta ha alcanzado su capacidad. Vuelve más tarde."
      : "The beta has reached its capacity. Please come back later.";
  if (code === "sign_in_required")
    return es
      ? "Inicia sesión para continuar. Tu borrador sigue en este dispositivo."
      : "Sign in to continue. Your draft stays on this device.";
  if (code === "account_context_changed")
    return es
      ? "La cuenta cambió en este navegador. Comprueba la sesión antes de continuar."
      : "The account changed in this browser. Check your session before continuing.";
  return es
    ? "No pudimos verificar tu sesión. Comprueba tu conexión y vuelve a intentarlo; tu borrador se conserva."
    : "We could not verify your session. Check your connection and try again; your draft is preserved.";
}

// Imported only by main.web.tsx. Never mount the creator without a verified session.
export function WebAccountBoundary({
  children,
  locale,
  active,
  onBack,
  onBeforeSignIn,
  onAccountReady,
  onSuspendAccount,
  onClearAccount,
  transientAttachmentCount,
  accountMenuTarget,
  onRequireSignIn,
  onSessionChange,
}: {
  children: ReactNode;
  locale: Locale;
  active: boolean;
  onBack: () => void;
  onBeforeSignIn: (redirect?: boolean) => Promise<void>;
  onAccountReady: (identity: {
    ownerKey: string;
    sessionKey: string;
  }) => Promise<void>;
  onSuspendAccount: () => void;
  onClearAccount: (identity: {
    ownerKey: string;
    sessionKey: string;
  }) => Promise<void>;
  transientAttachmentCount: number;
  accountMenuTarget: HTMLElement | null;
  onRequireSignIn: () => void;
  onSessionChange: (
    authenticated: boolean,
    canUseBlog: boolean,
    enabledProviders?: readonly (WebIdentityProvider | "email-code")[],
  ) => void;
}) {
  const es = locale === "es";
  const [account, setAccount] = useState<WebAccount | null>(null);
  const [busy, setBusy] = useState(false);
  const [checking, setChecking] = useState(true);
  const [methods, setMethods] = useState<WebAuthMethods | null>(null);
  const [captchaToken, setCaptchaToken] = useState("");
  const [captchaGeneration, setCaptchaGeneration] = useState(0);
  const [methodsLoading, setMethodsLoading] = useState(true);
  const [googlePending, setGooglePending] =
    useState<GoogleAuthTransaction | null>(null);
  const [googleReconnecting, setGoogleReconnecting] = useState(false);
  const [googleCancelling, setGoogleCancelling] = useState(false);
  const [error, setError] = useState("");
  const [email, setEmail] = useState("");
  const [challenge, setChallenge] = useState<EmailChallenge | null>(null);
  const [code, setCode] = useState("");
  const [retryAt, setRetryAt] = useState(0);
  const [now, setNow] = useState(Date.now);
  const [admin, setAdmin] = useState(false);
  const [recovery, setRecovery] = useState(false);
  const [editing, setEditing] = useState(false);
  const [rightsSignInAvailable, setRightsSignInAvailable] = useState(false);
  const [rightsProviders, setRightsProviders] = useState<
    readonly WebIdentityProvider[]
  >([]);
  const [rightsAction, setRightsAction] =
    useState<WebVerificationAction>("data");
  const [linkVerificationTarget, setLinkVerificationTarget] =
    useState<WebIdentityProvider | null>(null);
  const [authProvider, setAuthProvider] =
    useState<WebIdentityProvider>("google");
  const [authPurpose, setAuthPurpose] = useState<
    "sign_in" | "account_access" | "link_provider"
  >("sign_in");
  const [accountStatus, setAccountStatus] = useState("");
  const [deleting, setDeleting] = useState(false);
  const sequence = useRef(0);
  const busyRef = useRef(false);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const codeRef = useRef<HTMLInputElement>(null);
  const googleWindow = useRef<Window | null>(null);
  const freshSignInRequired = useRef(false);
  const accountRef = useRef(account);
  accountRef.current = account;

  const adoptAccount = useCallback(
    async (value: WebAccount, ticket: number) => {
      if (ticket !== sequence.current) return false;
      await onAccountReady({
        ownerKey: value.ownerKey,
        sessionKey: value.sessionKey,
      });
      if (ticket !== sequence.current) return false;
      setAccount(value);
      return true;
    },
    [onAccountReady],
  );

  const refreshMethods = useCallback(async () => {
    setMethodsLoading(true);
    try {
      setMethods(await loadWebAuthMethods());
    } catch {
      // Unavailable discovery never enables a sign-in method by assumption.
      setMethods(null);
    } finally {
      setMethodsLoading(false);
    }
  }, []);

  const refresh = useCallback(async () => {
    if (busyRef.current || freshSignInRequired.current) return;
    const ticket = ++sequence.current;
    try {
      const value = await loadWebAccount();
      if (ticket !== sequence.current) return;
      if (!(await adoptAccount(value, ticket))) return;
      setChecking(false);
      setError("");
      setChallenge(null);
      setCode("");
      setEmail("");
      const allowed = await canUseWebBlog();
      if (ticket === sequence.current) setAdmin(allowed);
    } catch (failure) {
      if (ticket !== sequence.current) return;
      setAccount(null);
      onSuspendAccount();
      setAdmin(false);
      // Background session checks must preserve an in-progress email challenge.
      if (!(
        failure instanceof AccountError && failure.code === "sign_in_required"
      ))
        setError(accountMessage(failure, es));
    } finally {
      if (ticket === sequence.current) setChecking(false);
    }
  }, [es, adoptAccount, onSuspendAccount]);

  useEffect(() => {
    void refreshMethods();
    const url = new URL(window.location.href);
    const result = url.searchParams.get("auth");
    const reason = url.searchParams.get("auth_error");
    if (result === "success" || result === "failure") {
      url.searchParams.delete("auth");
      url.searchParams.delete("auth_error");
      window.history.replaceState(
        null,
        "",
        url.pathname + url.search + url.hash,
      );
      if (result === "failure")
        setError(
          accountMessage(new AccountError(reason ?? "oidc_failed", ""), es),
        );
    }
  }, [refreshMethods, es]);

  useEffect(() => {
    if (!googlePending) return;
    let stopped = false;
    let timer: ReturnType<typeof setTimeout>;
    let delay = 2000;
    const deadline = Math.min(
      Date.parse(googlePending.expiresAt),
      Date.now() + 600_000,
    );
    const ticket = sequence.current;
    const finish = (failure?: unknown) => {
      if (stopped || ticket !== sequence.current) return;
      setGooglePending(null);
      setGoogleReconnecting(false);
      busyRef.current = false;
      setBusy(false);
      setChecking(false);
      if (failure) setError(accountMessage(failure, es));
    };
    const poll = async () => {
      if (stopped || ticket !== sequence.current) return;
      if (Date.now() >= deadline) {
        finish(new AccountError("oidc_expired", ""));
        return;
      }
      try {
        const status = await loadGoogleSignInStatus(
          googlePending.transactionId,
        );
        if (stopped || ticket !== sequence.current) return;
        if (status === "completed") {
          // The popup only establishes the HttpOnly cookie. Read the ordinary
          // account endpoint; a status, closed window or message is not a session.
          const value = await loadWebAccount();
          if (stopped || ticket !== sequence.current) return;
          if (!(await adoptAccount(value, ticket))) return;
          freshSignInRequired.current = false;
          setChallenge(null);
          setCode("");
          setEmail("");
          setError("");
          setLinkVerificationTarget(null);
          if (authPurpose === "link_provider")
            setAccountStatus(
              es
                ? "Método conectado. Conservas la misma cuenta y cuota."
                : "Sign-in method connected. Your account and allowance are unchanged.",
            );
          if (authPurpose === "account_access")
            setAccountStatus(
              es
                ? "Cuenta verificada. Repite la acción que elegiste."
                : "Account verified. Repeat the action you selected.",
            );
          finish();
          const allowed = await canUseWebBlog();
          if (ticket === sequence.current) setAdmin(allowed);
          return;
        }
        if (status === "failed" || status === "expired") {
          finish(
            new AccountError(
              status === "expired" ? "oidc_expired" : "oidc_failed",
              "",
            ),
          );
          return;
        }
        setGoogleReconnecting(false);
      } catch (failure) {
        if (stopped || ticket !== sequence.current) return;
        if (
          failure instanceof AccountError &&
          failure.code !== "unreachable" &&
          failure.code !== "unavailable"
        ) {
          finish(failure);
          return;
        }
        setGoogleReconnecting(true);
      }
      if (!stopped && ticket === sequence.current) {
        delay = Math.min(10_000, Math.ceil(delay * 1.5));
        timer = setTimeout(
          poll,
          Math.min(delay, Math.max(0, deadline - Date.now())),
        );
      }
    };
    timer = setTimeout(
      poll,
      Math.min(delay, Math.max(0, deadline - Date.now())),
    );
    return () => {
      stopped = true;
      clearTimeout(timer);
    };
  }, [googlePending, es, authPurpose, adoptAccount]);

  useEffect(() => {
    setWebAuthorizer((operationId) => {
      const current = accountRef.current;
      if (!current) throw new AccountError("sign_in_required", "");
      return authorizeWebExport(operationId, current);
    });
    const update = (event: Event) => {
      const quota = (
        event as CustomEvent<
          AccountAvailability & { ownerKey: string; sessionKey: string }
        >
      ).detail;
      const identity = accountRef.current;
      if (
        !identity ||
        identity.ownerKey !== quota.ownerKey ||
        identity.sessionKey !== quota.sessionKey
      )
        return;
      setAccount((current) =>
        current &&
        current.ownerKey === quota.ownerKey &&
        current.sessionKey === quota.sessionKey
          ? {
              ...current,
              remaining: quota.remaining,
              nextAvailableAt: quota.nextAvailableAt,
            }
          : current,
      );
      if (quota.remaining === 0) setEditing(false);
    };
    const ready = () => setRecovery(hasWebExportRecovery());
    const reviewPolicy = () => {
      void refresh();
    };
    const invalidate = () => {
      sequence.current++;
      onSuspendAccount();
      setAccount(null);
      setAdmin(false);
      setChecking(false);
    };
    const offline = () => {
      if (busyRef.current) {
        setGoogleReconnecting(true);
        return;
      }
      invalidate();
      setError(accountMessage(null, es));
    };
    const recheck = () => {
      if (document.visibilityState === "visible" && !busyRef.current) {
        void refresh();
      }
    };
    const visibility = () => {
      if (freshSignInRequired.current) {
        setChecking(false);
        return;
      }
      // A suspended/bfcache tab must revalidate before showing private work.
      onSuspendAccount();
      setChecking(true);
      recheck();
    };
    const externalChange = () => {
      if (freshSignInRequired.current) {
        setChecking(false);
        return;
      }
      invalidate();
      setChecking(true);
      recheck();
    };
    const externalEnd = () => {
      // Do not re-read an old cookie while the other tab's remote logout is
      // still in flight. A deliberate new sign-in is required in this tab.
      freshSignInRequired.current = true;
      invalidate();
      setError("");
    };
    window.addEventListener("accreatio:quota", update);
    window.addEventListener("accreatio:export-ready", ready);
    window.addEventListener("accreatio:session-invalid", invalidate);
    window.addEventListener("accreatio:policy-required", reviewPolicy);
    window.addEventListener("online", recheck);
    window.addEventListener("offline", offline);
    window.addEventListener("accreatio:account-recheck", externalChange);
    window.addEventListener("accreatio:account-ended", externalEnd);
    window.addEventListener("pageshow", visibility);
    document.addEventListener("visibilitychange", visibility);
    const poll = window.setInterval(recheck, 60_000);
    void refresh();
    return () => {
      sequence.current++;
      window.clearInterval(poll);
      window.removeEventListener("accreatio:quota", update);
      window.removeEventListener("accreatio:export-ready", ready);
      window.removeEventListener("accreatio:session-invalid", invalidate);
      window.removeEventListener("accreatio:policy-required", reviewPolicy);
      window.removeEventListener("online", recheck);
      window.removeEventListener("offline", offline);
      window.removeEventListener("accreatio:account-recheck", externalChange);
      window.removeEventListener("accreatio:account-ended", externalEnd);
      window.removeEventListener("pageshow", visibility);
      document.removeEventListener("visibilitychange", visibility);
    };
  }, [refresh, es, onSuspendAccount]);
  useEffect(() => {
    const enabledProviders: (WebIdentityProvider | "email-code")[] = [];
    if (methods?.methods.google.available) enabledProviders.push("google");
    if (methods?.methods.github.available) enabledProviders.push("github");
    if (methods?.methods.emailOtp.available)
      enabledProviders.push("email-code");
    onSessionChange(account !== null && !checking, admin, enabledProviders);
  }, [account, checking, admin, methods, onSessionChange]);
  useEffect(() => {
    if (active && (!account || account.policyAuthorizationRequired))
      titleRef.current?.focus({ preventScroll: true });
  }, [active, account === null, account?.policyAuthorizationRequired]);
  useEffect(() => {
    if (challenge && !busy) codeRef.current?.focus();
  }, [challenge?.challengeId, busy]);
  useEffect(() => {
    if (!challenge && !retryAt) return;
    setNow(Date.now());
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [challenge, retryAt]);
  useEffect(() => {
    if (!account) return;
    const delay = Math.max(0, Date.parse(account.expiresAt) - Date.now());
    const timer = window.setTimeout(
      () => {
        sequence.current++;
        onSuspendAccount();
        setAccount(null);
        setAdmin(false);
        setError(accountMessage(new AccountError("sign_in_required", ""), es));
      },
      Math.min(delay, 2_147_483_647),
    );
    return () => window.clearTimeout(timer);
  }, [account?.expiresAt, es, onSuspendAccount]);
  useEffect(() => {
    if (!account?.nextAvailableAt) return;
    const timer = window.setTimeout(
      () => void refresh(),
      Math.max(500, Date.parse(account.nextAvailableAt) - Date.now() + 1000),
    );
    return () => window.clearTimeout(timer);
  }, [account?.nextAvailableAt, refresh]);

  function showFailure(
    failure: unknown,
    action: WebVerificationAction = "data",
  ) {
    if (
      failure instanceof AccountError &&
      failure.code === "reauthentication_required"
    ) {
      freshSignInRequired.current = true;
      setRightsAction(action);
      setRightsProviders(account?.connectedProviders ?? []);
      setRightsSignInAvailable(account !== null);
      setAccount(null);
      onSuspendAccount();
      setAdmin(false);
      setDeleting(false);
      setChecking(false);
      onRequireSignIn();
    }
    setError(accountMessage(failure, es));
    if (failure instanceof AccountError && failure.retryAfter)
      setRetryAt(Date.now() + failure.retryAfter * 1000);
  }
  async function signInWithProvider(
    provider: WebIdentityProvider,
    purpose: "sign_in" | "account_access" | "link_provider" = "sign_in",
    verificationAction?: WebVerificationAction,
  ) {
    if (
      busyRef.current ||
      Date.now() < retryAt ||
      !methods?.methods[provider].available ||
      (purpose === "sign_in" && methods.captcha?.required && !captchaToken)
    )
      return;
    busyRef.current = true;
    setBusy(true);
    setError("");
    setAccountStatus("");
    setAuthProvider(provider);
    setAuthPurpose(purpose);
    setGoogleReconnecting(false);
    const verificationToken = purpose === "sign_in" ? captchaToken : undefined;
    if (purpose === "sign_in") setCaptchaToken("");
    const ticket = ++sequence.current;
    let popup: Window | null = null;
    try {
      if (transientAttachmentCount > 0 || purpose !== "sign_in") {
        // This runs before the first await, under the user's click activation.
        // Do not use window.open(noopener): browsers may return a null handle.
        popup = window.open(
          "about:blank",
          "_blank",
          "popup,width=520,height=720",
        );
        if (!popup) throw new AccountError("popup_blocked", "");
        popup.opener = null;
        popup.document.title = "accreatio";
        popup.document.body.textContent = es
          ? "Preparando el acceso. Mantén abierta la pestaña de tu proyecto."
          : "Preparing sign-in. Keep your project tab open.";
        googleWindow.current = popup;
      }
      try {
        await onBeforeSignIn(!popup);
      } catch {
        // A popup keeps this document and its private in-memory work alive.
        // Only a full-page redirect requires a confirmed durable save.
        if (!popup) throw new AccountError("draft_not_saved", "");
      }
      if (ticket !== sequence.current) return;
      const transaction = await startProviderSignIn(
        provider,
        popup ? "popup" : "redirect",
        {
          purpose,
          policyAuthorization:
            purpose === "sign_in"
              ? accountPolicyAuthorization({
                  accountDataAuthorized: true,
                  termsAccepted: true,
                })
              : undefined,
          verificationAction,
          captchaToken: verificationToken,
        },
      );
      if (ticket !== sequence.current) return;
      if (popup) {
        popup.location.replace(transaction.authorizationUrl);
        setGooglePending(transaction);
      } else {
        // Fields were durably saved and no transient file bytes can be lost.
        window.location.assign(transaction.authorizationUrl);
        busyRef.current = false;
        setBusy(false);
      }
    } catch (failure) {
      try {
        popup?.close();
      } catch {
        /* COOP may already have isolated it. */
      }
      if (ticket === sequence.current) {
        busyRef.current = false;
        setBusy(false);
        setChecking(false);
        if (
          purpose === "link_provider" &&
          failure instanceof AccountError &&
          failure.code === "reauthentication_required"
        ) {
          setLinkVerificationTarget(provider);
          setError(
            es
              ? "Verifica tu cuenta actual y luego vuelve a conectar el proveedor."
              : "Verify your current account, then connect the provider again.",
          );
        } else showFailure(failure, verificationAction);
      }
    } finally {
      if (purpose === "sign_in") setCaptchaGeneration((value) => value + 1);
    }
  }
  async function cancelGoogle() {
    if (!googlePending || googleCancelling) return;
    const ticket = sequence.current;
    setGoogleCancelling(true);
    try {
      const status = await cancelGoogleSignIn(googlePending.transactionId);
      if (ticket !== sequence.current) return;
      if (status === "completed") {
        // Completion can win the server-side race with cancellation.
        const value = await loadWebAccount();
        if (!(await adoptAccount(value, ticket))) return;
        freshSignInRequired.current = false;
        setAdmin(await canUseWebBlog());
      }
      sequence.current++;
      setGooglePending(null);
      setGoogleReconnecting(false);
      setChecking(false);
      setBusy(false);
      busyRef.current = false;
      setError("");
      try {
        googleWindow.current?.close();
      } catch {
        /* No opener dependency. */
      }
      googleWindow.current = null;
    } catch {
      setError(
        es
          ? "No pudimos confirmar la cancelación. Seguimos comprobando el acceso; mantén abierta esta pestaña."
          : "We could not confirm cancellation. We are still checking sign-in; keep this tab open.",
      );
    } finally {
      setGoogleCancelling(false);
    }
  }
  async function sendCode() {
    if (busyRef.current || !methods?.methods.emailOtp.available) return;
    busyRef.current = true;
    setBusy(true);
    setError("");
    const ticket = ++sequence.current;
    try {
      // Authentication remains in this page, so a failed disk write cannot lose
      // the in-memory draft or prevent access. Still flush when storage permits.
      await onBeforeSignIn().catch(() => {});
      if (ticket !== sequence.current) return;
      const value = await requestEmailCode(
        email,
        accountPolicyAuthorization({
          accountDataAuthorized: true,
          termsAccepted: true,
        }),
      );
      if (ticket !== sequence.current) return;
      setEmail(email.trim());
      setChallenge(value);
      setCode("");
      setRetryAt(0);
      setNow(Date.now());
    } catch (failure) {
      if (ticket === sequence.current) showFailure(failure);
    } finally {
      busyRef.current = false;
      setBusy(false);
      setChecking(false);
    }
  }
  async function verifyCode() {
    if (busyRef.current || !challenge) return;
    busyRef.current = true;
    setBusy(true);
    setError("");
    const ticket = ++sequence.current;
    try {
      const value = await verifyEmailCode(challenge.challengeId, code);
      if (ticket !== sequence.current) return;
      if (!(await adoptAccount(value, ticket))) return;
      freshSignInRequired.current = false;
      setChallenge(null);
      setCode("");
      setEmail("");
      setRetryAt(0);
      const allowed = await canUseWebBlog();
      if (ticket === sequence.current) setAdmin(allowed);
    } catch (failure) {
      if (ticket === sequence.current) showFailure(failure);
    } finally {
      busyRef.current = false;
      setBusy(false);
      setChecking(false);
    }
  }
  async function signOut(remove = false) {
    if (busyRef.current) return;
    const endingIdentity = accountRef.current;
    if (!endingIdentity) return;
    busyRef.current = true;
    setBusy(true);
    const ticket = ++sequence.current;
    let cleanupFailed = false;
    if (!remove) {
      freshSignInRequired.current = true;
      setAccount(null);
      setAdmin(false);
      try {
        // Explicit logout clears work immediately, even if the network fails.
        await onClearAccount(endingIdentity);
      } catch {
        cleanupFailed = true;
      }
    }
    try {
      await closeWebAccount(remove);
      if (remove) {
        // A rejected deletion must preserve work for same-owner verification.
        // A completed deletion clears only the session that requested it.
        try {
          await onClearAccount(endingIdentity);
        } catch {
          cleanupFailed = true;
        }
      }
      if (ticket !== sequence.current) return;
      freshSignInRequired.current = true;
      clearWebExportRecovery();
      setRecovery(false);
      setAccount(null);
      setRightsSignInAvailable(false);
      setAdmin(false);
      setChallenge(null);
      setCode("");
      setEmail("");
      setRetryAt(0);
      setDeleting(false);
      setEditing(false);
      setError(
        cleanupFailed
          ? es
            ? "La sesión se cerró. El navegador no confirmó el borrado del almacenamiento local; borra los datos de este sitio en el navegador."
            : "Signed out. The browser could not confirm local storage removal; clear this site's data in your browser."
          : "",
      );
    } catch (failure) {
      showFailure(failure, remove ? "delete" : "data");
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }
  async function retry() {
    setBusy(true);
    setError("");
    try {
      await retryWebExport();
    } catch (failure) {
      setError(accountMessage(failure, es));
    } finally {
      setBusy(false);
    }
  }
  async function downloadAccountData() {
    if (busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setError("");
    try {
      const value = await loadWebAccountData();
      const objectUrl = URL.createObjectURL(
        new Blob([JSON.stringify(value, null, 2)], {
          type: "application/json",
        }),
      );
      const link = document.createElement("a");
      link.href = objectUrl;
      link.download = "accreatio-account-data.json";
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    } catch (failure) {
      showFailure(failure);
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }
  async function acceptAccountPolicy() {
    if (busyRef.current || !account?.policyAuthorizationRequired) return;
    busyRef.current = true;
    setBusy(true);
    setError("");
    const ticket = ++sequence.current;
    try {
      const value = await saveWebAccountPolicy({
        ...accountPolicyAuthorization({
          accountDataAuthorized: true,
          termsAccepted: true,
        }),
        cookiesNoticeVersion: ACCOUNT_COOKIES_NOTICE_VERSION,
        cookiesNoticeAcknowledged: true,
      });
      if (ticket === sequence.current) await adoptAccount(value, ticket);
    } catch (failure) {
      if (ticket === sequence.current) showFailure(failure);
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }
  const accountMenu =
    account && !checking && accountMenuTarget
      ? createPortal(
          <WebAccountMenu
            account={account}
            locale={locale}
            busy={busy}
            deleting={deleting}
            error={active ? "" : error}
            onDeleteChange={setDeleting}
            onDownload={() => void downloadAccountData()}
            onSignOut={(remove) => void signOut(remove)}
            methods={methods}
            status={accountStatus}
            verificationAction={
              linkVerificationTarget
                ? `link_${linkVerificationTarget}`
                : undefined
            }
            onConnect={(provider) =>
              void signInWithProvider(provider, "link_provider")
            }
            onVerify={(provider, action) =>
              void signInWithProvider(provider, "account_access", action)
            }
            pending={googlePending !== null}
            onCancel={() => void cancelGoogle()}
          />,
          accountMenuTarget,
        )
      : null;
  if (!active)
    return (
      <>
        {accountMenu}
        {children}
      </>
    );
  if (account && !checking && account.policyAuthorizationRequired) {
    return (
      <>
        {accountMenu}
        <main
          className="onboarding web-signin"
          aria-labelledby="account-policy-title"
        >
          <section className="onboarding-card">
            <h1 id="account-policy-title" ref={titleRef} tabIndex={-1}>
              {es
                ? "Revisa tu cuenta y tus datos"
                : "Review your account and data"}
            </h1>
            <p>
              {es
                ? "Actualizamos los avisos de la beta. Tu cuenta aún no tiene registrada esta autorización. Tus proyectos y tu cuota se conservan."
                : "We updated the beta notices. Your account has no record of this authorization yet. Your projects and allowance are preserved."}
            </p>
            <p>
              {es
                ? "Puedes gestionar tus datos desde Privacy y cerrar sesión sin aceptar esta actualización. Para descargar o eliminar se requiere una verificación de los últimos cinco minutos."
                : "You can manage your data inside Privacy and sign out without accepting this update. Download and deletion need verification within the last five minutes."}
            </p>
            <div className="web-signin__providers">
              {(account.connectedProviders ?? [])
                .filter((provider) => methods?.methods[provider].available)
                .map((provider) => (
                  <button
                    key={provider}
                    className="secondary"
                    type="button"
                    disabled={busy}
                    onClick={() =>
                      void signInWithProvider(
                        provider,
                        "account_access",
                        "data",
                      )
                    }
                  >
                    {es
                      ? `Verificar ${provider === "github" ? "GitHub" : "Google"} para gestionar mi cuenta`
                      : `Verify ${provider === "github" ? "GitHub" : "Google"} for account controls`}
                  </button>
                ))}
            </div>
            <p>
              {es
                ? "Si no puedes verificar tu cuenta, escribe a "
                : "If you cannot verify your account, contact "}
              <a href="mailto:aekr@aekr.io">aekr@aekr.io</a>.
            </p>
            {error && (
              <p className="web-signin__error" role="alert">
                {error}
              </p>
            )}
            <AccountPolicyFields locale={locale} acknowledgeCookies />
            <div className="onboarding-actions">
              <button
                type="button"
                className="secondary"
                onClick={onBack}
                disabled={busy}
              >
                {es ? "Atrás" : "Back"}
              </button>
              <button
                type="button"
                className="save"
                disabled={busy}
                aria-describedby="account-policy-terms account-policy-data account-policy-scope"
                onClick={() => void acceptAccountPolicy()}
              >
                {busy
                  ? es
                    ? "Guardando…"
                    : "Saving…"
                  : es
                    ? "Guardar y continuar"
                    : "Save and continue"}
              </button>
            </div>
          </section>
        </main>
      </>
    );
  }
  if (!account || checking) {
    const resendSeconds = Math.max(
      0,
      Math.ceil(
        (Math.max(retryAt, challenge ? Date.parse(challenge.resendAt) : 0) -
          now) /
          1000,
      ),
    );
    const retrySeconds = Math.max(0, Math.ceil((retryAt - now) / 1000));
    const expired =
      challenge !== null && Date.parse(challenge.expiresAt) <= now;
    return (
      <main
        className="onboarding web-signin"
        aria-labelledby="web-signin-title"
      >
        <section className="onboarding-card">
          <FormationMark
            homeLabel={
              es ? "Ir al inicio de accreatio" : "Go to accreatio home"
            }
            tagline={
              es
                ? "De la idea a un inicio estructurado"
                : "From idea to a structured beginning"
            }
          />
          <p className="onboarding-progress">
            {es ? "Bienvenida · Paso 3 de 3" : "Welcome · Step 3 of 3"}
          </p>
          <div className="onboarding-content">
            <Mail aria-hidden="true" />
            <h1 id="web-signin-title" tabIndex={-1} ref={titleRef}>
              {es
                ? "Accede para comenzar tu proyecto"
                : "Sign in to start your project"}
            </h1>
            <p>
              {es
                ? "Usa uno de los métodos disponibles para acceder a tu cuenta."
                : "Use an available method to sign in to your account."}
            </p>
            <p className="onboarding-locality">
              {es
                ? "Guardamos los datos necesarios para tu cuenta, sesión y cuota. Tu proyecto y tus adjuntos permanecen en este dispositivo."
                : "We keep the data needed for your account, session and allowance. Your project and attachments stay on this device."}
            </p>
            {checking || methodsLoading ? (
              <p role="status">
                {es
                  ? "Comprobando tu sesión segura…"
                  : "Checking your secure session…"}
              </p>
            ) : null}
            {!checking &&
              !methodsLoading &&
              rightsSignInAvailable &&
              !googlePending && (
                <div className="web-signin__rights">
                  <div className="web-signin__providers">
                    {rightsProviders
                      .filter(
                        (provider) => methods?.methods[provider].available,
                      )
                      .map((provider) => (
                        <button
                          key={provider}
                          type="button"
                          className="secondary"
                          disabled={busy || retryAt > now}
                          onClick={() =>
                            void signInWithProvider(
                              provider,
                              "account_access",
                              rightsAction,
                            )
                          }
                        >
                          {es
                            ? `Verificar ${provider === "github" ? "GitHub" : "Google"} para gestionar mi cuenta`
                            : `Verify ${provider === "github" ? "GitHub" : "Google"} for account controls`}
                        </button>
                      ))}
                  </div>
                  <p>
                    {es
                      ? "Esta verificación es para descargar tus datos o eliminar tu cuenta existente, sin aceptar términos nuevos. Si tu sesión ya venció, escribe a "
                      : "Verify to download your data or delete your existing account without accepting new terms. If your session has expired, contact "}
                    <a href="mailto:aekr@aekr.io">aekr@aekr.io</a>.
                  </p>
                </div>
              )}
            {!checking &&
              !methodsLoading &&
              (methods?.methods.google.available ||
                methods?.methods.github.available ||
                methods?.methods.emailOtp.available) && (
                <AccountPolicyFields locale={locale} />
              )}
            {!checking &&
              !methodsLoading &&
              !challenge &&
              (methods?.methods.google.available ||
                methods?.methods.github.available) && (
                <div className="web-signin__google">
                  {methods?.captcha?.siteKey && (
                    <SharedCaptcha
                      siteKey={methods.captcha.siteKey}
                      locale={locale}
                      generation={captchaGeneration}
                      onToken={setCaptchaToken}
                    />
                  )}
                  {methods?.captcha && !methods.captcha.siteKey && (
                    <p role="status">
                      {es
                        ? "La verificación no está disponible ahora. Vuelve a intentarlo más tarde."
                        : "Verification is unavailable right now. Please try again later."}
                    </p>
                  )}
                  <div className="web-signin__providers">
                    {(["google", "github"] as const)
                      .filter(
                        (provider) => methods?.methods[provider].available,
                      )
                      .map((provider) => (
                        <button
                          key={provider}
                          className="web-signin__google-button"
                          type="button"
                          disabled={
                            busy ||
                            retryAt > now ||
                            (methods.captcha?.required === true &&
                              !captchaToken)
                          }
                          onClick={() => void signInWithProvider(provider)}
                          aria-describedby={`account-policy-terms account-policy-data account-policy-scope${methods.captcha ? " shared-captcha-description" : ""}`}
                        >
                          {provider === "google" && (
                            <img
                              src="/auth/google-g.png"
                              alt=""
                              width="20"
                              height="20"
                            />
                          )}
                          <span>
                            {es ? "Continuar con" : "Continue with"}{" "}
                            {provider === "github" ? "GitHub" : "Google"}
                          </span>
                        </button>
                      ))}
                  </div>
                </div>
              )}
            {googlePending && (
              <div className="web-signin__pending">
                <p role="status">
                  {googleReconnecting
                    ? es
                      ? "Reconectando para comprobar el acceso. Tus archivos siguen en esta pestaña."
                      : "Reconnecting to check sign-in. Your files are still in this tab."
                    : es
                      ? `Completa el acceso en la ventana de ${authProvider === "github" ? "GitHub" : "Google"}. Esta pestaña continuará cuando tu sesión esté verificada.`
                      : `Complete sign-in in the ${authProvider === "github" ? "GitHub" : "Google"} window. This tab will continue once your session is verified.`}
                </p>
                <button
                  type="button"
                  className="secondary"
                  disabled={googleCancelling}
                  onClick={() => void cancelGoogle()}
                >
                  {es ? "Cancelar acceso" : "Cancel sign-in"}
                </button>
              </div>
            )}
            {!checking &&
              !methodsLoading &&
              methods?.methods.emailOtp.available &&
              !googlePending && (
                <form
                  id="web-signin-form"
                  className="web-signin__form"
                  onSubmit={(event) => {
                    event.preventDefault();
                    void (challenge ? verifyCode() : sendCode());
                  }}
                >
                  {challenge ? (
                    <>
                      <p id="web-code-help" role="status">
                        {es
                          ? `Enviamos un código a ${email}. Revisa también la carpeta de correo no deseado.`
                          : `We sent a code to ${email}. Check your spam folder too.`}
                      </p>
                      <label htmlFor="web-otp">
                        {es ? "Código de 6 dígitos" : "6-digit code"}
                      </label>
                      <input
                        ref={codeRef}
                        id="web-otp"
                        name="one-time-code"
                        type="text"
                        inputMode="numeric"
                        autoComplete="one-time-code"
                        pattern="[0-9]{6}"
                        maxLength={6}
                        required
                        value={code}
                        disabled={busy}
                        aria-describedby="web-code-help web-code-expiry"
                        onChange={(event) =>
                          setCode(
                            event.target.value.replace(/\D/g, "").slice(0, 6),
                          )
                        }
                      />
                      <p id="web-code-expiry">
                        {expired
                          ? es
                            ? "El código ha vencido. Solicita otro para continuar."
                            : "This code has expired. Request another to continue."
                          : es
                            ? "El código vence en 10 minutos y solo puede usarse una vez."
                            : "The code expires in 10 minutes and can only be used once."}
                      </p>
                      <div className="web-signin__recovery">
                        <button
                          type="button"
                          className="secondary"
                          disabled={busy || resendSeconds > 0}
                          aria-describedby="account-policy-terms account-policy-data account-policy-scope"
                          onClick={() => void sendCode()}
                        >
                          {resendSeconds > 0
                            ? es
                              ? `Reenviar en ${resendSeconds} s`
                              : `Resend in ${resendSeconds} s`
                            : es
                              ? "Enviar otro código"
                              : "Send another code"}
                        </button>
                        <button
                          type="button"
                          className="secondary"
                          disabled={busy}
                          onClick={() => {
                            setChallenge(null);
                            setCode("");
                            setError("");
                          }}
                        >
                          {es ? "Cambiar correo" : "Change email"}
                        </button>
                      </div>
                    </>
                  ) : (
                    <>
                      <label htmlFor="web-email">
                        {es ? "Correo electrónico" : "Email address"}
                      </label>
                      <input
                        id="web-email"
                        name="email"
                        type="email"
                        inputMode="email"
                        autoComplete="email"
                        autoCapitalize="none"
                        spellCheck={false}
                        maxLength={254}
                        required
                        value={email}
                        disabled={busy}
                        onChange={(event) => setEmail(event.target.value)}
                      />
                      <p>
                        {es
                          ? "Te enviaremos un código para acceder sin contraseña."
                          : "We'll email you a code to sign in without a password."}
                      </p>
                    </>
                  )}
                  {retrySeconds > 0 && (
                    <p role="status">
                      {es
                        ? `Puedes intentarlo de nuevo en ${retrySeconds} s.`
                        : `You can try again in ${retrySeconds} s.`}
                    </p>
                  )}
                </form>
              )}
            {!checking &&
              !methodsLoading &&
              !methods?.methods.google.available &&
              !methods?.methods.github.available &&
              !methods?.methods.emailOtp.available && (
                <div className="web-signin__unavailable">
                  <p role="status">
                    {es
                      ? "El acceso no está disponible ahora. Tu borrador permanece en este dispositivo."
                      : "Sign-in is unavailable right now. Your draft stays on this device."}
                  </p>
                  <button
                    type="button"
                    className="secondary"
                    disabled={busy}
                    onClick={() => void refreshMethods()}
                  >
                    {es
                      ? "Comprobar métodos disponibles"
                      : "Check available methods"}
                  </button>
                </div>
              )}

            {error && (
              <p className="web-signin__error" role="alert">
                {error}
              </p>
            )}
            {retrySeconds > 0 && !methods?.methods.emailOtp.available && (
              <p role="status">
                {es
                  ? `Puedes volver a solicitar acceso en ${retrySeconds} s. La gestión de tus datos sigue disponible por separado.`
                  : `You can request sign-in again in ${retrySeconds} s. Account data controls remain available separately.`}
              </p>
            )}
            {error && !challenge && (
              <button
                type="button"
                className="secondary"
                disabled={busy || checking}
                onClick={() => void refresh()}
              >
                {es ? "Comprobar sesión de nuevo" : "Check session again"}
              </button>
            )}
          </div>
          <div className="onboarding-actions">
            <button
              type="button"
              className="secondary"
              disabled={busy}
              onClick={onBack}
            >
              <ArrowLeft aria-hidden="true" />
              {es ? "Atrás" : "Back"}
            </button>
            {methods?.methods.emailOtp.available && !googlePending && (
              <button
                type="submit"
                form="web-signin-form"
                className="save"
                aria-describedby="account-policy-terms account-policy-data account-policy-scope"
                disabled={
                  busy ||
                  checking ||
                  retrySeconds > 0 ||
                  (challenge !== null && (code.length !== 6 || expired))
                }
              >
                {busy
                  ? es
                    ? "Procesando…"
                    : "Working…"
                  : challenge
                    ? es
                      ? "Verificar y continuar"
                      : "Verify and continue"
                    : es
                      ? "Enviar código"
                      : "Send code"}
                <ArrowRight aria-hidden="true" />
              </button>
            )}
          </div>
        </section>
      </main>
    );
  }
  const exhausted = account.remaining === 0 && !editing;
  return (
    <>
      {accountMenu}
      {error && (
        <p className="web-account__error" role="alert">
          {error}
        </p>
      )}
      {recovery && (
        <div className="web-account__recovery">
          <button
            className="secondary"
            type="button"
            disabled={busy}
            onClick={() => void retry()}
          >
            {es
              ? "Volver a descargar el mismo ZIP"
              : "Download the same ZIP again"}
          </button>
          <small>
            {es
              ? "Reintentar una autorización aceptada dentro de 48 horas no consume otra."
              : "Retry an accepted authorization within 48 hours without using extra allowance."}
          </small>
        </div>
      )}
      {exhausted ? (
        <main className="web-account__thanks" aria-labelledby="quota-thanks">
          <h1 id="quota-thanks">
            {es
              ? "¡Gracias por crear con accreatio!"
              : "Thank you for creating with accreatio!"}
          </h1>
          <p>
            {es
              ? "Has usado tus cinco exportaciones. Vuelve para seguir dando forma a tus ideas."
              : "You've used your five exports. Come back for more space to grow your ideas."}
          </p>
          {account.nextAvailableAt && (
            <p>
              {es
                ? "Tu próxima exportación estará disponible: "
                : "Your next export is available: "}
              <time dateTime={account.nextAvailableAt}>
                {new Date(account.nextAvailableAt).toLocaleString(
                  es ? "es" : "en",
                )}
              </time>
              .
            </p>
          )}
          <p>
            {es
              ? "Tu borrador permanece en este dispositivo."
              : "Your draft stays on this device."}
          </p>
          <button
            className="secondary"
            type="button"
            onClick={() => setEditing(true)}
          >
            {es ? "Seguir editando mi borrador" : "Keep editing my draft"}
          </button>
        </main>
      ) : (
        children
      )}
    </>
  );
}
