import { legalHref, termsHref } from "../../legal";
import type { Locale } from "../../types";

export function AccountPolicyFields({
  locale,
  acknowledgeCookies = false,
}: {
  locale: Locale;
  acknowledgeCookies?: boolean;
}) {
  const es = locale === "es";
  return (
    <section
      className="web-signin__policy"
      aria-label={es ? "Tu cuenta y tus datos" : "Your account and data"}
    >
      <p id="account-policy-terms">
        {es ? "Al continuar, aceptas los " : "By continuing, you accept the "}
        <a href={termsHref(locale)} target="_blank" rel="noopener noreferrer">
          {es ? "Términos de AEKR" : "AEKR Terms"}
        </a>
        .
      </p>
      <p id="account-policy-data">
        {es
          ? "Al continuar, autorizas a AEKR a tratar tu identificador de acceso, correo, nombre y los datos mínimos de sesión y cuota necesarios para prestar y proteger tu cuenta, según la "
          : "By continuing, you authorize AEKR to process your sign-in identifier, email, name and minimal session and allowance records needed to provide and protect your account, as described in the "}
        <a
          href={legalHref("privacy", locale)}
          target="_blank"
          rel="noopener noreferrer"
        >
          {es ? "Política de privacidad" : "Privacy Policy"}
        </a>
        .
      </p>
      <p id="account-policy-scope">
        {es
          ? "Tus proyectos siguen en tu dispositivo. Puedes retirar esta autorización eliminando tu cuenta; los identificadores protegidos de cuota permanecen 48 horas. No autorizas publicidad ni analítica."
          : "Your projects stay on your device. You can withdraw this authorization by deleting your account; protected allowance identifiers remain for 48 hours. This does not authorize advertising or analytics."}
      </p>
      {acknowledgeCookies && (
        <p id="account-policy-cookies">
          {es
            ? "Al guardar y continuar, reconoces el aviso de cookies y almacenamiento necesario. Las opciones de analítica e investigación siguen separadas y desactivadas salvo tu elección expresa."
            : "By saving and continuing, you acknowledge the cookies and necessary storage notice. Optional analytics and research stay separate and off unless you expressly choose them."}
        </p>
      )}
      <a
        href={legalHref("cookies", locale)}
        target="_blank"
        rel="noopener noreferrer"
      >
        {es ? "Cookies y almacenamiento local" : "Cookies and local storage"}
      </a>
    </section>
  );
}
