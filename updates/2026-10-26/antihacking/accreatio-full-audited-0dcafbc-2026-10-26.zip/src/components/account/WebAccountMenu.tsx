import { legalHref, termsHref } from "../../legal";
import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
} from "react";
import { ChevronDown } from "lucide-react";
import type { WebAccount } from "../../account/webClient";
import type { Locale } from "../../types";
import type {
  WebAuthMethods,
  WebIdentityProvider,
  WebVerificationAction,
} from "../../account/contracts";

export function WebAccountMenu({
  account,
  locale,
  busy,
  deleting,
  error,
  onDeleteChange,
  onDownload,
  onSignOut,
  methods,
  onConnect,
  onVerify,
  verificationAction,
  status,
  pending,
  onCancel,
}: {
  account: WebAccount;
  locale: Locale;
  busy: boolean;
  deleting: boolean;
  error: string;
  onDeleteChange: (value: boolean) => void;
  onDownload: () => void;
  onSignOut: (remove?: boolean) => void;
  methods?: WebAuthMethods | null;
  onConnect?: (provider: WebIdentityProvider) => void;
  onVerify?: (
    provider: WebIdentityProvider,
    action: WebVerificationAction,
  ) => void;
  verificationAction?: WebVerificationAction;
  status?: string;
  pending?: boolean;
  onCancel?: () => void;
}) {
  const es = locale === "es";
  const limit = 5;
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const focusPanel = useRef(false);
  const name =
    account.displayName ||
    account.email.split("@")[0] ||
    (es ? "Cuenta" : "Account");
  const close = useCallback(
    (restoreFocus = false) => {
      setOpen(false);
      onDeleteChange(false);
      if (restoreFocus) triggerRef.current?.focus({ preventScroll: true });
    },
    [onDeleteChange],
  );

  useLayoutEffect(() => {
    if (!open) return;
    if (focusPanel.current) {
      panelRef.current?.focus({ preventScroll: true });
      focusPanel.current = false;
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const dismissOutside = (event: Event) => {
      if (
        event.target instanceof Node &&
        !rootRef.current?.contains(event.target)
      )
        close();
    };
    const escape = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      close(true);
    };
    document.addEventListener("pointerdown", dismissOutside, true);
    document.addEventListener("focusin", dismissOutside);
    document.addEventListener("keydown", escape);
    return () => {
      document.removeEventListener("pointerdown", dismissOutside, true);
      document.removeEventListener("focusin", dismissOutside);
      document.removeEventListener("keydown", escape);
    };
  }, [open, close]);

  return (
    <div className="web-account-menu" ref={rootRef}>
      <button
        type="button"
        className="web-account-menu__trigger"
        ref={triggerRef}
        aria-expanded={open}
        aria-controls="web-account-menu-panel"
        aria-label={es ? `Cuenta de ${name}` : `Account for ${name}`}
        title={name}
        onClick={() => (open ? close() : setOpen(true))}
        onKeyDown={(event) => {
          if (event.key === "ArrowDown") {
            event.preventDefault();
            if (open) panelRef.current?.focus({ preventScroll: true });
            else {
              focusPanel.current = true;
              setOpen(true);
            }
          }
        }}
      >
        <span>{name}</span>
        <ChevronDown aria-hidden="true" />
      </button>
      {open && (
        <div
          className="web-account-menu__panel"
          id="web-account-menu-panel"
          role="region"
          aria-label={es ? "Cuenta" : "Account"}
          tabIndex={-1}
          ref={panelRef}
        >
          <div className="web-account-menu__identity">
            <strong>{name}</strong>
            {account.email && (
              <p className="web-account-menu__email">{account.email}</p>
            )}
          </div>
          <div className="web-account-menu__quota" role="status">
            <p className="web-account-menu__used">
              {es
                ? `${limit - account.remaining} de ${limit} exportaciones usadas en las últimas 24 horas`
                : `${limit - account.remaining} of ${limit} exports used in the last 24 hours`}
            </p>
            <p className="web-account-menu__remaining">
              {es
                ? `${account.remaining} de ${limit} exportaciones restantes`
                : `${account.remaining} of ${limit} exports remaining`}
            </p>
          </div>
          <p className="web-account-menu__privacy">
            {es
              ? "Conservamos tu nombre, correo, identificadores de acceso y datos mínimos de sesión y cuota. Tus proyectos permanecen locales."
              : "We retain your name, email, sign-in identifiers and minimal session and allowance records. Your projects stay local."}
          </p>
          <div className="web-account-menu__links">
            <a
              href={legalHref("privacy", locale)}
              target="_blank"
              rel="noopener noreferrer"
            >
              {es ? "Privacidad" : "Privacy"}
            </a>
            <a
              href={termsHref(locale)}
              target="_blank"
              rel="noopener noreferrer"
            >
              {es ? "Términos" : "Terms"}
            </a>
            <a
              href={legalHref("cookies", locale)}
              target="_blank"
              rel="noopener noreferrer"
            >
              {es ? "Cookies y almacenamiento" : "Cookies and storage"}
            </a>
          </div>
          <div className="web-account-menu__actions">
            {(account.connectedProviders ?? []).map((provider) => (
              <p key={provider}>
                {provider === "github" ? "GitHub" : "Google"}:{" "}
                {es ? "conectado" : "connected"}
              </p>
            ))}
            {(["google", "github"] as const)
              .filter(
                (provider) =>
                  methods?.methods[provider].available &&
                  !(account.connectedProviders ?? []).includes(provider),
              )
              .map((provider) => (
                <button
                  key={provider}
                  type="button"
                  className="secondary"
                  disabled={busy}
                  onClick={() => onConnect?.(provider)}
                >
                  {es ? "Conectar" : "Connect"}{" "}
                  {provider === "github" ? "GitHub" : "Google"}
                </button>
              ))}
            {verificationAction &&
              (account.connectedProviders ?? [])
                .filter((provider) => methods?.methods[provider].available)
                .map((provider) => (
                  <button
                    key={provider}
                    type="button"
                    className="secondary"
                    disabled={busy}
                    onClick={() => onVerify?.(provider, verificationAction)}
                  >
                    {es ? "Verificar cuenta con" : "Verify account with"}{" "}
                    {provider === "github" ? "GitHub" : "Google"}
                  </button>
                ))}
            {pending && (
              <>
                <p role="status">
                  {es
                    ? "Completa la verificación en la otra ventana."
                    : "Complete verification in the other window."}
                </p>
                <button type="button" className="secondary" onClick={onCancel}>
                  {es ? "Cancelar acceso" : "Cancel sign-in"}
                </button>
              </>
            )}
            {status && <p role="status">{status}</p>}
            <button
              type="button"
              className="secondary"
              disabled={busy}
              onClick={() => {
                close();
                window.dispatchEvent(new Event("accreatio:open-privacy"));
              }}
            >
              {es ? "Privacidad y mis datos" : "Privacy and my data"}
            </button>
            <button
              type="button"
              className="secondary"
              disabled={busy}
              onClick={() => onSignOut()}
            >
              {es ? "Cerrar sesión" : "Sign out"}
            </button>
            <button
              type="button"
              className="secondary"
              disabled={busy}
              aria-expanded={deleting}
              onClick={() => onDeleteChange(!deleting)}
            >
              {es ? "Eliminar cuenta" : "Delete account"}
            </button>
          </div>
          {deleting && (
            <div
              className="web-account-menu__delete"
              role="group"
              aria-label={es ? "Confirmar eliminación" : "Confirm deletion"}
            >
              <p>
                {es
                  ? "Se eliminarán tu nombre, correo y métodos de acceso de accreatio y se cerrarán tus sesiones. Conservamos identificadores protegidos y recibos durante 48 horas para impedir reiniciar la cuota; se eliminan en el mantenimiento posterior. Borra el borrador de este sitio, referencias a archivos seleccionados y el ZIP preparado. El siguiente acceso empieza de cero. No elimina tus cuentas de proveedor ni archivos ya descargados. Descartar sus tokens no revoca la autorización concedida al proveedor."
                  : "Your name, email and accreatio sign-in methods will be removed and your sessions revoked. Protected identifiers and receipts remain for 48 hours to prevent resetting your allowance and are removed during subsequent maintenance. This clears the site draft, selected-file references and prepared ZIP. The next sign-in starts fresh. It does not delete provider accounts or previously downloaded files. Discarding provider tokens does not revoke your provider authorization."}
              </p>
              {(account.connectedProviders ?? []).map((provider) => (
                <a
                  key={provider}
                  href={
                    provider === "github"
                      ? "https://github.com/settings/apps/authorizations"
                      : "https://myaccount.google.com/connections"
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {es
                    ? `Gestionar la autorización en ${provider === "github" ? "GitHub" : "Google"}`
                    : `Manage authorization in ${provider === "github" ? "GitHub" : "Google"}`}
                </a>
              ))}
              <button
                type="button"
                className="secondary"
                disabled={busy}
                onClick={() => onSignOut(true)}
              >
                {es ? "Confirmar eliminación" : "Confirm deletion"}
              </button>
              <button
                type="button"
                className="secondary"
                onClick={() => onDeleteChange(false)}
              >
                {es ? "Cancelar" : "Cancel"}
              </button>
            </div>
          )}
          {error && (
            <p className="web-account-menu__error" role="alert">
              {error}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
