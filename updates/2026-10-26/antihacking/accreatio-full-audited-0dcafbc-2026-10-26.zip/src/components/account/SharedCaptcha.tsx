import { useEffect, useRef, useState } from "react";
import type { Locale } from "../../types";
import "./sharedCaptcha.css";

interface TurnstileApi {
  render(container: HTMLElement, options: Record<string, unknown>): string;
  remove(widget: string): void;
}
declare global {
  interface Window {
    turnstile?: TurnstileApi;
  }
}
const SCRIPT =
  "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
let loading: Promise<TurnstileApi> | undefined;
function loadTurnstile(): Promise<TurnstileApi> {
  if (window.turnstile) return Promise.resolve(window.turnstile);
  if (loading) return loading;
  loading = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    const timeout = window.setTimeout(() => fail(), 15_000);
    const fail = () => {
      window.clearTimeout(timeout);
      script.remove();
      loading = undefined;
      reject(new Error("verification_unavailable"));
    };
    script.src = SCRIPT;
    script.async = true;
    script.onerror = fail;
    script.onload = () => {
      window.clearTimeout(timeout);
      if (window.turnstile) resolve(window.turnstile);
      else fail();
    };
    document.head.append(script);
  });
  return loading;
}

export function SharedCaptcha({
  siteKey,
  locale,
  generation,
  onToken,
}: {
  siteKey: string;
  locale: Locale;
  generation: number;
  onToken(token: string): void;
}) {
  const es = locale === "es";
  const [started, setStarted] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [status, setStatus] = useState<
    "idle" | "loading" | "ready" | "verified" | "error" | "expired"
  >("idle");
  const container = useRef<HTMLDivElement>(null);
  useEffect(() => {
    onToken("");
    if (!started) return;
    let active = true;
    let api: TurnstileApi | undefined;
    let widget: string | undefined;
    setStatus("loading");
    void loadTurnstile()
      .then((loaded) => {
        if (!active || !container.current) return;
        api = loaded;
        widget = api.render(container.current, {
          sitekey: siteKey,
          action: "login",
          language: locale,
          theme: "auto",
          size: "flexible",
          "response-field": false,
          callback: (token: string) => {
            if (active) {
              onToken(token);
              setStatus("verified");
            }
          },
          "expired-callback": () => {
            if (active) {
              onToken("");
              setStatus("expired");
            }
          },
          "timeout-callback": () => {
            if (active) {
              onToken("");
              setStatus("expired");
            }
          },
          "error-callback": () => {
            if (active) {
              onToken("");
              setStatus("error");
            }
          },
        });
        setStatus("ready");
      })
      .catch(() => {
        if (active) setStatus("error");
      });
    return () => {
      active = false;
      onToken("");
      if (api && widget !== undefined) {
        try {
          api.remove(widget);
        } catch {
          // A failed third-party challenge must not break local project UI.
          container.current?.replaceChildren();
        }
      }
    };
  }, [siteKey, locale, generation, started, attempt, onToken]);
  return (
    <section
      className="shared-captcha"
      aria-label={es ? "Verificación de acceso" : "Sign-in verification"}
    >
      <p id="shared-captcha-description">
        {es
          ? "Una verificación para continuar con Google o GitHub."
          : "One verification to continue with Google or GitHub."}
      </p>
      {(!started || status === "error" || status === "expired") && (
        <button
          type="button"
          className="secondary"
          onClick={() => {
            setStarted(true);
            setAttempt((value) => value + 1);
          }}
        >
          {started
            ? es
              ? "Verificar de nuevo"
              : "Verify again"
            : es
              ? "Verificar para continuar"
              : "Verify to continue"}
        </button>
      )}
      <div ref={container} className="shared-captcha__widget" />
      <p className="shared-captcha__status" role="status">
        {status === "loading"
          ? es
            ? "Cargando verificación…"
            : "Loading verification…"
          : status === "verified"
            ? es
              ? "Verificado. Elige Google o GitHub."
              : "Verified. Choose Google or GitHub."
            : status === "error"
              ? es
                ? "No se pudo cargar la verificación. Vuelve a intentarlo."
                : "Verification could not load. Try again."
              : status === "expired"
                ? es
                  ? "La verificación venció. Verifica de nuevo."
                  : "Verification expired. Verify again."
                : ""}
      </p>
    </section>
  );
}
