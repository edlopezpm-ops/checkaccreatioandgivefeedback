import { useRef, type ReactNode } from "react";
import { Globe, Moon, Sun } from "lucide-react";
import type { Locale, Settings } from "../types";
import { AekrSignature } from "./AekrSignature";
import { FormationMark } from "./FormationMark";
import { Atmosphere, type AtmosphereVariant } from "./Atmosphere";
import { StatusNotice, type StatusTone } from "./StatusNotice";
import { useSectionTransition } from "./useSectionTransition";

export type BuiltInAppDestination =
  "new" | "orchestrationCenter" | "settings" | "history" | "about";

// Web-only surfaces can contribute a destination without making their module
// part of the shared renderer graph used by Electron.
export type AppDestination = BuiltInAppDestination | (string & {});

export interface AppNavigationItem {
  id: AppDestination;
  label: string;
}

interface AppFrameProps {
  children: ReactNode;
  wrapContent?: (children: ReactNode) => ReactNode;
  currentDestination: AppDestination;
  locale: Locale;
  navigation: readonly AppNavigationItem[];
  newProjectAccessory?: ReactNode;
  atmosphere: AtmosphereVariant;
  onBrandActivate: () => void;
  onDestinationChange: (destination: AppDestination) => void;
  onLocaleToggle: () => void;
  onThemeToggle: () => void;
  status: { detail?: string; label: string; tone?: StatusTone };
  tagline: string;
  theme: Settings["theme"];
  hideThemeToggle?: boolean;
  webFooter?: boolean;
  transitionKey?: string | number;
  floatingDestinationOpen?: string;
}

export function AppFrame({
  children,
  wrapContent,
  currentDestination,
  locale,
  navigation,
  newProjectAccessory,
  atmosphere,
  onBrandActivate,
  onDestinationChange,
  onLocaleToggle,
  onThemeToggle,
  status,
  tagline,
  theme,
  hideThemeToggle = false,
  webFooter = false,
  transitionKey,
  floatingDestinationOpen,
}: AppFrameProps) {
  const contentRef = useRef<HTMLDivElement>(null);
  useSectionTransition(contentRef, transitionKey, webFooter);
  const showStatus = !webFooter || (status.tone && status.tone !== "neutral");

  return (
    <div className={`app-shell${webFooter ? " app-shell--web" : ""}`}>
      <a className="skip-link" href="#app-content">
        {locale === "es" ? "Ir al contenido" : "Skip to content"}
      </a>
      <Atmosphere theme={theme} variant={atmosphere} />
      <header
        className={`app-header${showStatus ? " app-header--with-status" : ""}`}
      >
        <FormationMark
          homeLabel={
            locale === "es"
              ? "Ir al inicio de accreatio"
              : "Go to accreatio home"
          }
          tagline={tagline}
          onActivate={onBrandActivate}
        />
        <nav
          className="product-nav"
          aria-label={locale === "es" ? "Producto" : "Product"}
        >
          {navigation.map((item) => {
            const button = (
              <button
                type="button"
                key={item.id}
                className={currentDestination === item.id ? "active" : ""}
                aria-current={
                  currentDestination === item.id ? "page" : undefined
                }
                aria-haspopup={
                  webFooter && item.id === "about" ? "dialog" : undefined
                }
                aria-expanded={
                  webFooter && item.id === "about"
                    ? floatingDestinationOpen === "about"
                    : undefined
                }
                aria-controls={
                  webFooter && item.id === "about" ? "about-popover" : undefined
                }
                onClick={() => onDestinationChange(item.id)}
              >
                {item.label}
              </button>
            );
            return item.id === "new" && newProjectAccessory ? (
              <div className="product-nav__project-group" key={item.id}>
                {button}
                {newProjectAccessory}
              </div>
            ) : (
              button
            );
          })}
        </nav>
        <div className="header-actions">
          <button
            type="button"
            className="language-toggle"
            title={locale === "es" ? "Cambiar a inglés" : "Switch to Spanish"}
            aria-label={
              locale === "es" ? "Cambiar a inglés" : "Switch to Spanish"
            }
            onClick={onLocaleToggle}
          >
            <Globe aria-hidden="true" />
            <span>{locale === "es" ? "ES" : "EN"}</span>
          </button>
          {!hideThemeToggle && (
            <button
              type="button"
              aria-label={
                theme === "dark"
                  ? locale === "es"
                    ? "Cambiar a tema claro"
                    : "Switch to light theme"
                  : locale === "es"
                    ? "Cambiar a tema oscuro"
                    : "Switch to dark theme"
              }
              onClick={onThemeToggle}
            >
              {theme === "dark" ? (
                <Sun aria-hidden="true" />
              ) : (
                <Moon aria-hidden="true" />
              )}
            </button>
          )}
        </div>
        {showStatus && <StatusNotice {...status} />}
      </header>
      <div
        id="app-content"
        className="app-content"
        ref={contentRef}
        tabIndex={-1}
      >
        {wrapContent ? wrapContent(children) : children}
      </div>
      <AekrSignature webLinks={webFooter} locale={locale} />
    </div>
  );
}
