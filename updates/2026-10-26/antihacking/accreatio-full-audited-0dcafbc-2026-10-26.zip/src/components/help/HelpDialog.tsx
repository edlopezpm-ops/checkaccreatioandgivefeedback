import { useEffect, useRef } from "react";
import { X } from "lucide-react";
import type { Locale } from "../../types";
import { HelpTips, type HelpTopic } from "./HelpTips";
import "./HelpSurfaces.css";

export function HelpDialog({
  locale,
  topic,
  full = false,
  mode = "help",
  onClose,
}: {
  locale: Locale;
  topic?: HelpTopic;
  full?: boolean;
  mode?: "help" | "example";
  onClose(): void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const id = mode === "example" ? "example-guide" : "project-help";
  useEffect(() => {
    const surface = dialog.current!;
    const trigger = document.activeElement as HTMLElement | null;
    surface.showModal();
    return () => {
      surface.close();
      if (trigger?.isConnected) trigger.focus({ preventScroll: true });
    };
  }, []);
  return (
    <dialog
      ref={dialog}
      id={id}
      className={`help-dialog${mode === "example" ? " help-dialog--example" : ""}`}
      aria-labelledby={`${id}-title`}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          const bounds = event.currentTarget.getBoundingClientRect();
          if (
            event.clientX < bounds.left ||
            event.clientX > bounds.right ||
            event.clientY < bounds.top ||
            event.clientY > bounds.bottom
          )
            onClose();
        }
      }}
    >
      <header className="help-surface__header">
        <h2 id={`${id}-title`}>
          {mode === "example"
            ? locale === "es"
              ? "Cómo funciona accreatio"
              : "How accreatio works"
            : locale === "es"
              ? "Ayuda paso a paso"
              : "Step-by-step help"}
        </h2>
        <button
          type="button"
          onClick={onClose}
          aria-label={
            mode === "example"
              ? locale === "es"
                ? "Cerrar ejemplo"
                : "Close example"
              : locale === "es"
                ? "Cerrar ayuda"
                : "Close help"
          }
        >
          <X aria-hidden="true" />
        </button>
      </header>
      <HelpTips
        key={`${locale}-${topic}`}
        locale={locale}
        topic={topic}
        full={full}
      />
    </dialog>
  );
}
