import { useEffect, useId, useState } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import type { Locale } from "../../types";
import { helpTipsForTopic, type HelpTopic } from "./helpContent";
import "./helpTips.css";

export type { HelpTopic } from "./helpContent";

export function HelpTips({
  locale,
  topic,
  full = false,
}: {
  locale: Locale;
  topic?: HelpTopic;
  full?: boolean;
}) {
  const es = locale === "es";
  const [index, setIndex] = useState(0);
  const id = useId();
  const tips = helpTipsForTopic(topic, full);
  useEffect(() => setIndex(0), [topic, full]);
  const position = Math.min(index, tips.length - 1);
  const tip = tips[position];
  if (!tip) return null;
  return (
    <section
      className="help-tips"
      aria-roledescription={es ? "guía paso a paso" : "step-by-step guide"}
      aria-label={es ? "Cómo usar accreatio" : "How to use accreatio"}
    >
      <figure className="help-tips__slide" id={id}>
        <div className="help-tips__visual">
          <button
            type="button"
            className="help-tips__arrow help-tips__arrow--previous"
            disabled={position === 0}
            aria-label={es ? "Tip anterior" : "Previous tip"}
            aria-controls={id}
            onClick={() => setIndex(position - 1)}
          >
            <ArrowLeft aria-hidden="true" />
          </button>
          <img
            className="help-tips__image"
            key={`${locale}-${tip.id}`}
            src={`/help/${locale}/${tip.id}.jpg`}
            width={3840}
            height={2160}
            alt={`${tip.title[locale]}. ${es ? "Captura ilustrativa de accreatio con datos de ejemplo." : "Illustrative accreatio screenshot with example data."}`}
            loading="lazy"
            decoding="async"
          />
          <button
            type="button"
            className="help-tips__arrow help-tips__arrow--next"
            disabled={position === tips.length - 1}
            aria-label={es ? "Siguiente tip" : "Next tip"}
            aria-controls={id}
            onClick={() => setIndex(position + 1)}
          >
            <ArrowRight aria-hidden="true" />
          </button>
        </div>
        <figcaption>
          <p
            className="help-tips__position"
            aria-live="polite"
            aria-atomic="true"
          >
            {es
              ? `Tip ${position + 1} de ${tips.length}`
              : `Tip ${position + 1} of ${tips.length}`}
          </p>
          <h3>{tip.title[locale]}</h3>
          <p>{tip.instruction[locale]}</p>
          <p className="help-tips__detail">{tip.detail[locale]}</p>
        </figcaption>
      </figure>
    </section>
  );
}
