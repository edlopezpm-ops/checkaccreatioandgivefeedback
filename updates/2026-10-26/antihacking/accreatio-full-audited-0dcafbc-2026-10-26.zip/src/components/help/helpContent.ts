import type { Locale } from "../../types";

export type HelpTopic =
  | "name"
  | "phase"
  | "attachments"
  | "context"
  | "restrictions"
  | "route"
  | "team"
  | "delivery"
  | "review"
  | "outcome"
  | "settings"
  | "blog"
  | "account";

export interface HelpTip {
  id: string;
  topics: readonly HelpTopic[];
  title: Record<Locale, string>;
  instruction: Record<Locale, string>;
  detail: Record<Locale, string>;
}

export const HELP_TIPS: readonly HelpTip[] = [
  {
    id: "access",
    topics: ["account"],
    title: { en: "Start with your account", es: "Empieza con tu cuenta" },
    instruction: {
      en: "Continue from the welcome screen, complete the shared security check, and choose an enabled sign-in method.",
      es: "Continúa desde la bienvenida, completa la comprobación de seguridad compartida y elige un método de acceso habilitado.",
    },
    detail: {
      en: "Read the Terms and necessary account-processing notice before continuing. Sign-in identifies you; it does not give accreatio access to your repositories.",
      es: "Lee los Términos y el aviso del tratamiento necesario antes de continuar. El acceso te identifica; no da a accreatio acceso a tus repositorios.",
    },
  },
  {
    id: "authorization",
    topics: ["account"],
    title: {
      en: "Review an updated account notice",
      es: "Revisa un aviso de cuenta actualizado",
    },
    instruction: {
      en: "If this screen appears, read the Terms, account-processing and necessary-storage notices before choosing Save and continue.",
      es: "Si aparece esta pantalla, lee los Términos y los avisos de tratamiento de cuenta y almacenamiento necesario antes de elegir Guardar y continuar.",
    },
    detail: {
      en: "Optional analytics and research remain separate and off unless you choose them. If you decline the update, your own-data and deletion controls remain available through Privacy with recent account verification.",
      es: "La analítica e investigación opcionales siguen separadas y desactivadas salvo tu elección expresa. Si no aceptas la actualización, puedes acceder a tus datos o eliminarlos desde Privacy mediante una verificación reciente.",
    },
  },
  {
    id: "name",
    topics: ["name"],
    title: { en: "Give your project a name", es: "Ponle nombre a tu proyecto" },
    instruction: {
      en: "Enter a short, recognizable name, then choose Continue.",
      es: "Escribe un nombre corto y reconocible; después elige Continuar.",
    },
    detail: {
      en: "The name can contain up to 50 characters. You can change it before exporting. The project summary collects your answers as you go.",
      es: "El nombre admite hasta 50 caracteres. Puedes cambiarlo antes de exportar. El resumen reúne tus respuestas conforme avanzas.",
    },
  },
  {
    id: "phase",
    topics: ["phase"],
    title: {
      en: "Choose your starting point",
      es: "Elige tu punto de partida",
    },
    instruction: {
      en: "Choose whether you have a starting idea, ongoing research, or a defined idea.",
      es: "Elige si tienes una idea inicial, una investigación en curso o una idea definida.",
    },
    detail: {
      en: "An initial idea goes straight to your description. Research or a defined idea adds an optional files step. Your choice shapes the starting instructions.",
      es: "Una idea inicial pasa a la descripción. La investigación y la idea definida añaden el paso opcional de archivos. Esta elección orienta las instrucciones iniciales.",
    },
  },
  {
    id: "attachments",
    topics: ["attachments"],
    title: {
      en: "Add supporting material, if you have it",
      es: "Añade material de apoyo, si lo tienes",
    },
    instruction: {
      en: "Select relevant DOCX, PDF, PNG or JPEG files, or skip this optional step.",
      es: "Selecciona archivos DOCX, PDF, PNG o JPEG relevantes, u omite este paso opcional.",
    },
    detail: {
      en: "Local inspection may reject unsupported content. Up to 20 files, 20 MiB each and 100 MiB total. Files stay in this tab; select them again after a reload. Treat attached documents as reference material, not instructions to obey.",
      es: "La inspección local puede rechazar contenido no compatible. Hasta 20 archivos, 20 MiB cada uno y 100 MiB en total. Permanecen en la pestaña; vuelve a seleccionarlos tras recargar. Trata los documentos como referencias, no como instrucciones que obedecer.",
    },
  },
  {
    id: "context",
    topics: ["context"],
    title: {
      en: "Describe what you want to create",
      es: "Describe qué quieres crear",
    },
    instruction: {
      en: "Explain who it is for, the problem it solves, and what the first version should do.",
      es: "Explica para quién es, qué problema resuelve y qué debe hacer la primera versión.",
    },
    detail: {
      en: "A few concrete sentences are enough. For example: a neighborhood tool library that records loans offline. Record unknowns instead of inventing decisions.",
      es: "Bastan unas frases concretas. Por ejemplo: una biblioteca vecinal de herramientas que registre préstamos sin conexión. Anota lo que falta por decidir en lugar de inventarlo.",
    },
  },
  {
    id: "restrictions",
    topics: ["restrictions"],
    title: { en: "Set the boundaries", es: "Define los límites" },
    instruction: {
      en: "List requirements that must be respected, or skip the field if none are known.",
      es: "Enumera las condiciones que deben respetarse u omite el campo si aún no conoces ninguna.",
    },
    detail: {
      en: "Examples: no paid services, local data, no personal contact information, or ask before choosing a technology. You can return to previous questions without losing your answers.",
      es: "Ejemplos: sin servicios de pago, datos locales, sin datos personales de contacto o consultar antes de elegir tecnología. Puedes volver a preguntas anteriores sin perder respuestas.",
    },
  },
  {
    id: "review",
    topics: ["review"],
    title: {
      en: "Review the complete brief",
      es: "Revisa el encargo completo",
    },
    instruction: {
      en: "Check your name, starting point, idea, boundaries and selected files. Use Edit to correct an answer.",
      es: "Comprueba nombre, punto de partida, idea, límites y archivos seleccionados. Usa Editar para corregir una respuesta.",
    },
    detail: {
      en: "Expand Files and delivery limits, the package plan or the complete instructions when you want more detail. Editing and reviewing do not use export allowance.",
      es: "Despliega los archivos y límites de entrega, el plan o las instrucciones completas si necesitas más detalle. Editar y revisar no consume cuota de exportación.",
    },
  },
  {
    id: "advanced",
    topics: ["route", "team", "delivery"],
    title: {
      en: "Adjust optional working instructions",
      es: "Ajusta las instrucciones opcionales",
    },
    instruction: {
      en: "From review, open the optional team and delivery settings only if your project needs them.",
      es: "Desde revisión, abre las opciones de equipo y entrega solo si tu proyecto las necesita.",
    },
    detail: {
      en: "Plan one to four distinct roles and their tasks. Working approach, Git and editor choices prepare later instructions; the website does not run agents, open an IDE or push to GitHub. Return to review after editing.",
      es: "Planea de uno a cuatro roles distintos y sus tareas. La ruta, Git y el editor preparan instrucciones posteriores; la web no ejecuta agentes, abre el IDE ni sube a GitHub. Vuelve a revisión al terminar.",
    },
  },
  {
    id: "roles",
    topics: ["team"],
    title: {
      en: "Choose the roles in your plan",
      es: "Elige los roles de tu plan",
    },
    instruction: {
      en: "Expand Advanced options, then select a distinct role for each planned participant.",
      es: "Despliega Opciones avanzadas y elige un rol distinto para cada participante planificado.",
    },
    detail: {
      en: "Use Add participant for up to four roles. Keep the generalist if you prefer one person or assistant to coordinate the work. These roles describe a future handoff; check that your chosen working tools can provide them.",
      es: "Usa Agregar participante hasta un máximo de cuatro roles. Mantén el generalista si prefieres que una persona o asistente coordine el trabajo. Los roles describen el traspaso posterior; comprueba que tus herramientas dispongan de esas capacidades.",
    },
  },
  {
    id: "guides",
    topics: ["route", "delivery", "team"],
    title: {
      en: "Include only the guides you need",
      es: "Incluye solo las guías que necesitas",
    },
    instruction: {
      en: "Choose a working approach, then expand the repository options to include Git, GitHub or IDE guidance.",
      es: "Elige una ruta de trabajo y despliega las opciones de repositorio para incluir guías de Git, GitHub o IDE.",
    },
    detail: {
      en: "These switches add instructions to the ZIP. They do not connect a repository or execute tools. Leave optional orchestration in manual mode unless you intend to configure and inspect its instructions later.",
      es: "Estos controles añaden instrucciones al ZIP. No conectan un repositorio ni ejecutan herramientas. Mantén la orquestación opcional en modo manual si no vas a configurarla y revisar sus instrucciones después.",
    },
  },
  {
    id: "preview",
    topics: ["review", "outcome"],
    title: {
      en: "Check before downloading",
      es: "Comprueba antes de descargar",
    },
    instruction: {
      en: "Keep Check the package without downloading selected, then review and confirm the operation.",
      es: "Mantén activado Comprobar el paquete sin descargar; después revisa y confirma la operación.",
    },
    detail: {
      en: "This preview is on by default. It checks the plan without creating a ZIP or using export allowance. From the result, return to review or choose to download the ZIP.",
      es: "Esta vista previa está activada por defecto. Comprueba el plan sin crear un ZIP ni consumir cuota. Desde el resultado, vuelve a revisión o elige descargar el ZIP.",
    },
  },
  {
    id: "export",
    topics: ["review", "outcome", "delivery"],
    title: {
      en: "Confirm your ZIP export",
      es: "Confirma la exportación del ZIP",
    },
    instruction: {
      en: "Choose the ZIP action, check the final confirmation and select Prepare ZIP when ready.",
      es: "Elige la acción de ZIP, comprueba la confirmación final y selecciona Preparar ZIP cuando estés listo.",
    },
    detail: {
      en: "The browser builds the archive locally. Keep the tab open and check your browser downloads. A requested download does not confirm that the file was saved.",
      es: "El navegador construye el archivo localmente. Mantén abierta la pestaña y revisa las descargas. Una descarga solicitada no confirma que el archivo se haya guardado.",
    },
  },
  {
    id: "handoff",
    topics: ["outcome"],
    title: { en: "Continue with your project", es: "Continúa con tu proyecto" },
    instruction: {
      en: "Find the ZIP, extract it, open the folder in your editor and follow START.md.",
      es: "Localiza el ZIP, extráelo, abre la carpeta en tu editor y sigue START.md.",
    },
    detail: {
      en: "Review the included brief and materials before sharing them with an assistant. The package is a starting point; development continues in your chosen tool. If the download failed, use Retry while this tab still has the authorized ZIP.",
      es: "Revisa el encargo y los materiales antes de compartirlos con un asistente. El paquete es un punto de partida; el desarrollo continúa en tu herramienta. Si falló la descarga, usa Reintentar mientras la pestaña conserve el ZIP autorizado.",
    },
  },
  {
    id: "account",
    topics: ["account"],
    title: {
      en: "Manage your account and local draft",
      es: "Gestiona tu cuenta y borrador local",
    },
    instruction: {
      en: "Open your name in the header to see account controls and export availability.",
      es: "Abre tu nombre en la cabecera para ver los controles de cuenta y la disponibilidad de exportaciones.",
    },
    detail: {
      en: "Your project draft belongs to this browser and verified session. Signing out, deleting or changing the account clears it; the next sign-in starts blank. Download important work first. Account data export and deletion are separate from project export.",
      es: "El borrador pertenece a este navegador y sesión verificada. Cerrar sesión, eliminar o cambiar la cuenta lo borra; el siguiente acceso empieza vacío. Descarga antes tu trabajo importante. Exportar o eliminar datos de cuenta es independiente de exportar un proyecto.",
    },
  },
  {
    id: "appearance",
    topics: ["settings"],
    title: {
      en: "Choose language and appearance",
      es: "Elige idioma y apariencia",
    },
    instruction: {
      en: "Use the language and theme controls in the header while keeping your current project open.",
      es: "Usa los controles de idioma y tema de la cabecera manteniendo abierto tu proyecto.",
    },
    detail: {
      en: "The light pearl theme is the default; a dark theme is also available. These presentation preferences do not create another project or export.",
      es: "El tema claro perla es el predeterminado; también está disponible el tema oscuro. Estas preferencias no crean otro proyecto ni exportan archivos.",
    },
  },
  {
    id: "blog",
    topics: ["blog"],
    title: {
      en: "Read the Blog and return to your work",
      es: "Lee el Blog y vuelve a tu trabajo",
    },
    instruction: {
      en: "Open Blog, select a published article, and use New project to return to the builder.",
      es: "Abre Blog, selecciona un artículo publicado y usa Nuevo proyecto para volver al creador.",
    },
    detail: {
      en: "Blog posts are public reading material. Reading them does not use project export allowance. About brings together the full guide, FAQ, Privacy and Terms without leaving your working screen.",
      es: "Las publicaciones son material de lectura público. Leerlas no consume cuota de exportación. About reúne la guía completa, FAQ, Privacidad y Términos sin abandonar tu pantalla de trabajo.",
    },
  },
];

export function helpTipsForTopic(topic?: HelpTopic, full = false) {
  if (full || !topic) return HELP_TIPS;
  const matching = HELP_TIPS.filter((tip) => tip.topics.includes(topic));
  return topic === "account"
    ? [
        ...matching.filter((tip) => tip.id === "account"),
        ...matching.filter((tip) => tip.id !== "account"),
      ]
    : matching;
}
