import { useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import type { Locale } from "../../types";
import { legalHref, termsHref } from "../../legal";
import { FormationMark } from "../FormationMark";
import {
  WebProjectInformation,
  type PublicSignInProvider,
} from "../WebProjectInformation";
import { HelpTips } from "./HelpTips";
import "./HelpSurfaces.css";

export type AboutSection = "info" | "faq" | "help";

export function AboutPopover({
  locale,
  authenticated,
  initialSection = "info",
  enabledSignInProviders,
  onClose,
}: {
  locale: Locale;
  authenticated: boolean;
  initialSection?: AboutSection;
  enabledSignInProviders: readonly PublicSignInProvider[];
  onClose(): void;
}) {
  const es = locale === "es";
  const [section, setSection] = useState<AboutSection>(initialSection);
  const surface = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const panel = surface.current!;
    const trigger = document.activeElement as HTMLElement | null;
    const dismiss = (event: Event) => {
      if ((event as ToggleEvent).newState === "closed") onClose();
    };
    panel.addEventListener("toggle", dismiss);
    panel.showPopover();
    panel.querySelector<HTMLButtonElement>("button")?.focus();
    return () => {
      panel.removeEventListener("toggle", dismiss);
      panel.hidePopover();
      if (trigger?.isConnected) trigger.focus({ preventScroll: true });
    };
  }, [onClose]);
  const active = section === "help" && !authenticated ? "info" : section;
  return (
    <div
      ref={surface}
      id="about-popover"
      className="about-popover"
      popover="auto"
      role="dialog"
      aria-labelledby="about-popover-title"
    >
      <header className="help-surface__header">
        <h2 id="about-popover-title">
          {es ? "Acerca de accreatio" : "About accreatio"}
        </h2>
        <button
          type="button"
          onClick={onClose}
          aria-label={es ? "Cerrar About" : "Close About"}
        >
          <X aria-hidden="true" />
        </button>
      </header>
      <nav
        className="about-popover__sections"
        aria-label={es ? "Información de accreatio" : "accreatio information"}
      >
        {(
          ["info", "faq", ...(authenticated ? ["help"] : [])] as AboutSection[]
        ).map((id) => (
          <button
            key={id}
            type="button"
            aria-pressed={active === id}
            onClick={() => setSection(id)}
          >
            {id === "info"
              ? es
                ? "Acerca de"
                : "About"
              : id === "faq"
                ? "FAQ"
                : es
                  ? "Ayuda completa"
                  : "Full help"}
          </button>
        ))}
      </nav>
      <div className="about-popover__content">
        {active === "info" ? (
          <section className="about-popover__info">
            <FormationMark
              tagline={
                es
                  ? "De una idea a un inicio claro"
                  : "From an idea to a clear beginning"
              }
            />
            <p>
              {es
                ? "Describe tu idea, organiza tus límites y prepara un ZIP con el encargo y los archivos para continuar tu proyecto."
                : "Describe your idea, organize your boundaries, and prepare a ZIP with the brief and files to continue your project."}
            </p>
            <p>
              {es
                ? "La preparación ocurre en este navegador. No requiere un proveedor de IA ni envía el contenido de tu proyecto a accreatio. El acceso y la cuota utilizan un servicio de cuenta separado."
                : "Preparation happens in this browser. It requires no AI provider and sends no project content to accreatio. Sign-in and allowance use a separate account service."}
            </p>
            <p>
              {es
                ? "accreatio prepara el punto de partida; revisa los archivos antes de continuarlos en tu herramienta. Los roles describen trabajo futuro y requieren capacidades realmente disponibles."
                : "accreatio prepares the starting point; review the files before continuing in your tool. Roles describe future work and require capabilities that are actually available."}
            </p>
            <p>
              {es ? "Versión" : "Version"} {__APP_VERSION__}
            </p>
            <p>
              AEKR · 2026.{" "}
              {es
                ? "Todos los derechos reservados. La redistribución y reventa requieren permiso escrito."
                : "All rights reserved. Redistribution and resale require written permission."}
            </p>
            <a href="mailto:aekr@aekr.io">aekr@aekr.io</a>
          </section>
        ) : active === "faq" ? (
          <WebProjectInformation
            locale={locale}
            enabledSignInProviders={enabledSignInProviders}
            faqOnly
          />
        ) : (
          <HelpTips locale={locale} full />
        )}
      </div>
      <nav
        className="about-popover__legal"
        aria-label={es ? "Documentos legales" : "Legal documents"}
      >
        <a
          href={legalHref("privacy", locale)}
          target="_blank"
          rel="noopener noreferrer"
        >
          {es ? "privacidad" : "privacy"}
        </a>
        <a href={termsHref(locale)} target="_blank" rel="noopener noreferrer">
          {es ? "términos" : "terms"}
        </a>
        <a
          href={legalHref("cookies", locale)}
          target="_blank"
          rel="noopener noreferrer"
        >
          cookies
        </a>
      </nav>
    </div>
  );
}
