-- Deliberate prospective notice acknowledgement. Existing accounts stay pending.
-- Optional cookie consent remains separate; no authentication or visit backfill.
CREATE TABLE account_notice_acknowledgements (
  account_id TEXT PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
  cookies_notice_version TEXT NOT NULL,
  acknowledged_at INTEGER NOT NULL
);

CREATE TRIGGER accounts_purge_notice_acknowledgement_after_delete
AFTER UPDATE OF deleted_at ON accounts
WHEN NEW.deleted_at IS NOT NULL
BEGIN
  DELETE FROM account_notice_acknowledgements WHERE account_id=NEW.id;
END;
