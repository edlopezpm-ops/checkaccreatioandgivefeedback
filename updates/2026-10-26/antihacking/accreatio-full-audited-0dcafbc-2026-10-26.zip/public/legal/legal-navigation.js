(() => {
  const current = new URL(window.location.href);
  const requested = current.searchParams.get("lang");
  const locale =
    requested === "es" || requested === "en"
      ? requested
      : document.documentElement.lang === "es"
        ? "es"
        : "en";
  document.addEventListener("DOMContentLoaded", () => {
    for (const link of document.querySelectorAll("a[href]")) {
      const target = new URL(link.href, current);
      if (target.origin !== current.origin) continue;
      const terms = /^\/legal\/terms(?:-es)?(?:\.html)?$/u.test(
        target.pathname,
      );
      const information = /^\/legal\/(?:privacy|cookies|faq)(?:\.html)?$/u.test(
        target.pathname,
      );
      if (terms || information || target.pathname === "/") {
        if (terms)
          target.pathname = `/legal/terms${locale === "es" ? "-es" : ""}.html`;
        target.searchParams.set("lang", locale);
        link.href = target.pathname + target.search + target.hash;
      }
    }
  });
})();
