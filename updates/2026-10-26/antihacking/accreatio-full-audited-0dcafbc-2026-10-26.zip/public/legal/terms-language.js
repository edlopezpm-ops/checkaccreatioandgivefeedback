(() => {
  const current = new URL(window.location.href);
  const ownLocale = document.documentElement.lang === "es" ? "es" : "en";
  const requested = current.searchParams.get("lang");
  const locale =
    requested === "es" || requested === "en" ? requested : ownLocale;
  if (locale !== ownLocale) {
    document.documentElement.hidden = true;
    const target = new URL(
      locale === "es" ? "terms-es.html" : "terms.html",
      current,
    );
    target.searchParams.set("lang", locale);
    window.location.replace(target.pathname + target.search);
  }
})();
