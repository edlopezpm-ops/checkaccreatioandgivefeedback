import {
  ACCOUNT_POLICY,
  ACCOUNT_COOKIES_NOTICE_VERSION,
  type AccountPolicyContinuation,
  type AccountPolicyAuthorization,
} from "../../../shared/accountPolicy";
import { ApiError } from "../http";
import type { AccountDatabase } from "../accounts";

export { ACCOUNT_POLICY };

const FIELDS = [
  "privacyNoticeVersion",
  "termsVersion",
  "purposeVersion",
  "accountDataAuthorized",
  "termsAccepted",
] as const;

export function requirePolicyAuthorization(
  input: unknown,
): AccountPolicyAuthorization {
  if (
    !input ||
    typeof input !== "object" ||
    Array.isArray(input) ||
    Object.keys(input).length !== FIELDS.length ||
    !FIELDS.every((key) => Object.hasOwn(input, key))
  )
    throw new ApiError(
      400,
      "invalid_policy_authorization",
      "Review the account information and terms before continuing.",
    );
  const value = input as Record<string, unknown>;
  if (
    value.privacyNoticeVersion !== ACCOUNT_POLICY.privacyNoticeVersion ||
    value.termsVersion !== ACCOUNT_POLICY.termsVersion ||
    value.purposeVersion !== ACCOUNT_POLICY.purposeVersion
  )
    throw new ApiError(
      409,
      "policy_authorization_outdated",
      "The account information changed. Reload and review it before continuing.",
    );
  if (value.accountDataAuthorized !== true || value.termsAccepted !== true)
    throw new ApiError(
      403,
      "policy_authorization_required",
      "Authorize the necessary account processing and accept the terms to continue.",
    );
  return {
    ...ACCOUNT_POLICY,
    accountDataAuthorized: true,
    termsAccepted: true,
  };
}

// Only fixed application policy literals enter this SQL fragment. No request
// values, account identifiers or user-authored text are interpolated into SQL.
export const CURRENT_POLICY_SQL = `privacy_notice_version='${ACCOUNT_POLICY.privacyNoticeVersion}' AND terms_version='${ACCOUNT_POLICY.termsVersion}' AND purpose_version='${ACCOUNT_POLICY.purposeVersion}' AND EXISTS(SELECT 1 FROM account_notice_acknowledgements n WHERE n.account_id=account_policy_authorizations.account_id AND n.cookies_notice_version='${ACCOUNT_COOKIES_NOTICE_VERSION}')`;
export const TRANSACTION_POLICY_SQL = `policy_privacy_notice_version='${ACCOUNT_POLICY.privacyNoticeVersion}' AND policy_terms_version='${ACCOUNT_POLICY.termsVersion}' AND policy_purpose_version='${ACCOUNT_POLICY.purposeVersion}' AND policy_authorized_at IS NOT NULL`;
export const CLEAR_TRANSACTION_POLICY_SQL =
  "policy_privacy_notice_version=NULL,policy_terms_version=NULL,policy_purpose_version=NULL,policy_authorized_at=NULL";
export const POLICY_RECEIPT_COLUMNS =
  "privacy_notice_version,terms_version,purpose_version,authorized_at";
export const POLICY_UPSERT_SQL = `ON CONFLICT(account_id) DO UPDATE SET privacy_notice_version=excluded.privacy_notice_version,terms_version=excluded.terms_version,purpose_version=excluded.purpose_version,authorized_at=excluded.authorized_at
  WHERE account_policy_authorizations.privacy_notice_version!=excluded.privacy_notice_version OR account_policy_authorizations.terms_version!=excluded.terms_version OR account_policy_authorizations.purpose_version!=excluded.purpose_version`;

export interface PolicyReceiptRow {
  privacy_notice_version: string;
  terms_version: string;
  purpose_version: string;
  authorized_at: number;
}

export function policyReceipt(row: PolicyReceiptRow | undefined | null) {
  return row
    ? {
        privacyNoticeVersion: row.privacy_notice_version,
        termsVersion: row.terms_version,
        purposeVersion: row.purpose_version,
        accountDataAuthorized: true,
        termsAccepted: true,
        authorizedAt: new Date(row.authorized_at).toISOString(),
      }
    : null;
}

export async function hasCurrentPolicyAuthorization(
  db: AccountDatabase,
  accountId: string,
) {
  return !!(await db
    .prepare(
      `SELECT account_id FROM account_policy_authorizations WHERE account_id=? AND ${CURRENT_POLICY_SQL}`,
    )
    .bind(accountId)
    .first());
}

export function requirePolicyContinuation(
  input: unknown,
): AccountPolicyContinuation {
  if (
    !input ||
    typeof input !== "object" ||
    Array.isArray(input) ||
    Object.keys(input).length !== FIELDS.length + 2
  )
    throw new ApiError(
      400,
      "invalid_policy_authorization",
      "Review the account notices before continuing.",
    );
  const { cookiesNoticeVersion, cookiesNoticeAcknowledged, ...authorization } =
    input as Record<string, unknown>;
  const policy = requirePolicyAuthorization(authorization);
  if (cookiesNoticeVersion !== ACCOUNT_COOKIES_NOTICE_VERSION)
    throw new ApiError(
      409,
      "policy_authorization_outdated",
      "The cookies notice changed. Reload and review it.",
    );
  if (cookiesNoticeAcknowledged !== true)
    throw new ApiError(
      403,
      "policy_authorization_required",
      "Acknowledge the cookies notice to continue.",
    );
  return {
    ...policy,
    cookiesNoticeVersion: ACCOUNT_COOKIES_NOTICE_VERSION,
    cookiesNoticeAcknowledged: true,
  };
}
