import type { AccountBindings } from "../accounts";
import { ApiError } from "../http";
import type { RuntimeDependencies } from "../platform";

export const LOGIN_CAPTCHA_ACTION = "login";
const SITEVERIFY = "https://challenges.cloudflare.com/turnstile/v0/siteverify";

export function loginCaptchaConfiguration(
  env: AccountBindings,
  request: Request,
) {
  if (env.ACCOUNT_CAPTCHA_ENABLED !== "true") return null;
  const hostnames = (env.TURNSTILE_HOSTNAMES ?? "")
    .split(",")
    .map((host) => host.trim());
  if (
    !env.TURNSTILE_SITE_KEY ||
    !/^[A-Za-z0-9_-]{3,128}$/.test(env.TURNSTILE_SITE_KEY) ||
    !env.TURNSTILE_SECRET ||
    !/^\S{10,256}$/.test(env.TURNSTILE_SECRET) ||
    hostnames.length === 0 ||
    hostnames.some((host) => !/^[a-z0-9]+(?:[.-][a-z0-9]+)*$/.test(host)) ||
    !hostnames.includes(new URL(request.url).hostname)
  )
    throw new ApiError(
      503,
      "captcha_unavailable",
      "Verification is temporarily unavailable. Please try again.",
    );
  return {
    siteKey: env.TURNSTILE_SITE_KEY,
    secret: env.TURNSTILE_SECRET,
    hostnames,
  };
}

export async function verifyLoginCaptcha(
  env: AccountBindings,
  request: Request,
  token: unknown,
  dependencies: RuntimeDependencies,
) {
  const settings = loginCaptchaConfiguration(env, request);
  if (!settings) return;
  if (
    typeof token !== "string" ||
    !token ||
    token.length > 2048 ||
    /\s/.test(token)
  )
    throw new ApiError(
      403,
      "captcha_required",
      "Complete the shared verification before continuing.",
    );
  let result: Record<string, unknown>;
  try {
    const response = await dependencies.fetch(SITEVERIFY, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ secret: settings.secret, response: token }),
      redirect: "manual",
      signal: AbortSignal.timeout(10_000),
    });
    if (
      !response.ok ||
      !response.headers.get("Content-Type")?.includes("application/json")
    ) {
      await response.body?.cancel();
      throw new Error("verification_unavailable");
    }
    const value: unknown = await readBoundedResponse(response);
    if (!value || typeof value !== "object" || Array.isArray(value))
      throw new Error("invalid_verification");
    result = value as Record<string, unknown>;
  } catch {
    throw new ApiError(
      503,
      "captcha_unavailable",
      "Verification is temporarily unavailable. Please try again.",
    );
  }
  if (
    result.success !== true ||
    result.action !== LOGIN_CAPTCHA_ACTION ||
    result.hostname !== new URL(request.url).hostname ||
    !settings.hostnames.includes(String(result.hostname))
  )
    throw new ApiError(
      403,
      "captcha_invalid",
      "Verification expired or could not be confirmed. Verify again before continuing.",
    );
}

async function readBoundedResponse(response: Response): Promise<unknown> {
  if (!response.body) throw new Error("empty_verification");
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let size = 0;
  while (true) {
    const part = await reader.read();
    if (part.done) break;
    size += part.value.byteLength;
    if (size > 16_384) {
      await reader.cancel();
      throw new Error("verification_too_large");
    }
    chunks.push(part.value);
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
}
