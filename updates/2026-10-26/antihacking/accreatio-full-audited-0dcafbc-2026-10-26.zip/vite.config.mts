import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import { VitePWA } from "vite-plugin-pwa";

const pkg = JSON.parse(
  readFileSync(
    fileURLToPath(new URL("./package.json", import.meta.url)),
    "utf8",
  ),
);

export default defineConfig(({ mode }) => {
  const desktop = mode === "desktop";
  return {
    cacheDir: ".local/cache/vite",
    plugins: [
      react(),
      !desktop &&
        VitePWA({
          // manifest.webmanifest is hand-authored and already linked from
          // index.html; reuse it instead of generating a second manifest.
          manifest: false,
          injectRegister: null,
          registerType: "prompt",
          workbox: {
            // Legacy clients only reload from their update prompt. Activate
            // here so they cannot keep reloading the same obsolete app shell.
            skipWaiting: true,
            clientsClaim: false,
            globPatterns: ["**/*.{js,css,html,png,svg,webmanifest}"],
            // Full-resolution source crops and unused compatibility wordmarks
            // stay available without duplicating artwork in the PWA precache.
            globIgnores: [
              "branding/accreatio-lockup.png",
              "branding/accreatio-mark.png",
              "branding/accreatio-wordmark*",
              // Legal documents must revalidate through the network, including
              // document-only releases that do not install another worker.
              "legal/**/*.html",
            ],
            // Authentication, account downloads and legal navigation must reach
            // the network rather than receive the cached application shell.
            navigateFallbackDenylist: [
              /^\/api(?:\/|$)/,
              /^\/cdn-cgi(?:\/|$)/,
              /^\/legal(?:[/?]|$)/,
            ],
          },
        }),
    ].filter(Boolean),
    base: "./",
    publicDir: desktop ? false : "public",
    define: { __APP_VERSION__: JSON.stringify(pkg.version) },
    build: desktop
      ? {
          outDir: "dist-desktop",
          sourcemap: false,
          emptyOutDir: true,
          rollupOptions: { input: "desktop.html" },
        }
      : {
          outDir: "dist",
          sourcemap: false,
          emptyOutDir: true,
          rollupOptions: { input: "index.html" },
        },
  };
});
