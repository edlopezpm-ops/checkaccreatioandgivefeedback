import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { createServer } from "node:http";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { minimalDocx } from "./attachment-smoke-fixtures.mjs";
import { chromium } from "playwright";
import {
  createRightsTransaction,
  completeRightsAccess,
} from "../functions/_lib/auth/rights.ts";
import {
  harness,
  POLICY_AUTHORIZATION,
} from "../tests/helpers/accountHarness.ts";
import {
  continueQuestion,
  expectQuestion,
  finishGuidedQuestions,
} from "./guided-creation-functional-smoke.mjs";
import {
  assertPolicyNotice,
  assertClickwrapBeforeAction,
  rejectNonEssentialCookies,
  checkGoogleAccountUi,
} from "./google-account-functional-smoke.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const port = 4179;
const target = `http://127.0.0.1:${port}`;
const staticTarget = `http://127.0.0.1:${port - 1}`;
const output = path.join(root, ".local/logs", `account-ui-${Date.now()}`);
const blogPosts = JSON.parse(
  await readFile(path.join(root, "content/blog/founding-posts.json"), "utf8"),
).posts;
await mkdir(output, { recursive: true });
const server = spawn(
  process.execPath,
  [
    path.join(root, "node_modules/vite/bin/vite.js"),
    "preview",
    "--host",
    "127.0.0.1",
    "--port",
    String(port - 1),
    "--strictPort",
  ],
  { cwd: root, stdio: "ignore", windowsHide: true },
);
let browser;
let page;
let accountDiagnostics;
let activeFixture;

function installAccountRoutes(h, google = false) {
  const state = {
    blogReads: 0,
    requests: [],
    google,
    authRequests: [],
    authTransactions: new Map(),
    authStatusFailures: 0,
  };
  activeFixture = { h, state };
  accountDiagnostics = state;
  return state;
}

// Real HTTP, production handlers, D1-compatible SQLite and active service worker.
// Only the delivery transport is replaced with the harness mailbox; no email is sent.
const apiServer = createServer(async (request, response) => {
  const send = (status, body, headers = {}) => {
    response.writeHead(status, {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
      ...headers,
    });
    response.end(body);
  };
  try {
    const url = new URL(request.url, target);
    if (url.pathname === "/api/auth/v1/methods")
      return send(
        200,
        JSON.stringify({
          version: "auth.v1",
          methods: {
            google: { available: activeFixture.state.google },
            emailOtp: { available: !activeFixture.state.google },
          },
        }),
      );
    // UI transport fixture only. Production OIDC and browser binding have their
    // own backend integration suite; these routes never contact an identity provider.
    if (
      url.pathname === "/api/auth/v1/oidc/google/start" ||
      url.pathname === "/api/auth/v1/rights/google/start"
    ) {
      const chunks = [];
      for await (const chunk of request) chunks.push(chunk);
      const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      const accountAccess = body.purpose === "account_access";
      const rightsOnly = url.pathname.includes("/rights/");
      const expected = accountAccess
        ? [
            "mode",
            "purpose",
            "returnRoute",
            ...(body.verificationAction ? ["verificationAction"] : []),
            ...(rightsOnly ? ["rightsOnly"] : []),
          ]
        : ["mode", "policyAuthorization", "purpose", "returnRoute"];
      if (
        Object.keys(body).sort().join() !== expected.sort().join() ||
        !["sign_in", "account_access"].includes(body.purpose) ||
        !["popup", "redirect"].includes(body.mode) ||
        body.returnRoute !== "builder"
      )
        return send(
          400,
          JSON.stringify({ error: { code: "invalid_auth_request" } }),
        );
      if (
        accountAccess &&
        !["data", "delete", "link_google", "link_github"].includes(
          body.verificationAction,
        )
      )
        return send(
          400,
          JSON.stringify({ error: { code: "invalid_auth_request" } }),
        );
      let accountSession = null;
      if (accountAccess && !rightsOnly) {
        const session = await activeFixture.h.call("session", {
          method: "GET",
          cookie: request.headers.cookie,
        });
        if (session.status !== 200)
          return send(
            401,
            JSON.stringify({ error: { code: "sign_in_required" } }),
          );
        const cookie = request.headers.cookie?.match(
          /(?:^|;\s*)(__Host-accreatio_session=([a-f0-9]{64}))(?:;|$)/,
        );
        if (!cookie)
          return send(
            401,
            JSON.stringify({ error: { code: "sign_in_required" } }),
          );
        const tokenHash = createHash("sha256").update(cookie[2]).digest("hex");
        const row = activeFixture.h.db.sqlite
          .prepare("SELECT account_id FROM account_sessions WHERE token_hash=?")
          .get(tokenHash);
        if (!row)
          return send(
            401,
            JSON.stringify({ error: { code: "sign_in_required" } }),
          );
        accountSession = {
          tokenHash,
          accountId: row.account_id,
          cookie: cookie[1],
        };
      } else if (!rightsOnly) {
        try {
          assert.deepEqual(body.policyAuthorization, POLICY_AUTHORIZATION);
        } catch {
          return send(
            403,
            JSON.stringify({
              error: { code: "policy_authorization_required" },
            }),
          );
        }
      }
      const transactionId = crypto.randomUUID();
      if (rightsOnly) {
        assert.equal(body.rightsOnly, true);
        await createRightsTransaction(activeFixture.h.env.ACCOUNT_DB, {
          id: transactionId,
          purpose: "account_access",
          previousSessionTokenHash: null,
          verificationAction: body.verificationAction,
          provider: "google",
          rightsOnly: true,
          returnMode: "popup",
          stateHash: transactionId,
          browserHash: "synthetic-rights-browser",
          ipHash: "synthetic-rights-network",
          secretsCiphertext: "synthetic-provider-transport",
        });
      }
      activeFixture.state.authRequests.push(body);
      activeFixture.state.authTransactions.set(transactionId, {
        status: "pending",
        mode: body.mode,
        purpose: body.purpose,
        verificationAction: body.verificationAction,
        accountSession,
        rightsOnly,
      });
      return send(
        200,
        JSON.stringify({
          transactionId,
          authorizationUrl: `https://accounts.google.com/o/oauth2/v2/auth?state=${transactionId}`,
          expiresAt: new Date(Date.now() + 600_000).toISOString(),
        }),
      );
    }
    const authStatus = url.pathname.match(
      /^\/api\/auth\/v1\/transactions\/([\w-]+)\/(status|cancel)$/,
    );
    if (authStatus) {
      const state = activeFixture.state;
      const transaction = state.authTransactions.get(authStatus[1]);
      if (!transaction)
        return send(
          401,
          JSON.stringify({ error: { code: "sign_in_required" } }),
        );
      if (state.authStatusFailures > 0) {
        state.authStatusFailures--;
        return send(503, JSON.stringify({ error: { code: "unavailable" } }));
      }
      if (authStatus[2] === "cancel" && transaction.status === "pending")
        transaction.status = "failed";
      return send(200, JSON.stringify({ status: transaction.status }));
    }
    if (url.pathname === "/api/fixture/google/complete") {
      const transaction = activeFixture.state.authTransactions.get(
        url.searchParams.get("state"),
      );
      if (!transaction || transaction.status !== "pending")
        return send(409, "{}");
      let cookie;
      if (transaction.rightsOnly) {
        const claimNonce = crypto.randomUUID();
        const sessionToken = Buffer.from(
          crypto.getRandomValues(new Uint8Array(32)),
        ).toString("hex");
        activeFixture.h.db.sqlite
          .prepare(
            "UPDATE account_auth_transactions SET status='claimed',claim_nonce=? WHERE id=? AND status='created'",
          )
          .run(claimNonce, url.searchParams.get("state"));
        await completeRightsAccess(activeFixture.h.env.ACCOUNT_DB, {
          transactionId: url.searchParams.get("state"),
          claimNonce,
          sessionTokenHash: createHash("sha256")
            .update(sessionToken)
            .digest("hex"),
          identity: {
            issuer: "https://accounts.google.com",
            subject: "google-ui-fixture",
            email: null,
            emailVerified: false,
            hostedDomain: null,
            authoritativeEmail: false,
          },
        });
        cookie = `__Host-accreatio_rights=${sessionToken}`;
      } else if (transaction.purpose === "account_access") {
        const captured = transaction.accountSession;
        const session = await activeFixture.h.call("session", {
          method: "GET",
          cookie: captured.cookie,
        });
        if (session.status !== 200)
          return send(
            401,
            JSON.stringify({ error: { code: "sign_in_required" } }),
          );
        // Synthetic provider proof refreshes only the already captured session.
        // It must not use login(), create an account, update a profile or grant
        // policy authorization. Real OIDC identity binding is tested separately.
        const refreshed = activeFixture.h.db.sqlite
          .prepare(
            "UPDATE account_session_metadata SET authenticated_at=?,verification_action=? WHERE token_hash=? AND EXISTS(SELECT 1 FROM account_sessions WHERE token_hash=? AND account_id=?)",
          )
          .run(
            activeFixture.h.db.now,
            transaction.verificationAction ?? null,
            captured.tokenHash,
            captured.tokenHash,
            captured.accountId,
          );
        if (refreshed.changes !== 1) return send(401, "{}");
        cookie = captured.cookie;
      } else {
        cookie = await activeFixture.h.login({ email: "google-ui@gmail.com" });
        activeFixture.h.db.sqlite
          .prepare(
            `INSERT OR IGNORE INTO account_external_identities(id,account_id,issuer,subject,locator_hmac,created_at,last_authenticated_at)
          SELECT 'google-ui-fixture',id,'https://accounts.google.com','google-ui-fixture','google-ui-fixture',?,? FROM accounts WHERE email='google-ui@gmail.com'`,
          )
          .run(activeFixture.h.db.now, activeFixture.h.db.now);
      }
      transaction.status = "completed";
      return send(303, "", {
        "Set-Cookie": `${cookie}; Path=/; Secure; HttpOnly; SameSite=Strict`,
        Location:
          transaction.mode === "popup"
            ? "/api/fixture/google/done"
            : "/?auth=success",
      });
    }
    if (url.pathname === "/api/fixture/google/done")
      return send(
        200,
        "<!doctype html><title>accreatio test callback</title><p>Sign-in completed. Return to your project tab.</p>",
        {
          "Content-Type": "text/html",
          "Cross-Origin-Opener-Policy": "same-origin",
        },
      );
    if (url.pathname === "/api/admin/blog/session") return send(401, "{}");
    if (url.pathname === "/api/blog/posts") {
      activeFixture.state.blogReads++;
      return send(200, JSON.stringify({ posts: blogPosts }));
    }
    if (url.pathname.startsWith("/api/account/")) {
      const { h, state } = activeFixture;
      const action = url.pathname.slice("/api/account/".length);
      const chunks = [];
      for await (const chunk of request) chunks.push(chunk);
      const requestText = Buffer.concat(chunks).toString("utf8");
      const body = requestText ? JSON.parse(requestText) : undefined;
      state.requests.push({
        action,
        method: request.method,
        body:
          action === "otp/verify"
            ? { challengeId: body.challengeId, code: "[redacted]" }
            : body,
        navigation: request.headers["sec-fetch-mode"] === "navigate",
      });
      if (action === "session" && state.holdSession) {
        const held = state.holdSession;
        held.observed();
        await held.wait;
      }
      const result = await h.call(action, {
        method: request.method,
        url: url.href,
        origin: request.headers.origin,
        cookie: request.headers.cookie,
        headers: {
          ...(request.headers["x-accreatio-rights"]
            ? { "X-Accreatio-Rights": request.headers["x-accreatio-rights"] }
            : {}),
          ...(request.headers["x-accreatio-rights-transaction"]
            ? {
                "X-Accreatio-Rights-Transaction":
                  request.headers["x-accreatio-rights-transaction"],
              }
            : {}),
        },
        body,
        bindExportContext: false,
      });
      return send(
        result.status,
        await result.text(),
        Object.fromEntries(result.headers),
      );
    }
    const asset = await fetch(new URL(request.url, staticTarget));
    const headers = new Headers(asset.headers);
    headers.delete("Content-Encoding");
    headers.delete("Content-Length");
    send(
      asset.status,
      Buffer.from(await asset.arrayBuffer()),
      Object.fromEntries(headers),
    );
  } catch (error) {
    send(500, JSON.stringify({ error: { message: String(error) } }));
  }
});

async function continueThroughPrivacy(testPage) {
  await testPage
    .getByRole("heading", {
      name: "Prepare the brief for your next project",
    })
    .waitFor();
  await testPage
    .getByRole("button", { name: "Prepare my project", exact: true })
    .click();
  await testPage.getByRole("heading", { name: "What stays local" }).waitFor();
}
async function enterSignin() {
  await page
    .getByRole("button", { name: "Continue to sign in", exact: true })
    .click();
  await page.locator("#web-email").waitFor();
}
async function requestCode(email = "person@example.test") {
  const postsBefore = accountDiagnostics.requests.filter(
    (request) => request.method === "POST",
  ).length;
  await page.locator("#web-email").fill(email);
  const sendCode = page.getByRole("button", { name: "Send code", exact: true });
  await assertClickwrapBeforeAction(
    page,
    sendCode,
    () =>
      accountDiagnostics.requests.filter((request) => request.method === "POST")
        .length,
  );
  assert.equal(
    accountDiagnostics.requests.filter((request) => request.method === "POST")
      .length,
    postsBefore,
    "Typing an email or reading clickwrap never sends a payload",
  );
  await sendCode.click();
  await page.locator("#web-otp").waitFor();
  await assertPolicyNotice(page);
  assert.equal(
    accountDiagnostics.requests.filter((request) => request.method === "POST")
      .length,
    postsBefore + 1,
  );
  assert.deepEqual(
    accountDiagnostics.requests
      .filter((request) => request.action === "otp/request")
      .at(-1).body,
    { email, policyAuthorization: POLICY_AUTHORIZATION },
  );
  await page
    .getByRole("button", { name: "Change email", exact: true })
    .waitFor();
}
async function verifyLatest(h) {
  await assertPolicyNotice(page);
  await page.locator("#web-otp").fill(h.mailbox.at(-1).code);
  await page
    .getByRole("button", { name: "Verify and continue", exact: true })
    .click();
  await page.locator(".web-account-menu__trigger").waitFor();
  if (await page.locator("#account-policy-title").count())
    await page
      .getByRole("button", { name: "Save and continue", exact: true })
      .click();
}
const accountActionResponse = (testPage, action) =>
  testPage.waitForResponse(
    (response) =>
      new URL(response.url()).pathname === `/api/account/${action}` &&
      response.request().method() === "POST",
  );
async function advance(h, milliseconds) {
  h.db.now += milliseconds;
  await page.clock.fastForward(milliseconds);
}
async function assertLayouts(label) {
  for (const width of [320, 390, 1280]) {
    await page.setViewportSize({ width, height: 900 });
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      true,
      `${label} at ${width}px must not overflow`,
    );
    await page.screenshot({
      path: path.join(output, `${label}-${width}.png`),
      fullPage: true,
    });
  }
  await page.setViewportSize({ width: 390, height: 844 });
}
async function openAccountMenu() {
  const trigger = page.locator(".web-account-menu__trigger");
  await trigger.waitFor();
  assert.equal(
    await trigger.getAttribute("aria-controls"),
    "web-account-menu-panel",
  );
  if ((await trigger.getAttribute("aria-expanded")) !== "true")
    await trigger.click();
  const panel = page.getByRole("region", { name: "Account", exact: true });
  await panel.waitFor();
  assert.equal(await trigger.getAttribute("aria-expanded"), "true");
  return panel;
}
async function closeAccountMenu() {
  await page.keyboard.press("Escape");
  await page.locator("#web-account-menu-panel").waitFor({ state: "hidden" });
  assert.equal(
    await page
      .locator(".web-account-menu__trigger")
      .getAttribute("aria-expanded"),
    "false",
  );
  assert.equal(
    await page
      .locator(".web-account-menu__trigger")
      .evaluate((trigger) => document.activeElement === trigger),
    true,
    "Escape returns focus to the account trigger",
  );
}
async function assertAccountQuota(used, limit = 5) {
  const panel = await openAccountMenu();
  await panel
    .getByText(`${used} of ${limit} exports used in the last 24 hours`, {
      exact: true,
    })
    .waitFor();
  await panel
    .getByText(`${limit - used} of ${limit} exports remaining`, { exact: true })
    .waitFor();
  assert.equal(await page.locator(".web-account-menu__used").count(), 1);
  assert.equal(await page.locator(".web-account-menu__remaining").count(), 1);
  await closeAccountMenu();
}
async function assertNoAccountMenu() {
  assert.equal(await page.locator(".web-account-menu__trigger").count(), 0);
  assert.equal(await page.locator("#web-account-menu-panel").count(), 0);
}
async function checkAccountMenu() {
  const trigger = page.locator(".web-account-menu__trigger");
  assert.equal((await trigger.innerText()).trim(), "creator");
  assert.equal(
    await trigger.evaluate((element) => {
      const buttons = [
        ...element.closest(".app-header").querySelectorAll("button"),
      ];
      return buttons[buttons.indexOf(element) - 1]?.textContent?.trim();
    }),
    "New project",
    "The account trigger immediately follows New project in the header",
  );
  assert.equal(
    await page.getByText("creator@example.test", { exact: true }).count(),
    0,
  );
  assert.equal(
    await page
      .locator(".web-account-menu__used, .web-account-menu__remaining")
      .count(),
    0,
  );
  for (const width of [320, 390, 1280]) {
    await page.setViewportSize({ width, height: 900 });
    const panel = await openAccountMenu();
    await panel.getByText("creator@example.test", { exact: true }).waitFor();
    assert.equal(
      await page.getByText("creator@example.test", { exact: true }).count(),
      1,
    );
    const box = await panel.boundingBox();
    const withinViewport =
      box &&
      box.x >= 0 &&
      box.y >= 0 &&
      box.x + box.width <= width &&
      box.y + box.height <= 900;
    if (!withinViewport)
      console.error(
        "Account menu geometry",
        JSON.stringify({
          requestedWidth: width,
          measuredBox: box,
          currentLayout: await panel.evaluate((element) => {
            const menuRoot = element.closest(".web-account-menu");
            return {
              viewport: { width: innerWidth, height: innerHeight },
              panel: element.getBoundingClientRect().toJSON(),
              root: menuRoot.getBoundingClientRect().toJSON(),
              trigger: menuRoot
                .querySelector(".web-account-menu__trigger")
                .getBoundingClientRect()
                .toJSON(),
              panelStyle: element.getAttribute("style"),
            };
          }),
        }),
      );
    assert.ok(
      withinViewport,
      `Account menu stays within the ${width}px viewport: ${JSON.stringify(box)}`,
    );
    if (width >= 768) {
      const triggerBox = await trigger.boundingBox();
      assert.ok(
        triggerBox &&
          Math.abs(box.x + box.width - triggerBox.x - triggerBox.width) <= 1,
        `Desktop account panel aligns with the trigger right edge: ${JSON.stringify({ box, triggerBox })}`,
      );
    } else {
      const headerBox = await page.locator(".app-header").boundingBox();
      assert.ok(
        headerBox && Math.abs(box.y - headerBox.y - headerBox.height - 8) <= 1,
        `Mobile account panel opens below the header with an 8px gap: ${JSON.stringify({ box, headerBox })}`,
      );
    }
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      true,
    );
    await page.screenshot({
      path: path.join(output, `account-menu-${width}.png`),
      fullPage: true,
    });
    await closeAccountMenu();
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await trigger.focus();
  await page.keyboard.press("ArrowDown");
  const keyboardPanel = page.getByRole("region", {
    name: "Account",
    exact: true,
  });
  await keyboardPanel.waitFor();
  assert.equal(
    await keyboardPanel.evaluate(
      (element) => document.activeElement === element,
    ),
    true,
  );
  await closeAccountMenu();
  await openAccountMenu();
  // The open mobile panel covers the editor; use visible header padding for a
  // real outside pointer without navigating or clicking through the overlay.
  await page.locator(".app-header").click({ position: { x: 6, y: 6 } });
  await page.locator("#web-account-menu-panel").waitFor({ state: "hidden" });
  assert.equal(await trigger.getAttribute("aria-expanded"), "false");
  const panel = await openAccountMenu();
  await panel.locator('button:enabled, a[href], [tabindex="0"]').last().focus();
  await page.keyboard.press("Tab");
  await page.locator("#web-account-menu-panel").waitFor({ state: "hidden" });
  assert.equal(await trigger.getAttribute("aria-expanded"), "false");
  for (const destination of ["Blog", "About"]) {
    await page.getByRole("button", { name: destination, exact: true }).click();
    await page
      .locator(destination === "Blog" ? ".blog-post" : ".about-popover")
      .first()
      .waitFor();
    if (destination === "About")
      await page
        .getByRole("button", { name: "Close About", exact: true })
        .click();
    const publicPanel = await openAccountMenu();
    await publicPanel
      .getByText("creator@example.test", { exact: true })
      .waitFor();
    for (const name of ["Privacy and my data", "Sign out", "Delete account"])
      assert.equal(
        await publicPanel
          .getByRole("button", { name, exact: true })
          .isEnabled(),
        true,
      );
    await assertAccountQuota(0);
  }
  await page.getByRole("button", { name: "New project", exact: true }).click();
  await page.locator("#project-name").waitFor();
  console.log(
    "PASS account menu: header order, legacy username, private dropdown content, Escape/focus, outside click, Tab, Blog/About and 320/390/1280 layouts",
  );
}
const sessionPosts = (requests) =>
  requests.filter((r) => r.action === "session" && r.method === "POST").length;
const sessions = (h) =>
  h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get().n;

async function checkAccountDraftIsolation() {
  const context = await browser.newContext({
    viewport: { width: 390, height: 900 },
    reducedMotion: "reduce",
    acceptDownloads: true,
  });
  const h = await harness();
  h.db.now = Math.floor(Date.now() / 1000) * 1000;
  const state = installAccountRoutes(h);
  page = await context.newPage();
  await page.clock.install({ time: new Date(h.db.now) });
  const readStoredWork = () =>
    page.evaluate(async () => {
      const db = await new Promise((resolve, reject) => {
        const open = indexedDB.open("accreatio-drafts");
        open.onsuccess = () => resolve(open.result);
        open.onerror = () => reject(open.error);
      });
      const read = (key) =>
        new Promise((resolve, reject) => {
          const request = db
            .transaction("drafts")
            .objectStore("drafts")
            .get(key);
          request.onsuccess = () => resolve(request.result ?? null);
          request.onerror = () => reject(request.error);
        });
      try {
        return {
          durable: await read("account-current:v1"),
          legacy: await read("current"),
          journal: JSON.parse(
            localStorage.getItem("accreatio:account-draft:v1"),
          ),
          legacyJournal: localStorage.getItem("accreatio:draft-journal:v5"),
          marker: JSON.parse(
            localStorage.getItem("accreatio:draft-context:v1"),
          ),
          preference: JSON.parse(
            localStorage.getItem("accreatio:cookie-preferences"),
          ),
        };
      } finally {
        db.close();
      }
    });
  const session = async () => {
    const cookie = (await context.cookies()).find(
      (item) => item.name === "__Host-accreatio_session",
    );
    assert.ok(cookie);
    const response = await h.call("session", {
      method: "GET",
      cookie: `${cookie.name}=${cookie.value}`,
    });
    assert.equal(response.status, 200);
    return { cookie, account: await response.json() };
  };
  let preference;
  const assertBlank = async (label) => {
    await expectQuestion(page, "name");
    assert.equal(await page.locator("#project-name").inputValue(), "", label);
    assert.equal(await page.locator(".outcome-panel").count(), 0);
    assert.equal(await page.locator(".attachment-list li").count(), 0);
    assert.equal(
      await page
        .getByRole("button", {
          name: "Download the same ZIP again",
          exact: true,
        })
        .count(),
      0,
      `${label}: previous ZIP recovery is absent`,
    );
    const { account } = await session();
    const stored = await readStoredWork();
    assert.deepEqual(stored.preference, preference);
    assert.equal(stored.legacy, null);
    assert.equal(stored.legacyJournal, null);
    assert.equal(stored.marker.ownerKey, account.ownerKey);
    assert.equal(stored.marker.sessionKey, account.sessionKey);
    for (const draft of [stored.journal, stored.durable].filter(Boolean)) {
      assert.equal(draft.ownerKey, account.ownerKey);
      assert.equal(draft.sessionKey, account.sessionKey);
      assert.equal(draft.project.name, "");
      assert.equal(draft.project.context, "");
      assert.equal(draft.project.restrictions, "");
      assert.equal(draft.project.phase, "idea");
      assert.equal(draft.project.initializeGit, false);
      assert.equal(draft.project.createRemote, false);
      assert.equal(draft.project.openIde, false);
      assert.equal(draft.project.dryRun, true);
      assert.equal(draft.project.participants.length, 1);
      assert.deepEqual(draft.project.attachments, []);
      assert.equal(draft.transientAttachments?.count ?? 0, 0);
      assert.equal(draft.navigation?.question ?? "name", "name");
    }
    assert.doesNotMatch(
      JSON.stringify(stored),
      /Private account A|Private A context|Private A restriction|private-account-a\.docx|Replacement A secret/,
      label,
    );
  };
  const signIn = async (email) => {
    await requestCode(email);
    await verifyLatest(h);
    await page.locator("#project-name").waitFor();
  };
  const signOut = async () => {
    await openAccountMenu();
    const loggedOut = accountActionResponse(page, "logout");
    await page.getByRole("button", { name: "Sign out", exact: true }).click();
    assert.equal((await loggedOut).status(), 200);
    await page.locator("#web-email").waitFor();
    const stored = await readStoredWork();
    assert.equal(stored.durable, null);
    assert.equal(stored.journal, null);
    assert.equal(stored.legacy, null);
    assert.equal(stored.legacyJournal, null);
    assert.deepEqual(stored.preference, preference);
  };
  try {
    await page.goto(target);
    await continueThroughPrivacy(page);
    await enterSignin();
    await signIn("isolation-a@example.test");
    const aId = h.db.sqlite
      .prepare("SELECT id FROM accounts WHERE email=?")
      .get("isolation-a@example.test").id;
    const aFirst = await session();
    const choice = await rejectNonEssentialCookies(
      page,
      () =>
        state.requests.filter((request) => request.method === "POST").length,
    );
    preference = choice.preference;
    await page.locator("#project-name").fill("Private account A");
    await continueQuestion(page);
    await page.getByRole("button", { name: /I'm exploring the idea/ }).click();
    await expectQuestion(page, "attachments");
    const chooser = page.waitForEvent("filechooser");
    await page
      .getByRole("button", { name: "Add local files", exact: true })
      .click();
    await (
      await chooser
    ).setFiles({
      name: "private-account-a.docx",
      mimeType:
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      buffer: minimalDocx("Private account A attachment bytes"),
    });
    await page
      .getByRole("button", {
        name: "Remove private-account-a.docx",
        exact: true,
      })
      .waitFor();
    await continueQuestion(page);
    await expectQuestion(page, "context");
    await page.locator("#project-context").fill("Private A context");
    await continueQuestion(page);
    await expectQuestion(page, "restrictions");
    await page.locator("#project-restrictions").fill("Private A restriction");
    await continueQuestion(page);
    await expectQuestion(page, "review");
    await page.getByRole("button", { name: /^Advanced options ·/ }).click();
    await expectQuestion(page, "team");
    await page.locator(".guided-team__customization > summary").click();
    await page
      .getByRole("button", { name: "Add participant", exact: true })
      .click();
    await page
      .getByText("Repository, GitHub, and IDE · no options", { exact: true })
      .click();
    for (const label of [
      "Include Git guide",
      "Include GitHub guide",
      "Include IDE guide",
    ])
      await page.getByLabel(label, { exact: true }).check();
    await continueQuestion(page);
    await expectQuestion(page, "review");
    await page.locator(".review-stage__dry-run input").uncheck();
    await page.locator(".review-stage__confirm").getByRole("button").click();
    const download = page.waitForEvent("download");
    await page.locator("dialog .modal-actions .confirm").click();
    await (await download).path();
    await page
      .getByRole("button", { name: "Download the same ZIP again", exact: true })
      .waitFor();
    assert.equal(
      h.db.sqlite
        .prepare("SELECT COUNT(*) AS n FROM export_authorizations")
        .get().n,
      1,
    );
    await signOut();

    await signIn("isolation-b@example.test");
    const bId = h.db.sqlite
      .prepare("SELECT id FROM accounts WHERE email=?")
      .get("isolation-b@example.test").id;
    const bFirst = await session();
    assert.notEqual(
      bId,
      aId,
      "B is a different real account in the same fixture database",
    );
    assert.notEqual(bFirst.account.ownerKey, aFirst.account.ownerKey);
    await assertBlank("A logout then B must start from zero");
    await assertAccountQuota(0);
    await page.locator("#project-name").fill("Account B only");
    await signOut();
    await advance(h, 61_000);
    await signIn("isolation-a@example.test");
    const aReturned = await session();
    assert.equal(aReturned.account.ownerKey, aFirst.account.ownerKey);
    assert.notEqual(aReturned.account.sessionKey, aFirst.account.sessionKey);
    await assertBlank(
      "A returning after explicit logout must also start from zero",
    );
    await assertAccountQuota(1);

    await page.locator("#project-name").fill("Replacement A secret");
    const replacement = await h.login({ email: "isolation-b@example.test" });
    await context.addCookies([
      { ...aReturned.cookie, value: replacement.split("=")[1] },
    ]);
    let releaseSession, observeSession;
    const heldSession = new Promise((resolve) => {
      releaseSession = resolve;
    });
    const requestedSession = new Promise((resolve) => {
      observeSession = resolve;
    });
    state.holdSession = { wait: heldSession, observed: observeSession };
    await page.evaluate(() =>
      document.dispatchEvent(new Event("visibilitychange")),
    );
    await requestedSession;
    assert.equal(
      await page.locator("#project-name").count(),
      0,
      "Editor is blocked while the replacement session is being checked",
    );
    state.holdSession = undefined;
    releaseSession();
    await assertBlank(
      "Cookie replacement A to B cannot expose A's previous draft",
    );
    await assertAccountQuota(0);

    await page
      .locator("#project-name")
      .fill("Pending B edit before other-tab logout");
    const secondary = await context.newPage();
    await secondary.goto(target);
    const trigger = secondary.locator(".web-account-menu__trigger");
    await trigger.waitFor();
    await trigger.click();
    const secondaryLogout = accountActionResponse(secondary, "logout");
    await secondary
      .getByRole("button", { name: "Sign out", exact: true })
      .click();
    assert.equal((await secondaryLogout).status(), 200);
    await secondary.locator("#web-email").waitFor();
    await page.waitForFunction(() => !document.querySelector("#project-name"));
    await page.bringToFront();
    await page.evaluate(() =>
      document.dispatchEvent(new Event("visibilitychange")),
    );
    await page.locator("#web-email").waitFor();
    assert.equal(await page.locator("#project-name").count(), 0);
    await secondary.close();
    await advance(h, 61_000);
    await signIn("isolation-b@example.test");
    await assertBlank(
      "Logout in a secondary tab invalidates pending work in the primary tab",
    );
    await page.clock.fastForward(1500);
    await assertBlank(
      "A delayed autosave cannot restore work after another-tab logout",
    );
    assert.equal(
      h.db.sqlite
        .prepare("SELECT COUNT(*) AS n FROM export_authorizations")
        .get().n,
      1,
    );
    await writeFile(
      path.join(output, "account-isolation-receipt.json"),
      JSON.stringify(
        {
          result: "PASS",
          checks: [
            "different internal accounts share one fixture DB",
            "A logout to B blank",
            "A logout to A blank",
            "name/context/restrictions/options/navigation/attachments/recovery reset",
            "cookie replacement blocks editor while checking and resets before B",
            "secondary-tab logout invalidates pending primary work",
            "cookie preference and original quota receipt preserved",
          ],
        },
        null,
        2,
      ),
    );
    console.log(
      "PASS account draft isolation: distinct accounts, same-account return, cookie replacement, secondary-tab logout and unchanged cookie preferences/quota",
    );
  } catch (error) {
    await writeFile(
      path.join(output, "account-isolation-failure.txt"),
      await page
        .locator("body")
        .innerText()
        .catch(() => "unavailable"),
    );
    await page
      .screenshot({
        path: path.join(output, "account-isolation-failure.png"),
        fullPage: true,
      })
      .catch(() => {});
    throw error;
  } finally {
    await context.close();
  }
}

async function checkPrivacyDisclosures() {
  const privacyHarness = await harness();
  const privacyState = installAccountRoutes(privacyHarness);
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    reducedMotion: "reduce",
    extraHTTPHeaders: { DNT: "1", "Sec-GPC": "1" },
  });
  await context.addInitScript(() => {
    Object.defineProperty(navigator, "globalPrivacyControl", { value: true });
    Object.defineProperty(navigator, "doNotTrack", { value: "1" });
  });
  const network = [];
  context.on("request", (request) =>
    network.push({
      url: request.url(),
      method: request.method(),
      resourceType: request.resourceType(),
      dnt: request.headers().dnt,
      gpc: request.headers()["sec-gpc"],
    }),
  );
  try {
    page = await context.newPage();
    await page.goto(target);
    await page
      .getByRole("heading", {
        name: "Prepare the brief for your next project",
      })
      .waitFor();
    await page.evaluate(async () => {
      await navigator.serviceWorker.ready;
    });
    await page.getByRole("button", { name: "Blog", exact: true }).click();
    await page.locator(".blog-post").first().waitFor();
    await page.getByRole("button", { name: "About", exact: true }).click();
    await page.locator(".about-popover").waitFor();
    await page
      .getByRole("link", { name: "aekr@aekr.io", exact: true })
      .first()
      .waitFor();
    await page
      .getByRole("button", { name: "Close About", exact: true })
      .click();
    assert.equal(
      await page.evaluate(() =>
        localStorage.getItem("accreatio:cookie-preferences"),
      ),
      null,
      "Anonymous navigation records no default cookie acceptance",
    );
    assert.equal(
      await page
        .getByRole("button", {
          name: /^(accept all|reject all|manage cookies)$/i,
        })
        .count(),
      0,
    );
    const cookieChoice = await rejectNonEssentialCookies(
      page,
      () =>
        privacyState.authRequests.length +
        privacyState.requests.filter((request) => request.method !== "GET")
          .length,
    );
    assert.equal(cookieChoice.preferenceBefore, null);
    for (const documentName of ["privacy", "terms", "terms-es", "cookies"]) {
      await page.goto(`${target}/legal/${documentName}.html`);
      await page.locator("h1").first().waitFor();
      const contacts = page.locator('a[href="mailto:aekr@aekr.io"]');
      await contacts.first().waitFor();
      const publicText = await page.locator("body").innerText();
      if (documentName !== "terms-es")
        assert.match(publicText, /Operator:\s*AEKR/);
      if (documentName !== "terms")
        assert.match(publicText, /(?:Operador|Responsable):\s*AEKR/);
      assert.doesNotMatch(
        publicText,
        /(?:Operator|Operador|Responsable):\s*Ed Lopez/,
      );
      assert.ok(
        publicText.includes(
          documentName.startsWith("terms")
            ? "Version 20261025"
            : POLICY_AUTHORIZATION.privacyNoticeVersion,
        ),
      );
      if (documentName === "cookies") {
        const text = publicText;
        for (const inventoryEntry of [
          "__Host-accreatio_session",
          "__Host-accreatio_auth_tx",
          "accreatio:account-draft:v1",
          "localStorage",
          "IndexedDB",
          "CacheStorage",
        ])
          assert.ok(
            text.includes(inventoryEntry),
            `Cookie notice discloses ${inventoryEntry}`,
          );
        assert.match(text, /Global Privacy Control|GPC/);
        assert.match(text, /Do Not Track|DNT/);
      }
      assert.equal(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
        true,
      );
      await page.screenshot({
        path: path.join(output, `privacy-signals-${documentName}-390.png`),
        fullPage: true,
      });
    }
    assert.deepEqual(
      await page.evaluate(() => ({
        gpc: navigator.globalPrivacyControl,
        dnt: navigator.doNotTrack,
      })),
      { gpc: true, dnt: "1" },
    );
    assert.ok(network.length > 0);
    assert.deepEqual(
      network.filter((request) => new URL(request.url).origin !== target),
      [],
      "GPC/DNT browsing loads no external collector or resource",
    );
    assert.deepEqual(
      network.filter((request) => request.method !== "GET"),
      [],
      "Anonymous navigation transmits no optional event or account mutation",
    );
    assert.ok(
      network.some((request) => request.dnt === "1" && request.gpc === "1"),
      "Privacy signals are present on actual browser requests",
    );
    assert.deepEqual(privacyState.authRequests, []);
    assert.ok(
      privacyState.requests.every((request) => request.method === "GET"),
    );
    assert.equal(privacyHarness.mailbox.length, 0);
    assert.equal(sessions(privacyHarness), 0);
    assert.deepEqual(
      await context.cookies(),
      [],
      "Anonymous fixture browsing creates no advertising/analytics or account cookie",
    );
    const storage = await page.evaluate(async () => ({
      local: Object.keys(localStorage),
      session: Object.keys(sessionStorage),
      databases: (await indexedDB.databases()).map((database) => database.name),
    }));
    assert.ok(
      storage.local.every((key) =>
        [
          "accreatio:onboarding",
          "accreatio:cookie-preferences",
          "accreatio:collection-boundary:analytics:v1",
          "accreatio:collection-boundary:research:v1",
          "accreatio:account-draft:v1",
          "accreatio:draft-context:v1",
        ].includes(key),
      ),
    );
    assert.deepEqual(
      await page.evaluate(() =>
        JSON.parse(localStorage.getItem("accreatio:cookie-preferences")),
      ),
      cookieChoice.preference,
    );
    assert.deepEqual(storage.session, []);
    assert.ok(storage.databases.every((name) => name === "accreatio-drafts"));
    await writeFile(
      path.join(output, "privacy-signals-receipt.json"),
      JSON.stringify(
        {
          result: "PASS",
          boundary:
            "isolated local production bundle and synthetic fixture services; no claim about live edge/provider cookies",
          signals: { gpc: true, dnt: "1" },
          network,
          storage,
        },
        null,
        2,
      ),
    );
    console.log(
      "PASS privacy UI: public notices/contact, exact device-storage names and GPC/DNT with default-off optional collection and no optional transmission",
    );
  } finally {
    await context.close();
    page = null;
  }
}
try {
  await new Promise((resolve, reject) => {
    apiServer.once("error", reject);
    apiServer.listen(port, "127.0.0.1", resolve);
  });
  for (let i = 0; i < 100; i++) {
    try {
      if ((await fetch(target)).ok) break;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    acceptDownloads: true,
    reducedMotion: "reduce",
  });
  const h = await harness();
  h.db.now = Math.floor(Date.now() / 1000) * 1000;
  const state = installAccountRoutes(h);
  const { requests } = state;
  page = await context.newPage();
  await page.clock.install({ time: new Date(h.db.now) });
  const pageErrors = [];
  page.on("pageerror", (error) => pageErrors.push(error.message));
  await page.goto(target);
  await page
    .getByRole("heading", {
      name: "Prepare the brief for your next project",
    })
    .waitFor();
  assert.equal(await page.locator("#project-name").count(), 0);
  await assertNoAccountMenu();
  await page.getByRole("button", { name: "Blog", exact: true }).click();
  await page.locator(".blog-post").first().waitFor();
  assert.equal(await page.locator(".blog-post").count(), 3);
  assert.equal(await page.locator("#blog-admin-title").count(), 0);
  await assertNoAccountMenu();
  await page.getByRole("button", { name: "About", exact: true }).click();
  await page.locator(".about-popover").waitFor();
  assert.equal(await page.locator("#web-signin-title").count(), 0);
  await assertNoAccountMenu();
  await page.getByRole("button", { name: "Close About", exact: true }).click();
  await page
    .locator(".app-header")
    .getByRole("button", { name: "Go to accreatio home", exact: true })
    .click();
  await continueThroughPrivacy(page);
  assert.equal(sessions(h), 0);
  assert.equal(h.mailbox.length, 0);
  await enterSignin();
  await assertPolicyNotice(page);
  assert.equal(
    requests.filter((request) => request.method === "POST").length,
    0,
    "Mount, session reads and notices send no authorization",
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
      .get().n,
    0,
  );
  assert.equal(await page.locator("#project-name").count(), 0);
  assert.equal(
    await page.evaluate(() => document.activeElement?.id),
    "web-signin-title",
  );
  await assertLayouts("email");
  await page.evaluate(async () => {
    await navigator.serviceWorker.ready;
  });
  await page.reload();
  await page.locator("#web-email").waitFor();
  assert.equal(
    await page.evaluate(() => navigator.serviceWorker.controller !== null),
    true,
  );
  await page.getByRole("button", { name: "Back", exact: true }).click();
  await page.getByRole("heading", { name: "What stays local" }).waitFor();
  await enterSignin();
  await assertPolicyNotice(page);
  assert.equal(h.mailbox.length, 0, "Entering the gate must not send email");
  await requestCode();
  assert.equal(new URL(page.url()).origin, target);
  assert.equal(sessions(h), 0, "Sending a code cannot establish a session");
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
      .get().n,
    0,
    "Requesting OTP alone is not identity proof or a completed authorization receipt",
  );
  assert.equal(
    await page.getByRole("button", { name: /^Resend in/ }).isDisabled(),
    true,
  );
  await assertLayouts("code");
  const wrongCode = h.mailbox.at(-1).code === "000000" ? "111111" : "000000";
  await page.locator("#web-otp").fill(wrongCode);
  await page
    .getByRole("button", { name: "Verify and continue", exact: true })
    .click();
  await page
    .getByRole("alert")
    .filter({ hasText: "This code is invalid or expired" })
    .waitFor();
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
      .get().n,
    0,
    "Wrong identity proof cannot create a receipt",
  );
  await page.evaluate(() =>
    document.dispatchEvent(new Event("visibilitychange")),
  );
  assert.equal(
    await page.locator("#web-otp").inputValue(),
    wrongCode,
    "Session polling preserves the entered code",
  );
  await advance(h, 61_000);
  await assertPolicyNotice(page);
  await page
    .getByRole("button", { name: "Send another code", exact: true })
    .click();
  await page.waitForFunction(
    () => document.querySelector("#web-otp")?.value === "",
  );
  assert.equal(h.mailbox.length, 2);
  await page.getByRole("button", { name: "Change email", exact: true }).click();
  assert.equal(
    await page.locator("#web-email").inputValue(),
    "person@example.test",
  );
  await requestCode("creator@example.test");
  await verifyLatest(h);
  await page.locator("#project-name").waitFor();
  assert.equal(sessions(h), 1);
  assert.equal(sessionPosts(requests), 0);
  assert.equal(
    requests.some((r) => ["identity", "login"].includes(r.action)),
    false,
  );
  assert.equal(
    requests.some((r) => r.navigation),
    false,
    "OTP does not leave the app",
  );
  await page.reload();
  await page.locator("#project-name").waitFor();
  assert.equal(
    sessions(h),
    1,
    "Existing cookie sessions resume without issuance",
  );
  await assertAccountQuota(0);
  await checkAccountMenu();
  assert.ok(
    (await context.cookies()).some(
      (c) =>
        c.name === "__Host-accreatio_session" &&
        c.httpOnly &&
        c.secure &&
        c.sameSite === "Strict",
    ),
  );
  console.log(
    "PASS own OTP: ordered entry, invalid code, cooldown/resend, email correction, cookie resume, active service worker and layouts",
  );
  await page.locator("#project-name").fill("Account smoke");
  await page.locator(".guided-creation__continue").click();
  await page.getByRole("button", { name: /I'm starting with an idea/ }).click();
  await page
    .locator("#project-context")
    .fill("A local planning project for account verification.");
  await finishGuidedQuestions(page);
  // Follow the visible confirm flow, preserving the same project in memory.
  for (let i = 0; i < 5; i++) {
    await page.locator(".review-stage__dry-run input").uncheck();
    await page.locator(".review-stage__confirm").getByRole("button").click();
    const downloaded = page.waitForEvent("download");
    await page.locator("dialog .modal-actions .confirm").click();
    await (await downloaded).path();
    await assertAccountQuota(i + 1);
    if (i < 4)
      await page
        .getByRole("button", { name: "Edit and export again", exact: true })
        .click();
    if (i === 0) {
      const recovery = page.getByRole("button", {
        name: "Download the same ZIP again",
        exact: true,
      });
      await recovery.waitFor();
      page.once("dialog", (dialog) => dialog.dismiss());
      await page
        .getByRole("button", { name: "New draft", exact: true })
        .click();
      await recovery.waitFor();
      const authorizationCalls = requests.filter(
        (request) => request.action === "authorize",
      ).length;
      page.once("dialog", (dialog) => dialog.accept());
      await page
        .getByRole("button", { name: "New draft", exact: true })
        .click();
      await page.locator("#project-name").waitFor();
      assert.equal(await page.locator("#project-name").inputValue(), "");
      await recovery.waitFor({ state: "hidden" });
      assert.equal(
        requests.filter((request) => request.action === "authorize").length,
        authorizationCalls,
        "Discarding a draft must not authorize or consume an export",
      );
      assert.equal(sessions(h), 1, "Discarding a draft preserves the account");
      await assertAccountQuota(1);
      console.log(
        "PASS new draft: cancellation keeps ZIP retry; confirmed discard removes previous ZIP recovery without account or quota changes",
      );
      await page.locator("#project-name").fill("Account smoke");
      await page.locator(".guided-creation__continue").click();
      await page
        .getByRole("button", { name: /I'm starting with an idea/ })
        .click();
      await page
        .locator("#project-context")
        .fill("A local planning project for account verification.");
      await finishGuidedQuestions(page);
    }
  }
  await page
    .getByRole("heading", { name: "Thank you for creating with accreatio!" })
    .waitFor();
  assert.equal(await page.locator(".guided-creation").count(), 0);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM export_authorizations").get()
      .n,
    5,
  );
  const again = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Download the same ZIP again", exact: true })
    .click();
  await (await again).path();
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM export_authorizations").get()
      .n,
    5,
  );
  await page.screenshot({
    path: path.join(output, "thanks-390.png"),
    fullPage: true,
  });
  for (const width of [320, 1280]) {
    await page.setViewportSize({ width, height: 900 });
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      true,
    );
    await page.screenshot({
      path: path.join(output, `thanks-${width}.png`),
      fullPage: true,
    });
  }
  await page.reload();
  await page
    .getByRole("heading", { name: "Thank you for creating with accreatio!" })
    .waitFor();
  assert.equal(
    await page
      .getByRole("button", { name: "Download the same ZIP again", exact: true })
      .count(),
    0,
  );
  await page
    .getByRole("button", { name: "Keep editing my draft", exact: true })
    .click();
  assert.ok(await page.locator(".guided-creation").count());
  console.log(
    "PASS account quota: five ZIPs, retry, thank-you, reload and retained draft",
  );
  assert.ok(
    requests
      .filter((r) => r.action === "authorize")
      .every(
        (r) =>
          Object.keys(r.body).sort().join() ===
          "operationId,ownerKey,sessionKey",
      ),
  );
  assert.ok(state.blogReads > 0);
  assert.equal(
    await page.getByRole("button", { name: "Blog", exact: true }).count(),
    1,
  );
  h.db.sqlite.exec("DELETE FROM account_sessions");
  await page.evaluate(() =>
    document.dispatchEvent(new Event("visibilitychange")),
  );
  await page.locator("#web-email").waitFor();
  await assertNoAccountMenu();
  await assertPolicyNotice(page);
  assert.equal(await page.locator(".guided-creation").count(), 0);
  await page.getByRole("button", { name: "New project", exact: true }).click();
  assert.equal(await page.locator("#project-name").count(), 0);
  await page.reload();
  await page.locator("#web-email").waitFor();
  assert.equal(sessions(h), 0);
  await advance(h, 61_000);
  await requestCode("creator@example.test");
  await verifyLatest(h);
  await page
    .getByRole("button", { name: "Keep editing my draft", exact: true })
    .click();
  assert.ok(await page.locator(".guided-creation").count());
  await openAccountMenu();
  const logoutUrl = page.url();
  const loggedOut = accountActionResponse(page, "logout");
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  assert.equal((await loggedOut).status(), 200);
  await page.locator("#web-email").waitFor();
  await assertNoAccountMenu();
  await assertPolicyNotice(page);
  assert.equal(page.url(), logoutUrl);
  assert.equal(sessions(h), 0);
  await advance(h, 61_000);
  await requestCode("creator@example.test");
  await verifyLatest(h);
  await page
    .getByRole("button", { name: "Keep editing my draft", exact: true })
    .click();
  await page.locator("#project-name").waitFor();
  assert.equal(
    await page.locator("#project-name").inputValue(),
    "",
    "Explicit logout erases the draft even when the same account returns",
  );
  await openAccountMenu();
  // This legacy-OTP UI transport fixture represents a separate action-bound
  // proof. Actual Google/GitHub exchanges are covered by identity smoke/tests.
  const deleteCookie = (await context.cookies()).find(
    (cookie) => cookie.name === "__Host-accreatio_session",
  );
  await h.controlProof(
    `__Host-accreatio_session=${deleteCookie.value}`,
    "delete",
  );
  await page
    .getByRole("button", { name: "Delete account", exact: true })
    .click();
  const deletedAccount = accountActionResponse(page, "delete");
  await page
    .getByRole("button", { name: "Confirm deletion", exact: true })
    .click();
  assert.equal((await deletedAccount).status(), 200);
  await page.locator("#web-email").waitFor();
  await assertNoAccountMenu();
  await assertPolicyNotice(page);
  assert.equal(page.url(), logoutUrl);
  assert.equal(sessions(h), 0);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM accounts WHERE email IS NOT NULL")
      .get().n,
    0,
  );
  await advance(h, 61_000);
  await requestCode("creator@example.test");
  await verifyLatest(h);
  await assertAccountQuota(5);
  await page
    .getByRole("button", { name: "Keep editing my draft", exact: true })
    .click();
  await page.locator("#project-name").waitFor();
  assert.equal(
    await page.locator("#project-name").inputValue(),
    "",
    "Account deletion erases local work",
  );
  assert.equal(sessionPosts(requests), 0);
  for (const request of requests.filter(
    (request) => request.action === "otp/request",
  ))
    assert.deepEqual(request.body.policyAuthorization, POLICY_AUTHORIZATION);
  console.log(
    "PASS revocation, logout/deletion without navigation, isolated blank draft after logout/deletion and non-resettable allowance",
  );
  await context.close();

  // Independent fresh account covers expiry, outage and a latest edit whose
  // IndexedDB write fails. Authentication must preserve the in-memory draft.
  const recoveryContext = await browser.newContext({
    viewport: { width: 390, height: 844 },
    reducedMotion: "reduce",
  });
  const recoveryHarness = await harness();
  recoveryHarness.db.now = Math.floor(Date.now() / 1000) * 1000;
  const recoveryState = installAccountRoutes(recoveryHarness);
  page = await recoveryContext.newPage();
  await page.clock.install({ time: new Date(recoveryHarness.db.now) });
  page.on("pageerror", (error) => pageErrors.push(error.message));
  await page.goto(target);
  await continueThroughPrivacy(page);
  await enterSignin();
  await requestCode();
  await advance(recoveryHarness, 601_000);
  await page
    .getByText("This code has expired. Request another to continue.", {
      exact: true,
    })
    .waitFor();
  await page.locator("#web-otp").fill(recoveryHarness.mailbox.at(-1).code);
  assert.equal(
    await page
      .getByRole("button", { name: "Verify and continue", exact: true })
      .isDisabled(),
    true,
  );
  await page
    .getByRole("button", { name: "Send another code", exact: true })
    .click();
  await page.waitForFunction(
    () => document.querySelector("#web-otp")?.value === "",
  );
  await verifyLatest(recoveryHarness);
  await page.locator("#project-name").fill("Retained during reconnect");
  recoveryHarness.db.fail = true;
  await page.evaluate(() =>
    document.dispatchEvent(new Event("visibilitychange")),
  );
  await page.locator(".web-signin__error").waitFor();
  assert.equal(await page.locator("#project-name").count(), 0);
  recoveryHarness.db.fail = false;
  await page
    .getByRole("button", { name: "Check session again", exact: true })
    .click();
  await page.locator("#project-name").waitFor();
  assert.equal(
    await page.locator("#project-name").inputValue(),
    "Retained during reconnect",
  );
  await page.evaluate(() => {
    window.__originalDraftPut = IDBObjectStore.prototype.put;
    IDBObjectStore.prototype.put = function (...args) {
      if (this.name === "drafts")
        throw new DOMException("Test storage full", "QuotaExceededError");
      return window.__originalDraftPut.apply(this, args);
    };
  });
  await page
    .locator("#project-name")
    .fill("Immediate unsaved reauthentication draft");
  recoveryHarness.db.sqlite.exec("DELETE FROM account_sessions");
  await page.evaluate(() =>
    window.dispatchEvent(new Event("accreatio:session-invalid")),
  );
  await page.locator("#web-email").waitFor();
  await advance(recoveryHarness, 61_000);
  await requestCode();
  await verifyLatest(recoveryHarness);
  await page.locator("#project-name").waitFor();
  assert.equal(
    await page.locator("#project-name").inputValue(),
    "Immediate unsaved reauthentication draft",
  );
  await page.evaluate(() => {
    IDBObjectStore.prototype.put = window.__originalDraftPut;
  });
  assert.equal(sessionPosts(recoveryState.requests), 0);
  assert.equal(
    recoveryState.requests.some((r) => r.navigation),
    false,
  );
  await recoveryContext.close();

  const spanishContext = await browser.newContext({
    viewport: { width: 320, height: 900 },
    locale: "es-ES",
    reducedMotion: "reduce",
  });
  const spanishHarness = await harness();
  spanishHarness.db.now = Math.floor(Date.now() / 1000) * 1000;
  installAccountRoutes(spanishHarness);
  page = await spanishContext.newPage();
  await page.goto(target);
  await page
    .getByRole("button", { name: "Switch to Spanish", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Preparar mi proyecto", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Continuar al acceso", exact: true })
    .click();
  await page.locator("#web-email").fill("persona@example.test");
  await assertPolicyNotice(page);
  await assertClickwrapBeforeAction(
    page,
    page.getByRole("button", { name: "Enviar código", exact: true }),
    () =>
      accountDiagnostics.requests.filter((request) => request.method === "POST")
        .length,
  );
  await page
    .getByRole("button", { name: "Enviar código", exact: true })
    .click();
  await page.getByLabel("Código de 6 dígitos", { exact: true }).waitFor();
  await page
    .getByRole("button", { name: "Cambiar correo", exact: true })
    .waitFor();
  await page.screenshot({
    path: path.join(output, "otp-es-320.png"),
    fullPage: true,
  });
  assert.equal(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    true,
  );
  await page.locator("#web-otp").fill(spanishHarness.mailbox.at(-1).code);
  await page
    .getByRole("button", { name: "Verificar y continuar", exact: true })
    .click();
  const spanishTrigger = page.locator(".web-account-menu__trigger");
  await spanishTrigger.waitFor();
  assert.equal((await spanishTrigger.innerText()).trim(), "persona");
  await spanishTrigger.click();
  const spanishPanel = page.getByRole("region", {
    name: "Cuenta",
    exact: true,
  });
  await spanishPanel
    .getByText("persona@example.test", { exact: true })
    .waitFor();
  await spanishPanel
    .getByText("0 de 5 exportaciones usadas en las últimas 24 horas", {
      exact: true,
    })
    .waitFor();
  await spanishPanel
    .getByText("5 de 5 exportaciones restantes", { exact: true })
    .waitFor();
  for (const name of [
    "Privacidad y mis datos",
    "Cerrar sesión",
    "Eliminar cuenta",
  ])
    assert.equal(
      await spanishPanel.getByRole("button", { name, exact: true }).isEnabled(),
      true,
    );
  await page.screenshot({
    path: path.join(output, "account-menu-es-320.png"),
    fullPage: true,
  });
  assert.equal(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    true,
  );
  await closeAccountMenu();
  await spanishContext.close();
  await checkAccountDraftIsolation();
  await checkGoogleAccountUi({ browser, target, output, installAccountRoutes });
  await checkPrivacyDisclosures();
  page = null;
  assert.deepEqual(pageErrors, []);
  await writeFile(
    path.join(output, "receipt.json"),
    JSON.stringify(
      {
        result: "PASS",
        cases: [
          "welcome/privacy/email/code/builder order; no guest builder",
          "anonymous Blog/About and no ordinary-user composer",
          "email request creates no session; only correct OTP creates secure cookie",
          "distinct AEKR Terms and core-data notices; authorization payload only on intentional sign-in/continue, no checkbox state",
          "mount, session reads, wrong identity proof and revisiting notices never create authorization receipts",
          "incorrect code, resend cooldown, new code, change email, ES/EN",
          "expiry and resend recovery; session polling preserves challenge",
          "active service worker; cookie resumes without session creation",
          "no Access identity/login/logout or account document navigation",
          "outage/recheck and latest unsaved draft retained without navigation",
          "revocation, logout, deletion, reload remain locked",
          "explicit logout erases all project fields, options, navigation, attachments and ZIP recovery for both another account and the returning same account",
          "cookie replacement locks the editor during revalidation; secondary-tab logout invalidates queued local work",
          "five exports, same ZIP retry, thank-you, editing and quota after account recovery",
          "confirmed New draft removes previous ZIP retry without changing account or quota; cancellation preserves retry",
          "320/390/1280 layout; metadata-only authorization",
          "authenticated header account menu after New project; private email/quota; Escape, outside pointer, Tab; Blog/About availability",
          "Google UI transport fixtures: guarded navigation, real file-byte preservation, popup/COOP, cancellation, outage and active service worker",
          "legacy policy gate has no backfill; fresh account rights without acceptance; explicit current authorization is recorded once without retry redating",
          "public privacy/terms/cookies contact and storage inventory; GPC/DNT with no optional collectors, transmissions or fake banner",
          "optional cookie rejection is explicit and local, with unchanged auth, quota, draft and attached bytes",
        ],
        issued: 5,
        transport:
          "mock delivery mailbox; real OTP/SQLite handlers; synthetic Google UI transport separately from backend OIDC tests; no real email or IdP login",
        pageErrors,
      },
      null,
      2,
    ),
  );
  console.log(
    `PASS account UI/SQLite integration; evidence: ${path.relative(root, output)}`,
  );
} catch (error) {
  if (page) {
    await writeFile(
      path.join(output, "failure.json"),
      JSON.stringify({ url: page.url(), state: accountDiagnostics }, null, 2),
    );
    await page
      .screenshot({
        path: path.join(output, "failure.png"),
        fullPage: true,
        timeout: 5000,
      })
      .catch(() => {});
    await writeFile(
      path.join(output, "failure.txt"),
      await page
        .locator("body")
        .innerText({ timeout: 5000 })
        .catch(() => "Page body unavailable"),
    ).catch(() => {});
  }
  throw error;
} finally {
  await browser?.close();
  apiServer.closeAllConnections();
  await new Promise((resolve) => apiServer.close(resolve));
  server.kill();
}
