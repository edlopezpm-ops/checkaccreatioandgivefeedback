import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { chromium } from "playwright";
import { harness } from "../tests/helpers/accountHarness.ts";
import { handleOidc } from "../functions/_lib/auth/oidc.ts";
import { handleAccount } from "../functions/_lib/accounts.ts";

// Isolated local HTTP transport. Production handlers see a fixed HTTPS test
// origin; browser cookies and UI run on localhost, with no real IdP traffic.
const root = process.cwd(),
  port = 4187,
  target = `http://127.0.0.1:${port}`,
  assets = `http://127.0.0.1:${port - 1}`,
  origin = "https://accreatio.pages.dev";
const output = path.join(
  root,
  ".local/logs/readiness-2026-10-21",
  `identity-ui-${Date.now()}`,
);
await mkdir(output, { recursive: true });
const h = await harness();
h.db.now = Math.floor(Date.now() / 1000) * 1000;
Object.assign(h.env, {
  ACCOUNT_ENABLED: "true",
  ACCOUNT_GITHUB_ENABLED: "true",
  ACCOUNT_OIDC_ENABLED: "true",
  ACCOUNT_OTP_ENABLED: "false",
  GITHUB_CLIENT_ID: "Iv23.ui-fixture",
  GITHUB_CLIENT_SECRET: "synthetic-ui-secret",
  GITHUB_REDIRECT_URI: `${origin}/api/auth/v1/oidc/github/callback`,
  GOOGLE_CLIENT_ID: "ui-fixture.apps.googleusercontent.com",
  GOOGLE_CLIENT_SECRET: "synthetic-google-secret",
  GOOGLE_REDIRECT_URI: `${origin}/api/auth/v1/oidc/google/callback`,
  ACCOUNT_EMAIL_ENCRYPTION_KEY: "1".repeat(64),
  ACCOUNT_EMAIL_LOOKUP_KEY: "2".repeat(64),
  ACCOUNT_AUTH_LOCATOR_KEY: "3".repeat(64),
  ACCOUNT_OIDC_TRANSACTION_KEY: "4".repeat(64),
  ACCOUNT_CAPTCHA_ENABLED: "true",
  TURNSTILE_SITE_KEY: "synthetic-ui-site-key",
  TURNSTILE_SECRET: "synthetic-ui-turnstile-secret",
  TURNSTILE_HOSTNAMES: "accreatio.pages.dev",
});
const pair = await crypto.subtle.generateKey(
  {
    name: "RSASSA-PKCS1-v1_5",
    modulusLength: 2048,
    publicExponent: new Uint8Array([1, 0, 1]),
    hash: "SHA-256",
  },
  true,
  ["sign", "verify"],
);
const publicKey = await crypto.subtle.exportKey("jwk", pair.publicKey);
let authorization;
let githubReads = 0;
const usedCaptchaTokens = new Set();
const deps = {
  ...h.dependencies,
  fetch: async (input, init) => {
    const url = String(input);
    if (url === "https://challenges.cloudflare.com/turnstile/v0/siteverify") {
      const token = init.body.get("response");
      assert.equal(init.body.get("secret"), h.env.TURNSTILE_SECRET);
      assert.equal(init.body.get("remoteip"), null);
      const success =
        typeof token === "string" &&
        token.startsWith("synthetic-captcha-") &&
        !usedCaptchaTokens.has(token);
      usedCaptchaTokens.add(token);
      return Response.json({
        success,
        action: "login",
        hostname: "accreatio.pages.dev",
      });
    }
    if (url === "https://github.com/login/oauth/access_token")
      return Response.json({
        access_token: "ghu_synthetic_ui",
        token_type: "bearer",
      });
    if (url === "https://api.github.com/user") {
      githubReads++;
      return Response.json({
        id: 129001,
        login: "mutable-ui",
        name: "Identity UI Creator",
        email: null,
      });
    }
    if (url === "https://api.github.com/user/emails?per_page=100&page=1")
      return Response.json([
        { email: "identity-ui@example.test", primary: true, verified: true },
      ]);
    if (url === "https://www.googleapis.com/oauth2/v3/certs")
      return Response.json({
        keys: [{ ...publicKey, kid: "ui-key", alg: "RS256", use: "sig" }],
      });
    assert.equal(url, "https://oauth2.googleapis.com/token");
    const form = init.body;
    assert.equal(form.get("code"), "fixture-code");
    const claims = {
      iss: "https://accounts.google.com",
      sub: "stable-google-ui",
      aud: h.env.GOOGLE_CLIENT_ID,
      iat: h.db.now / 1000,
      exp: h.db.now / 1000 + 3600,
      nonce: authorization.searchParams.get("nonce"),
      email: "other-ui@gmail.com",
      email_verified: true,
      name: "Different presentation name",
    };
    const signed = `${Buffer.from(JSON.stringify({ alg: "RS256", kid: "ui-key" })).toString("base64url")}.${Buffer.from(JSON.stringify(claims)).toString("base64url")}`;
    const signature = await crypto.subtle.sign(
      "RSASSA-PKCS1-v1_5",
      pair.privateKey,
      new TextEncoder().encode(signed),
    );
    return Response.json({
      access_token: "synthetic-google-token",
      token_type: "Bearer",
      expires_in: 3600,
      id_token: `${signed}.${Buffer.from(signature).toString("base64url")}`,
    });
  },
};
const server = spawn(
  process.execPath,
  [
    path.join(root, "node_modules/vite/bin/vite.js"),
    "preview",
    "--host",
    "127.0.0.1",
    "--port",
    String(port - 1),
    "--strictPort",
  ],
  { cwd: root, stdio: "ignore", windowsHide: true },
);
const api = createServer(async (incoming, outgoing) => {
  try {
    const url = new URL(incoming.url, target);
    if (
      url.pathname.startsWith("/api/auth/") ||
      url.pathname.startsWith("/api/account/")
    ) {
      const chunks = [];
      for await (const chunk of incoming) chunks.push(chunk);
      const headers = new Headers(
        Object.entries(incoming.headers).filter(
          ([, value]) => typeof value === "string",
        ),
      );
      headers.set("Origin", origin);
      const request = new Request(`${origin}${url.pathname}${url.search}`, {
        method: incoming.method,
        headers,
        ...(chunks.length ? { body: Buffer.concat(chunks) } : {}),
      });
      let response;
      if (url.pathname.startsWith("/api/account/"))
        response = await handleAccount(
          { request, env: h.env },
          url.pathname.split("/").at(-1),
          deps,
        );
      else {
        const action = url.pathname.endsWith("/start")
          ? "start"
          : url.pathname.endsWith("/callback")
            ? "callback"
            : url.pathname.endsWith("/status")
              ? "status"
              : url.pathname.endsWith("/cancel")
                ? "cancel"
                : url.pathname.endsWith("/complete")
                  ? "complete"
                  : "methods";
        response = await handleOidc(
          {
            request,
            env: h.env,
            params: { id: url.pathname.split("/").at(-2) },
          },
          action,
          deps,
          undefined,
          url.pathname.includes("/github/") ? "github" : "google",
        );
      }
      const resultHeaders = Object.fromEntries(response.headers);
      if (resultHeaders.location) {
        const destination = new URL(resultHeaders.location, origin);
        resultHeaders.location = destination.pathname + destination.search;
      }
      outgoing.writeHead(response.status, resultHeaders);
      outgoing.end(Buffer.from(await response.arrayBuffer()));
      return;
    }
    if (url.pathname.startsWith("/api/")) {
      outgoing.writeHead(401, {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
      });
      outgoing.end("{}");
      return;
    }
    const asset = await fetch(`${assets}${url.pathname}${url.search}`);
    const headers = new Headers(asset.headers);
    headers.delete("Content-Encoding");
    headers.delete("Content-Length");
    outgoing.writeHead(asset.status, Object.fromEntries(headers));
    outgoing.end(Buffer.from(await asset.arrayBuffer()));
  } catch (error) {
    outgoing.writeHead(500, { "Content-Type": "application/json" });
    outgoing.end(JSON.stringify({ error: { code: "fixture_failed" } }));
    console.error(error);
  }
});
await new Promise((resolve) => api.listen(port, "127.0.0.1", resolve));
let browser, page;
try {
  for (let attempts = 0; attempts < 60; attempts++) {
    if (
      await fetch(assets)
        .then((response) => response.ok)
        .catch(() => false)
    )
      break;
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  browser = await chromium.launch({ headless: true, channel: "msedge" });
  const context = await browser.newContext({
    viewport: { width: 390, height: 900 },
    acceptDownloads: true,
    serviceWorkers: "block",
  });
  await context.addInitScript(() => {
    if (location.protocol === "http:") {
      localStorage.setItem(
        "accreatio:onboarding",
        JSON.stringify({ schemaVersion: 1, completed: true }),
      );
      // Test-only widget transport. The actual React lifecycle and backend
      // Siteverify gate run; no visitor verification or provider call is real.
      let serial = 0;
      window.turnstile = {
        render(container, options) {
          const id = `fixture-${++serial}`;
          window.__captchaOptions = options;
          const button = document.createElement("button");
          button.type = "button";
          button.dataset.fixtureCaptcha = id;
          button.textContent = "Complete synthetic verification";
          button.onclick = () =>
            options.callback(`synthetic-captcha-${crypto.randomUUID()}`);
          container.append(button);
          return id;
        },
        remove(id) {
          document.querySelector(`[data-fixture-captcha="${id}"]`)?.remove();
        },
      };
    }
  });
  const pageErrors = [];
  await context.route(
    /^https:\/\/(github\.com\/login\/oauth\/authorize|accounts\.google\.com\/o\/oauth2\/v2\/auth)/,
    async (route) => {
      authorization = new URL(route.request().url());
      await route.fulfill({
        status: 200,
        contentType: "text/html",
        body: "<!doctype html><title>Synthetic authorization</title><p>No real provider login or consent.</p>",
      });
    },
  );
  page = await context.newPage();
  page.on("pageerror", (error) => pageErrors.push(error.message));
  await page.goto(`${target}/?account=continue&lang=en`);
  const completeCaptcha = async () => {
    const google = page.getByRole("button", {
      name: "Continue with Google",
      exact: true,
    });
    const github = page.getByRole("button", {
      name: "Continue with GitHub",
      exact: true,
    });
    await google.waitFor();
    assert.equal(await google.isDisabled(), true);
    assert.equal(await github.isDisabled(), true);
    await page
      .getByRole("button", { name: "Verify to continue", exact: true })
      .click();
    const widget = page.getByRole("button", {
      name: "Complete synthetic verification",
      exact: true,
    });
    await widget.waitFor();
    assert.equal(await page.locator(".shared-captcha").count(), 1);
    assert.equal(await widget.count(), 1);
    await widget.click();
    await page
      .getByText("Verified. Choose Google or GitHub.", { exact: true })
      .waitFor();
    assert.equal(await google.isDisabled(), false);
    assert.equal(await github.isDisabled(), false);
  };
  await page
    .getByRole("button", { name: "Continue with GitHub", exact: true })
    .waitFor();
  await page
    .getByRole("button", { name: "Continue with Google", exact: true })
    .waitFor();
  for (const width of [320, 390, 1280]) {
    await page.setViewportSize({ width, height: 900 });
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      true,
    );
    await page.screenshot({
      path: path.join(output, `signin-en-${width}.png`),
      fullPage: true,
    });
  }
  await page.setViewportSize({ width: 390, height: 900 });
  await page.goto(`${target}/?account=continue&lang=es`);
  await page
    .getByRole("button", { name: "Continuar con GitHub", exact: true })
    .waitFor();
  await page.screenshot({
    path: path.join(output, "signin-es-390.png"),
    fullPage: true,
  });
  await page.goto(`${target}/?account=continue&lang=en`);
  await completeCaptcha();
  await page.evaluate(() => window.__captchaOptions["expired-callback"]());
  await page
    .getByText("Verification expired. Verify again.", { exact: true })
    .waitFor();
  assert.equal(
    await page
      .getByRole("button", { name: "Continue with Google", exact: true })
      .isDisabled(),
    true,
  );
  assert.equal(
    await page
      .getByRole("button", { name: "Continue with GitHub", exact: true })
      .isDisabled(),
    true,
  );
  await page.getByRole("button", { name: "Verify again", exact: true }).click();
  await page
    .getByRole("button", {
      name: "Complete synthetic verification",
      exact: true,
    })
    .click();
  await page
    .getByText("Verified. Choose Google or GitHub.", { exact: true })
    .waitFor();
  await page
    .getByRole("button", { name: "Continue with GitHub", exact: true })
    .click();
  await page.waitForURL("https://github.com/login/oauth/authorize**");
  assert.equal(authorization.searchParams.has("scope"), false);
  await page.goto(
    `${target}/api/auth/v1/oidc/github/callback?code=fixture-code&state=${authorization.searchParams.get("state")}`,
  );
  await page.locator(".web-account-menu__trigger").waitFor();
  await page
    .getByRole("button", { name: "Save and continue", exact: true })
    .click();
  await page.locator("#project-name").waitFor();
  const accountId = h.db.sqlite.prepare("SELECT id FROM accounts").get().id;
  const policy = h.db.sqlite
    .prepare("SELECT * FROM account_policy_authorizations")
    .get();
  let expectedDraftName = "Same account linking draft";
  await page.locator("#project-name").fill(expectedDraftName);
  const openMenu = async () => {
    const trigger = page.locator(".web-account-menu__trigger");
    if ((await trigger.getAttribute("aria-expanded")) !== "true")
      await trigger.click();
    return page.locator("#web-account-menu-panel");
  };
  const completeProvider = async (provider) => {
    const providerOrigin =
      provider === "github"
        ? "https://github.com/"
        : "https://accounts.google.com/";
    let providerPage;
    for (let attempt = 0; attempt < 200; attempt++) {
      providerPage = context
        .pages()
        .find((candidate) => candidate.url().startsWith(providerOrigin));
      if (providerPage) break;
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
    assert.ok(
      providerPage,
      `Expected a ${provider} authorization page or popup`,
    );
    await providerPage
      .goto(
        `${target}/api/auth/v1/oidc/${provider}/callback?code=fixture-code&${provider === "google" ? "iss=https%3A%2F%2Faccounts.google.com&" : ""}state=${authorization.searchParams.get("state")}`,
      )
      .catch((error) => {
        if (!providerPage.isClosed()) throw error;
      });
    await page.locator(".web-account-menu__trigger").waitFor();
    await page.locator("#project-name").waitFor();
    await page
      .getByText("Complete verification in the other window.", { exact: true })
      .waitFor({ state: "hidden" });
    assert.equal(
      await page.locator("#project-name").inputValue(),
      expectedDraftName,
      "A fresh proof or linked provider for the same account preserves its draft",
    );
  };
  let panel = await openMenu();
  await panel.getByText("GitHub: connected", { exact: true }).waitFor();
  const sessionToken = (await context.cookies()).find(
    (cookie) => cookie.name === "__Host-accreatio_session",
  ).value;
  const sessionResponse = await context.request.get(
    `${target}/api/account/session`,
    { headers: { Cookie: `__Host-accreatio_session=${sessionToken}` } },
  );
  assert.equal(sessionResponse.status(), 200);
  const exportContext = await sessionResponse.json();
  const receipt = await context.request.post(
    `${target}/api/account/authorize`,
    {
      data: {
        operationId: crypto.randomUUID(),
        ownerKey: exportContext.ownerKey,
        sessionKey: exportContext.sessionKey,
      },
      headers: { Cookie: `__Host-accreatio_session=${sessionToken}` },
    },
  );
  assert.equal(receipt.status(), 200);
  await panel
    .getByRole("button", { name: "Connect Google", exact: true })
    .click();
  await panel
    .getByRole("button", { name: "Verify account with GitHub", exact: true })
    .click();
  await completeProvider("github");
  panel = await openMenu();
  await panel
    .getByRole("button", { name: "Connect Google", exact: true })
    .click();
  await completeProvider("google");
  panel = await openMenu();
  await panel.getByText("Google: connected", { exact: true }).waitFor();
  await panel.getByText("GitHub: connected", { exact: true }).waitFor();
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get().n,
    1,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT id FROM accounts").get().id,
    accountId,
  );
  assert.deepEqual(
    h.db.sqlite.prepare("SELECT * FROM account_policy_authorizations").get(),
    policy,
  );
  const linkedToken = (await context.cookies()).find(
    (cookie) => cookie.name === "__Host-accreatio_session",
  ).value;
  const linkedContext = await (
    await context.request.get(`${target}/api/account/session`, {
      headers: { Cookie: `__Host-accreatio_session=${linkedToken}` },
    })
  ).json();
  assert.equal(linkedContext.ownerKey, exportContext.ownerKey);
  assert.notEqual(linkedContext.sessionKey, exportContext.sessionKey);
  await panel.getByText("4 of 5 exports remaining", { exact: true }).waitFor();
  await page.screenshot({
    path: path.join(output, "linked-account-390.png"),
    fullPage: true,
  });
  await panel
    .getByRole("button", { name: "Privacy and my data", exact: true })
    .click();
  const privacyDialog = page.getByRole("dialog", {
    name: "Privacy",
    exact: true,
  });
  await privacyDialog
    .locator("summary")
    .filter({ hasText: "Account data and deletion" })
    .click();
  const downloading = page.waitForEvent("download");
  await privacyDialog
    .getByRole("button", { name: "Verify with GitHub", exact: true })
    .click();
  await completeProvider("github");
  const data = JSON.parse(
    await (
      await import("node:fs/promises")
    ).readFile(await (await downloading).path(), "utf8"),
  );
  assert.equal(data.identities.length, 2);
  assert.equal(data.accountId, accountId);
  assert.equal(data.authorizations.length, 1);
  await privacyDialog
    .getByRole("button", { name: "Close", exact: true })
    .click();
  panel = await openMenu();
  const loggedOut = page.waitForResponse(
    (response) =>
      new URL(response.url()).pathname === "/api/account/logout" &&
      response.request().method() === "POST",
  );
  await panel.getByRole("button", { name: "Sign out", exact: true }).click();
  assert.equal((await loggedOut).status(), 200);
  expectedDraftName = "";
  await page.goto(`${target}/?account=continue&lang=en`);
  await completeCaptcha();
  await page
    .getByRole("button", { name: "Continue with Google", exact: true })
    .click();
  await page.waitForURL("https://accounts.google.com/**");
  await page.goto(
    `${target}/api/auth/v1/oidc/google/callback?code=fixture-code&iss=https%3A%2F%2Faccounts.google.com&state=${authorization.searchParams.get("state")}`,
  );
  await page.locator("#project-name").waitFor();
  assert.equal(
    await page.locator("#project-name").inputValue(),
    "",
    "The same internal account starts blank after explicit logout, including when it returns through another linked provider",
  );
  panel = await openMenu();
  await panel.getByText("4 of 5 exports remaining", { exact: true }).waitFor();
  await panel
    .getByRole("button", { name: "Delete account", exact: true })
    .click();
  await panel
    .getByRole("link", { name: "Manage authorization in GitHub", exact: true })
    .waitFor();
  await panel
    .getByRole("link", { name: "Manage authorization in Google", exact: true })
    .waitFor();
  await panel
    .getByRole("button", { name: "Confirm deletion", exact: true })
    .click();
  await page
    .getByRole("button", {
      name: "Verify Google for account controls",
      exact: true,
    })
    .click();
  await completeProvider("google");
  panel = await openMenu();
  await panel
    .getByRole("button", { name: "Delete account", exact: true })
    .click();
  const deleted = page.waitForResponse(
    (response) =>
      new URL(response.url()).pathname === "/api/account/delete" &&
      response.request().method() === "POST",
  );
  await panel
    .getByRole("button", { name: "Confirm deletion", exact: true })
    .click();
  assert.equal((await deleted).status(), 200);
  await page
    .getByRole("button", { name: "Continue with GitHub", exact: true })
    .waitFor();
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_external_identities")
      .get().n,
    0,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get().n,
    0,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
      .get().n,
    0,
  );
  assert.equal(githubReads, 3);
  assert.deepEqual(pageErrors, []);
  await writeFile(
    path.join(output, "receipt.json"),
    JSON.stringify(
      {
        result: "PASS",
        environment:
          "local Chromium/Edge, real backend/SQLite, synthetic Google and GitHub HTTPS",
        checks: [
          "Google/GitHub equal sign-in hierarchy ES/EN",
          "one explicit shared CAPTCHA gates both providers, expires closed and supports retry",
          "synthetic single-use CAPTCHA server validation; linking and own-data/deletion proof remain independent",
          "320/390/1280 layout",
          "GitHub new sign-in and Google explicit connection",
          "same internal account, policy and shared quota",
          "same-account proof and linking preserve local draft while session markers rotate",
          "both identities in own export",
          "logout and Google stable identity sign-in",
          "explicit logout clears local draft before the same account returns through another provider",
          "both authorization management links",
          "deletion removes linked identities, sessions and receipt",
        ],
        pageErrors,
      },
      null,
      2,
    ),
  );
  console.log(`PASS identity UI: ${output}`);
} catch (error) {
  await page
    ?.screenshot({ path: path.join(output, "failure.png"), fullPage: true })
    .catch(() => {});
  await writeFile(
    path.join(output, "failure.txt"),
    (await page
      ?.locator("body")
      .innerText()
      .catch(() => "unavailable")) ?? "unavailable",
  );
  throw error;
} finally {
  await browser?.close();
  api.closeAllConnections();
  await new Promise((resolve) => api.close(resolve));
  server.kill();
}
