// Run with: node --import tsx scripts/generate-help-slides.mjs
// Rebuilds illustrated SOP cards from the actual local web UI with disposable
// account fixtures. No live account or provider is contacted.
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { chromium } from "playwright";
import { HELP_TIPS } from "../src/components/help/helpContent.ts";

const root = fileURLToPath(new URL("..", import.meta.url));
const port = 4188;
const target = `http://127.0.0.1:${port}`;
const output = path.join(root, "public", "help");
const evidence = path.join(root, ".local", "logs", "playwright", "help-slides");
const keepServer = process.argv.includes("--keep-server");
const useExistingServer = process.argv.includes("--existing-server");
const server = useExistingServer
  ? null
  : spawn(
      process.execPath,
      [
        path.join(root, "node_modules", "vite", "bin", "vite.js"),
        "--mode",
        "web",
        "--host",
        "127.0.0.1",
        "--port",
        String(port),
        "--strictPort",
      ],
      { cwd: root, stdio: "ignore", windowsHide: true },
    );
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function writeAsset(file, data) {
  for (let attempt = 0; ; attempt++) {
    try {
      await writeFile(file, data);
      return;
    } catch (error) {
      if (
        attempt >= 5 ||
        !["UNKNOWN", "EBUSY", "EPERM", "EACCES"].includes(error.code)
      )
        throw error;
      await sleep(200 * (attempt + 1));
    }
  }
}
const escape = (value) =>
  value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
let browser;
let completed = false;
const manifest = {
  schema: 1,
  width: 3840,
  height: 2160,
  source:
    "Actual local accreatio web UI with disposable fictional account/project fixtures",
  generator: "scripts/generate-help-slides.mjs",
  slides: [],
};

async function configure(
  page,
  authenticated = true,
  policyAuthorizationRequired = false,
) {
  await page.route("**/api/auth/v1/methods", (route) =>
    route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({
        version: "auth.v1",
        captcha: { required: true, siteKey: "fixture-site-key" },
        methods: {
          google: { available: true },
          github: { available: true },
          emailOtp: { available: false },
        },
      }),
    }),
  );
  await page.route("**/api/account/**", (route) => {
    if (!authenticated)
      return route.fulfill({
        status: 401,
        contentType: "application/json",
        body: JSON.stringify({
          error: { code: "sign_in_required", message: "Sign in to continue." },
        }),
      });
    const operationId = route.request().postDataJSON()?.operationId;
    const issuedAt = new Date().toISOString();
    return route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({
        email: "example@example.test",
        displayName: "Example",
        ownerKey: `v1:${"a".repeat(64)}`,
        sessionKey: `v1:${"1".repeat(64)}`,
        connectedProviders: ["google", "github"],
        policyAuthorizationRequired,
        expiresAt: new Date(Date.now() + 86400000).toISOString(),
        remaining: 5,
        nextAvailableAt: null,
        ...(operationId
          ? {
              operationId,
              issuedAt,
              retryExpiresAt: new Date(Date.now() + 172800000).toISOString(),
            }
          : {}),
      }),
    });
  });
  const posts = JSON.parse(
    await readFile(
      path.join(root, "content", "blog", "founding-posts.json"),
      "utf8",
    ),
  ).posts;
  await page.route("**/api/blog/posts", (route) =>
    route.fulfill({
      contentType: "application/json",
      body: JSON.stringify({ posts }),
    }),
  );
  await page.route("**/api/admin/blog/**", (route) =>
    route.fulfill({
      status: 401,
      contentType: "application/json",
      body: JSON.stringify({ error: { code: "access_required" } }),
    }),
  );
}

async function capture(page, compositor, locale, id, selector) {
  const source = selector
    ? page.locator(selector).first()
    : page.locator(".app-shell");
  await source.waitFor({ state: "visible" });
  await page.evaluate(() => {
    document.activeElement?.blur();
    window.scrollTo({ top: 0, left: 0, behavior: "instant" });
  });
  await page.waitForTimeout(160);
  const screenshot = await source.screenshot({
    animations: "disabled",
    type: "jpeg",
    quality: 90,
    style:
      selector === ".web-signin"
        ? ".app-header { visibility: hidden !important; }"
        : "",
  });
  await writeFile(
    path.join(evidence, `${locale}-${id}-source.jpg`),
    screenshot,
  );
  const tip = HELP_TIPS.find((item) => item.id === id);
  assert.ok(tip, `Unknown help tip: ${id}`);
  const number = String(HELP_TIPS.indexOf(tip) + 1).padStart(2, "0");
  await compositor.setContent(`<!doctype html><html lang="${locale}"><head><meta charset="utf-8"><style>
    *{box-sizing:border-box}html,body{margin:0;width:3840px;height:2160px;overflow:hidden;font-family:Arial,Helvetica,sans-serif;background:#E8EAE7;color:#303235}
    body{padding:120px;display:grid;grid-template-columns:1120px 1fr;gap:110px;align-items:center}
    .copy{align-self:center} .eyebrow{font-size:44px;letter-spacing:5px;color:#5E655E;margin:0 0 80px;text-transform:uppercase}
    .number{display:block;font-size:160px;color:#E2232A;line-height:1;margin-bottom:50px}h1{font-size:103px;line-height:1.12;letter-spacing:-3px;margin:0 0 70px}
    .instruction{font-size:50px;line-height:1.45;margin:0 0 50px}.detail{font-size:37px;line-height:1.5;color:#515852;margin:0}
    .screen{width:2370px;height:1760px;display:flex;align-items:center;justify-content:center;padding:35px;background:#dce0d9;border:2px solid #c6cdc2;border-radius:42px;box-shadow:0 30px 90px #30323518}
    .screen img{max-width:100%;max-height:100%;object-fit:contain;border-radius:22px;box-shadow:0 12px 50px #30323512}
    .foot{position:absolute;left:120px;right:120px;bottom:50px;display:flex;justify-content:space-between;font-size:28px;color:#5E655E}
  </style></head><body><div class="copy"><p class="eyebrow">accreatio · ${locale === "es" ? "guía paso a paso" : "step-by-step guide"}</p><span class="number">${number}</span><h1>${escape(tip.title[locale])}</h1><p class="instruction">${escape(tip.instruction[locale])}</p><p class="detail">${escape(tip.detail[locale])}</p></div><div class="screen"><img alt="" src="data:image/jpeg;base64,${screenshot.toString("base64")}"></div><div class="foot"><span>${locale === "es" ? "Interfaz real · datos ficticios de ejemplo" : "Actual interface · fictional example data"}</span><span>3840 × 2160 · ${number} / ${HELP_TIPS.length}</span></div></body></html>`);
  await compositor.locator("img").evaluate((img) => img.decode());
  const bounds = await compositor.locator(".copy").boundingBox();
  assert.ok(
    bounds.y >= 60 && bounds.y + bounds.height < 2050,
    `${locale}/${id}: text must fit the 4K card`,
  );
  const file = path.join(output, locale, `${id}.jpg`);
  const rendered = await compositor.screenshot({
    type: "jpeg",
    quality: 85,
    animations: "disabled",
  });
  await writeAsset(file, rendered);
  const bytes = await readFile(file);
  manifest.slides.push({
    locale,
    id,
    path: `${locale}/${id}.jpg`,
    sha256: createHash("sha256").update(bytes).digest("hex"),
    bytes: bytes.length,
  });
  process.stdout.write(`Generated ${locale}/${id} (3840x2160)\n`);
}

try {
  await mkdir(evidence, { recursive: true });
  for (let attempt = 0; ; attempt++) {
    try {
      if ((await fetch(target)).ok) break;
    } catch {}
    if (attempt > 100) throw new Error("Help capture server did not start");
    await sleep(250);
  }
  browser = await chromium.launch({ headless: true });
  const compositor = await browser.newPage({
    viewport: { width: 3840, height: 2160 },
    deviceScaleFactor: 1,
  });
  for (const locale of ["en", "es"]) {
    await mkdir(path.join(output, locale), { recursive: true });
    const context = await browser.newContext({
      viewport: { width: 1440, height: 1080 },
      deviceScaleFactor: 2,
      reducedMotion: "reduce",
    });
    const page = await context.newPage();
    await configure(page);
    await page.goto(`${target}/?view=project&lang=${locale}`);
    await page.locator('[data-question="name"]').waitFor();
    await page
      .locator("#project-name")
      .fill(locale === "es" ? "Herramientas del barrio" : "Neighborhood tools");
    await capture(page, compositor, locale, "name", ".guided-creation");
    await page.locator(".guided-creation__continue").click();
    await page.locator('[data-question="phase"]').waitFor();
    await capture(page, compositor, locale, "phase", ".guided-creation");
    await page
      .getByRole("button", {
        name: locale === "es" ? /Estoy investigando/ : /I'm exploring the idea/,
      })
      .click();
    await page.locator('[data-question="attachments"]').waitFor();
    await capture(page, compositor, locale, "attachments", ".guided-creation");
    await page.locator(".guided-creation__continue").click();
    await page
      .locator("#project-context")
      .fill(
        locale === "es"
          ? "Una biblioteca vecinal de herramientas. Registrar préstamos sin conexión y ver qué herramientas están disponibles."
          : "A neighborhood tool library. Record loans offline and see which tools are available.",
      );
    await capture(page, compositor, locale, "context", ".guided-creation");
    await page.locator(".guided-creation__continue").click();
    await page
      .locator("#project-restrictions")
      .fill(
        locale === "es"
          ? "Sin servicios de pago, cuentas ni datos personales de contacto. Consultar antes de elegir tecnología."
          : "No paid services, accounts or personal contact details. Ask before choosing a technology.",
      );
    await capture(page, compositor, locale, "restrictions", ".guided-creation");
    await page.locator(".guided-creation__continue").click();
    await page.locator('[data-question="review"]').waitFor();
    await capture(page, compositor, locale, "review", ".review-stage");
    await page.locator(".review-stage__advanced").click();
    await page.locator('[data-question="team"]').waitFor();
    await capture(page, compositor, locale, "advanced", ".guided-creation");
    await page.locator(".guided-team__customization > summary").click();
    await page
      .getByRole("button", {
        name: locale === "es" ? "Agregar participante" : "Add participant",
        exact: true,
      })
      .click();
    await capture(page, compositor, locale, "roles", "#project-participants");
    const delivery = page.locator(
      '.creation-stage[aria-labelledby="delivery-title"]',
    );
    await delivery.locator("details > summary").click();
    await capture(
      page,
      compositor,
      locale,
      "guides",
      '.creation-stage[aria-labelledby="delivery-title"]',
    );
    await page.locator(".guided-creation__return").click();
    await page.locator(".review-stage__confirm .start").click();
    await page.locator(".modal-actions .confirm").click();
    await page.locator(".outcome-panel").waitFor();
    await capture(page, compositor, locale, "preview", ".outcome-panel");
    await page.locator(".outcome-panel__actions .start").click();
    await page.locator(".modal").waitFor();
    await capture(page, compositor, locale, "export", ".modal");
    const download = page.waitForEvent("download");
    await page.locator(".modal-actions .confirm").click();
    await download;
    await page.locator(".outcome-next").waitFor();
    await capture(page, compositor, locale, "handoff", ".outcome-panel");
    await page.locator(".web-account-menu__trigger").click();
    await capture(
      page,
      compositor,
      locale,
      "account",
      ".web-account-menu__panel",
    );
    await page.locator(".web-account-menu__trigger").click();
    await capture(page, compositor, locale, "appearance", ".app-header");
    await page.getByRole("button", { name: "Blog", exact: true }).click();
    await capture(page, compositor, locale, "blog", ".blog-experience");
    const access = await context.newPage();
    await configure(access, false);
    await access.goto(`${target}/?view=project&lang=${locale}`);
    await access.locator(".web-signin").waitFor();
    await capture(access, compositor, locale, "access", ".web-signin");
    const authorization = await context.newPage();
    await configure(authorization, true, true);
    await authorization.goto(`${target}/?view=project&lang=${locale}`);
    await authorization.locator("#account-policy-title").waitFor();
    await capture(
      authorization,
      compositor,
      locale,
      "authorization",
      ".web-signin",
    );
    await context.close();
  }
  assert.equal(manifest.slides.length, HELP_TIPS.length * 2);
  await writeFile(
    path.join(output, "manifest.json"),
    `${JSON.stringify(manifest, null, 2)}\n`,
  );
  process.stdout.write(
    `PASS ${manifest.slides.length} bilingual 4K SOP images\n`,
  );
  completed = true;
} catch (error) {
  await writeFile(
    path.join(evidence, "failure.txt"),
    String(error.stack ?? error),
  );
  throw error;
} finally {
  await browser?.close();
  if (server && keepServer && completed) {
    await writeFile(
      path.join(evidence, "preview-server.json"),
      `${JSON.stringify({ url: target, pid: server.pid }, null, 2)}\n`,
    );
    process.stdout.write(
      `Preview available at ${target} (PID ${server.pid}); stop this process after local inspection.\n`,
    );
  } else server?.kill();
}
