import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { chromium } from "playwright";
import { fileURLToPath } from "node:url";

const provenanceUrl = new URL(
  "../assets/branding/accreatio-logo-approved-2026-10-22.provenance.json",
  import.meta.url,
);
const provenance = JSON.parse(await readFile(provenanceUrl, "utf8"));
const source = await readFile(
  new URL(`../${provenance.source.path}`, import.meta.url),
);
assert.equal(
  createHash("sha256").update(source).digest("hex"),
  provenance.source.sha256,
  "The official owner-supplied logo changed. Restore the pinned original; do not redraw or silently replace it.",
);
const dir = new URL("../public/branding/", import.meta.url);
const previewDir = new URL("../.local/logs/playwright/", import.meta.url);
const darkPreviewDir = new URL(
  "../.local/logs/nebula-alignment-20261022/",
  import.meta.url,
);
await mkdir(dir, { recursive: true });
await mkdir(previewDir, { recursive: true });
await mkdir(darkPreviewDir, { recursive: true });
const sourceUrl = `data:image/png;base64,${source.toString("base64")}`;
const browser = await chromium.launch();
const svgUrl = (svg) =>
  `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
// Native masks derive every contour from the approved raster, including icons.
const identityFilter = (id, neutralColor, systemTheme = false) =>
  `<defs><filter id="${id}" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB"><feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 -1.515152 0 0 0 1.303030" result="neutral-alpha"/><feFlood${systemTheme ? ' class="system-neutral"' : ""} flood-color="${neutralColor}" result="pearl"/><feComposite in="pearl" in2="neutral-alpha" operator="in" result="pearl-ink"/><feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1.5 -1.5 0 0 -0.04" result="red-alpha"/><feFlood flood-color="${provenance.palette.red}" result="red"/><feComposite in="red" in2="red-alpha" operator="in" result="red-ink"/><feMerge><feMergeNode in="pearl-ink"/><feMergeNode in="red-ink"/></feMerge></filter></defs>`;

try {
  const cropPage = await browser.newPage();
  // Integer canvas crops retain the supplied pixels and custom lettering.
  // The master and PNG crops retain their original pearl texture.
  const crops = await cropPage.evaluate(
    async ({ sourceUrl, sourceSize, rectangles }) => {
      const image = new Image();
      image.src = sourceUrl;
      await image.decode();
      if (
        image.naturalWidth !== sourceSize.width ||
        image.naturalHeight !== sourceSize.height
      )
        throw new Error("Official logo dimensions do not match provenance.");
      return Object.fromEntries(
        Object.entries(rectangles).map(([name, { x, y, width, height }]) => {
          const canvas = document.createElement("canvas");
          canvas.width = width;
          canvas.height = height;
          const context = canvas.getContext("2d");
          if (!context) throw new Error("Canvas is unavailable.");
          context.drawImage(image, x, y, width, height, 0, 0, width, height);
          return [name, canvas.toDataURL("image/png")];
        }),
      );
    },
    {
      sourceUrl,
      sourceSize: provenance.source,
      rectangles: provenance.crops,
    },
  );
  const displayLockup = await cropPage.evaluate(async (source) => {
    const image = new Image();
    image.src = source;
    await image.decode();
    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth / 2;
    canvas.height = image.naturalHeight / 2;
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Canvas is unavailable.");
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = "high";
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/png");
  }, crops.lockup);
  const faviconRaster = await cropPage.evaluate(
    async ({ source, pearl }) => {
      const image = new Image();
      image.src = source;
      await image.decode();
      const canvas = document.createElement("canvas");
      canvas.width = 64;
      canvas.height = 64;
      const context = canvas.getContext("2d");
      if (!context) throw new Error("Canvas is unavailable.");
      // Pad in pearl before filtering so mask constants cannot fill transparent
      // input margins. The output favicon still has a fully transparent plate.
      context.fillStyle = pearl;
      context.fillRect(0, 0, 64, 64);
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = "high";
      const height = 60;
      const width = (image.naturalWidth / image.naturalHeight) * height;
      context.drawImage(image, (64 - width) / 2, 2, width, height);
      return canvas.toDataURL("image/png");
    },
    { source: crops.mark, pearl: provenance.palette.pearl },
  );
  await cropPage.close();

  const asset = (name, fullResolution = false, theme = "light") => {
    const scaled = name === "lockup" && !fullResolution;
    const width = provenance.crops[name].width / (scaled ? 2 : 1);
    const height = provenance.crops[name].height / (scaled ? 2 : 1);
    // Owner-authorized transparent adaptations (dark: 2026-10-22;
    // light: 2026-10-25) key the pale plate from the approved raster.
    // No logo geometry is drawn.
    // Red-channel darkness isolates charcoal strokes without a pale fringe
    // around the red dot; R-G chroma independently retains the dot contour.
    // The sRGB thresholds discard the original paper's faint texture fully.
    const filterId = `${theme}-identity`;
    const filter = identityFilter(
      filterId,
      theme === "dark" ? provenance.palette.pearl : provenance.palette.charcoal,
    );
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" role="img" aria-labelledby="title"><title id="title">accreatio official ${name} — ${theme} surface adaptation</title>${filter}<image width="${width}" height="${height}" filter="url(#${filterId})" href="${scaled ? displayLockup : crops[name]}"/></svg>`;
  };
  for (const name of Object.keys(provenance.crops)) {
    await writeFile(
      new URL(`accreatio-${name}.png`, dir),
      Buffer.from(crops[name].split(",")[1], "base64"),
    );
    // Both theme wrappers embed the same approved crop and native filters.
    for (const theme of ["light", "dark"])
      await writeFile(
        new URL(`accreatio-${name}-${theme}.svg`, dir),
        asset(name, false, theme),
      );
  }

  const favicon = `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64" role="img" aria-labelledby="title"><title id="title">accreatio official favicon</title><style>.system-neutral{flood-color:${provenance.palette.charcoal}}@media(prefers-color-scheme:dark){.system-neutral{flood-color:${provenance.palette.pearl}}}</style>${identityFilter("favicon-identity", provenance.palette.charcoal, true)}<image width="64" height="64" filter="url(#favicon-identity)" href="${faviconRaster}"/></svg>`;
  await writeFile(new URL("accreatio-favicon-v2.svg", dir), favicon);
  const faviconPage = await browser.newPage({
    viewport: { width: 32, height: 32 },
    colorScheme: "light",
    deviceScaleFactor: 1,
  });
  await faviconPage.setContent(
    `<style>html,body{margin:0;background:transparent}img{display:block;width:32px;height:32px}</style><img src="${svgUrl(favicon)}" alt="accreatio">`,
  );
  await faviconPage.locator("img").evaluate((image) => image.decode());
  await faviconPage.screenshot({
    path: fileURLToPath(new URL("accreatio-favicon-v2-32.png", dir)),
    omitBackground: true,
  });
  await faviconPage.close();

  for (const colorScheme of ["light", "dark"]) {
    const faviconPreview = await browser.newPage({
      viewport: { width: 600, height: 240 },
      colorScheme,
      deviceScaleFactor: 1,
    });
    await faviconPreview.setContent(
      `<style>html,body{margin:0}body{height:240px;display:flex;align-items:center;justify-content:center;gap:60px;background:${colorScheme === "dark" ? "#242726" : provenance.palette.pearl};color:${colorScheme === "dark" ? provenance.palette.pearl : provenance.palette.charcoal};font:14px sans-serif}span{display:grid;justify-items:center;align-content:center;gap:16px;height:120px}img{display:block}</style>${[16, 32, 64].map((size) => `<span><img width="${size}" height="${size}" src="${svgUrl(favicon)}" alt="accreatio favicon ${size}px">${size}px · ${colorScheme}</span>`).join("")}`,
    );
    await faviconPreview
      .locator("img")
      .evaluateAll((images) =>
        Promise.all(images.map((image) => image.decode())),
      );
    await faviconPreview.screenshot({
      path: fileURLToPath(
        new URL(`favicon-${colorScheme}-preview.png`, darkPreviewDir),
      ),
    });
    await faviconPreview.close();
  }

  const preview = await browser.newPage({
    viewport: { width: 1200, height: 760 },
    deviceScaleFactor: 1,
  });
  await preview.setContent(
    `<style>*{box-sizing:border-box}html,body{margin:0}body{display:flex;width:1200px;height:760px}section{width:600px;height:760px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:50px;background:#242726}section.light{background:${provenance.palette.pearl}}img.mark{width:180px;height:auto}img.lockup{width:520px;height:auto}</style><section><img class="mark" src="${svgUrl(asset("mark", false, "dark"))}" alt="Official accreatio symbol"><img class="lockup" src="${svgUrl(asset("lockup", false, "dark"))}" alt="Official accreatio logo"></section><section class="light"><img class="mark" src="${svgUrl(asset("mark"))}" alt="Official accreatio symbol"><img class="lockup" src="${svgUrl(asset("lockup"))}" alt="Official accreatio logo"></section>`,
  );
  await preview.screenshot({
    path: fileURLToPath(
      new URL("official-branding-reference-preview.png", previewDir),
    ),
  });
  await preview.close();

  const darkPreview = await browser.newPage({
    viewport: { width: 1200, height: 700 },
    deviceScaleFactor: 1,
  });
  await darkPreview.setContent(
    `<style>*{box-sizing:border-box}html,body{margin:0}body{font:14px sans-serif;color:${provenance.palette.pearl};display:flex}section{width:600px;height:700px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:46px;background:#242726}section.charcoal{background:#303235}.mark{width:160px}.wordmark{width:470px}.lockup{width:520px}img{height:auto}</style>${["", "charcoal"].map((className) => `<section class="${className}"><span>${className ? "#303235" : "#242726"} · transparent dark identity</span><img class="mark" src="${svgUrl(asset("mark", false, "dark"))}" alt="Official accreatio symbol"><img class="wordmark" src="${svgUrl(asset("wordmark", false, "dark"))}" alt="Official accreatio lettering"><img class="lockup" src="${svgUrl(asset("lockup", false, "dark"))}" alt="Official accreatio logo"></section>`).join("")}`,
  );
  await darkPreview.screenshot({
    path: fileURLToPath(
      new URL("dark-logo-transparent-preview.png", darkPreviewDir),
    ),
  });
  await darkPreview.close();

  const lightPreview = await browser.newPage({
    viewport: { width: 1200, height: 700 },
    deviceScaleFactor: 1,
  });
  await lightPreview.setContent(
    `<style>*{box-sizing:border-box}html,body{margin:0}body{font:14px sans-serif;color:${provenance.palette.charcoal};display:flex}section{width:600px;height:700px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:46px;background:#e8eae7}section.surface{background:#dde1d8}.mark{width:160px}.wordmark{width:470px}.lockup{width:520px}img{height:auto}</style>${["", "surface"].map((className) => `<section class="${className}"><span>${className ? "#dde1d8" : "#e8eae7"} · transparent light identity</span><img class="mark" src="${svgUrl(asset("mark"))}" alt="Official accreatio symbol"><img class="wordmark" src="${svgUrl(asset("wordmark"))}" alt="Official accreatio lettering"><img class="lockup" src="${svgUrl(asset("lockup"))}" alt="Official accreatio logo"></section>`).join("")}`,
  );
  await lightPreview.screenshot({
    path: fileURLToPath(
      new URL("light-logo-transparent-preview-20261025.png", previewDir),
    ),
  });
  await lightPreview.close();

  for (const size of [192, 512]) {
    const page = await browser.newPage({
      viewport: { width: size, height: size },
      deviceScaleFactor: 1,
    });
    await page.setContent(
      `<style>html,body{margin:0;width:100%;height:100%;background:${provenance.palette.pearl}}body{display:grid;place-items:center}img{width:86%;height:86%;object-fit:contain}</style><img src="${svgUrl(asset("mark"))}" alt="Official accreatio symbol">`,
    );
    await page.screenshot({
      path: fileURLToPath(new URL(`accreatio-web-${size}.png`, dir)),
    });
    await page.close();
  }
  const social = await browser.newPage({
    viewport: { width: 1200, height: 630 },
    deviceScaleFactor: 1,
  });
  await social.setContent(
    `<style>html,body{margin:0;width:100%;height:100%;background:${provenance.palette.pearl}}body{display:grid;place-items:center}img{width:1000px;height:auto}</style><img src="${svgUrl(asset("lockup", true))}" alt="Official accreatio logo">`,
  );
  await social.screenshot({
    path: fileURLToPath(new URL("accreatio-web-social.png", dir)),
  });
  await social.close();
  console.log(
    "PASS official accreatio logo: pinned source, 3 exact PNG crops, proportional 631x155 display lockup, 6 transparent light/dark SVG filter adaptations, system-theme SVG favicon and transparent 32px PNG fallback, 2 PWA icons and full-resolution social preview.",
  );
} finally {
  await browser.close();
}
