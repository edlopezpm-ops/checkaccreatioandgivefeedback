import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { createServer } from "node:http";
import { mkdir, mkdtemp, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { parseArgs } from "node:util";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

// Exercise real generated workers in a disposable browser. The local bootstrap
// installs them without opening an account, provider or user-owned browser data.
const { values } = parseArgs({
  options: {
    "legacy-dir": { type: "string" },
    "candidate-dir": { type: "string", default: "dist" },
  },
});
assert.ok(
  values["legacy-dir"],
  "Usage: node scripts/pwa-legal-smoke.mjs --legacy-dir <previous web build> [--candidate-dir dist]",
);
const root = fileURLToPath(new URL("../", import.meta.url));
await mkdir(path.join(root, ".local/logs"), { recursive: true });
const evidence = await mkdtemp(path.join(root, ".local/logs/pwa-legal-"));
const digest = (bytes) => createHash("sha256").update(bytes).digest("hex");
const legalNames = ["terms", "privacy", "cookies", "faq"];
const bundles = {};
for (const name of ["legacy", "candidate"]) {
  const directory = path.resolve(root, values[`${name}-dir`]);
  const worker = await readFile(path.join(directory, "sw.js"));
  const documents = {};
  for (const legal of legalNames)
    documents[legal] = await readFile(
      path.join(directory, "legal", `${legal}.html`),
      "utf8",
    );
  bundles[name] = { directory, worker, documents };
}
assert.notEqual(
  digest(bundles.legacy.worker),
  digest(bundles.candidate.worker),
  "Use separately built legacy and candidate workers",
);
assert.notEqual(
  bundles.legacy.documents.terms,
  bundles.candidate.documents.terms,
  "Legacy and candidate Terms must differ to reproduce stale delivery",
);

let workerStage = "legacy";
let documentStage = "legacy";
let delivery = "online";
const futureMarker = "LOCAL-FUTURE-LEGAL-REVISION";
const legalRequests = [];
const bootstrap = `<!doctype html><title>Local worker fixture</title><script>navigator.serviceWorker.register('/sw.js')</script>`;
const failureBody = "Legal document unavailable (local fixture)";
const server = createServer(async (request, response) => {
  const url = new URL(request.url, "http://localhost");
  if (url.pathname === "/__pwa_legal_fixture__") {
    response.writeHead(200, {
      "Content-Type": "text/html",
      "Cache-Control": "no-store",
    });
    return response.end(bootstrap);
  }
  if (
    /^\/legal(?:\/|$)/.test(url.pathname) &&
    !/\.(?:css|js)$/.test(url.pathname)
  ) {
    const legal = url.pathname.match(
      /^\/legal\/(terms|privacy|cookies|faq)(?:\.html)?$/,
    )?.[1];
    const status = legal ? (delivery === "unavailable" ? 503 : 200) : 404;
    let body = failureBody;
    if (status === 200) {
      body =
        bundles[documentStage === "future" ? "candidate" : documentStage]
          .documents[legal];
      if (documentStage === "future")
        body = body.replace(
          "</body>",
          `<p data-legal-fixture>${futureMarker}:${legal}</p></body>`,
        );
    }
    legalRequests.push({
      route: url.pathname,
      status,
      documentStage,
      bodyHash: digest(body),
    });
    response.writeHead(status, {
      "Content-Type": "text/html; charset=utf-8",
      // Match the existing production legal-document revalidation policy.
      "Cache-Control": "public, max-age=0, must-revalidate, no-transform",
    });
    return response.end(body);
  }
  const bundle = bundles[workerStage];
  const relative = url.pathname === "/" ? "index.html" : url.pathname.slice(1);
  const target = path.resolve(bundle.directory, relative);
  if (!target.startsWith(bundle.directory + path.sep)) {
    response.writeHead(403);
    return response.end();
  }
  try {
    const bytes = await readFile(target);
    response.writeHead(200, {
      "Content-Type":
        {
          ".html": "text/html",
          ".js": "application/javascript",
          ".css": "text/css",
          ".json": "application/json",
          ".svg": "image/svg+xml",
          ".png": "image/png",
          ".webmanifest": "application/manifest+json",
        }[path.extname(target)] ?? "application/octet-stream",
      "Cache-Control": "no-cache",
    });
    response.end(bytes);
  } catch {
    response.writeHead(404);
    response.end();
  }
});
await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ serviceWorkers: "allow" });
context.setDefaultTimeout(15_000);
const page = await context.newPage();
const receipt = {
  result: "RUNNING",
  scope:
    "Local generated-worker lifecycle and legal routing; no account or provider",
  bundles: Object.fromEntries(
    Object.entries(bundles).map(([name, bundle]) => [
      name,
      {
        directory: bundle.directory,
        workerSha256: digest(bundle.worker),
        termsSha256: digest(bundle.documents.terms),
      },
    ]),
  ),
  legalRequests,
};
const legalCacheEntries = () =>
  page.evaluate(async () => {
    const entries = [];
    for (const name of await caches.keys()) {
      const cache = await caches.open(name);
      for (const request of await cache.keys())
        if (/\/legal\/.*\.html$/.test(new URL(request.url).pathname))
          entries.push({ name, url: request.url });
    }
    return entries;
  });
const assertNetworkDocument = async (route, expected) => {
  const response = await page.goto(`${origin}${route}`);
  assert.equal(response.status(), 200, route);
  assert.equal(
    response.fromServiceWorker(),
    false,
    `${route} must use network`,
  );
  assert.equal(
    await response.text(),
    expected,
    `${route} must show current bytes`,
  );
  assert.ok(
    await page.evaluate(() => Boolean(navigator.serviceWorker.controller)),
  );
};

try {
  await page.goto(`${origin}/__pwa_legal_fixture__`);
  await page.evaluate(() =>
    Promise.race([
      navigator.serviceWorker.ready,
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Legacy worker not ready")), 15_000),
      ),
    ]),
  );
  let response = await page.goto(`${origin}/legal/terms`);
  assert.ok(
    await page.evaluate(() => Boolean(navigator.serviceWorker.controller)),
  );
  assert.equal(response.fromServiceWorker(), true);
  assert.equal(await response.text(), bundles.legacy.documents.terms);
  const legacyEntries = await legalCacheEntries();
  assert.equal(legacyEntries.length, legalNames.length);

  // A deployed document alone cannot repair an already controlling old worker.
  documentStage = "candidate";
  const before = legalRequests.length;
  response = await page.goto(`${origin}/legal/terms`);
  assert.equal(await response.text(), bundles.legacy.documents.terms);
  assert.equal(response.fromServiceWorker(), true);
  assert.equal(legalRequests.length, before);
  receipt.baseline = {
    staleTermsReproduced: true,
    legalPrecacheEntries: legacyEntries.length,
    documentNetworkRequests: 0,
  };

  workerStage = "candidate";
  await page.evaluate(async () => {
    const registration = await navigator.serviceWorker.getRegistration();
    const previous = registration.active;
    await registration.update();
    await new Promise((resolve, reject) => {
      const deadline = Date.now() + 15_000;
      const timer = setInterval(() => {
        if (
          registration.active !== previous &&
          registration.active?.state === "activated"
        ) {
          clearInterval(timer);
          resolve();
        } else if (Date.now() > deadline) {
          clearInterval(timer);
          reject(new Error("Replacement worker did not activate"));
        }
      }, 25);
    });
  });
  assert.deepEqual(
    await legalCacheEntries(),
    [],
    "Legal HTML must leave the service-worker cache when the replacement activates",
  );
  response = await page.reload();
  assert.equal(response.fromServiceWorker(), false);
  assert.equal(await response.text(), bundles.candidate.documents.terms);
  receipt.recovery = {
    replacementActivated: true,
    legalPrecacheEntries: 0,
    deliberateReloadShowsCurrentTerms: true,
  };

  for (const legal of legalNames)
    for (const suffix of ["", ".html?legal-check=current"])
      await assertNetworkDocument(
        `/legal/${legal}${suffix}`,
        bundles.candidate.documents[legal],
      );

  // Serve a later document revision without changing any worker/bundle byte.
  documentStage = "future";
  for (const legal of legalNames)
    for (const suffix of ["", ".html?legal-check=future"])
      await assertNetworkDocument(
        `/legal/${legal}${suffix}`,
        bundles.candidate.documents[legal].replace(
          "</body>",
          `<p data-legal-fixture>${futureMarker}:${legal}</p></body>`,
        ),
      );
  assert.equal(
    digest(await readFile(path.join(bundles.candidate.directory, "sw.js"))),
    receipt.bundles.candidate.workerSha256,
  );
  for (const route of ["/legal", "/legal?missing=1", "/legal/not-present"]) {
    response = await page.goto(`${origin}${route}`);
    assert.equal(response.status(), 404, route);
    assert.equal(response.fromServiceWorker(), false, route);
    assert.equal(await response.text(), failureBody);
  }
  delivery = "unavailable";
  response = await page.goto(`${origin}/legal/terms`);
  assert.equal(response.status(), 503);
  assert.equal(response.fromServiceWorker(), false);
  assert.equal(await response.text(), failureBody);
  delivery = "online";
  receipt.online = {
    currentRoutes: 8,
    futureRoutesWithoutWorkerChange: 8,
    unknownRoutesReturn404: 3,
    unavailableReturns503: true,
  };

  await context.setOffline(true);
  for (const legal of legalNames)
    for (const suffix of ["", ".html?legal-check=future"]) {
      // Each failed navigation has its own tab so Chromium's asynchronous
      // network-error document cannot interrupt the following navigation.
      const offlinePage = await context.newPage();
      try {
        await assert.rejects(
          offlinePage.goto(`${origin}/legal/${legal}${suffix}`),
          /ERR_INTERNET_DISCONNECTED|ERR_FAILED/,
          "Offline legal navigation must fail instead of showing cached Terms or the app shell",
        );
      } finally {
        await offlinePage.close();
      }
    }
  const offlineApp = await context.newPage();
  try {
    response = await offlineApp.goto(`${origin}/local-app-route`);
    assert.equal(response.fromServiceWorker(), true);
    assert.equal(
      await response.text(),
      await readFile(
        path.join(bundles.candidate.directory, "index.html"),
        "utf8",
      ),
      "Unrelated app-shell offline fallback remains available",
    );
  } finally {
    await offlineApp.close();
  }
  receipt.offline = { legalNavigationsFail: 8, appShellFallbackRetained: true };
  await context.setOffline(false);

  const fresh = await browser.newContext({ serviceWorkers: "allow" });
  try {
    const freshPage = await fresh.newPage();
    await freshPage.goto(`${origin}/__pwa_legal_fixture__`);
    await freshPage.evaluate(() =>
      Promise.race([
        navigator.serviceWorker.ready,
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error("Fresh worker not ready")), 15_000),
        ),
      ]),
    );
    response = await freshPage.goto(`${origin}/legal/terms`);
    assert.equal(response.fromServiceWorker(), false);
    assert.match(await response.text(), new RegExp(futureMarker));
    receipt.freshClient = { currentDocumentFromNetwork: true };
  } finally {
    await fresh.close();
  }
  receipt.result = "PASS";
  process.stdout.write(
    `PASS PWA legal delivery: legacy stale response reproduced; replacement removes legal precache; later revisions use network without a new worker; offline/503/404 do not substitute old legal HTML. Evidence: ${evidence}\n`,
  );
} catch (error) {
  receipt.result = "FAIL";
  receipt.failure = String(error);
  throw error;
} finally {
  await writeFile(
    path.join(evidence, "receipt.json"),
    JSON.stringify(receipt, null, 2),
  );
  await browser.close();
  await new Promise((resolve) => server.close(resolve));
}
