import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { chromium } from "playwright";
import { fileURLToPath } from "node:url";
import path from "node:path";
import {
  minimalDocx,
  assertSameDocxParts,
} from "./attachment-smoke-fixtures.mjs";
import {
  checkNebulaInteraction,
  backQuestion,
  checkGuidedJourney,
  checkNightTheme,
  checkProjectSummary,
  confirmReview,
  continueQuestion,
  expectQuestion,
  finishGuidedQuestions,
  inspectProjectZip,
  observeNebula,
} from "./guided-creation-functional-smoke.mjs";

const PORT = 4175;
const TARGET_URL = `http://127.0.0.1:${PORT}`;
const ROOT = fileURLToPath(new URL("..", import.meta.url));
const BLOG_POSTS = JSON.parse(
  readFileSync(path.join(ROOT, "content/blog/founding-posts.json"), "utf8"),
).posts;
const WEBGL_CANVAS = ".atmosphere__webgl canvas";
const STAR_CANVAS = ".atmosphere__starfield";
const preview = spawn(
  process.execPath,
  [
    path.join(ROOT, "node_modules", "vite", "bin", "vite.js"),
    "preview",
    "--host",
    "127.0.0.1",
    "--port",
    String(PORT),
    "--strictPort",
  ],
  { cwd: ROOT, stdio: "ignore", windowsHide: true },
);
const waitForServer = async () => {
  const deadline = Date.now() + 30_000;
  while (Date.now() < deadline) {
    try {
      if ((await fetch(TARGET_URL)).ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error("Preview server did not start");
};

const configureBlogApi = async (
  page,
  { canPublish = false, accountAuthenticated = true, adminStatus = 200 } = {},
) => {
  const exportReceipts = new Map();
  let postsRequests = 0;
  let adminRequests = 0;
  let releaseAdmin;
  const adminPending = new Promise((resolve) => {
    releaseAdmin = resolve;
  });
  // Baseline UI scenarios use a stable account fixture; the separate account
  // smoke exercises the real ledger and exhausted-quota flow.
  await page.route("**/api/auth/v1/methods", (route) =>
    route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({
        version: "auth.v1",
        methods: {
          google: { available: true },
          github: { available: true },
          emailOtp: { available: false },
        },
      }),
    }),
  );
  await page.route("**/api/account/**", (route) => {
    if (!accountAuthenticated)
      return route.fulfill({
        status: 401,
        contentType: "application/json",
        body: JSON.stringify({
          error: { code: "sign_in_required", message: "Sign in to continue." },
        }),
      });
    const action = new URL(route.request().url()).pathname.split("/").at(-1);
    if (action === "identity")
      return route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({ email: "ui-fixture@example.test" }),
      });
    const body = route.request().postData();
    const operationId = body ? JSON.parse(body).operationId : undefined;
    if (operationId && !exportReceipts.has(operationId)) {
      const issuedAt = new Date().toISOString();
      exportReceipts.set(operationId, {
        operationId,
        issuedAt,
        retryExpiresAt: new Date(
          Date.parse(issuedAt) + 172_800_000,
        ).toISOString(),
      });
    }
    return route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({
        email: "ui-fixture@example.test",
        ownerKey: `v1:${"a".repeat(64)}`,
        sessionKey: `v1:${"1".repeat(64)}`,
        connectedProviders: ["google"],
        policyAuthorizationRequired: false,
        expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
        remaining: 5,
        nextAvailableAt: null,
        ...(operationId ? exportReceipts.get(operationId) : {}),
      }),
    });
  });
  await page.route("**/api/blog/posts", (route) => {
    postsRequests += 1;
    return route.fulfill({
      body: JSON.stringify({ posts: BLOG_POSTS }),
      contentType: "application/json",
      headers: { "Cache-Control": "no-store" },
      status: 200,
    });
  });
  await page.route("**/api/admin/blog/session", async (route) => {
    adminRequests++;
    if (adminStatus === "pending") await adminPending;
    return route.fulfill({
      body: JSON.stringify(
        adminStatus === 401
          ? { error: { code: "access_required" } }
          : {
              actor: canPublish ? { kind: "human", label: "Ed Lopez" } : null,
              canPublish,
            },
      ),
      contentType: "application/json",
      headers: { "Cache-Control": "no-store" },
      status: adminStatus === "pending" ? 401 : adminStatus,
    });
  });
  await page.route("**/api/admin/blog/posts", async (route) => {
    if (!canPublish)
      return route.fulfill({
        status: 403,
        contentType: "application/json",
        body: "{}",
      });
    const request = route.request();
    const payload = request.postDataJSON();
    await route.fulfill({
      body: JSON.stringify({
        post: {
          ...payload,
          id: "d73eed89-7fa8-4af6-8f4f-43eef0b958c1",
          publishedAt: "2026-08-06T12:00:00.000Z",
          slug: "visual-smoke-post",
        },
      }),
      contentType: "application/json",
      headers: { "Cache-Control": "no-store" },
      status: 201,
    });
  });
  return {
    postsRequestCount: () => postsRequests,
    adminRequestCount: () => adminRequests,
    releaseAdminCheck: () => releaseAdmin(),
  };
};

const canvasPixelFingerprint = (page, selector) =>
  page.locator(selector).evaluate(async (element) => {
    if (!(element instanceof HTMLCanvasElement)) {
      throw new Error("Expected a canvas element");
    }
    const context = element.getContext("2d");
    if (!context) throw new Error("Expected a 2D canvas context");
    const pixels = context.getImageData(
      0,
      0,
      element.width,
      element.height,
    ).data;
    const digest = await crypto.subtle.digest("SHA-256", pixels);
    return {
      digest: Array.from(new Uint8Array(digest), (byte) =>
        byte.toString(16).padStart(2, "0"),
      ).join(""),
      height: element.height,
      width: element.width,
    };
  });

const readSavedDraft = (page) =>
  page.evaluate(
    () =>
      new Promise((resolve, reject) => {
        const request = indexedDB.open("accreatio-drafts");
        request.onerror = () => reject(request.error);
        request.onsuccess = () => {
          const database = request.result;
          const get = database
            .transaction("drafts", "readonly")
            .objectStore("drafts")
            .get("account-current:v1");
          get.onerror = () => {
            database.close();
            reject(get.error);
          };
          get.onsuccess = () => {
            database.close();
            resolve(get.result);
          };
        };
      }),
  );

const workingContext = (page) =>
  page.evaluate(() => {
    const surface = document.querySelector(
      ".guided-creation, .blog-experience",
    );
    return {
      url: location.href,
      question: surface
        ?.querySelector("[data-question]")
        ?.getAttribute("data-question"),
      fields: Array.from(
        surface?.querySelectorAll("input, textarea, select") ?? [],
        (field) => ({
          id: field.id,
          value: field.value,
          checked: field.checked,
        }),
      ),
      attachments: Array.from(
        surface?.querySelectorAll(".attachment-ready") ?? [],
        (row) => row.textContent,
      ),
      articles: Array.from(
        surface?.querySelectorAll(".blog-post h2") ?? [],
        (heading) => heading.textContent,
      ),
    };
  });

async function checkNoExtraHelp(page) {
  assert.equal(await page.locator(".blog-page .project-help__link").count(), 0);
  const before = await workingContext(page);
  const accountTrigger = page.locator(".web-account-menu__trigger");
  await accountTrigger.click();
  const account = page.locator("#web-account-menu-panel");
  await account.waitFor();
  assert.equal(
    await account.getByRole("link", { name: /^(?:help|ayuda)$/i }).count(),
    0,
    "The user menu has no contextual help entry",
  );
  assert.equal(await account.locator(".project-help__link").count(), 0);
  await page.keyboard.press("Escape");
  await account.waitFor({ state: "detached" });
  assert.deepEqual(await workingContext(page), before);
}

async function checkContextualHelp(page, topic) {
  const before = await workingContext(page);
  const help = page.locator(".project-help__link");
  await help.click();
  const popup = page.getByRole("dialog", {
    name: "Step-by-step help",
    exact: true,
  });
  await popup.waitFor();
  const image = popup.locator(".help-tips__slide img");
  assert.equal(await image.getAttribute("src"), `/help/en/${topic}.jpg`);
  await image.evaluate((element) => element.decode());
  assert.deepEqual(
    await image.evaluate((element) => [
      element.naturalWidth,
      element.naturalHeight,
    ]),
    [3840, 2160],
  );
  assert.deepEqual(await workingContext(page), before);
  await page.keyboard.press("Escape");
  await popup.waitFor({ state: "detached" });
  assert.equal(
    await help.evaluate((element) => element === document.activeElement),
    true,
  );
  assert.deepEqual(await workingContext(page), before);
}

async function checkPublicExample(page, locale = "en") {
  const es = locale === "es";
  const label = es ? "Ver un ejemplo" : "See an example";
  const trigger = page.getByRole("link", { name: label, exact: true });
  const beforeUrl = page.url();
  const beforeHeading = await page.locator("#onboarding-title").innerText();
  const beforeProgress = await page.locator(".onboarding-progress").innerText();
  assert.equal(await trigger.count(), 1);
  assert.equal(await trigger.getAttribute("href"), "#example-guide");
  assert.equal(
    await page.getByRole("button", { name: label, exact: true }).count(),
    0,
    "The public example is a hyperlink, not a button",
  );
  const width = page.viewportSize().width;
  const scrollbarStyle =
    width < 768
      ? await page.addStyleTag({
          content: "html{scrollbar-gutter:stable;overflow-y:scroll}",
        })
      : null;
  await trigger.click();
  const example = page.getByRole("dialog", {
    name: es ? "Cómo funciona accreatio" : "How accreatio works",
    exact: true,
  });
  await example.waitFor();
  assert.equal(await example.getAttribute("id"), "example-guide");
  assert.equal(await example.getByRole("link").count(), 0);
  assert.equal(page.url(), beforeUrl);
  assert.equal(
    await page.locator("#onboarding-title").innerText(),
    beforeHeading,
  );
  assert.equal(
    await page.locator(".onboarding-progress").innerText(),
    beforeProgress,
  );
  const image = example.locator(".help-tips__slide img");
  await image.evaluate((element) => element.decode());
  assert.deepEqual(
    await image.evaluate((element) => [
      element.naturalWidth,
      element.naturalHeight,
    ]),
    [3840, 2160],
  );
  const previous = example.getByRole("button", {
    name: es ? "Tip anterior" : "Previous tip",
    exact: true,
  });
  const next = example.getByRole("button", {
    name: es ? "Siguiente tip" : "Next tip",
    exact: true,
  });
  assert.equal(await previous.isEnabled(), false);
  assert.equal(await next.isEnabled(), true);
  const [visualBounds, imageBounds, previousBounds, nextBounds, counterBounds] =
    await Promise.all([
      example.locator(".help-tips__visual").boundingBox(),
      image.boundingBox(),
      previous.boundingBox(),
      next.boundingBox(),
      example.locator(".help-tips__position").boundingBox(),
    ]);
  const imageMiddle = imageBounds.y + imageBounds.height / 2;
  for (const bounds of [previousBounds, nextBounds]) {
    assert.ok(
      bounds.x >= visualBounds.x - 1 &&
        bounds.x + bounds.width <= visualBounds.x + visualBounds.width + 1 &&
        Math.abs(bounds.y + bounds.height / 2 - imageMiddle) < 2,
      "Carousel controls stay inside the visual frame, centered on the image sides",
    );
  }
  const imageCenter = imageBounds.x + imageBounds.width / 2;
  assert.ok(previousBounds.x + previousBounds.width / 2 < imageCenter);
  assert.ok(nextBounds.x + nextBounds.width / 2 > imageCenter);
  if (width >= 600) {
    assert.ok(previousBounds.x + previousBounds.width <= imageBounds.x + 1);
    assert.ok(nextBounds.x >= imageBounds.x + imageBounds.width - 1);
  }
  assert.ok(counterBounds.y >= imageBounds.y + imageBounds.height - 1);
  const geometry = await example.evaluate((element) => {
    const bounds = element.getBoundingClientRect();
    return {
      left: bounds.left,
      right: bounds.right,
      clientWidth: document.documentElement.clientWidth,
      innerWidth,
    };
  });
  if (scrollbarStyle) assert.ok(geometry.clientWidth < geometry.innerWidth);
  assert.ok(
    geometry.left >= 0 && geometry.right <= geometry.clientWidth,
    `Example dialog must fit the actual client area: ${JSON.stringify(geometry)}`,
  );
  const firstTip = await image.getAttribute("src");
  const firstCount = await example.locator(".help-tips__position").innerText();
  await next.click();
  assert.notEqual(await image.getAttribute("src"), firstTip);
  assert.notEqual(
    await example.locator(".help-tips__position").innerText(),
    firstCount,
  );
  await previous.click();
  assert.equal(await image.getAttribute("src"), firstTip);
  assert.equal(
    await example.locator(".help-tips__position").innerText(),
    firstCount,
  );
  assert.equal(page.url(), beforeUrl);
  await page.keyboard.press("Escape");
  await example.waitFor({ state: "detached" });
  assert.equal(
    await trigger.evaluate((element) => element === document.activeElement),
    true,
  );
  assert.equal(page.url(), beforeUrl);
  assert.equal(
    await page.locator("#onboarding-title").innerText(),
    beforeHeading,
  );
  assert.equal(
    await page.locator(".onboarding-progress").innerText(),
    beforeProgress,
  );
  if (scrollbarStyle)
    await scrollbarStyle.evaluate((element) => element.remove());
}

async function checkFloatingAbout(page, authenticated) {
  const before = await workingContext(page);
  const trigger = page
    .locator(".product-nav")
    .getByRole("button", { name: "About", exact: true });
  await trigger.click();
  const about = page.getByRole("dialog", {
    name: "About accreatio",
    exact: true,
  });
  await about.waitFor();
  assert.equal(await trigger.getAttribute("aria-expanded"), "true");
  const information = await about.innerText();
  assert.match(information, /AEKR/);
  assert.doesNotMatch(
    information,
    /Ed Lopez|Free authorized private-use license|Licencia privada de uso autorizado gratuito/i,
  );
  for (const name of ["privacy", "terms"])
    assert.equal(
      await about.getByRole("link", { name, exact: true }).getAttribute("href"),
      `/legal/${name}.html?lang=en`,
    );
  await about.getByRole("button", { name: "FAQ", exact: true }).click();
  await about.locator("#about-faq-title").waitFor();
  assert.ok((await about.locator(".about-faq details").count()) > 5);
  assert.equal(
    await about.getByRole("button", { name: "Full help", exact: true }).count(),
    authenticated ? 1 : 0,
  );
  if (authenticated) {
    await about.getByRole("button", { name: "Full help", exact: true }).click();
    assert.equal(
      await about.locator(".help-tips__slide img").getAttribute("src"),
      "/help/en/access.jpg",
    );
    await about.getByRole("button", { name: "Next tip", exact: true }).click();
    assert.notEqual(
      await about.locator(".help-tips__slide img").getAttribute("src"),
      "/help/en/access.jpg",
    );
  }
  assert.deepEqual(await workingContext(page), before);
  await about.getByRole("button", { name: "Close About", exact: true }).click();
  await about.waitFor({ state: "detached" });
  assert.equal(
    await trigger.evaluate((element) => element === document.activeElement),
    true,
  );
  assert.deepEqual(await workingContext(page), before);
}

const writeSavedDraft = (page, draft) =>
  page.evaluate(
    (value) =>
      new Promise((resolve, reject) => {
        const request = indexedDB.open("accreatio-drafts");
        request.onerror = () => reject(request.error);
        request.onsuccess = () => {
          const database = request.result;
          const transaction = database.transaction("drafts", "readwrite");
          transaction.objectStore("drafts").put(value, "account-current:v1");
          localStorage.setItem(
            "accreatio:account-draft:v1",
            JSON.stringify(value),
          );
          transaction.oncomplete = () => {
            database.close();
            resolve();
          };
          transaction.onerror = () => {
            database.close();
            reject(transaction.error);
          };
        };
      }),
    draft,
  );

async function checkExistingDraftGuards(page, validDraft) {
  for (const [caseName, roles] of [
    ["duplicate", ["generalist", "generalist"]],
    [
      "over-limit",
      ["generalist", "architect", "implementer", "auditor", "generalist"],
    ],
  ]) {
    await page.waitForTimeout(700);
    const draft = structuredClone(validDraft);
    draft.project.name =
      caseName === "duplicate" ? "D".repeat(51) : "Existing team";
    draft.project.participants = roles.map((role, index) => ({
      ...draft.project.participants[0],
      id: `existing-${index + 1}`,
      role,
    }));
    draft.navigation = { question: "name", hasReviewed: false, locale: "en" };
    await writeSavedDraft(page, draft);
    await page.reload();
    await expectQuestion(page, "name");
    await page.waitForFunction(
      (name) => document.querySelector("#project-name")?.value === name,
      draft.project.name,
    );
    if (caseName === "duplicate") {
      assert.equal(
        (await page.locator("#project-name").inputValue()).length,
        51,
        "Existing names must not be silently truncated",
      );
      await continueQuestion(page);
      await expectQuestion(page, "name");
      assert.equal(
        await page.locator("#project-name").getAttribute("aria-invalid"),
        "true",
      );
      await page.locator("#project-name").fill("Existing team");
    }
    for (const current of ["name", "phase", "context", "restrictions"]) {
      await expectQuestion(page, current);
      await continueQuestion(page);
    }
    await expectQuestion(page, "review");
    await page
      .locator(".review-stage__status")
      .getByRole("button", { name: /^Advanced options ·/ })
      .click()
      .catch(async (error) => {
        const evidence = path.join(
          ROOT,
          ".local/logs/readiness-2026-10-21",
          `web-restored-${caseName}-${Date.now()}`,
        );
        await mkdir(evidence, { recursive: true });
        await Promise.allSettled([
          page.screenshot({
            path: path.join(evidence, "failure.png"),
            fullPage: true,
          }),
          page
            .locator("body")
            .innerText()
            .then((body) => writeFile(path.join(evidence, "body.txt"), body)),
          page
            .content()
            .then((html) => writeFile(path.join(evidence, "page.html"), html)),
          readSavedDraft(page).then((saved) =>
            writeFile(
              path.join(evidence, "draft.json"),
              JSON.stringify(saved, null, 2),
            ),
          ),
        ]);
        console.error(`Restored-draft failure evidence: ${evidence}`);
        throw error;
      });
    await expectQuestion(page, "team");
    if (
      !(await page
        .locator(".guided-team__customization")
        .evaluate((element) => element.open))
    )
      await page.locator(".guided-team__customization > summary").click();
    assert.deepEqual(
      await page
        .locator(".team-list select")
        .evaluateAll((selects) => selects.map((select) => select.value)),
      roles,
      "Existing team topology must remain available for explicit correction",
    );
    await continueQuestion(page);
    await expectQuestion(page, "team");
    await page
      .locator("#project-participants .field-error")
      .waitFor({ state: "visible" });
    if (caseName === "duplicate") {
      await page.locator(".team-list select").nth(1).selectOption("architect");
    } else {
      assert.equal(
        await page
          .getByRole("button", { name: "Add participant" })
          .isDisabled(),
        true,
      );
      assert.equal(
        (await page.locator("#project-participant-limit").textContent()).trim(),
        "This draft has more than 4 participants. Remove participants to continue.",
      );
      await page.locator(".team-list li").last().getByRole("button").click();
    }
    await continueQuestion(page);
    await expectQuestion(page, "review");
  }
  console.log(
    "PASS restored draft guards: preserve and repair long names, duplicate roles and five participants",
  );
}

async function checkWebFooter() {
  // A separate context isolates storage, not Chromium's renderer/GPU process.
  // Run this fixture in its own browser before the motion suite starts, so no
  // live animation from another fixture competes with popup initialization.
  // CI previously intercepted a popup request without reaching the page event;
  // a request alone does not prove the response committed in a usable new tab.
  // Worker-enabled navigation is covered by the account and PWA smoke suites.
  const footerBrowser = await chromium.launch();
  try {
    const context = await footerBrowser.newContext({
      viewport: { width: 1280, height: 900 },
      reducedMotion: "reduce",
      serviceWorkers: "block",
    });
    // Keep a deny-by-default route for the full context lifetime, including any
    // late favicon/subresource request after a destination assertion completes.
    await context.route(
      (url) => url.origin !== new URL(TARGET_URL).origin,
      (route) => route.abort(),
    );
    const page = await context.newPage();
    await configureBlogApi(page);
    await page.goto(TARGET_URL);
    await checkWebFooterLinks(page);
  } finally {
    await footerBrowser.close();
  }
}

async function checkWebFooterLinks(page) {
  const footer = page.locator(".web-footer");
  await footer.waitFor();
  const destinations = [
    ["Built with AEKR", "https://aekr.io"],
    ["Instagram", "https://www.instagram.com/__aekr/"],
  ];
  for (const [name, href] of destinations) {
    const link = footer.getByRole("link", {
      name: new RegExp(`^${name} \\(opens in a new tab\\)$`),
    });
    assert.equal(await link.getAttribute("href"), href);
    assert.equal(await link.getAttribute("target"), "_blank");
    assert.match(await link.getAttribute("rel"), /\bnoopener\b/);
    assert.match(await link.getAttribute("rel"), /\bnoreferrer\b/);
    const expectedUrl = new URL(href).href;
    const originalUrl = page.url();
    const context = page.context();
    const originalPages = new Set(context.pages());
    const pageEvents = [];
    const recordPage = (createdPage) => pageEvents.push(createdPage);
    context.on("page", recordPage);
    const externalNavigation = [];
    const fulfilledNavigation = [];
    const failedNavigation = [];
    const isExternal = (url) => url.origin !== new URL(TARGET_URL).origin;
    const destinationReceipt = async (route) => {
      const request = route.request();
      if (request.isNavigationRequest()) externalNavigation.push(request.url());
      if (request.url() !== expectedUrl) return route.abort();
      try {
        await route.fulfill({
          body: "<!doctype html><title>Local footer destination receipt</title>",
          contentType: "text/html",
        });
        if (request.isNavigationRequest())
          fulfilledNavigation.push(request.url());
      } catch (error) {
        failedNavigation.push({ url: request.url(), error: error.message });
        throw error;
      }
    };
    await context.route(isExternal, destinationReceipt);
    let popup;
    try {
      // Scrolling and actionability can take time on software-rendered CI.
      // Start the new-tab deadline only after the real link is ready to click.
      await link.scrollIntoViewIfNeeded();
      await link.click({ trial: true });
      // noopener deliberately isolates the new tab. Observe its context event
      // without relying on Chromium attaching it to the parent popup event.
      [popup] = await Promise.all([
        context.waitForEvent("page", {
          predicate: (createdPage) => !originalPages.has(createdPage),
        }),
        link.click(),
      ]);
      await popup.waitForLoadState("domcontentloaded");
      assert.equal(pageEvents.length, 1);
      assert.equal(context.pages().length, originalPages.size + 1);
      assert.equal(originalPages.has(popup), false);
      assert.deepEqual(externalNavigation, [expectedUrl]);
      assert.deepEqual(fulfilledNavigation, [expectedUrl]);
      assert.equal(popup.url(), expectedUrl);
      assert.equal(await popup.title(), "Local footer destination receipt");
      assert.equal(await popup.evaluate(() => window.opener === null), true);
      assert.equal(page.url(), originalUrl);
      console.log(
        `PASS web footer destination: ${name}; intercepted isolated popup`,
      );
    } catch (error) {
      console.error(
        JSON.stringify({
          event: "footer_popup_failure",
          name,
          externalNavigation,
          fulfilledNavigation,
          failedNavigation,
          sourceUrl: page.url(),
          popupUrl: popup?.url(),
          originalPageCount: originalPages.size,
          contextPageCount: context.pages().length,
          contextPageUrls: context.pages().map((item) => item.url()),
          pageEventUrls: pageEvents.map((item) => item.url()),
        }),
      );
      throw error;
    } finally {
      await popup?.close();
      context.off("page", recordPage);
      await context.unroute(isExternal, destinationReceipt);
    }
  }
  for (const name of ["X", "LinkedIn"]) {
    const pending = footer.locator(`[aria-label="${name} (profile pending)"]`);
    assert.equal(
      await pending.isVisible(),
      false,
      "Pending profiles must be hidden",
    );
    assert.equal(await pending.getAttribute("href"), null);
    assert.equal(
      await footer.getByRole("link", { name: new RegExp(`^${name}`) }).count(),
      0,
    );
  }
  console.log(
    "PASS web footer: exact destinations, isolated new tabs, hidden pending profiles",
  );
}

let browser;
try {
  await waitForServer();
  await checkWebFooter();
  // Real in-app windows reserve space for classic scrollbars. Headless
  // Chromium otherwise hides them and misses layout-viewport clipping.
  browser = await chromium.launch({ ignoreDefaultArgs: ["--hide-scrollbars"] });
  for (const adminStatus of [401, "pending"]) {
    const publicPage = await browser.newPage({
      viewport: { width: 1280, height: 900 },
      reducedMotion: "reduce",
    });
    const publicApi = await configureBlogApi(publicPage, {
      accountAuthenticated: false,
      adminStatus,
    });
    await publicPage.goto(TARGET_URL);
    assert.equal(await publicPage.locator(".project-help__link").count(), 0);
    await publicPage
      .getByRole("heading", {
        name: "Prepare the brief for your next project",
        exact: true,
      })
      .waitFor();
    await checkPublicExample(publicPage);
    if (adminStatus === 401) {
      await publicPage.setViewportSize({ width: 390, height: 844 });
      await publicPage
        .getByRole("button", { name: "Switch to Spanish", exact: true })
        .click();
      await checkPublicExample(publicPage, "es");
      await publicPage
        .getByRole("button", { name: "Cambiar a inglés", exact: true })
        .click();
      await publicPage.setViewportSize({ width: 320, height: 780 });
      await checkPublicExample(publicPage);
      await publicPage.setViewportSize({ width: 1280, height: 900 });
    }
    await publicPage.getByRole("button", { name: "Blog", exact: true }).click();
    await publicPage.locator(".blog-post").first().waitFor();
    assert.equal(await publicPage.locator(".blog-post").count(), 3);
    assert.ok(publicApi.postsRequestCount() > 0);
    assert.ok(publicApi.adminRequestCount() > 0);
    assert.equal(await publicPage.locator("#blog-admin-title").count(), 0);
    assert.equal(await publicPage.locator("#web-signin-title").count(), 0);
    assert.equal(await publicPage.locator(".blog-state--error").count(), 0);
    assert.equal(
      await publicPage
        .getByRole("button", { name: /^(?:View )?welcome$/i })
        .count(),
      0,
    );
    const nav = await publicPage.locator(".product-nav").boundingBox();
    assert.ok(nav.x > 640, "Desktop navigation stays toward the top right");
    for (const button of await publicPage
      .locator(".product-nav button")
      .all()) {
      const bounds = await button.boundingBox();
      assert.ok(
        bounds.width <= 150 && bounds.height >= 44 && bounds.height <= 48,
        "Navigation is compact with accessible touch targets",
      );
    }
    publicApi.releaseAdminCheck();
    await checkFloatingAbout(publicPage, false);
    assert.equal(await publicPage.locator("#web-signin-title").count(), 0);
    await publicPage.close();
  }
  console.log(
    "PASS public Blog/About without account; posts survive denied or stalled admin capability",
  );
  const page = await browser.newPage({
    acceptDownloads: true,
    locale: "es-ES",
    colorScheme: "light",
  });
  const runtimeErrors = [];
  page.on("pageerror", (error) => runtimeErrors.push(error.message));
  await observeNebula(page);
  await configureBlogApi(page, { canPublish: true });
  await page.goto(TARGET_URL);
  await page.getByRole("button", { name: "Switch to Spanish" }).waitFor();
  assert.equal(await page.locator("html").getAttribute("lang"), "en");
  await checkNightTheme(page);
  await page.waitForFunction(
    () => document.querySelector(".atmosphere")?.dataset.renderer === "webgl",
    undefined,
    { timeout: 15_000 },
  );
  assert.equal(await page.locator(WEBGL_CANVAS).count(), 1);
  assert.equal(await page.locator(STAR_CANVAS).count(), 1);
  assert.equal(await page.locator(".atmosphere canvas").count(), 2);
  await page.evaluate(() => {
    window.__accreatioAtmosphereWebglCanvas = document.querySelector(
      ".atmosphere__webgl canvas",
    );
  });
  // Capture the rendered viewport canvas directly. Locator screenshots first
  // wait for scroll/actionability stability, which is unrelated to sampling
  // a live animation and stalled on the CI renderer. Keep the same clip for
  // both real frames, and reject layout changes before comparing their pixels.
  const canvasClip = await page.locator(WEBGL_CANVAS).boundingBox();
  assert.ok(canvasClip && canvasClip.width > 0 && canvasClip.height > 0);
  const firstFrame = await page.screenshot({
    clip: canvasClip,
    animations: "allow",
  });
  await page.waitForTimeout(1_000);
  assert.deepEqual(await page.locator(WEBGL_CANVAS).boundingBox(), canvasClip);
  const secondFrame = await page.screenshot({
    clip: canvasClip,
    animations: "allow",
  });
  const hash = (value) => createHash("sha256").update(value).digest("hex");
  assert.notEqual(hash(secondFrame), hash(firstFrame));
  assert.equal(
    await page
      .locator(".atmosphere")
      .evaluate((element) =>
        getComputedStyle(element).getPropertyValue("pointer-events"),
      ),
    "none",
  );
  await checkNebulaInteraction(page);
  if (await page.locator(".onboarding").count()) {
    assert.equal(
      await page
        .locator(
          ".onboarding button.formation-mark, .onboarding a.formation-mark",
        )
        .count(),
      0,
    );
    await page
      .getByRole("button", { name: "Prepare my project", exact: true })
      .click();
    assert.equal(
      await page
        .locator(
          ".onboarding button.formation-mark, .onboarding a.formation-mark",
        )
        .count(),
      0,
    );
    await page.getByRole("button", { name: "Continue to sign in" }).click();
  }
  await page.getByRole("button", { name: "Blog", exact: true }).click();
  await page.locator("#blog-title").waitFor();
  const blogTypography = await page
    .locator("#blog-title")
    .evaluate((element) => {
      const style = getComputedStyle(element);
      return [
        style.fontFamily,
        style.fontWeight,
        Number(
          (
            parseFloat(style.letterSpacing) / parseFloat(style.fontSize)
          ).toFixed(5),
        ),
      ];
    });
  await page.locator(".blog-post").first().waitFor();
  assert.equal(await page.locator(".blog-post").count(), 3);
  for (const title of [
    "Introducing accreatio",
    "Nebula made ideas for accreatio",
    "A small paradox, but a paradox after all.",
  ])
    assert.equal(await page.getByRole("heading", { name: title }).count(), 1);
  await page.locator("#blog-admin-title").waitFor();
  await page.getByLabel(/Título|Title/).fill("Visual smoke post");
  await page.getByLabel(/Resumen|Summary/).fill("A local API contract check.");
  await page
    .getByLabel(/Cuerpo|Body/)
    .fill("First paragraph.\n\nSecond paragraph.");
  await page.getByLabel(/Autor visible|Display author/).fill("Ed Lopez");
  await page
    .getByLabel(/Rol \/ procedencia visible|Display role \/ provenance/)
    .fill("Founder and product owner");
  await page.getByLabel(/Firma|Signature/).fill("Ed Lopez");
  await checkNoExtraHelp(page);
  await checkFloatingAbout(page, true);
  page.once("dialog", (dialog) => dialog.accept());
  await page
    .getByRole("button", { name: /Revisar y publicar|Review and publish/ })
    .click();
  await page.getByRole("heading", { name: "Visual smoke post" }).waitFor();
  assert.equal(await page.locator(".blog-post").count(), 4);
  await checkNightTheme(page);
  assert.equal(await page.locator(WEBGL_CANVAS).count(), 1);
  assert.equal(await page.locator(STAR_CANVAS).count(), 1);
  assert.equal(await page.locator(".atmosphere canvas").count(), 2);
  assert.equal(
    await page.evaluate(
      () =>
        window.__accreatioAtmosphereWebglCanvas ===
        document.querySelector(".atmosphere__webgl canvas"),
    ),
    true,
  );
  assert.equal(
    await page.evaluate(() =>
      performance
        .getEntriesByType("resource")
        .some(
          (entry) =>
            !new URL(entry.name).hostname.match(/^(127\.0\.0\.1|localhost)$/),
        ),
    ),
    false,
  );
  await page.getByRole("button", { name: "New project", exact: true }).click();
  await expectQuestion(page, "name");
  await page
    .getByRole("button", { name: /New draft/ })
    .first()
    .waitFor();
  const computedTypography = await page.evaluate(() => {
    const role = (selector) => {
      const style = getComputedStyle(document.querySelector(selector));
      return [style.fontFamily, style.fontWeight];
    };
    return {
      brand: role(".formation-mark strong"),
      button: role(".guided-creation__continue"),
      heading: role(".creation-stage__header h1"),
      label: role(".question-group label"),
      navigation: role(".product-nav button"),
      secondary: role(".creation-stage__header span"),
    };
  });
  // The declared stacks as Chromium serialises them back from
  // getComputedStyle, which drops quotes around families that do not need
  // them. The roles themselves are fixed by DECISIONS.md: design-v10 uses one
  // host-resident sans everywhere, separated by weight and size.
  const ui =
    'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
  const display = ui;
  assert.deepEqual(computedTypography, {
    brand: [display, "700"],
    button: [ui, "600"],
    heading: [display, "700"],
    label: [ui, "500"],
    navigation: [ui, "500"],
    secondary: [ui, "400"],
  });
  const mark = page.locator(".app-header .formation-mark strong");
  assert.equal((await mark.textContent()).trim(), "accreatio");
  assert.deepEqual(
    await mark.evaluate((element) => {
      const style = getComputedStyle(element);
      return [
        style.fontFamily,
        style.fontWeight,
        Number(
          (
            parseFloat(style.letterSpacing) / parseFloat(style.fontSize)
          ).toFixed(5),
        ),
      ];
    }),
    blogTypography,
  );
  assert.equal(
    await page
      .getByText("FROM IDEA TO STRUCTURE", { exact: true })
      .filter({ visible: true })
      .count(),
    0,
  );
  assert.equal(await page.locator(WEBGL_CANVAS).count(), 1);
  assert.equal(await page.locator(STAR_CANVAS).count(), 1);
  assert.equal(await page.locator(".atmosphere canvas").count(), 2);
  assert.equal(
    await page.evaluate(
      () =>
        window.__accreatioAtmosphereWebglCanvas ===
        document.querySelector(".atmosphere__webgl canvas"),
    ),
    true,
  );
  assert.equal(
    await page.getByRole("button", { name: "Settings", exact: true }).count(),
    0,
  );
  assert.equal(
    await page.getByRole("button", { name: "History", exact: true }).count(),
    0,
  );
  assert.equal(await page.getByText(/not supported in this host/i).count(), 0);
  assert.equal(await page.getByLabel("Destination folder").count(), 0);

  await checkProjectSummary(page, {
    Project: "—",
    "Starting point": null,
    Participants: null,
    Delivery: null,
  });
  await page.getByLabel("Project name").fill("Web Smoke");
  await checkProjectSummary(page, {
    Project: "Web Smoke",
    Participants: null,
    Delivery: null,
  });
  await continueQuestion(page);
  await expectQuestion(page, "phase");
  await page.getByRole("button", { name: /I'm starting with an idea/ }).click();
  await expectQuestion(page, "context");
  await page
    .locator("#project-context")
    .fill("Verify the real W1 browser contract.");
  await continueQuestion(page);
  await expectQuestion(page, "restrictions");
  await continueQuestion(page);
  await expectQuestion(page, "review");
  await page
    .locator(".review-stage__status")
    .getByRole("button", { name: /^Advanced options ·/ })
    .click();
  await expectQuestion(page, "team");
  await page.locator(".guided-team__customization > summary").click();
  await page.locator("#advanced-route").selectOption("local");
  assert.equal(await page.locator("#project-destination").count(), 0);
  await page.getByRole("button", { name: "Add participant" }).click();
  await page.locator(".team-list select").nth(1).selectOption("auditor");
  for (const index of [0, 1]) {
    const selects = page.locator(".team-list select");
    const otherRole = await selects.nth(1 - index).inputValue();
    assert.equal(
      await selects
        .nth(index)
        .locator(`option[value="${otherRole}"]`)
        .isDisabled(),
      true,
    );
    const currentRole = await selects.nth(index).inputValue();
    assert.equal(
      await selects
        .nth(index)
        .locator(`option[value="${currentRole}"]`)
        .isDisabled(),
      false,
    );
  }
  await page.getByRole("button", { name: "Add participant" }).click();
  await page.getByRole("button", { name: "Add participant" }).click();
  const selectedRoles = await page
    .locator(".team-list select")
    .evaluateAll((selects) => selects.map((select) => select.value));
  assert.equal(selectedRoles.length, 4);
  assert.equal(new Set(selectedRoles).size, 4);
  assert.equal(
    await page.getByRole("button", { name: "Add participant" }).isDisabled(),
    true,
  );
  assert.equal(
    (await page.locator("#project-participant-limit").textContent()).trim(),
    "Maximum of 4 participants reached. Remove a participant to change the team.",
  );
  await checkProjectSummary(page, { Participants: 4 });
  assert.equal(
    (await page.locator(".summary-drawer__preview").textContent()).trim(),
    "0 files · 4 participants",
  );
  await page.locator(".team-list li").nth(3).getByRole("button").click();
  assert.equal(
    await page.getByRole("button", { name: "Add participant" }).isDisabled(),
    false,
  );
  await page.locator(".team-list li").nth(2).getByRole("button").click();
  await page.locator(".team-list li").nth(1).getByRole("button").click();
  assert.equal(await page.locator(".team-list select").count(), 1);
  await page
    .getByText("Mode 1 orchestration · manual mode", { exact: true })
    .click();
  await page
    .getByRole("button", { name: /Prepare Mode 1 configuration/ })
    .click();
  const task = page.locator('textarea[id^="mode1-task-"]').first();
  assert.ok((await task.inputValue()).length > 30);
  assert.doesNotMatch(await task.inputValue(), /TODO/);
  await page.getByRole("button", { name: "Cancel", exact: true }).click();
  await page.waitForTimeout(700);
  const savedDraft = await readSavedDraft(page);
  assert.equal(savedDraft.project.name, "Web Smoke");
  console.log(
    "PASS advanced options: unique roles, limit, route and optional configuration",
  );
  await page.getByRole("button", { name: "Blog", exact: true }).click();
  await page.locator("#blog-title").waitFor();
  await page.getByRole("button", { name: "Create a project" }).click();
  while (
    (await page
      .locator(".guided-creation__question")
      .getAttribute("data-question")) !== "name"
  )
    await backQuestion(page);
  await page.locator("#project-name").waitFor();
  assert.equal(await page.getByLabel("Project name").inputValue(), "Web Smoke");
  assert.equal(
    await page
      .getByRole("button", { name: "View welcome", exact: true })
      .count(),
    0,
  );
  await checkContextualHelp(page, "name");
  await checkFloatingAbout(page, true);
  await expectQuestion(page, "name");
  assert.equal(await page.getByLabel("Project name").inputValue(), "Web Smoke");
  await page.getByRole("button", { name: "Switch to Spanish" }).click();
  assert.equal(await page.locator("html").getAttribute("lang"), "es");
  await page.reload();
  await page.waitForFunction(
    () => document.querySelector("#project-name")?.value === "Web Smoke",
  );
  assert.equal(await page.locator("#project-name").inputValue(), "Web Smoke");
  assert.equal(await page.locator("html").getAttribute("lang"), "es");
  await page.getByRole("button", { name: "Cambiar a inglés" }).click();
  await checkNightTheme(page);

  page.once("dialog", (dialog) => dialog.accept());
  await page.getByRole("button", { name: /New draft/ }).click();
  await page.waitForFunction(
    () => document.querySelector("#project-name")?.value === "",
  );
  assert.equal(await page.getByLabel("Project name").inputValue(), "");
  await page.getByLabel("Project name").fill("Web Export");
  await continueQuestion(page);
  await expectQuestion(page, "phase");
  await checkContextualHelp(page, "phase");
  await page.getByRole("button", { name: /I'm exploring the idea/ }).click();
  await expectQuestion(page, "attachments");
  assert.equal(
    await page.getByText("Only in this tab", { exact: true }).count(),
    1,
  );
  await page
    .getByText(
      "The draft keeps your answers and the number of selected files, but not their names or the files. Select them again after a reload.",
      { exact: true },
    )
    .waitFor();
  for (const invalid of [
    {
      name: "blocked.md",
      mimeType: "text/markdown",
      buffer: Buffer.from("Unsupported text"),
    },
    {
      name: "blocked.pdf",
      mimeType: "application/pdf",
      buffer: Buffer.from("Not a PDF"),
    },
    {
      name: "blocked.png",
      mimeType: "image/png",
      buffer: Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"/>'),
    },
  ]) {
    const rejectedChooser = page.waitForEvent("filechooser");
    await page.getByRole("button", { name: "Add local files" }).click();
    await (await rejectedChooser).setFiles(invalid);
    const rejected = page.locator(".attachment-rejected");
    await rejected.waitFor();
    assert.match(
      await rejected.innerText(),
      /Unsupported file type|Invalid content or format/,
    );
    assert.equal(await page.locator(".attachment-ready").count(), 0);
    await page
      .getByRole("button", { name: `Remove ${invalid.name}`, exact: true })
      .click();
  }
  const attachmentBytes = minimalDocx(
    "Local evidence. Bytes stay on this device.",
  );
  const fileChooserPromise = page.waitForEvent("filechooser");
  await page.getByRole("button", { name: "Add local files" }).click();
  await (
    await fileChooserPromise
  ).setFiles({
    name: "local-evidence.docx",
    mimeType:
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    buffer: attachmentBytes,
  });
  await page
    .getByRole("button", { name: "Remove local-evidence.docx" })
    .waitFor();
  await checkContextualHelp(page, "attachments");
  await checkFloatingAbout(page, true);
  await page
    .getByRole("button", { name: "Remove local-evidence.docx" })
    .waitFor();
  await checkProjectSummary(page, { "Attached files": 1 });
  assert.equal(
    (await page.locator(".summary-drawer__preview").textContent()).trim(),
    "1 file",
  );
  await page.waitForTimeout(700);
  const attachmentDraft = await readSavedDraft(page);
  assert.deepEqual(attachmentDraft.project.attachments, []);
  assert.equal(attachmentDraft.transientAttachments.count, 1);
  assert.equal(
    JSON.stringify(attachmentDraft).includes(attachmentBytes.toString("utf8")),
    false,
  );
  await page.reload();
  await expectQuestion(page, "attachments");
  await page.locator(".attachment-warning").waitFor();
  assert.match(
    await page.locator(".attachment-warning").textContent(),
    /1 local attachment/,
  );
  assert.equal(
    await page
      .getByRole("button", { name: "Remove local-evidence.docx" })
      .count(),
    0,
  );
  const reselectPromise = page.waitForEvent("filechooser");
  await page.getByRole("button", { name: "Add local files" }).click();
  await (
    await reselectPromise
  ).setFiles({
    name: "local-evidence.docx",
    mimeType:
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    buffer: attachmentBytes,
  });
  await page
    .getByRole("button", { name: "Remove local-evidence.docx" })
    .waitFor();
  await continueQuestion(page);
  await expectQuestion(page, "context");
  await page
    .locator("#project-context")
    .fill("Download an inspectable project bundle.");
  await checkContextualHelp(page, "context");
  await finishGuidedQuestions(page);
  await expectQuestion(page, "review");
  await checkContextualHelp(page, "review");
  assert.equal(
    await page.getByRole("progressbar").getAttribute("aria-valuemax"),
    "6",
  );
  assert.equal(
    await page.locator(".summary-drawer--web").count(),
    0,
    "Review uses its expanded overview instead of a duplicate drawer",
  );
  const overview = page.locator(".review-overview");
  await overview
    .getByRole("heading", { name: "Web Export", exact: true })
    .waitFor();
  const overviewRows = await overview
    .locator("dl > div")
    .evaluateAll((elements) =>
      Object.fromEntries(
        elements.map((element) => [
          element.querySelector("dt").textContent.trim(),
          element.querySelector("dd").textContent.trim(),
        ]),
      ),
    );
  assert.deepEqual(overviewRows, {
    "Planned roles": "Generalist",
    "Working approach": "Local tools",
    Orchestration: "Disabled",
    "Optional guides": "None",
    Delivery: "Downloadable project ZIP",
    "Attached files": "1 file(s): local-evidence.docx",
  });
  const dryChoice = page.getByRole("checkbox", {
    name: /Check the package without downloading/,
  });
  assert.equal(await dryChoice.isChecked(), true);
  assert.match(
    await page.locator(".review-stage__confirm button").textContent(),
    /Check the package without downloading/,
  );
  await dryChoice.uncheck();
  assert.match(
    await page.locator(".review-stage__confirm button").textContent(),
    /Create and download ZIP/,
  );
  await confirmReview(page);
  let downloadCount = 0;
  page.on("download", () => {
    downloadCount += 1;
  });
  const downloadPromise = page.waitForEvent("download");
  await page.getByRole("button", { name: /Prepare ZIP/ }).evaluate((button) => {
    button.click();
    button.click();
    button.dispatchEvent(
      new KeyboardEvent("keydown", { key: "Enter", bubbles: true }),
    );
  });
  const download = await downloadPromise;
  assert.equal(download.suggestedFilename(), "web-export.zip");
  assert.equal(await download.failure(), null);
  const exportedFiles = await inspectProjectZip(
    download,
    "Web Export",
    "Download an inspectable project bundle.",
  );
  assertSameDocxParts(
    [...exportedFiles].find(([name]) =>
      name.endsWith("local-evidence.docx"),
    )?.[1],
    attachmentBytes,
  );
  await page.waitForTimeout(250);
  assert.equal(downloadCount, 1);

  await page.getByRole("button", { name: /Edit and export again/ }).click();
  await confirmReview(page);
  const rerunPromise = page.waitForEvent("download");
  await page.getByRole("button", { name: /Prepare ZIP/ }).click();
  await rerunPromise;
  assert.equal(downloadCount, 2);
  await checkExistingDraftGuards(page, savedDraft);
  assert.equal(
    downloadCount,
    2,
    "Invalid restored drafts must not cause a download",
  );

  await checkFloatingAbout(page, true);
  await page.locator(WEBGL_CANVAS).dispatchEvent("webglcontextlost");
  await page
    .locator('.atmosphere[data-renderer="fallback"]')
    .waitFor({ state: "visible" });
  assert.equal(await page.locator(WEBGL_CANVAS).count(), 0);
  assert.equal(await page.locator(STAR_CANVAS).count(), 1);
  assert.equal(
    await page.locator(STAR_CANVAS).getAttribute("data-motion"),
    "active",
  );
  assert.equal(await page.locator(".atmosphere canvas").count(), 1);
  assert.deepEqual(runtimeErrors, []);
  // The animated journey and context-loss checks are complete. Release its
  // remaining active starfield before opening the semantic viewport journeys.
  await page.context().close();

  for (const width of [760, 390, 320]) {
    const responsivePage = await browser.newPage({
      viewport: { width, height: width === 390 ? 600 : 900 },
      reducedMotion: "reduce",
    });
    await configureBlogApi(responsivePage, { canPublish: true });
    await responsivePage.goto(TARGET_URL);
    await responsivePage
      .getByRole("button", { name: "Blog", exact: true })
      .click();
    await responsivePage.locator("#blog-title").waitFor();
    await responsivePage.locator(".blog-post").first().waitFor();
    assert.equal(await responsivePage.locator(".blog-post").count(), 3);
    await checkNoExtraHelp(responsivePage);
    assert.equal(
      await responsivePage.evaluate(
        () => document.documentElement.scrollWidth <= window.innerWidth,
      ),
      true,
    );
    await checkGuidedJourney(responsivePage, {
      width,
      locale: width === 390 ? "en" : "es",
      reducedMotion: true,
    });
    await responsivePage.close();
  }

  const reducedPage = await browser.newPage();
  await observeNebula(reducedPage);
  const ordinaryBlog = await configureBlogApi(reducedPage);
  await reducedPage.emulateMedia({ reducedMotion: "reduce" });
  await reducedPage.goto(TARGET_URL);
  await reducedPage.waitForTimeout(500);
  assert.equal(
    await reducedPage.locator('.atmosphere[data-renderer="fallback"]').count(),
    1,
  );
  assert.equal(await reducedPage.locator(WEBGL_CANVAS).count(), 0);
  assert.equal(await reducedPage.locator(STAR_CANVAS).count(), 1);
  assert.equal(
    await reducedPage.locator(STAR_CANVAS).getAttribute("data-motion"),
    "static",
  );
  assert.equal(await reducedPage.locator(".atmosphere canvas").count(), 1);
  const reducedStarBefore = await canvasPixelFingerprint(
    reducedPage,
    STAR_CANVAS,
  );
  await reducedPage.mouse.move(1100, 620);
  await reducedPage.mouse.click(12, 12);
  await reducedPage.waitForTimeout(1_000);
  const reducedStarAfter = await canvasPixelFingerprint(
    reducedPage,
    STAR_CANVAS,
  );
  assert.deepEqual(reducedStarAfter, reducedStarBefore);
  assert.deepEqual(
    await reducedPage.locator(".atmosphere").evaluate((element) => {
      const style = getComputedStyle(element);
      return [
        style.getPropertyValue("--nebula-pointer-x").trim(),
        style.getPropertyValue("--nebula-pointer-y").trim(),
      ];
    }),
    ["", ""],
  );
  assert.deepEqual(
    await reducedPage.evaluate(() => window.__nebulaObservation),
    { picks: [], bursts: 0, lastBurst: null },
  );
  await checkGuidedJourney(reducedPage, { locale: "en", reducedMotion: true });
  assert.equal(
    await reducedPage
      .getByRole("button", { name: "Blog", exact: true })
      .count(),
    1,
    "Ordinary project accounts can read the public Blog",
  );
  assert.equal(ordinaryBlog.postsRequestCount(), 0);
  await reducedPage.getByRole("button", { name: "Blog", exact: true }).click();
  await reducedPage.locator(".blog-post").first().waitFor();
  assert.equal(await reducedPage.locator(".blog-post").count(), 3);
  assert.equal(await reducedPage.locator("#blog-admin-title").count(), 0);
  assert.equal(
    await reducedPage.evaluate(
      () =>
        document
          .getAnimations()
          .filter((animation) => animation.id === "accreatio-section-enter")
          .length,
    ),
    0,
  );
  assert.equal(await reducedPage.locator(".blog-state--error").count(), 0);
  await reducedPage.close();

  const noWebglPage = await browser.newPage();
  const ordinaryFallbackBlog = await configureBlogApi(noWebglPage);
  await noWebglPage.addInitScript(() => {
    const getContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (type, ...args) {
      if (type === "webgl" || type === "webgl2") return null;
      return getContext.call(this, type, ...args);
    };
  });
  await noWebglPage.goto(TARGET_URL);
  await noWebglPage.waitForTimeout(500);
  assert.equal(
    await noWebglPage.locator('.atmosphere[data-renderer="fallback"]').count(),
    1,
  );
  assert.equal(await noWebglPage.locator(WEBGL_CANVAS).count(), 0);
  assert.equal(await noWebglPage.locator(STAR_CANVAS).count(), 1);
  assert.equal(
    await noWebglPage.locator(STAR_CANVAS).getAttribute("data-motion"),
    "active",
  );
  assert.equal(await noWebglPage.locator(".atmosphere canvas").count(), 1);
  assert.equal(
    await noWebglPage
      .getByRole("button", { name: "Blog", exact: true })
      .count(),
    1,
  );
  assert.equal(ordinaryFallbackBlog.postsRequestCount(), 0);
  await noWebglPage.getByRole("button", { name: "Blog", exact: true }).click();
  await noWebglPage.locator(".blog-post").first().waitFor();
  assert.equal(await noWebglPage.locator(".blog-post").count(), 3);
  assert.equal(await noWebglPage.locator("#blog-admin-title").count(), 0);
  assert.equal(await noWebglPage.locator(".blog-state--error").count(), 0);
  await noWebglPage.close();
  assert.deepEqual(runtimeErrors, []);
  console.log("PASS W1 browser functional smoke");
} finally {
  if (browser) await browser.close().catch(() => {});
  preview.kill();
}
