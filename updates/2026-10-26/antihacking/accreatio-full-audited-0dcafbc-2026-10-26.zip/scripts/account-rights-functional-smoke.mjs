import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const root = fileURLToPath(new URL("../", import.meta.url));
const port = 4193;
const target = `http://127.0.0.1:${port}`;
const output = path.join(
  root,
  ".local/logs",
  `account-rights-ui-${Date.now()}`,
);
await mkdir(output, { recursive: true });
const preview = spawn(
  process.execPath,
  [
    path.join(root, "node_modules/vite/bin/vite.js"),
    "preview",
    "--host",
    "127.0.0.1",
    "--port",
    String(port),
    "--strictPort",
  ],
  { cwd: root, stdio: "ignore", windowsHide: true },
);
let browser;
let activePage;
let stage = "start";
const report = {
  scope:
    "Synthetic browser UI: local built app and fixture API/provider responses only; no real OAuth, personal account, cookie proof implementation or provider acceptance is asserted.",
  cases: [],
  result: "RUNNING",
};

async function until(check, message, timeout = 10000) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if (await check()) return;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error(message);
}
async function installFixture(context) {
  const state = {
    next: "complete",
    proofTransaction: null,
    transactions: new Map(),
    requests: [],
    starts: 0,
    data: 0,
    deletes: 0,
    cancels: 0,
    external: [],
  };
  const ownData = {
    account: {
      id: "synthetic-rights-account",
      displayName: "Synthetic Ω",
      email: "synthetic@example.test",
    },
    policyAuthorization: null,
    allowance: { remaining: 4 },
  };
  await context.route("**/*", async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    const json = (body, status = 200, headers = {}) =>
      route.fulfill({
        status,
        contentType: "application/json",
        headers: { "Cache-Control": "no-store", ...headers },
        body: JSON.stringify(body),
      });
    if (url.origin !== target) {
      if (
        ["https://accounts.google.com", "https://github.com"].includes(
          url.origin,
        ) &&
        url.searchParams.has("fixture")
      ) {
        const tx = state.transactions.get(url.searchParams.get("fixture"));
        assert.ok(
          tx,
          "Only a known synthetic proof may navigate the provider popup.",
        );
        if (tx.mode !== "hold") tx.status = "completed";
        state.proofTransaction = tx.mode === "wrong" ? randomUUID() : tx.id;
        return route.fulfill({
          status: 200,
          contentType: "text/html",
          headers: { "Content-Security-Policy": "default-src 'none'" },
          body: "<!doctype html><title>Synthetic proof</title><h1>Synthetic account verification fixture</h1>",
        });
      }
      state.external.push(url.origin + url.pathname);
      return route.abort();
    }
    if (!url.pathname.startsWith("/api/")) return route.continue();
    const body = request.postData()
      ? JSON.parse(request.postData())
      : undefined;
    const headers = request.headers();
    state.requests.push({
      path: url.pathname,
      method: request.method(),
      body,
      rights: headers["x-accreatio-rights"],
      transaction: headers["x-accreatio-rights-transaction"],
    });
    if (url.pathname === "/api/auth/v1/methods")
      return json({
        version: "auth.v1",
        methods: {
          google: { available: true },
          github: { available: true },
          emailOtp: { available: false },
        },
      });
    if (
      /^\/api\/auth\/v1\/rights\/(google|github)\/start$/.test(url.pathname)
    ) {
      state.starts++;
      assert.deepEqual(Object.keys(body).sort(), [
        "mode",
        "purpose",
        "returnRoute",
        "rightsOnly",
        "verificationAction",
      ]);
      assert.equal(body.rightsOnly, true);
      assert.equal(body.purpose, "account_access");
      assert.equal(body.mode, "popup");
      assert.equal(body.returnRoute, "builder");
      assert.ok(["data", "delete"].includes(body.verificationAction));
      const mode = state.next;
      state.next = "complete";
      if (mode === "rate")
        return json(
          { error: { code: "rights_rate_limited", message: "Wait." } },
          429,
          { "Retry-After": "2" },
        );
      const id = randomUUID();
      const provider = url.pathname.includes("/github/") ? "github" : "google";
      state.transactions.set(id, {
        id,
        status: "pending",
        action: body.verificationAction,
        mode,
      });
      return json({
        transactionId: id,
        authorizationUrl: `${provider === "github" ? "https://github.com/login/oauth/authorize" : "https://accounts.google.com/o/oauth2/v2/auth"}?fixture=${id}`,
        expiresAt: new Date(Date.now() + 600000).toISOString(),
      });
    }
    const transaction = url.pathname.match(
      /^\/api\/auth\/v1\/transactions\/([^/]+)\/(status|cancel)$/,
    );
    if (transaction) {
      const tx = state.transactions.get(transaction[1]);
      assert.ok(tx);
      if (transaction[2] === "cancel") {
        state.cancels++;
        tx.status = "failed";
      }
      return json({ status: tx.status });
    }
    if (
      url.pathname === "/api/account/data" ||
      url.pathname === "/api/account/delete"
    ) {
      assert.equal(headers["x-accreatio-rights"], "1");
      const tx = state.transactions.get(
        headers["x-accreatio-rights-transaction"],
      );
      if (!tx || state.proofTransaction !== tx.id)
        return json(
          {
            error: { code: "rights_context_changed", message: "Verify again." },
          },
          401,
        );
      assert.equal(tx.status, "completed");
      assert.equal(
        tx.action,
        url.pathname.endsWith("/data") ? "data" : "delete",
      );
      if (url.pathname.endsWith("/data")) {
        state.data++;
        assert.equal(request.method(), "GET");
        return json(ownData);
      }
      state.deletes++;
      assert.equal(request.method(), "POST");
      return json({ ok: true });
    }
    if (
      url.pathname === "/api/account/session" ||
      url.pathname === "/api/account/identity" ||
      url.pathname === "/api/admin/blog/session"
    )
      return json(
        { error: { code: "sign_in_required", message: "Sign in." } },
        401,
      );
    throw new Error(`Unexpected API request ${url.pathname}`);
  });
  return { state, ownData };
}

async function instrumentStorage(page) {
  await page.evaluate(async () => {
    localStorage.setItem(
      "rights-smoke-unrelated-draft",
      "synthetic draft must remain",
    );
    sessionStorage.setItem(
      "rights-smoke-unrelated-session",
      "synthetic session must remain",
    );
    await new Promise((resolve, reject) => {
      const open = indexedDB.open("rights-smoke-fixture", 1);
      open.onupgradeneeded = () => open.result.createObjectStore("unrelated");
      open.onerror = () => reject(open.error);
      open.onsuccess = () => {
        const db = open.result;
        const tx = db.transaction("unrelated", "readwrite");
        tx.objectStore("unrelated").put("synthetic indexed draft", "draft");
        tx.oncomplete = () => {
          db.close();
          resolve();
        };
        tx.onerror = () => reject(tx.error);
      };
    });
    window.__rightsWrites = [];
    window.__rightsProductEvents = [];
    for (const name of ["setItem", "removeItem", "clear"]) {
      const original = Storage.prototype[name];
      Storage.prototype[name] = function (...args) {
        window.__rightsWrites.push({ kind: "storage", name, key: args[0] });
        return original.apply(this, args);
      };
    }
    for (const name of ["put", "add", "delete", "clear"]) {
      const original = IDBObjectStore.prototype[name];
      IDBObjectStore.prototype[name] = function (...args) {
        window.__rightsWrites.push({
          kind: "indexeddb",
          name,
          store: this.name,
        });
        return original.apply(this, args);
      };
    }
    for (const name of [
      "accreatio:quota",
      "accreatio:account-recheck",
      "accreatio:session-invalid",
    ])
      window.addEventListener(name, () =>
        window.__rightsProductEvents.push(name),
      );
  });
}
async function verifyLocalPreservation(page) {
  const state = await page.evaluate(async () => ({
    local: localStorage.getItem("rights-smoke-unrelated-draft"),
    session: sessionStorage.getItem("rights-smoke-unrelated-session"),
    writes: window.__rightsWrites,
    events: window.__rightsProductEvents,
    indexed: await new Promise((resolve, reject) => {
      const open = indexedDB.open("rights-smoke-fixture");
      open.onerror = () => reject(open.error);
      open.onsuccess = () => {
        const db = open.result;
        const tx = db.transaction("unrelated", "readonly");
        const read = tx.objectStore("unrelated").get("draft");
        read.onsuccess = () => resolve(read.result);
        tx.oncomplete = () => db.close();
      };
    }),
  }));
  assert.equal(state.local, "synthetic draft must remain");
  assert.equal(state.session, "synthetic session must remain");
  assert.equal(state.indexed, "synthetic indexed draft");
  assert.deepEqual(state.writes, []);
  assert.deepEqual(state.events, []);
  assert.equal(await page.locator("#project-name").count(), 0);
  assert.equal(await page.locator(".web-account-menu__trigger").count(), 0);
}

async function capture(page, filename) {
  // Capture fixed navigation at the document top rather than embedding its
  // current scrolled viewport position in a full-page image.
  await page.evaluate(() => {
    window.scrollTo(0, 0);
    if (document.activeElement instanceof HTMLElement)
      document.activeElement.blur();
  });
  await page.screenshot({ path: path.join(output, filename), fullPage: true });
}

async function runCase(locale, width) {
  stage = `${locale}-${width}: setup`;
  const es = locale === "es";
  const context = await browser.newContext({
    viewport: { width, height: 1000 },
    locale: es ? "es-ES" : "en-US",
    acceptDownloads: true,
    reducedMotion: "reduce",
    serviceWorkers: "block",
  });
  const { state, ownData } = await installFixture(context);
  const page = await context.newPage();
  activePage = page;
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto(`${target}/?lang=${locale}`);
  await page
    .getByRole("button", {
      name: es ? "Preparar mi proyecto" : "Prepare my project",
      exact: true,
    })
    .click();
  await page
    .getByRole("button", {
      name: es ? "Continuar al acceso" : "Continue to sign in",
      exact: true,
    })
    .click();
  await page.locator("#web-signin-title").waitFor();
  await page.getByRole("button", { name: "Privacy", exact: true }).click();
  const details = page.locator(
    ".cookie-preferences-dialog details.web-signin__rights",
  );
  await details.locator("summary").click();
  const google = details.getByRole("button", {
    name: es ? "Verificar con Google" : "Verify with Google",
    exact: true,
  });
  const github = details.getByRole("button", {
    name: es ? "Verificar con GitHub" : "Verify with GitHub",
    exact: true,
  });
  await until(
    () => google.isEnabled(),
    "Rights providers did not become available.",
  );
  await instrumentStorage(page);
  stage = `${locale}-${width}: data`;
  const downloadPromise = page.waitForEvent("download");
  await google.click();
  const download = await downloadPromise;
  const downloaded = await readFile(await download.path());
  assert.equal(download.suggestedFilename(), "accreatio-account-data.json");
  assert.deepEqual(downloaded, Buffer.from(JSON.stringify(ownData, null, 2)));
  await until(() => google.isEnabled(), "Data flow did not release UI.");
  assert.equal(state.data, 1);
  await verifyLocalPreservation(page);

  stage = `${locale}-${width}: wrong transaction`;
  state.next = "wrong";
  await google.click();
  await details.getByRole("alert").waitFor();
  assert.match(
    await details.getByRole("alert").innerText(),
    es ? /verificaci[oó]n|verifica/i : /verif/i,
  );
  assert.equal(state.data, 1);
  await until(() => google.isEnabled(), "Denied proof did not release UI.");

  stage = `${locale}-${width}: deletion`;
  await details.locator("select").selectOption("delete");
  await github.click();
  const confirm = details.getByRole("button", {
    name: es ? "Eliminar la cuenta verificada" : "Delete the verified account",
    exact: true,
  });
  await confirm.waitFor();
  assert.equal(
    state.deletes,
    0,
    "Verification must never delete without a separate confirmation.",
  );
  await capture(page, `rights-confirm-${locale}-${width}.png`);
  await confirm.click();
  await until(
    () => state.deletes === 1,
    "Confirmed deletion did not reach the dedicated wrapper.",
  );
  await until(() => google.isEnabled(), "Deletion did not release UI.");
  await verifyLocalPreservation(page);

  stage = `${locale}-${width}: rate limit`;
  await details.locator("select").selectOption("data");
  state.next = "rate";
  await google.click();
  await details.getByRole("alert").waitFor();
  assert.equal(
    await google.isDisabled(),
    true,
    "Retry-After must disable provider actions.",
  );
  assert.match(await details.innerText(), /\d+ s\./);
  await until(() => google.isEnabled(), "Retry-After did not expire.", 5000);

  stage = `${locale}-${width}: cancellation`;
  state.next = "hold";
  await google.click();
  const cancel = details.getByRole("button", {
    name: es ? "Cancelar verificación" : "Cancel verification",
    exact: true,
  });
  await cancel.waitFor();
  await cancel.click();
  await until(
    () => state.cancels === 1,
    "Cancellation did not reach its transaction endpoint.",
  );
  const pollsAfterCancel = state.requests.filter((request) =>
    request.path.endsWith("/status"),
  ).length;
  await new Promise((resolve) => setTimeout(resolve, 1200));
  assert.equal(
    state.requests.filter((request) => request.path.endsWith("/status")).length,
    pollsAfterCancel,
    "Cancellation must stop transaction polling.",
  );
  assert.equal(state.data, 1);
  assert.equal(state.deletes, 1);
  await verifyLocalPreservation(page);
  assert.deepEqual(state.external, []);
  assert.deepEqual(errors, []);
  assert.ok(
    state.requests.every(
      (request) =>
        !request.path.includes("/oidc/") &&
        !request.path.endsWith("/authorize") &&
        !request.path.endsWith("/logout"),
    ),
  );
  assert.ok(
    state.requests
      .filter((request) => request.method === "POST")
      .every((request) => request.body?.policyAuthorization === undefined),
  );
  assert.equal(
    (await context.cookies()).filter(
      (cookie) => cookie.name === "__Host-accreatio_session",
    ).length,
    0,
  );
  const layout = await page.evaluate(() => ({
    width: innerWidth,
    scrollWidth: document.documentElement.scrollWidth,
  }));
  assert.ok(
    layout.scrollWidth <= layout.width + 1,
    `Horizontal overflow at ${locale}/${width}`,
  );
  await capture(page, `rights-final-${locale}-${width}.png`);
  const result = {
    locale,
    width,
    result: "PASS",
    starts: state.starts,
    dataDownloads: state.data,
    confirmedDeletions: state.deletes,
    cancelledTransactions: state.cancels,
    downloadBytes: downloaded.length,
    downloadSha256: createHash("sha256").update(downloaded).digest("hex"),
    externalNetworkRequests: state.external.length,
    localStorageAndIndexedDbWrites: 0,
    ordinarySessionAdopted: false,
    pollingStoppedAfterCancel: true,
    providerWindowsRemaining: context.pages().length - 1,
    popupClosureScope:
      "Cross-origin/isolated provider windows may require manual closure; transaction cancellation and no subsequent actions are verified.",
  };
  report.cases.push(result);
  console.log(
    `PASS rights UI ${locale}/${width}: exact download, transaction rejection, confirmed deletion, Retry-After, popup cancellation, local preservation.`,
  );
  await context.close();
  activePage = null;
}

try {
  await until(
    async () => {
      try {
        return (await fetch(target)).ok;
      } catch {
        return false;
      }
    },
    "Rights preview did not start.",
    30000,
  );
  browser = await chromium.launch();
  for (const locale of ["en", "es"])
    for (const width of [1280, 320]) await runCase(locale, width);
  report.result = "PASS";
} catch (error) {
  report.result = "FAIL";
  report.stage = stage;
  report.error = error instanceof Error ? error.message : String(error);
  try {
    await activePage?.screenshot({
      path: path.join(output, "failure.png"),
      fullPage: true,
    });
  } catch {
    /* Keep original error. */
  }
  console.error(error);
  process.exitCode = 1;
} finally {
  await writeFile(
    path.join(output, "receipt.json"),
    JSON.stringify(report, null, 2) + "\n",
  );
  await browser?.close();
  preview.kill();
  console.log(`Evidence: ${path.relative(root, output)}`);
}
