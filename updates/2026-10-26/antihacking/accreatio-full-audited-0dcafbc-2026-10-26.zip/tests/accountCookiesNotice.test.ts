import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import {
  harness,
  POLICY_AUTHORIZATION,
  POLICY_CONTINUATION,
} from "./helpers/accountHarness";

test("0010 preserves existing receipts and leaves all cookies acknowledgements absent", () => {
  const db = new DatabaseSync(":memory:");
  db.exec(
    "PRAGMA foreign_keys=ON; CREATE TABLE accounts(id TEXT PRIMARY KEY,deleted_at INTEGER); INSERT INTO accounts VALUES('old',NULL); CREATE TABLE existing_receipt(account_id TEXT,version TEXT,at INTEGER); INSERT INTO existing_receipt VALUES('old','prior',123)",
  );
  const before = db.prepare("SELECT * FROM existing_receipt").all();
  db.exec(
    readFileSync(
      new URL(
        "../migrations-auth/0010_cookies_notice_acknowledgement.sql",
        import.meta.url,
      ),
      "utf8",
    ),
  );
  assert.deepEqual(db.prepare("SELECT * FROM existing_receipt").all(), before);
  assert.equal(
    db.prepare("SELECT count(*) n FROM account_notice_acknowledgements").get()
      ?.n,
    0,
  );
  db.close();
});

test("sign-in and repeated session reads never acknowledge cookies; own data remains available", async () => {
  const h = await harness();
  const requested = await h.call("otp/request", {
    body: {
      email: "new@example.test",
      policyAuthorization: POLICY_AUTHORIZATION,
    },
  });
  const { challengeId } = await requested.json();
  const signedIn = await h.call("otp/verify", {
    body: { challengeId, code: h.mailbox.at(-1)!.code },
  });
  assert.equal((await signedIn.json()).policyAuthorizationRequired, true);
  const cookie = signedIn.headers.get("Set-Cookie")!.split(";")[0];
  for (let i = 0; i < 3; i++)
    assert.equal(
      (await (await h.call("session", { method: "GET", cookie })).json())
        .policyAuthorizationRequired,
      true,
    );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT count(*) n FROM account_notice_acknowledgements")
      .get()?.n,
    0,
  );
  assert.equal(
    (
      await h.call("authorize", {
        cookie,
        body: { operationId: crypto.randomUUID() },
      })
    ).status,
    403,
  );
  await h.controlProof(cookie, "data");
  const data = await h.call("data", { method: "GET", cookie });
  assert.equal(data.status, 200);
  assert.equal((await data.json()).cookiesNoticeAcknowledgement, null);
  assert.equal(
    (await h.call("policy", { cookie, body: POLICY_AUTHORIZATION })).status,
    400,
  );
  assert.equal(
    (await h.call("policy", { cookie, body: POLICY_CONTINUATION })).status,
    200,
  );
  const saved = h.db.sqlite
    .prepare("SELECT * FROM account_notice_acknowledgements")
    .get();
  assert.equal(saved?.acknowledged_at, h.db.now);
  h.db.now += 1000;
  assert.equal(
    (await h.call("policy", { cookie, body: POLICY_CONTINUATION })).status,
    200,
  );
  assert.deepEqual(
    h.db.sqlite.prepare("SELECT * FROM account_notice_acknowledgements").get(),
    saved,
  );
});

test("notice receipts bind to each verified account, roll back on failure and purge on deletion", async () => {
  const h = await harness();
  const first = await h.login({ email: "first@example.test" });
  const second = await h.login(
    { email: "second@example.test" },
    { policyAuthorization: false },
  );
  assert.equal(
    (await (await h.call("session", { method: "GET", cookie: first })).json())
      .policyAuthorizationRequired,
    false,
  );
  assert.equal(
    (await (await h.call("session", { method: "GET", cookie: second })).json())
      .policyAuthorizationRequired,
    true,
  );
  h.db.sqlite.exec(
    "CREATE TRIGGER notice_failure BEFORE INSERT ON account_notice_acknowledgements BEGIN SELECT RAISE(ABORT,'synthetic'); END;",
  );
  assert.equal(
    (await h.call("policy", { cookie: second, body: POLICY_CONTINUATION }))
      .status,
    503,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT count(*) n FROM account_notice_acknowledgements")
      .get()?.n,
    1,
  );
  h.db.sqlite.exec("DROP TRIGGER notice_failure");
  await h.controlProof(first, "delete");
  assert.equal((await h.call("delete", { cookie: first })).status, 200);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT count(*) n FROM account_notice_acknowledgements")
      .get()?.n,
    0,
  );
});
