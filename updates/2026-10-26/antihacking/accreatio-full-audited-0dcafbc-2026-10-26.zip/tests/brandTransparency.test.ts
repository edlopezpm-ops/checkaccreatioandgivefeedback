import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { chromium } from "playwright";

test("official logo keeps original custody and transparent theme contours", async () => {
  for (const [path, sha256] of [
    [
      "assets/branding/accreatio-logo-approved-2026-10-22.png",
      "0c53ade5c085e5867541ab933a53288b35e8157f9b1e7698c6536725e5a4b71a",
    ],
    [
      "public/branding/accreatio-mark.png",
      "166352f90972a84b111d320387d819bf36dbd40758550eed373697352a218c20",
    ],
    [
      "public/branding/accreatio-wordmark.png",
      "021b2330f44102e573d5817b0a631a332446b20ff9cf177036cd236e946f9184",
    ],
    [
      "public/branding/accreatio-lockup.png",
      "23ae87231062499944311bd54f20ce8d9f69c54af736bc7e74b8fcc8589e117a",
    ],
  ]) {
    const original = await readFile(new URL(`../${path}`, import.meta.url));
    assert.equal(createHash("sha256").update(original).digest("hex"), sha256);
  }
  const browser = await chromium.launch();
  try {
    const page = await browser.newPage();
    for (const name of ["mark", "wordmark", "lockup"]) {
      const variants = await Promise.all(
        ["light", "dark"].map(async (theme) => {
          const svg = await readFile(
            new URL(
              `../public/branding/accreatio-${name}-${theme}.svg`,
              import.meta.url,
            ),
            "utf8",
          );
          return `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
        }),
      );
      const result = await page.evaluate(async (sources) => {
        const pixels = await Promise.all(
          sources.map(async (source) => {
            const image = new Image();
            image.src = source;
            await image.decode();
            const canvas = document.createElement("canvas");
            canvas.width = image.naturalWidth;
            canvas.height = image.naturalHeight;
            const context = canvas.getContext("2d")!;
            context.drawImage(image, 0, 0);
            return {
              data: context.getImageData(0, 0, canvas.width, canvas.height)
                .data,
              width: canvas.width,
              height: canvas.height,
            };
          }),
        );
        const [light, dark] = pixels;
        let foreground = 0,
          red = 0,
          contourDifferences = 0;
        for (let i = 0; i < light.data.length; i += 4) {
          if (light.data[i + 3] > 200) foreground++;
          if (light.data[i + 3] > 200 && light.data[i] > light.data[i + 1] * 2)
            red++;
          if (light.data[i + 3] !== dark.data[i + 3]) contourDifferences++;
        }
        const cornerAlpha = pixels.flatMap(({ data, width, height }) =>
          [0, width - 1, width * (height - 1), width * height - 1].map(
            (p) => data[p * 4 + 3],
          ),
        );
        const transparent = Array.from(light.data)
          .filter((_, i) => i % 4 === 3)
          .filter((alpha) => alpha === 0).length;
        return {
          foreground,
          red,
          contourDifferences,
          cornerAlpha,
          transparent,
          area: light.width * light.height,
        };
      }, variants);
      assert.deepEqual(
        result.cornerAlpha,
        Array(8).fill(0),
        `${name} has a visible plate at a corner`,
      );
      assert.ok(
        result.transparent > result.area * 0.4,
        `${name} retains its pale plate`,
      );
      assert.ok(
        result.foreground > result.area * 0.03,
        `${name} lost its supplied contours`,
      );
      if (name !== "wordmark")
        assert.ok(result.red > result.area * 0.003, `${name} lost its red dot`);
      assert.equal(
        result.contourDifferences,
        0,
        `${name} changes geometry between themes`,
      );
    }
  } finally {
    await browser.close();
  }
});
