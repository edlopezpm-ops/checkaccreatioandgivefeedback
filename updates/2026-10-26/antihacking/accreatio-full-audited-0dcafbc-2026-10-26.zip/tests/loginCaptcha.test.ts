import assert from "node:assert/strict";
import test from "node:test";
import { handleOidc } from "../functions/_lib/auth/oidc";
import {
  loginCaptchaConfiguration,
  verifyLoginCaptcha,
} from "../functions/_lib/auth/captcha";
import type { AccountBindings } from "../functions/_lib/accounts";
import type {
  OidcStore,
  CreateOidcTransaction,
} from "../functions/_lib/auth/oidc-contracts";
import { ApiError } from "../functions/_lib/http";
import { ACCOUNT_POLICY } from "../shared/accountPolicy";
import {
  loadWebAuthMethods,
  startProviderSignIn,
  AccountError,
} from "../src/account/webClient";
import type { RuntimeDependencies } from "../functions/_lib/platform";

const origin = "https://accreatio.com";
const env: AccountBindings = {
  ACCOUNT_ENABLED: "true",
  ACCOUNT_OIDC_ENABLED: "true",
  ACCOUNT_GITHUB_ENABLED: "true",
  ACCOUNT_DB: {} as AccountBindings["ACCOUNT_DB"],
  ACCOUNT_IDENTITY_KEY: "a".repeat(64),
  ACCOUNT_OIDC_TRANSACTION_KEY: "c".repeat(64),
  ACCOUNT_EMAIL_ENCRYPTION_KEY: "d".repeat(64),
  ACCOUNT_EMAIL_LOOKUP_KEY: "e".repeat(64),
  ACCOUNT_AUTH_LOCATOR_KEY: "f".repeat(64),
  GOOGLE_CLIENT_ID: "fixture.apps.googleusercontent.com",
  GOOGLE_CLIENT_SECRET: "synthetic-google-secret",
  GOOGLE_REDIRECT_URI: `${origin}/api/auth/v1/oidc/google/callback`,
  GITHUB_CLIENT_ID: "fixture-github-client",
  GITHUB_CLIENT_SECRET: "synthetic-github-secret",
  GITHUB_REDIRECT_URI: `${origin}/api/auth/v1/oidc/github/callback`,
  ACCOUNT_CAPTCHA_ENABLED: "true",
  TURNSTILE_SITE_KEY: "fixture-site-key",
  TURNSTILE_SECRET: "synthetic-turnstile-secret",
  TURNSTILE_HOSTNAMES: "accreatio.com",
};
const proof = {
  ...ACCOUNT_POLICY,
  accountDataAuthorized: true,
  termsAccepted: true,
};
const request = () => new Request(`${origin}/api/auth/v1/methods`);
const dependencies = (fetcher: typeof fetch): RuntimeDependencies => ({
  now: () => Date.now(),
  randomUUID: () => crypto.randomUUID(),
  subtle: crypto.subtle,
  fetch: fetcher,
});

test("CAPTCHA config fails closed for ordinary login without hiding independent rights providers", async () => {
  const configured = await handleOidc({ request: request(), env }, "methods");
  const publicMethods = await configured.json();
  assert.deepEqual(publicMethods.captcha, {
    required: true,
    siteKey: env.TURNSTILE_SITE_KEY,
  });
  assert.ok(!JSON.stringify(publicMethods).includes(env.TURNSTILE_SECRET!));
  for (const invalid of [
    { ...env, TURNSTILE_SECRET: undefined },
    { ...env, TURNSTILE_HOSTNAMES: "other.example" },
    { ...env, TURNSTILE_SITE_KEY: "wrong key" },
  ]) {
    assert.throws(
      () => loginCaptchaConfiguration(invalid, request()),
      (error: unknown) =>
        error instanceof ApiError && error.code === "captcha_unavailable",
    );
    const result = await handleOidc(
      { request: request(), env: invalid },
      "methods",
    );
    const body = await result.json();
    assert.equal(result.status, 200);
    assert.deepEqual(body.captcha, { required: true, siteKey: null });
    assert.equal(body.methods.google.available, true);
    assert.equal(body.methods.github.available, true);
    assert.ok(!JSON.stringify(body).includes(env.TURNSTILE_SECRET!));
  }
});

test("server verification bounds input and checks success, action, hostname, and malformed/upstream failures", async () => {
  let calls = 0;
  const success = dependencies(async (input, init) => {
    calls++;
    assert.equal(
      String(input),
      "https://challenges.cloudflare.com/turnstile/v0/siteverify",
    );
    assert.equal(init?.redirect, "manual");
    assert.ok(init?.body instanceof URLSearchParams);
    assert.equal(init.body.get("secret"), env.TURNSTILE_SECRET);
    assert.equal(init.body.get("response"), "valid-token");
    assert.equal(init.body.get("remoteip"), null);
    return Response.json({
      success: true,
      action: "login",
      hostname: "accreatio.com",
    });
  });
  for (const token of [undefined, null, 5, "", "x".repeat(2049), "token space"])
    await assert.rejects(
      verifyLoginCaptcha(env, request(), token, success),
      (error: unknown) =>
        error instanceof ApiError && error.code === "captcha_required",
    );
  assert.equal(calls, 0);
  await verifyLoginCaptcha(env, request(), "valid-token", success);
  assert.equal(calls, 1);
  for (const body of [
    { success: false, "error-codes": ["timeout-or-duplicate"] },
    { success: true, action: "other", hostname: "accreatio.com" },
    { success: true, action: "login", hostname: "other.example" },
  ])
    await assert.rejects(
      verifyLoginCaptcha(
        env,
        request(),
        "valid-token",
        dependencies(async () => Response.json(body)),
      ),
      (error: unknown) =>
        error instanceof ApiError && error.code === "captcha_invalid",
    );
  for (const fetcher of [
    async () => {
      throw new Error("upstream-private-error");
    },
    async () => new Response(null, { status: 302 }),
    async () =>
      new Response("bad json", {
        headers: { "Content-Type": "application/json" },
      }),
    async () => Response.json({ payload: "x".repeat(20_000) }),
  ])
    await assert.rejects(
      verifyLoginCaptcha(env, request(), "valid-token", dependencies(fetcher)),
      (error: unknown) =>
        error instanceof ApiError &&
        error.code === "captcha_unavailable" &&
        !error.message.includes("private"),
    );
});

test("Google and GitHub share login verification; missing/replayed tokens create no transactions; rights proof stays independent", async () => {
  const created: CreateOidcTransaction[] = [];
  const store: OidcStore = {
    createTransaction: async (input) => {
      created.push(input);
      return { expiresAt: Date.now() + 600_000 };
    },
    claimTransaction: async () => null,
    getTransactionStatus: async () => null,
    cancelTransaction: async () => null,
    failTransaction: async () => {},
    completeGoogleLogin: async () => ({ expiresAt: Date.now() + 600_000 }),
  };
  const used = new Set<string>();
  const deps = dependencies(async (_input, init) => {
    const token = (init?.body as URLSearchParams).get("response")!;
    const success = !used.has(token);
    used.add(token);
    return Response.json({
      success,
      action: "login",
      hostname: "accreatio.com",
    });
  });
  const start = (
    provider: "google" | "github",
    token?: string,
    rights = false,
  ) =>
    handleOidc(
      {
        env,
        request: new Request(
          `${origin}/api/auth/v1/${rights ? "rights" : "oidc"}/${provider}/start`,
          {
            method: "POST",
            headers: { Origin: origin, "Content-Type": "application/json" },
            body: JSON.stringify(
              rights
                ? {
                    purpose: "account_access",
                    returnRoute: "builder",
                    mode: "popup",
                    rightsOnly: true,
                    verificationAction: "data",
                  }
                : {
                    purpose: "sign_in",
                    returnRoute: "builder",
                    mode: "redirect",
                    policyAuthorization: proof,
                    ...(token ? { captchaToken: token } : {}),
                  },
            ),
          },
        ),
      },
      "start",
      deps,
      store,
      provider,
    );
  for (const provider of ["google", "github"] as const) {
    const absent = await start(provider);
    assert.equal(absent.status, 403);
    assert.equal((await absent.json()).error.code, "captcha_required");
    const token = `valid-${provider}`;
    assert.equal((await start(provider, token)).status, 200);
    const count = created.length;
    const replay = await start(provider, token);
    assert.equal(replay.status, 403);
    assert.equal((await replay.json()).error.code, "captcha_invalid");
    assert.equal(created.length, count);
  }
  assert.equal(created.length, 2);
  assert.equal((await start("github", undefined, true)).status, 200);
  assert.equal(created.at(-1)?.rightsOnly, true);
  assert.equal(created.at(-1)?.policyAuthorization, undefined);
});

test("browser discovers shared public key and passes a token only to ordinary provider sign-in", async (t) => {
  const fixture = {
    version: "auth.v1",
    methods: {
      google: { available: true },
      github: { available: true },
      emailOtp: { available: false },
    },
    captcha: { required: true, siteKey: "fixture-site-key" },
  };
  const fetchMock = t.mock.method(globalThis, "fetch", async () =>
    Response.json(fixture),
  );
  assert.deepEqual(await loadWebAuthMethods(), fixture);
  for (const captcha of [
    { required: false, siteKey: "fixture" },
    { required: true, siteKey: "invalid key" },
    null,
  ]) {
    fetchMock.mock.mockImplementation(async () =>
      Response.json({ ...fixture, captcha }),
    );
    await assert.rejects(loadWebAuthMethods(), AccountError);
  }
  fetchMock.mock.mockImplementation(async () =>
    Response.json({ ...fixture, captcha: { required: true, siteKey: null } }),
  );
  assert.equal((await loadWebAuthMethods()).captcha?.siteKey, null);
  for (const purpose of ["sign_in", "account_access"] as const) {
    fetchMock.mock.mockImplementation(async (_url, init) => {
      const body = JSON.parse(String(init?.body));
      assert.equal(
        body.captchaToken,
        purpose === "sign_in" ? "shared-response" : undefined,
      );
      return Response.json({
        transactionId: "opaque-transaction-123456",
        authorizationUrl:
          "https://github.com/login/oauth/authorize?state=opaque",
        expiresAt: new Date(Date.now() + 60_000).toISOString(),
      });
    });
    await startProviderSignIn("github", "popup", {
      purpose,
      captchaToken: "shared-response",
      verificationAction: purpose === "account_access" ? "data" : undefined,
    });
  }
});
