import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const read = (path: string) =>
  readFileSync(new URL(path, import.meta.url), "utf8");
const app = read("../src/App.tsx");
const onboarding = read("../src/components/Onboarding.tsx");
const styles = read("../src/styles.css");
const responsive = read("../src/responsive.css");

test("first-run onboarding has two outcome-led, local-first screens", () => {
  assert.match(onboarding, /What you will make/);
  assert.match(onboarding, /What stays local/);
  assert.match(onboarding, /5–10 minutes/);
  assert.match(onboarding, /local folder on desktop/);
  assert.match(onboarding, /downloadable ZIP on the web/);
  assert.doesNotMatch(
    onboarding,
    /Cloudflare handles access|creates no internal account/,
  );
  assert.match(onboarding, /desktop edition requires no account/);
  assert.match(onboarding, /syncs no projects to the cloud/);
  assert.match(onboarding, /web keeps accounts and Blog posts separate/);
  assert.match(onboarding, /Selected files remain only in the tab/);
});

test("guided completion enters creation and contextual help replaces welcome shortcuts", () => {
  assert.doesNotMatch(onboarding, /Omitir|Skip|onboarding-skip/);
  assert.match(onboarding, /Continue/);
  assert.match(onboarding, /Finish and create/);
  assert.match(onboarding, /onClick=\{onComplete\}/);
  assert.match(app, /saveOnboardingCompletion\(\)/);
  assert.doesNotMatch(app, /View welcome|Ver bienvenida/);
  assert.match(app, /setShowOnboarding\(true\)/);
  assert.match(onboarding, /Prepare the brief for your next project/);
  assert.doesNotMatch(
    onboarding,
    /Prepare the brief for (?:tour next|your next software) project/,
  );
  assert.match(
    onboarding,
    /<a[\s\S]*?href="#example-guide"[\s\S]*?aria-haspopup="dialog"/,
  );
  assert.match(onboarding, /<HelpDialog[\s\S]*?mode="example"/);
  assert.doesNotMatch(
    onboarding,
    /href=[^\n]*examples|manifest\.json|START\.\$\{locale\}\.md/,
  );
});

test("help stays contextual and About opens above the current screen", () => {
  const projectHelp = read("../src/components/creation/ProjectHelp.tsx");
  const guided = read("../src/components/creation/GuidedCreation.tsx");
  const helpDialog = read("../src/components/help/HelpDialog.tsx");
  const about = read("../src/components/help/AboutPopover.tsx");
  assert.match(projectHelp, /<a[\s\S]*?aria-haspopup="dialog"/);
  assert.match(projectHelp, /event\.preventDefault\(\)/);
  assert.match(projectHelp, /es \? "ayuda" : "help"/);
  assert.doesNotMatch(projectHelp, /FAQ|ToS|about-faq|about-terms/);
  assert.match(guided, /topic=\{current\}/);
  assert.match(helpDialog, /surface\.showModal\(\)/);
  assert.match(helpDialog, /trigger\.focus\(\{ preventScroll: true \}\)/);
  assert.match(about, /popover="auto"/);
  assert.match(about, /authenticated \? \["help"\] : \[\]/);
  assert.match(about, /faqOnly/);
  assert.match(about, /href=\{legalHref\("privacy", locale\)\}/);
  assert.match(about, /href=\{termsHref\(locale\)\}/);
});

test("onboarding is semantic, keyboard-native, and explains unavailable storage", () => {
  assert.match(onboarding, /<main className="onboarding" aria-labelledby=/);
  assert.match(onboarding, /role="status"/);
  assert.match(onboarding, /may appear again/);
  const buttons = [...onboarding.matchAll(/<button\b([^>]*)>/g)];
  assert.ok(buttons.length >= 3);
  for (const [, attributes] of buttons)
    assert.match(attributes, /type="button"/);
  assert.match(
    styles,
    /\.onboarding-actions button\s*{[\s\S]*?min-height:\s*var\(--touch-target\)/,
  );
});

test("mobile onboarding uses one-column facts and a safe-area action region", () => {
  assert.match(
    responsive,
    /@media \(max-width: 767px\)[\s\S]*?\.onboarding-facts\s*{[\s\S]*?grid-template-columns:\s*1fr/,
  );
  assert.match(
    responsive,
    /\.onboarding-actions\s*{[\s\S]*?env\(safe-area-inset-bottom\)/,
  );
  assert.doesNotMatch(styles, /\.onboarding\s*{[^}]*min-width/);
});
