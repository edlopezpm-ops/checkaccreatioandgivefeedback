import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import vm from "node:vm";
import React, { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { legalHref } from "../src/legal";
import { AccountPolicyFields } from "../src/components/account/AccountPolicyFields";

Object.assign(globalThis, { React });

const read = (file: string) =>
  readFileSync(new URL(file, import.meta.url), "utf8");

function legalPage(href: string): {
  href: string;
  locale: string;
  links: { raw: string; href: string }[];
} {
  const current = new URL(href, "https://accreatio.com");
  const basename = current.pathname
    .split("/")
    .at(-1)!
    .replace(/\.html$/u, "");
  assert.match(basename, /^(?:terms(?:-es)?|privacy|cookies|faq)$/u);
  const html = read(`../public/legal/${basename}.html`);
  const links = [...html.matchAll(/<a\b[^>]*href="([^"]+)"/gu)].map((match) => {
    const raw = match[1].replaceAll("&amp;", "&");
    let absolute = new URL(raw, current).href;
    return {
      raw,
      get href() {
        return absolute;
      },
      set href(value: string) {
        absolute = new URL(value, current).href;
      },
    };
  });
  const root = {
    lang: html.match(/<html lang="([^"]+)"/u)![1],
    hidden: false,
  };
  const ready: (() => void)[] = [];
  let redirected: string | undefined;
  const context = vm.createContext({
    URL,
    window: {
      location: {
        href: current.href,
        replace: (target: string) => {
          redirected = new URL(target, current).href;
        },
      },
    },
    document: {
      // The deployed global header forbids sending a referrer on every hop.
      referrer: "",
      documentElement: root,
      querySelectorAll: () => links,
      addEventListener: (event: string, handler: () => void) => {
        assert.equal(event, "DOMContentLoaded");
        ready.push(handler);
      },
    },
  });
  for (const match of html.matchAll(/<script\b[^>]*src="([^"]+)"/gu)) {
    if (!/^(?:terms-language|legal-navigation)\.js$/u.test(match[1])) continue;
    vm.runInContext(read(`../public/legal/${match[1]}`), context);
  }
  if (redirected) return legalPage(redirected);
  ready.forEach((handler) => handler());
  return { href: current.href, locale: root.lang, links };
}

function termsLinks(page: ReturnType<typeof legalPage>) {
  return page.links.filter((link) =>
    /\/legal\/terms(?:-es)?(?:\.html)?$/u.test(new URL(link.href).pathname),
  );
}

test("application legal entrypoints carry the primary locale before any referrer-free navigation", () => {
  for (const locale of ["es", "en"] as const) {
    const notice = renderToStaticMarkup(
      createElement(AccountPolicyFields, { locale }),
    );
    for (const destination of ["privacy", "cookies", "faq"] as const) {
      const href = legalHref(destination, locale);
      assert.equal(href, `/legal/${destination}.html?lang=${locale}`);
      for (const link of termsLinks(legalPage(href))) {
        assert.equal(legalPage(link.href).locale, locale);
      }
      if (destination !== "faq") assert.ok(notice.includes(`href="${href}"`));
    }
  }
  for (const file of [
    "AboutExperience",
    "WebProjectInformation",
    "account/AccountPolicyFields",
    "account/CookiePreferences",
    "help/AboutPopover",
    "account/WebAccountMenu",
  ]) {
    const source = read(`../src/components/${file}.tsx`);
    assert.match(
      source,
      /href=\{legalHref\("(?:privacy|cookies|faq)", locale\)\}/u,
    );
    assert.doesNotMatch(source, /href="\/legal\/(?:privacy|cookies|faq)/u);
  }
});

test("legal return preserves EN/ES with the real no-referrer policy across Privacy, Cookies and FAQ", () => {
  assert.match(read("../public/_headers"), /Referrer-Policy:\s*no-referrer/u);
  for (const locale of ["es", "en"]) {
    const initial = legalPage(
      `/legal/terms${locale === "es" ? "-es" : ""}.html?lang=${locale}`,
    );
    for (const destination of ["privacy", "cookies", "faq"]) {
      const outward = initial.links.find((link) =>
        new URL(link.href).pathname.endsWith(`/${destination}.html`),
      );
      assert.ok(outward);
      const information = legalPage(outward.href);
      const returns = termsLinks(information);
      assert.ok(returns.length > 0);
      for (const link of returns) {
        const returned = legalPage(link.href);
        assert.equal(
          returned.locale,
          locale,
          `${locale}: Terms → ${destination} → Terms must retain the selected document without referrer`,
        );
        assert.equal(new URL(link.href).searchParams.get("lang"), locale);
      }
    }
  }
});

test("intermediate legal hops and app return carry explicit language without storage or referrer", () => {
  for (const locale of ["es", "en"]) {
    for (const destination of ["privacy", "cookies", "faq"]) {
      const page = legalPage(`/legal/${destination}.html?lang=${locale}`);
      for (const link of page.links) {
        const target = new URL(link.href);
        if (target.origin !== "https://accreatio.com") continue;
        if (target.pathname === "/") {
          assert.equal(target.searchParams.get("lang"), locale);
        } else if (
          /^\/legal\/(?:privacy|cookies|faq)(?:\.html)?$/u.test(
            target.pathname,
          ) &&
          !link.raw.startsWith("#")
        ) {
          assert.equal(target.searchParams.get("lang"), locale);
          for (const termsLink of termsLinks(legalPage(link.href))) {
            assert.equal(legalPage(termsLink.href).locale, locale);
          }
        }
      }
      assert.equal(
        page.links.find((link) => link.raw === "#espanol")?.href,
        page.links.find((link) => link.raw === "#espanol")
          ? `https://accreatio.com/legal/${destination}.html?lang=${locale}#espanol`
          : undefined,
      );
    }
  }
});
