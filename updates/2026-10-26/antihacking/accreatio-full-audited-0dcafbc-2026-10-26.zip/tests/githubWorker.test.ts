import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { build } from "esbuild";
import { Miniflare, convertV4MiniflareOptions } from "miniflare";
import { POLICY_AUTHORIZATION } from "./helpers/accountHarness";

test(
  "GitHub authorization executes in workerd with real D1, encrypted PKCE and Strict session",
  { timeout: 60_000 },
  async () => {
    const origin = "https://accreatio.pages.dev";
    let authorization: URL;
    let userReads = 0;
    const output = await build({
      stdin: {
        contents: `import {handleOidc} from './functions/_lib/auth/oidc.ts';
    import {handleAccount} from './functions/_lib/accounts.ts';
    export default {fetch(request,env){const path=new URL(request.url).pathname;
      if(path.startsWith('/api/account/'))return handleAccount({request,env},path.split('/').at(-1));
      const action=path.endsWith('/start')?'start':path.endsWith('/callback')?'callback':'methods';
      return handleOidc({request,env},action,{fetch:(url,init)=>env.GITHUB_FIXTURE.fetch(new Request(url,init)),now:()=>Date.now(),randomUUID:()=>crypto.randomUUID(),subtle:crypto.subtle},undefined,'github');}};`,
        resolveDir: process.cwd(),
        loader: "ts",
      },
      bundle: true,
      platform: "browser",
      target: "es2022",
      format: "esm",
      write: false,
    });
    const mf = new Miniflare(
      convertV4MiniflareOptions({
        modules: true,
        script: output.outputFiles[0].text,
        compatibilityDate: "2026-08-06",
        d1Databases: ["ACCOUNT_DB"],
        bindings: {
          ACCOUNT_ENABLED: "true",
          ACCOUNT_GITHUB_ENABLED: "true",
          ACCOUNT_OIDC_ENABLED: "false",
          ACCOUNT_OTP_ENABLED: "false",
          ACCOUNT_IDENTITY_KEY: "a".repeat(64),
          ACCOUNT_OTP_KEY: "b".repeat(64),
          ACCOUNT_OIDC_TRANSACTION_KEY: "c".repeat(64),
          ACCOUNT_EMAIL_ENCRYPTION_KEY: "d".repeat(64),
          ACCOUNT_EMAIL_LOOKUP_KEY: "e".repeat(64),
          ACCOUNT_AUTH_LOCATOR_KEY: "f".repeat(64),
          GITHUB_CLIENT_ID: "Iv23.workerfixture",
          GITHUB_CLIENT_SECRET: "synthetic-worker-secret",
          GITHUB_REDIRECT_URI: `${origin}/api/auth/v1/oidc/github/callback`,
        },
        serviceBindings: {
          GITHUB_FIXTURE: async (request) => {
            if (request.url === "https://github.com/login/oauth/access_token") {
              const body = new URLSearchParams(await request.text());
              assert.equal(body.get("client_id"), "Iv23.workerfixture");
              const challenge = Buffer.from(
                await crypto.subtle.digest(
                  "SHA-256",
                  new TextEncoder().encode(body.get("code_verifier")!),
                ),
              ).toString("base64url");
              assert.equal(
                challenge,
                authorization.searchParams.get("code_challenge"),
              );
              return Response.json({
                access_token: "ghu_synthetic_worker",
                token_type: "bearer",
                refresh_token: "discarded_worker_token",
              });
            }
            assert.equal(
              request.headers.get("Authorization"),
              "Bearer ghu_synthetic_worker",
            );
            if (request.url === "https://api.github.com/user") {
              userReads++;
              return new Response(
                '{"id":9007199254740993,"login":"changing-handle","email":null,"name":"GitHub Worker Fixture"}',
                { headers: { "Content-Type": "application/json" } },
              );
            }
            assert.equal(
              request.url,
              "https://api.github.com/user/emails?per_page=100&page=1",
            );
            return Response.json([
              {
                email: "private-worker@example.test",
                primary: true,
                verified: true,
              },
            ]);
          },
        },
      }),
    );
    try {
      const db = await mf.getD1Database("ACCOUNT_DB");
      for (const filename of [
        "0001_accounts.sql",
        "0002_own_email_otp.sql",
        "0003_google_oidc_privacy.sql",
        "0004_google_display_name.sql",
        "0005_account_policy_authorization.sql",
        "0006_github_identity_linking.sql",
        "0007_abuse_guard.sql",
        "0008_rights_only.sql",
        "0010_cookies_notice_acknowledgement.sql",
      ]) {
        const sql = await readFile(
          new URL(`../migrations-auth/${filename}`, import.meta.url),
          "utf8",
        );
        for (const statement of sql
          .replace(/--[^\n]*/g, "")
          .split(/;\s*(?=CREATE|ALTER|UPDATE|$)/)
          .map((part) => part.trim())
          .filter(Boolean))
          await db.prepare(statement).run();
      }
      const start = await mf.dispatchFetch(
        `${origin}/api/auth/v1/oidc/github/start`,
        {
          method: "POST",
          headers: { Origin: origin, "Content-Type": "application/json" },
          body: JSON.stringify({
            purpose: "sign_in",
            returnRoute: "builder",
            mode: "popup",
            policyAuthorization: POLICY_AUTHORIZATION,
          }),
        },
      );
      assert.equal(start.status, 200);
      const tx = (await start.json()) as { authorizationUrl: string };
      authorization = new URL(tx.authorizationUrl);
      const cookie = start.headers.get("Set-Cookie")!.split(";")[0];
      const response = await mf.dispatchFetch(
        `${origin}/api/auth/v1/oidc/github/callback?state=${authorization.searchParams.get("state")}&code=fixture-code`,
        { headers: { Cookie: cookie }, redirect: "manual" },
      );
      assert.equal(response.status, 303);
      assert.match(response.headers.get("Location")!, /auth=success$/);
      const sessionCookie = response.headers.get("Set-Cookie")!;
      assert.match(sessionCookie, /Secure; HttpOnly; SameSite=Strict/);
      const session = await mf.dispatchFetch(`${origin}/api/account/session`, {
        headers: { Cookie: sessionCookie.split(";")[0] },
      });
      assert.equal(session.status, 200);
      const value = (await session.json()) as {
        email: string;
        connectedProviders: string[];
      };
      assert.equal(value.email, "private-worker@example.test");
      assert.deepEqual(value.connectedProviders, ["github"]);
      assert.equal(userReads, 1);
      assert.equal(
        (
          await db
            .prepare("SELECT subject FROM account_external_identities")
            .first<{ subject: string }>()
        )?.subject,
        "9007199254740993",
      );
      const raw = await db
        .prepare(
          "SELECT secrets_ciphertext,status FROM account_auth_transactions",
        )
        .first<{ secrets_ciphertext: string | null; status: string }>();
      assert.equal(raw?.secrets_ciphertext, null);
      assert.equal(raw?.status, "completed");
    } finally {
      await mf.dispose();
    }
  },
);
