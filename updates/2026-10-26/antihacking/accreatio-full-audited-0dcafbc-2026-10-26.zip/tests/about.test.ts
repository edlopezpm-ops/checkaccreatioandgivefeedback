import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const read = (path: string) =>
  readFileSync(new URL(path, import.meta.url), "utf8");
const app = read("../src/App.tsx");
const about = read("../src/components/AboutExperience.tsx");
const publicContent = read("../src/components/PublicContent.tsx");
const responsive = read("../src/responsive.css");
const license = read("../LICENSE");
const viteConfig = read("../vite.config.mts");

test("About preserves every administrative fact from the previous surface", () => {
  for (const fact of [
    "aboutVersion",
    "license",
    "privacy",
    "aboutSecurityCopy",
    "aboutWebDocumentsCopy",
    "aboutDesktopDocumentsCopy",
    "aboutCopyrightRole",
    "aboutCopyright",
    "aboutClosingPrinciples",
    "__APP_VERSION__",
    "© 2026 Ed Lopez",
  ])
    assert.match(`${app}\n${about}`, new RegExp(fact.replace("©", "\\©")));
});

test("version and private-use license remain derived from their controlling sources", () => {
  assert.match(
    viteConfig,
    /__APP_VERSION__:\s*JSON\.stringify\(pkg\.version\)/,
  );
  assert.match(
    license,
    /Copyright \(c\) 2026 Ed Lopez\. All rights reserved\./,
  );
  assert.match(license, /prior written permission from Ed Lopez/);
  assert.match(
    app,
    /All rights reserved\. Free for authorized private use; redistribution and resale require written permission\./,
  );
  assert.match(
    app,
    /Todos los derechos reservados\. Uso privado autorizado gratuito; la redistribución y reventa requieren permiso escrito\./,
  );
  assert.doesNotMatch(about, /open[ -]source|trademark/i);
});

test("web legal documents remain accessible with applicable versioned status", () => {
  for (const document of ["privacy", "faq", "cookies"])
    assert.ok(about.includes(`href={legalHref("${document}", locale)}`));
  assert.match(about, /href=\{termsHref\(locale\)\}/);
  assert.match(about, /applicable web beta documents/);
  assert.match(about, /Formal legal review remains pending/);
  assert.doesNotMatch(about, /beta draft|beta\)"|\(borrador\)/);
  assert.doesNotMatch(about, /GDPR|CCPA|HIPAA|SOC 2|ISO 27001/);
});

test("editorial About explains the product model, limits, FAQ, and next action", () => {
  assert.match(about, /Describe/);
  assert.match(about, /Organize/);
  assert.match(about, /Take your project/);
  assert.match(about, /Human-controlled orchestration/);
  assert.match(about, /not a security or compliance certification/);
  assert.match(about, /<section className="about-faq"/);
  assert.match(about, /onClick={onStart}/);
  assert.match(about, /className="about-brand-link"[\s\S]*?onClick=\{onHome\}/);
  assert.match(about, /read About and the Blog on the web without signing in/);
  assert.match(about, /choose an enabled sign-in method/);
  assert.match(about, /accreatio is web-only/);
  assert.match(
    about,
    /obsolete, was never released, and will never be released/,
  );
});

test("shared content is semantic and About collapses to one column on mobile", () => {
  assert.match(publicContent, /<section/);
  assert.match(publicContent, /aria-labelledby/);
  assert.match(
    responsive,
    /\.about-steps\s*{[\s\S]*?grid-template-columns:\s*1fr/,
  );
  assert.match(
    responsive,
    /\.about-product-close\s*{[\s\S]*?flex-direction:\s*column/,
  );
});
