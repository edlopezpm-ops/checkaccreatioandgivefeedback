import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import test from "node:test";
import {
  HELP_TIPS,
  helpTipsForTopic,
  type HelpTopic,
} from "../src/components/help/helpContent";

const topics: HelpTopic[] = [
  "name",
  "phase",
  "attachments",
  "context",
  "restrictions",
  "route",
  "team",
  "delivery",
  "review",
  "outcome",
  "settings",
  "blog",
  "account",
];

test("contextual tips cover every module and full guide preserves the complete workflow", () => {
  for (const topic of topics) {
    const tips = helpTipsForTopic(topic);
    assert.ok(tips.length > 0, `Missing help for ${topic}`);
    assert.ok(tips.every((tip) => tip.topics.includes(topic)));
  }
  assert.equal(helpTipsForTopic("name", true), HELP_TIPS);
  assert.equal(helpTipsForTopic(), HELP_TIPS);
  assert.equal(helpTipsForTopic("account")[0].id, "account");
  assert.deepEqual(
    HELP_TIPS.slice(0, 8).map((tip) => tip.id),
    [
      "access",
      "authorization",
      "name",
      "phase",
      "attachments",
      "context",
      "restrictions",
      "review",
    ],
  );
  assert.ok(HELP_TIPS.find((tip) => tip.id === "export"));
  assert.ok(HELP_TIPS.find((tip) => tip.id === "handoff"));
});

function jpegDimensions(bytes: Buffer) {
  assert.equal(bytes.readUInt16BE(0), 0xffd8);
  let offset = 2;
  while (offset < bytes.length) {
    assert.equal(bytes[offset], 0xff);
    const marker = bytes[offset + 1];
    const size = bytes.readUInt16BE(offset + 2);
    if ([0xc0, 0xc1, 0xc2].includes(marker)) {
      return {
        width: bytes.readUInt16BE(offset + 7),
        height: bytes.readUInt16BE(offset + 5),
      };
    }
    offset += size + 2;
  }
  throw new Error("JPEG has no dimensions");
}

test("all EN/ES SOP images are actual 4K assets bound to their provenance manifest", async () => {
  const root = new URL("../public/help/", import.meta.url);
  const manifest = JSON.parse(
    await readFile(new URL("manifest.json", root), "utf8"),
  );
  assert.equal(manifest.width, 3840);
  assert.equal(manifest.height, 2160);
  assert.equal(manifest.slides.length, HELP_TIPS.length * 2);
  for (const locale of ["en", "es"] as const) {
    for (const tip of HELP_TIPS) {
      assert.ok(
        tip.title[locale] && tip.instruction[locale] && tip.detail[locale],
      );
      const relative = `${locale}/${tip.id}.jpg`;
      const entry = manifest.slides.find(
        (slide: { path: string }) => slide.path === relative,
      );
      assert.ok(entry, `Missing manifest entry ${relative}`);
      const bytes = await readFile(new URL(relative, root));
      assert.deepEqual(jpegDimensions(bytes), { width: 3840, height: 2160 });
      assert.equal(
        createHash("sha256").update(bytes).digest("hex"),
        entry.sha256,
      );
    }
  }
});
