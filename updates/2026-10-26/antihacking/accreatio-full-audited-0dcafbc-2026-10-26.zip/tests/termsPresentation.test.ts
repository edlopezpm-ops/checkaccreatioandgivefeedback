import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import vm from "node:vm";
import { termsHref } from "../src/legal";
import { ACCOUNT_POLICY } from "../shared/accountPolicy";

const read = (path: string) =>
  readFileSync(new URL(path, import.meta.url), "utf8");
const english = read("../public/legal/terms.html");
const spanish = read("../public/legal/terms-es.html");
const script = read("../public/legal/terms-language.js");
const navigationScript = read("../public/legal/legal-navigation.js");
const normalize = (text: string) => text.replace(/\s+/gu, " ").trim();
const textOnly = (text: string) => normalize(text.replace(/<[^>]+>/gu, ""));

test("each Terms document contains one full language and the matching canonical source", () => {
  assert.deepEqual(ACCOUNT_POLICY, {
    privacyNoticeVersion: "2026-10-25-captcha-privacy",
    termsVersion: "2026-10-25-captcha",
    purposeVersion: "account-core-v1",
  });
  const structure: number[][] = [];
  for (const [locale, html, markdown] of [
    ["en", english, read("../docs/TERMS_OF_SERVICE.md")],
    ["es", spanish, read("../docs/TERMS_OF_SERVICE_ES.md")],
  ]) {
    assert.match(html, new RegExp(`<html lang="${locale}"`));
    assert.equal((html.match(/<h1>/gu) ?? []).length, 1);
    const clauses = [
      ...html.matchAll(/<h2>(\d+)\.[\s\S]*?(?=<h2>|<\/main>)/gu),
    ];
    assert.deepEqual(
      clauses.map((clause) => Number(clause[1])),
      Array.from({ length: 14 }, (_, index) => index + 1),
    );
    structure.push(
      clauses.map((clause) => (clause[0].match(/<p>/gu) ?? []).length),
    );
    const publicText = textOnly(
      html.slice(html.indexOf("<h1>"), html.indexOf("</main>")),
    );
    const canonicalText = normalize(
      markdown
        .replace(/^#+ /gmu, "")
        .replace(/\[([^\]]+)\]\([^)]+\)/gu, "$1")
        .replaceAll("`", ""),
    );
    assert.equal(publicText, canonicalText);
    assert.match(html, /<p class="terms-version">Version 20261025<\/p>/u);
    assert.equal((html.match(/Version 20261025/gu) ?? []).length, 1);
    assert.ok(!html.includes(ACCOUNT_POLICY.termsVersion));
    assert.doesNotMatch(
      html,
      /Updated:|Terms version:|SHA[-\s]?256|checksum|\bhash(?:es|ing)?\b|\bHMAC\b|draft-context:v1/iu,
    );
    assert.doesNotMatch(
      html,
      /<button|href="#espanol"|summary in Spanish|resumen (?:en )?español/iu,
    );
    assert.match(html, /mailto:aekr@aekr\.io/u);
    assert.match(html, /account-core-v1/u);
  }
  assert.deepEqual(
    structure[1],
    structure[0],
    "ES preserves every EN clause and paragraph, including attachments and agents",
  );
  assert.doesNotMatch(
    english,
    /Términos en español|Trabajo legítimo|Contenido y proyectos prohibidos/u,
  );
  assert.doesNotMatch(
    spanish,
    /Scope and access|Prohibited content and projects|Terms of Service/u,
  );
});

test("all application Terms entrypoints use the active primary locale", () => {
  assert.equal(termsHref("en"), "/legal/terms.html?lang=en");
  assert.equal(termsHref("es"), "/legal/terms-es.html?lang=es");
  for (const source of [
    "../src/components/AboutExperience.tsx",
    "../src/components/WebProjectInformation.tsx",
    "../src/components/account/WebAccountMenu.tsx",
    "../src/components/account/AccountPolicyFields.tsx",
  ]) {
    assert.match(read(source), /href=\{termsHref\(locale\)\}/u);
    assert.doesNotMatch(read(source), /href="\/legal\/terms/u);
  }
});

function resolveLegal(href: string, locale = "en", referrer = "") {
  const element = { lang: locale, hidden: false };
  const links = [
    { href: "https://accreatio.com/?view=welcome&lang=en" },
    { href: "https://accreatio.com/legal/privacy.html" },
    { href: "https://accreatio.com/legal/cookies.html" },
    { href: "mailto:aekr@aekr.io" },
    { href: "https://policies.google.com/privacy" },
  ];
  let replaced: string | undefined;
  let ready: (() => void) | undefined;
  vm.runInNewContext(`${script}\n${navigationScript}`, {
    URL,
    window: {
      location: {
        href,
        replace: (target: string) => {
          replaced = target;
        },
      },
    },
    document: {
      referrer,
      documentElement: element,
      addEventListener: (event: string, handler: () => void) => {
        assert.equal(event, "DOMContentLoaded");
        ready = handler;
      },
      querySelectorAll: () => links,
    },
  });
  ready?.();
  return { element, links, replaced };
}

test("direct and refreshed explicit language requests resolve without additional selectors, storage or referrer", () => {
  for (const route of ["terms", "terms.html"]) {
    const englishDefault = resolveLegal(`https://accreatio.com/legal/${route}`);
    assert.equal(englishDefault.replaced, undefined);
    assert.equal(englishDefault.element.hidden, false);
    const spanishRequest = resolveLegal(
      `https://accreatio.com/legal/${route}?lang=es`,
    );
    assert.equal(spanishRequest.replaced, "/legal/terms-es.html?lang=es");
    assert.equal(
      spanishRequest.element.hidden,
      true,
      "the inactive document cannot flash before navigation",
    );
    assert.equal(
      resolveLegal(`https://accreatio.com/legal/${route}?lang=invalid`)
        .replaced,
      undefined,
    );
  }
  assert.equal(
    resolveLegal("https://accreatio.com/legal/terms-es.html?lang=es", "es")
      .replaced,
    undefined,
  );
  assert.equal(
    resolveLegal("https://accreatio.com/legal/terms-es.html", "es").replaced,
    undefined,
  );
  assert.equal(
    resolveLegal("https://accreatio.com/legal/terms-es.html?lang=en", "es")
      .replaced,
    "/legal/terms.html?lang=en",
  );
  assert.equal(
    resolveLegal(
      "https://accreatio.com/legal/terms",
      "en",
      "https://accreatio.com/legal/privacy.html?lang=es",
    ).replaced,
    undefined,
  );
  assert.equal(
    resolveLegal(
      "https://accreatio.com/legal/terms",
      "en",
      "https://other.example/?lang=es",
    ).replaced,
    undefined,
  );
  assert.equal(
    resolveLegal(
      "https://accreatio.com/legal/terms?lang=en",
      "en",
      "https://accreatio.com/?lang=es",
    ).replaced,
    undefined,
    "explicit URL determines the document without using referrer",
  );
});

test("Terms navigation and return keep the chosen language and leave outside destinations intact", () => {
  const { links } = resolveLegal(
    "https://accreatio.com/legal/terms-es.html?lang=es",
    "es",
  );
  assert.equal(links[0].href, "/?view=welcome&lang=es");
  assert.equal(links[1].href, "/legal/privacy.html?lang=es");
  assert.equal(links[2].href, "/legal/cookies.html?lang=es");
  assert.equal(links[3].href, "mailto:aekr@aekr.io");
  assert.equal(links[4].href, "https://policies.google.com/privacy");
  assert.match(english, /script src="terms-language\.js"/u);
  assert.match(spanish, /script src="terms-language\.js"/u);
  assert.match(read("../vite.config.mts"), /legal\/\*\*\/\*\.html/u);
});
