import assert from "node:assert/strict";
import test from "node:test";
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import {
  harness,
  POLICY_AUTHORIZATION,
  POLICY_CONTINUATION,
} from "./helpers/accountHarness";
import { ACCOUNT_POLICY } from "../shared/accountPolicy";

const receipt = (h: Awaited<ReturnType<typeof harness>>) =>
  h.db.sqlite.prepare("SELECT * FROM account_policy_authorizations").get();

test("additive migration preserves existing accounts/sessions without backfilling acceptance", () => {
  const db = new DatabaseSync(":memory:");
  db.exec("PRAGMA foreign_keys=ON");
  for (const filename of [
    "0001_accounts.sql",
    "0002_own_email_otp.sql",
    "0003_google_oidc_privacy.sql",
    "0004_google_display_name.sql",
  ])
    db.exec(
      readFileSync(
        new URL(`../migrations-auth/${filename}`, import.meta.url),
        "utf8",
      ),
    );
  db.exec(
    "INSERT INTO accounts(id,identity_key,email,created_at,last_seen_at) VALUES('existing','legacy','person@example.test',1,1); INSERT INTO account_sessions(token_hash,account_id,expires_at) VALUES('old-session','existing',9999999999999)",
  );
  const before = db.prepare("SELECT * FROM accounts").get();
  db.exec(
    readFileSync(
      new URL(
        "../migrations-auth/0005_account_policy_authorization.sql",
        import.meta.url,
      ),
      "utf8",
    ),
  );
  assert.deepEqual(db.prepare("SELECT * FROM accounts").get(), before);
  assert.equal(
    db.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()?.n,
    1,
  );
  assert.equal(
    db.prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations").get()
      ?.n,
    0,
  );
  db.close();
});

test("existing accounts receive no fictitious authorization; fresh rights and logout stay available", async () => {
  const h = await harness();
  const cookie = await h.login(undefined, { policyAuthorization: false });
  assert.equal(receipt(h), undefined);
  const session = await h.call("session", { method: "GET", cookie });
  assert.equal((await session.json()).policyAuthorizationRequired, true);
  const blocked = await h.call("authorize", {
    cookie,
    body: { operationId: crypto.randomUUID() },
  });
  assert.equal(blocked.status, 403);
  assert.equal(
    (await blocked.json()).error.code,
    "policy_authorization_required",
  );
  await h.controlProof(cookie, "data");
  const data = await h.call("data", { method: "GET", cookie });
  assert.equal(data.status, 200);
  assert.equal((await data.json()).policyAuthorization, null);
  assert.equal((await h.call("logout", { cookie })).status, 200);
  assert.equal(receipt(h), undefined);
});

test("policy endpoint validates affirmative current choices and same-origin without side effects", async () => {
  const h = await harness();
  const cookie = await h.login(undefined, { policyAuthorization: false });
  for (const body of [undefined, {}, { ...POLICY_CONTINUATION, extra: true }]) {
    assert.equal((await h.call("policy", { cookie, body })).status, 400);
  }
  for (const key of [
    "accountDataAuthorized",
    "termsAccepted",
    "cookiesNoticeAcknowledged",
  ]) {
    assert.equal(
      (
        await h.call("policy", {
          cookie,
          body: { ...POLICY_CONTINUATION, [key]: false },
        })
      ).status,
      403,
    );
  }
  for (const key of [
    "privacyNoticeVersion",
    "termsVersion",
    "purposeVersion",
    "cookiesNoticeVersion",
  ]) {
    assert.equal(
      (
        await h.call("policy", {
          cookie,
          body: { ...POLICY_CONTINUATION, [key]: "previous" },
        })
      ).status,
      409,
    );
  }
  assert.equal(
    (
      await h.call("policy", {
        cookie,
        origin: "https://other.test",
        body: POLICY_CONTINUATION,
      })
    ).status,
    403,
  );
  assert.equal(
    (
      await h.call("policy", {
        cookie,
        headers: { "Sec-Fetch-Site": "cross-site" },
        body: POLICY_CONTINUATION,
      })
    ).status,
    403,
  );
  assert.equal(
    (
      await h.call("policy", {
        cookie,
        body: { ...POLICY_CONTINUATION, excess: "x".repeat(1024) },
      })
    ).status,
    413,
  );
  assert.equal(
    (await h.call("policy", { body: POLICY_CONTINUATION })).status,
    401,
  );
  assert.equal((await h.call("policy", { method: "GET", cookie })).status, 405);
  assert.equal(receipt(h), undefined);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM export_authorizations").get()
      ?.n,
    0,
  );
});

test("affirmative receipt uses database time, is idempotent and is included in own-data export", async () => {
  const h = await harness();
  const cookie = await h.login(undefined, { policyAuthorization: false });
  const acceptedAt = h.db.now;
  Object.assign(h.dependencies, { now: () => Date.parse("2099-01-01") });
  const saved = await h.call("policy", { cookie, body: POLICY_CONTINUATION });
  assert.equal(saved.status, 200);
  assert.equal((await saved.json()).policyAuthorizationRequired, false);
  assert.equal(receipt(h)?.authorized_at, acceptedAt);
  h.db.now += 30_000;
  const replies = await Promise.all(
    Array.from({ length: 5 }, () =>
      h.call("policy", { cookie, body: POLICY_CONTINUATION }),
    ),
  );
  assert.ok(replies.every((reply) => reply.status === 200));
  assert.equal(receipt(h)?.authorized_at, acceptedAt);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
      .get()?.n,
    1,
  );
  await h.controlProof(cookie, "data");
  const exported = await h.call("data", { method: "GET", cookie });
  assert.deepEqual((await exported.json()).policyAuthorization, {
    ...POLICY_AUTHORIZATION,
    authorizedAt: new Date(acceptedAt).toISOString(),
  });
  assert.equal(
    (
      await h.call("authorize", {
        cookie,
        body: { operationId: crypto.randomUUID() },
      })
    ).status,
    200,
  );
});

test("stale policy blocks old export receipts until a fresh explicit authorization", async () => {
  const h = await harness();
  const cookie = await h.login();
  const operationId = crypto.randomUUID();
  assert.equal(
    (await h.call("authorize", { cookie, body: { operationId } })).status,
    200,
  );
  const oldAuthorizedAt = receipt(h)?.authorized_at;
  h.db.sqlite.exec(
    "UPDATE account_policy_authorizations SET terms_version='2026-10-20-beta', privacy_notice_version='2026-10-20-privacy'",
  );
  assert.equal(
    (await h.call("session", { method: "GET", cookie }).then((r) => r.json()))
      .policyAuthorizationRequired,
    true,
  );
  assert.equal(receipt(h)?.authorized_at, oldAuthorizedAt);
  assert.equal(receipt(h)?.terms_version, "2026-10-20-beta");
  assert.equal(
    (
      await h.call("policy", {
        cookie,
        body: {
          ...POLICY_CONTINUATION,
          privacyNoticeVersion: "2026-10-20-privacy",
          termsVersion: "2026-10-20-beta",
        },
      })
    ).status,
    409,
  );
  assert.equal(receipt(h)?.authorized_at, oldAuthorizedAt);
  assert.equal(
    (await h.call("authorize", { cookie, body: { operationId } })).status,
    403,
  );
  h.db.now += 10_000;
  assert.equal(
    (await h.call("policy", { cookie, body: POLICY_CONTINUATION })).status,
    200,
  );
  assert.equal(receipt(h)?.authorized_at, h.db.now);
  assert.equal(
    (await h.call("authorize", { cookie, body: { operationId } })).status,
    200,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM export_authorizations").get()
      ?.n,
    1,
  );
});

test("Terms-only update preserves the prior receipt and data rights until deliberate renewal", async () => {
  const h = await harness();
  const cookie = await h.login();
  const priorTermsVersion = "2026-10-22b-beta";
  h.db.sqlite
    .prepare("UPDATE account_policy_authorizations SET terms_version=?")
    .run(priorTermsVersion);
  const priorReceipt = receipt(h);
  h.db.now += 30_000;

  const session = await h.call("session", { method: "GET", cookie });
  assert.equal((await session.json()).policyAuthorizationRequired, true);
  assert.deepEqual(receipt(h), priorReceipt);
  assert.equal(
    (
      await h.call("authorize", {
        cookie,
        body: { operationId: crypto.randomUUID() },
      })
    ).status,
    403,
  );

  await h.controlProof(cookie, "data");
  const data = await h.call("data", { method: "GET", cookie });
  assert.equal(data.status, 200);
  const exported = (await data.json()).policyAuthorization;
  assert.equal(exported.termsVersion, priorTermsVersion);
  assert.equal(
    exported.privacyNoticeVersion,
    ACCOUNT_POLICY.privacyNoticeVersion,
  );
  assert.equal(exported.purposeVersion, ACCOUNT_POLICY.purposeVersion);
  assert.deepEqual(receipt(h), priorReceipt);

  assert.equal(
    (await h.call("policy", { cookie, body: POLICY_CONTINUATION })).status,
    200,
  );
  assert.equal(receipt(h)?.terms_version, ACCOUNT_POLICY.termsVersion);
  assert.equal(
    receipt(h)?.privacy_notice_version,
    priorReceipt?.privacy_notice_version,
  );
  assert.equal(receipt(h)?.purpose_version, priorReceipt?.purpose_version);
  assert.equal(receipt(h)?.authorized_at, h.db.now);
});

test("served policy documents disclose the expected public labels and retain approved boundaries", () => {
  for (const [markdownPaths, htmlPaths, version] of [
    [
      ["../docs/PRIVACY_POLICY.md"],
      ["../public/legal/privacy.html"],
      ACCOUNT_POLICY.privacyNoticeVersion,
    ],
    [
      ["../docs/TERMS_OF_SERVICE.md", "../docs/TERMS_OF_SERVICE_ES.md"],
      ["../public/legal/terms.html", "../public/legal/terms-es.html"],
      "Version 20261025",
    ],
  ]) {
    const markdown = markdownPaths
      .map((path) => readFileSync(new URL(path, import.meta.url), "utf8"))
      .join("\n");
    const html = htmlPaths
      .map((path) => readFileSync(new URL(path, import.meta.url), "utf8"))
      .join("\n");
    for (const rawSource of [markdown, html]) {
      const source = rawSource.replace(/\s+/gu, " ");
      assert.ok(
        source.includes(version),
        `${markdownPaths} and ${htmlPaths} must disclose the expected public label`,
      );
      assert.ok(source.includes(ACCOUNT_POLICY.purposeVersion));
      assert.match(source, /Google and GitHub/);
      assert.match(source, /Google y GitHub/);
      assert.match(source, /immediate local journal and IndexedDB/);
      assert.match(source, /journal local de escritura inmediata y IndexedDB/);
      assert.match(source, /without file names or bytes/);
      assert.match(source, /no sus nombres ni bytes/);
      assert.match(source, /bound to that action and valid for five minutes/);
      assert.match(
        source,
        /ligada a esa acción y válida durante cinco minutos/,
      );
      assert.match(
        source,
        /does not establish that a password or MFA was entered again/,
      );
      assert.match(source, /48 hours/);
      assert.match(source, /cookie preferences remain independent/);
      assert.doesNotMatch(
        source,
        /2026-10-20-(?:privacy|beta)|unverified entity|jurisdiction is selected|se inventan arbitraje|Saving has a short delay/,
      );
    }
  }
  const privacy = readFileSync(
    new URL("../public/legal/privacy.html", import.meta.url),
    "utf8",
  );
  assert.match(privacy, /accreatio:account-draft:v1/);
  assert.match(privacy, /SameSite=Strict/);
  assert.match(privacy, /SameSite=Lax/);
  assert.match(privacy, /180 days/);
  assert.match(privacy, /do not backfill/);
  assert.match(privacy, /https:\/\/github.com\/settings\/apps\/authorizations/);
  const cookies = readFileSync(
    new URL("../public/legal/cookies.html", import.meta.url),
    "utf8",
  ).replace(/\s+/gu, " ");
  assert.ok(cookies.includes(ACCOUNT_POLICY.privacyNoticeVersion));
  assert.equal((cookies.match(/accreatio:account-draft:v1/gu) ?? []).length, 2);
  assert.match(cookies, /Google\/GitHub return/);
  assert.match(cookies, /Retorno Google\/GitHub/);
  assert.match(cookies, /without selected file names or bytes/);
  assert.match(cookies, /sin nombres ni bytes de archivos seleccionados/);
  assert.match(cookies, /180-day validity/);
  assert.match(cookies, /No identifier or server transmission/iu);
  assert.doesNotMatch(
    cookies,
    /2026-10-20-privacy|Verify Google for account controls/,
  );
});

test("authorization batch rechecks session revocation and export batch rechecks policy races", async () => {
  const h = await harness();
  const cookie = await h.login(undefined, { policyAuthorization: false });
  const original = h.db.batch.bind(h.db);
  h.db.batch = async (statements) => {
    h.db.sqlite.exec("DELETE FROM account_sessions");
    return original(statements);
  };
  assert.equal(
    (await h.call("policy", { cookie, body: POLICY_CONTINUATION })).status,
    401,
  );
  assert.equal(receipt(h), undefined);
  h.db.batch = original;
  const fresh = await h.login();
  h.db.batch = async (statements) => {
    h.db.sqlite.exec("DELETE FROM account_policy_authorizations");
    return original(statements);
  };
  assert.equal(
    (
      await h.call("authorize", {
        cookie: fresh,
        body: { operationId: crypto.randomUUID() },
      })
    ).status,
    403,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM export_authorizations").get()
      ?.n,
    0,
  );
});

test("policy batch rolls back on failure; deletion and compatible older writers purge authorization immediately", async () => {
  const h = await harness();
  const cookie = await h.login(undefined, { policyAuthorization: false });
  h.db.sqlite.exec(
    "CREATE TRIGGER policy_failure BEFORE INSERT ON account_policy_authorizations BEGIN SELECT RAISE(ABORT,'synthetic failure'); END;",
  );
  assert.equal(
    (await h.call("policy", { cookie, body: POLICY_CONTINUATION })).status,
    503,
  );
  assert.equal(receipt(h), undefined);
  assert.equal(
    (await h.call("session", { method: "GET", cookie })).status,
    200,
  );
  h.db.sqlite.exec("DROP TRIGGER policy_failure");
  assert.equal(
    (await h.call("policy", { cookie, body: POLICY_CONTINUATION })).status,
    200,
  );
  await h.controlProof(cookie, "delete");
  assert.equal((await h.call("delete", { cookie })).status, 200);
  assert.equal(receipt(h), undefined);
  const tombstones = JSON.stringify(
    h.db.sqlite.prepare("SELECT * FROM account_auth_tombstones").all(),
  );
  assert.ok(!tombstones.includes(POLICY_AUTHORIZATION.termsVersion));
  await h.login();
  assert.ok(receipt(h));
  h.db.sqlite.exec("UPDATE accounts SET deleted_at=unixepoch()*1000");
  assert.equal(receipt(h), undefined);
});

test("OTP requires current affirmative authorization before issuing a code", async () => {
  const h = await harness();
  for (const policyAuthorization of [
    undefined,
    { ...POLICY_AUTHORIZATION, termsAccepted: false },
    { ...POLICY_AUTHORIZATION, purposeVersion: "old" },
  ]) {
    const response = await h.call("otp/request", {
      body: { email: "person@example.test", policyAuthorization },
    });
    assert.ok([400, 403, 409].includes(response.status));
  }
  assert.equal(h.mailbox.length, 0);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_otp_challenges")
      .get()?.n,
    0,
  );
});
