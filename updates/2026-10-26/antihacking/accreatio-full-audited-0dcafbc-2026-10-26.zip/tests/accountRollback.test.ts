import assert from "node:assert/strict";
import test from "node:test";
import {
  harness,
  POLICY_AUTHORIZATION,
  POLICY_CONTINUATION,
} from "./helpers/accountHarness";
import { oidcStore } from "../functions/_lib/auth/oidc-store";
import { handleOidc } from "../functions/_lib/auth/oidc";
import { backfillEmails, toHex } from "../functions/_lib/auth/privacy";

// Production SQL and Web Crypto, with fixture-validated claims at the store
// boundary. These tests do not establish a successful login with Google.
async function setup() {
  const h = await harness();
  Object.assign(h.env, {
    ACCOUNT_OIDC_ENABLED: "true",
    ACCOUNT_EMAIL_ENCRYPTION_KEY: "1".repeat(64),
    ACCOUNT_EMAIL_LOOKUP_KEY: "2".repeat(64),
    ACCOUNT_AUTH_LOCATOR_KEY: "3".repeat(64),
    ACCOUNT_OIDC_TRANSACTION_KEY: "4".repeat(64),
    GOOGLE_CLIENT_ID: "rollback.apps.googleusercontent.com",
    GOOGLE_CLIENT_SECRET: "fixture-only-secret",
    GOOGLE_REDIRECT_URI:
      "https://accreatio.pages.dev/api/auth/v1/oidc/google/callback",
  });
  const store = oidcStore(h.env, h.dependencies);
  async function transaction(previousSessionTokenHash: string | null = null) {
    const tx = {
      id: crypto.randomUUID(),
      stateHash: crypto.randomUUID(),
      browserHash: crypto.randomUUID(),
      claimNonce: crypto.randomUUID(),
    };
    await store.createTransaction({
      ...tx,
      ipHash: crypto.randomUUID(),
      secretsCiphertext: "fixture-envelope",
      returnMode: "popup",
      previousSessionTokenHash,
      policyAuthorization: POLICY_AUTHORIZATION,
    });
    assert.ok(await store.claimTransaction(tx));
    return tx;
  }
  async function googleLogin(subject = "rollback-subject") {
    const tx = await transaction();
    const token = toHex(crypto.getRandomValues(new Uint8Array(32)));
    const hash = toHex(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token)),
    );
    await store.completeGoogleLogin({
      transactionId: tx.id,
      claimNonce: tx.claimNonce,
      identity: {
        issuer: "https://accounts.google.com",
        subject,
        email: "rollback@gmail.com",
        emailVerified: true,
        authoritativeEmail: true,
        hostedDomain: null,
      },
      sessionTokenHash: hash,
    });
    assert.equal(
      (
        await h.call("policy", {
          cookie: `__Host-accreatio_session=${token}`,
          body: POLICY_CONTINUATION,
        })
      ).status,
      200,
    );
    return { hash, cookie: `__Host-accreatio_session=${token}` };
  }
  async function oidc(action: "methods" | "start") {
    const request = new Request(
      `https://accreatio.pages.dev/api/auth/v1/${action}`,
      {
        method: action === "methods" ? "GET" : "POST",
        headers: {
          Origin: "https://accreatio.pages.dev",
          "Content-Type": "application/json",
        },
        ...(action === "start"
          ? {
              body: JSON.stringify({
                purpose: "sign_in",
                returnRoute: "builder",
                mode: "redirect",
              }),
            }
          : {}),
      },
    );
    return handleOidc({ request, env: h.env }, action, h.dependencies);
  }
  return { ...h, store, transaction, googleLogin, oidc };
}

test("compatible rollback disables Google admission and preserves encrypted accounts, existing sessions and concurrent rolling quota", async () => {
  const h = await setup();
  const legacyCookie = await h.login();
  const first = await h.googleLogin();
  const second = await h.googleLogin();
  const before = h.db.sqlite
    .prepare("SELECT * FROM accounts ORDER BY id")
    .all();
  const identities = h.db.sqlite
    .prepare("SELECT * FROM account_external_identities")
    .all();
  const identityKey = h.env.ACCOUNT_IDENTITY_KEY;
  h.env.ACCOUNT_OIDC_ENABLED = "false";
  assert.equal(
    (await (await h.oidc("methods")).json()).methods.google.available,
    false,
  );
  assert.equal((await h.oidc("start")).status, 503);
  assert.equal(h.env.ACCOUNT_IDENTITY_KEY, identityKey);
  for (const cookie of [legacyCookie, first.cookie, second.cookie]) {
    assert.equal(
      (await h.call("session", { method: "GET", cookie })).status,
      200,
    );
    await h.controlProof(cookie, "data");
    assert.equal((await h.call("data", { method: "GET", cookie })).status, 200);
  }
  const operations = Array.from({ length: 12 }, () => crypto.randomUUID());
  const responses = await Promise.all(
    operations.map((operationId, i) =>
      h.call("authorize", {
        cookie: i % 2 ? first.cookie : second.cookie,
        body: { operationId },
      }),
    ),
  );
  assert.equal(responses.filter((r) => r.status === 200).length, 5);
  assert.equal(responses.filter((r) => r.status === 429).length, 7);
  const accepted = operations[responses.findIndex((r) => r.status === 200)];
  assert.equal(
    (
      await h.call("authorize", {
        cookie: second.cookie,
        body: { operationId: accepted },
      })
    ).status,
    200,
  );
  const receipts = h.db.sqlite
    .prepare("SELECT * FROM export_authorizations ORDER BY operation_id")
    .all();
  assert.equal(receipts.length, 5);
  assert.deepEqual(
    h.db.sqlite.prepare("SELECT * FROM accounts ORDER BY id").all(),
    before,
  );
  assert.deepEqual(
    h.db.sqlite.prepare("SELECT * FROM account_external_identities").all(),
    identities,
  );
  h.env.ACCOUNT_OIDC_ENABLED = "true";
  const resumed = await h.googleLogin();
  assert.equal(
    (
      await (
        await h.call("session", { method: "GET", cookie: resumed.cookie })
      ).json()
    ).remaining,
    0,
  );
  assert.deepEqual(
    h.db.sqlite
      .prepare("SELECT * FROM export_authorizations ORDER BY operation_id")
      .all(),
    receipts,
  );
  assert.deepEqual(
    h.db.sqlite.prepare("SELECT * FROM accounts ORDER BY id").all(),
    before,
  );
});

test("rollback retains contact collision barriers and cannot downgrade a Google-only account to email OTP", async () => {
  const h = await setup();
  const first = await h.googleLogin();
  h.env.ACCOUNT_OIDC_ENABLED = "false";
  const requested = await h.call("otp/request", {
    body: {
      policyAuthorization: POLICY_AUTHORIZATION,
      email: "rollback@gmail.com",
    },
  });
  assert.equal(requested.status, 200);
  const { challengeId } = await requested.json();
  const verified = await h.call("otp/verify", {
    body: { challengeId, code: h.mailbox.at(-1)!.code },
  });
  assert.notEqual(verified.status, 200);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    1,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
    1,
  );
  assert.equal(
    (await h.call("session", { method: "GET", cookie: first.cookie })).status,
    200,
  );
});

test("missing privacy key fails closed instead of bypassing an existing Google email reservation", async () => {
  const h = await setup();
  await h.googleLogin();
  h.env.ACCOUNT_OIDC_ENABLED = "false";
  delete h.env.ACCOUNT_EMAIL_LOOKUP_KEY;
  const requested = await h.call("otp/request", {
    body: {
      policyAuthorization: POLICY_AUTHORIZATION,
      email: "rollback@gmail.com",
    },
  });
  if (requested.status === 200) {
    const { challengeId } = await requested.json();
    const verified = await h.call("otp/verify", {
      body: { challengeId, code: h.mailbox.at(-1)!.code },
    });
    assert.notEqual(
      verified.status,
      200,
      "Missing encryption/lookup configuration must not create a second principal for a federated contact",
    );
  }
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    1,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM accounts WHERE email IS NOT NULL")
      .get()!.n,
    0,
  );
});

test("logout cancels a previously claimed OAuth transaction and prevents creating a replacement session", async () => {
  const h = await setup();
  const first = await h.googleLogin();
  const tx = await h.transaction(first.hash);
  assert.equal((await h.call("logout", { cookie: first.cookie })).status, 200);
  await assert.rejects(
    h.store.completeGoogleLogin({
      transactionId: tx.id,
      claimNonce: tx.claimNonce,
      identity: {
        issuer: "https://accounts.google.com",
        subject: "rollback-subject",
        email: null,
        emailVerified: false,
        authoritativeEmail: false,
        hostedDomain: null,
      },
      sessionTokenHash: "9".repeat(64),
    }),
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
    0,
  );
  assert.equal(
    h.db.sqlite
      .prepare(
        "SELECT secrets_ciphertext FROM account_auth_transactions WHERE id=?",
      )
      .get(tx.id)!.secrets_ciphertext,
    null,
  );
});

test("backfill CAS cannot restore a concurrently deleted contact or change its identity key", async () => {
  const h = await setup();
  // Represent a pre-backfill legacy row without changing schema or the key.
  await h.login();
  const initial = h.db.sqlite
    .prepare("SELECT id,identity_key FROM accounts")
    .get()!;
  h.db.sqlite
    .prepare(
      "UPDATE accounts SET email='person@example.test',email_ciphertext=NULL,email_lookup_key=NULL",
    )
    .run();
  const prepare = h.db.prepare.bind(h.db);
  h.db.prepare = (sql) => {
    const statement = prepare(sql);
    if (sql.startsWith("UPDATE accounts SET email_ciphertext =")) {
      const run = statement.run.bind(statement);
      statement.run = async () => {
        h.db.sqlite
          .prepare(
            "UPDATE accounts SET email=NULL,deleted_at=?,security_version=security_version+1 WHERE id=?",
          )
          .run(h.db.now, initial.id);
        return run();
      };
    }
    return statement;
  };
  await backfillEmails(h.env, h.dependencies);
  const result = h.db.sqlite.prepare("SELECT * FROM accounts").get()!;
  assert.equal(result.email, null);
  assert.equal(result.email_ciphertext, null);
  assert.equal(result.email_lookup_key, null);
  assert.equal(result.identity_key, initial.identity_key);
  assert.equal(result.deleted_at, h.db.now);
});

test("revocation between session read and write prevents data export, deletion and quota issuance", async () => {
  for (const action of ["data", "delete", "authorize"] as const) {
    const h = await setup();
    const first = await h.googleLogin();
    const initial = h.db.sqlite.prepare("SELECT * FROM accounts").get()!;
    const batch = h.db.batch.bind(h.db);
    h.db.batch = async (statements) => {
      h.db.sqlite
        .prepare("DELETE FROM account_sessions WHERE token_hash=?")
        .run(first.hash);
      return batch(statements);
    };
    const response = await h.call(action, {
      cookie: first.cookie,
      method: action === "data" ? "GET" : "POST",
      ...(action === "authorize"
        ? { body: { operationId: crypto.randomUUID() } }
        : {}),
    });
    assert.notEqual(response.status, 200);
    assert.deepEqual(
      h.db.sqlite.prepare("SELECT * FROM accounts").get(),
      initial,
    );
    assert.equal(
      h.db.sqlite
        .prepare("SELECT COUNT(*) AS n FROM export_authorizations")
        .get()!.n,
      0,
    );
    assert.equal(
      h.db.sqlite
        .prepare("SELECT COUNT(*) AS n FROM account_auth_tombstones")
        .get()!.n,
      0,
    );
  }
});
