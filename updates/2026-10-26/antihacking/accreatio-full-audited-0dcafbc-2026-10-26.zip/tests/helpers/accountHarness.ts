import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import {
  ACCOUNT_POLICY,
  ACCOUNT_COOKIES_NOTICE_VERSION,
} from "../../shared/accountPolicy";
import {
  handleAccount,
  type AccountBindings,
  type AccountDatabase,
} from "../../functions/_lib/accounts";
import type {
  BlogPreparedStatement,
  DatabaseValue,
  RuntimeDependencies,
} from "../../functions/_lib/platform";

// Real SQLite executes the production statements and transactional batches.
// Only the clock, mail transport and separate admin identity are fixtures.
export const POLICY_AUTHORIZATION = {
  ...ACCOUNT_POLICY,
  accountDataAuthorized: true,
  termsAccepted: true,
};

export const POLICY_CONTINUATION = {
  ...POLICY_AUTHORIZATION,
  cookiesNoticeVersion: ACCOUNT_COOKIES_NOTICE_VERSION,
  cookiesNoticeAcknowledged: true,
};

class SqliteStore implements AccountDatabase {
  readonly sqlite = new DatabaseSync(":memory:");
  now = Date.parse("2026-09-05T23:59:00Z");
  fail = false;
  constructor() {
    this.sqlite.exec("PRAGMA foreign_keys = ON");
    this.sqlite.exec(
      readFileSync(
        new URL("../../migrations-auth/0001_accounts.sql", import.meta.url),
        "utf8",
      ),
    );
    this.sqlite.exec(
      readFileSync(
        new URL(
          "../../migrations-auth/0002_own_email_otp.sql",
          import.meta.url,
        ),
        "utf8",
      ),
    );
    this.sqlite.function("unixepoch", () => this.now / 1000);
    this.sqlite.exec(
      readFileSync(
        new URL(
          "../../migrations-auth/0003_google_oidc_privacy.sql",
          import.meta.url,
        ),
        "utf8",
      ),
    );
    this.sqlite.exec(
      readFileSync(
        new URL(
          "../../migrations-auth/0004_google_display_name.sql",
          import.meta.url,
        ),
        "utf8",
      ),
    );
    this.sqlite.exec(
      readFileSync(
        new URL(
          "../../migrations-auth/0005_account_policy_authorization.sql",
          import.meta.url,
        ),
        "utf8",
      ),
    );
    this.sqlite.exec(
      readFileSync(
        new URL(
          "../../migrations-auth/0006_github_identity_linking.sql",
          import.meta.url,
        ),
        "utf8",
      ),
    );
    for (const migration of [
      "0007_abuse_guard.sql",
      "0008_rights_only.sql",
      "0010_cookies_notice_acknowledgement.sql",
    ])
      this.sqlite.exec(
        readFileSync(
          new URL(`../../migrations-auth/${migration}`, import.meta.url),
          "utf8",
        ),
      );
  }
  prepare(sql: string) {
    return new Statement(this, sql);
  }
  async batch(statements: Statement[]) {
    if (this.fail) throw new Error("database offline");
    this.sqlite.exec("BEGIN");
    try {
      const result = statements.map((s) => ({
        success: true,
        results: s.read(),
      }));
      this.sqlite.exec("COMMIT");
      return result;
    } catch (error) {
      this.sqlite.exec("ROLLBACK");
      throw error;
    }
  }
}
class Statement implements BlogPreparedStatement {
  values: DatabaseValue[] = [];
  constructor(
    private store: SqliteStore,
    private sql: string,
  ) {}
  bind(...values: DatabaseValue[]) {
    this.values = values;
    return this;
  }
  read() {
    if (this.store.fail) throw new Error("database offline");
    return this.store.sqlite.prepare(this.sql).all(...this.values);
  }
  async first<T>() {
    return (this.read()[0] as T | undefined) ?? null;
  }
  async all<T>() {
    return { success: true, results: this.read() as T[] };
  }
  async run() {
    this.read();
    return { success: true };
  }
}

const issuer = "https://account-tests.cloudflareaccess.com";
const origin = "https://accreatio.pages.dev";
export async function harness() {
  const db = new SqliteStore();
  const mailbox: { email: string; code: string; expiresInMinutes: number }[] =
    [];
  const pair = await crypto.subtle.generateKey(
    {
      name: "RSASSA-PKCS1-v1_5",
      modulusLength: 2048,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: "SHA-256",
    },
    true,
    ["sign", "verify"],
  );
  const jwk = await crypto.subtle.exportKey("jwk", pair.publicKey);
  const kid = crypto.randomUUID();
  const env: AccountBindings & {
    ACCOUNT_ACCESS_ISSUER: string;
    ACCOUNT_ACCESS_AUDIENCES: string;
  } = {
    ACCOUNT_DB: db,
    ACCOUNT_ENABLED: "true",
    ACCOUNT_ACCESS_ISSUER: issuer,
    ACCOUNT_ACCESS_AUDIENCES: '["project-account"]',
    ACCOUNT_IDENTITY_KEY: "a".repeat(64),
    ACCOUNT_OTP_KEY: "b".repeat(64),
    ACCOUNT_MAILER: {
      async fetch(request: Request) {
        assert.equal(request.url, "https://account-mailer.internal/otp");
        mailbox.push(
          (await request.json()) as {
            email: string;
            code: string;
            expiresInMinutes: number;
          },
        );
        return Response.json({ ok: true }, { status: 202 });
      },
    },
  };
  const dependencies: RuntimeDependencies = {
    now: () => db.now,
    randomUUID: () => crypto.randomUUID(),
    subtle: crypto.subtle,
    fetch: async () =>
      Response.json({ keys: [{ ...jwk, kid, alg: "RS256", use: "sig" }] }),
  };
  async function token(overrides: Record<string, unknown> = {}) {
    const claims = {
      email: "person@example.test",
      sub: "verified-human",
      iss: issuer,
      type: "app",
      aud: ["project-account"],
      iat: db.now / 1000,
      exp: db.now / 1000 + 3600,
      ...overrides,
    };
    const header = Buffer.from(JSON.stringify({ alg: "RS256", kid })).toString(
      "base64url",
    );
    const payload = Buffer.from(JSON.stringify(claims)).toString("base64url");
    const data = `${header}.${payload}`;
    const signature = await crypto.subtle.sign(
      "RSASSA-PKCS1-v1_5",
      pair.privateKey,
      new TextEncoder().encode(data),
    );
    return `${data}.${Buffer.from(signature).toString("base64url")}`;
  }
  async function call(
    action: Parameters<typeof handleAccount>[1],
    options: {
      cookie?: string;
      body?: unknown;
      method?: string;
      url?: string;
      token?: string;
      claims?: Record<string, unknown>;
      origin?: string;
      env?: AccountBindings;
      ip?: string;
      headers?: Record<string, string>;
      bindExportContext?: boolean;
    } = {},
  ) {
    let body = options.body;
    if (
      action === "authorize" &&
      options.bindExportContext !== false &&
      body !== null &&
      typeof body === "object" &&
      Object.keys(body).join() === "operationId" &&
      "operationId" in body &&
      typeof body.operationId === "string" &&
      /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(
        body.operationId,
      )
    ) {
      // Direct account-SQL fixtures bind their current session. HTTP/UI
      // transports must disable this so missing client context is not repaired.
      const session = await call("session", {
        ...options,
        body: undefined,
        method: "GET",
      });
      if (session.status === 200) {
        const { ownerKey, sessionKey } = await session.json();
        body = { ...body, ownerKey, sessionKey };
      }
    }
    const request = new Request(
      options.url ?? `${origin}/api/account/${action}`,
      {
        method: options.method ?? "POST",
        headers: {
          Origin: options.origin ?? origin,
          "Content-Type": "application/json",
          "CF-Connecting-IP": options.ip ?? "192.0.2.1",
          ...(options.token === undefined && options.claims === undefined
            ? {}
            : {
                "Cf-Access-Jwt-Assertion":
                  options.token ?? (await token(options.claims)),
              }),
          ...(options.cookie ? { Cookie: options.cookie } : {}),
          ...options.headers,
        },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      },
    );
    return handleAccount(
      { request, env: options.env ?? env },
      action,
      dependencies,
    );
  }
  let fixtureQueue: Promise<unknown> = Promise.resolve();
  function login(
    claims?: Record<string, unknown>,
    options: { policyAuthorization?: boolean } = {},
  ): Promise<string> {
    const action = fixtureQueue.then(async () => {
      const email =
        typeof claims?.email === "string"
          ? claims.email
          : "person@example.test";
      const last = db.sqlite
        .prepare("SELECT MAX(created_at) AS latest FROM account_otp_challenges")
        .get()?.latest;
      if (typeof last === "number") db.now = Math.max(db.now, last + 60_000);
      const requested = await call("otp/request", {
        body: { email, policyAuthorization: POLICY_AUTHORIZATION },
      });
      assert.equal(requested.status, 200);
      const { challengeId } = await requested.json();
      const response = await call("otp/verify", {
        body: { challengeId, code: mailbox.at(-1)!.code },
      });
      assert.equal(response.status, 200);
      const header = response.headers.get("Set-Cookie")!;
      assert.match(header, /Secure; HttpOnly; SameSite=Strict/);
      if (options.policyAuthorization !== false) {
        // Explicit fixture continuation, separate from sign-in. Production never
        // infers the cookies notice acknowledgement from authentication.
        assert.equal(
          (
            await call("policy", {
              cookie: header.split(";")[0],
              body: POLICY_CONTINUATION,
            })
          ).status,
          200,
        );
      }
      if (options.policyAuthorization === false) {
        // Represent an existing pre-migration account/session, never a server
        // path that grants authentication without the new affirmative action.
        const tokenHash = Buffer.from(
          await dependencies.subtle.digest(
            "SHA-256",
            new TextEncoder().encode(header.split(";")[0].split("=")[1]),
          ),
        ).toString("hex");
        db.sqlite
          .prepare(
            "DELETE FROM account_policy_authorizations WHERE account_id=(SELECT account_id FROM account_sessions WHERE token_hash=?)",
          )
          .run(tokenHash);
      }
      return header.split(";")[0];
    });
    fixtureQueue = action;
    return action;
  }
  async function controlProof(
    cookie: string,
    action: "data" | "delete" | "link_google" | "link_github",
  ) {
    // Fixture for suites testing account SQL rather than OAuth. Production
    // grants this metadata only after a new same-account, action-bound exchange.
    // Preserve authentication time so expired-proof tests remain meaningful.
    const tokenHash = Buffer.from(
      await crypto.subtle.digest(
        "SHA-256",
        new TextEncoder().encode(cookie.split(";")[0].split("=")[1]),
      ),
    ).toString("hex");
    db.sqlite
      .prepare(
        "UPDATE account_session_metadata SET verification_action=? WHERE token_hash=?",
      )
      .run(action, tokenHash);
  }
  return { db, env, call, login, token, dependencies, mailbox, controlProof };
}
