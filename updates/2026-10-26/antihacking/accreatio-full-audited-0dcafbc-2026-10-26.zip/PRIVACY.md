# accreatio privacy baseline pointer

Owner instruction: 2026-10-11. Shared engineering requirements are maintained in
[AEKR_PRIVACY_BASELINE.md](https://github.com/edlopezpm-ops/timeKER/blob/main/docs/legal/AEKR_PRIVACY_BASELINE.md).
This local intake is not a replacement for `public/legal/privacy.html` or
`public/legal/terms.html`, a live release, or a compliance certification.

Source reviewed at `9899571c230faf84cd42a9b5fd40afc09a52a00c`: local project drafts
in IndexedDB; separate D1 account and blog stores; no-op/default-off optional
analytics and advertising adapters. Account-data sale, advertising and identity
combination across products are excluded by the existing notice. Preserve them.

Authentication uses `__Host-accreatio_session` (24 hours, Secure/HttpOnly/Strict)
and Google transaction cookie `__Host-accreatio_auth_tx` (10 minutes,
Secure/HttpOnly/Lax). Account deletion does not erase local drafts. Cleanup periods
and provider copies have separate rules in the current notice. The independent
2026-10-11 public GET saw a Cloudflare Access gate setting `CF_Session`; inspect
that provider boundary before claiming a complete cookie inventory.

Owner now confirms Chile/USA operations, worldwide intent and the shared
support/privacy contact `aekr@aekr.io`. The currently published accreatio contact
remains unchanged by this intake; update it in a bounded product release after
checking links and request handling. Record exact controller/entity, address,
US state and actual served markets. Verify live cleanup, rights, provider logs,
transfers and retention. No optional collection or sibling publication is enabled.
