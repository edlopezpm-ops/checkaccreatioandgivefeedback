export const ACCOUNT_POLICY = {
  privacyNoticeVersion: "2026-10-25-captcha-privacy",
  termsVersion: "2026-10-25-captcha",
  purposeVersion: "account-core-v1",
} as const;

export const ACCOUNT_COOKIES_NOTICE_VERSION = "2026-10-22b-privacy";

export type AccountPolicyAuthorization = {
  readonly privacyNoticeVersion: string;
  readonly termsVersion: string;
  readonly purposeVersion: string;
  readonly accountDataAuthorized: boolean;
  readonly termsAccepted: boolean;
};

export type AccountPolicyContinuation = AccountPolicyAuthorization & {
  readonly cookiesNoticeVersion: string;
  readonly cookiesNoticeAcknowledged: boolean;
};
