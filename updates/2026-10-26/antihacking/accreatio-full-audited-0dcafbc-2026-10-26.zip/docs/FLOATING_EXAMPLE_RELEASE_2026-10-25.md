# Floating example and help presentation — 25 October 2026

Published at [accreatio.com](https://accreatio.com/). This owner-requested correction supersedes the presentation in the [earlier help release](HELP_AND_SHARED_CAPTCHA_RELEASE_2026-10-25.md); that historical receipt is preserved.

## Delivered changes

- Welcome heading: `Prepare the brief for your next project`.
- `See an example` / `Ver un ejemplo` is a native hyperlink opening the complete SOP in a wide floating dialog. The welcome screen and URL remain in place. Previous/next controls sit at the image sides, with overlays on narrow screens to retain image width. The counter is below the image. Escape, close and backdrop dismissal restore focus to the link.
- The same side navigation is used by the shared tips component. Project-module and result help remain. The Blog and account-menu help links and their unused prop wiring were removed.
- The visible About panel credits `AEKR · 2026`, retains the application version and omits the personal name and free/private-use license label. Canonical licensing and Terms documents were not changed.
- EN/ES FAQ describes the floating guide and project-only contextual help. The account-panel SOP images were rebuilt to remove their obsolete help link. Only those two images and the manifest changed; the other 32 images remained byte-identical. All 34 remain 3840 × 2160.

## Source and publication

Runtime source: `5fba2922b49a00ff47f12aecbc5ee1d082430db4`, committed and pushed to `main` from baseline `e8cc49473133d3acd68a5d77e7b1c9a80f0317bf`.

Production Pages deployment: `2c71b4bf-828a-4ce2-ad85-bb12a1117a3c`, [immutable URL](https://2c71b4bf.accreatio.pages.dev/). The in-app browser's existing Pages Retry action published that exact source. Dashboard status was success at 20:07 EDT, duration 1 minute 21 seconds. Automatic deployments remained paused. No database, provider, secret, consent, quota, dependency or service-cost change was made.

## Verification and boundaries

- Unit/regression suite **491/491 PASS**; app/Functions typecheck and formatting PASS.
- Web build and publication gate PASS: 86 files. Web-only surface smoke PASS with zero desktop files. SOP manifest/dimension checks PASS.
- Full web functional smoke PASS in EN/ES at 1280, 760, 390 and 320 px. New cases cover hyperlink semantics, real 4K decode, floating-dialog bounds with native scrollbars, desktop rails/mobile overlays, counter placement, previous/next, URL and welcome-state preservation, Escape/focus restoration, absent Blog/account help and the revised About copy. Existing project and ZIP flows passed in the same run. Authenticated cases use isolated fictional fixtures.
- Hosted readback checked 84 public bodies: 82 exactly match the build. Root HTML has the known Cloudflare JavaScript-detection insertion; robots.txt has its managed prefix followed by the source restriction. Neither is called byte-identical; there are zero unexpected mismatches. Public methods still require the existing shared CAPTCHA and an anonymous account-session request remains 401.
- In-app-browser hosted inspection confirms the corrected heading, hyperlink, wide floating image, lateral navigation, counter and About copy. Narrow viewport inspection confirms the dialog remains inside the 375 px client area of the requested 390 px viewport. Public review used a temporary tab with account-session requests blocked and the worker bypassed to inspect the fresh shell; this test configuration was confined to that tab and removed when closing it. No personal OAuth, account export/deletion, Terms acceptance or quota-consuming project export was performed in hosted QA. This is technical delivery evidence, not human acceptance.

Final unit log: `.local/logs/2026-10-26T00-02-10-542Z-test-7ea11ac8-119d-4a77-afa1-ea4e76ebbb21.log`. Final build: `.local/logs/2026-10-26T00-03-20-730Z-build-web-0a97ae3f-d679-4257-9123-fdd031a5d6f6.log`. Full web smoke: `.local/logs/2026-10-26T00-03-48-887Z-test-web-45a319f9-f8d3-4dfa-90f8-aa2c7baafa7c.log`. These UTC filenames fall on 26 October while the owner's local delivery date is 25 October. Hosted readback is under `.local/logs/floating-example-20261025/`; browser captures are under `.local/logs/playwright/floating-example-20261025/`. Ignored local evidence is not assumed present in another checkout.

The commit containing this receipt is documentation only and does not require another deployment. Preexisting untracked audit material was preserved.
