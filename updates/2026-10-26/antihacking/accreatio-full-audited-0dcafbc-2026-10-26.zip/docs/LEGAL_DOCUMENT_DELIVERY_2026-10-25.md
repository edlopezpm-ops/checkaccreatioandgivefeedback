# Legal-document delivery addendum — 2026-10-25

Outcome: LOCAL_REGRESSION_VERIFIED

Delivery state: SOURCE_CANDIDATE / INDEPENDENT_REVIEW_AND_PUBLICATION_PENDING

Product state: LEGAL_DELIVERY_CORRECTION_NOT_YET_HOSTED

Gate/authority state: OWNER_AUTHORIZED_TOS_DELIVERY / ALGORITHMS_DISCOVERY_ONLY

## Scope and cause

This bounded delivery correction starts at `04f837ccfcd37f9cd5bce1d70537ecabc9002230`. It supplements the [Terms source receipt](TOS_HARDENING_2026-10-25.md); it does not revise its historical validation or publication statements.

The generated worker precached the four legal HTML documents. Workbox also matched clean URLs such as `/legal/terms` to their cached `.html` counterparts. Thus an already installed worker could display older Terms even when the server returned the current document. The existing HTTP revalidation header could not refresh a response served directly from that worker's precache.

`vite.config.mts` now excludes `legal/**/*.html` from precaching and denies `/legal`, its query form and its descendants from the application-shell navigation fallback. Once the replacement worker activates, Workbox removes the obsolete legal entries from its precache. Legal documents then reach the network and the existing `public, max-age=0, must-revalidate, no-transform` policy. Cached legal CSS/JavaScript and the unrelated offline application shell retain their existing behavior.

No Terms text/version, account receipt, acceptance flow, Privacy/cookie choice, draft, account service, discovery prompt, detector, algorithm, dependency, runtime binding or provider changes. The candidate's 48 publication files differ from the baseline only in `sw.js`. Terms remain byte-identical: SHA-256 `baaf4f9d7847ec9fd9fe88dcc40eae665136f01b1249df30bf184a3a5c0c86ae`.

## Local regression and checks

[`scripts/pwa-legal-smoke.mjs`](../scripts/pwa-legal-smoke.mjs) uses real, separately generated production workers and assets, a loopback HTTP server and disposable Chromium contexts. Its bootstrap installs a worker without opening the account UI or using any real provider, account, browser profile, backup or private payload.

- **RED:** the actual legacy build from `d836e7ee8e03f83eb2d5b53e1ba655d7d6efef54` serves cached older Terms after the fixture server switches to the current document, with zero legal-document network requests. Replacing it with the unchanged `04f837c` baseline still leaves four legal HTML entries and fails the same cache-removal assertion. Receipt: `.local/logs/pwa-legal-bxzoD1/receipt.json`.
- **GREEN:** the replacement activates, all four legal HTML cache entries disappear, and a deliberate reload reaches the current Terms over the network. Eight clean/explicit-HTML routes return exact current bytes. Eight later document revisions return the updated bytes without changing the worker. Three unknown legal routes return the fixture's 404, a simulated unavailable route returns its 503, and eight offline legal navigations fail instead of receiving cached legal text or the app shell. The unrelated offline shell still works, and a fresh controlled client also receives the current network document. Receipt: `.local/logs/pwa-legal-kt2aN9/receipt.json`.
- The 17 focused account-policy, web-release and surface-boundary tests pass. App/Functions typechecks, web build, 48-file artifact gate, web-only boundary smoke, script syntax, formatting and diff checks pass. The existing large-chunk advisory remains. No full-suite rerun is claimed.
- A read-only auxiliary implementation review found no material issue. Requested implementation dispatch is GPT-6.1 Sol with ultra reasoning; writer `/root/tos_accreatio_cache_fix`. Independent Astra/ultra review of the immutable commit and actual publication remain separate coordinator steps. This receipt does not attest model identity, legal approval or security certification.

Worker SHA-256: legacy `edead738ff5804dabb839b423c627c33e2b4db2245f04c5a6d79ab5bbcf1b396`; RED baseline `ac009b0f5d4b9da47e58ece7bf3e4c1255e5c6fca96bb25b787155261a539d92`; GREEN candidate `b024ad57f57150350ee6a142fd03d4e3f37c42df1e73904cd546ea40e5a291e7`.

Reproduce with `node scripts/pwa-legal-smoke.mjs --legacy-dir <legacy-web-build> --candidate-dir dist` after the web build. The legacy input was built from a `git archive` of the named commit with the resident dependencies; scratch inputs stay under `.local/cache/pwa-legal-tos-20261025/`. Command summaries use `.local/logs/pwa-legal-*-20261025.log`. An initial fixture-only race between Chromium error documents was corrected by isolating each offline navigation in its own disposable tab.

## Delivery limits

An already controlling older worker can still serve one old legal document before discovering and activating the replacement. This patch cannot retroactively alter that old worker. The local harness calls `registration.update()` to make the transition deterministic and then reloads deliberately; it does not prove immediate automatic adoption by every open client. A previously installed client may need an online update and reload once. No browser-storage clearing or forced application reload is introduced.

The 404, 503 and offline checks describe the local fixture and generated worker, not Cloudflare observations. After publication, verify the existing canonical host both with a prior controlling client and a fresh client. Deployment, hosted observation, owner acceptance and any real Terms continuation remain separate evidence. This candidate performs no deployment, provider authorization, push, workflow, PR or real-user acceptance.

Technical references: [Workbox precaching lifecycle and URL matching](https://developer.chrome.com/docs/workbox/modules/workbox-precaching), [Workbox navigation-route denylist](https://developer.chrome.com/docs/workbox/reference/workbox-routing), and [Vite PWA excluded-route/offline behavior](https://vite-pwa-org.netlify.app/workbox/inject-manifest#exclude-routes).
