# Terms language and presentation correction — 2026-10-25

Outcome: LOCAL_IMPLEMENTATION_VERIFIED

Delivery state: SOURCE_ONLY

Product state: PRESENTATION_CORRECTION_NOT_YET_OBSERVED_ON_CANONICAL_HOST

Gate/authority state: OWNER_AUTHORIZED_DIRECT_MAIN_DELIVERY / PUBLICATION_BY_COORDINATOR_PENDING

## Scope and source

The owner's follow-up requires complete separate English and Spanish Terms, selected through the application's existing main language control, and a single version line without verbose header metadata or verification identifiers. This correction starts from clean remote `main` at `0d3c13a1dfba54128a6ee2dbc0474dc0639f98e5` in the existing isolated product checkout. Historical source, cache and hosted release receipts remain unchanged.

`public/legal/terms.html` contains English only. `public/legal/terms-es.html` contains Spanish only, with all fourteen clauses and the same paragraph structure as English. Spanish clauses 1–10 now provide the complete text instead of the former grouped summary; existing Spanish clauses 11–14 retain their substance. The canonical maintained sources are respectively `docs/TERMS_OF_SERVICE.md` and `docs/TERMS_OF_SERVICE_ES.md`. Attachment and automated-agent rules formerly repeated in the Markdown appendix are integrated into clause 6 of each language.

The only introductory metadata is `Version 2026-10-25-acceptable-use`. Operator identity, institutional notice address and contact/report/review/appeal channels remain within substantive clauses. User-facing request-counter protection and draft ownership wording preserve the existing protections without exposing the technical verification label or internal draft key. The account purpose remains disclosed; no mechanism or version changes with this presentation correction.

`src/legal.ts` supplies localized Terms URLs to all five application entrypoints: About, project information, sign-in, signed-in account menu, and the account continuation/renewal notice. Every link uses the real current `locale` supplied by the unchanged primary language control. There are no additional language controls in either Terms document.

The main application already carries the selected language in its URL. No new cookie, localStorage/sessionStorage key, account setting or private draft read is introduced. Explicit valid `lang=en/es` selects the corresponding full document; refresh preserves that URL. A same-origin referrer's valid `lang` is a fallback for links from the other legal pages. Bare main Terms defaults to English, matching the application's bare-URL default; a bare explicit Spanish document stays Spanish. Cross-origin referrers do not select a language. An early external script hides a mismatched document before replacing its URL, and Terms navigation/return links retain the selected language. The existing CSP remains unchanged.

## Preserved boundaries

- Terms version remains `2026-10-25-acceptable-use`; Privacy remains `2026-10-22b-privacy`; purpose remains `account-core-v1`.
- Privacy/cookies content, optional choices, deliberate account acceptance, account receipts, rights-only access, providers, legal restrictions, future algorithm/discovery boundaries and all runtime data mechanisms remain unchanged. No real acceptance, migration or backfill is performed.
- `vite.config.mts` remains unchanged from the published PWA correction `a1adeed9d1ace02ca55bd1df23964e0c43534e59`. The generated worker excludes both Terms HTML documents and all other legal HTML; legal navigation still bypasses the offline application fallback.
- Product branding, palette, typography and legal stylesheet are unchanged. No Cloudflare operation, browser session, deployment, PR or GitHub Actions run is performed by this implementation. Direct push to existing `main` uses `[skip ci]` under the owner's order.

## Focused verification

- 23/23 tests pass across `termsPresentation`, `accountPolicy`, `about` and `webRelease`. They cover complete fourteen-clause language documents, canonical/public text parity, per-clause paragraph parity, one version line, excluded verification labels, all five localized entrypoints, direct/clean/explicit routes, refresh-equivalent requests, valid and invalid language queries, same-origin inheritance, foreign-referrer exclusion and language-preserving legal/return links. Script behavior is exercised in isolated JavaScript contexts without storage or a browser. Existing account tests use synthetic local SQLite and verify deliberate renewal and preserved own-data access.
- App typecheck and production web build pass; Functions typecheck passes. The publication gate passes with 50 files and no source maps or known internal configuration/source paths. The build retains the existing advisory for chunks over 500 kB.
- A separate baseline comparison verifies all fourteen English clauses are retained, apart from three authorized presentation simplifications: the version reference, request-counter verification terminology and the internal draft reference. Spanish clauses 11–14 are retained apart from the version reference. Generated worker inspection confirms no legal HTML, including the added Spanish document, enters its precache.
- Formatting of every edited source/document and `git diff --check` pass. No full-suite or browser regression run is claimed.

Ignored logs: `.local/logs/terms-presentation-tests-20261025.log`, `.local/logs/2026-10-25T16-49-04-271Z-build-web-33a14b55-ce4f-4872-81f0-49dd463dd439.log` and `.local/logs/2026-10-25T16-49-04-271Z-typecheck-functions-6375253b-ff75-404f-89b6-5428d3d20ad4.log`. These are local source evidence only.

The coordinator explicitly dispatched writer `/root/tos_ui_accreatio` with `fork_turns=none`, `model=gpt-6.1-sol` and `reasoning_effort=ultra`; the spawn tool accepted those parameters. Runtime model telemetry was not measured. A separate inherited-model reader inspected the initial source entrypoints and language behavior, without writing files; that source inspection is not an independent review of the final immutable patch. This receipt supplies no legal approval, security certification, human acceptance or hosted-delivery claim.

## Required hosted observation

The coordinator must publish the complete new build through the existing Pages project and verify fresh and previously controlled clients after the application update/reload. At desktop and mobile widths, use the primary language button in both directions, open Terms from account/renewal and public entrypoints, and confirm only the selected complete language appears. Check refreshed and direct `terms`, `terms.html` and `terms-es.html` routes with both valid queries and bare fallback, language-preserving return to accreatio, the sole version line, and retained reporting/rights/acceptable-use clauses. A client still running an older application bundle may retain its older link behavior until the updated worker/application activates. Source push, deployment and actual hosted observation remain separate facts.
