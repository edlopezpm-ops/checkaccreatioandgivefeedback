# accreatio acceptable-use Terms update — 2026-10-25

Outcome: LOCAL_IMPLEMENTATION_VERIFIED
Delivery state: SOURCE_CANDIDATE / INDEPENDENT_REVIEW_AND_PUBLICATION_PENDING
Product state: NEW_TERMS_NOT_YET_OBSERVED_ON_CANONICAL_HOST
Gate/authority state: OWNER_AUTHORIZED_TOS_PUBLICATION / ALGORITHMS_DISCOVERY_ONLY

## Authority and scope

The owner's 25 October order authorizes strengthened EN/ES Terms, versioned account review, source delivery and publication, together with a future abuse-prevention discovery prompt. The central contract is `aekr-collectandsecurity/tos/IMPLEMENTATION_CONTRACT_2026-10-25.md`, T01–T19 including the later AI-video/AI-slop order. Existing product governance, local project custody, zero direct service cost and separate optional choices remain.

This candidate starts at verified remote `main` commit `d836e7ee8e03f83eb2d5b53e1ba655d7d6efef54` in the clean isolated checkout on `codex/tos-hardening-accreatio-20261025`. The canonical sibling's older checkout and unrelated untracked documents were not changed.

## Product change

- `public/legal/terms.html` and maintained `docs/TERMS_OF_SERVICE.md` add matching EN/ES clauses 11–14: accessible legitimate work; authority and material rights; prohibited content and malicious projects; proportionate restrictions; minimal reports, human review and appeals through the existing contact; future controls; and a bounded legal notice preserving mandatory rights.
- The service exclusion covers pornography, nudity, **all photographs of minors and images depicting minors, identifiable or not, real or synthetic**. This is a product rule broader than criminal law, not a declaration that all ordinary images of minors are criminal.
- Security abuse includes websites, banks, social networks, phones, payment cards, wallets/cryptoassets and other systems. Authorized defensive security with a defined scope remains distinguishable from abuse.
- The stale blanket statement that no optional tracker is enabled is replaced only in Terms by the existing Privacy Policy's independent prospective usage/research choices. No Privacy notice, optional collection version, account purpose, provider or collection permission changes.
- `ACCOUNT_POLICY.termsVersion` becomes `2026-10-25-acceptable-use`. Privacy remains `2026-10-22b-privacy`; necessary purpose remains `account-core-v1`. Existing deliberate renewal applies to stale Terms receipts; visits/session refresh do not accept. Rights-only access continues without new Terms. No migration, receipt backfill or real-user acceptance was performed.
- The [discovery prompt](discovery/ABUSE_PREVENTION_DISCOVERY_PROMPT_2026-10-25.md) is copied byte-for-byte from the owner's central deliverable, including T19. SHA-256: `5cc8f09818c78a0e5614753c8b5ec72b3901ed16bb2f514944ec3915b67b8010`. It was **not executed**. The prior candidate's prompt hash was `a646f5505b809706388bdebb8a283a0542d55afda922cf884409044cf10048d1` before the owner's additional instruction.
- T19 excludes projects, prompts, plans and agent configurations for AI-generated videos or AI slop, including downstream generation by another service. It covers creative generation/replacement of scenes, characters, avatars or voices without a percentage threshold or quality exception. Ordinary text/caption/cut/template assistance on real footage and legitimate AI-assisted orchestration are not prohibited merely for using AI. No detector or origin certification is activated.

The change adds no content/fraud classifier, automatic content sanction, age/biometric check, model provider, charge, upload receiver or private-content inspection. Existing attachment reconstruction and bounded request-abuse controls retain their source behavior. Branding, design, account functions and runtime bindings are unchanged.

## Local validation

- 47/47 focused unit/integration tests pass: account policy, rights, existing account abuse, guard, rights client, web release and About.
- Added a real SQLite regression for a Terms-only stale receipt: session read preserves its old receipt/timestamp; export authorization is blocked; verified own-data access still returns the old receipt; deliberate current renewal updates Terms and database time while preserving Privacy/purpose versions.
- Typecheck for app/Functions, Functions compilation and web build pass. The existing web publication gate reports 48 files and no source maps or known internal source/configuration paths.
- Web-only artifact boundary smoke passes. Existing built-browser account/SQLite suite and rights UI suite pass; rights scenarios cover EN/ES at desktop and 320px, exact download, rejected transactions, confirmed synthetic deletion, Retry-After, cancellation and local preservation. Browser fixtures are synthetic and local; no real mail or provider login was sent.
- Prettier for edited HTML/TypeScript and `git diff --check` pass. Build retains the existing advisory for chunks larger than 500 kB; no bundle restructuring is part of this ToS update.

Ignored command logs are under `.local/logs/`, with prefix/date `tos-20261025` or `2026-10-25T15-04`; browser receipts are `.local/logs/account-ui-1792940684541` and `.local/logs/account-rights-ui-1792940685162`. These are local evidence, not hosted observation or human acceptance.

## Research and review limits

The source writer is `/root/tos_accreatio_implementation`, inheriting the parent implementation dispatch requested as GPT-6.1 Sol with ultra reasoning. Model/runtime identity is not independently attested by this receipt. Central social/billing research records the separately requested Astra/ultra comparison; that is research scope, not product certification. Independent candidate review and actual Git/host receipts must be recorded separately.

Primary references consulted by this implementation include [Cloudflare Pages configuration](https://developers.cloudflare.com/pages/functions/wrangler-configuration/), [Chile Law 21.459](https://www.bcn.cl/leychile/navegar?idNorma=1177743&tipoVersion=0), and the central current official-source legal/social corpus, including [Chile consumer-law consolidated text](https://www.bcn.cl/leychile/navegar?idNorma=1160403), [YouTube child-safety policy](https://support.google.com/youtube/answer/2801999?hl=en), [US Copyright Office section 512](https://www.copyright.gov/512/) and [EU DSA](https://eur-lex.europa.eu/eli/reg/2022/2065). These guide original product wording; no external contract or its exceptions were imported as authorization. Applicable laws, roles and dates require review for the actual service and market; neither these documents nor this technical work certifies worldwide compliance or immunity from claims.

## Publication and rollback boundary

### Additional owner instruction before first publication

The first source patch was merged as PR14, commit `6079151bcb547677abdf665695b384ee3efcd92b`, but public readback still showed `2026-10-22b-beta`; it was not deployed. The subsequent AI-video/AI-slop wording is added before this release's first publication. `ACCOUNT_POLICY`, Privacy and purpose are unchanged by this follow-up; the pending target Terms version remains `2026-10-25-acceptable-use`, without any existing acceptance of the unpublished target being fabricated. The follow-up changes only the two Terms documents, the exact discovery copy and this receipt.

The 47 focused tests and broader local checks above describe the first source candidate. Follow-up verification is recorded separately; unchanged account/rights suites are not claimed as freshly rerun. CI for PR14 and merge stopped at the existing npm audit dependency findings; package manifests/lock were unchanged. OAuth was valid but lacked the Pages scope (project API 403/code10000); that failure is not deployment evidence. Publishing remains a separate required operation.

Follow-up T19 verification by the coordinator: the existing account-policy suite passed 10/10, including document/version parity, deliberate renewal and preserved rights; the web build/typecheck and 48-file artifact gate passed. HTML formatting and diff checks passed. These checks do not execute the discovery prompt, classify project content or prove hosted delivery. Initial source review remains scoped to its reviewed commit; the T19 follow-up has its own immutable commit and bounded review.

Source review, commit/push/merge, Pages deployment, public HTTP readback and the owner's requested in-app browser observation remain separate facts. A read-only Wrangler deployment listing initially returned Cloudflare API authentication error 10000; no remote change followed from that attempt. It is not a deployment or permission change.

Use the existing Pages production project and exact compatible production variables, bindings and secrets. No migration, DNS, new provider, paid resource or runtime-key rotation is needed. A compatible source/deployment rollback must preserve real current receipt handling and rights access; do not fabricate acceptance, restore withdrawn optional choices or alter user data to match a release. A later receipt will bind actual publication and observed version to immutable source.
