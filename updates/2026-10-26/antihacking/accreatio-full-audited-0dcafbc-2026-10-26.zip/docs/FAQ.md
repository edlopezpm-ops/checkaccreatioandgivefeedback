# accreatio FAQ

Updated: 2026-10-25. This guide describes the restricted beta for the web. Available account methods are shown on the sign-in screen. The desktop prototype is obsolete, was never released and will never be released; accreatio is web-only.

## Getting started

### What will I make?

accreatio turns your project definition into a structured starting point: a project prompt, discovery and governance documents, a plan, and an inspectable ZIP. The exact contents depend on your selected output. It does not build the finished product or run AI agents for you.

Open the See an example link on the welcome screen before signing in. It opens a floating 4K illustrated walkthrough with previous/next controls at the sides: sign in, name the project, explain the idea, set constraints, add supporting files, review, export, and continue from the downloaded ZIP. This preview uses a fictional project and does not sign you in or change your draft. After exporting your own project, extract the ZIP, open the folder in your editor, and follow `START.md`.

### Do I need every answer first?

No. Start with a project name of up to 50 characters and work through one question at a time. Idea/context accepts up to 20,000 UTF-16 units, constraints up to 10,000, and each participant task up to 5,000. These use the JavaScript textarea count; some emoji count as two units. You can go back, change answers, and use the project summary before confirming. The summary shows your current choices, selected-file count, and planned participants. Participants are roles in the plan, not agents currently running.

### How many team roles can I choose?

The web flow supports one to four participants with unique roles: Generalist, Architect, Implementer, and Auditor. A selected role cannot be selected again. Later, compare the plan with the tools and agents actually available; exporting four roles does not create four live agents.

### Is the beta free, and do I need an account?

Sign in to prepare your project. The access screen shows the methods enabled in this environment; the About FAQ lists the server-confirmed providers when available. No email-code step is required when that method is disabled. Signing in is separate from authorizing access to a repository. About, the sample, and published Blog posts are public. The separate account service authorizes five new exports per account in any rolling 24 hours across sessions and devices; there is no midnight reset. Editing and checking do not use allowance. You can retry the same authorized export within 48 hours without using another slot, while its ZIP remains available in the same tab. Account controls provide own-data download and deletion; see the [Privacy Policy](PRIVACY_POLICY.md).

## Review and export

### What is the difference between dry review and Prepare ZIP?

Check the package without downloading validates and previews planned output. Create and download ZIP builds the selected bundle in your browser and requests its download. Checking does not use export allowance. Review the brief, constraints, supporting files, and selected options before choosing the action.

### Can I get the ZIP directly or after a review?

Yes. Choose Create and download ZIP from review when you are ready. Checking first is optional. Check the current summary and selected files, especially after changing your answers.

### How do I know the ZIP was saved?

The result shows the bundle filename and output manifest. A download request is not proof that your browser saved the file. Check Downloads or your device's Files app, open the ZIP, and inspect its contents. If a download is blocked, check browser download settings before deliberately requesting it again.

### Does the web app write into an existing project or run commands?

No. It exports a ZIP and may include setup instructions for you to review and run separately. It does not operate your filesystem, Git, GitHub CLI, IDE, or local AI tools. When extracting a ZIP, you control the destination and overwrite prompts from your extraction tool. Browser export cannot protect files you later replace manually.

### Are my source files changed?

No. Selected source files are read for the requested bundle and remain unchanged. For repository or combined output, attachments are included under docs/product/sources/. Duplicate archive names are resolved deterministically. Review the manifest for the files included in your selected output.

## Drafts, files, and privacy

### What is saved in the browser?

When local saving succeeds, this browser keeps one draft bound to the verified account and session, with answers, project and participant names, options, position, and selected-file count. Selected file names and bytes are not retained in that draft. Follow the saving status shown in the builder; a draft is a convenience, not a backup. Keep important work outside the browser before closing or clearing it.

### What happens after a reload or on another device?

The draft can restore answers in the same browser and site only after verifying the matching account and session. Select source files again after reload. Signing out, deleting or changing an account clears the current site draft, selected-file references and prepared ZIP. A later sign-in starts a new blank draft. Previously downloaded files remain under your control. Cookie preferences, introduction completion and account allowance are independent; clearing a draft or signing out does not reset that allowance. Older drafts without account ownership are discarded. Another browser, device, private session, or preview URL has separate storage and will not receive your draft. Clearing site data, browser eviction, or New draft can remove it. There is no server copy of your project to restore.

### Can I retain a draft through a full-page sign-in check?

Same-owner reauthentication can retain a saved draft through OAuth with a one-use sessionStorage marker, `accreatio:draft-oauth-handoff:v1`, valid for at most ten minutes. It contains only opaque account/session labels and expiry, not project data or credentials. It is created only after saving a known-session draft before redirect, and used only after a successful return and verification of the same owner. Invalid, expired or unreadable/unremovable markers are rejected. Each new sign-in first removes and confirms the absence of any previous marker. Sign out or account change clears it; a draft cleared by explicit sign out is not restored. Prepared ZIPs and selected files still need to be recreated or selected again after navigation.

### Are my project or files uploaded?

Project definition and attachment processing happen on your device. The editorial backend does not receive project fields, attachments, ZIPs, local paths, or GitHub, IDE, or AI-provider credentials. This does not mean the website has no network activity: Cloudflare serves and protects the site and processes request and authentication/security metadata. The public Blog retrieves published editorial posts; only administrators can publish them. See the Privacy Policy for that distinction.

The separate account service retains the account data described in the Privacy Policy; accounts are not local. If you later share your ZIP with an assistant or another service, that service's terms and controls apply.

### Which files and sizes are supported?

Only DOCX, PDF, PNG, and JPEG are supported, up to 20 files, 20 MiB each, and 100 MiB total per operation. Audio, video, archives, executables, scripts, and macro-enabled Office formats are excluded. A device with limited memory may struggle before reaching these application limits.

### Does accreatio interpret documents or check them for malware?

Attachments are parsed locally to enforce structure and active-content limits, then reconstructed before export. They are not executed, summarized by AI or certified free of malware. Select only files you have authority to use and inspect received files with appropriate tools before opening them elsewhere.

### Can I use it on mobile or offline?

The layout adapts to narrow screens and touch input. File selection, ZIP downloads, memory, and installation options depend on the mobile browser and device. Use Files or Downloads to inspect exports. Desktop installation is not required; the desktop prototype was never released and will never be released.

The web builder needs a connection to verify your signed-in session. During temporary suspension, unavailable/offline session verification or reauthentication, the builder stays locked and clears its prepared ZIP and retry information from memory. The saved draft stays hidden and can resume only after the same owner is verified again. Explicit sign out, account deletion or an account change discards that draft.

### Can I choose a language or light theme?

The matte pearl theme is the default; choose the optional soft dark theme with the theme control. Switch between Spanish and English with the language control. Public links carry `lang=es` or `lang=en` so direct navigation and reload preserve that language.

## AI, Blog, and help

### Does Mode 1 run AI or charge an API?

No. Basic preparation does not require orchestration. Optional orchestration instructions prepare a reviewable configuration for separate local tools and require later configuration on your machine. Inspect those instructions before running them. The web app cannot verify local installation or sign-in and does not invoke or supervise agents. Any assistant you later choose has its own terms, availability, and costs.

### Is the Blog part of my project storage?

No. Anyone can read published Blog posts without signing in. Only server-authorized administrators can publish; a project account does not grant publishing permission. Editorial posts persist separately in D1. The current interface is append-only, without post editing, deletion, scheduling, media uploads, or backdating. AI-authored editorial collaborations carry provenance and do not represent a hosted AI feature or corporate statements by OpenAI or Anthropic.

### Does a generated plan certify my project?

No. Templates and plans are engineering aids. Review them for your actual engineering, security, legal, licensing, and compliance needs before use. Generated instructions require your independent decision before execution.

### Can I use the exported templates commercially or deliver them to a client?

The included reusable AEKR templates carry the MIT notice in `LICENSES/AEKR-TEMPLATES.txt`, preserved from AEKR's `LICENSE-CODE`. That notice permits use, modification, redistribution, and sale while preserving its copyright and permission notice. You retain the rights you already hold in your own material. This does not license accreatio application code, transfer its branding rights, or clear your third-party inputs. Review the bundle's notices, personal information, secrets, and confidentiality obligations before sharing it.

### How do I use the shared sign-in verification?

Choose Verify to continue once, complete the Cloudflare Turnstile challenge, then choose Google or GitHub. Both buttons use that same verification. If it expires or an attempt fails, verify again before retrying. This verification does not accept the Terms or authorize account processing; the provider continuation action beside the visible notice does that. Own-data access and deletion use separate identity checks. Provider data and export allowance are described in the Terms.

### Where are the step-by-step tips?

After signing in, use the lowercase help link below the lower-left corner of the current project module. Its popup starts with tips for that module, and follows the current step. Move between images with the previous/next controls at the sides; close the popup to continue filling the same screen. About opens a floating panel containing the updated FAQ, the full illustrated guide, Privacy and Terms links. Opening it keeps your current project screen and answers in place. Before signing in, the See an example link on the welcome screen opens the floating walkthrough.

### Where can I get help or report a problem?

Use the floating About panel for the FAQ, full guide and links to Terms and Privacy. The footer also links the Terms. Contact AEKR at aekr@aekr.io for access, privacy, security, or editorial concerns. Include a brief description and browser/device details when useful. Do not send credentials, access tokens, or project attachments merely to report a UI problem.

## Preguntas frecuentes — resumen en español

### ¿Qué crea y cómo se usa?

accreatio prepara un inicio estructurado y un ZIP; no construye el producto ni ejecuta agentes. El nombre admite 50 caracteres. Idea/contexto admite hasta 20.000 unidades UTF-16, restricciones hasta 10.000 y cada tarea de participante hasta 5.000. Se usa el conteo del textarea de JavaScript; algunos emoji cuentan como dos unidades. Puedes volver y revisar respuestas antes de confirmar. En la web se eligen de uno a cuatro roles únicos: Generalist, Architect, Implementer y Auditor. Los participantes del resumen son parte del plan, no agentes en ejecución.

### ¿Puedo exportar sin dry review?

Sí. En la revisión puedes elegir Crear y descargar ZIP cuando estés listo; comprobar primero es opcional y no consume cuota. Comprueba Descargas o Archivos y abre el ZIP: solicitar la descarga no prueba que se haya guardado. Extráelo, abre la carpeta en tu editor y sigue START.md. Antes de iniciar sesión, el enlace Ver un ejemplo de la bienvenida abre el flujo completo en una guía flotante con imágenes 4K, textos paso a paso y controles anterior/siguiente en los lados; el ejemplo ficticio no modifica tu borrador.

### ¿Qué conserva el borrador?

Cuando el guardado local funciona, el navegador conserva un borrador vinculado a la cuenta y sesión verificadas, con respuestas, nombres de proyecto y participantes, opciones, posición y cantidad de adjuntos. No conserva nombres ni bytes de los archivos: debes seleccionarlos otra vez tras recargar. Sólo se restaura tras verificar la misma cuenta y sesión. Cerrar sesión, eliminar o cambiar la cuenta borra el borrador actual del sitio, las referencias a archivos seleccionados y el ZIP preparado. El siguiente acceso comienza un borrador nuevo vacío. No borra archivos ya descargados. Preferencias de cookies, introducción y cuota de cuenta son independientes; borrar un borrador o cerrar sesión no reinicia esa cuota. Se descartan borradores antiguos sin propietario. Consulta el estado de guardado del creador; el borrador no es una copia de seguridad. Otro navegador, dispositivo o URL de preview tiene almacenamiento separado. Nuevo borrador o borrar datos del sitio puede eliminarlo; no existe una copia del proyecto en el servidor.

### ¿Puedo conservar el borrador al verificar de nuevo el acceso?

La reautenticación del mismo propietario puede conservar un borrador guardado mediante un marcador de sessionStorage, `accreatio:draft-oauth-handoff:v1`, de un uso y válido como máximo diez minutos. Sólo contiene etiquetas opacas de cuenta/sesión y caducidad, sin datos del proyecto ni credenciales. Se crea tras guardar el borrador de una sesión conocida y antes de redirigir a OAuth; sólo se usa tras un retorno exitoso y verificar al mismo propietario. Se rechazan marcadores inválidos, caducados o cuya lectura/borrado no se confirme. Cada nuevo acceso elimina primero y confirma la ausencia del marcador anterior. Cerrar sesión o cambiar de cuenta lo borra; no se restaura un borrador eliminado por cierre explícito. Tras navegar hay que volver a preparar el ZIP y seleccionar los archivos.

### ¿Qué ocurre con mis documentos?

Los archivos se procesan localmente y no se suben al backend editorial. Se admiten hasta 20 archivos, 20 MiB por archivo y 100 MiB en total: DOCX, PDF, PNG y JPEG. Su estructura y funciones activas se comprueban localmente y los archivos se reconstruyen antes de exportar; esto no certifica ausencia de malware. Las fuentes originales no se modifican. Al extraer el ZIP, tú controlas el destino y cualquier reemplazo. Si después lo entregas a otro asistente o servicio, se aplican sus condiciones y controles.

### ¿Hay cuentas, AI o datos en la nube?

Inicia sesión para preparar tu proyecto. La pantalla de acceso muestra los métodos habilitados en este entorno; la FAQ de About enumera los proveedores confirmados por el servidor cuando están disponibles. No se exige un código por correo si ese método está deshabilitado. About, el ejemplo y el Blog son públicos. El servicio de cuenta separado autoriza cinco exportaciones nuevas por cuenta en cualquier periodo móvil de 24 horas, compartido entre sesiones y dispositivos; no se reinicia a medianoche. Editar y comprobar no consume cuota. Puedes reintentar la misma exportación autorizada durante 48 horas sin consumir otra, mientras su ZIP siga disponible en esta pestaña. El menú permite descargar tus datos de cuenta y eliminarla; consulta [privacidad](PRIVACY_POLICY.md). La cuenta no es local; el contenido del proyecto se procesa en este navegador.

### ¿Funciona en el teléfono y sin conexión?

La interfaz se adapta a pantallas estrechas y al tacto. Adjuntos, memoria, descargas e instalación dependen del dispositivo y navegador. El creador necesita conexión para verificar tu sesión. Durante una suspensión temporal, verificación de sesión no disponible/sin conexión o reautenticación, el creador permanece bloqueado y borra de memoria el ZIP preparado y su reintento. El borrador guardado queda oculto y sólo puede retomarse al verificar de nuevo al mismo propietario. Cerrar sesión explícitamente, eliminar o cambiar la cuenta descarta ese borrador. El tema perla es el predeterminado; oscuro es opcional. Los enlaces públicos conservan español o inglés con lang=es o lang=en al recargar. El prototipo de escritorio es obsoleto, nunca fue ni será publicado.

### ¿Cómo uso la verificación compartida?

Pulsa Verificar para continuar una vez, completa el desafío de Cloudflare Turnstile y elige Google o GitHub; ambos botones comparten esa verificación. Si vence o un intento falla, verifica de nuevo antes de reintentar. El desafío no acepta condiciones ni autoriza datos de cuenta: esa decisión corresponde a continuar con el proveedor junto al aviso visible. El acceso a datos propios y el borrado conservan su prueba de identidad separada. Los datos de proveedor y la cuota se explican en los Términos.

### ¿Dónde encuentro ayuda y condiciones?

Tras iniciar sesión, los módulos del proyecto tienen un enlace ayuda en minúscula debajo de su esquina inferior izquierda. Abre un popup de tips del módulo actual y acompaña el paso en que estás. Cambia de imagen con los controles anterior/siguiente de los lados y ciérralo para seguir en la misma pantalla. About abre un panel flotante con la FAQ actualizada, la guía ilustrada completa y enlaces a Privacy y ToS, conservando la pantalla y tus respuestas. Antes del acceso, el enlace Ver un ejemplo de la bienvenida abre la guía flotante. Los Términos también están en el footer. Para acceso, privacidad, seguridad o publicaciones, escribe a AEKR: aekr@aekr.io. No envíes credenciales ni archivos innecesarios. Los planes no sustituyen una revisión profesional. Las publicaciones del Blog se pueden leer sin iniciar sesión. Sólo el administrador puede publicar; una cuenta de proyectos no concede ese permiso.

### ¿Puedo usar las plantillas exportadas comercialmente o entregarlas a clientes?

Las plantillas AEKR reutilizables incluidas llevan el aviso MIT en `LICENSES/AEKR-TEMPLATES.txt`, preservado de `LICENSE-CODE` de AEKR. Ese aviso permite uso, modificación, redistribución y venta conservando su copyright y aviso de permiso. Conservas los derechos que ya tienes sobre tu material. Esto no licencia el código de la aplicación accreatio, transfiere derechos de marca ni autoriza tus entradas de terceros. Revisa los avisos, datos personales, secretos y obligaciones de confidencialidad antes de compartir el paquete.


Attachment policy update, 2026-10-22: strict local content/structure inspection and reconstruction apply at selection and ZIP construction. Scripts, executables, SVG, archives, text, Markdown, JSON, YAML and CSV are not accepted as user attachments. Complex or unsupported features may be rejected. Original local files are not overwritten. Generated project documents/configuration and own-account exports are separate product outputs.
