# Legal-navigation language correction — 2026-10-25

Outcome: LOCAL_REGRESSION_VERIFIED

Delivery state: SOURCE_ONLY

Product state: CORRECTION_NOT_YET_OBSERVED_ON_CANONICAL_HOST

Gate/authority state: OWNER_AUTHORIZED_DIRECT_MAIN_DELIVERY / COORDINATOR_PUBLICATION_PENDING

## Cause and bounded correction

This correction starts at remote `main` `d191526f2a67b69249096d2601195a29ecb6ef7d`. It supplements the historical [presentation receipt](TOS_PRESENTATION_2026-10-25.md), which is preserved unchanged. Its statement about inheriting language from a same-origin referrer is superseded by this finding: the real global `Referrer-Policy: no-referrer` prevents that mechanism. The earlier isolated test supplied a referrer that the deployed policy would not send. Thus Spanish Terms → Privacy/Cookies/FAQ → their bare Terms link returned the English document.

The new external `public/legal/legal-navigation.js` propagates explicit `lang=en/es` to existing known legal-page and app-return links and selects the full matching Terms document. It is loaded by both Terms documents and by Privacy, Cookies and FAQ. `terms-language.js` now resolves only explicit query and document fallback, without reading or depending on a referrer. No security/privacy header is relaxed and no browser storage is introduced.

The application's existing links to Privacy/Cookies/FAQ also use the actual primary `locale` through `legalHref` in About, project information, sign-in, account menu, account continuation/renewal and Cookie preferences. This covers app ES → other legal page → Terms and chained legal hops. Existing query values and fragments are retained when the language parameter is added. External and email destinations retain their existing values.

All five legal HTML bodies remain byte-identical to the baseline; only their head script includes change. Privacy/Cookies/FAQ text, EN/ES Terms, canonical Terms sources, version labels, substantive operator/contact/reporting channels, acceptance/rights/optional-purpose mechanisms, CSP, the `no-referrer` policy, and PWA configuration remain unchanged. Terms remains `2026-10-25-acceptable-use`, Privacy `2026-10-22b-privacy`, and purpose `account-core-v1`. The earlier receipt is not normalized or rewritten.

## Verification

- **RED:** on the named baseline, two new regression checks execute the actual route scripts found in the actual HTML with an empty `document.referrer` on every hop. Spanish Terms → Privacy → Terms returns `en` instead of `es`; intermediate legal links/app return also lose the language. Log: `.local/logs/legal-navigation-no-referrer-red-20261025.log`.
- **GREEN:** 26/26 focused tests pass across `legalNavigation`, `termsPresentation`, `accountPolicy`, `about` and `webRelease`. The corrected regression executes real external route scripts and actual links from Privacy, Cookies and FAQ in both directions and both languages, including intermediate legal hops and app return. A rendered account-continuation notice proves its legal entrypoints carry the selected locale. Tests retain empty referrers, provide no storage, and assert the real header remains `no-referrer`. Log: `.local/logs/legal-navigation-no-referrer-green-20261025.log`.
- App typecheck/build, Functions typecheck and the 51-file publication gate pass. The generated worker still excludes all five legal HTML documents. Header, policy/version, PWA-config, canonical-Terms and historical-receipt diffs are empty. Independent byte comparison confirms all five legal HTML bodies are unchanged. The existing warning for chunks above 500 kB remains.
- Edited-file formatting and `git diff --check` pass. No full-suite or browser run is claimed. Local script/SSR/SQLite evidence does not establish hosted behavior or human acceptance.

Build/typecheck logs: `.local/logs/2026-10-25T16-59-50-478Z-build-web-76313612-fa7e-4f3d-9dd4-c3c8c191af36.log` and `.local/logs/2026-10-25T16-59-50-478Z-typecheck-functions-1f713a98-d8b0-429d-a004-22c273008c08.log`.

Writer `/root/tos_ui_accreatio` retains the coordinator's accepted explicit `fork_turns=none`, `model=gpt-6.1-sol`, `reasoning_effort=ultra` dispatch; runtime model telemetry was not measured. The separate reviewer `/root/tos_ui_review` reported this source finding. This receipt does not claim final immutable review, legal approval, security certification or hosted delivery.

## Publication boundary

This source correction uses direct `main` commit/push with `[skip ci]`; it performs no PR, Cloudflare operation, IAB interaction, real account action or deployment. The coordinator must publish the complete corrected build rather than the earlier 50-file ZIP, then verify EN/ES Terms → Privacy, Cookies and FAQ → Terms, app → those legal documents → Terms, inter-document hops, return to the app and refresh in fresh and updated prior clients. Hosted observation receives a separate receipt.
