# Prompt de discovery · accreatio · prevención de proyectos y material prohibidos

Trabaja en el repositorio canónico de accreatio. Esta orden autoriza **investigación y diseño**, no implementación, activación, suspensión de cuentas ni tratamiento de material real. El objetivo posterior será prevenir el uso de accreatio para proyectos maliciosos y contenido prohibido, preservando su utilidad y accesibilidad para profesionales independientes y personas con recursos limitados.

## 1. Autoridad, fuentes y baseline

Lee AGENTS, MASTER_SWITCH y el estado/read set vigente. Registra rama, HEAD, remoto, dirty state, release real y diferencias con la aplicación alojada. Conserva cambios ajenos y fuentes históricas; no reactives el desktop retirado. Lee el ToS publicado y su versión efectiva, la política de privacidad y los recibos de cuenta. No infieras aceptación nueva por abrir una sesión.

Consulta el paquete central de ToS del 25 de octubre de 2026 y vuelve a verificar sus fuentes oficiales cuando hagas este discovery. Distingue ley vigente, transición y aplicabilidad pendiente por país, rol y audiencia. No declares inmunidad jurídica o cumplimiento mundial. AEKR es un proyecto personal; no inventes una sociedad, elegibilidad de proveedor o un equipo de moderación.

## 2. Superficie real y fronteras

Traza los datos desde respuestas de definición, títulos, prompts, texto libre, nombres de archivo, adjuntos/importaciones y referencias hasta validación/previsualización, planes, paquetes ZIP y configuración para agentes. Identifica qué superficies existen hoy y cuáles no. Examina el modelo local de borradores, IndexedDB, almacenamiento de cuenta, Functions, autorización de exportación y límites de cuota sin abrir datos de usuarios.

Para cada salida, explica qué puede inspeccionarse localmente, qué llega al servidor y qué no es observable desde el servicio. Un control sólo cliente se puede eludir; una verificación de cuota de exportación no certifica el contenido de un ZIP generado en el dispositivo. No añadas un upload o receptor central para cerrar esa diferencia sin una decisión explícita y revisada de privacidad, necesidad, coste y arquitectura.

## 3. Taxonomía y contexto

Vincula cada regla a un apartado del ToS: pornografía/desnudez; fotografías de menores e imágenes reales o sintéticas que los representen, identificables o no, prohibidas por la regla propia del servicio; explotación sexual infantil y grooming; imágenes íntimas sin consentimiento/deepfakes abusivos; documentos robados, falsificados o sin derechos; odio dirigido, amenazas, violencia y maltrato animal; fraude, phishing, malware, robo de credenciales y acceso no autorizado a sitios, bancos, redes sociales, teléfonos, tarjetas, wallets y otros sistemas.

No confundas fotos ordinarias de menores con CSAM ni un término técnico con intención delictiva. Distingue ciberseguridad defensiva autorizada, formación legítima y análisis de riesgos de una instrucción para atacar a un tercero. Una etiqueta «educativo», una autodeclaración o un resultado de modelo no prueban autorización. Define el mínimo de evidencia de alcance permitido sin solicitar credenciales ni documentos privados innecesarios.

Por orden expresa adicional, accreatio tampoco admite prompts, planes, instrucciones, configuraciones para agentes o proyectos cuya finalidad sea producir vídeos generados por IA o AI slop, aunque la generación se ejecute después en otro servicio. Incluye creación o sustitución creativa mediante IA de escenas, personajes/avatares o voces del vídeo, sin un porcentaje mínimo ficticio y aunque el resultado tenga alta calidad. AI slop abarca producción generativa automatizada masiva, repetitiva, engañosa o spam. No se prohíbe por esa sola razón la orquestación legítima con IA ni la asistencia ordinaria de texto, subtítulos, recorte o plantillas sobre material real; determina finalidad y flujo efectivo, no una palabra clave o una valoración estética. Diseña evidencias mínimas de procedencia/intención y revisión de incertidumbre; un detector o autodeclaración no certifican origen ni justifican por sí solos una sanción definitiva.

## 4. Diseño de decisiones y puntos de control

Propón puntos de control en definición, edición/importación, preparación, previsualización y exportación, con revalidación del estado vigente al producir la salida. Define resultados tipados propuestos: permitido, corrección necesaria, revisión, restricción provisional de una acción y suspensión pendiente de revisión; reserva una sanción definitiva a evidencia y revisión competentes. Distingue indicio, infracción confirmada y cumplimiento de orden legal.

Diseña expiración, versión de política/modelo, revocación, concurrencia entre pestañas, cambios tras una revisión, idempotencia, fallos de red/proveedor y recuperación. Una detección fallida o sin servicio no debe mostrarse como aprobación del contenido; la respuesta segura debe ser proporcional a la acción y al riesgo. No inventes umbrales operativos, plazos de sanción o puntuaciones «certificadas».

## 5. Privacidad, personas y evidencia

Evalúa minimización, fundamento y transparencia por cada dato nuevo, acceso restringido, retención por finalidad, borrado y eventual preservación legal. No descargues, generes, dupliques ni envíes material sexual infantil o presuntamente ilegal a modelos, terceros, repositorios o revisores. Diseña reportes con identificador de decisión y metadatos mínimos; la preservación obligatoria, si aplica, requiere un protocolo jurídico y operativo separado.

Prepara aviso comprensible, motivos, corrección, apelación accesible, intervención humana real y restablecimiento. No bloquees exportaciones lícitas o derechos de datos de forma indiscriminada. Considera falsos positivos, idiomas, trabajo defensivo legítimo y efectos sobre personas con pocos recursos; no uses recursos, nacionalidad o características protegidas como señales sustitutivas de abuso.

## 6. Alternativas, coste y evaluación

Compara reglas deterministas, análisis local y proveedores de moderación disponibles con sus capacidades reales, licencias, acceso/admisión, retención, regiones, límites y costes. No selecciones automáticamente un proveedor pagado ni conviertas una suscripción de usuario en permiso de API. Evalúa texto y material multimodal sólo donde exista una vía de producto necesaria y autorizada.

Propón un corpus seguro y sintético de etiquetas/metadatos/textos benignos: pruebas de contexto, traducción, citas, evasión, archivos comprimidos, cambios de nombre, revocación y fallos. No uses material de víctimas ni payloads ofensivos operativos. Define precisión/recall por categoría, tasa de apelaciones y errores, carga humana y presupuesto; deja los valores pendientes de evaluación real. Diseña una fase de observación autorizada antes de restringir automáticamente y un mecanismo de apagado y reversión.

## Entregables y salida

Entrega un mapa de fuente/destino, gap analysis por cláusula, clasificación jurídica condicionada, ADR comparativo con costes, contratos y estados propuestos, proceso de revisión/apelación, plan de pruebas seguro y un backlog por etapas con prerrequisitos verificables. Incluye un prompt de implementación posterior acotado, con lista explícita de datos/decisiones pendientes. Separa hechos observados, propuestas y desconocidos. **No escribas el algoritmo, no despliegues y no suspendas usuarios en esta tarea de discovery.**
