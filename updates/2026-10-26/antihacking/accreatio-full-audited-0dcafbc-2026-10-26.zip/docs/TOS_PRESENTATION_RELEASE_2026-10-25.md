# Terms presentation publication — 2026-10-25

Outcome: DEPLOYED_AND_OBSERVED

Delivery state: REVIEWED_SOURCE_ON_MAIN / MANUAL_PAGES_SUCCESS / PUBLIC_READBACK_PASS

Product state: COMPLETE_SEPARATE_EN_ES_TERMS / PUBLIC_LABEL_VERSION_20261025

Gate/authority state: OWNER_AUTHORIZED_PRESENTATION_CORRECTION / NO_USER_ACCEPTANCE_CLAIM

This publication closes the separate source checkpoints [language presentation](TOS_PRESENTATION_2026-10-25.md), [legal navigation](TOS_LEGAL_NAVIGATION_FIX_2026-10-25.md) and [numeric public label](TOS_PUBLIC_VERSION_LABEL_2026-10-25.md). Those historical receipts retain their original scope and status.

## Published behavior

The two complete fourteen-clause documents are [English](https://accreatio.com/legal/terms?lang=en) and [Spanish](https://accreatio.com/legal/terms-es?lang=es). The application's existing principal language button selects the corresponding document at all five Terms entrypoints. There is no additional Terms language control and no Spanish summary inside the English document. Each document shows only **Version 20261025** as introductory metadata. Substantive operator, rights, report and appeal clauses remain in the body.

Explicit language parameters preserve the selection through Privacy, Cookies, FAQ, Terms and return to the application without browser storage or referrer dependence. The global `no-referrer` policy and CSP are retained. The prior legal-document precache/fallback correction remains in effect.

## Source, deployment and checks

- Final application source: `f1d9f98b5f85c4124716a55a26a4ea401e4d15b7`, delivered directly to main with `[skip ci]`.
- Final Pages deployment: `f3ebd202-0728-4455-83a5-8a8bd34d6ede`, exact source above, successful at `2026-10-25T17:20:41.910525Z`. The coordinator retried the existing skipped commit in the Cloudflare dashboard through the requested ChatGPT in-app browser. Automatic Git deployments remain paused; this order changed no provider settings, credentials/scopes, variables, bindings, DNS or billing.
- The preceding complete-language deployment `49031e9c-02cd-4c5b-9667-1d8eb9e6e70b` from `8062756defa3dc9cc2425e0ac3d07b3b900e5745` was observed before the owner's later numeric-label clarification. The final build differs from it only in the two Terms HTML files.
- Existing evidence records 26/26 focused tests, app/Functions types, build and the 51-file publication gate as passing. It covers localized entrypoints, both complete documents, real navigation scripts with empty referrers, deliberate account continuation and preserved own-data access. No full-suite rerun is claimed.
- Final HTTP readback at `2026-10-25T17:21:08.297Z`: twelve public documents/scripts/style assets exactly match source, including clean/explicit Terms routes, Privacy/Cookies/FAQ, both language scripts, worker and application JS/CSS. The main index retains the exact source shell/bootstrap plus Cloudflare's managed JavaScript-detection append; it is explicitly not reported as byte-identical. Anonymous account-session access remains 401. Legal headers retain revalidation and `no-referrer`.
- In-app-browser observation confirms both complete languages, fourteen headings each, only the numeric version label, no visible internal Terms identifier or checksum explanation, and selection through the principal language button. EN/ES legal-document chains, refresh and return to the Spanish application retain language. The prior controlled application required an online update/reload before its links reflected the new build. No browser storage was cleared.
- Separate Astra/ultra immutable-source reviews report zero open actionable findings after the navigation correction and public-label delta. Review read source and existing evidence; it did not repeat suites or the coordinator's hosted browser checks. Requested/accepted dispatch settings are recorded, without independent model-runtime telemetry or legal/security certification.

## Preserved boundaries and limits

The machine Terms identifier stays `2026-10-25-acceptable-use`; Privacy stays `2026-10-22b-privacy`; necessary purpose stays `account-core-v1`. The display label changes no account acknowledgment, consent, quota, data rights, optional choices, algorithm, provider or data schema. No actual customer agreement or account flow was completed by the coordinator.

Browser observation uses the integrated browser's actual desktop viewport. A requested narrow viewport override returned the desktop width; it is not counted as a hosted mobile test. Screenshots and route checks remain private coordinator evidence. Script/SQLite regressions and readback do not establish human UAT or universal immediate PWA adoption. Existing dependency-audit findings and the large-chunk advisory remain unchanged and outside this presentation correction.

This later closure is documentation-only; no application republish is needed for its commit. Product code and evidence stay in this repository; the coordinating repository adds a separate bounded delivery receipt.
