# accreatio Terms publication receipt — 2026-10-25

Outcome: DEPLOYED_AND_OBSERVED

Delivery state: REVIEWED_SOURCE_ON_MAIN / PAGES_SUCCESS / HOSTED_READBACK_PASS

Product state: EN_ES_TERMS_AND_LEGAL_CACHE_CORRECTION_PUBLISHED

Gate/authority state: OWNER_AUTHORIZED_PUBLICATION / ALGORITHMS_DISCOVERY_ONLY / NO_CUSTOMER_ACCEPTANCE_CLAIM

This closure supplements the historical [Terms candidate](TOS_HARDENING_2026-10-25.md) and [legal-cache candidate](LEGAL_DOCUMENT_DELIVERY_2026-10-25.md). Their pending-state statements describe their original checkpoints and are not rewritten. Structured evidence is in [the release receipt](evidence/tos-release-20261025.json).

## Source and actual publication

The final Terms candidate is `48294c95cbbed83b8ffb6a5c32c6f2cbef3e95e1`. After the owner's instruction to avoid Actions and use main directly, `04f837ccfcd37f9cd5bce1d70537ecabc9002230` published that source to main with `[skip ci]`. PR15 consequently appeared merged; no new Actions run was found for this commit. Earlier PR14/15 and CI history are retained.

The bounded cache correction is `a1adeed9d1ace02ca55bd1df23964e0c43534e59`, pushed directly to main with `[skip ci]`. The final manual Pages deployment is **`66ac8514-f503-4c86-95aa-a53e1c6afef8`**, from that exact source, successful at `2026-10-25T16:06:24Z`. No Actions run was found for this commit. This receipt is a later documentation-only addition and requires no application republish.

The existing CLI OAuth was valid but lacked Pages scope (403/code10000). Publication used the existing Cloudflare dashboard session in the owner's requested ChatGPT in-app browser. The existing Pages build command was blank; initial deployment `518d4897-29d0-44f4-a3b2-e31dab6757e4` failed resolving `openid-client`. Setting the command to `npm ci && npm run build:web`, while retaining output `dist`, produced successful initial Terms deployment `dde7e89b-0b4b-47f3-b646-920bc10a238c` and then the final cache-corrected deployment above. Automatic Git deployments remain paused. No credentials/scopes, variables, secrets, bindings, DNS or billing were changed by this publication operation.

## Hosted evidence

HTTP readback at `2026-10-25T16:10:30.199Z` matched generated source bytes for [canonical Terms](https://accreatio.com/legal/terms), the explicit `.html` alias, Privacy, Cookies and `sw.js`. Both Terms routes returned 200 and the exact 58,375-byte document, SHA-256 `baaf4f9d7847ec9fd9fe88dcc40eae665136f01b1249df30bf184a3a5c0c86ae`. Legal responses retain `public, max-age=0, must-revalidate, no-transform`; `sw.js` returned `max-age=14400`. The anonymous account-session endpoint returned 401. These checks do not prove authenticated account behavior or customer acceptance.

The existing installed PWA initially showed old Terms despite current origin bytes; an ordinary reload showed the current version. The final in-app-browser readback shows `2026-10-25-acceptable-use`, the EN/ES text and the Spanish exclusion of prompts/projects for AI-generated videos and AI slop. A screenshot was saved privately by the coordinator. No real Terms continuation, account deletion or content inspection occurred.

## Review and verification scope

The separately dispatched Astra/ultra reviewer found zero actionable findings in the final Terms candidate and, separately, in immutable cache commit `a1adeed9d1ace02ca55bd1df23964e0c43534e59`. Review read source, generated worker/artifacts and existing evidence; it did not rerun suites or independently observe the hosted site. The requested/accepted model setting is recorded, without independent model-runtime telemetry, legal approval or security certification.

The original 47 focused tests, account/rights synthetic browser checks, types/build and T19 follow-up 10-case account-policy suite are recorded in the Terms candidate receipt. The cache delta adds the real-worker RED/GREEN regression and 17 focused tests, types/build, 48-file artifact gate and surface checks described in its addendum. Among those 48 publication files only `sw.js` changes for the cache delta. Terms text/version, account receipt semantics, Privacy `2026-10-22b-privacy` and purpose `account-core-v1` stay unchanged by that delta. No full-suite rerun is claimed.

Earlier CI stopped at inherited npm-audit findings (1 low, 2 moderate, 4 high); manifests and lock are unchanged. This release does not claim green remote CI or resolve those dependency findings.

## Limits and future work

The replacement worker excludes legal HTML from precache and navigation-shell fallback; its local regression checks current and future network documents, stale-cache removal, fixture 404/503/offline responses and preservation of the unrelated offline shell. Those failure responses belong to the fixture, not to Cloudflare observations. An old controlling client may still need an online worker update and reload once. Immediate adoption by every open client is not claimed; no storage clearing or forced reload was introduced.

The discovery prompt is delivered, unexecuted, at [the canonical product path](discovery/ABUSE_PREVENTION_DISCOVERY_PROMPT_2026-10-25.md), SHA-256 `5cc8f09818c78a0e5614753c8b5ec72b3901ed16bb2f514944ec3915b67b8010`. No moderation/fraud algorithm, automatic content suspension, new provider or paid service is implemented or activated. Customer consent, data, identity and independent optional choices are not backfilled. The canonical sibling checkout's unrelated local files remain untouched. The release reduces contractual ambiguity; it does not establish worldwide legal compliance, immunity from claims or human UAT/acceptance.
