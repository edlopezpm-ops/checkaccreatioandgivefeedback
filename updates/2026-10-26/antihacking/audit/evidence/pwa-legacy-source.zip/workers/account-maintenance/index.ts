import {
  backfillEmails,
  maintainAccounts,
} from "../../functions/_lib/auth/privacy";
import type { AccountBindings } from "../../functions/_lib/accounts";
import { maintainAbuse } from "../../functions/_lib/abuse";

interface MaintenanceBindings extends AccountBindings {
  ACCOUNT_MAINTENANCE_ENABLED?: string;
}

export default {
  async scheduled(_controller: unknown, env: MaintenanceBindings) {
    if (env.ACCOUNT_MAINTENANCE_ENABLED !== "true") return;
    if (!env.ACCOUNT_DB) throw new Error("account_maintenance_unavailable");
    await maintainAccounts(env.ACCOUNT_DB);
    await maintainAbuse(env.ACCOUNT_DB);
    await backfillEmails(env);
  },
  fetch() {
    return new Response(null, {
      status: 404,
      headers: { "Cache-Control": "no-store" },
    });
  },
};
