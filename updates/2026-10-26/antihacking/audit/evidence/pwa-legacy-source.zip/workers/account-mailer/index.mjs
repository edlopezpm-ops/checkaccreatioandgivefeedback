// Only the account service may bind this Worker. It has no public ingress.
// Request bodies, recipients, OTPs and provider exceptions are never logged.
const MAX_BODY_BYTES = 1024;
const EMAIL_PATTERN =
  /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/i;
const CONTROL_PATTERN = /[\u0000-\u001f\u007f]/;

/** @param {unknown} value */
function validEmail(value) {
  return (
    typeof value === "string" &&
    value.length <= 254 &&
    !CONTROL_PATTERN.test(value) &&
    EMAIL_PATTERN.test(value) &&
    value.split("@")[0].length <= 64 &&
    !value.startsWith(".") &&
    !value.includes("..") &&
    !value.includes(".@")
  );
}

/** @param {unknown} recipient @param {Env} env */
function recipientAllowed(recipient, env) {
  // The public-recipient switch is separate from merely enabling the transport.
  // This application list contains only destinations verified in Cloudflare.
  if (env.ACCOUNT_MAILER_ALLOW_ARBITRARY_RECIPIENTS === "true") return true;
  if (typeof recipient !== "string") return false;
  try {
    const recipients = JSON.parse(env.ACCOUNT_MAILER_ALLOWED_RECIPIENTS);
    return (
      Array.isArray(recipients) &&
      recipients.length > 0 &&
      recipients.length <= 200 &&
      recipients.every(validEmail) &&
      recipients.some(
        (email) => email.toLowerCase() === recipient.toLowerCase(),
      )
    );
  } catch {
    return false;
  }
}

/** @param {string} value */
function escapeHtml(value) {
  return value.replace(/[&<>"']/g, (character) => {
    switch (character) {
      case "&":
        return "&amp;";
      case "<":
        return "&lt;";
      case ">":
        return "&gt;";
      case '"':
        return "&quot;";
      default:
        return "&#39;";
    }
  });
}

/** @param {Record<string, unknown>} body @param {number} status */
function json(body, status) {
  return Response.json(body, {
    status,
    headers: {
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
    },
  });
}

/** @param {Request} request @returns {Promise<unknown>} */
async function readPayload(request) {
  const reader = request.body?.getReader();
  if (!reader) throw new Error("invalid_body");
  const chunks = [];
  let bytes = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > MAX_BODY_BYTES) throw new Error("invalid_body");
      chunks.push(value);
    }
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
  const buffer = new Uint8Array(bytes);
  let offset = 0;
  for (const chunk of chunks) {
    buffer.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(buffer));
}

export default {
  /** @param {Request} request @param {Env} env */
  async fetch(request, env) {
    if (env.ACCOUNT_MAILER_ENABLED !== "true") {
      return json({ ok: false, error: "delivery_unavailable" }, 503);
    }
    const url = new URL(request.url);
    if (
      url.protocol !== "https:" ||
      url.hostname !== "account-mailer.internal" ||
      url.pathname !== "/otp" ||
      url.search ||
      request.headers.has("origin")
    ) {
      return json({ ok: false, error: "not_found" }, 404);
    }
    if (request.method !== "POST") {
      return json({ ok: false, error: "method_not_allowed" }, 405);
    }
    if (
      request.headers.get("content-type")?.split(";")[0].trim() !==
      "application/json"
    ) {
      return json({ ok: false, error: "invalid_body" }, 400);
    }
    let payload;
    try {
      payload = await readPayload(request);
    } catch {
      return json({ ok: false, error: "invalid_body" }, 400);
    }
    if (
      typeof payload !== "object" ||
      payload === null ||
      Array.isArray(payload) ||
      Object.keys(payload).some(
        (key) => !["email", "code", "expiresInMinutes"].includes(key),
      ) ||
      !("email" in payload) ||
      !validEmail(payload.email) ||
      !("code" in payload) ||
      typeof payload.code !== "string" ||
      !/^\d{6}$/.test(payload.code)
    ) {
      return json({ ok: false, error: "invalid_body" }, 400);
    }
    const expiresInMinutes =
      "expiresInMinutes" in payload ? payload.expiresInMinutes : 10;
    if (
      typeof expiresInMinutes !== "number" ||
      !Number.isInteger(expiresInMinutes) ||
      expiresInMinutes < 1 ||
      expiresInMinutes > 30
    ) {
      return json({ ok: false, error: "invalid_body" }, 400);
    }
    const sender = env.ACCOUNT_SENDER_EMAIL;
    const senderName = env.ACCOUNT_SENDER_NAME;
    if (
      !env.EMAIL ||
      typeof env.EMAIL.send !== "function" ||
      !validEmail(sender) ||
      !senderName ||
      senderName.length > 80 ||
      CONTROL_PATTERN.test(senderName)
    ) {
      return json({ ok: false, error: "delivery_unavailable" }, 503);
    }
    if (!recipientAllowed(payload.email, env)) {
      return json({ ok: false, error: "delivery_unavailable" }, 503);
    }
    // No remote assets, tracking pixels, links, attachments or arbitrary content.
    const text = `Tu código de acceso a accreatio es: ${payload.code}\n\nCaduca en ${expiresInMinutes} minutos y solo se puede usar una vez. No lo compartas.\n\nSi no solicitaste este código, puedes ignorar este correo.`;
    const html = `<!doctype html><html lang="es"><body><h1>${escapeHtml(senderName)}</h1><p>Tu código de acceso:</p><p style="font-size:32px;font-weight:bold;letter-spacing:6px">${payload.code}</p><p>Caduca en ${expiresInMinutes} minutos y solo se puede usar una vez. No lo compartas.</p><p>Si no solicitaste este código, puedes ignorar este correo.</p></body></html>`;
    try {
      await env.EMAIL.send({
        to: String(payload.email),
        from: { email: sender, name: senderName },
        subject: "Tu código de acceso a accreatio",
        text,
        html,
      });
    } catch {
      return json({ ok: false, error: "delivery_unavailable" }, 502);
    }
    // Accepted by the delivery provider. Inbox delivery is verified separately.
    return json({ ok: true }, 202);
  },
};
