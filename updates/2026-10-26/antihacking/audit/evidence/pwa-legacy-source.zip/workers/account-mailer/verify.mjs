import { spawnSync } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../../", import.meta.url));
const stamp = new Date().toISOString().replaceAll(/[:.]/g, "-");
const logDirectory = path.join(root, ".local/logs/otp", `mailer-${stamp}`);
mkdirSync(logDirectory, { recursive: true });
mkdirSync(path.join(root, ".local/cache/account-mailer"), { recursive: true });
const config = "workers/account-mailer/wrangler.jsonc";
const types = ".local/cache/account-mailer/worker-configuration.d.ts";
const wrangler = "node_modules/wrangler/bin/wrangler.js";
const checks = [
  ["tests", ["--test", "workers/account-mailer/mailer.test.mjs"]],
  [
    "types",
    [wrangler, "types", types, "--config", config, "--strict-vars=false"],
  ],
  [
    "typecheck",
    [
      "node_modules/typescript/bin/tsc",
      "--ignoreConfig",
      "--noEmit",
      "--allowJs",
      "--checkJs",
      "--strict",
      "--skipLibCheck",
      "--target",
      "ES2022",
      "--module",
      "ESNext",
      "--moduleResolution",
      "bundler",
      "workers/account-mailer/index.mjs",
      types,
    ],
  ],
  [
    "dry-run",
    [
      wrangler,
      "deploy",
      "--dry-run",
      "--config",
      config,
      "--outdir",
      "../../.local/cache/account-mailer/build",
    ],
  ],
];
for (const [name, args] of checks) {
  const result = spawnSync(process.execPath, args, {
    cwd: root,
    shell: false,
    windowsHide: true,
    encoding: "utf8",
    maxBuffer: 8 * 1024 * 1024,
    env: {
      ...process.env,
      WRANGLER_SEND_METRICS: "false",
      WRANGLER_LOG_PATH: path.join(root, ".local/logs/wrangler"),
    },
  });
  const logfile = path.join(logDirectory, `${name}.log`);
  writeFileSync(
    logfile,
    `${result.stdout ?? ""}${result.stderr ?? ""}\nExit: ${result.status ?? 1}\n`,
    { flag: "wx" },
  );
  console.log(
    `account-mailer ${name}: ${result.status === 0 ? "PASS" : "FAIL"} (${path.relative(root, logfile)})`,
  );
  if (result.status !== 0) {
    process.exitCode = result.status ?? 1;
    break;
  }
}
