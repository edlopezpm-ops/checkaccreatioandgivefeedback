# Private account email transport

`accreatio-account-mailer` delivers accreatio OTP messages through the existing Cloudflare Email Sending service. Pages does not support a `send_email` binding in Wrangler 4.119.0; the account Functions use an `ACCOUNT_MAILER` service binding to this Worker. It has no routes, Workers subdomain, preview URLs, API credentials, message store, or application logging.

The internal contract is `POST https://account-mailer.internal/otp`, `Content-Type: application/json`, with `{ "email": "recipient@example.com", "code": "123456", "expiresInMinutes": 10 }`. The code must have six digits. Expiry defaults to ten minutes and must be an integer between one and thirty. Only these fields are accepted; the account backend generates and hashes the code and enforces expiry, attempts, resend limits and send budgets. The transport limits bodies to 1 KiB and never accepts arbitrary subject, HTML, sender, multiple recipients or attachments.

`202 { "ok": true }` means the provider accepted the message, not proof of inbox delivery. Configuration and delivery failures return generic `503` or `502` responses without provider messages, email addresses or OTPs. Text and HTML include the code and expiry; the subject has no code and the message contains no links, external assets or tracking pixels.

`ACCOUNT_MAILER_ENABLED` defaults to `false`. Before enabling it, verify an authorized zero-cost sending path and perform a controlled inbox test. [Current Cloudflare pricing](https://developers.cloudflare.com/email-service/platform/pricing/) requires Workers Paid for arbitrary recipients, includes 3,000 messages per account and billing month, then charges $0.35 per 1,000. Verified destination addresses remain free on all plans. A daily sending limit is an abuse limit, not a billing cap; existing Email Sending enablement does not establish a free entitlement. Do not create a paid subscription or enable overage to deploy this component.

The default `ACCOUNT_MAILER_ALLOW_ARBITRARY_RECIPIENTS=false` allows delivery only to addresses in the JSON array secret `ACCOUNT_MAILER_ALLOWED_RECIPIENTS`. The operator must confirm each address is already verified in Cloudflare before adding it; the Worker does not call management APIs or verify addresses itself. Empty, absent, malformed or mismatched lists fail closed. Recipient lists never belong in the config, repository or logs. This restriction supports a free, controlled preview; it does not provide public sign-in for arbitrary email addresses. Enabling arbitrary recipients requires a separate explicit `ACCOUNT_MAILER_ALLOW_ARBITRARY_RECIPIENTS=true` deployment after entitlement and aggregate billing limits are proven.

The initial sender is **accreatio <aekr@aekr.io>**. For a future accreatio domain, change `ACCOUNT_SENDER_EMAIL`, `ACCOUNT_SENDER_NAME` and `send_email[].allowed_sender_addresses` together after onboarding that domain. [Cloudflare manages sender authentication](https://developers.cloudflare.com/email-service/concepts/email-authentication/) using SPF on `cf-bounce.<domain>` and DKIM under `cf-bounce._domainkey.<domain>`. Preserve existing Google Workspace apex MX and SPF records. Review existing DMARC policy and alignment without weakening it for deployment.

The Cloudflare sending-domain setting `preview_enabled` controls [message-body previews in the activity log](https://developers.cloudflare.com/api/resources/email_sending/), not beta access or free pricing. Disable provider message previews before production OTP traffic. The transport intentionally disables Worker observability to avoid retaining authentication activity; Cloudflare email infrastructure still processes recipients and delivery metadata according to its service retention.

Run local verification from the repository root:

```powershell
node workers/account-mailer/verify.mjs
```

This runs twelve behavior/security tests, generates the real Worker `Env` and runtime types into `.local/cache/account-mailer/`, typechecks the module in strict mode and bundles a Wrangler dry-run. Logs are uniquely written under `.local/logs/otp/`. It neither deploys nor sends real email.

Deployment is coordinated with the Pages account service. Keep `ACCOUNT_MAILER_ENABLED=false` until readiness is proven; add the service binding to the intended Pages environment explicitly. To stop new delivery, redeploy this Worker with `ACCOUNT_MAILER_ENABLED=false`. Existing account sessions and quota receipts remain in the separate account D1 database. Remove the Pages binding before deleting the Worker; never delete the account database to roll back delivery.
