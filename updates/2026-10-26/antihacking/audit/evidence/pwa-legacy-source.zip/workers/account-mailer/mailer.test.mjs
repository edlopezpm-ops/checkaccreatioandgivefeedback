import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { format } from "prettier";
import mailer from "./index.mjs";

const payload = {
  email: "owner@example.com",
  code: "103050",
  expiresInMinutes: 10,
};
const request = (body = payload, url = "https://account-mailer.internal/otp") =>
  new Request(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
const environment = (send) => ({
  ACCOUNT_MAILER_ENABLED: "true",
  ACCOUNT_MAILER_ALLOW_ARBITRARY_RECIPIENTS: "false",
  ACCOUNT_MAILER_ALLOWED_RECIPIENTS: '["owner@example.com"]',
  ACCOUNT_SENDER_EMAIL: "aekr@aekr.io",
  ACCOUNT_SENDER_NAME: "accreatio",
  EMAIL: { send },
});

test("sends one concise OTP without tracking, logs, or exposing the code in response", async () => {
  const calls = [];
  const response = await mailer.fetch(
    request(),
    environment(async (message) => calls.push(message)),
  );
  assert.equal(response.status, 202);
  assert.deepEqual(await response.json(), { ok: true });
  assert.equal(response.headers.get("cache-control"), "no-store");
  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0].from, { email: "aekr@aekr.io", name: "accreatio" });
  assert.equal(calls[0].to, payload.email);
  assert.match(calls[0].text, /103050/);
  assert.match(calls[0].text, /10 minutos/);
  assert.match(calls[0].html, /103050/);
  assert.doesNotMatch(calls[0].html, /https?:|src=|href=|<img/i);
  assert.doesNotMatch(calls[0].subject, /103050/);
  assert.equal(calls[0].attachments, undefined);
});

test("invalid payloads cannot trigger delivery or inject recipients or message content", async () => {
  let sends = 0;
  const env = environment(async () => sends++);
  for (const body of [
    null,
    [],
    {},
    { ...payload, code: "12345" },
    { ...payload, code: "<img>1" },
    { ...payload, email: "owner@example.com\r\nBcc:other@example.com" },
    { ...payload, email: ["owner@example.com"] },
    { ...payload, bcc: "other@example.com" },
    { ...payload, html: "custom" },
    { ...payload, expiresInMinutes: 0 },
    { ...payload, expiresInMinutes: 31 },
    { ...payload, expiresInMinutes: 1.5 },
    { ...payload, expiresInMinutes: "10" },
  ])
    assert.equal((await mailer.fetch(request(body), env)).status, 400);
  assert.equal(sends, 0);
});

test("an apostrophe accepted by account normalization remains deliverable", async () => {
  const email = "o'connor@example.test";
  let sends = 0;
  const env = environment(async (message) => {
    assert.equal(message.to, email);
    sends++;
  });
  env.ACCOUNT_MAILER_ALLOWED_RECIPIENTS = JSON.stringify([email]);
  assert.equal(
    (await mailer.fetch(request({ ...payload, email }), env)).status,
    202,
  );
  assert.equal(sends, 1);
});

test("body cap is enforced without trusting content-length", async () => {
  let sends = 0;
  const response = await mailer.fetch(
    request({ ...payload, email: "x".repeat(2048) }),
    environment(async () => sends++),
  );
  assert.equal(response.status, 400);
  assert.equal(sends, 0);
});

test("malformed JSON and content types are rejected before sending", async () => {
  const env = environment(async () => assert.fail("must not send"));
  const invalid = new Request("https://account-mailer.internal/otp", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: "{",
  });
  assert.equal((await mailer.fetch(invalid, env)).status, 400);
  const wrongType = new Request("https://account-mailer.internal/otp", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  assert.equal((await mailer.fetch(wrongType, env)).status, 400);
});

test("public hostnames, browser origin and other routes or methods are rejected", async () => {
  const env = environment(async () => assert.fail("must not send"));
  for (const url of [
    "https://mailer.workers.dev/otp",
    "https://account-mailer.internal/other",
    "https://account-mailer.internal/otp?code=123456",
    "http://account-mailer.internal/otp",
  ]) {
    assert.equal((await mailer.fetch(request(payload, url), env)).status, 404);
  }
  const browserRequest = request();
  browserRequest.headers.set("origin", "https://accreatio.com");
  assert.equal((await mailer.fetch(browserRequest, env)).status, 404);
  assert.equal(
    (
      await mailer.fetch(
        new Request("https://account-mailer.internal/otp"),
        env,
      )
    ).status,
    405,
  );
});

test("provider failures are sanitized and no successful delivery is reported", async () => {
  const response = await mailer.fetch(
    request(),
    environment(async () => {
      throw new Error("provider contains owner@example.com code103050");
    }),
  );
  assert.equal(response.status, 502);
  assert.deepEqual(await response.json(), {
    ok: false,
    error: "delivery_unavailable",
  });
});

test("sender remains configurable and invalid configuration fails closed", async () => {
  const env = environment(async (message) => {
    assert.deepEqual(message.from, {
      email: "account@accreatio.example",
      name: "accreatio <access>",
    });
    assert.match(message.html, /&lt;access&gt;/);
  });
  env.ACCOUNT_SENDER_EMAIL = "account@accreatio.example";
  env.ACCOUNT_SENDER_NAME = "accreatio <access>";
  assert.equal((await mailer.fetch(request(), env)).status, 202);
  env.ACCOUNT_SENDER_NAME = "bad\r\nBcc:other@example.com";
  assert.equal((await mailer.fetch(request(), env)).status, 503);
});

test("deployment keeps all public ingress disabled and only the approved sender", async () => {
  const config = JSON.parse(
    await format(
      await readFile(new URL("./wrangler.jsonc", import.meta.url), "utf8"),
      { parser: "json", trailingComma: "none" },
    ),
  );
  assert.equal(config.workers_dev, false);
  assert.equal(config.preview_urls, false);
  assert.deepEqual(config.routes, []);
  assert.equal(config.observability.enabled, false);
  assert.equal(config.vars.ACCOUNT_MAILER_ENABLED, "false");
  assert.equal(config.vars.ACCOUNT_MAILER_ALLOW_ARBITRARY_RECIPIENTS, "false");
  assert.deepEqual(config.secrets.required, [
    "ACCOUNT_MAILER_ALLOWED_RECIPIENTS",
  ]);
  assert.deepEqual(config.send_email, [
    { name: "EMAIL", allowed_sender_addresses: ["aekr@aekr.io"] },
  ]);
});

test("email delivery stays disabled until the zero-cost transport is explicitly enabled", async () => {
  const env = environment(async () => assert.fail("must not send"));
  env.ACCOUNT_MAILER_ENABLED = "false";
  assert.equal((await mailer.fetch(request(), env)).status, 503);
});

test("verified-recipient mode fails closed for absent, empty, invalid or mismatched lists", async () => {
  for (const recipients of [
    undefined,
    "",
    "[]",
    "[",
    "{}",
    '["other@example.com"]',
    '["owner@example.com", "invalid"]',
  ]) {
    const env = environment(async () => assert.fail("must not send"));
    env.ACCOUNT_MAILER_ALLOWED_RECIPIENTS = recipients;
    assert.equal((await mailer.fetch(request(), env)).status, 503);
  }
});

test("arbitrary-recipient delivery requires its own explicit switch", async () => {
  let sends = 0;
  const env = environment(async () => sends++);
  env.ACCOUNT_MAILER_ALLOWED_RECIPIENTS = "[]";
  for (const value of [undefined, "false", "TRUE", "yes"]) {
    env.ACCOUNT_MAILER_ALLOW_ARBITRARY_RECIPIENTS = value;
    assert.equal((await mailer.fetch(request(), env)).status, 503);
  }
  env.ACCOUNT_MAILER_ALLOW_ARBITRARY_RECIPIENTS = "true";
  assert.equal((await mailer.fetch(request(), env)).status, 202);
  assert.equal(sends, 1);
});
