# Third-Party Notices

accreatio uses open-source packages distributed through npm, including React, Electron, Vite, TypeScript, Lucide, and their transitive dependencies. Their copyrights and license texts are available in `node_modules/<package>/LICENSE*` and package metadata.

## Browser-rendered atmosphere

The atmosphere carries no third-party runtime dependency. Both of its layers are accreatio-owned code over native browser APIs: the procedural nebula is a first-party GLSL shader on the WebGL API (`src/components/nebula.ts`), and the deterministic star field uses Canvas2D (`src/components/StarField.tsx`). Neither introduces a package, remote asset, CDN script, hosted service, or paid cost.

DEC-018 removed the previous `vanta@0.5.24` and `three@0.185.1` runtime dependencies when the shader replaced them. Builds produced before that decision did bundle those MIT-licensed packages (Copyright 2020 Teng Bao; Copyright 2010–2026 three.js authors), and any redistributed artifact from that period still carries their notices.

## Visual references and marks

The ESA/Webb public nebula archive (`https://esawebb.org/images/archive/category/nebulae/`) informed high-level visual direction only. No ESA/Webb image, crop, pixel data, metadata, or derivative raster is distributed in accreatio.

The accreatio orbital-`a` mark and small AEKR signature are local vector implementations created for this owner-authorized project. The full AEKR build banner at `assets/aekr-banner.png` is an owner-supplied local raster used in repository documentation and embedded byte-for-byte in the self-contained Project Map; its copy-along MIT notice is `assets/AEKR-BANNER-LICENSE.txt`. These AEKR marks acknowledge the governed-build relationship; they do not reproduce private handbook content or assert certification/endorsement by a third party.

Before distributing builds outside the authorized private-use group, generate and review a complete dependency license report and software bill of materials. accreatio's private-use license does not replace or restrict third-party licenses.
