(() => {
  let theme = "light";
  try {
    if (localStorage.getItem("accreatio:theme") === "dark") theme = "dark";
  } catch {
    // Keep the pearl default when device storage is unavailable.
  }
  document.documentElement.dataset.theme = theme;
  document
    .querySelector('meta[name="theme-color"]')
    ?.setAttribute("content", theme === "dark" ? "#242726" : "#e8eae7");
})();
