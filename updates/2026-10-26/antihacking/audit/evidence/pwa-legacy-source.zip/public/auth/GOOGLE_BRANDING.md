# Google sign-in assets

Retrieved 2026-09-08 from Google's official sign-in branding resources:

- `google-g.png`: https://developers.google.com/static/identity/images/g-logo.png
- `google-sans-500.ttf`: Google Fonts CSS API, Google Sans Medium, subset containing only the characters used by "Continue with Google" and "Continuar con Google".

## Font license and copyright

The font is distributed under the **SIL Open Font License 1.1**, retained in full
as [OFL.txt](OFL.txt). The license text is copied from the `OFL.txt` returned by Google's
[Google Sans download manifest](https://fonts.google.com/download/list?family=Google%20Sans),
whose bundle name is `Google_Sans.zip`, with trailing whitespace normalized; it is not a license inferred from the
logo's branding guidelines. The font's own OpenType `name` table identifies the
following copyright notice and links to `https://openfontlicense.org`:

> Copyright 2025 The Google Sans Project Authors (github.com/googlefonts/googlesans)

OFL permits embedding, redistribution and modification subject to its conditions;
the bundled font and its subset remain under OFL, not the application's license.
The Google Fonts CSS `text` parameter produced this 5,388-byte subset. The font
binary was copied without local modification after that provider-side subsetting.
No Reserved Font Names are specified by the official project's
[license declaration](https://github.com/googlefonts/googlesans/tree/11978866b0e25153c8421deeb6fe907073dd1fdb#license).

## Logo and delivery

Use is restricted here to the sign-in button described by
https://developers.google.com/identity/branding-guidelines . Google brand assets
remain Google's trademarks; this file does not assign them the application's
license. The logo is copied unchanged. All assets are served locally; the page
does not load a Google font, identity SDK, tracking script or image remotely.
