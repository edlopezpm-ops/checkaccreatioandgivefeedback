import { authenticateAccess, authorizePublisher } from "../../../_lib/access";
import { ApiError, jsonResponse, methodNotAllowed } from "../../../_lib/http";
import type { AccountBindings } from "../../../_lib/accounts";
import { runtimeDependencies, type BlogBindings } from "../../../_lib/platform";
import { revealEmail, type EmailRecord } from "../../../_lib/auth/privacy";

// Separate administrative permission: ordinary project accounts cannot enumerate emails.
export async function handleEmailExport(
  context: {
    request: Request;
    env: AccountBindings & BlogBindings & { ACCOUNT_EMAIL_ADMINS?: string };
  },
  deps = runtimeDependencies(),
) {
  if (context.request.method !== "GET") return methodNotAllowed(["GET"]);
  try {
    const identity = await authenticateAccess(
      context.request,
      context.env,
      deps,
    );
    const actor = await authorizePublisher(
      identity,
      {
        BLOG_HUMAN_ADMINS: context.env.ACCOUNT_EMAIL_ADMINS,
        BLOG_AGENT_ADMINS: "{}",
      },
      deps,
    );
    if (actor?.kind !== "human")
      throw new ApiError(
        403,
        "owner_required",
        "An authorized human administrator is required.",
      );
    const db = context.env.ACCOUNT_DB;
    if (!db || context.env.ACCOUNT_ENABLED !== "true")
      throw new ApiError(
        503,
        "account_unavailable",
        "Account service is unavailable.",
      );
    const cursor = new URL(context.request.url).searchParams.get("after") ?? "";
    if (cursor !== "" && !/^[a-f0-9-]{36}$/.test(cursor))
      throw new ApiError(400, "invalid_cursor", "Invalid export cursor.");
    const result = await db
      .prepare(
        "SELECT id, email, email_ciphertext, email_encryption_key_version FROM accounts WHERE (email IS NOT NULL OR email_ciphertext IS NOT NULL) AND deleted_at IS NULL AND id > ? ORDER BY id LIMIT 501",
      )
      .bind(cursor)
      .all<EmailRecord>();
    if (!result.success || !result.results)
      throw new Error("database unavailable");
    const page = result.results.slice(0, 500);
    return jsonResponse(
      {
        emails: await Promise.all(
          page.map((row) => revealEmail(row, context.env, deps)),
        ),
        nextCursor: result.results.length > 500 ? page.at(-1)!.id : null,
      },
      200,
      {
        "Content-Disposition":
          'attachment; filename="accreatio-emails-page.json"',
      },
    );
  } catch (error) {
    return jsonResponse(
      {
        error: {
          code: error instanceof ApiError ? error.code : "account_unavailable",
        },
      },
      error instanceof ApiError ? error.status : 503,
    );
  }
}

export const onRequest = (context: Parameters<typeof handleEmailExport>[0]) =>
  handleEmailExport(context);
