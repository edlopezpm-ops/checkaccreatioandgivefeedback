import { handleOidc, type OidcContext } from "../../../../../_lib/auth/oidc";
export const onRequest = (context: OidcContext) =>
  handleOidc(context, "status");
