import { handlePublishPost } from "../../../_lib/handlers";
import type { BlogFunctionContext } from "../../../_lib/platform";

export const onRequest = (context: BlogFunctionContext) =>
  handlePublishPost(context);
