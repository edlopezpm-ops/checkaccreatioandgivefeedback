import { handleAdminSession } from "../../../_lib/handlers";
import type { BlogFunctionContext } from "../../../_lib/platform";

export const onRequest = (context: BlogFunctionContext) =>
  handleAdminSession(context);
