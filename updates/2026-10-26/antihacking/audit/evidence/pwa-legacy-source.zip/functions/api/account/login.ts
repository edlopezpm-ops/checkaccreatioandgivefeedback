import { handleAccount, type AccountBindings } from "../../_lib/accounts";

export const onRequest = (context: {
  request: Request;
  env: AccountBindings;
}) => handleAccount(context, "login");
