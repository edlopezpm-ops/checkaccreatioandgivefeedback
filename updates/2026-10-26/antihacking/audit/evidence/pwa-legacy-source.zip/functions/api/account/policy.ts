import { handleAccount } from "../../_lib/accounts";

export const onRequest = (context: Parameters<typeof handleAccount>[0]) =>
  handleAccount(context, "policy");
