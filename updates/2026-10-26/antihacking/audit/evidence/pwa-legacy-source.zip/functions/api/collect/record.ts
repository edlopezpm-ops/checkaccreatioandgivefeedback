import { handleCollection } from "../../_lib/collection";
export const onRequest = (context: Parameters<typeof handleCollection>[0]) =>
  handleCollection(context, "record");
