import {
  handleApiAdmission,
  type ApiAdmissionContext,
} from "../_lib/apiAdmission";

export const onRequest = (context: ApiAdmissionContext) =>
  handleApiAdmission(context);
