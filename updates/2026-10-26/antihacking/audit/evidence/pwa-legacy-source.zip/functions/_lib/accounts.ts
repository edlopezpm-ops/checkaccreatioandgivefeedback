import {
  ApiError,
  SECURITY_HEADERS,
  jsonResponse,
  methodNotAllowed,
  readBoundedJson,
} from "./http";
import { enforceAbuse, abuseErrorResponse, ABUSE_ALLOWED_SQL } from "./abuse";
import {
  runtimeDependencies,
  type BlogPreparedStatement,
  type RuntimeDependencies,
} from "./platform";
import {
  AUTH_RETENTION_MS,
  PRIVACY_NOTICE_VERSION,
  privacyConfigured,
  protectEmail,
  revealEmail,
  revealDisplayName,
  fallbackDisplayName,
  type EmailRecord,
} from "./auth/privacy";
import {
  CLEAR_TRANSACTION_POLICY_SQL,
  CURRENT_POLICY_SQL,
  POLICY_RECEIPT_COLUMNS,
  POLICY_UPSERT_SQL,
  TRANSACTION_POLICY_SQL,
  hasCurrentPolicyAuthorization,
  policyReceipt,
  requirePolicyAuthorization,
  type PolicyReceiptRow,
} from "./auth/policy";

export const ACCOUNT_WINDOW_MS = 86_400_000;
const RETENTION_MS = 2 * ACCOUNT_WINDOW_MS;
const SESSION_MS = ACCOUNT_WINDOW_MS;
const OTP_MS = 600_000;
const OTP_COOLDOWN_MS = 60_000;
const OTP_ATTEMPTS = 5;
const COOKIE = "__Host-accreatio_session";
const RIGHTS_COOKIE = "__Host-accreatio_rights";
const NOW_SQL = "(unixepoch() * 1000)";
const UUID =
  /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

export interface AccountDatabase {
  prepare(query: string): BlogPreparedStatement;
  batch(
    statements: BlogPreparedStatement[],
  ): Promise<readonly { success: boolean; results?: readonly unknown[] }[]>;
}
export interface AccountBindings {
  readonly COLLECT_ENABLED?: string;
  readonly API_ALLOWED_HOSTS?: string;
  readonly ACCOUNT_DB?: AccountDatabase;
  readonly ACCOUNT_IDENTITY_KEY?: string;
  readonly ACCOUNT_OTP_KEY?: string;
  readonly ACCOUNT_MAILER?: { fetch(request: Request): Promise<Response> };
  readonly ACCOUNT_MAX_ACCOUNTS?: string;
  readonly ACCOUNT_OTP_EMAIL_HOURLY?: string;
  readonly ACCOUNT_OTP_IP_HOURLY?: string;
  readonly ACCOUNT_OTP_GLOBAL_DAILY?: string;
  readonly ACCOUNT_ENABLED?: string;
  readonly ACCOUNT_ABUSE_ENABLED?: string;
  readonly ACCOUNT_OTP_ENABLED?: string;
  readonly ACCOUNT_OIDC_ENABLED?: string;
  readonly GOOGLE_CLIENT_ID?: string;
  readonly GOOGLE_CLIENT_SECRET?: string;
  readonly GOOGLE_REDIRECT_URI?: string;
  readonly ACCOUNT_GITHUB_ENABLED?: string;
  readonly GITHUB_CLIENT_ID?: string;
  readonly GITHUB_CLIENT_SECRET?: string;
  readonly GITHUB_REDIRECT_URI?: string;
  readonly ACCOUNT_OIDC_TRANSACTION_KEY?: string;
  readonly ACCOUNT_OIDC_IP_HOURLY?: string;
  readonly ACCOUNT_OIDC_GLOBAL_HOURLY?: string;
  readonly ACCOUNT_EMAIL_ENCRYPTION_KEY?: string;
  readonly ACCOUNT_EMAIL_LOOKUP_KEY?: string;
  readonly ACCOUNT_AUTH_LOCATOR_KEY?: string;
}
interface AccountRow {
  id: string;
  email: string;
  displayName: string;
  identity_key: string;
  email_lookup_key?: string | null;
  security_version: number;
  authenticated_at?: number | null;
  tokenHash: string;
  sessionExpiresAt?: number;
}
interface QuotaRow {
  used: number;
  oldest: number | null;
}

// A single conditional write makes count+admission indivisible, including
// different sessions/devices. Database time, never the request clock, owns it.
export const AUTHORIZE_SQL = `INSERT INTO export_authorizations (account_id, operation_id, issued_at)
 SELECT ?, ?, ${NOW_SQL}
 WHERE EXISTS (SELECT 1 FROM accounts WHERE id = ? AND deleted_at IS NULL
   AND EXISTS(SELECT 1 FROM account_policy_authorizations WHERE account_id=accounts.id AND ${CURRENT_POLICY_SQL}))
 AND (SELECT COUNT(*) FROM export_authorizations
      WHERE account_id = ? AND issued_at > ${NOW_SQL} - ${ACCOUNT_WINDOW_MS}) < 5
 ON CONFLICT(account_id, operation_id) DO NOTHING`;

const fail = (status: number, code: string, message: string): never => {
  throw new ApiError(status, code, message);
};
const dbFor = (env: AccountBindings) => {
  if (
    env.ACCOUNT_ENABLED !== "true" ||
    !env.ACCOUNT_DB ||
    !env.ACCOUNT_IDENTITY_KEY ||
    env.ACCOUNT_IDENTITY_KEY.length < 43
  )
    return fail(
      503,
      "account_unavailable",
      "Account service is temporarily unavailable.",
    );
  return env.ACCOUNT_DB;
};
const hex = (bytes: ArrayBuffer) =>
  Array.from(new Uint8Array(bytes), (b) =>
    b.toString(16).padStart(2, "0"),
  ).join("");
const digest = async (value: string, dependencies: RuntimeDependencies) =>
  hex(
    await dependencies.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(value),
    ),
  );

async function emailIdentity(
  email: string,
  env: AccountBindings,
  dependencies: RuntimeDependencies,
) {
  // Preserve the existing Access-era normalization and identity HMAC exactly.
  return {
    email,
    key: await hmac(env.ACCOUNT_IDENTITY_KEY!, email, dependencies),
  };
}

async function hmac(
  secret: string,
  value: string,
  dependencies: RuntimeDependencies,
) {
  const key = await dependencies.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return hex(
    await dependencies.subtle.sign(
      "HMAC",
      key,
      new TextEncoder().encode(value),
    ),
  );
}

async function localWorkKeys(
  accountId: string,
  tokenHash: string,
  env: AccountBindings,
  dependencies: RuntimeDependencies,
) {
  // Purpose-separated local ownership markers, never account credentials.
  const [ownerKey, sessionKey] = await Promise.all([
    hmac(
      env.ACCOUNT_IDENTITY_KEY!,
      JSON.stringify(["accreatio.local-owner.v1", accountId]),
      dependencies,
    ),
    hmac(
      env.ACCOUNT_IDENTITY_KEY!,
      JSON.stringify(["accreatio.local-session.v1", tokenHash]),
      dependencies,
    ),
  ]);
  return { ownerKey: `v1:${ownerKey}`, sessionKey: `v1:${sessionKey}` };
}

function requireOrigin(request: Request) {
  if (
    request.headers.get("Origin") !== new URL(request.url).origin ||
    (request.headers.has("Sec-Fetch-Site") &&
      request.headers.get("Sec-Fetch-Site") !== "same-origin")
  )
    fail(403, "invalid_origin", "Use accreatio to complete this action.");
}
const cookie = (token: string, maxAge: number) =>
  `${COOKIE}=${token}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${maxAge}`;
function readToken(request: Request, cookieName = COOKIE) {
  const matches = (request.headers.get("Cookie") ?? "")
    .split(";")
    .map((v) => v.trim())
    .filter((v) => v.startsWith(`${cookieName}=`));
  if (matches.length !== 1) return null;
  const token = matches[0].slice(cookieName.length + 1);
  return /^[a-f0-9]{64}$/.test(token) ? token : null;
}
async function findSession(
  request: Request,
  db: AccountDatabase,
  dependencies: RuntimeDependencies,
  env: AccountBindings,
  rightsOnly = false,
) {
  const token = readToken(request, rightsOnly ? RIGHTS_COOKIE : COOKIE);
  if (!token) return null;
  const tokenHash = await digest(token, dependencies);
  const row = await db
    .prepare(
      `SELECT a.id, a.email, a.email_ciphertext, a.email_encryption_key_version, a.display_name_ciphertext, a.email_lookup_key, a.identity_key, a.security_version, m.authenticated_at, s.expires_at AS sessionExpiresAt FROM account_sessions s
    JOIN accounts a ON a.id = s.account_id
    LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash
    WHERE s.token_hash = ? AND s.expires_at > ${NOW_SQL}
    AND a.deleted_at IS NULL AND (m.token_hash IS NULL OR m.security_version=a.security_version)
    AND COALESCE(m.rights_only,0)=?`,
    )
    .bind(tokenHash, rightsOnly ? 1 : 0)
    .first<AccountRow & EmailRecord>();
  if (!row) return null;
  const email = (await revealEmail(row, env, dependencies)) ?? "";
  return {
    ...row,
    email,
    displayName:
      (await revealDisplayName(row, env, dependencies)) ??
      fallbackDisplayName(email),
    tokenHash,
  };
}
async function quota(db: AccountDatabase, accountId: string) {
  const row = await db
    .prepare(
      `SELECT COUNT(*) AS used, MIN(issued_at) AS oldest FROM export_authorizations
    WHERE account_id = ? AND issued_at > ${NOW_SQL} - ?`,
    )
    .bind(accountId, ACCOUNT_WINDOW_MS)
    .first<QuotaRow>();
  if (!row)
    return fail(
      503,
      "quota_unavailable",
      "Export availability could not be checked.",
    );
  return {
    remaining: Math.max(0, 5 - row.used),
    nextAvailableAt:
      row.used >= 5 && row.oldest !== null
        ? new Date(row.oldest + ACCOUNT_WINDOW_MS).toISOString()
        : null,
  };
}
async function cleanup(db: AccountDatabase) {
  // Bounded, indexed work. No full-table sweep or per-request account scan.
  const results = await db.batch([
    db.prepare(`DELETE FROM account_sessions WHERE token_hash IN
      (SELECT token_hash FROM account_sessions WHERE expires_at <= ${NOW_SQL} LIMIT 100)`),
    db.prepare(`DELETE FROM export_authorizations WHERE rowid IN
      (SELECT rowid FROM export_authorizations WHERE issued_at <= ${NOW_SQL} - ${RETENTION_MS} LIMIT 100)`),
    db.prepare(`DELETE FROM accounts WHERE id IN
      (SELECT id FROM accounts WHERE deleted_at IS NOT NULL AND deleted_at <= ${NOW_SQL} - ${RETENTION_MS} LIMIT 100)`),
    db.prepare(`UPDATE account_otp_challenges SET email = NULL, verifier = NULL,${CLEAR_TRANSACTION_POLICY_SQL}
      WHERE id IN (SELECT id FROM account_otp_challenges
        WHERE expires_at <= ${NOW_SQL} AND (email IS NOT NULL OR verifier IS NOT NULL) LIMIT 100)`),
    db.prepare(`DELETE FROM account_otp_challenges WHERE id IN
      (SELECT id FROM account_otp_challenges WHERE created_at <= ${NOW_SQL} - ${RETENTION_MS} LIMIT 100)`),
  ]);
  if (results.some((r) => !r.success))
    fail(
      503,
      "account_unavailable",
      "Account service is temporarily unavailable.",
    );
}

function configuredLimit(
  value: string | undefined,
  fallback: number,
  maximum: number,
) {
  if (value === undefined) return fallback;
  if (!/^[1-9]\d*$/.test(value) || Number(value) > maximum)
    return fail(
      503,
      "account_unavailable",
      "Account service is temporarily unavailable.",
    );
  return Number(value);
}

function otpSettings(env: AccountBindings) {
  if (
    env.ACCOUNT_OTP_ENABLED === "false" ||
    !env.ACCOUNT_OTP_KEY ||
    env.ACCOUNT_OTP_KEY.length < 43 ||
    env.ACCOUNT_OTP_KEY === env.ACCOUNT_IDENTITY_KEY ||
    !env.ACCOUNT_MAILER
  )
    return fail(
      503,
      "otp_delivery_unavailable",
      "Email sign-in is temporarily unavailable. Please try again later.",
    );
  return {
    secret: env.ACCOUNT_OTP_KEY,
    mailer: env.ACCOUNT_MAILER,
    emailHourly: configuredLimit(env.ACCOUNT_OTP_EMAIL_HOURLY, 5, 10),
    ipHourly: configuredLimit(env.ACCOUNT_OTP_IP_HOURLY, 20, 100),
    globalDaily: configuredLimit(env.ACCOUNT_OTP_GLOBAL_DAILY, 90, 100),
    accounts: configuredLimit(env.ACCOUNT_MAX_ACCOUNTS, 1000, 100000),
  };
}

async function requireOtpPrivacy(env: AccountBindings, db: AccountDatabase) {
  if (privacyConfigured(env)) return;
  // The legacy plaintext path exists only for unmigrated legacy fixtures/stores.
  // Missing keys must never downgrade an already encrypted/federated store.
  if (
    env.ACCOUNT_EMAIL_ENCRYPTION_KEY ||
    env.ACCOUNT_EMAIL_LOOKUP_KEY ||
    env.ACCOUNT_AUTH_LOCATOR_KEY ||
    env.ACCOUNT_OIDC_ENABLED === "true" ||
    (await db
      .prepare(
        "SELECT 1 FROM accounts WHERE email_ciphertext IS NOT NULL OR identity_scheme='federated-v1' LIMIT 1",
      )
      .first())
  ) {
    fail(
      503,
      "account_unavailable",
      "Account service is temporarily unavailable.",
    );
  }
}

function normalizeEmail(value: unknown) {
  if (typeof value !== "string")
    return fail(400, "invalid_email", "Enter a valid email address.");
  const email = value.trim().toLowerCase();
  // ASCII mailbox subset; rejects controls, header injection and ambiguous names.
  // Normalization is identical to the prior verified Access email identity.
  if (
    email.length > 254 ||
    !/^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/.test(
      email,
    ) ||
    email.split("@")[0].length > 64 ||
    email.startsWith(".") ||
    email.includes("..") ||
    email.includes(".@")
  )
    return fail(400, "invalid_email", "Enter a valid email address.");
  return email;
}

function exactBody(
  body: unknown,
  keys: readonly string[],
): body is Record<string, unknown> {
  return (
    !!body &&
    typeof body === "object" &&
    !Array.isArray(body) &&
    Object.keys(body).length === keys.length &&
    keys.every((key) => Object.hasOwn(body, key))
  );
}

async function readAccountJson(request: Request, maximumBytes: number) {
  try {
    return await readBoundedJson(request, maximumBytes);
  } catch (error) {
    // The shared parser originated in Blog; account errors remain product-specific.
    if (error instanceof ApiError && error.code === "payload_too_large")
      return fail(413, error.code, "This account request is too large.");
    if (error instanceof ApiError && error.code === "empty_body")
      return fail(400, error.code, "A JSON account request is required.");
    throw error;
  }
}

function randomCode() {
  // Rejection sampling avoids modulo bias; entropy is supplied by Web Crypto.
  const sample = new Uint32Array(1);
  do {
    crypto.getRandomValues(sample);
  } while (sample[0] >= 4_294_000_000);
  return String(sample[0] % 1_000_000).padStart(6, "0");
}

async function otpVerifier(
  secret: string,
  id: string,
  identityKey: string,
  code: string,
  dependencies: RuntimeDependencies,
) {
  return hmac(
    secret,
    JSON.stringify([
      "accreatio.email-otp.v1",
      "sign_in",
      id,
      identityKey,
      code,
    ]),
    dependencies,
  );
}

async function requestOtp(
  request: Request,
  env: AccountBindings,
  db: AccountDatabase,
  dependencies: RuntimeDependencies,
) {
  const settings = otpSettings(env);
  const body = await readAccountJson(request, 512);
  if (
    !body ||
    typeof body !== "object" ||
    Array.isArray(body) ||
    !Object.hasOwn(body, "email") ||
    Object.keys(body).some(
      (key) => key !== "email" && key !== "policyAuthorization",
    )
  )
    return fail(400, "invalid_email", "Enter a valid email address.");
  const value = body as Record<string, unknown>;
  const authorization = requirePolicyAuthorization(value.policyAuthorization);
  const identity = await emailIdentity(
    normalizeEmail(value.email),
    env,
    dependencies,
  );
  // CF-Connecting-IP is populated by the edge, never a client-authored body field.
  // Without it all requests share a conservative fallback bucket.
  const ipKey = await hmac(
    settings.secret,
    JSON.stringify([
      "accreatio.otp-ip.v1",
      request.headers.get("CF-Connecting-IP") ?? "unavailable",
    ]),
    dependencies,
  );
  const id = dependencies.randomUUID();
  const code = randomCode();
  const verifier = await otpVerifier(
    settings.secret,
    id,
    identity.key,
    code,
    dependencies,
  );
  await cleanup(db);
  // D1 executes this batch transactionally. Admission, cooldown and all limits
  // are checked by one conditional write, including simultaneous requests.
  const result = await db.batch([
    db
      .prepare(
        `INSERT INTO account_otp_challenges
      (id, identity_key, email, purpose, verifier, ip_key, created_at, expires_at,policy_privacy_notice_version,policy_terms_version,policy_purpose_version,policy_authorized_at)
      SELECT ?, ?, ?, 'sign_in', ?, ?, ${NOW_SQL}, ${NOW_SQL} + ${OTP_MS},?,?,?,${NOW_SQL}
      WHERE NOT EXISTS (SELECT 1 FROM account_otp_challenges WHERE identity_key = ? AND created_at > ${NOW_SQL} - ${OTP_COOLDOWN_MS})
      AND (SELECT COUNT(*) FROM account_otp_challenges WHERE identity_key = ? AND created_at > ${NOW_SQL} - 3600000) < ?
      AND (SELECT COUNT(*) FROM account_otp_challenges WHERE ip_key = ? AND created_at > ${NOW_SQL} - 3600000) < ?
      AND (SELECT COUNT(*) FROM account_otp_challenges WHERE created_at > ${NOW_SQL} - ${ACCOUNT_WINDOW_MS}) < ?`,
      )
      .bind(
        id,
        identity.key,
        identity.email,
        verifier,
        ipKey,
        authorization.privacyNoticeVersion,
        authorization.termsVersion,
        authorization.purposeVersion,
        identity.key,
        identity.key,
        settings.emailHourly,
        ipKey,
        settings.ipHourly,
        settings.globalDaily,
      ),
    db
      .prepare(
        `UPDATE account_otp_challenges SET invalidated_at = ${NOW_SQL}, email = NULL, verifier = NULL,${CLEAR_TRANSACTION_POLICY_SQL}
      WHERE identity_key = ? AND id != ? AND consumed_at IS NULL AND invalidated_at IS NULL
      AND EXISTS (SELECT 1 FROM account_otp_challenges WHERE id = ?)`,
      )
      .bind(identity.key, id, id),
    db
      .prepare(
        "SELECT expires_at, created_at FROM account_otp_challenges WHERE id = ?",
      )
      .bind(id),
  ]);
  if (result.some((r) => !r.success))
    return fail(
      503,
      "account_unavailable",
      "Account service is temporarily unavailable.",
    );
  const challenge = result[2].results?.[0] as
    { expires_at: number; created_at: number } | undefined;
  if (!challenge)
    return jsonResponse(
      {
        error: {
          code: "otp_rate_limited",
          message:
            "Please wait before requesting another code. If requests remain limited, try again later.",
          retryAfter: 60,
        },
      },
      429,
      { "Retry-After": "60" },
    );
  try {
    const sent = await settings.mailer.fetch(
      new Request("https://account-mailer.internal/otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: identity.email,
          code,
          expiresInMinutes: 10,
        }),
      }),
    );
    if (!sent.ok) throw new Error("delivery_failed");
    const delivered = await db
      .prepare(
        `UPDATE account_otp_challenges SET delivered_at = ${NOW_SQL}
      WHERE id = ? AND invalidated_at IS NULL AND expires_at > ${NOW_SQL}`,
      )
      .bind(id)
      .run();
    if (!delivered.success) throw new Error("delivery_state_failed");
  } catch {
    await db
      .prepare(
        `UPDATE account_otp_challenges SET invalidated_at = ${NOW_SQL}, email = NULL, verifier = NULL,${CLEAR_TRANSACTION_POLICY_SQL} WHERE id = ?`,
      )
      .bind(id)
      .run();
    return fail(
      503,
      "otp_delivery_unavailable",
      "The code could not be sent. Wait a minute and try again.",
    );
  }
  return jsonResponse({
    challengeId: id,
    expiresAt: new Date(challenge.expires_at).toISOString(),
    resendAt: new Date(challenge.created_at + OTP_COOLDOWN_MS).toISOString(),
  });
}

async function verifyOtp(
  request: Request,
  env: AccountBindings,
  db: AccountDatabase,
  dependencies: RuntimeDependencies,
) {
  const settings = otpSettings(env);
  const body = await readAccountJson(request, 256);
  if (
    !exactBody(body, ["challengeId", "code"]) ||
    typeof body.challengeId !== "string" ||
    !UUID.test(body.challengeId) ||
    typeof body.code !== "string" ||
    !/^\d{6}$/.test(body.code)
  )
    return fail(
      400,
      "invalid_otp_request",
      "Enter the six-digit code from your email.",
    );
  const challenge = await db
    .prepare(
      "SELECT identity_key, email FROM account_otp_challenges WHERE id = ?",
    )
    .bind(body.challengeId)
    .first<{ identity_key: string; email: string | null }>();
  const existing = challenge
    ? await db
        .prepare("SELECT id FROM accounts WHERE identity_key=?")
        .bind(challenge.identity_key)
        .first<{ id: string }>()
    : null;
  const accountId = existing?.id ?? dependencies.randomUUID();
  const encryptedEmail =
    challenge?.email && privacyConfigured(env)
      ? await protectEmail(challenge.email, accountId, env, dependencies)
      : null;
  // Also compute an HMAC for missing IDs; failure never discloses account existence.
  const verifier = await otpVerifier(
    settings.secret,
    body.challengeId,
    challenge?.identity_key ?? "unavailable",
    body.code,
    dependencies,
  );
  const tokenBytes = crypto.getRandomValues(new Uint8Array(32));
  const token = hex(tokenBytes.buffer);
  const tokenHash = await digest(token, dependencies);
  const id = body.challengeId;
  // The attempt nonce links successful consumption to this exact transactional
  // increment. An exhausted challenge cannot succeed on a later correct guess.
  // The winner's nonce then gates every account/session write in the same batch.
  const results = await db.batch([
    db
      .prepare(
        `UPDATE account_otp_challenges SET attempts = attempts + 1, last_attempt_key = ?
      WHERE id = ? AND purpose = 'sign_in' AND delivered_at IS NOT NULL
      AND expires_at > ${NOW_SQL} AND consumed_at IS NULL AND invalidated_at IS NULL AND attempts < ${OTP_ATTEMPTS}`,
      )
      .bind(tokenHash, id),
    db
      .prepare(
        `UPDATE account_otp_challenges SET consumed_at = ${NOW_SQL}, consumption_key = ?
      WHERE id = ? AND last_attempt_key = ? AND verifier = ? AND consumed_at IS NULL
      AND invalidated_at IS NULL AND expires_at > ${NOW_SQL} AND attempts <= ${OTP_ATTEMPTS} AND ${TRANSACTION_POLICY_SQL}
      AND NOT EXISTS(SELECT 1 FROM accounts a JOIN account_abuse_state b ON b.account_id=a.id WHERE a.identity_key=account_otp_challenges.identity_key AND b.suspended_until>${NOW_SQL})
      AND (?=1 OR NOT EXISTS(SELECT 1 FROM accounts WHERE email_ciphertext IS NOT NULL OR identity_scheme='federated-v1'))`,
      )
      .bind(tokenHash, id, tokenHash, verifier, privacyConfigured(env) ? 1 : 0),
    db
      .prepare(
        `INSERT INTO accounts (id, identity_key, email, created_at, last_seen_at)
      SELECT ?, identity_key, email, ${NOW_SQL}, ${NOW_SQL} FROM account_otp_challenges
      WHERE id = ? AND consumption_key = ? AND (SELECT COUNT(*) FROM accounts) < ?
      AND NOT EXISTS(SELECT 1 FROM accounts a WHERE a.email_lookup_key=? AND a.identity_key!=account_otp_challenges.identity_key)
      AND NOT EXISTS(SELECT 1 FROM account_auth_tombstones t WHERE t.locator_kind='email' AND t.locator_hmac=? AND t.expires_at>${NOW_SQL} AND t.account_id!=?)
      ON CONFLICT(identity_key) DO NOTHING`,
      )
      .bind(
        accountId,
        id,
        tokenHash,
        settings.accounts,
        encryptedEmail?.lookupKey ?? null,
        encryptedEmail?.lookupKey ?? null,
        accountId,
      ),
    db
      .prepare(
        `UPDATE accounts SET email = (SELECT email FROM account_otp_challenges WHERE id = ?), deleted_at = NULL, last_seen_at = ${NOW_SQL}
      WHERE identity_key = (SELECT identity_key FROM account_otp_challenges WHERE id = ? AND consumption_key = ?)`,
      )
      .bind(id, id, tokenHash),
    db
      .prepare(
        `DELETE FROM account_sessions WHERE token_hash IN
      (SELECT token_hash FROM account_sessions WHERE account_id =
        (SELECT a.id FROM accounts a JOIN account_otp_challenges c ON c.identity_key = a.identity_key WHERE c.id = ? AND c.consumption_key = ?)
        ORDER BY expires_at DESC LIMIT -1 OFFSET 9)`,
      )
      .bind(id, tokenHash),
    db
      .prepare(
        `INSERT INTO account_sessions (token_hash, account_id, expires_at)
      SELECT ?, a.id, ${NOW_SQL} + ${SESSION_MS} FROM accounts a JOIN account_otp_challenges c ON c.identity_key = a.identity_key
      WHERE c.id = ? AND c.consumption_key = ? AND a.deleted_at IS NULL AND ${ABUSE_ALLOWED_SQL("a.id")}`,
      )
      .bind(tokenHash, id, tokenHash),
    db
      .prepare(
        `SELECT a.id, a.email, s.expires_at FROM account_sessions s JOIN accounts a ON a.id = s.account_id WHERE s.token_hash = ?`,
      )
      .bind(tokenHash),
    db
      .prepare(
        `SELECT consumed_at FROM account_otp_challenges WHERE id = ? AND consumption_key = ?`,
      )
      .bind(id, tokenHash),
    db
      .prepare(
        `INSERT INTO account_policy_authorizations(account_id,privacy_notice_version,terms_version,purpose_version,authorized_at)
      SELECT ?,policy_privacy_notice_version,policy_terms_version,policy_purpose_version,policy_authorized_at FROM account_otp_challenges WHERE id=? AND consumption_key=? AND ${TRANSACTION_POLICY_SQL}
      AND EXISTS(SELECT 1 FROM account_sessions WHERE token_hash=?) ${POLICY_UPSERT_SQL}`,
      )
      .bind(accountId, id, tokenHash, tokenHash),
    db
      .prepare(
        `UPDATE accounts SET email=NULL,email_ciphertext=?,email_encryption_key_version=?,email_lookup_key=?,email_verification_source='email-otp',email_verified_at=${NOW_SQL},privacy_notice_version=?
      WHERE id=? AND ?=1 AND EXISTS(SELECT 1 FROM account_otp_challenges WHERE id=? AND consumption_key=?)`,
      )
      .bind(
        encryptedEmail?.ciphertext ?? null,
        encryptedEmail?.keyVersion ?? null,
        encryptedEmail?.lookupKey ?? null,
        PRIVACY_NOTICE_VERSION,
        accountId,
        encryptedEmail ? 1 : 0,
        id,
        tokenHash,
      ),
    db
      .prepare(
        `INSERT INTO account_session_metadata(token_hash,method,authenticated_at,security_version) SELECT ?,'email-otp',${NOW_SQL},security_version FROM accounts WHERE id=? AND EXISTS(SELECT 1 FROM account_sessions WHERE token_hash=?)`,
      )
      .bind(tokenHash, accountId, tokenHash),
    db
      .prepare(
        `UPDATE account_otp_challenges SET email=NULL,verifier=NULL,${CLEAR_TRANSACTION_POLICY_SQL} WHERE id=? AND consumption_key=?`,
      )
      .bind(id, tokenHash),
  ]);
  if (results.some((r) => !r.success))
    return fail(
      503,
      "account_unavailable",
      "Account service is temporarily unavailable.",
    );
  const account = results[6].results?.[0] as
    { id: string; email: string; expires_at: number } | undefined;
  if (!account) {
    if (results[7].results?.length)
      return fail(
        503,
        "beta_capacity",
        "This preview has reached its account capacity. Please try again later.",
      );
    return fail(
      401,
      "otp_invalid",
      "That code is incorrect, expired or already used. Try again or request a new code.",
    );
  }
  return jsonResponse(
    {
      ...(await localWorkKeys(account.id, tokenHash, env, dependencies)),
      email: account.email,
      displayName: fallbackDisplayName(account.email),
      expiresAt: new Date(account.expires_at).toISOString(),
      policyAuthorizationRequired: false,
      ...(await quota(db, account.id)),
    },
    200,
    { "Set-Cookie": cookie(token, SESSION_MS / 1000) },
  );
}

export async function handleAccount(
  context: { request: Request; env: AccountBindings },
  action:
    | "session"
    | "authorize"
    | "logout"
    | "delete"
    | "data"
    | "identity"
    | "login"
    | "policy"
    | "otp/request"
    | "otp/verify",
  dependencies = runtimeDependencies(),
): Promise<Response> {
  const { request, env } = context;
  const methods =
    action === "session"
      ? ["GET", "POST"]
      : action === "data" || action === "identity" || action === "login"
        ? ["GET"]
        : ["POST"];
  if (!methods.includes(request.method)) return methodNotAllowed(methods);
  // Older installed clients navigate here. Return to the app without a JSON
  // document, provider lookup, account access or caller-controlled destination.
  if (action === "login")
    return new Response(null, {
      status: 303,
      headers: {
        ...SECURITY_HEADERS,
        Location: "/",
        "Cache-Control": "no-store",
        "Referrer-Policy": "no-referrer",
      },
    });
  try {
    const db = dbFor(env);
    if (request.method === "POST") requireOrigin(request);
    if (action === "logout") {
      const statements: BlogPreparedStatement[] = [];
      for (const name of [COOKIE, RIGHTS_COOKIE]) {
        const token = readToken(request, name);
        if (!token) continue;
        const tokenHash = await digest(token, dependencies);
        statements.push(
          db
            .prepare(
              `UPDATE account_auth_transactions SET status='failed',secrets_ciphertext=NULL,previous_session_token_hash=NULL,issued_session_token_hash=NULL,${CLEAR_TRANSACTION_POLICY_SQL} WHERE previous_session_token_hash=? AND status IN ('created','claimed')`,
            )
            .bind(tokenHash),
          db
            .prepare("DELETE FROM account_sessions WHERE token_hash=?")
            .bind(tokenHash),
        );
      }
      if (
        statements.length &&
        (await db.batch(statements)).some((result) => !result.success)
      )
        return fail(
          503,
          "account_unavailable",
          "Sign out could not be completed.",
        );
      const response = jsonResponse({ ok: true }, 200);
      response.headers.append("Set-Cookie", cookie("", 0));
      response.headers.append(
        "Set-Cookie",
        `${RIGHTS_COOKIE}=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0`,
      );
      return response;
    }
    if (action === "otp/request" || action === "otp/verify")
      await requireOtpPrivacy(env, db);
    if (action === "otp/request")
      return await requestOtp(request, env, db, dependencies);
    if (action === "otp/verify")
      return await verifyOtp(request, env, db, dependencies);
    const rightsOnly =
      (action === "data" || action === "delete") &&
      request.headers.get("X-Accreatio-Rights") === "1";
    const account = await findSession(
      request,
      db,
      dependencies,
      env,
      rightsOnly,
    );
    if (!account) {
      // Rights routes reserve their admission for a verified principal. Failed
      // lookups still consume a bounded anonymous network budget.
      if (
        env.ACCOUNT_ABUSE_ENABLED === "true" &&
        (action === "data" || action === "delete")
      )
        await enforceAbuse({
          db,
          secret: env.ACCOUNT_AUTH_LOCATOR_KEY,
          request,
          route: "rights",
        });
      return fail(401, "sign_in_required", "Sign in to continue.");
    }
    const protectedAction = !["data", "delete", "logout"].includes(action);
    if (env.ACCOUNT_ABUSE_ENABLED === "true")
      await enforceAbuse({
        db,
        secret: env.ACCOUNT_AUTH_LOCATOR_KEY!,
        request,
        route: protectedAction
          ? action === "authorize"
            ? "export-authorize"
            : action === "session" || action === "identity"
              ? "account-read"
              : "account-write"
          : "rights",
        principal: { accountId: account.id, tokenHash: account.tokenHash },
        skipNetwork: true,
        sanctionEligible: action === "session" || action === "identity",
      });
    if (action === "identity")
      return jsonResponse({
        email: account.email,
        displayName: account.displayName,
      });
    if (action === "policy") {
      const authorization = requirePolicyAuthorization(
        await readAccountJson(request, 512),
      );
      const gate = `EXISTS(SELECT 1 FROM account_sessions s JOIN accounts a ON a.id=s.account_id LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash WHERE s.token_hash=? AND s.account_id=? AND s.expires_at>${NOW_SQL} AND a.deleted_at IS NULL AND a.security_version=? AND COALESCE(m.rights_only,0)=0 AND (m.token_hash IS NULL OR m.security_version=a.security_version) AND ${ABUSE_ALLOWED_SQL("a.id")})`;
      const args = [account.tokenHash, account.id, account.security_version];
      const results = await db.batch([
        db
          .prepare(
            `INSERT INTO account_policy_authorizations(account_id,privacy_notice_version,terms_version,purpose_version,authorized_at)
          SELECT ?,?,?,?,${NOW_SQL} WHERE ${gate} ${POLICY_UPSERT_SQL}`,
          )
          .bind(
            account.id,
            authorization.privacyNoticeVersion,
            authorization.termsVersion,
            authorization.purposeVersion,
            ...args,
          ),
        db
          .prepare(
            `SELECT account_id FROM account_policy_authorizations WHERE account_id=? AND ${CURRENT_POLICY_SQL} AND ${gate}`,
          )
          .bind(account.id, ...args),
      ]);
      if (results.some((result) => !result.success))
        return fail(
          503,
          "account_unavailable",
          "Account authorization could not be saved.",
        );
      if (!results[1].results?.length)
        return fail(401, "sign_in_required", "Sign in to continue.");
    }
    if (action === "session" || action === "policy") {
      const identities = await db
        .prepare(
          "SELECT DISTINCT issuer FROM account_external_identities WHERE account_id=? ORDER BY issuer",
        )
        .bind(account.id)
        .all<{ issuer: string }>();
      return jsonResponse({
        ...(await localWorkKeys(
          account.id,
          account.tokenHash,
          env,
          dependencies,
        )),
        email: account.email,
        displayName: account.displayName,
        connectedProviders: (identities.results ?? []).flatMap((identity) =>
          identity.issuer === "https://accounts.google.com"
            ? ["google"]
            : identity.issuer === "https://github.com"
              ? ["github"]
              : [],
        ),
        expiresAt: new Date(account.sessionExpiresAt!).toISOString(),
        policyAuthorizationRequired: !(await hasCurrentPolicyAuthorization(
          db,
          account.id,
        )),
        ...(await quota(db, account.id)),
      });
    }
    if (action === "data" || action === "delete") {
      if (rightsOnly) {
        const transactionId = request.headers.get(
          "X-Accreatio-Rights-Transaction",
        );
        if (
          !transactionId ||
          !UUID.test(transactionId) ||
          !(await db
            .prepare(
              `SELECT id FROM account_auth_transactions WHERE id=? AND status='completed' AND rights_only=1 AND account_id=? AND verification_action=? AND access_security_version=?`,
            )
            .bind(transactionId, account.id, action, account.security_version)
            .first())
        )
          return fail(
            401,
            "reauthentication_required",
            "Verify this account action again in this tab.",
          );
      }
      const recent = await db
        .prepare(
          `SELECT s.token_hash FROM account_sessions s LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash
        WHERE s.token_hash=? AND s.expires_at>${NOW_SQL} AND COALESCE(m.authenticated_at,s.expires_at-${SESSION_MS})>${NOW_SQL}-300000
        AND m.verification_action=?`,
        )
        .bind(account.tokenHash, action)
        .first();
      if (!recent)
        return fail(
          401,
          "reauthentication_required",
          "Sign in again before downloading or deleting your account data.",
        );
    }
    if (action === "authorize") {
      const body = await readAccountJson(request, 256);
      if (
        !body ||
        typeof body !== "object" ||
        Array.isArray(body) ||
        Object.keys(body).some(
          (key) => !["operationId", "ownerKey", "sessionKey"].includes(key),
        ) ||
        !("operationId" in body) ||
        typeof body.operationId !== "string" ||
        !UUID.test(body.operationId)
      )
        return fail(
          400,
          "invalid_operation",
          "A valid export operation is required.",
        );
      const workKeys = await localWorkKeys(
        account.id,
        account.tokenHash,
        env,
        dependencies,
      );
      if (
        !("ownerKey" in body) ||
        body.ownerKey !== workKeys.ownerKey ||
        !("sessionKey" in body) ||
        body.sessionKey !== workKeys.sessionKey
      )
        return fail(
          409,
          "account_context_changed",
          "Your account session changed. Prepare this ZIP again.",
        );
      if (!(await hasCurrentPolicyAuthorization(db, account.id)))
        return fail(
          403,
          "policy_authorization_required",
          "Review the necessary account processing and terms before exporting.",
        );
      if (env.ACCOUNT_ABUSE_ENABLED === "true") {
        const allowance = await quota(db, account.id);
        if (allowance.remaining > 0)
          await enforceAbuse({
            db,
            secret: env.ACCOUNT_AUTH_LOCATOR_KEY!,
            request,
            route: "account-write",
            principal: { accountId: account.id, tokenHash: account.tokenHash },
            skipNetwork: true,
            sanctionEligible: true,
          });
      }
      const results = await db.batch([
        db
          .prepare(
            AUTHORIZE_SQL.replace(
              " ON CONFLICT",
              ` AND EXISTS(SELECT 1 FROM account_sessions s JOIN accounts a ON a.id=s.account_id LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash WHERE s.token_hash=? AND s.account_id=? AND s.expires_at>${NOW_SQL} AND a.security_version=? AND COALESCE(m.rights_only,0)=0 AND (m.token_hash IS NULL OR m.security_version=a.security_version) AND ${ABUSE_ALLOWED_SQL("a.id")}) ON CONFLICT`,
            ),
          )
          .bind(
            account.id,
            body.operationId,
            account.id,
            account.id,
            account.tokenHash,
            account.id,
            account.security_version,
          ),
        db
          .prepare(
            `SELECT issued_at FROM export_authorizations WHERE account_id = ? AND operation_id = ?
          AND issued_at > ${NOW_SQL} - ? AND EXISTS(SELECT 1 FROM account_sessions s JOIN accounts a ON a.id=s.account_id LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash WHERE s.token_hash=? AND s.account_id=export_authorizations.account_id AND s.expires_at>${NOW_SQL} AND a.deleted_at IS NULL AND a.security_version=? AND COALESCE(m.rights_only,0)=0 AND (m.token_hash IS NULL OR m.security_version=a.security_version) AND ${ABUSE_ALLOWED_SQL("a.id")})
          AND EXISTS(SELECT 1 FROM account_policy_authorizations WHERE account_id=export_authorizations.account_id AND ${CURRENT_POLICY_SQL})`,
          )
          .bind(
            account.id,
            body.operationId,
            RETENTION_MS,
            account.tokenHash,
            account.security_version,
          ),
      ]);
      if (results.some((r) => !r.success))
        return fail(
          503,
          "quota_unavailable",
          "Export availability could not be checked.",
        );
      const receipt = results[1].results?.[0] as
        { issued_at: number } | undefined;
      const availability = await quota(db, account.id);
      if (!receipt && !(await hasCurrentPolicyAuthorization(db, account.id)))
        return fail(
          403,
          "policy_authorization_required",
          "Review the necessary account processing and terms before exporting.",
        );
      if (!receipt && availability.remaining > 0)
        return fail(
          410,
          "receipt_expired",
          "This export receipt has expired. Prepare a new ZIP.",
        );
      if (!receipt)
        return jsonResponse(
          {
            error: {
              code: "quota_exhausted",
              message:
                "Thank you for creating with accreatio. Come back when your next export is available.",
            },
            ...availability,
          },
          429,
          {
            "Retry-After": String(
              Math.max(
                1,
                Math.ceil(
                  (Date.parse(availability.nextAvailableAt!) -
                    dependencies.now()) /
                    1000,
                ),
              ),
            ),
          },
        );
      return jsonResponse({
        operationId: body.operationId,
        issuedAt: new Date(receipt.issued_at).toISOString(),
        authorizedAt: new Date(receipt.issued_at).toISOString(),
        retryExpiresAt: new Date(
          receipt.issued_at + RETENTION_MS,
        ).toISOString(),
        ...availability,
      });
    }
    if (action === "data") {
      const gate = `EXISTS(SELECT 1 FROM account_sessions s JOIN accounts a ON a.id=s.account_id LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash
        WHERE s.token_hash=? AND s.account_id=? AND s.expires_at>${NOW_SQL} AND a.deleted_at IS NULL AND a.security_version=? AND m.verification_action='data' AND COALESCE(m.authenticated_at,s.expires_at-${SESSION_MS})>${NOW_SQL}-300000)`;
      const args = [account.tokenHash, account.id, account.security_version];
      const results = await db.batch([
        db
          .prepare(
            `SELECT id,email,email_ciphertext,email_encryption_key_version,display_name_ciphertext,created_at AS createdAt,last_seen_at AS lastSeenAt,email_verification_source AS emailVerificationSource,email_verified_at AS emailVerifiedAt,privacy_notice_version AS privacyNoticeVersion FROM accounts WHERE id=? AND ${gate}`,
          )
          .bind(account.id, ...args),
        db
          .prepare(
            `SELECT operation_id AS operationId,issued_at AS issuedAt FROM export_authorizations WHERE account_id=? AND issued_at>${NOW_SQL}-? AND ${gate} ORDER BY issued_at LIMIT 20`,
          )
          .bind(account.id, RETENTION_MS, ...args),
        db
          .prepare(
            `SELECT issuer,subject,created_at AS createdAt,last_authenticated_at AS lastAuthenticatedAt FROM account_external_identities WHERE account_id=? AND ${gate} ORDER BY created_at`,
          )
          .bind(account.id, ...args),
        db
          .prepare(
            `SELECT m.method,m.authenticated_at AS authenticatedAt,s.expires_at AS expiresAt FROM account_sessions s LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash WHERE s.account_id=? AND s.expires_at>${NOW_SQL} AND ${gate} ORDER BY s.expires_at LIMIT 10`,
          )
          .bind(account.id, ...args),
        db
          .prepare(
            `SELECT ${POLICY_RECEIPT_COLUMNS} FROM account_policy_authorizations WHERE account_id=? AND ${gate}`,
          )
          .bind(account.id, ...args),
        db
          .prepare(
            `SELECT level, suspended_until AS suspendedUntil, recurrence_until AS recurrenceUntil, expires_at AS expiresAt FROM account_abuse_state WHERE account_id=? AND expires_at>${NOW_SQL} AND ${gate}`,
          )
          .bind(account.id, ...args),
      ]);
      if (results.some((r) => !r.success))
        return fail(
          503,
          "account_unavailable",
          "Account data could not be retrieved.",
        );
      const data = results[0].results?.[0] as
        | (EmailRecord & {
            createdAt: number;
            lastSeenAt: number;
            emailVerificationSource: string | null;
            emailVerifiedAt: number | null;
            privacyNoticeVersion: string | null;
          })
        | undefined;
      if (!data)
        return fail(
          401,
          "reauthentication_required",
          "Sign in again before downloading your account data.",
        );
      const exportedEmail = await revealEmail(data, env, dependencies);
      const exportedDisplayName =
        (await revealDisplayName(data, env, dependencies)) ??
        fallbackDisplayName(exportedEmail);
      // Decryption awaits cannot retain an authorization revoked in the meantime.
      if (
        !(await db
          .prepare(`SELECT id FROM accounts WHERE id=? AND ${gate}`)
          .bind(account.id, ...args)
          .first())
      )
        return fail(
          401,
          "reauthentication_required",
          "Verify your account again before downloading.",
        );
      return jsonResponse(
        {
          manifest: {
            product: "accreatio",
            preparedAt: new Date(dependencies.now()).toISOString(),
            format: "JSON UTF-8",
            scope:
              "Verified own-account access response; local project download is separate",
            included: [
              "identity and display profile",
              "linked identity methods",
              "active session metadata without bearer secrets",
              "current versioned account-processing and Terms receipt",
              "retained 48-hour quota receipts",
              "current security restriction",
            ],
            limitations: [
              "Projects and attachment bytes never reach this account service; download them from Privacy and data in their original browser.",
              "Browser choices and optional contributions have a separate purpose-capability export; no account association is constructed.",
              "External identity providers, infrastructure logs, mailbox correspondence and recovery copies are not silently claimed complete. Use the published rights contact for a verified, scoped extraction or explanation of those stores; never submit credentials or project files.",
              "Session tokens, credential verifiers, runtime keys and other accounts are excluded. Shared-network and other relevant security records require a verified scoped extraction/redaction to avoid disclosing other users; they are not claimed silently included. JSON strings remain data; no spreadsheet formulas are emitted.",
            ],
          },
          email: exportedEmail,
          displayName: exportedDisplayName,
          accountId: data.id,
          createdAt: data.createdAt,
          lastSeenAt: data.lastSeenAt,
          emailVerificationSource: data.emailVerificationSource,
          emailVerifiedAt: data.emailVerifiedAt,
          authorizations: results[1].results ?? [],
          identities: results[2].results ?? [],
          sessions: results[3].results ?? [],
          privacyNoticeVersion: data.privacyNoticeVersion,
          policyAuthorization: policyReceipt(
            results[4].results?.[0] as PolicyReceiptRow | undefined,
          ),
          securityRestriction: results[5].results?.[0]
            ? {
                reason: "repeated_request_limit_exceeded",
                ...(results[5].results[0] as object),
              }
            : null,
        },
        200,
        {
          "Content-Disposition":
            'attachment; filename="accreatio-account.json"',
        },
      );
    }
    if (action === "delete") {
      const recentSession = `EXISTS(SELECT 1 FROM account_sessions s JOIN accounts a ON a.id=s.account_id LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash WHERE s.token_hash=? AND s.expires_at>${NOW_SQL} AND a.deleted_at IS NULL AND a.security_version=? AND (m.token_hash IS NULL OR m.security_version=a.security_version) AND m.verification_action='delete' AND COALESCE(m.authenticated_at,s.expires_at-${SESSION_MS})>${NOW_SQL}-300000)`;
      const results = await db.batch([
        db
          .prepare(
            `INSERT INTO account_auth_tombstones(locator_kind,locator_hmac,account_id,expires_at)
          SELECT 'external',e.locator_hmac,e.account_id,${NOW_SQL}+${AUTH_RETENTION_MS} FROM account_external_identities e
          WHERE e.account_id=? AND ${recentSession}
          ON CONFLICT(locator_kind,locator_hmac) DO UPDATE SET expires_at=excluded.expires_at WHERE account_auth_tombstones.account_id=excluded.account_id`,
          )
          .bind(account.id, account.tokenHash, account.security_version),
        db
          .prepare(
            `INSERT INTO account_auth_tombstones(locator_kind,locator_hmac,account_id,expires_at)
          SELECT 'email',email_lookup_key,id,${NOW_SQL}+${AUTH_RETENTION_MS} FROM accounts WHERE id=? AND email_lookup_key IS NOT NULL AND ${recentSession}
          ON CONFLICT(locator_kind,locator_hmac) DO UPDATE SET expires_at=excluded.expires_at WHERE account_auth_tombstones.account_id=excluded.account_id`,
          )
          .bind(account.id, account.tokenHash, account.security_version),
        db
          .prepare(
            `UPDATE accounts SET email=NULL,email_ciphertext=NULL,email_encryption_key_version=NULL,display_name_ciphertext=NULL,email_lookup_key=NULL,email_verification_source=NULL,email_verified_at=NULL,privacy_notice_version=NULL,deleted_at=${NOW_SQL},security_version=security_version+1
          WHERE id=? AND deleted_at IS NULL AND security_version=? AND ${recentSession} RETURNING id`,
          )
          .bind(
            account.id,
            account.security_version,
            account.tokenHash,
            account.security_version,
          ),
        db
          .prepare(
            `DELETE FROM account_external_identities WHERE account_id=? AND EXISTS(SELECT 1 FROM accounts WHERE id=? AND deleted_at IS NOT NULL)`,
          )
          .bind(account.id, account.id),
        db
          .prepare(
            `UPDATE account_auth_transactions SET status='failed',secrets_ciphertext=NULL,previous_session_token_hash=NULL,issued_session_token_hash=NULL,${CLEAR_TRANSACTION_POLICY_SQL} WHERE (account_id=? OR previous_session_token_hash IN(SELECT token_hash FROM account_sessions WHERE account_id=?)) AND EXISTS(SELECT 1 FROM accounts WHERE id=? AND deleted_at IS NOT NULL)`,
          )
          .bind(account.id, account.id, account.id),
        db
          .prepare(
            `UPDATE account_otp_challenges SET email = NULL, verifier = NULL, invalidated_at = ${NOW_SQL},${CLEAR_TRANSACTION_POLICY_SQL} WHERE identity_key = ? AND EXISTS(SELECT 1 FROM accounts WHERE id=? AND deleted_at IS NOT NULL)`,
          )
          .bind(account.identity_key, account.id),
        db
          .prepare(
            "DELETE FROM account_sessions WHERE account_id = ? AND EXISTS(SELECT 1 FROM accounts WHERE id=? AND deleted_at IS NOT NULL)",
          )
          .bind(account.id, account.id),
        db
          .prepare(
            "DELETE FROM account_policy_authorizations WHERE account_id=? AND EXISTS(SELECT 1 FROM accounts WHERE id=? AND deleted_at IS NOT NULL)",
          )
          .bind(account.id, account.id),
      ]);
      if (results.some((r) => !r.success))
        return fail(
          503,
          "account_unavailable",
          "Account deletion could not be completed.",
        );
      if (!results[2].results?.length)
        return fail(
          401,
          "reauthentication_required",
          "Sign in again before deleting your account data.",
        );
    }
    const response = jsonResponse({ ok: true }, 200);
    response.headers.append(
      "Set-Cookie",
      rightsOnly
        ? `${RIGHTS_COOKIE}=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0`
        : cookie("", 0),
    );
    if (!rightsOnly)
      response.headers.append(
        "Set-Cookie",
        `${RIGHTS_COOKIE}=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0`,
      );
    return response;
  } catch (error) {
    const abuse = abuseErrorResponse(error);
    if (abuse) return abuse;
    // No identifiers, headers, codes, content or raw error strings in logs.
    if (error instanceof ApiError)
      return jsonResponse(
        {
          error: {
            code: error.code,
            message: error.publicMessage,
            ...(error.retryAfterSeconds
              ? { retryAfter: error.retryAfterSeconds }
              : {}),
          },
        },
        error.status,
        error.retryAfterSeconds
          ? { "Retry-After": String(error.retryAfterSeconds) }
          : undefined,
      );
    return jsonResponse(
      {
        error: {
          code: "account_unavailable",
          message: "Account service is temporarily unavailable.",
        },
      },
      503,
    );
  }
}
