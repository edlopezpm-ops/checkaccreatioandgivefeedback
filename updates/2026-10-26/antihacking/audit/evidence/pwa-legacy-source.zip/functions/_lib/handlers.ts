import { authenticateAccess, authorizePublisher } from "./access";
import {
  listPublishedPosts,
  normalizeIdempotencyKey,
  publishPost,
  validateNewBlogPost,
} from "./blog";
import {
  ApiError,
  errorResponse,
  jsonResponse,
  methodNotAllowed,
  readBoundedJson,
} from "./http";
import {
  runtimeDependencies,
  type BlogFunctionContext,
  type RuntimeDependencies,
} from "./platform";

const MAX_PUBLISH_BYTES = 32_768;

const requireDatabase = (context: BlogFunctionContext) => {
  if (!context.env.BLOG_DB) {
    throw new ApiError(
      503,
      "editorial_database_unavailable",
      "Blog posts are temporarily unavailable.",
    );
  }
  return context.env.BLOG_DB;
};

export const handleListPosts = async (context: BlogFunctionContext) => {
  const route = "GET /api/blog/posts";
  try {
    if (context.request.method !== "GET") return methodNotAllowed(["GET"]);
    const posts = await listPublishedPosts(requireDatabase(context));
    return jsonResponse({ posts });
  } catch (error) {
    return errorResponse(error, route);
  }
};

export const handleAdminSession = async (
  context: BlogFunctionContext,
  dependencies: RuntimeDependencies = runtimeDependencies(),
) => {
  const route = "GET /api/admin/blog/session";
  try {
    if (context.request.method !== "GET") return methodNotAllowed(["GET"]);
    const identity = await authenticateAccess(
      context.request,
      context.env,
      dependencies,
    );
    const actor = await authorizePublisher(identity, context.env, dependencies);
    return jsonResponse({ canPublish: actor !== null, actor });
  } catch (error) {
    return errorResponse(error, route);
  }
};

const enforceBrowserWriteBoundary = (
  request: Request,
  actorKind: "human" | "agent",
) => {
  const origin = request.headers.get("Origin");
  const expectedOrigin = new URL(request.url).origin;
  if (origin !== null && origin !== expectedOrigin) {
    throw new ApiError(
      403,
      "cross_origin_write_denied",
      "Cross-origin publishing is not allowed.",
    );
  }
  if (actorKind === "human" && origin === null) {
    throw new ApiError(
      403,
      "origin_required",
      "Browser publishing requires a same-origin request.",
    );
  }
};

export const handlePublishPost = async (
  context: BlogFunctionContext,
  dependencies: RuntimeDependencies = runtimeDependencies(),
) => {
  const route = "POST /api/admin/blog/posts";
  try {
    if (context.request.method !== "POST") return methodNotAllowed(["POST"]);
    if (context.request.headers.get("X-Accreatio-Publish") !== "blog-v1") {
      throw new ApiError(
        403,
        "publish_header_required",
        "The Blog publish request is missing its required header.",
      );
    }
    const suppliedOrigin = context.request.headers.get("Origin");
    if (
      suppliedOrigin !== null &&
      suppliedOrigin !== new URL(context.request.url).origin
    ) {
      throw new ApiError(
        403,
        "cross_origin_write_denied",
        "Cross-origin publishing is not allowed.",
      );
    }
    const identity = await authenticateAccess(
      context.request,
      context.env,
      dependencies,
    );
    const actor = await authorizePublisher(identity, context.env, dependencies);
    if (!actor) {
      throw new ApiError(
        403,
        "publisher_not_authorized",
        "This Access identity cannot publish Blog posts.",
      );
    }
    enforceBrowserWriteBoundary(context.request, actor.kind);
    const idempotencyKey = normalizeIdempotencyKey(
      context.request.headers.get("Idempotency-Key"),
    );
    const input = validateNewBlogPost(
      await readBoundedJson(context.request, MAX_PUBLISH_BYTES),
    );
    const result = await publishPost(
      requireDatabase(context),
      actor,
      input,
      idempotencyKey,
      dependencies,
    );
    return jsonResponse(
      { post: result.post },
      result.replayed ? 200 : 201,
      result.replayed ? { "Idempotency-Replayed": "true" } : undefined,
    );
  } catch (error) {
    return errorResponse(error, route);
  }
};
