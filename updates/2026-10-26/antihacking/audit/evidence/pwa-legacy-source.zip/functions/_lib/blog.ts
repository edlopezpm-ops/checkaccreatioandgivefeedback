import { ApiError } from "./http";
import type { AuthorizedActor } from "./access";
import type { BlogDatabase, RuntimeDependencies } from "./platform";

const UUID =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const CONTROL_CHARACTERS = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u;

export interface BlogPost {
  readonly id: string;
  readonly slug: string;
  readonly title: string;
  readonly summary: string;
  readonly paragraphs: readonly string[];
  readonly language: "en" | "es";
  readonly author: string;
  readonly authorRole: string;
  readonly signature: string;
  readonly publishedAt: string;
}

export interface NewBlogPost {
  readonly title: string;
  readonly summary: string;
  readonly paragraphs: readonly string[];
  readonly language: "en" | "es";
  readonly author: string;
  readonly authorRole: string;
  readonly signature: string;
}

interface BlogRow {
  readonly id: string;
  readonly slug: string;
  readonly title: string;
  readonly summary: string;
  readonly paragraphs_json: string;
  readonly language: string;
  readonly author: string;
  readonly author_role: string;
  readonly signature: string;
  readonly published_at: string;
}

const isRecord = (
  value: unknown,
): value is { readonly [key: string]: unknown } =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const validateText = (value: unknown, field: string, maximum: number) => {
  if (typeof value !== "string") {
    throw new ApiError(422, "invalid_post", `${field} must be text.`);
  }
  const normalized = value
    .replaceAll("\r\n", "\n")
    .replaceAll("\r", "\n")
    .trim();
  if (
    normalized.length === 0 ||
    normalized.length > maximum ||
    CONTROL_CHARACTERS.test(normalized)
  ) {
    throw new ApiError(
      422,
      "invalid_post",
      `${field} is empty, too long, or contains unsupported characters.`,
    );
  }
  return normalized;
};

export const validateNewBlogPost = (value: unknown): NewBlogPost => {
  if (!isRecord(value)) {
    throw new ApiError(
      422,
      "invalid_post",
      "The Blog post must be a JSON object.",
    );
  }
  const expectedFields = [
    "author",
    "authorRole",
    "language",
    "paragraphs",
    "signature",
    "summary",
    "title",
  ];
  if (
    Object.keys(value).sort().join("\n") !== expectedFields.sort().join("\n")
  ) {
    throw new ApiError(
      422,
      "invalid_post",
      "The Blog post has missing or unsupported fields.",
    );
  }
  if (
    !Array.isArray(value.paragraphs) ||
    value.paragraphs.length === 0 ||
    value.paragraphs.length > 64
  ) {
    throw new ApiError(
      422,
      "invalid_post",
      "paragraphs must contain between 1 and 64 text paragraphs.",
    );
  }
  const paragraphs = value.paragraphs.map((paragraph, index) =>
    validateText(paragraph, `paragraphs[${index}]`, 2_400),
  );
  if (value.language !== "en" && value.language !== "es") {
    throw new ApiError(422, "invalid_post", "language must be en or es.");
  }
  return {
    title: validateText(value.title, "title", 120),
    summary: validateText(value.summary, "summary", 240),
    paragraphs,
    language: value.language,
    author: validateText(value.author, "author", 80),
    authorRole: validateText(value.authorRole, "authorRole", 160),
    signature: validateText(value.signature, "signature", 160),
  };
};

const parseParagraphs = (serialized: string) => {
  let parsed: unknown;
  try {
    parsed = JSON.parse(serialized) as unknown;
  } catch {
    throw new ApiError(
      500,
      "invalid_editorial_record",
      "Stored Blog content could not be read.",
    );
  }
  if (
    !Array.isArray(parsed) ||
    parsed.length === 0 ||
    parsed.length > 64 ||
    parsed.some((paragraph) => typeof paragraph !== "string")
  ) {
    throw new ApiError(
      500,
      "invalid_editorial_record",
      "Stored Blog content could not be read.",
    );
  }
  return parsed as readonly string[];
};

const rowToPost = (row: BlogRow): BlogPost => {
  if (row.language !== "en" && row.language !== "es") {
    throw new ApiError(
      500,
      "invalid_editorial_record",
      "Stored Blog content could not be read.",
    );
  }
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    summary: row.summary,
    paragraphs: parseParagraphs(row.paragraphs_json),
    language: row.language,
    author: row.author,
    authorRole: row.author_role,
    signature: row.signature,
    publishedAt: row.published_at,
  };
};

const SELECT_COLUMNS = `
  id, slug, title, summary, paragraphs_json, language, author, author_role,
  signature, published_at
`;

export const listPublishedPosts = async (database: BlogDatabase) => {
  try {
    const result = await database
      .prepare(
        `SELECT ${SELECT_COLUMNS}
         FROM blog_posts
         WHERE publication_status = ?1
         ORDER BY published_at DESC, created_at DESC, id DESC`,
      )
      .bind("published")
      .all<BlogRow>();
    if (!result.success || !result.results) {
      throw new ApiError(
        503,
        "editorial_database_unavailable",
        "Blog posts are temporarily unavailable.",
      );
    }
    return result.results.map(rowToPost);
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError(
      503,
      "editorial_database_unavailable",
      "Blog posts are temporarily unavailable.",
    );
  }
};

const slugify = (title: string, id: string) => {
  const base = title
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80)
    .replace(/-+$/g, "");
  return `${base || "post"}-${id.slice(0, 8)}`;
};

export const normalizeIdempotencyKey = (value: string | null) => {
  if (!value || !UUID.test(value)) {
    throw new ApiError(
      400,
      "invalid_idempotency_key",
      "Idempotency-Key must be a UUID.",
    );
  }
  return value.toLowerCase();
};

export interface PublishedPostResult {
  readonly post: BlogPost;
  readonly replayed: boolean;
}

export const publishPost = async (
  database: BlogDatabase,
  actor: AuthorizedActor,
  input: NewBlogPost,
  idempotencyKey: string,
  dependencies: RuntimeDependencies,
): Promise<PublishedPostResult> => {
  const id = dependencies.randomUUID();
  if (!UUID.test(id)) {
    throw new ApiError(
      500,
      "identifier_generation_failed",
      "The Blog post could not be published.",
    );
  }
  const publishedAt = new Date(dependencies.now()).toISOString();
  const slug = slugify(input.title, id);
  try {
    const insertion = await database
      .prepare(
        `INSERT INTO blog_posts (
         id, slug, title, summary, paragraphs_json, language, author, author_role,
         signature, published_at, created_at, actor_kind, actor_label,
         idempotency_key, publication_status
       ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15)
       ON CONFLICT(actor_kind, actor_label, idempotency_key) DO NOTHING`,
      )
      .bind(
        id,
        slug,
        input.title,
        input.summary,
        JSON.stringify(input.paragraphs),
        input.language,
        input.author,
        input.authorRole,
        input.signature,
        publishedAt,
        publishedAt,
        actor.kind,
        actor.label,
        idempotencyKey,
        "published",
      )
      .run();
    if (
      !insertion.success ||
      (insertion.meta?.changes !== 0 && insertion.meta?.changes !== 1)
    ) {
      throw new ApiError(
        503,
        "editorial_database_unavailable",
        "The Blog post could not be published because editorial storage is unavailable.",
      );
    }

    const existing = await database
      .prepare(
        `SELECT ${SELECT_COLUMNS}
       FROM blog_posts
       WHERE actor_kind = ?1 AND actor_label = ?2 AND idempotency_key = ?3`,
      )
      .bind(actor.kind, actor.label, idempotencyKey)
      .first<BlogRow>();
    if (!existing) {
      throw new ApiError(
        409,
        "publish_conflict",
        "The Blog post could not be published with this key.",
      );
    }
    return {
      post: rowToPost(existing),
      replayed: insertion.meta.changes === 0,
    };
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError(
      503,
      "editorial_database_unavailable",
      "The Blog post could not be published because editorial storage is unavailable.",
    );
  }
};
