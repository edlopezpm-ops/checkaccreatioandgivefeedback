import { ApiError } from "./http";
import type { BlogBindings, RuntimeDependencies } from "./platform";

const ACCESS_HEADER = "Cf-Access-Jwt-Assertion";
const MAX_TOKEN_BYTES = 16_384;
const MAX_JWKS_BYTES = 65_536;
const CLOCK_SKEW_SECONDS = 60;
const SAFE_LABEL = /^[a-z0-9](?:[a-z0-9-]{0,38}[a-z0-9])?$/;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const IDENTIFIER_CONTROL_CHARACTERS = /[\u0000-\u001f\u007f]/u;

type JsonObject = { readonly [key: string]: unknown };

interface AccessIdentity {
  readonly kind: "human" | "agent";
  readonly sensitiveIdentifier: string;
}

const encodeHumanIdentifier = (email: string, subject: string) =>
  JSON.stringify([email, subject]);

export interface AuthorizedActor {
  readonly kind: "human" | "agent";
  readonly label: string;
}

const isObject = (value: unknown): value is JsonObject =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const decodeBase64Url = (encoded: string) => {
  if (encoded.length === 0 || !/^[A-Za-z0-9_-]+$/.test(encoded)) {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }
  const padded = encoded
    .replaceAll("-", "+")
    .replaceAll("_", "/")
    .padEnd(Math.ceil(encoded.length / 4) * 4, "=");
  let binary: string;
  try {
    binary = atob(padded);
  } catch {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1)
    bytes[index] = binary.charCodeAt(index);
  return bytes;
};

const decodeTokenObject = (encoded: string) => {
  const bytes = decodeBase64Url(encoded);
  let text: string;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }
  let value: unknown;
  try {
    value = JSON.parse(text) as unknown;
  } catch {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }
  if (!isObject(value)) {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }
  return value;
};

const requireIssuer = (env: BlogBindings) => {
  const value = env.BLOG_ACCESS_ISSUER;
  if (!value)
    throw new ApiError(
      503,
      "access_configuration_unavailable",
      "Blog authentication is not configured.",
    );
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    throw new ApiError(
      503,
      "access_configuration_unavailable",
      "Blog authentication is not configured.",
    );
  }
  if (
    parsed.protocol !== "https:" ||
    !parsed.hostname.endsWith(".cloudflareaccess.com") ||
    parsed.pathname !== "/" ||
    parsed.search !== "" ||
    parsed.hash !== "" ||
    value !== parsed.origin
  ) {
    throw new ApiError(
      503,
      "access_configuration_unavailable",
      "Blog authentication is not configured.",
    );
  }
  return value;
};

const requireAudiences = (env: BlogBindings) => {
  let value: unknown;
  try {
    value = JSON.parse(env.BLOG_ACCESS_AUDIENCES ?? "") as unknown;
  } catch {
    throw new ApiError(
      503,
      "access_configuration_unavailable",
      "Blog authentication is not configured.",
    );
  }
  if (
    !Array.isArray(value) ||
    value.length === 0 ||
    value.length > 8 ||
    value.some(
      (audience) =>
        typeof audience !== "string" ||
        audience.length < 8 ||
        audience.length > 256,
    )
  ) {
    throw new ApiError(
      503,
      "access_configuration_unavailable",
      "Blog authentication is not configured.",
    );
  }
  return new Set(value);
};

const readBoundedJwks = async (response: Response) => {
  const declared = response.headers.get("Content-Length");
  if (declared && /^\d+$/.test(declared) && Number(declared) > MAX_JWKS_BYTES) {
    throw new ApiError(
      503,
      "access_keys_unavailable",
      "Blog authentication is temporarily unavailable.",
    );
  }
  if (!response.body) {
    throw new ApiError(
      503,
      "access_keys_unavailable",
      "Blog authentication is temporarily unavailable.",
    );
  }
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > MAX_JWKS_BYTES) {
      await reader.cancel().catch(() => undefined);
      throw new ApiError(
        503,
        "access_keys_unavailable",
        "Blog authentication is temporarily unavailable.",
      );
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(
      new TextDecoder("utf-8", { fatal: true }).decode(bytes),
    ) as unknown;
  } catch {
    throw new ApiError(
      503,
      "access_keys_unavailable",
      "Blog authentication is temporarily unavailable.",
    );
  }
  if (!isObject(parsed) || !Array.isArray(parsed.keys)) {
    throw new ApiError(
      503,
      "access_keys_unavailable",
      "Blog authentication is temporarily unavailable.",
    );
  }
  return parsed.keys;
};

const importSigningKey = async (
  issuer: string,
  keyId: string,
  dependencies: RuntimeDependencies,
) => {
  let response: Response;
  try {
    response = await dependencies.fetch(`${issuer}/cdn-cgi/access/certs`, {
      headers: { Accept: "application/json" },
      cache: "no-store",
      // Workers supports manual redirects; the response.ok check rejects 3xx.
      redirect: "manual",
    });
  } catch {
    throw new ApiError(
      503,
      "access_keys_unavailable",
      "Blog authentication is temporarily unavailable.",
    );
  }
  if (!response.ok) {
    throw new ApiError(
      503,
      "access_keys_unavailable",
      "Blog authentication is temporarily unavailable.",
    );
  }
  const keys = await readBoundedJwks(response);
  const candidate = keys.find(
    (value): value is JsonObject =>
      isObject(value) &&
      value.kid === keyId &&
      value.kty === "RSA" &&
      typeof value.n === "string" &&
      typeof value.e === "string" &&
      (value.alg === undefined || value.alg === "RS256") &&
      (value.use === undefined || value.use === "sig") &&
      (value.key_ops === undefined ||
        (Array.isArray(value.key_ops) && value.key_ops.includes("verify"))),
  );
  if (!candidate) {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }
  try {
    return await dependencies.subtle.importKey(
      "jwk",
      candidate,
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
      false,
      ["verify"],
    );
  } catch {
    throw new ApiError(
      503,
      "access_keys_unavailable",
      "Blog authentication is temporarily unavailable.",
    );
  }
};

const validateClaims = (
  claims: JsonObject,
  issuer: string,
  acceptedAudiences: ReadonlySet<string>,
  now: number,
) => {
  if (claims.iss !== issuer || claims.type !== "app") {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }
  if (
    !Array.isArray(claims.aud) ||
    claims.aud.length === 0 ||
    claims.aud.some(
      (audience) =>
        typeof audience !== "string" ||
        audience.length === 0 ||
        audience.length > 256,
    ) ||
    !claims.aud.some(
      (audience) =>
        typeof audience === "string" && acceptedAudiences.has(audience),
    )
  ) {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }
  const nowSeconds = Math.floor(now / 1000);
  if (
    !Number.isInteger(claims.exp) ||
    !Number.isInteger(claims.iat) ||
    (claims.nbf !== undefined && !Number.isInteger(claims.nbf)) ||
    (claims.exp as number) <= nowSeconds - CLOCK_SKEW_SECONDS ||
    (claims.iat as number) > nowSeconds + CLOCK_SKEW_SECONDS ||
    (typeof claims.nbf === "number" &&
      claims.nbf > nowSeconds + CLOCK_SKEW_SECONDS)
  ) {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }

  const hasEmail = Object.hasOwn(claims, "email");
  const hasCommonName = Object.hasOwn(claims, "common_name");
  if (
    hasEmail &&
    !hasCommonName &&
    typeof claims.email === "string" &&
    typeof claims.sub === "string" &&
    claims.sub.length > 0 &&
    claims.sub.length <= 256
  ) {
    const email = claims.email.trim().toLowerCase();
    if (
      email.length <= 320 &&
      EMAIL.test(email) &&
      !IDENTIFIER_CONTROL_CHARACTERS.test(claims.sub)
    ) {
      return {
        kind: "human",
        sensitiveIdentifier: encodeHumanIdentifier(email, claims.sub),
      } as const;
    }
  }
  if (
    !hasEmail &&
    hasCommonName &&
    claims.sub === "" &&
    typeof claims.common_name === "string" &&
    claims.common_name.length > 0 &&
    claims.common_name.length <= 256 &&
    !IDENTIFIER_CONTROL_CHARACTERS.test(claims.common_name)
  ) {
    return { kind: "agent", sensitiveIdentifier: claims.common_name } as const;
  }
  throw new ApiError(
    401,
    "invalid_access_token",
    "A valid Access session is required.",
  );
};

export const authenticateAccess = async (
  request: Request,
  env: BlogBindings,
  dependencies: RuntimeDependencies,
): Promise<AccessIdentity> => {
  const token = request.headers.get(ACCESS_HEADER);
  if (!token || token.length > MAX_TOKEN_BYTES) {
    throw new ApiError(
      401,
      "access_token_required",
      "A valid Access session is required.",
    );
  }
  const parts = token.split(".");
  if (parts.length !== 3) {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }
  const header = decodeTokenObject(parts[0]);
  if (
    header.alg !== "RS256" ||
    typeof header.kid !== "string" ||
    header.kid.length === 0 ||
    header.kid.length > 256 ||
    (header.typ !== undefined && header.typ !== "JWT") ||
    header.crit !== undefined
  ) {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }
  const issuer = requireIssuer(env);
  const acceptedAudiences = requireAudiences(env);
  const key = await importSigningKey(issuer, header.kid, dependencies);
  const signedBytes = new TextEncoder().encode(`${parts[0]}.${parts[1]}`);
  const signature = decodeBase64Url(parts[2]);
  const valid = await dependencies.subtle.verify(
    "RSASSA-PKCS1-v1_5",
    key,
    signature,
    signedBytes,
  );
  if (!valid) {
    throw new ApiError(
      401,
      "invalid_access_token",
      "A valid Access session is required.",
    );
  }
  return validateClaims(
    decodeTokenObject(parts[1]),
    issuer,
    acceptedAudiences,
    dependencies.now(),
  );
};

const parseAdminMap = (
  serialized: string | undefined,
  kind: "human" | "agent",
) => {
  let value: unknown;
  try {
    value = JSON.parse(serialized ?? "") as unknown;
  } catch {
    throw new ApiError(
      503,
      "admin_configuration_unavailable",
      "Blog administration is not configured.",
    );
  }
  if (!isObject(value) || Object.keys(value).length > 32) {
    throw new ApiError(
      503,
      "admin_configuration_unavailable",
      "Blog administration is not configured.",
    );
  }
  const entries: Array<readonly [string, string]> = [];
  const normalizedIdentifiers = new Set<string>();
  for (const [rawIdentifier, rawMapValue] of Object.entries(value)) {
    const normalizedEmail = rawIdentifier.trim().toLowerCase();
    const humanEntry =
      kind === "human" &&
      isObject(rawMapValue) &&
      Object.keys(rawMapValue).sort().join("\n") === "label\nsub" &&
      typeof rawMapValue.sub === "string" &&
      typeof rawMapValue.label === "string"
        ? { sub: rawMapValue.sub, label: rawMapValue.label }
        : null;
    const identifier =
      kind === "human" && humanEntry
        ? encodeHumanIdentifier(normalizedEmail, humanEntry.sub)
        : rawIdentifier;
    const label = kind === "human" ? humanEntry?.label : rawMapValue;
    if (
      identifier.length === 0 ||
      identifier.length > 640 ||
      (kind === "agent" && IDENTIFIER_CONTROL_CHARACTERS.test(identifier)) ||
      (kind === "human" &&
        (!humanEntry ||
          normalizedEmail.length > 320 ||
          !EMAIL.test(normalizedEmail) ||
          humanEntry.sub.length === 0 ||
          humanEntry.sub.length > 256 ||
          IDENTIFIER_CONTROL_CHARACTERS.test(humanEntry.sub))) ||
      typeof label !== "string" ||
      !SAFE_LABEL.test(label) ||
      normalizedIdentifiers.has(identifier)
    ) {
      throw new ApiError(
        503,
        "admin_configuration_unavailable",
        "Blog administration is not configured.",
      );
    }
    normalizedIdentifiers.add(identifier);
    entries.push([identifier, label]);
  }
  return entries;
};

const constantTimeEqual = (left: Uint8Array, right: Uint8Array) => {
  if (left.byteLength !== right.byteLength) return false;
  let difference = 0;
  for (let index = 0; index < left.byteLength; index += 1)
    difference |= left[index] ^ right[index];
  return difference === 0;
};

export const authorizePublisher = async (
  identity: AccessIdentity,
  env: BlogBindings,
  dependencies: RuntimeDependencies,
): Promise<AuthorizedActor | null> => {
  const entries = parseAdminMap(
    identity.kind === "human" ? env.BLOG_HUMAN_ADMINS : env.BLOG_AGENT_ADMINS,
    identity.kind,
  );
  const presentedDigest = new Uint8Array(
    await dependencies.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(identity.sensitiveIdentifier),
    ),
  );
  let matchedLabel: string | null = null;
  for (const [identifier, label] of entries) {
    const configuredDigest = new Uint8Array(
      await dependencies.subtle.digest(
        "SHA-256",
        new TextEncoder().encode(identifier),
      ),
    );
    if (constantTimeEqual(presentedDigest, configuredDigest))
      matchedLabel = label;
  }
  return matchedLabel ? { kind: identity.kind, label: matchedLabel } : null;
};
