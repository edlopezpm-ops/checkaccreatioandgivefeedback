export const SECURITY_HEADERS = {
  "Strict-Transport-Security": "max-age=86400",
  "Referrer-Policy": "no-referrer",
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
} as const;

const JSON_HEADERS = {
  ...SECURITY_HEADERS,
  "Cache-Control": "no-store",
  "Content-Type": "application/json; charset=utf-8",
} as const;

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly publicMessage: string;
  readonly retryAfterSeconds?: number;

  constructor(
    status: number,
    code: string,
    publicMessage: string,
    retryAfterSeconds?: number,
  ) {
    super(code);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.publicMessage = publicMessage;
    // Response metadata is numeric only; never accept request-authored headers.
    if (
      typeof retryAfterSeconds === "number" &&
      Number.isFinite(retryAfterSeconds) &&
      retryAfterSeconds > 0
    )
      this.retryAfterSeconds = Math.min(86_400, Math.ceil(retryAfterSeconds));
  }
}

export const jsonResponse = (
  value: unknown,
  status = 200,
  extraHeaders?: HeadersInit,
) => {
  const headers = new Headers(JSON_HEADERS);
  if (extraHeaders) {
    new Headers(extraHeaders).forEach((headerValue, headerName) => {
      headers.set(headerName, headerValue);
    });
  }
  return new Response(JSON.stringify(value), { status, headers });
};

export const errorResponse = (error: unknown, route: string) => {
  if (error instanceof ApiError) {
    logOperationalError(route, error.status, error.code);
    return jsonResponse(
      { error: { code: error.code, message: error.publicMessage } },
      error.status,
      error.retryAfterSeconds === undefined
        ? undefined
        : { "Retry-After": String(error.retryAfterSeconds) },
    );
  }
  logOperationalError(route, 500, "internal_error");
  return jsonResponse(
    {
      error: {
        code: "internal_error",
        message: "The Blog service could not complete this request.",
      },
    },
    500,
  );
};

export const methodNotAllowed = (allowed: readonly string[]) =>
  jsonResponse(
    {
      error: {
        code: "method_not_allowed",
        message: "This method is not supported.",
      },
    },
    405,
    { Allow: allowed.join(", ") },
  );

const parseContentLength = (headers: Headers) => {
  const header = headers.get("Content-Length");
  if (header === null) return null;
  if (!/^\d+$/.test(header)) {
    throw new ApiError(
      400,
      "invalid_content_length",
      "The request size header is invalid.",
    );
  }
  const length = Number(header);
  if (!Number.isSafeInteger(length)) {
    throw new ApiError(
      400,
      "invalid_content_length",
      "The request size header is invalid.",
    );
  }
  return length;
};

export const readBoundedJson = async (
  request: Request,
  maximumBytes: number,
): Promise<unknown> => {
  const mediaType = request.headers
    .get("Content-Type")
    ?.split(";", 1)[0]
    ?.trim()
    .toLowerCase();
  if (mediaType !== "application/json") {
    throw new ApiError(
      415,
      "unsupported_media_type",
      "Content-Type must be application/json.",
    );
  }
  const declaredLength = parseContentLength(request.headers);
  if (declaredLength !== null && declaredLength > maximumBytes) {
    throw new ApiError(
      413,
      "payload_too_large",
      "The Blog post exceeds the allowed request size.",
    );
  }
  if (!request.body) {
    throw new ApiError(400, "empty_body", "A JSON Blog post is required.");
  }

  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > maximumBytes) {
      await reader.cancel().catch(() => undefined);
      throw new ApiError(
        413,
        "payload_too_large",
        "The Blog post exceeds the allowed request size.",
      );
    }
    chunks.push(value);
  }

  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }

  let text: string;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    throw new ApiError(
      400,
      "invalid_encoding",
      "The request must contain valid UTF-8 JSON.",
    );
  }
  try {
    return JSON.parse(text) as unknown;
  } catch {
    throw new ApiError(
      400,
      "invalid_json",
      "The request body is not valid JSON.",
    );
  }
};

const logOperationalError = (
  route: string,
  status: number,
  errorClass: string,
) => {
  // Fixed fields only: never add request headers, claims, identifiers, or post content.
  console.error(
    JSON.stringify({ event: "blog_api_error", route, status, errorClass }),
  );
};
