import type { AccountDatabase } from "./accounts";
import { ApiError, jsonResponse } from "./http";
import { keyedHash } from "./auth/privacy";
import type { BlogPreparedStatement, DatabaseValue } from "./platform";

const NOW = "(unixepoch() * 1000)";
const MINUTE = 60_000;
const HOUR = 3_600_000;
const RECURRENCE = 172_800_000;
const MAX_BUCKETS = 8192;
const MAX_ANONYMOUS_BUCKETS = 4096;
const RIGHTS_RESERVED_BUCKETS = 512;
const MAX_ACCOUNT_STATES = 4096;

/** Fixed classes prevent attacker-controlled paths from allocating new keys. */
export const ABUSE_ROUTES = {
  "public-read": { network: 180 },
  "auth-start": { network: 20 },
  "auth-status": { network: 120 },
  "otp-request": { network: 12 },
  "otp-verify": { network: 60 },
  "account-read": { network: 360, account: 120, session: 90 },
  "account-write": { network: 120, account: 30, session: 20 },
  "export-authorize": { network: 60, account: 12, session: 8 },
  rights: { network: 180, account: 12, session: 8 },
  callback: { network: 180 },
} as const;
export type AbuseRoute = keyof typeof ABUSE_ROUTES;
export interface AbusePrincipal {
  readonly accountId: string;
  readonly tokenHash: string;
}
export interface AbuseRequest {
  readonly db: AccountDatabase;
  readonly secret: string | undefined;
  readonly request: Request;
  readonly route: AbuseRoute;
  readonly principal?: AbusePrincipal;
  /** Middleware already charged the network budget for this request. */
  readonly networkChecked?: boolean;
  readonly skipNetwork?: boolean;
  /** True only after full authentication, input and business eligibility checks.
   * Never set for expired sessions, malformed input or exhausted product quota. */
  readonly sanctionEligible?: boolean;
}
interface Dimension {
  key: string;
  kind: "network" | "account" | "session";
  limit: number;
}

export class AbuseError extends ApiError {
  readonly retryAfter: number;
  readonly suspendedUntil?: string;
  constructor(retryAfter: number, suspendedUntil?: string) {
    const seconds = Number.isFinite(retryAfter)
      ? Math.max(1, Math.min(86_400, Math.ceil(retryAfter)))
      : 60;
    super(
      429,
      suspendedUntil ? "account_suspended" : "request_rate_limited",
      suspendedUntil
        ? "This account is temporarily restricted. Account controls remain available."
        : "Please wait before trying again.",
      seconds,
    );
    this.retryAfter = seconds;
    this.suspendedUntil = suspendedUntil;
  }
}

export function abuseErrorResponse(error: unknown): Response | null {
  if (!(error instanceof AbuseError)) return null;
  return jsonResponse(
    {
      error: {
        code: error.code,
        message: error.publicMessage,
        retryAfter: error.retryAfter,
        ...(error.suspendedUntil
          ? { suspendedUntil: error.suspendedUntil }
          : {}),
      },
    },
    429,
    { "Retry-After": String(error.retryAfter) },
  );
}

/** The argument is a developer-owned SQL reference, never request input. */
export function ABUSE_ALLOWED_SQL(accountReference = "accounts.id") {
  if (!/^[a-z_][a-z0-9_]*(?:\.[a-z_][a-z0-9_]*)?$/i.test(accountReference))
    throw new Error("invalid_abuse_account_reference");
  return `NOT EXISTS(SELECT 1 FROM account_abuse_state WHERE account_id=${accountReference} AND suspended_until>${NOW})`;
}

const unavailable = (): never => {
  throw new ApiError(
    503,
    "abuse_guard_unavailable",
    "Account protection is temporarily unavailable. Your draft is still here.",
  );
};

function ipv4(value: string) {
  const parts = value.split(".");
  return parts.length === 4 &&
    parts.every((part) => /^\d{1,3}$/.test(part) && Number(part) <= 255)
    ? parts.map(Number).join(".")
    : null;
}
function ipv6(value: string) {
  if (!/^[a-f0-9:.]+$/i.test(value) || !value.includes(":")) return null;
  try {
    return new URL(`http://[${value}]/`).hostname.slice(1, -1).toLowerCase();
  } catch {
    return null;
  }
}
function ipv6Network(value: string) {
  const [left, right] = value.split("::");
  const start = left ? left.split(":") : [];
  const end = right ? right.split(":") : [];
  const expanded = value.includes("::")
    ? [...start, ...Array(8 - start.length - end.length).fill("0"), ...end]
    : start;
  if (expanded.length !== 8) return null;
  if (
    expanded.slice(0, 5).every((part) => Number.parseInt(part, 16) === 0) &&
    Number.parseInt(expanded[5], 16) === 0xffff
  ) {
    const high = Number.parseInt(expanded[6], 16);
    const low = Number.parseInt(expanded[7], 16);
    return `v4:${high >>> 8}.${high & 255}.${low >>> 8}.${low & 255}`;
  }
  return `v6:${expanded
    .slice(0, 4)
    .map((part) => Number.parseInt(part, 16).toString(16))
    .join(":")}/64`;
}

/** Pages edge ingress supplies these headers. Never use X-Forwarded-For/body
 * values. Cross-zone Worker placeholder IPs do not identify an end user. */
export async function abuseNetworkKey(secret: string, request: Request) {
  const value = request.headers.get("CF-Connecting-IP")?.trim();
  if (!value || value.length > 64) return null;
  let address = ipv4(value);
  let normalized: string | null = address ? `v4:${address}` : null;
  if (address && Number(address.split(".")[0]) >= 240) {
    const original = request.headers.get("CF-Connecting-IPv6")?.trim();
    normalized =
      original && original.length <= 64
        ? ipv6Network(ipv6(original) ?? "")
        : null;
  } else if (!address) {
    address = ipv6(value);
    if (address === "2a06:98c0:3600::103") return null;
    normalized = address ? ipv6Network(address) : null;
  }
  if (!normalized) return null;
  return `n1:${await keyedHash(secret, JSON.stringify(["accreatio.abuse.network.v1", normalized]))}`;
}

export async function getAbuseAccountStatus(
  db: AccountDatabase,
  accountId: string,
) {
  try {
    const row = await db
      .prepare(
        `SELECT suspended_until AS suspendedUntil FROM account_abuse_state WHERE account_id=? AND suspended_until>${NOW}`,
      )
      .bind(accountId)
      .first<{ suspendedUntil: number }>();
    return {
      suspended: Boolean(row),
      suspendedUntil: row ? new Date(row.suspendedUntil).toISOString() : null,
    };
  } catch {
    return unavailable();
  }
}

/** Cleanup is bounded even if hourly scheduling has accumulated a backlog. */
export async function maintainAbuse(db: AccountDatabase) {
  try {
    const result = await db.batch([
      db.prepare(
        `DELETE FROM account_abuse_buckets WHERE rowid IN(SELECT rowid FROM account_abuse_buckets WHERE expires_at<=${NOW} LIMIT 500)`,
      ),
      db.prepare(
        `DELETE FROM account_abuse_state WHERE account_id IN(SELECT account_id FROM account_abuse_state WHERE expires_at<=${NOW} AND suspended_until<=${NOW} LIMIT 500)`,
      ),
    ]);
    if (result.some((entry) => !entry.success)) return unavailable();
  } catch {
    return unavailable();
  }
}

export async function enforceAbuse(input: AbuseRequest): Promise<void> {
  try {
    const { db, request, route, principal } = input;
    if (
      !Object.hasOwn(ABUSE_ROUTES, route) ||
      !input.secret ||
      !/^[a-f0-9]{64}$/.test(input.secret)
    )
      return unavailable();
    const safeRoute = route === "rights" || route === "callback";
    const rule = ABUSE_ROUTES[route] as {
      network: number;
      account?: number;
      session?: number;
    };
    const dimensions: Dimension[] = [];
    const network = await abuseNetworkKey(input.secret, request);
    if (
      network &&
      !input.networkChecked &&
      !input.skipNetwork &&
      !(principal && route === "rights")
    )
      dimensions.push({ key: network, kind: "network", limit: rule.network });
    if (principal) {
      if (
        !principal.accountId ||
        principal.accountId.length > 128 ||
        !/^[a-f0-9]{64}$/.test(principal.tokenHash)
      )
        throw new ApiError(401, "sign_in_required", "Sign in to continue.");
      if (rule.account)
        dimensions.push({
          key: `a1:${await keyedHash(input.secret, JSON.stringify(["accreatio.abuse.account.v1", principal.accountId]))}`,
          kind: "account",
          limit: rule.account,
        });
      if (rule.session)
        dimensions.push({
          key: `s1:${await keyedHash(input.secret, JSON.stringify(["accreatio.abuse.session.v1", principal.tokenHash]))}`,
          kind: "session",
          limit: rule.session,
        });
    }
    // Missing edge provenance never creates a shared "unknown IP" ban.
    if (!dimensions.length) return unavailable();
    const accountId = principal?.accountId ?? "";
    const tokenHash = principal?.tokenHash ?? "";
    const validPrincipal = principal
      ? `EXISTS(SELECT 1 FROM account_sessions s JOIN accounts a ON a.id=s.account_id LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash WHERE s.token_hash=? AND s.account_id=? AND s.expires_at>${NOW} AND a.deleted_at IS NULL AND (m.token_hash IS NULL OR m.security_version=a.security_version) ${safeRoute ? "" : "AND COALESCE(m.rights_only,0)=0"})`
      : "1";
    const parameters: DatabaseValue[] = dimensions.flatMap((dimension) => [
      dimension.key,
      dimension.kind,
      dimension.limit,
    ]);
    if (principal) parameters.push(tokenHash, accountId);
    parameters.push(route, accountId);
    const windowStart = `CAST(${NOW}/${MINUTE} AS INTEGER)*${MINUTE}`;
    const requested = dimensions.map(() => "(?,?,?)").join(",");
    // A request inside an existing cooldown is only denied. It cannot become
    // another attributable episode, even after the account episode clock moves.
    const bucketFull = `(b.blocked_until<=${NOW} AND b.window_start=${windowStart} AND b.request_count>=r.request_limit AND b.last_excess_at<=${NOW}-${MINUTE})`;
    const gateSql = `WITH requested(scope_key,scope_kind,request_limit) AS(VALUES ${requested}),
      auth AS(SELECT ${validPrincipal} AS valid),
      existing AS(SELECT r.*,b.window_start,b.request_count,b.blocked_until,b.last_excess_at FROM requested r LEFT JOIN account_abuse_buckets b ON b.scope_key=r.scope_key AND b.route_class=?),
      blocking AS(SELECT COALESCE(MAX(CASE WHEN b.blocked_until>${NOW} THEN b.blocked_until WHEN b.window_start=${windowStart} AND b.request_count>=r.request_limit THEN ${windowStart}+${MINUTE} ELSE 0 END),0) AS retry_at,
        COALESCE(MAX(CASE WHEN b.blocked_until>${NOW} THEN 1 ELSE 0 END),0) AS cooling,
        COALESCE(MAX(CASE WHEN r.scope_kind IN('account','session') AND ${bucketFull} THEN 1 ELSE 0 END),0) AS own_excess FROM requested r LEFT JOIN existing b ON b.scope_key=r.scope_key),
      state AS(SELECT COALESCE(MAX(suspended_until),0) AS suspended_until,COALESCE(MAX(revision),0) AS revision FROM account_abuse_state WHERE account_id=?),
      capacity AS(SELECT (SELECT COUNT(*) FROM account_abuse_buckets)+(SELECT COUNT(*) FROM existing WHERE window_start IS NULL) AS total,
        (SELECT COUNT(*) FROM account_abuse_buckets WHERE scope_kind='network')+(SELECT COUNT(*) FROM existing WHERE window_start IS NULL AND scope_kind='network') AS anonymous),
      decision AS(SELECT CASE WHEN auth.valid=0 THEN 'authentication'
        WHEN ${safeRoute ? "0" : "state.suspended_until>" + NOW} THEN 'suspension'
        WHEN capacity.total>${safeRoute ? MAX_BUCKETS : MAX_BUCKETS - RIGHTS_RESERVED_BUCKETS} OR capacity.anonymous>${principal ? MAX_BUCKETS : MAX_ANONYMOUS_BUCKETS} THEN 'capacity'
        WHEN blocking.cooling=1 THEN 'cooldown'
        WHEN blocking.retry_at>${NOW} THEN 'rate' ELSE 'allow' END AS reason,
        auth.valid,blocking.own_excess,blocking.retry_at,state.suspended_until,state.revision FROM auth,blocking,state,capacity)
      UPDATE account_abuse_gate SET allowed=(SELECT reason='allow' FROM decision),principal_valid=(SELECT valid FROM decision),own_excess=(SELECT own_excess FROM decision),retry_at=(SELECT retry_at FROM decision),suspended_until=(SELECT suspended_until FROM decision),prior_revision=(SELECT revision FROM decision),reason=(SELECT reason FROM decision) WHERE id=1`;
    const statements: BlogPreparedStatement[] = [
      db.prepare(
        `DELETE FROM account_abuse_buckets WHERE rowid IN(SELECT rowid FROM account_abuse_buckets WHERE expires_at<=${NOW} LIMIT 25)`,
      ),
      db.prepare(
        `DELETE FROM account_abuse_state WHERE account_id IN(SELECT account_id FROM account_abuse_state WHERE expires_at<=${NOW} AND suspended_until<=${NOW} LIMIT 25)`,
      ),
      db.prepare(gateSql).bind(...parameters),
    ];
    for (const dimension of dimensions) {
      statements.push(
        db
          .prepare(
            `INSERT INTO account_abuse_buckets(scope_key,scope_kind,route_class,window_start,request_count,expires_at)
        SELECT ?,?,?,${windowStart},1,${NOW}+${HOUR} WHERE EXISTS(SELECT 1 FROM account_abuse_gate WHERE id=1 AND allowed=1)
        ON CONFLICT(scope_key,route_class) DO UPDATE SET window_start=excluded.window_start,request_count=CASE WHEN account_abuse_buckets.window_start=excluded.window_start THEN MIN(account_abuse_buckets.request_count+1,?) ELSE 1 END,
        strikes=CASE WHEN account_abuse_buckets.last_excess_at<=${NOW}-900000 THEN 0 ELSE account_abuse_buckets.strikes END,expires_at=excluded.expires_at`,
          )
          .bind(dimension.key, dimension.kind, route, dimension.limit),
      );
      if (!safeRoute) {
        const nextStrike = `CASE WHEN last_excess_at<=${NOW}-900000 THEN 1 ELSE MIN(strikes+1,5) END`;
        statements.push(
          db
            .prepare(
              `UPDATE account_abuse_buckets SET strikes=${nextStrike},blocked_until=${NOW}+CASE ${nextStrike} WHEN 1 THEN 30000 WHEN 2 THEN 60000 WHEN 3 THEN 120000 WHEN 4 THEN 300000 ELSE 900000 END,last_excess_at=${NOW},expires_at=${NOW}+${HOUR}
          WHERE scope_key=? AND route_class=? AND (blocked_until<=${NOW}) AND (last_excess_at<=${NOW}-${MINUTE}) AND window_start=${windowStart} AND request_count>=? AND EXISTS(SELECT 1 FROM account_abuse_gate WHERE id=1 AND reason='rate' AND principal_valid=1)`,
            )
            .bind(dimension.key, route, dimension.limit),
        );
      }
    }
    if (principal && !safeRoute && input.sanctionEligible === true) {
      // Only the two latest pending episode times are needed for an exact
      // rolling three-in-ten-minute decision, without an event-history table.
      const nextCount = `CASE WHEN excess_count=0 OR last_episode_at<=${NOW}-600000 THEN 1 WHEN excess_count=2 AND episode_window_start>${NOW}-600000 THEN 3 ELSE 2 END`;
      const priorLevel = `CASE WHEN recurrence_until>${NOW} THEN level ELSE 0 END`;
      const nextLevel = `MIN((${priorLevel})+1,3)`;
      const sanction = `CASE ${nextLevel} WHEN 1 THEN 600000 WHEN 2 THEN 3600000 ELSE 86400000 END`;
      statements.push(
        db
          .prepare(
            `INSERT INTO account_abuse_state(account_id,level,excess_count,episode_window_start,last_episode_at,suspended_until,recurrence_until,expires_at)
        SELECT ?,0,1,${NOW},${NOW},0,${NOW}+${RECURRENCE},${NOW}+${RECURRENCE}
        WHERE (EXISTS(SELECT 1 FROM account_abuse_state WHERE account_id=?) OR (SELECT COUNT(*) FROM account_abuse_state)<${MAX_ACCOUNT_STATES})
        AND EXISTS(SELECT 1 FROM account_abuse_gate WHERE id=1 AND reason='rate' AND principal_valid=1 AND own_excess=1)
        ON CONFLICT(account_id) DO UPDATE SET
          level=CASE WHEN (${nextCount})>=3 THEN ${nextLevel} ELSE (${priorLevel}) END,
          excess_count=CASE WHEN (${nextCount})>=3 THEN 0 ELSE (${nextCount}) END,
          episode_window_start=CASE WHEN excess_count=0 OR last_episode_at<=${NOW}-600000 OR (${nextCount})>=3 THEN ${NOW} WHEN excess_count=2 AND episode_window_start<=${NOW}-600000 THEN last_episode_at ELSE episode_window_start END,
          suspended_until=CASE WHEN (${nextCount})>=3 THEN ${NOW}+(${sanction}) ELSE suspended_until END,
          recurrence_until=CASE WHEN (${nextCount})>=3 THEN ${NOW}+${RECURRENCE} ELSE recurrence_until END,
          expires_at=${NOW}+${RECURRENCE},
          revision=revision+CASE WHEN (${nextCount})>=3 THEN 1 ELSE 0 END,last_episode_at=${NOW}
        WHERE suspended_until<=${NOW} AND last_episode_at<=${NOW}-${MINUTE}`,
          )
          .bind(accountId, accountId),
      );
      const transitioned = `EXISTS(SELECT 1 FROM account_abuse_state a,account_abuse_gate g WHERE a.account_id=? AND a.revision>g.prior_revision AND a.suspended_until>${NOW} AND g.reason='rate')`;
      statements.push(
        db
          .prepare(
            `UPDATE accounts SET security_version=security_version+1 WHERE id=? AND ${transitioned}`,
          )
          .bind(accountId, accountId),
      );
      statements.push(
        db
          .prepare(
            `DELETE FROM account_sessions WHERE account_id=? AND NOT EXISTS(SELECT 1 FROM account_session_metadata m WHERE m.token_hash=account_sessions.token_hash AND m.rights_only=1) AND ${transitioned}`,
          )
          .bind(accountId, accountId),
      );
    }
    statements.push(
      db
        .prepare(
          `SELECT g.allowed,g.reason,g.principal_valid AS principalValid,
      MAX(g.retry_at,COALESCE((SELECT MAX(blocked_until) FROM account_abuse_buckets WHERE route_class=? AND scope_key IN(${dimensions.map(() => "?").join(",")})),0)) AS retryAt,
      CASE WHEN ?=1 THEN 0 ELSE COALESCE((SELECT suspended_until FROM account_abuse_state WHERE account_id=?),0) END AS suspendedUntil,${NOW} AS now FROM account_abuse_gate g WHERE g.id=1`,
        )
        .bind(
          route,
          ...dimensions.map((dimension) => dimension.key),
          safeRoute ? 1 : 0,
          accountId,
        ),
    );
    const result = await db.batch(statements);
    if (result.some((entry) => !entry.success)) return unavailable();
    const row = result.at(-1)?.results?.[0] as
      | {
          allowed: number;
          reason: string;
          principalValid: number;
          retryAt: number;
          suspendedUntil: number;
          now: number;
        }
      | undefined;
    if (!row) return unavailable();
    if (!row.principalValid)
      throw new ApiError(401, "sign_in_required", "Sign in to continue.");
    if (row.suspendedUntil > row.now)
      throw new AbuseError(
        (row.suspendedUntil - row.now) / 1000,
        new Date(row.suspendedUntil).toISOString(),
      );
    if (row.reason === "capacity") return unavailable();
    if (!row.allowed) throw new AbuseError((row.retryAt - row.now) / 1000);
  } catch (error) {
    if (error instanceof ApiError) throw error;
    return unavailable();
  }
}
