import { ApiError } from "../http";
import { cleanCollection } from "../collection";
import { ACCOUNT_POLICY } from "../../../shared/accountPolicy";
import { CLEAR_TRANSACTION_POLICY_SQL } from "./policy";
import type { AccountBindings, AccountDatabase } from "../accounts";
import { runtimeDependencies, type RuntimeDependencies } from "../platform";

export const AUTH_NOW_SQL = "(unixepoch() * 1000)";
export const AUTH_RETENTION_MS = 172_800_000;
export const PRIVACY_NOTICE_VERSION = ACCOUNT_POLICY.privacyNoticeVersion;
const utf8 = new TextEncoder();
export const toHex = (bytes: ArrayBuffer | Uint8Array) =>
  Array.from(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes), (b) =>
    b.toString(16).padStart(2, "0"),
  ).join("");
const fromHex = (value: string) =>
  Uint8Array.from(value.match(/../g) ?? [], (byte) => parseInt(byte, 16));
const unavailable = (): never => {
  throw new ApiError(
    503,
    "account_unavailable",
    "Account service is temporarily unavailable.",
  );
};

function keyMaterial(
  env: AccountBindings,
  name:
    | "ACCOUNT_EMAIL_ENCRYPTION_KEY"
    | "ACCOUNT_EMAIL_LOOKUP_KEY"
    | "ACCOUNT_AUTH_LOCATOR_KEY",
) {
  const value = env[name];
  if (!value || !/^[a-f0-9]{64}$/.test(value)) return unavailable();
  const keys = [
    env.ACCOUNT_EMAIL_ENCRYPTION_KEY,
    env.ACCOUNT_EMAIL_LOOKUP_KEY,
    env.ACCOUNT_AUTH_LOCATOR_KEY,
    env.ACCOUNT_OIDC_TRANSACTION_KEY,
    env.ACCOUNT_IDENTITY_KEY,
    env.ACCOUNT_OTP_KEY,
  ].filter(Boolean);
  if (new Set(keys).size !== keys.length) return unavailable();
  return value;
}
export function privacyConfigured(env: AccountBindings) {
  try {
    keyMaterial(env, "ACCOUNT_EMAIL_ENCRYPTION_KEY");
    keyMaterial(env, "ACCOUNT_EMAIL_LOOKUP_KEY");
    keyMaterial(env, "ACCOUNT_AUTH_LOCATOR_KEY");
    return true;
  } catch {
    return false;
  }
}
export async function keyedHash(
  secret: string,
  value: string,
  deps = runtimeDependencies(),
) {
  const key = await deps.subtle.importKey(
    "raw",
    utf8.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return toHex(await deps.subtle.sign("HMAC", key, utf8.encode(value)));
}
export async function emailLookup(
  email: string,
  env: AccountBindings,
  deps = runtimeDependencies(),
) {
  return `v1:${await keyedHash(keyMaterial(env, "ACCOUNT_EMAIL_LOOKUP_KEY"), email.trim().toLowerCase(), deps)}`;
}
export async function externalLocator(
  issuer: string,
  subject: string,
  env: AccountBindings,
  deps = runtimeDependencies(),
) {
  return `v1:${await keyedHash(keyMaterial(env, "ACCOUNT_AUTH_LOCATOR_KEY"), JSON.stringify(["external-subject-v1", issuer, subject]), deps)}`;
}
export async function protectEmail(
  email: string,
  accountId: string,
  env: AccountBindings,
  deps = runtimeDependencies(),
) {
  const key = await deps.subtle.importKey(
    "raw",
    fromHex(keyMaterial(env, "ACCOUNT_EMAIL_ENCRYPTION_KEY")),
    "AES-GCM",
    false,
    ["encrypt"],
  );
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await deps.subtle.encrypt(
    {
      name: "AES-GCM",
      iv,
      tagLength: 128,
      additionalData: utf8.encode(
        JSON.stringify(["email-v1", "accreatio", accountId]),
      ),
    },
    key,
    utf8.encode(email),
  );
  return {
    ciphertext: `v1:${toHex(iv)}:${toHex(encrypted)}`,
    keyVersion: "v1",
    lookupKey: await emailLookup(email, env, deps),
  };
}
export interface EmailRecord {
  id: string;
  email: string | null;
  email_ciphertext?: string | null;
  email_encryption_key_version?: string | null;
  display_name_ciphertext?: string | null;
}

/** Presentation only: never an account identifier, email proof or authority. */
export function normalizeDisplayName(value: unknown): string | null {
  if (
    typeof value !== "string" ||
    value.length > 512 ||
    /[\p{Cc}\p{Cf}\p{Cs}]/u.test(value)
  )
    return null;
  const name = value.normalize("NFC").trim().replace(/ +/g, " ");
  return name && [...name].length <= 120 && utf8.encode(name).length <= 512
    ? name
    : null;
}

export function fallbackDisplayName(email: string | null | undefined) {
  return email?.split("@")[0] || "Account";
}

export async function protectDisplayName(
  name: string,
  accountId: string,
  env: AccountBindings,
  deps = runtimeDependencies(),
) {
  const normalized = normalizeDisplayName(name);
  if (!normalized) return unavailable();
  const key = await deps.subtle.importKey(
    "raw",
    fromHex(keyMaterial(env, "ACCOUNT_EMAIL_ENCRYPTION_KEY")),
    "AES-GCM",
    false,
    ["encrypt"],
  );
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await deps.subtle.encrypt(
    {
      name: "AES-GCM",
      iv,
      tagLength: 128,
      additionalData: utf8.encode(
        JSON.stringify(["display-name-v1", "accreatio", accountId]),
      ),
    },
    key,
    utf8.encode(normalized),
  );
  return `v1:${toHex(iv)}:${toHex(encrypted)}`;
}

export async function revealDisplayName(
  row: EmailRecord,
  env: AccountBindings,
  deps = runtimeDependencies(),
): Promise<string | null> {
  if (!row.display_name_ciphertext) return null;
  if (
    !/^v1:[a-f0-9]{24}:(?:[a-f0-9]{2}){17,528}$/.test(
      row.display_name_ciphertext,
    )
  )
    return unavailable();
  const [, nonce, ciphertext] = row.display_name_ciphertext.split(":");
  try {
    const key = await deps.subtle.importKey(
      "raw",
      fromHex(keyMaterial(env, "ACCOUNT_EMAIL_ENCRYPTION_KEY")),
      "AES-GCM",
      false,
      ["decrypt"],
    );
    const plain = await deps.subtle.decrypt(
      {
        name: "AES-GCM",
        iv: fromHex(nonce),
        tagLength: 128,
        additionalData: utf8.encode(
          JSON.stringify(["display-name-v1", "accreatio", row.id]),
        ),
      },
      key,
      fromHex(ciphertext),
    );
    const value = normalizeDisplayName(
      new TextDecoder("utf-8", { fatal: true }).decode(plain),
    );
    if (!value) return unavailable();
    return value;
  } catch {
    return unavailable();
  }
}
export async function revealEmail(
  row: EmailRecord,
  env: AccountBindings,
  deps = runtimeDependencies(),
): Promise<string | null> {
  if (!row.email_ciphertext) return row.email; // Bounded expand/contract migration reader.
  if (
    row.email_encryption_key_version !== "v1" ||
    !/^v1:[a-f0-9]{24}:[a-f0-9]{34,1200}$/.test(row.email_ciphertext)
  )
    return unavailable();
  const [, nonce, ciphertext] = row.email_ciphertext.split(":");
  if (ciphertext.length % 2) return unavailable();
  try {
    const key = await deps.subtle.importKey(
      "raw",
      fromHex(keyMaterial(env, "ACCOUNT_EMAIL_ENCRYPTION_KEY")),
      "AES-GCM",
      false,
      ["decrypt"],
    );
    const plain = await deps.subtle.decrypt(
      {
        name: "AES-GCM",
        iv: fromHex(nonce),
        tagLength: 128,
        additionalData: utf8.encode(
          JSON.stringify(["email-v1", "accreatio", row.id]),
        ),
      },
      key,
      fromHex(ciphertext),
    );
    return new TextDecoder("utf-8", { fatal: true }).decode(plain);
  } catch {
    return unavailable();
  }
}

/** Idempotent bounded backfill; CAS prevents overwriting deletion or a newer email. */
export async function backfillEmails(
  env: AccountBindings,
  deps = runtimeDependencies(),
  limit = 100,
) {
  if (!env.ACCOUNT_DB || !privacyConfigured(env)) return unavailable();
  const db = env.ACCOUNT_DB;
  const rows = await db
    .prepare(
      "SELECT id, email FROM accounts WHERE email IS NOT NULL AND deleted_at IS NULL ORDER BY id LIMIT ?",
    )
    .bind(Math.min(100, Math.max(1, limit)))
    .all<{ id: string; email: string }>();
  if (!rows.success || !rows.results) return unavailable();
  for (const row of rows.results) {
    const encrypted = await protectEmail(row.email, row.id, env, deps);
    const result = await db
      .prepare(
        `UPDATE accounts SET email_ciphertext = ?, email_encryption_key_version = ?, email_lookup_key = ?, email_verification_source = COALESCE(email_verification_source, 'legacy-email-otp'), email = NULL WHERE id = ? AND email = ? AND deleted_at IS NULL`,
      )
      .bind(
        encrypted.ciphertext,
        encrypted.keyVersion,
        encrypted.lookupKey,
        row.id,
        row.email,
      )
      .run();
    if (!result.success) return unavailable();
  }
  return rows.results.length;
}

/** Scheduled hourly and also safe to call opportunistically; no logs or PII results. */
export async function maintainAccounts(db: AccountDatabase) {
  const now = AUTH_NOW_SQL;
  const results = await db.batch([
    db.prepare(
      `UPDATE account_auth_transactions SET status = 'expired', secrets_ciphertext = NULL, previous_session_token_hash = NULL,issued_session_token_hash=NULL,${CLEAR_TRANSACTION_POLICY_SQL} WHERE id IN (SELECT id FROM account_auth_transactions WHERE expires_at <= ${now} AND (secrets_ciphertext IS NOT NULL OR status IN ('created', 'claimed') OR policy_authorized_at IS NOT NULL OR issued_session_token_hash IS NOT NULL) LIMIT 500)`,
    ),
    db.prepare(
      `DELETE FROM account_auth_transactions WHERE id IN (SELECT id FROM account_auth_transactions WHERE created_at <= ${now} - 3600000 LIMIT 500)`,
    ),
    db.prepare(
      `DELETE FROM account_sessions WHERE token_hash IN (SELECT token_hash FROM account_sessions WHERE expires_at <= ${now} LIMIT 500)`,
    ),
    db.prepare(
      `DELETE FROM export_authorizations WHERE rowid IN (SELECT rowid FROM export_authorizations WHERE issued_at <= ${now} - ${AUTH_RETENTION_MS} LIMIT 500)`,
    ),
    db.prepare(
      `DELETE FROM account_auth_tombstones WHERE rowid IN (SELECT rowid FROM account_auth_tombstones WHERE expires_at <= ${now} LIMIT 500)`,
    ),
    db.prepare(
      `DELETE FROM accounts WHERE id IN (SELECT id FROM accounts WHERE deleted_at IS NOT NULL AND deleted_at <= ${now} - ${AUTH_RETENTION_MS} LIMIT 500)`,
    ),
    db.prepare(
      `UPDATE account_otp_challenges SET email = NULL, verifier = NULL,${CLEAR_TRANSACTION_POLICY_SQL} WHERE id IN (SELECT id FROM account_otp_challenges WHERE expires_at <= ${now} AND (email IS NOT NULL OR verifier IS NOT NULL OR policy_authorized_at IS NOT NULL) LIMIT 500)`,
    ),
    db.prepare(
      `DELETE FROM account_otp_challenges WHERE id IN (SELECT id FROM account_otp_challenges WHERE created_at <= ${now} - ${AUTH_RETENTION_MS} LIMIT 500)`,
    ),
  ]);
  if (results.some((result) => !result.success)) return unavailable();
  await cleanCollection(db);
}
