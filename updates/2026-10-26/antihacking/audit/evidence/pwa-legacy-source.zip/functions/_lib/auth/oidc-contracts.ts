import type { AccountPolicyAuthorization } from "../../../shared/accountPolicy";

export type OidcReturnMode = "popup" | "redirect";
export type IdentityProvider = "google" | "github";
export type VerificationAction =
  "data" | "delete" | "link_google" | "link_github";
export type OidcTransactionStatus =
  "pending" | "completed" | "failed" | "expired";

export interface CreateOidcTransaction {
  readonly id: string;
  readonly stateHash: string;
  readonly browserHash: string;
  readonly ipHash: string;
  readonly secretsCiphertext: string;
  readonly returnMode: OidcReturnMode;
  readonly previousSessionTokenHash: string | null;
  readonly purpose?: "sign_in" | "account_access" | "link_provider";
  readonly provider?: IdentityProvider;
  readonly verificationAction?: VerificationAction;
  readonly policyAuthorization?: AccountPolicyAuthorization;
  readonly rightsOnly?: boolean;
}

export interface ClaimedOidcTransaction {
  readonly id: string;
  readonly secretsCiphertext: string;
  readonly returnMode: OidcReturnMode;
  readonly expiresAt: number;
  readonly provider?: IdentityProvider;
}

/** Constructed only after openid-client validates the token and protocol. */
export interface ValidatedGoogleIdentity {
  readonly issuer: "https://accounts.google.com";
  readonly subject: string;
  readonly email: string | null;
  readonly emailVerified: boolean;
  readonly hostedDomain: string | null;
  readonly authoritativeEmail: boolean;
  readonly displayName?: string | null;
}
export interface ValidatedGithubIdentity {
  readonly issuer: "https://github.com";
  readonly subject: string;
  readonly email: string | null;
  readonly emailVerified: boolean;
  readonly authoritativeEmail: boolean;
  readonly displayName?: string | null;
}
export type ValidatedIdentity =
  ValidatedGoogleIdentity | ValidatedGithubIdentity;

/** Atomic operations; database time owns TTLs and admission windows. */
export interface OidcStore {
  // Retain bounded admission receipts beyond the ten-minute secret TTL for
  // hourly limits. Cancel earlier pending transactions for this browser.
  createTransaction(
    input: CreateOidcTransaction,
  ): Promise<{ readonly expiresAt: number }>;
  claimTransaction(input: {
    readonly stateHash: string;
    readonly browserHash: string;
    readonly claimNonce: string;
    readonly provider?: IdentityProvider;
  }): Promise<ClaimedOidcTransaction | null>;
  getTransactionStatus(input: {
    readonly id: string;
    readonly browserHash: string;
  }): Promise<{
    readonly status: OidcTransactionStatus;
    readonly errorCode?: string;
  } | null>;
  cancelTransaction(input: {
    readonly id: string;
    readonly browserHash: string;
  }): Promise<{ readonly status: OidcTransactionStatus } | null>;
  // CAS on the winning claim; terminal transitions erase encrypted secrets.
  failTransaction(input: {
    readonly id: string;
    readonly claimNonce: string;
    readonly failureCode?: string;
  }): Promise<void>;
  // Resolve issuer/sub and tombstones before considering an email-based
  // collision/new admission. Never link by email. Capture/revoke the previous
  // session from the transaction, atomically with session issuance/completion.
  completeGoogleLogin(input: {
    readonly transactionId: string;
    readonly claimNonce: string;
    readonly identity: ValidatedIdentity;
    readonly sessionTokenHash: string;
  }): Promise<{ readonly expiresAt: number; readonly rightsOnly?: boolean }>;
}
