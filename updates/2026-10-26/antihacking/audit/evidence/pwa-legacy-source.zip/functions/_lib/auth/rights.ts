import { ApiError } from "../http";
import type { AccountDatabase } from "../accounts";
import type { CreateOidcTransaction, OidcStore } from "./oidc-contracts";
import { AUTH_NOW_SQL as NOW } from "./privacy";
import { CLEAR_TRANSACTION_POLICY_SQL } from "./policy";

const denied = (): never => {
  throw new ApiError(
    403,
    "rights_verification_unavailable",
    "This account verification could not be completed. Try your existing sign-in method or contact privacy support.",
  );
};

export async function createRightsTransaction(
  db: AccountDatabase,
  input: CreateOidcTransaction & { readonly rightsOnly?: boolean },
): Promise<{ readonly expiresAt: number }> {
  if (
    input.rightsOnly !== true ||
    input.purpose !== "account_access" ||
    input.previousSessionTokenHash !== null ||
    input.policyAuthorization !== undefined ||
    (input.verificationAction !== "data" &&
      input.verificationAction !== "delete") ||
    (input.provider !== "google" && input.provider !== "github")
  )
    return denied();
  const results = await db.batch([
    db
      .prepare(
        `INSERT INTO account_auth_transactions
      (id,state_hash,browser_hash,ip_hash,secrets_ciphertext,return_mode,status,created_at,expires_at,purpose,provider,intent,verification_action,rights_only)
      SELECT ?,?,?,?,?,?,'created',${NOW},${NOW}+600000,'account_access',?,'account_access',?,1
      WHERE (SELECT COUNT(*) FROM account_auth_transactions WHERE rights_only=1 AND ip_hash=? AND created_at>${NOW}-3600000)<20
      AND (SELECT COUNT(*) FROM account_auth_transactions WHERE rights_only=1 AND created_at>${NOW}-3600000)<90
      AND (SELECT COUNT(*) FROM account_auth_transactions WHERE rights_only=1)<1024`,
      )
      .bind(
        input.id,
        input.stateHash,
        input.browserHash,
        input.ipHash,
        input.secretsCiphertext,
        input.returnMode,
        input.provider,
        input.verificationAction,
        input.ipHash,
      ),
    db
      .prepare(
        `UPDATE account_auth_transactions SET status='failed',secrets_ciphertext=NULL,previous_session_token_hash=NULL,issued_session_token_hash=NULL,${CLEAR_TRANSACTION_POLICY_SQL}
      WHERE rights_only=1 AND browser_hash=? AND id!=? AND status IN ('created','claimed')
      AND EXISTS(SELECT 1 FROM account_auth_transactions WHERE id=? AND rights_only=1)`,
      )
      .bind(input.browserHash, input.id, input.id),
    db
      .prepare(
        "SELECT expires_at AS expiresAt FROM account_auth_transactions WHERE id=? AND rights_only=1",
      )
      .bind(input.id),
  ]);
  if (results.some((result) => !result.success)) return denied();
  const created = results[2].results?.[0] as { expiresAt: number } | undefined;
  if (!created)
    throw new ApiError(
      429,
      "rights_rate_limited",
      "Please wait before starting another account verification.",
      3600,
    );
  return created;
}

export async function completeRightsAccess(
  db: AccountDatabase,
  input: Parameters<OidcStore["completeGoogleLogin"]>[0],
): Promise<{ readonly expiresAt: number; readonly rightsOnly: true }> {
  const provider =
    input.identity.issuer === "https://accounts.google.com"
      ? "google"
      : input.identity.issuer === "https://github.com"
        ? "github"
        : null;
  if (!provider || !input.identity.subject) return denied();
  const gate = `t.id=? AND t.claim_nonce=? AND t.status='claimed' AND t.rights_only=1
    AND t.purpose='account_access' AND t.intent='account_access' AND t.provider=? AND t.expires_at>${NOW}
    AND t.verification_action IN ('data','delete') AND t.previous_session_token_hash IS NULL
    AND t.policy_privacy_notice_version IS NULL AND t.policy_terms_version IS NULL
    AND t.policy_purpose_version IS NULL AND t.policy_authorized_at IS NULL`;
  const args = [input.transactionId, input.claimNonce, provider];
  const identity = `e.issuer=? AND e.subject=? AND a.deleted_at IS NULL`;
  const identityArgs = [input.identity.issuer, input.identity.subject];
  const live = `a.deleted_at IS NULL AND a.security_version=t.access_security_version
    AND EXISTS(SELECT 1 FROM account_external_identities e WHERE e.account_id=a.id AND e.issuer=? AND e.subject=?)`;
  try {
    const results = await db.batch([
      db
        .prepare(
          `UPDATE account_auth_transactions AS t
        SET account_id=(SELECT a.id FROM accounts a JOIN account_external_identities e ON e.account_id=a.id WHERE ${identity}),
        access_security_version=(SELECT a.security_version FROM accounts a JOIN account_external_identities e ON e.account_id=a.id WHERE ${identity})
        WHERE ${gate} AND EXISTS(SELECT 1 FROM accounts a JOIN account_external_identities e ON e.account_id=a.id WHERE ${identity}) RETURNING account_id`,
        )
        .bind(...identityArgs, ...identityArgs, ...args, ...identityArgs),
      db
        .prepare(
          `INSERT INTO account_sessions(token_hash,account_id,expires_at)
        SELECT ?,a.id,${NOW}+300000 FROM accounts a JOIN account_auth_transactions t ON t.account_id=a.id WHERE ${gate} AND ${live}`,
        )
        .bind(input.sessionTokenHash, ...args, ...identityArgs),
      db
        .prepare(
          `INSERT INTO account_session_metadata(token_hash,method,authenticated_at,security_version,verification_action,rights_only)
        SELECT ?,'oidc',${NOW},a.security_version,t.verification_action,1 FROM accounts a JOIN account_auth_transactions t ON t.account_id=a.id
        JOIN account_sessions s ON s.account_id=a.id AND s.token_hash=? WHERE ${gate} AND ${live} AND s.expires_at>${NOW}`,
        )
        .bind(
          input.sessionTokenHash,
          input.sessionTokenHash,
          ...args,
          ...identityArgs,
        ),
      db
        .prepare(
          `UPDATE account_auth_transactions AS t SET issued_session_token_hash=? WHERE ${gate} AND EXISTS(
        SELECT 1 FROM account_sessions s JOIN account_session_metadata m ON m.token_hash=s.token_hash JOIN accounts a ON a.id=s.account_id
        WHERE s.token_hash=? AND s.account_id=t.account_id AND s.expires_at>${NOW} AND m.rights_only=1 AND m.verification_action=t.verification_action
        AND m.security_version=t.access_security_version AND a.security_version=t.access_security_version AND a.deleted_at IS NULL)`,
        )
        .bind(input.sessionTokenHash, ...args, input.sessionTokenHash),
      // Do not put expiry in this WHERE: the completion integrity trigger must
      // abort the entire batch if the clock/deletion/revocation changed mid-write.
      db
        .prepare(
          `UPDATE account_auth_transactions SET status='completed',secrets_ciphertext=NULL,previous_session_token_hash=NULL,issued_session_token_hash=NULL,${CLEAR_TRANSACTION_POLICY_SQL}
        WHERE id=? AND claim_nonce=? AND status='claimed' AND rights_only=1`,
        )
        .bind(input.transactionId, input.claimNonce),
      db
        .prepare(
          `SELECT s.expires_at AS expiresAt FROM account_sessions s JOIN account_session_metadata m ON m.token_hash=s.token_hash
        JOIN accounts a ON a.id=s.account_id JOIN account_auth_transactions t ON t.account_id=a.id
        WHERE s.token_hash=? AND t.id=? AND t.claim_nonce=? AND t.status='completed' AND t.rights_only=1 AND m.rights_only=1
        AND m.verification_action=t.verification_action AND m.security_version=a.security_version AND a.deleted_at IS NULL AND s.expires_at>${NOW}`,
        )
        .bind(input.sessionTokenHash, input.transactionId, input.claimNonce),
    ]);
    if (
      results.some((result) => !result.success) ||
      !results[0].results?.length
    )
      return denied();
    const session = results[5].results?.[0] as
      { expiresAt: number } | undefined;
    return session
      ? { expiresAt: session.expiresAt, rightsOnly: true }
      : denied();
  } catch {
    return denied();
  }
}
