import * as oidc from "openid-client";
import { requirePolicyAuthorization } from "./policy";
import type { AccountBindings } from "../accounts";
import {
  ApiError,
  SECURITY_HEADERS,
  jsonResponse,
  methodNotAllowed,
  readBoundedJson,
} from "../http";
import { runtimeDependencies, type RuntimeDependencies } from "../platform";
import { oidcStore } from "./oidc-store";
import { normalizeDisplayName, privacyConfigured } from "./privacy";
import { authorizeGithubIdentity, GITHUB_AUTHORIZE } from "./github";
import type {
  ClaimedOidcTransaction,
  OidcReturnMode,
  OidcStore,
  ValidatedGoogleIdentity,
  IdentityProvider,
  VerificationAction,
} from "./oidc-contracts";

const ISSUER = "https://accounts.google.com";
const AUTHORIZE = "https://accounts.google.com/o/oauth2/v2/auth";
const TOKEN = "https://oauth2.googleapis.com/token";
const JWKS = "https://www.googleapis.com/oauth2/v3/certs";
const CALLBACK = "/api/auth/v1/oidc/google/callback";
const TRANSACTION_COOKIE = "__Host-accreatio_auth_tx";
const SESSION_COOKIE = "__Host-accreatio_session";
const HEX_TOKEN = /^[a-f0-9]{64}$/;
const UUID =
  /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const UTF8 = new TextEncoder();

export type OidcAction =
  "methods" | "start" | "callback" | "status" | "cancel" | "complete";
export interface OidcContext {
  readonly request: Request;
  readonly env: AccountBindings;
  readonly params?: Readonly<Record<string, string | string[]>>;
}

function unavailable(provider: IdentityProvider = "google"): never {
  throw new ApiError(
    503,
    provider === "github" ? "github_unavailable" : "google_unavailable",
    `${provider === "github" ? "GitHub" : "Google"} sign-in is temporarily unavailable.`,
  );
}

function commonConfiguration(
  env: AccountBindings,
  provider: IdentityProvider = "google",
) {
  if (
    env.ACCOUNT_ENABLED !== "true" ||
    !env.ACCOUNT_IDENTITY_KEY ||
    env.ACCOUNT_IDENTITY_KEY.length < 43 ||
    !privacyConfigured(env) ||
    !env.ACCOUNT_DB ||
    !env.ACCOUNT_OIDC_TRANSACTION_KEY ||
    !HEX_TOKEN.test(env.ACCOUNT_OIDC_TRANSACTION_KEY) ||
    env.ACCOUNT_OIDC_TRANSACTION_KEY === env.ACCOUNT_IDENTITY_KEY ||
    env.ACCOUNT_OIDC_TRANSACTION_KEY === env.ACCOUNT_OTP_KEY
  )
    unavailable(provider);
  return { key: env.ACCOUNT_OIDC_TRANSACTION_KEY };
}
function configuration(
  env: AccountBindings,
  request: Request,
  provider: IdentityProvider = "google",
) {
  const common = commonConfiguration(env, provider);
  const github = provider === "github";
  const clientId = github ? env.GITHUB_CLIENT_ID : env.GOOGLE_CLIENT_ID;
  const clientSecret = github
    ? env.GITHUB_CLIENT_SECRET
    : env.GOOGLE_CLIENT_SECRET;
  const redirectUri = github
    ? env.GITHUB_REDIRECT_URI
    : env.GOOGLE_REDIRECT_URI;
  if (
    (github ? env.ACCOUNT_GITHUB_ENABLED : env.ACCOUNT_OIDC_ENABLED) !==
      "true" ||
    !clientId ||
    !(github
      ? /^[A-Za-z0-9._-]{1,128}$/.test(clientId)
      : /^[a-zA-Z0-9._-]+\.apps\.googleusercontent\.com$/.test(clientId)) ||
    !clientSecret ||
    clientSecret.length > 1024 ||
    !redirectUri
  )
    unavailable(provider);
  let redirect: URL;
  try {
    redirect = new URL(redirectUri);
  } catch {
    return unavailable(provider);
  }
  if (
    redirect.protocol !== "https:" ||
    redirect.username ||
    redirect.password ||
    redirect.search ||
    redirect.hash ||
    redirect.pathname !==
      (github ? "/api/auth/v1/oidc/github/callback" : CALLBACK) ||
    redirect.origin !== new URL(request.url).origin ||
    redirect.href !== redirectUri
  )
    unavailable(provider);
  return {
    clientId,
    clientSecret,
    redirectUri: redirect.href,
    key: common.key,
  };
}

function exactOrigin(request: Request) {
  if (
    request.headers.get("Origin") !== new URL(request.url).origin ||
    (request.headers.has("Sec-Fetch-Site") &&
      request.headers.get("Sec-Fetch-Site") !== "same-origin")
  )
    throw new ApiError(
      403,
      "invalid_origin",
      "Use accreatio to complete this action.",
    );
}

function tokenCookie(request: Request, name: string): string | null {
  const matches = (request.headers.get("Cookie") ?? "")
    .split(";")
    .map((part) => part.trim())
    .filter((part) => part.startsWith(`${name}=`));
  if (matches.length !== 1) return null;
  const token = matches[0].slice(name.length + 1);
  return HEX_TOKEN.test(token) ? token : null;
}

function randomToken() {
  return hex(crypto.getRandomValues(new Uint8Array(32)));
}
function hex(value: ArrayBuffer | Uint8Array) {
  const bytes = value instanceof Uint8Array ? value : new Uint8Array(value);
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join(
    "",
  );
}
function unhex(value: string) {
  if (!/^(?:[a-f0-9]{2})+$/.test(value)) throw new Error("invalid_envelope");
  return Uint8Array.from(value.match(/../g)!, (byte) => parseInt(byte, 16));
}
async function hash(value: string, dependencies: RuntimeDependencies) {
  return hex(await dependencies.subtle.digest("SHA-256", UTF8.encode(value)));
}

interface TransactionSecrets {
  nonce: string;
  verifier: string;
  state: string;
  redirectUri: string;
}
const aad = (id: string) =>
  UTF8.encode(JSON.stringify(["accreatio.oidc.v1", id]));
async function transactionKey(
  secret: string,
  dependencies: RuntimeDependencies,
) {
  return dependencies.subtle.importKey("raw", unhex(secret), "AES-GCM", false, [
    "encrypt",
    "decrypt",
  ]);
}
export async function sealOidcSecrets(
  id: string,
  value: TransactionSecrets,
  secret: string,
  dependencies = runtimeDependencies(),
) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await dependencies.subtle.encrypt(
    { name: "AES-GCM", iv, additionalData: aad(id), tagLength: 128 },
    await transactionKey(secret, dependencies),
    UTF8.encode(JSON.stringify(value)),
  );
  return `v1.${hex(iv)}.${hex(ciphertext)}`;
}
export async function openOidcSecrets(
  id: string,
  envelope: string,
  secret: string,
  dependencies = runtimeDependencies(),
): Promise<TransactionSecrets> {
  if (envelope.length > 4096) throw new Error("invalid_envelope");
  const [version, iv, ciphertext, extra] = envelope.split(".");
  if (
    version !== "v1" ||
    !iv ||
    iv.length !== 24 ||
    !ciphertext ||
    extra !== undefined
  )
    throw new Error("invalid_envelope");
  const plaintext = await dependencies.subtle.decrypt(
    { name: "AES-GCM", iv: unhex(iv), additionalData: aad(id), tagLength: 128 },
    await transactionKey(secret, dependencies),
    unhex(ciphertext),
  );
  const value: unknown = JSON.parse(
    new TextDecoder("utf-8", { fatal: true }).decode(plaintext),
  );
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("invalid_envelope");
  const record = value as Record<string, unknown>;
  if (
    typeof record.nonce !== "string" ||
    !/^[a-zA-Z0-9_-]{43}$/.test(record.nonce) ||
    typeof record.verifier !== "string" ||
    !/^[a-zA-Z0-9_-]{43}$/.test(record.verifier) ||
    typeof record.state !== "string" ||
    !/^[a-zA-Z0-9_-]{43}$/.test(record.state) ||
    typeof record.redirectUri !== "string"
  )
    throw new Error("invalid_envelope");
  return {
    nonce: record.nonce,
    verifier: record.verifier,
    state: record.state,
    redirectUri: record.redirectUri,
  };
}

async function ipHash(
  request: Request,
  secret: string,
  dependencies: RuntimeDependencies,
) {
  const ip = request.headers.get("CF-Connecting-IP") ?? "unavailable";
  const key = await dependencies.subtle.importKey(
    "raw",
    unhex(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return hex(
    await dependencies.subtle.sign(
      "HMAC",
      key,
      UTF8.encode(JSON.stringify(["oidc-ip-v1", ip.slice(0, 64)])),
    ),
  );
}

/** Fixed Google endpoints: no user-controlled discovery, redirects or JWKS URLs. */
export function googleClient(
  settings: { clientId: string; clientSecret: string },
  dependencies = runtimeDependencies(),
  tokenProgress?: (stage: "token_exchange" | "token_validation") => void,
) {
  const client = new oidc.Configuration(
    {
      issuer: ISSUER,
      authorization_endpoint: AUTHORIZE,
      token_endpoint: TOKEN,
      jwks_uri: JWKS,
      response_types_supported: ["code"],
      response_modes_supported: ["query"],
      code_challenge_methods_supported: ["S256"],
      id_token_signing_alg_values_supported: ["RS256"],
      authorization_response_iss_parameter_supported: true,
    },
    settings.clientId,
    {
      client_secret: settings.clientSecret,
      id_token_signed_response_alg: "RS256",
    },
  );
  client.timeout = 10;
  client[oidc.customFetch] = async (url, options) => {
    if (url !== TOKEN && url !== JWKS)
      throw new Error("provider_endpoint_rejected");
    if (url === TOKEN) tokenProgress?.("token_exchange");
    const body =
      options.body instanceof Uint8Array
        ? new Uint8Array(options.body).buffer
        : options.body;
    const response = await dependencies.fetch(url, {
      ...options,
      body,
      redirect: "manual",
    });
    if (response.status >= 300 && response.status < 400)
      throw new Error("provider_redirect_rejected");
    const maximum = url === JWKS ? 262_144 : 32_768;
    if (Number(response.headers.get("Content-Length")) > maximum) {
      await response.body?.cancel();
      throw new Error("provider_response_too_large");
    }
    if (!response.body) throw new Error("provider_response_empty");
    const reader = response.body.getReader();
    const chunks: Uint8Array[] = [];
    let length = 0;
    while (true) {
      const part = await reader.read();
      if (part.done) break;
      length += part.value.byteLength;
      if (length > maximum) {
        await reader.cancel();
        throw new Error("provider_response_too_large");
      }
      chunks.push(part.value);
    }
    const bytes = new Uint8Array(length);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.length;
    }
    const headers = new Headers(response.headers);
    headers.delete("Content-Encoding");
    headers.delete("Content-Length");
    if (url === TOKEN && response.ok) tokenProgress?.("token_validation");
    return new Response(bytes, { status: response.status, headers });
  };
  // Code-flow defaults trust the token endpoint's TLS. Require JWS verification
  // as well, using the library's bounded JWKS retrieval and algorithm checks.
  oidc.enableNonRepudiationChecks(client);
  return client;
}

export function googleIdentity(
  claims: oidc.IDToken,
  now = Date.now(),
): ValidatedGoogleIdentity {
  if (
    claims.iss !== ISSUER ||
    typeof claims.sub !== "string" ||
    !/^[\x21-\x7e]{1,255}$/.test(claims.sub) ||
    !Number.isFinite(claims.iat) ||
    claims.iat > Math.floor(now / 1000) + 60 ||
    !Number.isFinite(claims.exp) ||
    claims.exp <= Math.floor(now / 1000)
  )
    throw new Error("invalid_identity");
  const candidate =
    typeof claims.email === "string" ? claims.email.trim().toLowerCase() : "";
  const email =
    candidate.length <= 254 &&
    /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/.test(
      candidate,
    )
      ? candidate
      : null;
  const hostedDomain =
    typeof claims.hd === "string" &&
    claims.hd.length <= 253 &&
    /^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/i.test(claims.hd)
      ? claims.hd.toLowerCase()
      : null;
  const emailVerified = claims.email_verified === true;
  return {
    issuer: ISSUER,
    subject: claims.sub,
    email,
    emailVerified,
    hostedDomain,
    displayName: normalizeDisplayName(claims.name),
    authoritativeEmail:
      email !== null &&
      emailVerified &&
      (email.endsWith("@gmail.com") || hostedDomain !== null),
  };
}

function finish(
  request: Request,
  mode: OidcReturnMode,
  success: boolean,
  cookie?: string,
  errorCode?: string,
) {
  const target = new URL(
    mode === "popup" ? "/api/auth/v1/complete" : "/",
    request.url,
  );
  if (errorCode) target.searchParams.set("auth_error", errorCode);
  target.searchParams.set("auth", success ? "success" : "failure");
  const headers = new Headers({
    ...SECURITY_HEADERS,
    Location: target.href,
    "Cache-Control": "no-store",
    "Referrer-Policy": "no-referrer",
    "X-Content-Type-Options": "nosniff",
  });
  if (cookie) headers.set("Set-Cookie", cookie);
  return new Response(null, { status: 303, headers });
}

function completePage() {
  // Deliberately no script, opener, token, identifier or third-party resource.
  return new Response(
    `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>accreatio sign-in</title><body><main><h1>Return to accreatio</h1><p>Your original tab will show the sign-in result. You can close this window.</p><p lang="es">Tu pestaña original mostrará el resultado. Puedes cerrar esta ventana.</p></main></body></html>`,
    {
      headers: {
        ...SECURITY_HEADERS,
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store",
        "Content-Security-Policy":
          "default-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'",
        "Referrer-Policy": "no-referrer",
        "X-Content-Type-Options": "nosniff",
        "Cross-Origin-Opener-Policy": "same-origin",
      },
    },
  );
}

type CallbackFailureStage =
  | "configuration"
  | "callback_binding"
  | "transaction_decrypt"
  | "authorization_response"
  | "token_exchange"
  | "token_validation"
  | "account_admission";

function reportCallbackFailure(stage: CallbackFailureStage, error: unknown) {
  let code:
    | CallbackFailureStage
    | "provider_invalid_client"
    | "provider_invalid_grant"
    | "provider_authorization_rejected" = stage;
  if (error instanceof oidc.ResponseBodyError) {
    if (error.error === "invalid_client") code = "provider_invalid_client";
    else if (error.error === "invalid_grant") code = "provider_invalid_grant";
  } else if (error instanceof oidc.AuthorizationResponseError) {
    code = "provider_authorization_rejected";
  }
  // Only locally defined literals leave this boundary. Provider errors can
  // contain tokens/claims in cause, response, message and error_description.
  // Do not log those objects, callback URLs, identifiers or cookie values.
  console.warn(JSON.stringify({ event: "oidc_callback_failed", code }));
}

export async function handleOidc(
  context: OidcContext,
  action: OidcAction,
  dependencies = runtimeDependencies(),
  providedStore?: OidcStore,
  provider: IdentityProvider = "google",
): Promise<Response> {
  const { request, env } = context;
  const expected = action === "start" || action === "cancel" ? "POST" : "GET";
  if (request.method !== expected) return methodNotAllowed([expected]);
  let claimed: ClaimedOidcTransaction | null = null;
  let claimNonce = "";
  let store: OidcStore | undefined;
  let failureStage: CallbackFailureStage = "configuration";
  try {
    if (action === "complete") return completePage();
    if (action === "methods") {
      let google = false;
      let github = false;
      try {
        configuration(env, request);
        google = true;
      } catch {
        /* Capability stays off. */
      }
      try {
        configuration(env, request, "github");
        github = true;
      } catch {
        /* Fail closed. */
      }
      return jsonResponse({
        version: "auth.v1",
        methods: {
          google: { available: google },
          github: { available: github },
          emailOtp: {
            available:
              env.ACCOUNT_ENABLED === "true" &&
              env.ACCOUNT_OTP_ENABLED === "true" &&
              !!env.ACCOUNT_MAILER &&
              !!env.ACCOUNT_OTP_KEY,
          },
        },
      });
    }
    // Status/cancel belong to the browser transaction, including when only
    // GitHub is enabled or a provider was disabled during an in-flight flow.
    const settings =
      action === "status" || action === "cancel"
        ? {
            ...commonConfiguration(env),
            clientId: "",
            clientSecret: "",
            redirectUri: "",
          }
        : configuration(env, request, provider);
    const activeStore: OidcStore =
      providedStore ?? oidcStore(env, dependencies);
    store = activeStore;
    if (action === "start") {
      exactOrigin(request);
      const body = await readBoundedJson(request, 512);
      if (!body || typeof body !== "object" || Array.isArray(body))
        throw new ApiError(
          400,
          "invalid_auth_request",
          "Choose a sign-in method in accreatio.",
        );
      const value = body as Record<string, unknown>;
      if (
        Object.keys(value).some(
          (key) =>
            ![
              "purpose",
              "returnRoute",
              "mode",
              "policyAuthorization",
              "verificationAction",
              "rightsOnly",
            ].includes(key),
        ) ||
        (value.purpose !== "sign_in" &&
          value.purpose !== "account_access" &&
          value.purpose !== "link_provider") ||
        value.returnRoute !== "builder" ||
        (value.mode !== "popup" && value.mode !== "redirect")
      )
        throw new ApiError(
          400,
          "invalid_auth_request",
          "Choose a sign-in method in accreatio.",
        );
      const rightsOnly = value.rightsOnly === true;
      const rightsRoute =
        /^\/api\/auth\/v1\/rights\/(google|github)\/start$/.test(
          new URL(request.url).pathname,
        );
      if (rightsOnly !== rightsRoute)
        throw new ApiError(
          400,
          "invalid_auth_request",
          "Choose the account action in accreatio.",
        );
      if (
        (value.rightsOnly !== undefined &&
          typeof value.rightsOnly !== "boolean") ||
        (rightsOnly &&
          (value.purpose !== "account_access" ||
            !["data", "delete"].includes(String(value.verificationAction))))
      )
        throw new ApiError(
          400,
          "invalid_auth_request",
          "Choose the account action in accreatio.",
        );
      if (
        value.purpose !== "sign_in" &&
        value.policyAuthorization !== undefined
      )
        throw new ApiError(
          400,
          "invalid_policy_authorization",
          "Account-control verification does not accept a new policy authorization.",
        );
      const policyAuthorization =
        value.purpose === "sign_in"
          ? requirePolicyAuthorization(value.policyAuthorization)
          : undefined;
      if (
        (value.purpose === "account_access" &&
          !["data", "delete", "link_google", "link_github"].includes(
            String(value.verificationAction),
          )) ||
        (value.purpose !== "account_access" &&
          value.verificationAction !== undefined)
      )
        throw new ApiError(
          400,
          "invalid_auth_request",
          "Choose the account action in accreatio.",
        );
      const id = dependencies.randomUUID();
      const browser = tokenCookie(request, TRANSACTION_COOKIE) ?? randomToken();
      const state = oidc.randomState();
      const verifier = oidc.randomPKCECodeVerifier();
      const nonce = oidc.randomNonce();
      const previousSession = rightsOnly
        ? null
        : tokenCookie(request, SESSION_COOKIE);
      if (value.purpose !== "sign_in" && !rightsOnly && !previousSession)
        throw new ApiError(
          401,
          "sign_in_required",
          "Use your existing signed-in browser or contact privacy support for account controls.",
        );
      const created = await activeStore.createTransaction({
        id,
        stateHash: await hash(state, dependencies),
        browserHash: await hash(browser, dependencies),
        ipHash: await ipHash(request, settings.key, dependencies),
        secretsCiphertext: await sealOidcSecrets(
          id,
          { state, nonce, verifier, redirectUri: settings.redirectUri },
          settings.key,
          dependencies,
        ),
        returnMode: value.mode,
        purpose: value.purpose,
        provider,
        verificationAction: value.verificationAction as
          VerificationAction | undefined,
        policyAuthorization,
        previousSessionTokenHash: previousSession
          ? await hash(previousSession, dependencies)
          : null,
        ...(rightsOnly ? { rightsOnly: true } : {}),
      });
      const authorization =
        provider === "github"
          ? new URL(GITHUB_AUTHORIZE)
          : oidc.buildAuthorizationUrl(googleClient(settings, dependencies), {
              redirect_uri: settings.redirectUri,
              scope: "openid email profile",
              response_type: "code",
              response_mode: "query",
              code_challenge: await oidc.calculatePKCECodeChallenge(verifier),
              code_challenge_method: "S256",
              state,
              nonce,
            });
      if (provider === "github") {
        for (const [key, value] of Object.entries({
          client_id: settings.clientId,
          redirect_uri: settings.redirectUri,
          response_type: "code",
          state,
          code_challenge: await oidc.calculatePKCECodeChallenge(verifier),
          code_challenge_method: "S256",
        }))
          authorization.searchParams.set(key, value);
      }
      return jsonResponse(
        {
          transactionId: id,
          authorizationUrl: authorization.href,
          expiresAt: new Date(created.expiresAt).toISOString(),
        },
        200,
        {
          "Set-Cookie": `${TRANSACTION_COOKIE}=${browser}; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=600`,
        },
      );
    }
    failureStage = "callback_binding";
    const browser = tokenCookie(request, TRANSACTION_COOKIE);
    if (!browser)
      throw new ApiError(
        400,
        "auth_transaction_invalid",
        "Start sign-in again from accreatio.",
      );
    if (action === "status" || action === "cancel") {
      if (action === "cancel") exactOrigin(request);
      if (request.headers.get("Sec-Fetch-Site") === "cross-site")
        throw new ApiError(
          403,
          "invalid_origin",
          "Use accreatio to check sign-in.",
        );
      const id = context.params?.id;
      if (typeof id !== "string" || !UUID.test(id))
        throw new ApiError(
          404,
          "auth_transaction_unavailable",
          "This sign-in is no longer available.",
        );
      const input = { id, browserHash: await hash(browser, dependencies) };
      const result =
        action === "cancel"
          ? await activeStore.cancelTransaction(input)
          : await activeStore.getTransactionStatus(input);
      if (!result)
        throw new ApiError(
          404,
          "auth_transaction_unavailable",
          "This sign-in is no longer available.",
        );
      return jsonResponse(result);
    }
    const current = new URL(request.url);
    if (
      `${current.origin}${current.pathname}` !== settings.redirectUri ||
      current.search.length > 8192
    )
      throw new Error("invalid_callback");
    for (const key of ["state", "code", "iss", "error", "error_description"])
      if (current.searchParams.getAll(key).length > 1)
        throw new Error("ambiguous_callback");
    const state = current.searchParams.get("state");
    if (!state || !/^[a-zA-Z0-9_-]{43}$/.test(state))
      throw new Error("invalid_state");
    claimNonce = randomToken();
    claimed = await activeStore.claimTransaction({
      stateHash: await hash(state, dependencies),
      browserHash: await hash(browser, dependencies),
      claimNonce,
      provider,
    });
    if (!claimed) throw new Error("invalid_transaction");
    failureStage = "transaction_decrypt";
    const secrets = await openOidcSecrets(
      claimed.id,
      claimed.secretsCiphertext,
      settings.key,
      dependencies,
    );
    if (secrets.redirectUri !== settings.redirectUri)
      throw new Error("configuration_changed");
    failureStage = "authorization_response";
    let identity;
    if (provider === "github") {
      identity = await authorizeGithubIdentity(
        settings,
        secrets,
        current,
        dependencies,
      );
    } else {
      const tokens = await oidc.authorizationCodeGrant(
        googleClient(settings, dependencies, (stage) => {
          failureStage = stage;
        }),
        current,
        {
          expectedState: secrets.state,
          expectedNonce: secrets.nonce,
          pkceCodeVerifier: secrets.verifier,
          idTokenExpected: true,
        },
      );
      failureStage = "token_validation";
      const claims = tokens.claims();
      if (!claims) throw new Error("identity_missing");
      // The library checks azp for multiple audiences; this single-client profile
      // also rejects a conflicting azp when aud is a single string.
      if (claims.azp !== undefined && claims.azp !== settings.clientId)
        throw new Error("authorized_party_mismatch");
      identity = googleIdentity(claims, dependencies.now());
    }
    const session = randomToken();
    failureStage = "account_admission";
    const completed = await activeStore.completeGoogleLogin({
      transactionId: claimed.id,
      claimNonce,
      identity,
      sessionTokenHash: await hash(session, dependencies),
    });
    return finish(
      request,
      claimed.returnMode,
      true,
      `${completed.rightsOnly ? "__Host-accreatio_rights" : SESSION_COOKIE}=${session}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${Math.max(0, Math.floor((completed.expiresAt - dependencies.now()) / 1000))}`,
    );
  } catch (error) {
    if (claimed && store)
      await store
        .failTransaction({
          id: claimed.id,
          claimNonce,
          failureCode: error instanceof ApiError ? error.code : undefined,
        })
        .catch(() => undefined);
    // No raw provider errors, credentials, query strings, claims or identifiers.
    if (action === "callback") {
      reportCallbackFailure(failureStage, error);
      const reason =
        provider === "github" &&
        error instanceof ApiError &&
        [
          "account_suspended",
          "verified_email_required",
          "identity_conflict",
          "provider_cancelled",
          "provider_permission_required",
          "provider_unavailable",
          "provider_authorization_invalid",
        ].includes(error.code)
          ? error.code
          : undefined;
      return finish(
        request,
        claimed?.returnMode ?? "popup",
        false,
        undefined,
        reason,
      );
    }
    const known = error instanceof ApiError;
    return jsonResponse(
      {
        error: {
          code: known
            ? error.code
            : provider === "github"
              ? "github_unavailable"
              : "google_unavailable",
          message: known
            ? error.publicMessage
            : "Sign-in is temporarily unavailable. Your draft is still here.",
          ...(known && error.retryAfterSeconds
            ? { retryAfter: error.retryAfterSeconds }
            : {}),
        },
      },
      known ? error.status : 503,
      known && error.retryAfterSeconds
        ? { "Retry-After": String(error.retryAfterSeconds) }
        : undefined,
    );
  }
}
