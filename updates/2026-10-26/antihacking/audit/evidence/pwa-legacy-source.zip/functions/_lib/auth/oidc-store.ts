import { ApiError } from "../http";
import { ABUSE_ALLOWED_SQL, getAbuseAccountStatus } from "../abuse";
import { createRightsTransaction, completeRightsAccess } from "./rights";
import type { AccountBindings } from "../accounts";
import { runtimeDependencies } from "../platform";
import type { OidcStore, ClaimedOidcTransaction } from "./oidc-contracts";
import {
  CLEAR_TRANSACTION_POLICY_SQL,
  POLICY_UPSERT_SQL,
  TRANSACTION_POLICY_SQL,
  requirePolicyAuthorization,
} from "./policy";
import {
  AUTH_NOW_SQL as NOW,
  PRIVACY_NOTICE_VERSION,
  emailLookup,
  externalLocator,
  keyedHash,
  privacyConfigured,
  protectEmail,
  normalizeDisplayName,
  protectDisplayName,
} from "./privacy";

const fail = (): never => {
  throw new ApiError(
    403,
    "sign_in_unavailable",
    "This sign-in could not be completed. Use an existing sign-in method or try again.",
  );
};
function limit(value: string | undefined, fallback: number, maximum: number) {
  if (value === undefined) return fallback;
  if (!/^[1-9]\d*$/.test(value) || Number(value) > maximum) return fail();
  return Number(value);
}
const contactEmail = (value: string | null) => {
  const email = value?.trim().toLowerCase();
  return email &&
    email.length <= 254 &&
    /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/.test(
      email,
    ) &&
    email.split("@")[0].length <= 64 &&
    !email.startsWith(".") &&
    !email.includes("..") &&
    !email.includes(".@")
    ? email
    : null;
};

export function oidcStore(
  env: AccountBindings,
  deps = runtimeDependencies(),
): OidcStore {
  const configuredDb = env.ACCOUNT_DB;
  if (
    !configuredDb ||
    env.ACCOUNT_ENABLED !== "true" ||
    !env.ACCOUNT_IDENTITY_KEY ||
    env.ACCOUNT_IDENTITY_KEY.length < 43 ||
    !privacyConfigured(env)
  ) {
    throw new ApiError(
      503,
      "account_unavailable",
      "Account service is temporarily unavailable.",
    );
  }
  const db = configuredDb;
  const liveAccess = `EXISTS(SELECT 1 FROM account_sessions s JOIN accounts a ON a.id=s.account_id LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash
    WHERE s.token_hash=account_auth_transactions.previous_session_token_hash AND s.account_id=account_auth_transactions.account_id AND s.expires_at>${NOW}
    AND a.deleted_at IS NULL AND a.security_version=account_auth_transactions.access_security_version AND COALESCE(m.rights_only,0)=0 AND (m.token_hash IS NULL OR m.security_version=a.security_version) AND ${ABUSE_ALLOWED_SQL("a.id")})`;
  const priorSession = `SELECT s.token_hash FROM account_sessions s JOIN accounts a ON a.id=s.account_id LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash
    WHERE s.token_hash=? AND s.expires_at>${NOW} AND a.deleted_at IS NULL AND COALESCE(m.rights_only,0)=0 AND (m.token_hash IS NULL OR m.security_version=a.security_version) AND ${ABUSE_ALLOWED_SQL("a.id")}`;
  const recentLink = `EXISTS(SELECT 1 FROM account_sessions s JOIN account_session_metadata m ON m.token_hash=s.token_hash
    WHERE s.token_hash=account_auth_transactions.previous_session_token_hash AND m.authenticated_at>${NOW}-300000
    AND m.verification_action='link_'||account_auth_transactions.provider)`;
  async function completeAccountAccess(
    input: Parameters<OidcStore["completeGoogleLogin"]>[0],
  ) {
    const gate = `id=? AND claim_nonce=? AND status='claimed' AND intent='account_access' AND expires_at>${NOW} AND ${liveAccess}
      AND EXISTS(SELECT 1 FROM account_external_identities e WHERE e.account_id=account_auth_transactions.account_id AND e.issuer=? AND e.subject=?)`;
    const args = [
      input.transactionId,
      input.claimNonce,
      input.identity.issuer,
      input.identity.subject,
    ];
    const issued = `EXISTS(SELECT 1 FROM account_sessions WHERE token_hash=?)`;
    const results = await db.batch([
      db
        .prepare(
          `INSERT INTO account_sessions(token_hash,account_id,expires_at) SELECT ?,account_id,${NOW}+86400000 FROM account_auth_transactions WHERE ${gate}`,
        )
        .bind(input.sessionTokenHash, ...args),
      db
        .prepare(
          `INSERT INTO account_session_metadata(token_hash,method,authenticated_at,security_version,verification_action)
        SELECT ?,'oidc',${NOW},a.security_version,t.verification_action FROM accounts a JOIN account_sessions s ON s.account_id=a.id
        JOIN account_auth_transactions t ON t.id=? AND t.claim_nonce=? WHERE s.token_hash=?`,
        )
        .bind(
          input.sessionTokenHash,
          input.transactionId,
          input.claimNonce,
          input.sessionTokenHash,
        ),
      db
        .prepare(
          `UPDATE account_auth_transactions SET issued_session_token_hash=? WHERE ${gate}
          AND EXISTS(SELECT 1 FROM account_sessions s JOIN account_session_metadata m ON m.token_hash=s.token_hash WHERE s.token_hash=? AND s.account_id=account_auth_transactions.account_id AND m.method='oidc')`,
        )
        .bind(input.sessionTokenHash, ...args, input.sessionTokenHash),
      db
        .prepare(
          `DELETE FROM account_sessions WHERE token_hash=(SELECT previous_session_token_hash FROM account_auth_transactions WHERE id=? AND claim_nonce=?) AND ${issued}`,
        )
        .bind(input.transactionId, input.claimNonce, input.sessionTokenHash),
      db
        .prepare(
          `DELETE FROM account_sessions WHERE token_hash IN(SELECT token_hash FROM account_sessions WHERE account_id=(SELECT account_id FROM account_sessions WHERE token_hash=?) AND token_hash!=? ORDER BY expires_at DESC,token_hash LIMIT -1 OFFSET 9) AND ${issued}`,
        )
        .bind(
          input.sessionTokenHash,
          input.sessionTokenHash,
          input.sessionTokenHash,
        ),
      db
        .prepare(
          `UPDATE account_auth_transactions SET status='completed',secrets_ciphertext=NULL,previous_session_token_hash=NULL,issued_session_token_hash=NULL,${CLEAR_TRANSACTION_POLICY_SQL} WHERE id=? AND claim_nonce=? AND status='claimed' AND purpose='account_access'`,
        )
        .bind(input.transactionId, input.claimNonce),
      db
        .prepare(
          "SELECT expires_at AS expiresAt FROM account_sessions WHERE token_hash=?",
        )
        .bind(input.sessionTokenHash),
    ]);
    if (results.some((result) => !result.success)) return fail();
    const session = results[6].results?.[0] as
      { expiresAt: number } | undefined;
    return session ?? fail();
  }
  async function completeLink(
    input: Parameters<OidcStore["completeGoogleLogin"]>[0],
  ) {
    const locator = await externalLocator(
      input.identity.issuer,
      input.identity.subject,
      env,
      deps,
    );
    const conflict = await db
      .prepare(
        `SELECT 1 FROM account_external_identities e JOIN account_auth_transactions t ON t.id=?
      WHERE e.issuer=? AND e.subject=? AND e.account_id!=t.account_id
      UNION ALL SELECT 1 FROM account_auth_tombstones t JOIN account_auth_transactions x ON x.id=? WHERE t.locator_kind='external' AND t.locator_hmac=? AND t.account_id!=x.account_id AND t.expires_at>${NOW} LIMIT 1`,
      )
      .bind(
        input.transactionId,
        input.identity.issuer,
        input.identity.subject,
        input.transactionId,
        locator,
      )
      .first();
    if (conflict)
      throw new ApiError(
        409,
        "identity_conflict",
        "This sign-in method cannot be connected. Sign in with your usual method; accounts cannot be merged.",
      );
    const gate = `id=? AND claim_nonce=? AND status='claimed' AND intent='link_provider' AND expires_at>${NOW} AND ${liveAccess} AND ${recentLink}
      AND NOT EXISTS(SELECT 1 FROM account_external_identities e WHERE e.issuer=? AND e.subject=? AND e.account_id!=account_auth_transactions.account_id)
      AND NOT EXISTS(SELECT 1 FROM account_external_identities e WHERE e.account_id=account_auth_transactions.account_id AND e.issuer=? AND e.subject!=?)
      AND NOT EXISTS(SELECT 1 FROM account_auth_tombstones WHERE locator_kind='external' AND locator_hmac=? AND account_id!=account_auth_transactions.account_id AND expires_at>${NOW})`;
    const args = [
      input.transactionId,
      input.claimNonce,
      input.identity.issuer,
      input.identity.subject,
      input.identity.issuer,
      input.identity.subject,
      locator,
    ];
    const results = await db.batch([
      db
        .prepare(
          `INSERT INTO account_external_identities(id,account_id,issuer,subject,locator_hmac,created_at,last_authenticated_at)
        SELECT ?,account_id,?,?,?,${NOW},${NOW} FROM account_auth_transactions WHERE ${gate}
        AND NOT EXISTS(SELECT 1 FROM account_external_identities WHERE issuer=? AND subject=?)`,
        )
        .bind(
          deps.randomUUID(),
          input.identity.issuer,
          input.identity.subject,
          locator,
          ...args,
          input.identity.issuer,
          input.identity.subject,
        ),
      db
        .prepare(
          `INSERT INTO account_sessions(token_hash,account_id,expires_at) SELECT ?,account_id,${NOW}+86400000 FROM account_auth_transactions WHERE ${gate}`,
        )
        .bind(input.sessionTokenHash, ...args),
      db
        .prepare(
          `INSERT INTO account_session_metadata(token_hash,method,authenticated_at,security_version)
        SELECT ?,'oidc',${NOW},a.security_version FROM account_sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token_hash=?`,
        )
        .bind(input.sessionTokenHash, input.sessionTokenHash),
      db
        .prepare(
          `UPDATE account_auth_transactions SET issued_session_token_hash=? WHERE ${gate}
        AND EXISTS(SELECT 1 FROM account_sessions WHERE token_hash=? AND account_id=account_auth_transactions.account_id)`,
        )
        .bind(input.sessionTokenHash, ...args, input.sessionTokenHash),
      db
        .prepare(
          `DELETE FROM account_sessions WHERE token_hash=(SELECT previous_session_token_hash FROM account_auth_transactions WHERE id=? AND claim_nonce=?)
        AND EXISTS(SELECT 1 FROM account_sessions WHERE token_hash=?)`,
        )
        .bind(input.transactionId, input.claimNonce, input.sessionTokenHash),
      db
        .prepare(
          `DELETE FROM account_sessions WHERE token_hash IN(SELECT token_hash FROM account_sessions WHERE account_id=(SELECT account_id FROM account_sessions WHERE token_hash=?) AND token_hash!=? ORDER BY expires_at DESC,token_hash LIMIT -1 OFFSET 9)
        AND EXISTS(SELECT 1 FROM account_sessions WHERE token_hash=?)`,
        )
        .bind(
          input.sessionTokenHash,
          input.sessionTokenHash,
          input.sessionTokenHash,
        ),
      db
        .prepare(
          `UPDATE account_auth_transactions SET status='completed',secrets_ciphertext=NULL,previous_session_token_hash=NULL,issued_session_token_hash=NULL,${CLEAR_TRANSACTION_POLICY_SQL}
        WHERE id=? AND claim_nonce=? AND status='claimed' AND intent='link_provider'`,
        )
        .bind(input.transactionId, input.claimNonce),
      db
        .prepare(
          "SELECT expires_at AS expiresAt FROM account_sessions WHERE token_hash=?",
        )
        .bind(input.sessionTokenHash),
    ]);
    if (results.some((result) => !result.success)) return fail();
    return (
      (results[7].results?.[0] as { expiresAt: number } | undefined) ?? fail()
    );
  }
  return {
    async createTransaction(input) {
      if (input.rightsOnly === true) return createRightsTransaction(db, input);
      const purpose = input.purpose ?? "sign_in";
      if (
        purpose !== "sign_in" &&
        purpose !== "account_access" &&
        purpose !== "link_provider"
      )
        return fail();
      if (purpose !== "sign_in" && input.policyAuthorization !== undefined)
        return fail();
      const authorization =
        purpose === "sign_in"
          ? requirePolicyAuthorization(input.policyAuthorization)
          : null;
      const provider = input.provider ?? "google";
      if (provider !== "google" && provider !== "github") return fail();
      if (
        purpose === "account_access" &&
        !["data", "delete", "link_google", "link_github"].includes(
          input.verificationAction ?? "",
        )
      )
        return fail();
      if (purpose !== "sign_in") {
        const current = await db
          .prepare(
            `SELECT a.id,m.authenticated_at,m.verification_action FROM account_sessions s JOIN accounts a ON a.id=s.account_id
          LEFT JOIN account_session_metadata m ON m.token_hash=s.token_hash WHERE s.token_hash=? AND s.expires_at>${NOW}
          AND a.deleted_at IS NULL AND COALESCE(m.rights_only,0)=0 AND (m.token_hash IS NULL OR m.security_version=a.security_version)`,
          )
          .bind(input.previousSessionTokenHash)
          .first<{
            id: string;
            authenticated_at: number | null;
            verification_action: string | null;
          }>();
        if (!current)
          throw new ApiError(
            401,
            "sign_in_required",
            "Use your existing signed-in browser for this action.",
          );
        if (
          purpose === "account_access" &&
          !(await db
            .prepare(
              "SELECT 1 FROM account_external_identities WHERE account_id=? AND issuer=?",
            )
            .bind(
              current.id,
              provider === "google"
                ? "https://accounts.google.com"
                : "https://github.com",
            )
            .first())
        )
          return fail();
        if (purpose === "link_provider") {
          const recent = await db
            .prepare(
              `SELECT 1 FROM account_sessions s JOIN account_session_metadata m ON m.token_hash=s.token_hash
            WHERE s.token_hash=? AND m.authenticated_at>${NOW}-300000 AND m.verification_action=?`,
            )
            .bind(input.previousSessionTokenHash, `link_${provider}`)
            .first();
          if (!recent)
            throw new ApiError(
              401,
              "reauthentication_required",
              "Verify your current account before connecting another sign-in method.",
            );
        }
      }
      const basePurpose =
        purpose === "link_provider" ? "account_access" : purpose;
      const results = await db.batch([
        db
          .prepare(
            `INSERT INTO account_auth_transactions
          (id,state_hash,browser_hash,ip_hash,secrets_ciphertext,return_mode,previous_session_token_hash,status,created_at,expires_at,policy_privacy_notice_version,policy_terms_version,policy_purpose_version,policy_authorized_at,purpose,account_id,access_security_version,provider,intent,verification_action,initiator_authenticated_at)
          SELECT ?,?,?,?,?,?,(${priorSession}),'created',${NOW},${NOW}+600000,?,?,?,CASE WHEN ?='sign_in' THEN ${NOW} ELSE NULL END,?,
          CASE WHEN ?='account_access' THEN (SELECT account_id FROM account_sessions WHERE token_hash=?) ELSE NULL END,
          CASE WHEN ?='account_access' THEN (SELECT a.security_version FROM accounts a JOIN account_sessions s ON s.account_id=a.id WHERE s.token_hash=?) ELSE NULL END,?,?,?,
          (SELECT authenticated_at FROM account_session_metadata WHERE token_hash=?)
          WHERE (SELECT COUNT(*) FROM account_auth_transactions WHERE rights_only=0)<4096 AND (?!='sign_in' OR (SELECT COUNT(*) FROM account_auth_transactions WHERE rights_only=0 AND intent='sign_in' AND ip_hash=? AND created_at > ${NOW}-3600000) < ?)
          AND (?!='sign_in' OR (SELECT COUNT(*) FROM account_auth_transactions WHERE rights_only=0 AND intent='sign_in' AND created_at > ${NOW}-3600000) < ?)
          AND (?='sign_in' OR EXISTS(${priorSession}))
          AND (?='sign_in' OR (SELECT COUNT(*) FROM account_auth_transactions WHERE rights_only=0 AND account_id=(SELECT account_id FROM account_sessions WHERE token_hash=?) AND intent IN ('account_access','link_provider') AND created_at>${NOW}-3600000)<20)`,
          )
          .bind(
            input.id,
            input.stateHash,
            input.browserHash,
            input.ipHash,
            input.secretsCiphertext,
            input.returnMode,
            input.previousSessionTokenHash,
            authorization?.privacyNoticeVersion ?? null,
            authorization?.termsVersion ?? null,
            authorization?.purposeVersion ?? null,
            basePurpose,
            basePurpose,
            basePurpose,
            input.previousSessionTokenHash,
            basePurpose,
            input.previousSessionTokenHash,
            provider,
            purpose,
            input.verificationAction ?? null,
            input.previousSessionTokenHash,
            basePurpose,
            input.ipHash,
            limit(env.ACCOUNT_OIDC_IP_HOURLY, 20, 100),
            basePurpose,
            limit(env.ACCOUNT_OIDC_GLOBAL_HOURLY, 90, 1000),
            basePurpose,
            input.previousSessionTokenHash,
            basePurpose,
            input.previousSessionTokenHash,
          ),
        db
          .prepare(
            `UPDATE account_auth_transactions SET status='failed', secrets_ciphertext=NULL, previous_session_token_hash=NULL,issued_session_token_hash=NULL,${CLEAR_TRANSACTION_POLICY_SQL}
          WHERE browser_hash=? AND id!=? AND status IN ('created','claimed') AND EXISTS(SELECT 1 FROM account_auth_transactions WHERE id=?)`,
          )
          .bind(input.browserHash, input.id, input.id),
        db
          .prepare(
            "SELECT expires_at AS expiresAt FROM account_auth_transactions WHERE id=?",
          )
          .bind(input.id),
      ]);
      if (results.some((r) => !r.success)) return fail();
      const row = results[2].results?.[0] as { expiresAt: number } | undefined;
      if (
        !row &&
        purpose !== "sign_in" &&
        !(await db
          .prepare(priorSession)
          .bind(input.previousSessionTokenHash)
          .first())
      )
        throw new ApiError(
          401,
          "sign_in_required",
          "Use your existing signed-in browser or contact privacy support for account controls.",
        );
      if (!row)
        throw new ApiError(
          429,
          "sign_in_rate_limited",
          "Please wait before trying to sign in again.",
          3600,
        );
      return row;
    },
    async claimTransaction(input) {
      return db
        .prepare(
          `UPDATE account_auth_transactions SET status='claimed', claim_nonce=?
        WHERE state_hash=? AND browser_hash=? AND provider=? AND status='created' AND expires_at>${NOW}
        AND ((intent='sign_in' AND ${TRANSACTION_POLICY_SQL}) OR (intent='account_access' AND (rights_only=1 OR ${liveAccess})) OR (intent='link_provider' AND ${liveAccess} AND ${recentLink}))
        RETURNING id, secrets_ciphertext AS secretsCiphertext, return_mode AS returnMode, expires_at AS expiresAt,provider`,
        )
        .bind(
          input.claimNonce,
          input.stateHash,
          input.browserHash,
          input.provider ?? "google",
        )
        .first<ClaimedOidcTransaction>();
    },
    async getTransactionStatus(input) {
      const row = await db
        .prepare(
          `SELECT CASE WHEN expires_at<=${NOW} THEN 'expired' WHEN status IN ('created','claimed') THEN 'pending' ELSE status END AS status,failure_code AS errorCode
        FROM account_auth_transactions WHERE id=? AND browser_hash=?`,
        )
        .bind(input.id, input.browserHash)
        .first<{
          status: "pending" | "completed" | "failed" | "expired";
          errorCode: string | null;
        }>();
      return row
        ? {
            status: row.status,
            ...(row.errorCode ? { errorCode: row.errorCode } : {}),
          }
        : null;
    },
    async failTransaction(input) {
      const result = await db
        .prepare(
          `UPDATE account_auth_transactions SET status='failed',failure_code=?, secrets_ciphertext=NULL, previous_session_token_hash=NULL,issued_session_token_hash=NULL,${CLEAR_TRANSACTION_POLICY_SQL} WHERE id=? AND claim_nonce=? AND status='claimed'`,
        )
        .bind(input.failureCode ?? null, input.id, input.claimNonce)
        .run();
      if (!result.success) return fail();
    },
    async cancelTransaction(input) {
      const results = await db.batch([
        db
          .prepare(
            `UPDATE account_auth_transactions SET status='failed',secrets_ciphertext=NULL,previous_session_token_hash=NULL,issued_session_token_hash=NULL,${CLEAR_TRANSACTION_POLICY_SQL} WHERE id=? AND browser_hash=? AND status IN ('created','claimed')`,
          )
          .bind(input.id, input.browserHash),
        db
          .prepare(
            `SELECT CASE WHEN expires_at<=${NOW} THEN 'expired' WHEN status IN ('created','claimed') THEN 'pending' ELSE status END AS status FROM account_auth_transactions WHERE id=? AND browser_hash=?`,
          )
          .bind(input.id, input.browserHash),
      ]);
      if (results.some((r) => !r.success)) return fail();
      return (
        (results[1].results?.[0] as
          | { status: "pending" | "completed" | "failed" | "expired" }
          | undefined) ?? null
      );
    },
    async completeGoogleLogin(input) {
      const identity = input.identity;
      if (
        !["https://accounts.google.com", "https://github.com"].includes(
          identity.issuer,
        ) ||
        !identity.subject ||
        identity.subject.length > 255
      )
        return fail();
      const transaction = await db
        .prepare(
          "SELECT intent AS purpose,provider,rights_only AS rightsOnly FROM account_auth_transactions WHERE id=? AND claim_nonce=? AND status='claimed'",
        )
        .bind(input.transactionId, input.claimNonce)
        .first<{ purpose: string; provider: string; rightsOnly: number }>();
      if (!transaction) return fail();
      if (
        transaction.provider !==
        (identity.issuer === "https://github.com" ? "github" : "google")
      )
        return fail();
      if (
        identity.issuer === "https://github.com" &&
        !/^[1-9][0-9]{0,19}$/.test(identity.subject)
      )
        return fail();
      if (transaction.rightsOnly === 1) return completeRightsAccess(db, input);
      if (transaction.purpose === "account_access")
        return completeAccountAccess(input);
      if (transaction.purpose === "link_provider") return completeLink(input);
      const locator = await externalLocator(
        identity.issuer,
        identity.subject,
        env,
        deps,
      );
      const email = contactEmail(identity.email);
      const authoritative =
        !!email &&
        identity.emailVerified &&
        identity.authoritativeEmail &&
        (identity.issuer === "https://github.com" ||
          email.endsWith("@gmail.com") ||
          !!identity.hostedDomain);
      const lookup = email ? await emailLookup(email, env, deps) : null;
      const legacy = email
        ? await keyedHash(env.ACCOUNT_IDENTITY_KEY!, email, deps)
        : null;
      const existing = await db
        .prepare(
          `SELECT a.id,a.security_version,a.deleted_at,'linked' AS source FROM account_external_identities e JOIN accounts a ON a.id=e.account_id WHERE e.issuer=? AND e.subject=?
        UNION ALL SELECT a.id,a.security_version,a.deleted_at,'tombstone' AS source FROM account_auth_tombstones t JOIN accounts a ON a.id=t.account_id WHERE t.locator_kind='external' AND t.locator_hmac=? AND t.expires_at>${NOW} LIMIT 1`,
        )
        .bind(identity.issuer, identity.subject, locator)
        .first<{
          id: string;
          security_version: number;
          deleted_at: number | null;
          source: string;
        }>();
      if ((!existing || existing.source === "tombstone") && !authoritative)
        throw new ApiError(
          403,
          "verified_email_required",
          "Add a primary verified email at your sign-in provider, then try again.",
        );
      if (existing?.source === "tombstone" && existing.deleted_at === null)
        throw new ApiError(
          409,
          "identity_conflict",
          "Sign in with your current method, then explicitly reconnect this provider from your account.",
        );
      if (
        !existing &&
        email &&
        (await db
          .prepare(
            `SELECT 1 FROM accounts WHERE identity_key=? OR (deleted_at IS NULL AND (email_lookup_key=? OR email=?))
        UNION ALL SELECT 1 FROM account_auth_tombstones WHERE locator_kind='email' AND locator_hmac=? AND expires_at>${NOW} LIMIT 1`,
          )
          .bind(legacy, lookup, email, lookup)
          .first())
      )
        throw new ApiError(
          409,
          "identity_conflict",
          "Sign in with your usual method, then connect this provider from your account. Existing accounts cannot be merged.",
        );
      if (existing?.source === "linked" && existing.deleted_at !== null)
        return fail();
      if (existing && env.ACCOUNT_ABUSE_ENABLED === "true") {
        const restriction = await getAbuseAccountStatus(db, existing.id);
        if (restriction.suspended)
          throw new ApiError(
            403,
            "account_suspended",
            "Service access is temporarily suspended. You can still verify your account for data access or deletion.",
            Math.max(
              1,
              Math.ceil(
                (Date.parse(restriction.suspendedUntil!) - deps.now()) / 1000,
              ),
            ),
          );
      }
      const accountId = existing?.id ?? deps.randomUUID();
      const protectedEmail = authoritative
        ? await protectEmail(email!, accountId, env, deps)
        : null;
      const displayName = normalizeDisplayName(identity.displayName);
      const protectedName = displayName
        ? await protectDisplayName(displayName, accountId, env, deps)
        : null;
      const condition = existing
        ? `EXISTS(SELECT 1 FROM accounts a WHERE a.id=? AND a.security_version=? AND ${existing.source === "linked" ? "a.deleted_at IS NULL AND EXISTS(SELECT 1 FROM account_external_identities e WHERE e.account_id=a.id AND e.locator_hmac=?)" : `a.deleted_at IS NOT NULL AND EXISTS(SELECT 1 FROM account_auth_tombstones t WHERE t.account_id=a.id AND t.locator_kind='external' AND t.locator_hmac=? AND t.expires_at>${NOW})`})`
        : `NOT EXISTS(SELECT 1 FROM account_external_identities WHERE locator_hmac=?)
           AND NOT EXISTS(SELECT 1 FROM account_auth_tombstones WHERE locator_kind='external' AND locator_hmac=? AND expires_at>${NOW})
           AND NOT EXISTS(SELECT 1 FROM accounts WHERE identity_key=? OR (deleted_at IS NULL AND (email_lookup_key=? OR email=?)))
           AND NOT EXISTS(SELECT 1 FROM account_auth_tombstones WHERE locator_kind='email' AND locator_hmac=? AND expires_at>${NOW})
           AND (SELECT COUNT(*) FROM accounts WHERE deleted_at IS NULL) < ?`;
      const conditionValues = existing
        ? [existing.id, existing.security_version, locator]
        : [
            locator,
            locator,
            legacy,
            lookup,
            email,
            lookup,
            limit(env.ACCOUNT_MAX_ACCOUNTS, 1000, 10000),
          ];
      // Every write is gated by this transaction's winning nonce. Recheck the
      // identity/version/capacity inside one batch, after any preliminary reads.
      const gate = `SELECT 1 FROM account_auth_transactions WHERE id=? AND claim_nonce=? AND status='claimed' AND purpose='sign_in' AND expires_at>${NOW} AND account_id=? AND ${TRANSACTION_POLICY_SQL} AND ${ABUSE_ALLOWED_SQL("account_auth_transactions.account_id")}`;
      const liveInitiator = `(previous_session_token_hash IS NULL OR EXISTS(SELECT 1 FROM account_sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token_hash=account_auth_transactions.previous_session_token_hash AND s.expires_at>${NOW} AND a.deleted_at IS NULL))`;
      const gateValues = [input.transactionId, input.claimNonce, accountId];
      const results = await db.batch([
        // New account FK is deferred until it exists: account_id is set below.
        db
          .prepare(
            `INSERT INTO accounts(id,identity_key,identity_scheme,email_ciphertext,email_encryption_key_version,email_lookup_key,email_verification_source,email_verified_at,privacy_notice_version,created_at,last_seen_at)
          SELECT ?,?,'federated-v1',?,?,?,?,${NOW},?,${NOW},${NOW}
          WHERE ?=1 AND EXISTS(SELECT 1 FROM account_auth_transactions WHERE id=? AND claim_nonce=? AND status='claimed' AND expires_at>${NOW} AND ${TRANSACTION_POLICY_SQL} AND ${liveInitiator}) AND ${condition}`,
          )
          .bind(
            accountId,
            `fed-v1:${accountId}`,
            protectedEmail?.ciphertext ?? null,
            protectedEmail?.keyVersion ?? null,
            protectedEmail?.lookupKey ?? null,
            transaction.provider,
            PRIVACY_NOTICE_VERSION,
            existing ? 0 : 1,
            input.transactionId,
            input.claimNonce,
            ...conditionValues,
          ),
        db
          .prepare(
            `UPDATE account_auth_transactions SET account_id=? WHERE id=? AND claim_nonce=? AND status='claimed' AND expires_at>${NOW} AND ${TRANSACTION_POLICY_SQL} AND ${liveInitiator}
          AND ${existing ? condition : "EXISTS(SELECT 1 FROM accounts WHERE id=? AND identity_key=?)"}`,
          )
          .bind(
            accountId,
            input.transactionId,
            input.claimNonce,
            ...(existing
              ? conditionValues
              : [accountId, `fed-v1:${accountId}`]),
          ),
        db
          .prepare(
            `UPDATE accounts SET last_seen_at=${NOW},privacy_notice_version=?,deleted_at=NULL,display_name_ciphertext=COALESCE(?,display_name_ciphertext) WHERE id=? AND EXISTS(${gate})`,
          )
          .bind(
            PRIVACY_NOTICE_VERSION,
            protectedName,
            accountId,
            ...gateValues,
          ),
        db
          .prepare(
            `UPDATE accounts SET email=NULL,email_ciphertext=?,email_encryption_key_version=?,email_lookup_key=?,email_verification_source=?,email_verified_at=${NOW}
          WHERE id=? AND ?=1 AND EXISTS(${gate})`,
          )
          .bind(
            protectedEmail?.ciphertext ?? null,
            protectedEmail?.keyVersion ?? null,
            protectedEmail?.lookupKey ?? null,
            transaction.provider,
            accountId,
            existing?.source === "tombstone" && authoritative ? 1 : 0,
            ...gateValues,
          ),
        db
          .prepare(
            `INSERT INTO account_external_identities(id,account_id,issuer,subject,locator_hmac,created_at,last_authenticated_at)
          SELECT ?,?,?,?,?,${NOW},${NOW} WHERE EXISTS(${gate}) AND NOT EXISTS(SELECT 1 FROM account_external_identities WHERE issuer=? AND subject=?)`,
          )
          .bind(
            deps.randomUUID(),
            accountId,
            identity.issuer,
            identity.subject,
            locator,
            ...gateValues,
            identity.issuer,
            identity.subject,
          ),
        db
          .prepare(
            `UPDATE account_external_identities SET last_authenticated_at=${NOW} WHERE issuer=? AND subject=? AND account_id=? AND EXISTS(${gate})`,
          )
          .bind(identity.issuer, identity.subject, accountId, ...gateValues),
        db
          .prepare(
            `INSERT INTO account_sessions(token_hash,account_id,expires_at) SELECT ?,?,${NOW}+86400000 WHERE EXISTS(${gate})`,
          )
          .bind(input.sessionTokenHash, accountId, ...gateValues),
        db
          .prepare(
            `INSERT INTO account_session_metadata(token_hash,method,authenticated_at,security_version) SELECT ?,'oidc',${NOW},security_version FROM accounts WHERE id=? AND EXISTS(${gate})`,
          )
          .bind(input.sessionTokenHash, accountId, ...gateValues),
        db
          .prepare(
            `UPDATE account_auth_transactions SET issued_session_token_hash=? WHERE id=? AND claim_nonce=? AND status='claimed' AND purpose='sign_in' AND expires_at>${NOW} AND account_id=? AND ${TRANSACTION_POLICY_SQL}
            AND EXISTS(SELECT 1 FROM account_sessions s JOIN account_session_metadata m ON m.token_hash=s.token_hash WHERE s.token_hash=? AND s.account_id=account_auth_transactions.account_id AND m.method='oidc')`,
          )
          .bind(input.sessionTokenHash, ...gateValues, input.sessionTokenHash),
        db
          .prepare(
            `DELETE FROM account_sessions WHERE token_hash=(SELECT previous_session_token_hash FROM account_auth_transactions WHERE id=?) AND EXISTS(${gate})`,
          )
          .bind(input.transactionId, ...gateValues),
        db
          .prepare(
            `DELETE FROM account_sessions WHERE token_hash IN(SELECT token_hash FROM account_sessions WHERE account_id=? AND token_hash!=? ORDER BY expires_at DESC,token_hash LIMIT -1 OFFSET 9) AND EXISTS(${gate})`,
          )
          .bind(accountId, input.sessionTokenHash, ...gateValues),
        db
          .prepare(
            `INSERT INTO account_policy_authorizations(account_id,privacy_notice_version,terms_version,purpose_version,authorized_at)
          SELECT account_id,policy_privacy_notice_version,policy_terms_version,policy_purpose_version,policy_authorized_at FROM account_auth_transactions WHERE id=? AND claim_nonce=? AND account_id=? AND status='claimed' AND purpose='sign_in' AND expires_at>${NOW} AND ${TRANSACTION_POLICY_SQL}
          AND issued_session_token_hash=? AND EXISTS(SELECT 1 FROM account_sessions s JOIN account_session_metadata m ON m.token_hash=s.token_hash WHERE s.token_hash=issued_session_token_hash AND s.account_id=account_auth_transactions.account_id AND s.expires_at>${NOW} AND m.method='oidc')
          ${POLICY_UPSERT_SQL}`,
          )
          .bind(...gateValues, input.sessionTokenHash),
        db
          .prepare(
            `UPDATE account_auth_transactions SET status='completed',secrets_ciphertext=NULL,previous_session_token_hash=NULL,issued_session_token_hash=NULL,${CLEAR_TRANSACTION_POLICY_SQL} WHERE id=? AND claim_nonce=? AND status='claimed' AND purpose='sign_in'`,
          )
          .bind(input.transactionId, input.claimNonce),
        db
          .prepare(
            "SELECT expires_at AS expiresAt FROM account_sessions WHERE token_hash=?",
          )
          .bind(input.sessionTokenHash),
      ]);
      if (results.some((r) => !r.success)) return fail();
      const session = results[13].results?.[0] as
        { expiresAt: number } | undefined;
      if (!session) return fail();
      return session;
    },
  };
}
