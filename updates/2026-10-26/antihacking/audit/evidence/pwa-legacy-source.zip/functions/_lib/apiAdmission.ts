import type { AccountBindings } from "./accounts";
import { abuseErrorResponse, enforceAbuse, type AbuseRoute } from "./abuse";
import {
  ApiError,
  jsonResponse,
  methodNotAllowed,
  SECURITY_HEADERS,
} from "./http";

export interface ApiAdmissionContext {
  readonly request: Request;
  readonly env: AccountBindings;
  next(): Promise<Response>;
}

/** Classification owns a finite key space. Query parameters, transaction IDs
 * and unknown paths never become a new stored bucket class. */
export function classifyApiRequest(request: Request): AbuseRoute | null {
  let pathname = new URL(request.url).pathname;
  try {
    pathname = decodeURIComponent(pathname);
  } catch {
    return "public-read";
  }
  pathname = pathname.replace(/\/{2,}/g, "/").replace(/\/$/, "");
  if (
    /^\/api\/auth\/v1\/rights\/(?:google|github)\/start$/.test(pathname) ||
    pathname === "/api/account/data" ||
    pathname === "/api/account/delete"
  )
    return null;
  if (/^\/api\/auth\/v1\/oidc\/(?:google|github)\/callback$/.test(pathname))
    return "callback";
  if (/^\/api\/auth\/v1\/oidc\/(?:google|github)\/start$/.test(pathname))
    return "auth-start";
  if (
    /^\/api\/auth\/v1\/transactions\/[^/]+\/(?:status|cancel)$/.test(pathname)
  )
    return "auth-status";
  if (pathname === "/api/account/otp/request") return "otp-request";
  if (pathname === "/api/account/otp/verify") return "otp-verify";
  if (pathname === "/api/account/authorize") return "export-authorize";
  if (
    pathname === "/api/account/logout" ||
    pathname === "/api/account/policy" ||
    (pathname === "/api/admin/blog/posts" && request.method !== "GET")
  )
    return "account-write";
  if (
    /^\/api\/account\/(?:session|identity|login)$/.test(pathname) ||
    pathname === "/api/admin/accounts/emails" ||
    pathname === "/api/admin/blog/session"
  )
    return "account-read";
  return "public-read";
}

function secure(response: Response) {
  const result = new Response(response.body, response);
  for (const [name, value] of Object.entries(SECURITY_HEADERS))
    result.headers.set(name, value);
  return result;
}

export async function handleApiAdmission(context: ApiAdmissionContext) {
  try {
    const configuredHosts = context.env.API_ALLOWED_HOSTS;
    if (configuredHosts !== undefined) {
      const hosts = configuredHosts.split(",").map((host) => host.trim());
      const url = new URL(context.request.url);
      if (
        !hosts.length ||
        hosts.some((host) => !/^[a-z0-9]+(?:[.-][a-z0-9]+)*$/.test(host)) ||
        url.protocol !== "https:" ||
        url.port ||
        !hosts.includes(url.hostname)
      )
        throw new ApiError(
          403,
          "unapproved_host",
          "Use the official application address.",
        );
    }
    // Reject impossible envelopes before D1/provider work. Provider labels,
    // user-agent strings and claimed email addresses never grant extra budget.
    if (context.request.url.length > 8192)
      throw new ApiError(414, "uri_too_long", "The request URL is too long.");
    if (!["GET", "HEAD", "POST"].includes(context.request.method))
      return secure(methodNotAllowed(["GET", "HEAD", "POST"]));
    const length = context.request.headers.get("Content-Length");
    if (length !== null) {
      if (!/^\d{1,10}$/.test(length))
        throw new ApiError(
          400,
          "invalid_content_length",
          "The request size header is invalid.",
        );
      if (Number(length) > 32768)
        throw new ApiError(
          413,
          "payload_too_large",
          "The request exceeds the allowed size.",
        );
    }
    if (context.env.ACCOUNT_ABUSE_ENABLED === "true") {
      const route = classifyApiRequest(context.request);
      // Rights handlers validate their own session before using reserved
      // capacity; invalid proofs receive their own bounded network admission.
      if (route !== null) {
        if (!context.env.ACCOUNT_DB)
          throw new ApiError(
            503,
            "abuse_guard_unavailable",
            "Account protection is temporarily unavailable.",
          );
        await enforceAbuse({
          db: context.env.ACCOUNT_DB,
          secret: context.env.ACCOUNT_AUTH_LOCATOR_KEY,
          request: context.request,
          route,
        });
      }
    }
    return secure(await context.next());
  } catch (error) {
    const limited = abuseErrorResponse(error);
    if (limited) return secure(limited);
    if (error instanceof ApiError)
      return secure(
        jsonResponse(
          {
            error: {
              code: error.code,
              message: error.publicMessage,
              ...(error.retryAfterSeconds
                ? { retryAfter: error.retryAfterSeconds }
                : {}),
            },
          },
          error.status,
          error.retryAfterSeconds
            ? { "Retry-After": String(error.retryAfterSeconds) }
            : undefined,
        ),
      );
    return secure(
      jsonResponse(
        {
          error: {
            code: "api_unavailable",
            message:
              "The service is temporarily unavailable. Your draft is still here.",
          },
        },
        503,
      ),
    );
  }
}
