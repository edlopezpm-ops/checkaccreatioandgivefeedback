import { ApiError } from "../http";
import { normalizeDisplayName } from "./privacy";
import type { RuntimeDependencies } from "../platform";
import type { ValidatedGithubIdentity } from "./oidc-contracts";

export const GITHUB_AUTHORIZE = "https://github.com/login/oauth/authorize";
const TOKEN = "https://github.com/login/oauth/access_token";
const USER = "https://api.github.com/user";
const EMAILS = "https://api.github.com/user/emails";

async function providerText(
  url: string,
  init: RequestInit,
  deps: RuntimeDependencies,
) {
  const response = await deps.fetch(url, {
    ...init,
    redirect: "manual",
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    await response.body?.cancel();
    throw new ApiError(
      503,
      response.status === 403
        ? "provider_permission_required"
        : "provider_unavailable",
      "GitHub could not verify this authorization. Check the app's email permission or try again.",
    );
  }
  if (
    !response.headers.get("Content-Type")?.includes("application/json") ||
    !response.body
  )
    throw new Error("provider_response_invalid");
  const reader = response.body.getReader();
  const maximum = url === TOKEN ? 32_768 : 262_144;
  const chunks: Uint8Array[] = [];
  let size = 0;
  while (true) {
    const part = await reader.read();
    if (part.done) break;
    size += part.value.byteLength;
    if (size > maximum) {
      await reader.cancel();
      throw new Error("provider_response_too_large");
    }
    chunks.push(part.value);
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return {
    text: new TextDecoder("utf-8", { fatal: true }).decode(bytes),
    next: /<[^>]+>;\s*rel="next"/.test(response.headers.get("Link") ?? ""),
  };
}

/** Extract only the top-level numeric ID lexeme, before JSON number coercion.
 * Profile names/handles and nested or duplicate id properties cannot replace it.
 */
export function githubSubject(text: string): string {
  let depth = 0,
    subject: string | undefined;
  for (let i = 0; i < text.length; i++) {
    const character = text[i];
    if (character === '"') {
      const start = i++;
      for (; i < text.length; i++) {
        if (text[i] === "\\") {
          i++;
          continue;
        }
        if (text[i] === '"') break;
      }
      if (depth === 1 && JSON.parse(text.slice(start, i + 1)) === "id") {
        const match = /^\s*:\s*([1-9][0-9]{0,19})(?=\s*[,}])/.exec(
          text.slice(i + 1),
        );
        if (match) {
          if (subject !== undefined) throw new Error("duplicate_identity");
          subject = match[1];
        } else if (/^\s*:/.test(text.slice(i + 1)))
          throw new Error("invalid_identity");
      }
    } else if (character === "{" || character === "[") depth++;
    else if (character === "}" || character === "]") depth--;
  }
  const parsed: unknown = JSON.parse(text);
  if (
    !parsed ||
    typeof parsed !== "object" ||
    Array.isArray(parsed) ||
    !subject
  )
    throw new Error("invalid_identity");
  return subject;
}

export async function authorizeGithubIdentity(
  settings: { clientId: string; clientSecret: string; redirectUri: string },
  secrets: { verifier: string; state: string },
  callback: URL,
  deps: RuntimeDependencies,
): Promise<ValidatedGithubIdentity> {
  if (callback.searchParams.get("state") !== secrets.state)
    throw new Error("invalid_state");
  if (callback.searchParams.has("error"))
    throw new ApiError(
      403,
      "provider_cancelled",
      "GitHub authorization was cancelled. Your draft is preserved; try again when ready.",
    );
  const code = callback.searchParams.get("code");
  if (!code || code.length > 2048) throw new Error("invalid_code");
  const tokenResponse = await providerText(
    TOKEN,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client_id: settings.clientId,
        client_secret: settings.clientSecret,
        redirect_uri: settings.redirectUri,
        code,
        code_verifier: secrets.verifier,
      }),
    },
    deps,
  );
  const token = JSON.parse(tokenResponse.text) as Record<string, unknown>;
  if (
    typeof token.access_token !== "string" ||
    !/^[A-Za-z0-9_-]{1,512}$/.test(token.access_token) ||
    String(token.token_type).toLowerCase() !== "bearer" ||
    token.error
  )
    throw new ApiError(
      403,
      "provider_authorization_invalid",
      "GitHub authorization expired or is invalid. Start sign-in again.",
    );
  // Only these fixed endpoints receive the transient token. Refresh tokens,
  // avatars, repositories and all other provider fields are discarded.
  const headers = {
    Accept: "application/vnd.github+json",
    Authorization: `Bearer ${token.access_token}`,
    "X-GitHub-Api-Version": "2026-03-10",
    "User-Agent": "accreatio-identity",
  };
  const userResponse = await providerText(USER, { headers }, deps);
  const subject = githubSubject(userResponse.text);
  const user = JSON.parse(userResponse.text) as Record<string, unknown>;
  let email: string | null = null;
  for (let page = 1; page <= 10; page++) {
    const response = await providerText(
      `${EMAILS}?per_page=100&page=${page}`,
      { headers },
      deps,
    );
    const values: unknown = JSON.parse(response.text);
    if (!Array.isArray(values) || values.length > 100)
      throw new Error("provider_emails_invalid");
    for (const candidate of values) {
      if (
        candidate &&
        typeof candidate === "object" &&
        candidate.primary === true &&
        candidate.verified === true &&
        typeof candidate.email === "string"
      ) {
        const value = candidate.email.trim().toLowerCase();
        if (email !== null && email !== value)
          throw new Error("ambiguous_primary_email");
        email = value;
      }
    }
    if (!response.next) break;
    if (page === 10) throw new Error("provider_email_pagination_limit");
  }
  return {
    issuer: "https://github.com",
    subject,
    email,
    emailVerified: email !== null,
    authoritativeEmail: email !== null,
    displayName: normalizeDisplayName(user.name),
  };
}
