# Decisions

## DEC-019 — One-question creation flow and autonomous click-responsive nebula

Status: implementation and preparation for testing authorized by Ed Lopez, 2026-09-04. Final user acceptance remains pending. See `docs/design-v11/DESIGN.md` and its result record.

Replace the grouped creation screens with a sequential questionnaire using the existing project definition, validation, draft and execution boundaries. Keep an explicit Continue for text, preserve answers on Back, allow editing from Review, and retain the final dry-run/confirmation controls. The current instruction supersedes the earlier wait for owner drawings; the old flow remains buildable behind a build-time legacy selector until hosted acceptance, as required by the archive policy.

Supersede DEC-018's pointer-carried light and the retained parallax contract: increase autonomous motion, remove all atmosphere response to pointer movement, and allow a bounded smoke burst only on a primary left click on exposed visible moving gas. UI and empty-sky clicks cannot trigger it. Reduced motion, pause, visibility, device constraints and renderer fallbacks remain authoritative.

Reuse native browser controls, CSS, React and the owned shader; add no visual service, dependency, public API or privileged operation. Existing Access, D1, publisher, export, Git and provider contracts remain outside this frontend change. A protected test deployment uses the existing Pages project and retains predecessor deployments. This does not represent user acceptance or activate publishing.

The bounded legacy copy is required recovery capacity, not a second maintained product. Ceiling: preserve the prior build until Ed accepts v11; reconsider at that acceptance, with archive disposition recorded separately rather than automatic deletion. Owner: Ed Lopez. Introduced by design v11. Verification includes both build selections; the independent parent audit evaluates the added presentation complexity.

Owner scope update during this increment: accreatio is web-first; freeze desktop development and release work. Apply the supplied orbital identity to web branding, favicon, PWA icons and social preview, while retaining previous desktop assets and installer configuration. The orbital symbol has a luminous spherical core, cyan/violet paths and a satellite; the geometric lowercase wordmark and exact tagline `FROM IDEA TO STRUCTURE` are local vector assets, without downloaded fonts. Final validation and deployment target the web build. This supersedes the desktop-release expectation for this increment, not its host isolation or execution safeguards.

## DEC-018 — Owned procedural nebula, single-sans hierarchy, and quiet instrument palette

Status: Accepted by owner authorization, Ed Lopez, 2026-09-01, after the owner rejected the shipped frontend and asked for a sober, modern, Scandinavian-restraint result with a near-real interactive nebula. Local verification passed; **no independent audit has been performed for this increment**, and the Electron execute smoke was not run locally because this checkout's `node_modules/electron` binary was replaced by an empty OneDrive placeholder. Neither omission may be presented as evidence of a pass.

Decision: supersede DEC-014's Vanta/Three rendering technique and DEC-015's display-serif typography role. Render the nebula with an accreatio-owned GLSL fragment shader in `src/components/nebula.ts`: value-noise fbm under two-level domain warping, dust-lane absorption, two emission cores (one anchored in the gas, one carried by the pointer), micro star grains, and ordered dither against banding. Remove the `vanta` and `three` dependencies and their ambient module declarations; the module is lazy-imported and owns nothing outside the canvas it is handed.

Typography: retire the serif display face. Brand, headings, UI, body, and controls all resolve to the one host-resident sans stack, separated by weight and size rather than by family; mono remains for code and technical counters. This reverses DEC-015's explicit "display serif for editorial headings" clause, which was the standing contract that the previous frontend expressed. The no-webfont rule is unchanged: no `@font-face`, no font bytes, no remote font request, and the Project Map keeps `font-src 'none'`.

Palette and surfaces: replace the violet-tinted dark theme with a near-black blue-grey ground (`#0a0c14`) and the lilac light theme with a near-white ground (`#f5f5f7`). Panels become translucent blurred instruments over the nebula rather than opaque cards; borders become low-contrast hairlines derived from the text color; navigation and pills lose their boxes. All sixteen final text/status pairs were checked at or above 4.5:1 before the values were written.

Interface honesty: field errors surface only once the user has tried to leave a stage, not while a field they have not reached is merely still empty; and a stage the user has never opened can no longer advertise itself as complete on the strength of its defaults. Redundant copy was removed where the shell already states the same fact.

Consequences: the atmosphere no longer depends on a third-party rendering library, so its behavior, cost, and failure modes are fully owned and readable in one file. Every existing safeguard is preserved unchanged — reduced motion, save-data, slow update, hidden page, absent or lost WebGL, coarse pointer, 30 fps cap, and DPR ceiling all still fall back to the static local composition. Recorded evidence: 215/215 unit and source-contract tests, typecheck across all three graphs, format check, project-map file:// smoke, the W1 browser functional smoke (WebGL canvas animating, pointer-parallax geometry, theme switch preserving the canvas, Blog, ZIP export), and Lighthouse performance 95 / accessibility 100 / best-practices 100. This increment changes presentation only: no schema, flow, IPC, filesystem/Git execution, credential, Mode 1 semantic, attachment, or editorial behavior is touched.

## DEC-017 — Separate web and Electron renderer graphs

Status: Accepted by owner authorization, Ed Lopez, 2026-08-06; design gate, full local/Windows verification, fresh exact-commit Claude audit, and protected deployment passed. Authenticated hosted acceptance remains pending.

Decision: Build the web renderer from `index.html` into `dist/` and the Electron renderer from `desktop.html` into `dist-desktop/`. Inject the Blog destination only from the web entry. The shared `App` and desktop entry must not import the Blog reader, publisher, editorial API client/styles, PWA registration, or founding content. Electron loads `dist-desktop/desktop.html`, and packaging allowlists `dist-desktop/**/*`; `functions/`, migrations, Wrangler configuration, the web output, and editorial fixtures remain outside the desktop package.

Consequences: the Blog and all portal administration are web-only by construction rather than by a runtime flag. Both builds, a complete desktop artifact scan, Electron UI checks, and web Blog/editor checks are release gates. Project creation remains shared where host-neutral; the desktop application retains its existing navigation and behavior.

## DEC-016 — Authenticated web-only editorial channel

Status: Accepted by owner authorization, Ed Lopez, 2026-08-06; independent design gate, full local/Windows verification, fresh exact-commit Claude audit, and protected deployment passed. Release `0.8.0` is deployed but not represented as fully accepted or enabled for human/agent publishing.

Decision: Preserve the accepted definition: “accreatio is an authenticated, local-first, ephemeral-session web application for creating and exporting projects.” Add a web-only Blog backed by same-origin Cloudflare Pages Functions and a free-tier D1 database. D1 is the sole runtime source for published posts, including the three reviewed founding posts. Publishing is append-only in this increment: no editing, deletion, scheduling, media upload, or backdating.

Authentication and authorization: every Blog route independently validates `Cf-Access-Jwt-Assertion` with the fixed Access issuer, accepted application audience, RS256 signature from the team JWKS, token lifetime, and an exact human-or-service claim shape. Human publishing requires both verified email and subject to match the encrypted admin map. AEKR automation requires an empty subject, no email, and an allowlisted verified `common_name` from a separately issued revocable Access service token. Both resolve immediately to safe actor labels; raw emails, subjects, client IDs, JWTs, and token secrets are not stored or intentionally logged. Browser writes additionally require same-origin `Origin`, JSON, the custom publish header, and a UUID idempotency key. Server authorization remains mandatory even when the UI hides the composer.

Data boundary: persistent editorial rows and the Cloudflare request/authentication metadata needed to deliver and protect the portal are a separate disclosed data class. The editorial backend receives no project form content, attachment bytes, project ZIPs, local paths, or optional GitHub/IDE/AI credentials. Project generation/export remains local-first and available without connecting an external service. “Ephemeral-session” refers to accreatio-operated server-side project and integration state; it does not describe the deliberate IndexedDB project draft or published editorial posts.

Consequences: production and preview require separate D1 bindings and may use distinct Access audiences. The fixed issuer, audiences, human map, and agent map remain protected runtime configuration, not source literals. Agent publishing cannot be described as active until its narrow Service Auth policy and a real allowlisted token are exercised. Cloudflare Pages Functions and D1 must remain within the zero-direct-cost constraint; any paid requirement stops rollout before charge. Design and evidence are in `docs/design-v8/`.

## DEC-015 — Layered procedural starfield and responsive glass instruments

Status: Accepted by owner authorization, Ed Lopez, 2026-08-05; independently audited after push at `7a7e511595a8ab820e09b46de21903170b390e1c` with **PASS WITH NON-BLOCKING IMPROVEMENTS**.

Decision: Supersede only DEC-014's nebula speed, single CSS star plane, and the current Home/About glass-width treatment. Double every view-specific Vanta speed exactly. Replace the synchronized CSS star pattern with one local deterministic 2D canvas behind the nebula: three depth bands, right-weighted density, distinct sizes, distinct per-star periods/phases, bounded non-linear drift, and fine-pointer parallax that increases from far/small to near/large. Treat 2/3/5 mm as CSS reference boxes for autonomous drift around each star anchor, not as guaranteed physical monitor measurements and not as a cap on the separate parallax offset.

Layout and typography: cap About with a fluid approximately 62rem measure that shrinks to its available viewport, remove the ultrawide expansion, reduce excessive hero height/spacing, and share a slightly more transparent blurred instrument surface across onboarding/Home creation and About. Preserve the existing original typography roles across the product: display serif for editorial headings, sans for UI/body/control text, and mono only for technical counters/code. Remove stale selectors and literal overrides that accidentally change those roles; do not add or download a font.

AEKR provenance extension: before final independent audit, the owner additionally required the supplied full AEKR banner in the root README and a responsive copy in the Project Map footer beside its canonical-source contract. Keep one source PNG plus its copy-along notice under `assets/`; embed the PNG's exact bytes at generation time so the interactive HTML remains self-contained under `img-src data:`. The banner is acknowledgment, not runtime AEKR coupling or certification. The separate AEKR repository adopted the general future-project rule through its own explicit upstream decision at `d872514719520735f19fa107d87f7ba3e18f4b9d`.

Runtime boundary: the star plane is a second presentation-only canvas, separate from the one Vanta WebGL canvas. It uses no dependency, image, network, project data, storage, IPC, credential, or privileged capability. Rendering is capped at 30 fps and DPR 1.5, pauses while hidden, becomes static for reduced motion/save-data/slow-update, and ignores coarse pointers. This increment did not itself authorize deployment; DEC-009's later 2026-08-06 decision separately permits only an access-restricted, zero-cost beta.

Evidence boundary: by explicit owner instruction, this increment receives rendered visual testing only. Build is allowed solely to produce the browser artifact used for inspection; prior automated v4 results remain historical and must not be presented as new v5 test evidence. The implementation/evidence commit must be pushed before Claude performs a fresh complete read-only repository/AEKR audit. Claude reports only; Codex may reconcile documentation afterward without silently implementing audited code suggestions.

Consequences: two presentation canvases and one additional bounded animation loop replace the old one-canvas invariant. GPU/CPU/battery, visibility lifecycle, density/readability, cross-monitor CSS-mm approximation, visual-only regression scope, and the generated map's larger embedded-banner size remain explicit risks. Full design and acceptance evidence live in `docs/archive/2026-09-05/design-v5/DESIGN.md`.

## DEC-014 — Local WebGL nebula, orbital-a identity, and cool light mode

Status: Accepted by owner authorization, Ed Lopez, 2026-08-05; independently audited after push at `7da2707` with **PASS WITH NON-BLOCKING IMPROVEMENTS**.

Decision: Supersede only DEC-013's CSS-only atmosphere technique, v3 mark geometry, and cream light-palette direction after the owner rejected that visual result and explicitly expanded scope. Use one persistent local Vanta `FOG`/Three renderer for autonomous motion plus accreatio-owned bounded pointer parallax, a right-to-left density mask, counter-moving CSS depth/fallback, and view-specific legibility. Use a new transparent orbital lowercase-`a` SVG and deterministic derived PWA/social/Windows assets. Add a small transparent “Built with AEKR” signature as a non-interactive governed-build acknowledgment. The five-stage flow, local-first behavior, no-Skip onboarding, brand-to-home semantic, and execution controls remain unchanged; DEC-009 continues to own deployment policy.

Runtime boundary: pin `vanta@0.5.24` and `three@0.185.1`, bundle both locally, and dynamically import them only when WebGL, motion/update preferences, connection settings, and page visibility permit. Vanta's input controls remain disabled; it receives no project data or privileged capability. Missing/failed/lost WebGL, reduced motion, slow updates, save-data, and hidden documents fall back to a static local CSS composition. No CDN, remote image, telemetry, API, service, account, deployment, or direct monetary cost is introduced.

Governance profile: **Full/high-risk for governed delivery**, inherited from the complete product's filesystem/Git preparation and optional human-gated orchestration surface plus the owner's explicit audit requirement. The implementation commit must be pushed before Claude performs a complete read-only repository/AEKR audit. Claude reports gaps only; Codex owns any post-audit documentation reconciliation and must not silently implement reported code improvements as part of the audit.

Consequences: the atmosphere now has a GPU/runtime dependency and a materially larger lazy chunk. Vanta's age and documented Three-version mismatch, WebGL power/context behavior, motion sensitivity, bundle/precache cost, and expanded supply chain remain explicit open risks. The current runtime pair is accepted only on the evidence recorded for this phase. This visual increment did not authorize deployment; DEC-009's later bounded-beta decision is authoritative. Full design and rollback detail is in `docs/archive/2026-09-05/design-v4/DESIGN.md`.

## DEC-013 — Procedural atmosphere, vector identity, and Full-governance delivery

Status: Accepted by owner authorization, Ed Lopez, 2026-08-05; independently audited after push.

Decision: Preserve the design-v2 guided product flow while superseding its narrower no-geometry-change/no-looping-atmosphere constraints with the owner's explicit v3 mandate. Use a corrected vector mark and one persistent, original CSS atmosphere; animate only slow transforms/opacity, pause when hidden, honor reduced motion, and reduce layers on constrained displays. Keep the functional instrument more opaque than the environment. Use one brand-to-home semantic and no onboarding Skip escape hatch.

Governance profile: **Full/high-risk for governed delivery**. The product remains local-first and zero-service-cost, but it controls filesystem/Git preparation and optional human-gated orchestration; the owner also explicitly requires independent final audit. Full treatment applies to design/change-control/risk/audit evidence without claiming that every visual change is itself high risk.

Consequences: CSS/SVG remain preferred over Canvas/WebGL or a visual dependency. Dark/light themes share semantic tokens. This increment did not authorize hosting; DEC-009's later access-restricted-beta decision is authoritative. The prior design-v2 constraints remain historical evidence, not current direction where DEC-013 conflicts with them.

## DEC-012 — Explicit funding policy; paid API unavailable

Status: Accepted by Human Design Gate, Ed Lopez, 2026-08-05.

Decision: Default to the exact `subscription_cli`/USD-zero policy. Keep the existing provider-invocation maximum as a distinct call-count limit. Enable API only after a compiled provider/model profile and versioned AEKR runtime prove an exact cumulative pre-invocation cost hard stop; zero current profiles qualify.

Consequences: Paid API remains visibly unavailable with no credential fields or fallback. Provenance records the policy, draft schema is v5, and runnable AEKR YAML removes the fixed Claude budget and commented ceiling without adding an unsupported funding key.

## DEC-011 — Compiled capability-driven provider registry

Status: Accepted by Human Design Gate, Ed Lopez, 2026-08-05.

Decision: Replace independent Claude Code/Codex switches with one compiled registry containing exactly those two evidenced production providers. Provider assignment is keyed by participant ID. Capabilities, fixed desktop probes, fail-closed subscription-auth classifiers, availability states, and exact current AEKR serializers are registry-owned. W1 reports detection as unsupported while retaining deterministic export.

Consequences: Adding production support is an owner-reviewed code and evidence change, not a dynamic plug-in action. No provider manifest, download, credential storage, user-authored command, shell, API-key execution, telemetry, or automatic paid fallback is introduced. Availability is ephemeral and desktop Mode 1 start rechecks required adapters. Unknown IDs remain visible and block generation rather than silently becoming Claude Code.

## DEC-010 — Participant identity is separate from canonical role

Status: Accepted by Human Design Gate, Ed Lopez, 2026-08-05.

Decision: Represent project topology as an ordered list of one to six stable participant instances. Participant IDs are the identity and association key; the four canonical roles describe responsibility and may repeat. Array position is the sole order. Browser drafts use schema version 3 and generated provenance uses schema version 2.

Current AEKR compatibility: its consumed YAML contract is role-keyed, so accreatio emits runnable Mode 1 YAML only for one to four participants with unique roles. Repeated-role or five/six-participant Mode 1 plans fail closed with `orchestrationContractUnsupported`; Mode 0/manual remains available. A participant-aware upstream AEKR schema is a separate future decision.

Consequences: Role edits preserve participant identity, provider, and task. Bootstrap availability and independence are assessed per participant instance. An auditor sharing the context/tool invocation of audited work is self-review, not independent audit. No participant is silently dropped, merged, aliased, or reduced.

## DEC-009 — Hosted web beta (access, hosting + custom domain)

**Status: ZERO-COST ACCESS-RESTRICTED BETA DEPLOYED; OWNER-AUTHENTICATED ACCEPTANCE PENDING — Cloudflare Pages Direct Upload is live behind separate production and preview Access applications; anonymous access, custom domain, and broad promotion remain unauthorized.**

Supersession note: DEC-016 authorizes Pages Functions and D1 only for the separate web editorial channel, and DEC-017 requires its exclusion from Electron. DEC-009 remains authoritative for the protected origin, zero-cost, anonymous-access, domain, and promotion boundaries; its static/no-backend restriction describes the historical `0.7.0` deployment, not the pending `0.8.0` candidate.

Operational update for `0.8.0`: the owner later connected the existing Pages project to GitHub. Two automatic production attempts failed before promotion. Automatic production and preview deployments are now paused through branch control, while the source connection remains installed; release continues only through the exact-commit Wrangler path required by the current runbook.

Context: Phase W1 (export-first PWA) is code-complete and locally verified as of 2026-08-03 — see `docs/PHASE_P1_PILOT_EVIDENCE.md` and `docs/WEB_STRATEGY.md`'s phase table (drafts, ZIP export, offline service-worker shell, accessibility hygiene all built and browser-tested against a local dev server and a local production preview build). None of that alone proves a hosted URL exists; live status requires deployment evidence in `CHANGE_CONTROL.md`.

The 2026-08-03 owner instruction selected the technical target while preserving the deployment hold. On 2026-08-06, Ed Lopez explicitly lifted the account-setup/publication hold for this bounded increment with “Modo AEKR. Full commit/deploy.”:

1. **Hosting platform and restricted beta publication: authorized.** Cloudflare Pages Direct Upload may create/deploy the static W1 project through an owner-authenticated Wrangler session at zero direct cost, only after the Full release gates pass.
2. **Public identity: bounded.** The inferred Pages project name is `accreatio`; if unavailable, deployment pauses instead of selecting another name silently.
3. **Custom domain: still unauthorized.** The free `*.pages.dev` origin is the only approved beta origin. Any purchased/custom domain requires separate written approval. Changing origins later does not migrate IndexedDB drafts or installed-PWA state.
4. **Access boundary: mandatory.** Before the first production asset upload, Cloudflare Access must protect the production `*.pages.dev` hostname and permit only copyright-holder-approved identities; the initial allowlist is the owner. Unauthenticated access must fail closed. Access configuration and credentials remain outside the repository.
5. **Promotion boundary: unchanged.** Formal legal/trademark review, a deliberate public-use license, and the remaining public-release gates stay open before anonymous access or broad promotion. The first release is a restricted beta, not a claim of general-availability readiness.

Decision: **Restricted beta deployed on 2026-08-06.** Tests, independent review, exact-commit CI, zero-cost checks, owner-authenticated account setup, exact-production and wildcard-preview Access configuration, anonymous fail-closed probes, and static Direct Upload cleared before publication. The deployed source is `39ea088175e69430fa9f2539681ea978b264675d`; deployment evidence is recorded in `CHANGE_CONTROL.md`. No anonymous/public policy, DNS, custom domain, paid capability, Function, Worker, KV, analytics, backend, or telemetry is authorized. Owner-authenticated hosted UX/header/offline/network/Lighthouse acceptance remains open; see `docs/W1_RELEASE_READINESS.md`.

Consequence: the canonical beta origin is `https://accreatio.pages.dev`, protected for owner-approved identities; the immutable deployment origin is recorded in `CHANGE_CONTROL.md`. Browser drafts remain origin-bound; export before any future origin change. Any Access-policy drift or anonymous `200` response is an immediate no-go requiring the project to be disabled before investigation. DEC-008's legal-review gate continues to block anonymous public distribution; this decision permits only the narrower owner-authorized private beta.

Cross-references: `docs/WEB_STRATEGY.md` (phase table), `docs/archive/2026-09-05/PROGRAM_P0_RECONCILIATION.md` §10 (SaaS/deployment hold boundary), `RISKS.md` ("Custom domain cost silently accepted as a default").

## DEC-008 — Product identity: accreatio

Status: Accepted; supersedes DEC-005.

Decision: Use lowercase **accreatio** for the product and generated provenance directory `.accreatio`.

Rationale: The name evokes accretion: dispersed material becoming a coherent structure, matching the app's job of turning project inputs into a governed starting point.

Consequence: Legacy Inflaton and Periastron settings/history are migrated. This is product-name screening, not formal trademark clearance; anonymous public distribution remains gated on legal review. DEC-009 separately permits an access-restricted, owner-authorized beta.

## DEC-005 — Product identity

Status: Accepted

Decision: Rename the product to **Inflaton**, the hypothetical scalar field associated with cosmic inflation.

Rationale: The inflaton is associated with the universe's initial rapid expansion; the product similarly turns a compact project definition into an expanding, governed workspace. Current search found academic/user handles but no directly competing project-bootstrap product under the name.

Consequence: This is product-name screening, not formal trademark clearance. Public distribution remains gated on legal search.

## DEC-006 — Existing targets and attachments

Status: Accepted

Decision: Augment existing roots and version every colliding generated file. Copy attachments as opaque allowlisted files; never move, parse, or execute them.

## DEC-007 — Web evolution

Status: Accepted

Decision: Build an export-first PWA, then optionally pair it with a consent-based local companion. Do not run arbitrary user commands in a hosted multi-tenant backend.

## DEC-001 — Desktop framework

Status: Accepted for MVP

Context: Windows-first local filesystem and process access are required, with future web UI reuse and zero service cost.

Options: React + Tauri; React + Electron; PySide6; Flutter.

Decision: React + TypeScript + Electron.

Rationale: Node is installed on the target machine; Rust is not. Electron enables immediate implementation and shares the complete renderer with a web future.

Consequences: Larger bundle and memory footprint than Tauri. Privileged APIs must remain behind IPC.

## DEC-002 — No generic shell executor

Status: Accepted

Decision: Use Node filesystem APIs and a fixed Git process call with argument arrays.

Rationale: This prevents project form text from becoming executable shell content and works across PowerShell/CMD differences.

## DEC-003 — Existing targets

Status: Accepted

Decision: Reject the entire run when any planned root target exists.

Rationale: A hard failure is understandable, reversible, and safer than merge semantics.

## DEC-004 — Remote repositories

Status: Deferred

Decision: No remote creation in MVP.

Rationale: The core value does not require GitHub, and local-only behavior protects privacy and cost.
