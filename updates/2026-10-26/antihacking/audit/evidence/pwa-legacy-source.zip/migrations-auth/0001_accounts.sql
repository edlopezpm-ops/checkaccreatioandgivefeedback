-- Separate database; contains no project data and grants no Blog authority.
CREATE TABLE accounts (
  id TEXT PRIMARY KEY,
  identity_key TEXT NOT NULL UNIQUE,
  email TEXT,
  created_at INTEGER NOT NULL,
  last_seen_at INTEGER NOT NULL,
  deleted_at INTEGER
);
CREATE INDEX accounts_email_export ON accounts(id) WHERE email IS NOT NULL;
CREATE INDEX accounts_retention ON accounts(last_seen_at);
CREATE TABLE account_sessions (
  token_hash TEXT PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE INDEX sessions_account ON account_sessions(account_id, expires_at);
CREATE INDEX sessions_expiry ON account_sessions(expires_at);
CREATE TABLE export_authorizations (
  account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  operation_id TEXT NOT NULL,
  issued_at INTEGER NOT NULL,
  PRIMARY KEY (account_id, operation_id)
);
CREATE INDEX authorizations_window ON export_authorizations(account_id, issued_at);
CREATE INDEX authorizations_retention ON export_authorizations(issued_at);
