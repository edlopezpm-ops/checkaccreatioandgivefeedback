-- Access-era sessions are revoked once. Account IDs, identity HMACs and rolling
-- export receipts remain unchanged; never rotate ACCOUNT_IDENTITY_KEY here.
DELETE FROM account_sessions;

CREATE TABLE account_otp_challenges (
  id TEXT PRIMARY KEY,
  identity_key TEXT NOT NULL,
  email TEXT,
  purpose TEXT NOT NULL CHECK (purpose = 'sign_in'),
  verifier TEXT,
  ip_key TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  delivered_at INTEGER,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts BETWEEN 0 AND 5),
  last_attempt_key TEXT,
  consumed_at INTEGER,
  consumption_key TEXT UNIQUE,
  invalidated_at INTEGER
);
CREATE INDEX otp_identity_window ON account_otp_challenges(identity_key, created_at);
CREATE INDEX otp_ip_window ON account_otp_challenges(ip_key, created_at);
CREATE INDEX otp_retention ON account_otp_challenges(created_at);
CREATE INDEX otp_expiry ON account_otp_challenges(expires_at);
CREATE INDEX accounts_deleted_retention ON accounts(deleted_at) WHERE deleted_at IS NOT NULL;
