-- Separate, bounded security state. No request body, email, raw IP or project data.
CREATE TABLE account_abuse_buckets (
  scope_key TEXT NOT NULL,
  scope_kind TEXT NOT NULL CHECK(scope_kind IN ('network','account','session')),
  route_class TEXT NOT NULL,
  window_start INTEGER NOT NULL,
  request_count INTEGER NOT NULL CHECK(request_count BETWEEN 0 AND 1000),
  blocked_until INTEGER NOT NULL DEFAULT 0,
  strikes INTEGER NOT NULL DEFAULT 0 CHECK(strikes BETWEEN 0 AND 5),
  last_excess_at INTEGER NOT NULL DEFAULT 0,
  expires_at INTEGER NOT NULL,
  PRIMARY KEY(scope_key,route_class)
);
CREATE INDEX abuse_buckets_expiry ON account_abuse_buckets(expires_at);
CREATE INDEX abuse_buckets_kind ON account_abuse_buckets(scope_kind);

CREATE TABLE account_abuse_state (
  account_id TEXT PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
  level INTEGER NOT NULL DEFAULT 0 CHECK(level BETWEEN 0 AND 3),
  excess_count INTEGER NOT NULL DEFAULT 0 CHECK(excess_count BETWEEN 0 AND 2),
  episode_window_start INTEGER NOT NULL,
  last_episode_at INTEGER NOT NULL,
  suspended_until INTEGER NOT NULL DEFAULT 0,
  recurrence_until INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  revision INTEGER NOT NULL DEFAULT 0 CHECK(revision >= 0)
);
CREATE INDEX abuse_state_expiry ON account_abuse_state(expires_at);

-- A fixed scratch row is overwritten and consumed within each transactional
-- batch. It retains no request identifier or caller-controlled data.
CREATE TABLE account_abuse_gate (
  id INTEGER PRIMARY KEY CHECK(id=1),
  allowed INTEGER NOT NULL DEFAULT 0,
  principal_valid INTEGER NOT NULL DEFAULT 0,
  own_excess INTEGER NOT NULL DEFAULT 0,
  retry_at INTEGER NOT NULL DEFAULT 0,
  suspended_until INTEGER NOT NULL DEFAULT 0,
  prior_revision INTEGER NOT NULL DEFAULT 0,
  reason TEXT NOT NULL DEFAULT 'unavailable'
);
INSERT INTO account_abuse_gate(id) VALUES(1);
