-- No historical account or in-flight challenge is assigned an authorization.
-- A row exists only after two affirmative choices and valid account proof.
CREATE TABLE account_policy_authorizations (
  account_id TEXT PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
  privacy_notice_version TEXT NOT NULL,
  terms_version TEXT NOT NULL,
  purpose_version TEXT NOT NULL,
  authorized_at INTEGER NOT NULL
);

ALTER TABLE account_auth_transactions ADD COLUMN policy_privacy_notice_version TEXT;
ALTER TABLE account_auth_transactions ADD COLUMN policy_terms_version TEXT;
ALTER TABLE account_auth_transactions ADD COLUMN policy_purpose_version TEXT;
ALTER TABLE account_auth_transactions ADD COLUMN policy_authorized_at INTEGER;
ALTER TABLE account_auth_transactions ADD COLUMN purpose TEXT NOT NULL DEFAULT 'sign_in' CHECK (purpose IN ('sign_in','account_access'));
ALTER TABLE account_auth_transactions ADD COLUMN access_security_version INTEGER;
ALTER TABLE account_auth_transactions ADD COLUMN issued_session_token_hash TEXT;

ALTER TABLE account_otp_challenges ADD COLUMN policy_privacy_notice_version TEXT;
ALTER TABLE account_otp_challenges ADD COLUMN policy_terms_version TEXT;
ALTER TABLE account_otp_challenges ADD COLUMN policy_purpose_version TEXT;
ALTER TABLE account_otp_challenges ADD COLUMN policy_authorized_at INTEGER;

-- Conditional writes can stop matching if the database clock reaches expiry
-- between statements. Completing must abort the entire batch in that case,
-- including any earlier account/profile/session or authorization writes.
-- The marker is set only after this transaction issued a session and is cleared
-- by the completing statement; it is never retained on a terminal transaction.
CREATE TRIGGER account_auth_transactions_complete_integrity
BEFORE UPDATE OF status ON account_auth_transactions
WHEN NEW.status='completed' AND OLD.status='claimed'
BEGIN
  SELECT CASE WHEN OLD.expires_at <= unixepoch()*1000
    OR OLD.account_id IS NULL
    OR OLD.issued_session_token_hash IS NULL
    OR NOT EXISTS (
      SELECT 1 FROM account_sessions s
      JOIN accounts a ON a.id=s.account_id
      JOIN account_session_metadata m ON m.token_hash=s.token_hash
      WHERE s.token_hash=OLD.issued_session_token_hash
        AND s.account_id=OLD.account_id
        AND s.expires_at>unixepoch()*1000
        AND a.deleted_at IS NULL
        AND m.method='oidc' AND m.security_version=a.security_version
        AND (OLD.purpose='sign_in' OR a.security_version=OLD.access_security_version)
    )
    OR (OLD.purpose='sign_in' AND (
      OLD.policy_authorized_at IS NULL OR NOT EXISTS (
        SELECT 1 FROM account_policy_authorizations p
        WHERE p.account_id=OLD.account_id
          AND p.privacy_notice_version=OLD.policy_privacy_notice_version
          AND p.terms_version=OLD.policy_terms_version
          AND p.purpose_version=OLD.policy_purpose_version
      )
    ))
    THEN RAISE(ABORT,'auth_completion_incomplete') END;
END;

-- Compatible older deletion writers must not retain a policy receipt either.
CREATE TRIGGER accounts_purge_policy_authorization_after_delete
AFTER UPDATE OF deleted_at ON accounts
WHEN NEW.deleted_at IS NOT NULL
BEGIN
  DELETE FROM account_policy_authorizations WHERE account_id=NEW.id;
END;
