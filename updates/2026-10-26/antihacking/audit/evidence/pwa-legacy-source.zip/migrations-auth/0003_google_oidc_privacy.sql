-- Additive only. Preserve legacy IDs, ACCOUNT_IDENTITY_KEY and quota receipts.
ALTER TABLE accounts ADD COLUMN identity_scheme TEXT NOT NULL DEFAULT 'legacy-email-v1';
ALTER TABLE accounts ADD COLUMN security_version INTEGER NOT NULL DEFAULT 0;
ALTER TABLE accounts ADD COLUMN email_ciphertext TEXT;
ALTER TABLE accounts ADD COLUMN email_encryption_key_version TEXT;
ALTER TABLE accounts ADD COLUMN email_lookup_key TEXT;
ALTER TABLE accounts ADD COLUMN email_verification_source TEXT;
ALTER TABLE accounts ADD COLUMN email_verified_at INTEGER;
ALTER TABLE accounts ADD COLUMN privacy_notice_version TEXT;
CREATE UNIQUE INDEX accounts_email_lookup ON accounts(email_lookup_key) WHERE deleted_at IS NULL AND email_lookup_key IS NOT NULL;
CREATE INDEX accounts_email_backfill ON accounts(id) WHERE email IS NOT NULL;

CREATE TABLE account_external_identities (
  id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  issuer TEXT NOT NULL,
  subject TEXT NOT NULL,
  locator_hmac TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL,
  last_authenticated_at INTEGER NOT NULL,
  UNIQUE(issuer, subject)
);
CREATE INDEX external_identities_account ON account_external_identities(account_id);
CREATE TABLE account_auth_tombstones (
  locator_kind TEXT NOT NULL CHECK(locator_kind IN ('external', 'email')),
  locator_hmac TEXT NOT NULL,
  account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL,
  PRIMARY KEY(locator_kind, locator_hmac)
);
CREATE INDEX auth_tombstones_expiry ON account_auth_tombstones(expires_at);

CREATE TABLE account_auth_transactions (
  id TEXT PRIMARY KEY,
  state_hash TEXT NOT NULL UNIQUE,
  browser_hash TEXT NOT NULL,
  ip_hash TEXT NOT NULL,
  secrets_ciphertext TEXT,
  return_mode TEXT NOT NULL CHECK(return_mode IN ('redirect', 'popup')),
  previous_session_token_hash TEXT,
  account_id TEXT REFERENCES accounts(id) ON DELETE SET NULL,
  status TEXT NOT NULL CHECK(status IN ('created', 'claimed', 'completed', 'failed', 'expired')),
  claim_nonce TEXT UNIQUE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX auth_transactions_browser ON account_auth_transactions(browser_hash, created_at);
CREATE INDEX auth_transactions_ip ON account_auth_transactions(ip_hash, created_at);
CREATE INDEX auth_transactions_retention ON account_auth_transactions(created_at);
CREATE INDEX auth_transactions_expiry ON account_auth_transactions(expires_at);
CREATE TABLE account_session_metadata (
  token_hash TEXT PRIMARY KEY REFERENCES account_sessions(token_hash) ON DELETE CASCADE,
  method TEXT NOT NULL CHECK(method IN ('oidc', 'email-otp')),
  authenticated_at INTEGER NOT NULL,
  security_version INTEGER NOT NULL
);
-- Reject new authorizations when a concurrently revoked session was checked
-- outside the batch. Application statements also recheck inside the write.
