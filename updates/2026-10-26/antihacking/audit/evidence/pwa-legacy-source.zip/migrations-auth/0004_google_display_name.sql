-- Additive profile display data. No identity, contact or quota changes.
ALTER TABLE accounts ADD COLUMN display_name_ciphertext TEXT;

-- The older compatible writer does not know this column. Its deletion must
-- still erase the profile name while retaining the quota tombstone account.
CREATE TRIGGER accounts_purge_display_name_after_delete
AFTER UPDATE OF deleted_at ON accounts
WHEN NEW.deleted_at IS NOT NULL AND NEW.display_name_ciphertext IS NOT NULL
BEGIN
  UPDATE accounts SET display_name_ciphertext=NULL WHERE id=NEW.id;
END;
