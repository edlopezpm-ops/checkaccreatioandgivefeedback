-- Additive scopes: an existing row remains an ordinary transaction/session.
ALTER TABLE account_auth_transactions ADD COLUMN rights_only INTEGER NOT NULL DEFAULT 0 CHECK(rights_only IN (0,1));
ALTER TABLE account_session_metadata ADD COLUMN rights_only INTEGER NOT NULL DEFAULT 0 CHECK(rights_only IN (0,1));
CREATE INDEX account_auth_rights_ip ON account_auth_transactions(rights_only,ip_hash,created_at);
CREATE INDEX account_auth_rights_window ON account_auth_transactions(rights_only,created_at);

CREATE TRIGGER account_auth_rights_creation_scope
BEFORE INSERT ON account_auth_transactions WHEN NEW.rights_only=1
BEGIN
  SELECT CASE WHEN NEW.purpose!='account_access' OR NEW.intent!='account_access'
    OR NEW.verification_action IS NULL OR NEW.verification_action NOT IN ('data','delete')
    OR NEW.previous_session_token_hash IS NOT NULL OR NEW.account_id IS NOT NULL
    OR NEW.access_security_version IS NOT NULL OR NEW.policy_authorized_at IS NOT NULL
    OR NEW.policy_privacy_notice_version IS NOT NULL OR NEW.policy_terms_version IS NOT NULL OR NEW.policy_purpose_version IS NOT NULL
    THEN RAISE(ABORT,'rights_creation_scope') END;
END;

CREATE TRIGGER account_session_rights_scope
BEFORE INSERT ON account_session_metadata WHEN NEW.rights_only=1
BEGIN
  SELECT CASE WHEN NEW.method!='oidc' OR NEW.verification_action IS NULL OR NEW.verification_action NOT IN ('data','delete')
    OR NEW.authenticated_at>unixepoch()*1000 OR NEW.authenticated_at<=unixepoch()*1000-300000
    OR NOT EXISTS(SELECT 1 FROM account_sessions s JOIN accounts a ON a.id=s.account_id
      WHERE s.token_hash=NEW.token_hash AND s.expires_at>unixepoch()*1000 AND s.expires_at<=NEW.authenticated_at+300000
      AND a.deleted_at IS NULL AND a.security_version=NEW.security_version)
    THEN RAISE(ABORT,'rights_session_scope') END;
END;

CREATE TRIGGER account_session_rights_immutable
BEFORE UPDATE OF rights_only,verification_action,authenticated_at,security_version ON account_session_metadata
WHEN OLD.rights_only!=NEW.rights_only OR (OLD.rights_only=1 AND (
  OLD.verification_action IS NOT NEW.verification_action OR OLD.authenticated_at!=NEW.authenticated_at OR OLD.security_version!=NEW.security_version))
BEGIN
  SELECT RAISE(ABORT,'rights_session_scope_immutable');
END;

CREATE TRIGGER account_auth_rights_immutable
BEFORE UPDATE OF rights_only ON account_auth_transactions WHEN OLD.rights_only!=NEW.rights_only
BEGIN
  SELECT RAISE(ABORT,'rights_transaction_scope_immutable');
END;

CREATE TRIGGER account_auth_rights_completion_scope
BEFORE UPDATE OF status ON account_auth_transactions
WHEN NEW.status='completed' AND OLD.status='claimed' AND OLD.rights_only=1
BEGIN
  SELECT CASE WHEN OLD.purpose!='account_access' OR OLD.intent!='account_access'
    OR OLD.expires_at<=unixepoch()*1000
    OR OLD.verification_action IS NULL OR OLD.verification_action NOT IN ('data','delete')
    OR OLD.previous_session_token_hash IS NOT NULL OR OLD.policy_authorized_at IS NOT NULL
    OR OLD.policy_privacy_notice_version IS NOT NULL OR OLD.policy_terms_version IS NOT NULL OR OLD.policy_purpose_version IS NOT NULL
    OR NOT EXISTS(SELECT 1 FROM account_sessions s
      JOIN account_session_metadata m ON m.token_hash=s.token_hash JOIN accounts a ON a.id=s.account_id
      JOIN account_external_identities e ON e.account_id=a.id
      WHERE s.token_hash=OLD.issued_session_token_hash AND a.id=OLD.account_id AND a.deleted_at IS NULL
      AND a.security_version=OLD.access_security_version AND m.security_version=a.security_version
      AND m.rights_only=1 AND m.method='oidc' AND m.verification_action=OLD.verification_action
      AND s.expires_at>unixepoch()*1000 AND s.expires_at<=m.authenticated_at+300000
      AND e.issuer=CASE OLD.provider WHEN 'github' THEN 'https://github.com' ELSE 'https://accounts.google.com' END)
    THEN RAISE(ABORT,'rights_completion_scope') END;
END;
