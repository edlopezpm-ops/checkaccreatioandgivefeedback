-- No account FK, email, network hash, URL, project text, or cross-product ID.
CREATE TABLE collection_permissions (
  token_hash TEXT PRIMARY KEY,
  purpose TEXT NOT NULL CHECK (purpose IN ('analytics','research')),
  notice_version TEXT NOT NULL,
  granted_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  revoked_at INTEGER
);
CREATE TABLE collection_records (
  id TEXT PRIMARY KEY,
  token_hash TEXT NOT NULL REFERENCES collection_permissions(token_hash) ON DELETE CASCADE,
  recorded_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  payload_json TEXT NOT NULL CHECK(length(payload_json) <= 4096)
);
CREATE INDEX collection_expiry ON collection_records(expires_at);
CREATE INDEX collection_permission_records ON collection_records(token_hash,recorded_at);
CREATE INDEX collection_permission_expiry ON collection_permissions(expires_at);
