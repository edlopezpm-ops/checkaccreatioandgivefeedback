-- Additive: retain existing account IDs, sessions, identities and receipts.
-- purpose remains compatible with the preceding writer; intent distinguishes
-- explicit linking from account controls without rebuilding the live table.
ALTER TABLE account_auth_transactions ADD COLUMN provider TEXT NOT NULL DEFAULT 'google' CHECK(provider IN ('google','github'));
ALTER TABLE account_auth_transactions ADD COLUMN intent TEXT NOT NULL DEFAULT 'sign_in' CHECK(intent IN ('sign_in','account_access','link_provider'));
ALTER TABLE account_auth_transactions ADD COLUMN verification_action TEXT CHECK(verification_action IN ('data','delete','link_google','link_github'));
ALTER TABLE account_auth_transactions ADD COLUMN failure_code TEXT;
ALTER TABLE account_auth_transactions ADD COLUMN initiator_authenticated_at INTEGER;
UPDATE account_auth_transactions SET intent=purpose;
ALTER TABLE account_session_metadata ADD COLUMN verification_action TEXT CHECK(verification_action IN ('data','delete','link_google','link_github'));

-- Session, provider and account changes during the batch must roll back every
-- write. In particular, linkage never survives a failed session rotation.
CREATE TRIGGER account_auth_transactions_link_integrity
BEFORE UPDATE OF status ON account_auth_transactions
WHEN NEW.status='completed' AND OLD.status='claimed' AND OLD.intent='link_provider'
BEGIN
  SELECT CASE WHEN OLD.initiator_authenticated_at IS NULL
    OR OLD.initiator_authenticated_at<=unixepoch()*1000-300000
    OR NOT EXISTS (
    SELECT 1 FROM account_external_identities e
    JOIN account_sessions s ON s.account_id=e.account_id
    JOIN accounts a ON a.id=s.account_id
    JOIN account_session_metadata m ON m.token_hash=s.token_hash
    WHERE e.account_id=OLD.account_id
      AND e.issuer=CASE OLD.provider WHEN 'github' THEN 'https://github.com' ELSE 'https://accounts.google.com' END
      AND s.token_hash=OLD.issued_session_token_hash
      AND s.expires_at>unixepoch()*1000
      AND a.deleted_at IS NULL AND a.security_version=OLD.access_security_version
      AND m.security_version=a.security_version
  ) THEN RAISE(ABORT,'auth_link_incomplete') END;
END;
