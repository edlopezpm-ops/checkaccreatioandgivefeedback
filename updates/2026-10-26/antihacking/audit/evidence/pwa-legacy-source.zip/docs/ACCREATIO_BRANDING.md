# accreatio official branding

Owner approval: **Ed Lopez, 2026-10-22**. The owner supplied the new logo and instructed: “Documentalo, ese es el que usaremos”. This supplied artwork is the official accreatio identity for the web redesign.

![Official accreatio logo](../public/branding/accreatio-lockup.png)

## Canonical original

The original PNG is preserved byte for byte at [`assets/branding/accreatio-logo-approved-2026-10-22.png`](../assets/branding/accreatio-logo-approved-2026-10-22.png). It is 1536 × 1024 pixels and 1,368,825 bytes.

SHA-256: `0c53ade5c085e5867541ab933a53288b35e8157f9b1e7698c6536725e5a4b71a`.

The [provenance manifest](../assets/branding/accreatio-logo-approved-2026-10-22.provenance.json) records the approval, pinned original, palette and exact crop rectangles. The supplied symbol, red dot, lettering and proportions are artwork. Do not redraw, trace, retype or recreate them with generative tools. The canonical original, full-resolution PNG crops and light SVGs preserve the supplied pearl texture. The owner separately authorized a dark-surface adaptation on 2026-10-22: “En la versión dark cuida que no se vea el fondo blanco del logo/logotypo.” The bounded native SVG filter described below removes the pale plate and maps the exact raster contours to pearl and red on dark surfaces. Other recoloring, removal or replacements require owner authorization.

## Palette

| Role                                     | Color          |
| ---------------------------------------- | -------------- |
| Iceland matte pearl, default background  | `#E8EAE7`      |
| Charcoal, principal titles and bold text | `#303235`      |
| Intense red, sparse contrast details     | `#E2232A`      |
| Body text, dark mineral gray             | `#515852`      |
| Subtext, one lighter mineral gray step   | `#5E655E`      |

The owner specified the background/title/accent mapping and delegated the body
and subtext choices on 2026-10-22. Body `#515852` and subtext `#5E655E` retain a
quiet gray hierarchy and readable contrast on the pearl surfaces. These are the
values already applied in the deployed pearl theme. Dark-mode reading values
remain recorded separately in the [design palette](DESIGN_ICELAND_PEARL_2026-10-22.md).

These values guide surrounding UI. The supplied image and light derivatives retain their original texture and pixel variations. The owner-authorized dark adaptation uses pearl `#E8EAE7` for neutral logo strokes and intense red `#E2232A` for its dot. Preserve the existing application typography; display the official logo lettering from the image rather than approximating it with a font.

## Public derivatives

Run `node scripts/render-web-brand-assets.mjs`. The local renderer first verifies the canonical PNG hash. It then retains full-resolution integer pixel crops as PNG files. Symbol and separate wordmark SVGs embed those exact crops. The displayed complete-logo SVG embeds a proportional half-resolution crop, **631 × 155 pixels**, using deterministic high-quality canvas downscaling to reduce the web payload. PWA and social derivatives also use proportional scaling; the social image starts from the full-resolution crop. The renderer makes no network requests and adds no dependency or service.

| Derivative                                                                              | Source rectangle `(x, y, width, height)` | Consumers                                 |
| --------------------------------------------------------------------------------------- | ---------------------------------------- | ----------------------------------------- |
| `accreatio-mark.png`, `accreatio-mark-light.svg`, `accreatio-mark-dark.svg`             | `(144, 342, 284, 302)`                   | Symbol and favicon                        |
| `accreatio-wordmark.png`, `accreatio-wordmark-light.svg`, `accreatio-wordmark-dark.svg` | `(480, 426, 920, 170)`                   | Supplied lettering when separately needed |
| `accreatio-lockup.png`, `accreatio-lockup-light.svg`, `accreatio-lockup-dark.svg`       | `(140, 338, 1262, 310)`                  | Complete official logo                    |
| `accreatio-web-192.png`, `accreatio-web-512.png`                                        | Proportional symbol placement            | PWA and touch icon                        |
| `accreatio-web-social.png`                                                              | Proportional complete logo placement     | 1200 × 630 social image                   |
| `accreatio-favicon-v2.svg`, `accreatio-favicon-v2-32.png`                                | Proportional symbol in a 64 × 64 raster  | Browser tab, with transparent 32px fallback |

All derivatives live in [`public/branding/`](../public/branding/). The SVG files contain cropped or proportionally scaled approved raster artwork, not newly drawn vector logos. The original master and the three full-resolution PNG crops retain their exact pixels; scaled display derivatives resample pixels and do not claim pixel equality with those originals. The light SVG files remain unchanged. Each dark SVG embeds the same source crop and adds the owner-authorized native SVG filter; it draws no paths, text or substitute shapes. The complete logo already contains the brand name, so a consumer using it should suppress duplicate adjacent accreatio text while retaining its accessible name.

### Transparent dark-surface adaptation

The dark variants use `color-interpolation-filters="sRGB"`. The charcoal stroke mask is `clamp(1.303030 − 1.515152 × R, 0, 1)` and the independent red-dot mask is `clamp(1.5 × (R − G) − 0.04, 0, 1)`, with normalized source channels. Native `feColorMatrix` filters derive those alpha masks from the embedded approved raster. `feFlood` and `feComposite` map them to pearl and red before `feMerge` combines them. The pale raster plate and its subtle texture fall below the alpha thresholds, producing a transparent surround; the red-channel mask excludes the red dot from the pearl strokes and avoids a pale halo around its edge. No cloud, generative image operation, font substitution or geometric reconstruction is used.

The renderer writes `.local/logs/nebula-alignment-20261022/dark-logo-transparent-preview.png` for visual checks of the symbol, lettering and complete lockup on `#242726` and `#303235`. The adaptation preserves their proportions and source contours while changing dark-mode output color and alpha; it does not claim pixel identity with the unchanged original.

### Browser favicon

On 2026-10-22 the owner requested replacement of the former purple browser-tab icon with the selected official symbol. The new, cache-safe `/branding/accreatio-favicon-v2.svg` path embeds a proportional 64 × 64 raster derivative rather than the full-size crop. It uses the same native alpha masks to remove the pale plate. Its neutral strokes are charcoal in a light browser color scheme and pearl under `prefers-color-scheme: dark`; the red dot remains `#E2232A`. The transparent 32 × 32 PNG fallback uses charcoal and red. Both derive their shapes from the approved symbol without redrawing it.

The renderer records 16px, 32px and 64px visual comparisons in `.local/logs/nebula-alignment-20261022/favicon-light-preview.png` and `favicon-dark-preview.png`. The new asset path avoids reusing the cached former SVG identity.

The renderer writes its visual comparison to ignored `.local/logs/playwright/official-branding-reference-preview.png`. The previous web design and logo remain recoverable in [`docs/design-backups/2026-10-22-pre-iceland/design-source.zip`](design-backups/2026-10-22-pre-iceland/design-source.zip).

## AEKR is separate

This approval replaces accreatio artwork only. Canonical AEKR assets, master banner and accepted footer remain governed by [AEKR asset preservation](AEKR_BRANDING.md). Do not substitute this logo for AEKR or alter its pinned copies. Verify them separately with `npm.cmd run aekr:branding:check`.
