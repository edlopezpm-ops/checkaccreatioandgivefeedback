# Web-only delivery and desktop retirement

**Authority:** Ed Lopez's direct instruction on 2026-10-22: the accreatio desktop prototype is obsolete, was not released, and will never be released. The product's future delivery is web-only. This supersedes earlier wording that described desktop development or releases as frozen.

## Current product boundary

The browser/PWA prepares project definitions, prompts, plans and inspectable ZIPs locally. Its separate account service handles identity, revocable sessions, account-processing/Terms receipts, allowance and own-account rights. The Blog and editorial service remain separate from project contents. Desktop filesystem, local Git/GitHub, IDE and orchestration execution are not current product capabilities.

## Delivery commands

| Command | Current behavior |
| --- | --- |
| `npm.cmd run dev`, `npm.cmd start`, `npm.cmd run dev:web` | Start the web development server |
| `npm.cmd run build`, `npm.cmd run build:web` | Build the web application and check publication artifacts |
| `npm.cmd run typecheck` | Check the shared browser application and edge Functions |
| `npm.cmd run verify` | Run web delivery checks, functional browser checks and account/identity/rights checks |
| `npm.cmd run test:surface` | Check the web surface without requiring a desktop build |
| `npm.cmd run dev:desktop`, `npm.cmd run build:desktop`, `npm.cmd run test:electron`, `npm.cmd run package:win` | Exit with failure and the explicit desktop retirement reason |

The CI workflow calls `npm run verify`, so it follows this web-only delivery boundary. Shared domain/source regression tests may still inspect retained prototype code; their passing results do not certify desktop execution or release. The historical artifact scanner retains its explicit desktop inspection mode solely for custody work; it is outside the release pipeline.

## Historical custody

`electron/`, `desktop.html`, `src/main.desktop.tsx`, the Electron bridge, legacy smoke scripts, renderer configuration, historical dependency records and packaging metadata remain in the repository for provenance and recovery. Historical packages and archive manifests remain in their existing locations. This change neither rebuilds them nor deletes, redistributes or promotes them as release candidates.

Earlier dated receipts record the tests, source, prototypes and artifacts that existed at the time. They remain historical evidence. Their references to desktop builds, packages, freezes or support do not authorize future desktop delivery and do not establish that the prototype was released. [SOP_DESKTOP.md](SOP_DESKTOP.md) is explicitly historical.

Direct invocation of retained low-level tools is not an authorized product workflow. The retirement guard blocks the documented npm desktop entry points; preserving source is not a technical claim that no one can compile it independently.

## Evidence scope

The retirement regression tests check the web defaults and the nonzero exit/reason returned by the guard. Current verification must use the web build, publication gate and functional web checks. Historical Electron build or smoke results are not reused as web release evidence. This lifecycle change does not by itself claim deployment, hosted verification, personal provider authorization or new product acceptance.

Electron, electron-builder, concurrently and wait-on were removed from active development dependencies. Legacy source and packaging metadata remain historical custody; the active web lockfile has no desktop packager.
