# Bounded abuse protection and footer release — 2026-10-22

## Delivered source and production

Implementation source: `73e2288df90843b81f2cfbb51dc90febe4f7cdd0`.

Production Pages deployment: `2c2558a5-31b1-495f-bf68-be8bf6f4de6e`, successful at `2026-10-22T18:20:19.269786Z`, [immutable deployment](https://2c2558a5.accreatio.pages.dev), [final domain](https://accreatio.com). Deployment metadata names the implementation commit and marks the checkout dirty because unrelated, pre-existing untracked documentary material remained outside the published build. No such material was added to this release. This receipt changes documentation only after the deployed source commit.

Production maintenance Worker: `accreatio-account-maintenance`, version `24d66201-966b-4f61-81c4-0373fa632761`, hourly schedule `17 * * * *`. Deployment/readback is not an observation of this version's scheduled execution.

Additive account migrations `0007_abuse_guard.sql` and `0008_rights_only.sql` applied to production and the isolated readiness-preview store. Production has eight migrations and no pending migration. Aggregate-only before/after migration readback retained three accounts, three linked identities, one session, three export authorizations and three policy receipts; the new restriction/rights state began empty. No historical sanction, acceptance or policy receipt was fabricated.

The production `ACCOUNT_ABUSE_ENABLED=true` binding and existing D1/secret-name configuration were read back after deployment. Google and GitHub remain available; email OTP remains disabled. No identity/privacy key was rotated, exported or displayed. Preview schema application does not claim a new preview application deployment.

## Behavior

- Fixed API route classes reserve atomic per-network/account/session budgets and return `429` with `Retry-After`. IPv4/IPv6 network values are purpose-separated HMACs; raw addresses, emails, user agents, bodies and project content are not retained by the guard.
- Three attributable eligible excess episodes in a rolling ten minutes trigger a ten-minute restriction; recurrence can escalate to one hour and then 24 hours. Cooldown retries, invalid proofs/input, ordinary quota exhaustion, shared-network excess and rights actions do not generate sanctions. Security-version changes and ordinary-session revocation are atomic. No automatic permanent closure or second-email/shared-IP ban was introduced.
- Independent, five-minute, action-scoped rights verification permits existing linked accounts to download/delete their data without ordinary access or new Terms acceptance. Separate cookies and completed transaction/account/action/security-version binding prevent ordinary-session escalation and cross-tab account replacement behind a pending confirmation. Logout remains idempotent after ordinary-session revocation.
- Current notices are `2026-10-22-privacy` / `2026-10-22-beta`; purpose remains `account-core-v1`. Latest restriction summary is included in own-account download. Necessary storage inventory and review/support routes are updated.
- Web/desktop publication disables source maps and a build gate rejects internal sources/configuration and unapproved archives. Static responses and API responses add one-day HSTS. The frontend delivered to a browser remains inspectable.
- Cookie preferences now shares the footer row with Instagram and canonical AEKR branding. The accepted pearl/dark palette, typography, nebula, logo and red Blog accent remain. The earlier design backup remains at `236748f`, `docs/design-backups/2026-10-22-pre-iceland/`.

See [the implementation and operations contract](ABUSE_GUARD_2026-10-22.md) for thresholds, retention, bounded capacity, cleanup, rights and rollback constraints.

## Verification

- Complete repository `verify` chain passed before the final narrow corrections. Final affected verification passed **423/423 unit/SQL/Miniflare tests**, app/Electron/Functions typecheck, formatting, Functions compilation and production builds. The new browser rights smoke is included in `verify` and separately passed on the final published build.
- Final rights browser smoke: EN/ES at 1280/320px, four cases. Exact 205-byte JSON download, incorrect transaction rejection, post-proof deletion confirmation, `Retry-After`, cancellation stopping polling, no ordinary-session adoption and no local-storage/IndexedDB writes. Provider fixtures were synthetic; isolated provider windows may require manual closure.
- Independent reviews of backend integration and guard/middleware closed with no pending blocker. Review found and corrected a transaction-completion expiry gap, pending episodes crossing old state expiry, cross-dimension cooldown attribution, and logout after session revocation. Regressions exercise each boundary. These bounded reviews are not a complete repository audit or penetration test.
- Visual review: 36 page/footer captures, six cookie dialogs and six expanded rights panels at 1440/390/320px, pearl/dark EN/ES. Footer control centers match exactly; targets are at least 44px, rights select 48px. No overflow/runtime errors. Final themed deletion button was separately inspected at desktop/mobile widths.
- Real packaged Windows diagnostic smoke passed with **17 byte-identical ASAR assets**, onboarding, renderer/preload, guarded filesystem execution, concurrent retry, failure recovery and history. Diagnostic package was not published or asserted as a signed desktop release.
- Lighthouse verification passed: performance 92, accessibility 100, best practices 100; SEO 69 retains the intentional private-beta noindex exemption.
- Production readback passed **28 byte-identical public assets, eight API/legal route checks, eight desktop/mobile theme views, eight legal-view checks and zero runtime errors**. Footer alignment, dark logo alpha, favicon/title, red Blog text, notice versions, disabled OTP and rejected rights/ordinary route-scope mismatches were checked. Asset comparisons used a release query to bypass old CDN header metadata; the bare root/API/legal responses also returned HSTS.
- Anonymous production rights start/status/cancel passed for Google and GitHub, without navigating to a provider or issuing an ordinary session. Only aggregate guard counters were read back; no production flood, real suspension, identity proof, personal account export or deletion was attempted.

Evidence: `.local/logs/abuse-20261022/`, `.local/logs/abuse-guard-20261022/`, `.local/logs/account-rights-ui-1792693135877/` and `.local/logs/packaged-nebula-alignment-1792692835208/`. Logs remain ignored under the repository retention rules.

## Limits

The active Cloudflare zone reports the Free Website plan, price zero. Zone-setting reads were denied with `403 / 9109`; no zone WAF/DDoS settings were changed or attack capacity verified. Static GET/asset traffic stays on CDN outside these API counters. Volumetric/ICMP protection belongs to the edge provider. Shared finite rights/callback capacity can still delay self-service under distributed exhaustion; the documented support route remains necessary.

Live D1 concurrency/load, full provider reauthentication and human acceptance were not inferred from synthetic SQL/browser tests, anonymous route checks or deployment success. Source/client minification cannot prevent F12 inspection or scraping of delivered content. No periodic independent-backup service, paid security feature or AI-based sanction decision was added.
