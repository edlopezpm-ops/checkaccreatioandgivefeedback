# Provider Registry and Support Contract

accreatio supports exactly two production providers: Claude Code and Codex. Both use a locally installed subscription CLI, desktop-only readiness detection, and deterministic AEKR adapter serialization. Provider assignment belongs to a stable participant ID; changing or reordering a participant's canonical role does not reassign its provider.

The compiled registry in `shared/providerRegistry.ts` is the sole source for provider identity, display order, capabilities, fixed diagnostic probes, authentication classifiers, availability vocabulary, and adapter serialization. It is deliberately not a plug-in loader. W1 may configure either registered provider and export the same deterministic YAML as desktop, but a browser cannot inspect local CLI installation or authentication and reports `unsupported_host`.

## Current support matrix

| Provider | Allowed funding/auth path | Desktop probes | AEKR adapter policy |
| --- | --- | --- | --- |
| Claude Code | Claude subscription CLI (`authMethod: claude.ai`) | `claude --version`; `claude auth status` | `kind: claude_code`; no monetary field |
| Codex | ChatGPT subscription CLI; API-key login is rejected | `codex --version`; `codex login status` | `kind: codex`; Implementer uses `workspace-write`, every other canonical role uses `read-only` |

Availability is ephemeral and is never saved in a project, draft, or YAML. Desktop execution checks the providers named by the selected AEKR configuration immediately before start. Export remains available without a successful check because artifact generation is deterministic and does not invoke a provider.

An allowlisted Cloudflare Access service identity for web-only Blog publishing is not an AI-provider credential and does not extend this registry. It authorizes only the append-only editorial endpoint, remains outside the repository/browser/D1, and grants no Claude, Codex, GitHub, IDE, project-data, or orchestration capability.

Both descriptors intentionally have no API model profiles and no `api_funding` or `exact_cumulative_cost_hard_stop` capability. See `docs/FUNDING_POLICY.md`. The current AEKR compatibility boundary accepts subscription adapter keys only; paid or legacy monetary keys fail fresh desktop preflight.

## Adding a production provider

A new provider requires an owner-approved code change with all of the following evidence:

- a stable safe ID, product label, and explicit evidenced capabilities;
- compiled executable names and fixed argument arrays, with no user/provider text entering a process command;
- a deterministic, fail-closed classifier for one approved authentication mode;
- an evidenced AEKR adapter kind and supported fields against the consumed upstream schema;
- exact serializer fixtures plus desktop/W1 availability and accessibility tests;
- a migration decision, security/threat review, documentation, and Human Design Gate approval.

Missing evidence means no production descriptor or UI option. Dynamic manifests, downloads, provider-supplied code, credential fields, API calls, telemetry, shell interpolation, and automatic paid fallback are prohibited. Test-only descriptors must remain inside tests and cannot be enabled by configuration, environment, or build flags.
