# Browser attachment security

Owner authority: Ed Lopez, 2026-10-22. accreatio is web-only. User-selected attachments admit only modern Word DOCX, PDF, PNG and JPEG. Legacy DOC, macro-enabled Word, scripts, executables, archives, JSON, text/Markdown, YAML, CSV, SVG and other formats are rejected. Generated project instructions/configuration and own-account JSON exports are separate trusted product outputs.

## Enforcement

The shared extension allowlist remains a metadata filter. The picker and final browser execution boundary additionally call `prepareAttachment`. The browser uses a disposable same-origin module worker, terminates inspection after ten seconds, and retains a module-private WeakMap proof only for the immutable reconstructed output Blob and exact filename. `buildWebExport` rejects unprepared bytes. Direct bridge calls undergo the same inspection before archive creation, prepared-ZIP retention, quota authorization or download. Changing a name or copying bytes into a new Blob does not copy proof.

Selection is serialized; after asynchronous processing the UI rechecks account/workspace generation, draft readiness, phase and attachment state. It updates metadata to reconstructed sizes and rechecks the existing 20-file, 20 MiB/file and 100 MiB/selection limits. Files remain in page memory and are never uploaded for inspection; restored drafts retain only the missing-file count and require re-selection. Malformed stored scalar/project shapes are rejected before rendering, with a visible recovery notice.

## Strict supported subset

- DOCX: bounded OPC ZIP parsing, fixed-size inflation, CRC/path/name/overlap checks, required Word package parts and parsed XML/relationships. Reject macros, OLE/embedded objects, active fields, external relationships/templates, DTD/entities, unsupported parts and malformed packages. Rebuild the ZIP; embedded PNG/JPEG media are reconstructed too. Complex Word features, external hyperlinks, fonts, uncommon OOXML namespaces/encodings and embedded objects can be rejected intentionally.
- PDF: parse actual object/stream syntax and encoded names, including compressed object streams; bounded raw/Flate decoding and dimension-checked JPEG streams. Reject encrypted/malformed PDFs, scripts, launch/submit/import/remote actions, automatic actions, embedded files, forms/XFA, rich media and unsupported codecs/filter combinations. Static internal navigation and HTTPS links are allowed. Rewrite the parsed document before export. The supported header is PDF 1.0–1.7; unsupported PDF 2.0, predictors and other codecs fail closed.
- PNG/JPEG: verify the signature and dimensions, actually decode and draw into a new canvas, then export fresh PNG/JPEG bytes. No fallback to original bytes. PNG transparency and decoded image orientation are retained; original metadata, polyglot suffixes and animation are not preserved. Browsers without module workers, bitmap decoding or OffscreenCanvas fail closed for these inputs.

Limits include 16 million pixels, 8192 pixels per dimension, 512 DOCX entries, 32 MiB total DOCX expansion, 4 MiB/XML part, 64 XML depth and 50,000 XML nodes. PDF bounds include 8 MiB/Flate stream, 32 MiB cumulative decoded streams, 2,000 pages, 20,000 indirect objects, 100,000 parsed objects and depth 64. Source tests and browser checks must verify these limits; unsupported features are not silently reinterpreted.

## Limits of this control

This is strict active-content admission and reconstruction, not a general antivirus engine or proof against unknown document-reader vulnerabilities. Static HTTPS links remain untrusted destinations and plain document text can still contain instructions; generated project governance tells downstream agents to treat attachments as untrusted reference data. No public client code can prevent someone from modifying their own browser or creating a malicious ZIP with unrelated software. accreatio does not host or distribute one user's project ZIP to another user.

No source minification/encryption can hide browser-delivered content from its visitor. Secrets and authorization remain server-side. Provider-independent network/session/account limits and Cloudflare edge protections address request abuse separately; see [the edge security record](EDGE_SECURITY_2026-10-22.md).
