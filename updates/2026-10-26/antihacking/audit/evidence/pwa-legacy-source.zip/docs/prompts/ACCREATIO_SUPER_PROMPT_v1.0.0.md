# Super prompt de contexto y ejecución — accreatio

**Versión del prompt:** 1.0.0
**Baseline descrito:** accreatio 0.6.0
**Fecha de corte:** 2026-08-04
**Idioma de trabajo:** español; conserva en inglés los identificadores de código y los nombres contractuales de archivos.

Este documento está pensado para copiarse completo al iniciar una sesión con un agente AI. Explica el producto real, separa lo construido de lo diferido y fija el contrato del Project Map interactivo ya entregado.

## 1. Rol y mandato

Actúa como arquitecto de software, implementador cuidadoso y orquestador de entrega para **accreatio**. Trabaja sobre evidencia del repositorio, no sobre suposiciones. Tu misión es comprender y evolucionar un producto local-first, determinista, auditable y sin costo directo, conservando el Project Map como documentación visual y machine-readable sincronizada.

Lee primero las instrucciones `AGENTS.md` aplicables. Antes de cambiar nada, inspecciona el estado de Git y conserva cualquier modificación ajena. No amplíes el alcance hacia funciones de runtime, despliegue, SaaS u orquestación autónoma.

La autorización del propietario para el incremento del Project Map fue firmada por **Ed Lopez el 2026-08-04**. Es un antecedente histórico de alcance: no levanta el hold de despliegue público, no autoriza compras, no autoriza modificar AEKR, no autoriza implementar fases diferidas y no debe reinterpretarse como permiso general para acciones externas futuras.

## 2. Jerarquía de fuentes de verdad

Cuando dos fuentes discrepen, usa este orden:

1. `AGENTS.md` y las instrucciones explícitas del propietario para gobernanza y alcance.
2. El código y las pruebas actuales para comportamiento implementado.
3. `package.json`, `CHANGE_CONTROL.md`, `DECISIONS.md` y `RISKS.md` para versión, decisiones y estado de entrega.
4. Los SOP y documentos de estrategia para explicación y roadmap.
5. Documentos históricos o propuestas para contexto, nunca para afirmar estado actual.

Ten especial cuidado con documentación que captura un momento anterior:

- `docs/archive/2026-09-05/PROJECT_DISCOVERY.md` describe el MVP original y conserva decisiones superadas por 0.6.0.
- `docs/WEB_ARCHITECTURE.md` nació como propuesta; parte de sus rótulos de estado quedó superada por el código W0/W1 ya construido.
- El estado de una capacidad no cambia porque aparezca en un diagrama o documento de planificación.

Si encuentras otra contradicción material, no la ocultes: aplica la fuente superior, corrige el artefacto dentro del alcance si corresponde y reporta la discrepancia.

## 3. Qué es accreatio

accreatio es un punto de lanzamiento para proyectos de software gobernados. Convierte una definición estructurada del proyecto en:

- un prompt canónico explícito;
- un plan de acciones determinista y visible antes de ejecutar;
- archivos mínimos de discovery, gobernanza y procedencia;
- y, según el host y la elección humana, una preparación segura de filesystem, Git/GitHub o un ZIP inspeccionable.

Su usuario principal es una persona técnica que quiere pasar de una idea dispersa a un inicio reproducible sin depender de memoria, copy/paste frágil ni automatización opaca.

accreatio **no es** un agente AI, no genera la aplicación final, no decide arquitectura por el usuario, no es un IDE, no es un terminal genérico y no es un “project operating system”. La generación base es local y determinista; una misma entrada produce los mismos documentos salvo metadatos temporales explícitos y el versionado necesario para evitar colisiones.

## 4. Estado real: construido, upstream, diferido y en hold

| Área                                           | Estado verificable                                                                               | Límite que no se debe cruzar                                                                                            |
| ---------------------------------------------- | ------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------- |
| Aplicación desktop Electron para Windows       | Construida; ejecuta filesystem, Git/GitHub opcional, settings, historial e IDE detrás de IPC     | Sin shell genérico, sin overwrite, sin commit ni push automático                                                        |
| Revisión futura del runtime desktop            | Fase 3 de plataforma propuesta: medir Electron frente a Tauri y, si sigue vigente, Wails          | Evaluación post-v1 solamente; no migrar hasta demostrar paridad del `Bridge`, seguridad, Windows y costo cero            |
| Cliente React compartido                       | Construido; UI bilingüe y responsive, temas claro/oscuro, preview y plan en vivo                 | El renderer no obtiene acceso a Node                                                                                    |
| Dominio, validación, templates y planificación | Construidos y probados como lógica compartida/pura                                               | No duplicar reglas por host                                                                                             |
| W1 PWA export-first                            | Código completo y verificado localmente; borrador IndexedDB, shell offline y ZIP                 | Beta Cloudflare Pages restringida por Access autorizada; release gates/evidencia pendientes; sin acceso anónimo ni dominio custom |
| Preparación Mode 1                             | Construida: UI de roles/proveedores/límites y generación de `.ai-engineering/orchestration.yaml` | accreatio no inicia ni administra la sesión AEKR                                                                        |
| AEKR                                           | Upstream independiente en otro repositorio                                                       | accreatio consume su contrato; no lo gobierna ni copia wholesale                                                        |
| Orchestration Center / P5                      | Diferido                                                                                         | No presentarlo como funcionalidad disponible                                                                            |
| Companion local W2 / P7                        | Diferido                                                                                         | No crear listener loopback ni ampliar la frontera de confianza en este incremento                                       |
| W3 SaaS / P8                                   | P8 está DONE como sketch documental; implementación W3 no autorizada                             | Sin cuentas, billing, multi-tenancy, backend de ejecución ni storage cloud                                              |
| Project Map interactivo                        | Entregado como documentación HTML/JSON autocontenida                                             | No forma parte del runtime de desktop/PWA ni debe importarse desde la aplicación                                        |

## 5. Experiencia de usuario actual

### Desktop

La navegación ofrece **Nuevo proyecto**, **Configuración**, **Historial** y **Acerca de**. El flujo principal combina un formulario a la izquierda con, a la derecha, la vista previa viva del prompt y una lista expandible de “Qué haremos”. El usuario puede trabajar en español o inglés y con tema claro u oscuro.

La persona:

1. configura ubicaciones locales y herramientas;
2. define identidad, fase, contexto, restricciones, ruta, agentes y acción;
3. adjunta fuentes permitidas cuando corresponda;
4. opcionalmente prepara Mode 1 y selecciona Git, GitHub o apertura de IDE;
5. inspecciona prompt y plan;
6. confirma una simulación o ejecución real;
7. recibe ruta, pasos completados, logs y error explícito si algo se detiene.

El historial conserva localmente hasta 50 ejecuciones. GitHub es opt-in, usa la sesión local de `gh`, crea remoto privado por defecto y nunca hace push automático.

### Web/PWA W1

El host web conserva **Nuevo proyecto** y **Acerca de**, persiste un borrador versionado en IndexedDB y exporta un ZIP. No muestra settings, historial ni selector de carpeta; no admite attachments ni tracking-only en W1 y explica esas limitaciones en vez de simular soporte. La detección de proveedores requiere desktop.

Con dry-run activo sólo informa qué ZIP produciría. Con dry-run desactivado descarga `<slug>.zip`. El service worker permite reabrir la shell offline después de la primera carga y solicita confirmación antes de aplicar una actualización. No existe hoy una URL pública autorizada.

## 6. Entradas y reglas del dominio

La entrada principal es `ProjectDefinition`:

| Campo           | Contrato                                                                         |
| --------------- | -------------------------------------------------------------------------------- |
| `name`          | Requerido, máximo 80 caracteres y debe producir un slug no vacío                 |
| `phase`         | `idea`, `discovery-active` o `discovery-complete`                                |
| `context`       | Requerido                                                                        |
| `restrictions`  | Texto opcional                                                                   |
| `route`         | `local`, `vendor` o `mixed`; queda documentada, no ejecuta una política remota   |
| `action`        | `tracking`, `repository` o `both`; W1 sólo exporta las variantes con repositorio |
| `destination`   | Requerido por el contrato actual; en web es el destino lógico `browser-download` |
| `agents`        | Entre 1 y 4 roles únicos: `generalist`, `architect`, `implementer`, `auditor`    |
| `attachments`   | Desktop: archivos opacos allowlisted; máximo 20, 20 MB cada uno y 100 MB total   |
| `initializeGit` | Sólo para una acción con repositorio                                             |
| `createRemote`  | Implica Git; usa GitHub CLI y no hace push                                       |
| `remotePrivate` | `true` por defecto                                                               |
| `openIde`       | Implica Git y un repositorio                                                     |
| `dryRun`        | Disponible siempre y activo por defecto; recomendado, no obligatorio             |
| `orchestration` | Mode 0/1, roles, tareas, proveedor y límites acotados                            |

Extensiones permitidas para sources: `.md`, `.txt`, `.pdf`, `.docx`, `.json`, `.yaml`, `.yml`, `.csv`, `.png`, `.jpg` y `.jpeg`. Se copian como bytes opacos: la aplicación no las analiza, renderiza ni ejecuta.

`Settings` aporta `baseFolder`, `toolkitPath`, `futureProjectsPath`, rama Git inicial, IDE preferido, tema, locale y confirmación. `futureProjectsPath` es obligatorio para `tracking` o `both`.

Mode 1 sólo es válido cuando sus roles coinciden exactamente con los agentes planificados, cada tarea tiene contenido y los límites permanecen dentro del contrato: sesión de 60 a 7200 segundos, 1–10 iteraciones por entidad, 1–100 invocaciones de proveedor y 1–10 fallos consecutivos.

## 7. Salidas observables

### Desktop, acción con repositorio

- `<project-root>/PROJECT_PROMPT.md`
- `<project-root>/docs/product/discovery.md`
- `<project-root>/AGENTS.md`
- `<project-root>/docs/product/sources/*` para attachments
- `<project-root>/.accreatio/project.json`
- `<project-root>/.ai-engineering/orchestration.yaml` sólo si Mode 1 está habilitado
- repositorio Git local, remoto GitHub o apertura del IDE sólo si fueron solicitados

### Desktop, tracking

- `<future_projects>/<slug>/PROJECT_STATUS.md`

La acción `both` produce las dos familias. Cada colisión usa un nombre versionado como `name (1).ext`; los originales quedan intactos.

### Web/PWA

El ZIP contiene, bajo `<slug>/`, `PROJECT_PROMPT.md`, `docs/product/discovery.md`, `AGENTS.md`, `.accreatio/project.json`, `SETUP.md` y, si aplica, `.ai-engineering/orchestration.yaml`. `SETUP.md` expresa como texto los comandos que el navegador no puede ejecutar. El navegador no ejecuta Git, GitHub ni IDE.

## 8. Pipeline obligatorio

Conserva esta separación de responsabilidades:

1. **Configuración:** cargar defaults/settings o defaults del host web.
2. **Captura:** construir una definición tipada a partir del formulario.
3. **Validación:** aplicar una sola fuente compartida de invariantes.
4. **Generación:** producir prompt, discovery, gobernanza, procedencia y Mode 1 de forma determinista.
5. **Planificación:** convertir la definición en `PlannedAction[]` antes de cualquier mutación.
6. **Revisión humana:** mostrar prompt, acciones, detalles, destino y dry-run.
7. **Confirmación:** exigir una acción explícita de la persona.
8. **Ejecución por host:** Electron usa capacidades privilegiadas acotadas; web crea un bundle local.
9. **Evidencia:** devolver pasos completados, logs, ruta/ZIP y error honesto.
10. **Persistencia local:** historial desktop o borrador web, nunca sync silencioso.

Una validación fallida detiene el pipeline. Un dry-run no escribe ni descarga. Una falla posterior reporta qué pasos sí se completaron; nunca borra trabajo válido para ocultar un resultado parcial.

## 9. Arquitectura y fronteras de confianza

| Componente               | Responsabilidad                                                                          |
| ------------------------ | ---------------------------------------------------------------------------------------- |
| `shared/domain.ts`       | Tipos, constantes, slug, validación, templates compartidos, firma y configuración Mode 1 |
| `src/core.ts`            | API de dominio del renderer, planificación de acciones y `SETUP.md`; sin Node            |
| `src/App.tsx`            | UI React web-reusable, estado del formulario, preview, confirmación y resultado          |
| `src/types.ts`           | Contratos del bridge, acciones y resultados                                              |
| `src/bridge/index.ts`    | Selecciona una vez el adaptador según el host                                            |
| `src/bridge/electron.ts` | Adaptador tipado a la API expuesta por preload                                           |
| `src/bridge/web.ts`      | Capacidades honestas de W1 y exportación ZIP; rechaza lo no soportado                    |
| `src/draftStore.ts`      | Persistencia y migración del borrador web en IndexedDB                                   |
| `src/webExport.ts`       | Manifiesto puro del bundle web, en paridad con templates desktop                         |
| `electron/preload.ts`    | Frontera IPC estrecha con `contextBridge`                                                |
| `electron/main.ts`       | Dialogs, settings, historial, filesystem, Git/GitHub, provider checks e IDE              |
| `electron/files.ts`      | Escritura/copia exclusiva y versionada contra colisiones concurrentes                    |

El renderer Electron corre con `contextIsolation`, sandbox y sin `nodeIntegration`. Ventanas, navegación y permisos se deniegan por defecto. Los procesos permitidos se invocan con ejecutable fijo y arrays de argumentos tipados, nunca interpolando texto en un shell. No añadas un runner genérico.

El Bridge actual tiene 9 métodos y no debe documentarse con el conteo histórico de 8: `chooseFolder`, `chooseAttachments`, `loadSettings`, `saveSettings`, `githubStatus`, `connectGithub`, `loadHistory`, `execute` y `checkProviders`.

## 10. Seguridad, privacidad, costo y gobernanza

Estas reglas son invariantes:

- Costo directo obligatorio: **$0** hasta que Ed lo cambie explícitamente.
- Sin dependencia AI para validar, generar documentos o planificar.
- Sin telemetría, analytics, cuentas, cloud sync ni storage de secretos.
- Sin upload silencioso de prompts, rutas, sources o credenciales.
- Sin sobrescribir archivos existentes; usar copias versionadas y creación exclusiva.
- Sin ejecutar ni analizar attachments.
- GitHub siempre opcional; credenciales bajo `gh`/sistema operativo; privado por defecto; sin push automático.
- Sin commit/push automático en proyectos generados.
- Sin publicar el toolkit privado AEKR ni asumir autoridad sobre su repositorio.
- Sin representar compilación, Electron o ejecución local como “inhackable”.
- Sin confundir “PWA construida” con “sitio público desplegado”.
- Sin implementar capacidades diferidas porque aparezcan como nodos del mapa.

## 11. Agentes y Mode 0/Mode 1

Los roles canónicos son:

- `generalist`: visión global, coordinación y handoffs.
- `architect`: límites, tradeoffs y criterios antes de implementar.
- `implementer`: cambios aprobados y pruebas proporcionales.
- `auditor`: verificación independiente, sin modificar archivos.

La topología planificada tiene de uno a cuatro roles mutuamente exclusivos. Al iniciar una sesión, compara esa topología con los agentes y herramientas realmente disponibles. Si faltan roles, avisa y pide decisión antes de reducirla. Nunca presentes una auto-revisión como auditoría independiente.

Mode 0 es el default: la persona coordina asistentes fuera de accreatio. Mode 1 sólo genera un YAML revisable para el runtime upstream de AEKR. Sólo `implementer` puede recibir escritura; `auditor` debe trabajar en contexto fresco; las transiciones de riesgo son humanas; no hay commit/push automático. En 0.6.0 accreatio **no ejecuta** ese runtime.

Para este incremento, la auditoría debe limitarse a los artefactos del Project Map y a su integración documental. No reabras una auditoría general del repositorio salvo que una evidencia indispensable revele un defecto directamente causado por este cambio.

## 12. Project Map interactivo y machine-readable — baseline entregado

El mapa meramente conceptual de Markdown ya fue reemplazado por un paquete documental de tres piezas complementarias en la raíz. Al mantenerlo o ampliarlo, conserva:

1. `PROJECT_MAP.md`: landing page breve, explicación de estados, instrucciones de uso y enlaces a los dos artefactos siguientes.
2. `project-map.json`: fuente machine-readable para agentes AI.
3. `project-map.html`: visor autocontenido para humanos.

No conviertas estos archivos en una ruta, bundle o dependencia del runtime. Deben poder revisarse, versionarse y abrirse independientemente de la aplicación.

### 12.1 Contrato mínimo del JSON

El objeto raíz contiene `nodes`, `edges` y `flows`; cada flujo contiene `steps`. Mantén ese contrato pequeño: la versión de este prompt y la versión de producto viven en documentación, no son necesarias para reconstruir las rutas.

Forma recomendada:

```json
{
  "nodes": [
    {
      "id": "react-ui",
      "label": "React renderer",
      "subtitle": "src/App.tsx",
      "description": "Formulario, preview y revisión del plan",
      "group": "renderer",
      "kind": "module",
      "status": "current",
      "paths": ["src/App.tsx"],
      "responsibilities": ["Capturar input tipado", "Mostrar resultados"],
      "position": { "x": 282, "y": 254 }
    },
    {
      "id": "shared-domain",
      "label": "Dominio compartido",
      "subtitle": "shared/domain.ts + src/core.ts",
      "description": "Validación, tipos y generación determinista",
      "group": "shared",
      "kind": "module",
      "status": "current",
      "paths": ["shared/domain.ts", "src/core.ts"],
      "responsibilities": ["Validar invariantes", "Generar contenido"],
      "position": { "x": 282, "y": 506 }
    }
  ],
  "edges": [
    {
      "id": "ui-to-domain",
      "source": "react-ui",
      "target": "shared-domain",
      "label": "valida y planifica",
      "type": "call",
      "status": "current"
    }
  ],
  "flows": [
    {
      "id": "desktop-repository",
      "label": "Crear o ampliar repositorio local",
      "description": "Del formulario a archivos versionados y Git opcional",
      "status": "current",
      "steps": [
        {
          "nodeId": "react-ui",
          "edgeId": "ui-to-domain",
          "action": "Solicitar validación y planificación."
        },
        {
          "nodeId": "shared-domain",
          "action": "Devolver el resultado determinista."
        }
      ]
    }
  ]
}
```

La forma exacta puede añadir campos útiles, pero debe respetar estas invariantes:

- IDs únicos, estables, legibles y no dependientes de posiciones visuales.
- Cada `edge.source` y `edge.target` referencia un nodo existente.
- Cada step referencia un nodo existente. Salvo el step final, `edgeId` identifica la arista saliente que conecta ese nodo con el `nodeId` del siguiente step.
- El orden del array `steps` expresa la ruta completa de origen a resultado; no es una lista decorativa de etiquetas.
- Estados explícitos `current`, `upstream`, `planned` y `hold`: `current` significa construido hoy y `planned` significa diferido/no construido. Nunca mezclar ambos.
- Paths de código relativos al repositorio; nunca rutas absolutas del equipo del autor.
- Descripciones suficientes para que otro agente razone sobre responsabilidad y frontera de confianza sin abrir el HTML.
- JSON válido, sin comentarios, HTML, funciones ni datos exclusivamente visuales.

El dataset debe cubrir, como mínimo, usuario/UI, dominio compartido, bridge, las ramas Electron y web, operaciones privilegiadas, outputs, AEKR/Mode 1 y las fronteras diferidas/hold. Incluye flujos completos y distintos para:

- dry-run desktop;
- ejecución desktop persistente, tanto para el workspace/repo como para el tracking que desemboca en la misma frontera de archivos versionados;
- herramientas locales opcionales Git/GitHub/IDE;
- exportación ZIP, autosave del borrador y arranque offline web;
- preparación y handoff Mode 1;
- companion local futuro y frontera SaaS en hold, sin fingir que son ejecuciones actuales.

### 12.2 Contrato del HTML autocontenido

`project-map.html` debe:

- abrir directamente desde `file://` y funcionar offline;
- contener todo su CSS, JavaScript, SVG/iconografía y dataset; sin CDN, fuentes remotas, fetch ni dependencias externas;
- incorporar una copia semánticamente idéntica de `project-map.json`, preferentemente en un bloque `<script type="application/json">`;
- representar nodos y aristas de arquitectura de manera interactiva, con dirección y estados legibles;
- mostrar el diagrama como superficie principal y un panel de flujos a la derecha en desktop;
- al seleccionar un flujo por mouse o teclado, resaltar **todos y sólo** sus nodos y aristas, atenuar el resto y mantener visible el nombre/estado activo;
- permitir limpiar la selección y recuperar la vista general;
- ofrecer detalle útil al seleccionar o enfocar un nodo, sin depender únicamente de hover;
- ofrecer controles comprensibles de encuadre/zoom si el diagrama los necesita;
- mantener una leyenda consistente con los estados del JSON;
- ser limpio, profesional, sobrio y compatible con tema claro/oscuro si se implementan ambos;
- responder bien en desktop, tablet y móvil: el panel derecho puede apilarse debajo, pero no debe perder ningún flujo ni causar overflow horizontal de la página;
- conservar contraste, foco visible, orden de tabulación, labels accesibles, targets cómodos y `prefers-reduced-motion`;
- crear texto con APIs seguras (`textContent` o equivalentes), no con interpolación insegura de `innerHTML`;
- degradar de forma honesta si falta una referencia: mostrar error legible en vez de resaltar una ruta falsa.

El HTML es un documento de arquitectura, no una demo artística: prioriza legibilidad de relaciones, claridad de estados y navegación rápida sobre animaciones o efectos.

### 12.3 Sincronía de artefactos

El JSON separado es el contrato para agentes; el dataset embebido hace al HTML autocontenido. Ambos deben permanecer semánticamente sincronizados. Una modificación del mapa no está completa si cambia sólo uno. `PROJECT_MAP.md` debe explicar que el visor no es runtime.

## 13. No-goals específicos del Project Map

No:

- cambiar `src/`, `electron/` o `shared/` para “integrar” el mapa;
- añadir React, Mermaid, D3, Cytoscape u otra dependencia al visor;
- requerir un servidor HTTP para abrirlo;
- crear telemetría o persistencia del comportamiento del visor;
- ejecutar comandos o cargar archivos locales desde el HTML;
- desplegar W1 o conectar Cloudflare;
- implementar P5, W2, W3 o Mode 2;
- modificar AEKR;
- convertir estados futuros en promesas de roadmap;
- hacer una auditoría general ajena al Project Map;
- sobrescribir o descartar cambios preexistentes de otra persona.

## 14. Criterios de aceptación

La entrega sólo está completa cuando:

1. `PROJECT_MAP.md`, `project-map.json` y `project-map.html` describen el mismo sistema y distinguen visualmente `current` (construido), `upstream`, `planned` (diferido) y `hold`.
2. El JSON parsea sin errores y cumple integridad referencial para nodos, aristas y steps de todos los flows.
3. Un agente puede reconstruir cada ruta usando sólo `project-map.json`.
4. El HTML abre offline como archivo local sin requests de red ni errores de consola.
5. El diagrama muestra nodos y aristas con etiquetas legibles y dirección inequívoca.
6. El panel de flujos está a la derecha en viewport desktop.
7. Seleccionar cada flujo resalta su ruta completa; cambiar de flujo elimina el highlight anterior; limpiar vuelve al estado general.
8. La misma interacción es posible con teclado y el foco siempre es visible.
9. En anchos aproximados de 1440, 1024 y 390 px no se pierde contenido crítico ni aparece overflow horizontal de la página.
10. El dataset embebido y `project-map.json` son semánticamente iguales.
11. No existen librerías, assets, fuentes o APIs remotas en el HTML.
12. Ningún texto afirma que W1 está desplegada, que P5/W2/W3 están construidos o que accreatio ejecuta agentes.
13. El cambio no introduce imports, dependencias ni rutas de producción hacia el mapa.
14. Las pruebas existentes siguen pasando. Ejecuta al menos `npm test`, `npm run typecheck`, `npm run format:check` y `npm run build`; completa también los smoke/controles visuales aplicables exigidos por `AGENTS.md`, o documenta con precisión cualquier verificación no ejecutada.
15. La revisión visual prueba flujos uno por uno y no se limita a confirmar que “se ve bien”.
16. Una auditoría independiente —si existe un agente auditor real— revisa únicamente este alcance, registra hallazgos por severidad y no modifica archivos. Si no existe independencia real, declara la revisión como auto-verificación.

## 15. Formato del reporte final

Entrega un único reporte conciso que incluya:

- resultado primero;
- archivos creados/modificados;
- decisiones de diseño y del schema que afecten a futuros editores/agentes;
- evidencia concreta de validación JSON, interacción por flujo, responsive/accessibility y suite del repositorio;
- límites o verificaciones pendientes, sin suavizarlos;
- confirmación explícita de que no se tocó runtime, no se desplegó nada y no se amplió el alcance.

No digas “completo”, “auditado” o “verificado” sin evidencia reproducible.
