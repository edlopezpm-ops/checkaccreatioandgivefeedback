# Preview writer cutover

Scope: accreatio preview, 2026-09-08. The account store is shared by historical preview deployments. Updating one branch alias alone leaves older immutable URLs capable of running obsolete account writes. Six successful previews still enabled the pre-encryption account implementation against D1 `3c42de52-6883-4f1a-b81a-3c693abab64d`; these builds cannot remain usable during the new privacy migration.

The replacement `google-oidc-preview.accreatio.pages.dev` serves compatible deployment `a2c34f21-8622-431d-b7a2-95b572fada51`. The historical alias `archive-email-auth-preview.accreatio.pages.dev` was moved to a second deployment of the same compatible source/build (`61624986-4ca8-4c64-a3b6-e88cf93fa76c`), with Google and email OTP disabled. That upload records a dirty working tree because release documentation and a test fixture were being completed; the uploaded application bundle and public assets were unchanged from the compatible commit `948aac2f53b9cc26bf6fa42a12aea7a657fff189`.

The six obsolete unaliased runtime deployments are retired after the compatible aliases are in place. Their source commits and historical documents remain in Git; the account database, records and production deployment are not deleted. This retires unsafe runtime entry points, not the project history.

| Retired deployment                     | Recorded source commit                     |
| -------------------------------------- | ------------------------------------------ |
| `f661cf71-4311-4dac-939f-527abab627c6` | `e920b052d84776db64a2861372858f10f5e7e4ed` |
| `aff9853d-4a35-4d9c-a5d6-db537decd232` | `6d6530d`                                  |
| `95a45883-726b-4ec2-b93d-a1f145f0ade4` | `b7ae71ca271d5352bde3e920cbd237fb8d728736` |
| `a6446cfd-1356-49a2-9ffd-7e4e80295e6c` | `80362c391888a1bafc18c06077c2ca1996bbeecc` |
| `a3f4f09f-f24c-4a3e-abfd-d1a3fa34ce64` | `b0bd09d13b7f7d0916b34705b8f0f7d1dc7d19a0` |
| `af1f6b16-966a-4d75-a66e-322c15e1f609` | `db5c6c8c841175d6b3db4d4236448fa542cacf54` |

The remaining older deployment `2e451918-dbdc-427a-955f-af9514c24b9f` has no account-enabled flag and its source fails closed for that service. No account writer is enabled there. The production canonical deployment remains `11235c8c-108f-46f3-8cce-fb88a144330b`, without the preview account D1 binding.

All six pinned deletions returned success after checking preview scope, the exact account database and absence of aliases. Final API pagination returned 43 previews: the only successful deployments bound to account D1 were the two compatible aliases and the one account-disabled historical deployment. Production canonical identity was read back unchanged.

Do not restore any retired plaintext-era deployment as an account-service rollback. Use the [compatible rollback](GOOGLE_OIDC_ROLLBACK.md), retaining schema 0003 and the original keys and receipts. Re-inventory all successful deployments that bind the store before any later authentication activation.
