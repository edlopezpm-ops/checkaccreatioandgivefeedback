# Blog roadmap — after the v12 frontend

**Superseded where conflicting:** the latest owner clarification permits anonymous Blog reading and reserves publishing for administrators. The explicit login, session recovery and public-route correction is documented in [PUBLIC_SIGNIN_2026-09-05.md](PUBLIC_SIGNIN_2026-09-05.md). Earlier checks below describe their historical candidate.

Date: 2026-09-04. Status: proposed next work. Reviewed after frontend implementation `7fc8b93` and deployment record `2ac2612` were committed and pushed. The protected v12 preview is ready for owner testing; this review did not activate a publisher or create an editorial post.

## Current product

The Blog already reads posts from D1 through authenticated Pages Functions. It has an English/Spanish composer, strict content validation, explicit publication confirmation, human/agent authorization and idempotent publishing. The current lifecycle is append-only.

The composer draft exists only in React memory and disappears on reload. Its review action is a generic confirmation, without a complete editorial preview. Published posts cannot be corrected or withdrawn through the current API. The listing retrieves and renders every published body, without pagination.

Evidence: [Blog UI](../src/components/BlogExperience.tsx), [API handlers](../functions/_lib/handlers.ts), [editorial storage](../functions/_lib/blog.ts), and [API tests](../tests/blogApi.test.ts). The passing frontend smoke intercepts Blog APIs; it does not establish live authenticated publishing against Access/D1.

The 2026-09-04 read-only Cloudflare metadata inspection exposes protected production publisher configuration but not its contents; preview publisher maps are not present in that response. This does not establish an effective `canPublish` result. Older records that say both maps are empty remain dated evidence, not a verified current publisher state. Check the authenticated admin-session endpoint before deciding which configuration is missing.

## Proposed sequence

| Step | Work | Completion evidence |
| --- | --- | --- |
| 1. Close private publishing acceptance | Verify owner-authenticated Blog reading and admin capability in preview; configure only the missing owner mapping if needed. Exercise one intended, reviewed post when its publication is authorized. | Owner can publish, other identities cannot; anonymous requests still redirect; one intended post persists and a retry does not duplicate it. |
| 2. Protect editorial work | Establish an encrypted backup and a restore exercise in preview. Add recoverable local composer drafts and a full rendered preview before publication. | Recovery succeeds; reload retains the draft; reviewed content matches the submitted post. |
| 3. Support corrections | Design versioned revisions and reversible withdrawal, preserving published history and attribution. Implement after recovery is proven. | Corrections retain prior revisions; withdrawn content can be restored; changes are attributable and recoverable. |
| 4. Optional AEKR publication | Reuse the existing publish endpoint with individually scoped, revocable service identities after human publishing works. Add pagination when the catalog grows. | Allowed service identity succeeds; wrong/revoked identities fail; human access and project-data isolation remain intact. |

The next bounded increment is step 1, followed by recovery and editor improvements. No new CMS or paid service is needed for the existing publishing path. Project drafts, attachments, ZIPs and integration credentials remain outside the editorial store. Desktop stays frozen.

## Reconciliation with prior planning

[Design v9 roadmap](design-v9/ROADMAP.md) remains the historical basis for R0 acceptance and R1 recovery/revisions. Its Three/Vanta optimization and desktop packaging lane do not describe the current web-only increment: the atmosphere now uses the owned GLSL renderer and desktop work is frozen. [The earlier owner checklist](HOE_R0_CHECKLIST.md) also predates night-only UI and the new external footer links; any renewed acceptance checklist should test the current behavior and distinguish deliberate external-link navigation from automatic application traffic.

This is a planning review, separate from the completed v12 parent audit and protected deployment. Authenticated publisher acceptance and later editorial implementation are not claimed here.

## 2026-09-05 owner clarification

The Blog is reserved for administrators, including reading. Ordinary project accounts have no Blog navigation or posts access. Server-side administrator authorization precedes editorial storage access. See [central sign-in and Blog correction](SIGNIN_FLOW_2026-09-05.md); the earlier roadmap remains historical planning context.
