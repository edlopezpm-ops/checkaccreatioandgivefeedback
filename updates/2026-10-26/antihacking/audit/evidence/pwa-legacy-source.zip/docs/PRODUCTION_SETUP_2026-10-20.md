# accreatio production setup — 2026-10-20

Historical cutover receipt: **the free beta became live at https://accreatio.com with a real owner Google sign-in and session persistence observed**, on source `1b5a1ffe67e5d1c898f105ae8efb4ece75c32b84`. This closes the initial domain cutover and observed owner login journey. It does not certify broad public launch, every account lifecycle journey, subscriptions or recovery.

The initial privacy release used source `aa9629b635aa54c55c2211ba846a4048beb4be61`, migration `0005`, Pages `f854ab2d-55ec-4990-87f8-7551a71f6eb1` and maintenance version `fbcce59c-3169-4ba5-9ebb-12a54ca78477`.

The current AEKR continuation/cookie release is source `1d30f4d246099cb0d802d0c5f759381a8d35f4aa`, Pages `7966e29c-2cca-49b5-95b7-d101b17fa95a`, successful at `2026-10-20T22:01:55.343538Z`. Policy versions, five account migrations, privacy keys and maintenance version are unchanged. It presents Terms/necessary-account authorization beside the deliberate sign-in action, without checkboxes, and independent optional-cookie refusal. See [current release readiness](APP_READINESS_2026-10-20.md) for 337/337 local tests, final diagnostic package, 21 current hosted checks, protected custody and the separate human acceptance scope. The rows below retain their historical source and observation scope.

## Domain and hosting

| Item                  | Confirmed state                                                                            |
| --------------------- | ------------------------------------------------------------------------------------------ |
| Registrar             | Spaceship; owner-provided `accreatio.com`                                                  |
| Delegated nameservers | `derek.ns.cloudflare.com`, `raegan.ns.cloudflare.com`                                      |
| Cloudflare zone       | `d32abf38b7ff99ec84db8d2bf0874049`, active, Free plan, $0                                  |
| Pages project         | Existing `accreatio` project retained                                                      |
| Custom domains        | Apex and www, both active with active verification/validation                              |
| DNS                   | Apex and www proxied CNAMEs to `accreatio.pages.dev`; delegation checked through `1.1.1.1` |
| Canonical redirect    | `https://www.accreatio.com/*` → `https://accreatio.com/${1}`, HTTP 301, query preserved    |
| Transport             | Always Use HTTPS on; Universal SSL active; minimum TLS 1.2, TLS 1.3 enabled                |
| HTTP observation      | Apex, legal routes and Blog API 200; HTTP upgrades and www redirect 301                    |

The registrar initially had no custom DNS records or connected services. The Cloudflare scan imported two parking A records, replaced by the Pages CNAMEs. No existing mail/MX dependency was found. Domain privacy and renewal settings were preserved. No paid hosting, email transport or plan upgrade was enabled.

The existing production Blog database was retained. Preview accounts and keys were not copied into production. Browser drafts are origin-local; changing the hostname does not move drafts from another origin or synchronize project content. The older protected Pages/preview URLs remain available. Git production autodeployment remains disabled; this release was deployed explicitly.

## Production account service and Google

- New, isolated D1 `accreatio-accounts`: `84e68cab-6bbd-4a4b-a8fc-3d4eda2765d3`; all four migrations applied.
- Existing production `BLOG_DB`: `0fb6bf15-a2d1-4105-a3a4-7629eb8cc5cd`, retained separately.
- Five distinct new production account keys installed as protected runtime configuration. Account/OIDC enabled, own email OTP off. Admission remains capped at 1,000 accounts independently of provider capacity.
- Google project `accreatio-production`, under `aekr.io`, and Web client `accreatio-production-web` created after the owner's explicit policy and credential confirmations. No new billing account enabled.
- Exact single callback: `https://accreatio.com/api/auth/v1/oidc/google/callback`; scopes `openid email profile`. Home, privacy, terms and authorized domain configured.
- Google Audience read back as **External / Testing**. Production publication and brand verification are not completed or claimed.
- The owner personally completed a real Google exchange on the final hostname and confirmed completion. The app displayed the profile; reload retained the signed-in state. The account menu showed zero exports used and **5/5 remaining**. No project export or account deletion was performed on that account.
- Sanitized D1 aggregates at `2026-10-20T20:38:54Z`: one live account, one Google identity and one live session with hashed token. Email/display name were encrypted, with no plaintext account email. No personal account payload, provider token or cookie was retrieved for this receipt.

The owner login above is observed hosted evidence. Cancellation, logout, account data download/deletion, multitab, quota and revocation are covered by local integration/UI tests; a new production-domain disposable-account journey for all of them has not been performed. It must not be described as completed human UAT.

## Scheduled maintenance

| Item                     | Confirmed state                                                                                                |
| ------------------------ | -------------------------------------------------------------------------------------------------------------- |
| Worker                   | `accreatio-account-maintenance`                                                                                |
| Deployed version         | `19d1833c-cac5-47a4-afb7-f29835705fe5`                                                                         |
| Store and keys           | Production account D1 and the same three production privacy keys                                               |
| Schedule                 | `17 * * * *`, enabled                                                                                          |
| Public exposure          | `workers_dev=false`, preview URLs off, `routes=[]`                                                             |
| Last cleanup observation | Synthetic expired probe count fell from `1` at `2026-10-20T21:14:33.795Z` to `0` at `2026-10-20T21:17:24.722Z` |

The probe was inserted just after the 20:17 UTC tick and disappeared after the scheduled 21:17 UTC tick. This is the **first observed successful scheduled production cleanup**. No manual cleanup or application-request cleanup was invoked; `maintainAccounts` runs only in the maintenance Worker. The readback is `.local/logs/revival-20261020/cleanup-after.json`.

This observation belongs to deployed Worker version `19d1833c-cac5-47a4-afb7-f29835705fe5` and the existing `1b5a1ffe67e5d1c898f105ae8efb4ece75c32b84` production release. Migration `0005` and the new privacy/maintenance source were not deployed at this observation. One synthetic expired probe establishes that bounded pass; it does not establish ongoing monitoring, every retention category, backlog clearance or provider-copy deletion.

## Credential custody

All seven newly configured production values (five account keys, Google client ID and secret) are saved in `.local/private/production-20261020/accreatio-production.config.json`. The directory is Git-ignored and its Windows ACL is restricted to the current owner. It includes the authorized Google client JSON, deployment/source metadata, matching source ZIP and backup instructions. Back up the directory through an owner-controlled secure backup process; no external backup was sent. This config is not a D1 data backup.

Four original Blog values are non-exportable through the available Cloudflare interface: `BLOG_ACCESS_AUDIENCES`, `BLOG_ACCESS_ISSUER`, `BLOG_AGENT_ADMINS`, `BLOG_HUMAN_ADMINS`. They remain installed and were preserved without rotation. The config records that their original clear values are absent; an original owner-held copy is still required for recovery into a new project. Personal GitHub, Cloudflare and Spaceship login credentials do not belong in this application backup.

## Exact deployment and verification receipt

| Item                          | Result                                                                                                                                                       |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Initial local/remote baseline | `9899571c230faf84cd42a9b5fd40afc09a52a00c`                                                                                                                   |
| Main revival source           | `fe7413a4aa505ec38bdfae8f1cd105890f0a9f68`                                                                                                                   |
| Final application source      | `1b5a1ffe67e5d1c898f105ae8efb4ece75c32b84`                                                                                                                   |
| Production Pages deployment   | `230955a4-d3df-48fa-8ef8-7bae3ddc3463`, success at `2026-10-20T20:32:12Z`                                                                                    |
| Provider readback             | Branch `main`, commit `1b5a1ff…`, ad-hoc deployment, checked at `20:38:54Z`                                                                                  |
| Full local verification       | `npm.cmd run log -- verify`: PASS on `fe7413a`, 307/307 tests; typecheck, formatting, branding, Functions, builds and functional web/Electron/account checks |
| Final header change           | `build:web` and `test:surface`: PASS on `1b5a1ff`; legal HTML matches local build byte-for-byte with `no-transform`                                          |
| Dependency audit              | 0 high/critical; 8 moderate in inherited packaging dependencies without a compatible published fix                                                           |
| Diagnostic Windows package    | Built/retained locally; packaged host smoke PASS, 19 ASAR assets match build; no desktop publication                                                         |
| GitHub CI                     | **BLOCKED by account billing before any steps**, not a passing remote verification                                                                           |
| Hosted readback               | Root/legal bytes match build; Google on, OTP off; anonymous account/admin endpoints 401 with `no-store`; Blog reads 200                                      |
| Independent review            | Separate agents reviewed archive/source, OAuth reference and final configuration/dependency changes                                                          |

The deploy records `commit_dirty=true` because pre-existing untracked `PRIVACY.md` was preserved. Tracked application source was clean; that file was not modified, committed or included in the build. Later receipt-only commits do not change the deployed application source above.

GitHub run [39492761338](https://github.com/edlopezpm-ops/accreatio/actions/runs/39492761338) has an empty steps list. Its annotation states that recent account payments failed or the spending limit must be increased. No payment, spending increase, visibility change or futile rerun was performed. Local verification and provider deployment are recorded separately from this remote CI limitation.

Full verification included Lighthouse 97 performance / 100 accessibility / 100 best practices; SEO 66 reflects the intentional private-beta `noindex`. AEKR pinned assets passed (4/4); comparison against the old vendor folder name was skipped. The diagnostic package is unsigned; its portable wrapper was not executed. The actual packaged host smoke used an isolated profile and test-only `--no-sandbox` workaround, without changing product security settings.

Sanitized local evidence (ignored; retain separately when needed):

- `.local/logs/revival-20261020/cloudflare-readback.json`
- `.local/logs/revival-20261020/http-readback.json`
- `.local/logs/revival-20261020/account-aggregate-readback.json`
- `.local/logs/revival-20261020/cleanup-after.json`
- `.local/logs/revival-20261020/accreatio-production-live.jpg`
- `.local/logs/2026-10-20T20-23-27-913Z-verify-26f509c0-abcb-4a26-ba67-eafdec7a1c1f.log`
- `.local/logs/2026-10-20T20-14-23-479Z-npm-audit-final.json`
- `.local/logs/packaged-revival-1792528093925/package-custody.json`

## Remaining launch and recovery work

Google brand/publication status, broader external-account lifecycle acceptance, cleanup backlog/failure handling, measured capacity, protected data backup/recovery rehearsal and accurate commercial/legal operating facts remain separate launch work. New-domain administrator publishing was not exercised: anonymous access fails closed, and retained Access-protected administration remains separate from product sign-in. GitHub/other adapters, linking and all subscription/checkout/entitlement behavior remain unimplemented; the micro SaaS document records the backlog and owner decisions.

On failure, preserve production D1 and every key needed to read encrypted records, identify accounts and retain quota continuity. Disable the affected sign-in capability first and deploy a reviewed compatible recovery release. Do not restore the old account-unaware application over live account activity, replace production with a preview snapshot, casually rotate keys or overwrite later deletions, revocations and receipts. Keep Blog and preview resources separate.

References: [revival baseline](REVIVAL_BASELINE_2026-10-20.md), [account contracts](AUTH_ROADMAP.md), [privacy operations](ACCOUNT_PRIVACY_OPERATIONS.md), [compatible rollback](GOOGLE_OIDC_ROLLBACK.md), [micro SaaS work](MICRO_SAAS_LAUNCH_2026-10-20.md).
