# Web Strategy

> **CURRENT: FREE WEB BETA ON `accreatio.com`.** The custom domain, separate production account store and real owner Google login are recorded in the [October 20 production receipt](PRODUCTION_SETUP_2026-10-20.md). The [current readiness assessment](APP_READINESS_2026-10-20.md) owns outstanding launch work. The phase receipts below retain their original observation dates.

> **Historical August 6 state:** `0.8.0` at `accreatio.pages.dev` behind Cloudflare Access, with Blog/Pages Functions/D1 and authenticated publishing acceptance pending. Its old restriction on custom-domain setup was superseded by the owner's October revival request. Administrator publishing, paid capability and broad promotion retain their own acceptance requirements.

## Decision

Do not port the current executor directly into a hosted backend. A browser cannot safely browse arbitrary desktop paths or run local Git/IDE commands, and a hosted command runner would turn local trust into remote code-execution risk.

The accepted product definition is: **accreatio is an authenticated, local-first, ephemeral-session web application for creating and exporting projects.** Its persistent editorial channel does not change the project-data boundary.

## Recommended architecture

1. Reuse the pure domain model, validation, prompt generator, action planner, design system, and i18n bundle in a progressive web app.
2. Offer browser-only export first: download a signed project bundle/ZIP and copyable command manifest without requiring GitHub, an IDE, or an AI provider.
3. For full local execution, pair the web UI with an optional open-source local companion using a loopback API, short-lived consent tokens, origin allowlist, explicit per-run approval, and zero inbound network exposure.
4. Keep GitHub optional via OAuth device flow or GitHub App with least-privilege, short-lived tokens. Never proxy or persist personal tokens in a generic backend.
5. Make toolkit profiles portable, signed, versioned bundles. Ship a sanitized public default; allow users to import another compatible toolkit locally.
6. Keep Blog editorial data in one web-only D1 source behind independently verified Cloudflare Access JWTs. Permit append-only publishing by the verified owner and separately allowlisted, revocable AEKR service identities; never mix this channel with project data or the Electron build.

## Public toolkit split

The private AI Engineering Knowledge Repo must not be embedded or published wholesale. Build a separate reviewed distribution containing only templates required at runtime, license-compatible content, no PII/client details, no internal paths, and a machine-readable manifest. Treat it as a release artifact generated from an explicit allowlist, not a clone filtered by blocklist.

## Deferred gates

Broad promotion requires threat modeling, trademark review, dependency/SBOM automation, accessibility review, accurate reviewed privacy terms, abuse controls for hosted features, a public-use license decision and an independent security assessment. The current readiness record distinguishes completed engineering checks from remaining provider, operator and human acceptance. Signed desktop updates remain a requirement for a future desktop release; desktop publication is frozen and is outside the current web release. DEC-009's historical owner-only beta does not itself close these launch requirements.

## Delivery phases and current status

### Phase W0 — Web-ready shared client (complete, 2026-08-03)

- Keep validation, prompt generation, action planning, localization, and the design system free of Electron dependencies.
- Ship brand icons and an installable web-app manifest from the shared renderer build.
- Preserve zero-cost project operation with no hosted project database, analytics, storage, or paid API. The later editorial channel is a separate, bounded free-tier data class.
- Delivered as accreatio's first AEKR Mode 1 pilot: `Bridge` interface with `electronBridge`/`webBridge`, zero remaining `window.accreatio` branches in `App.tsx`. See `docs/PHASE_P1_PILOT_EVIDENCE.md`.

### Phase W1 — Export-first PWA (code-complete 2026-08-03; **protected beta deployed 2026-08-06, authenticated acceptance pending**, see DEC-009)

- ~~Store drafts locally in IndexedDB~~ — done: `src/draftStore.ts`, web-only, verified in a real browser (reload restores the draft).
- ~~Export a deterministic ZIP/manifest that the user can inspect and execute locally~~ — done: `src/webExport.ts` + `client-zip`, producing `PROJECT_PROMPT.md`/`docs/product/discovery.md`/`AGENTS.md`/`.accreatio/project.json`/`SETUP.md` under the project slug, verified end-to-end in a real browser (real ZIP download, unzipped and inspected). Known gap: attachment upload (`chooseAttachments`) and tracking-only exports remain unsupported in this phase — the browser reports both explicitly rather than silently doing nothing.
- ~~Support offline use through a versioned service worker~~ — done: `vite-plugin-pwa` (`generateSW`, reusing the existing hand-authored manifest), registered manually in `src/main.tsx` so an available update prompts before reloading rather than silently swapping code under an open tab. Verified in a real browser: after first load, going offline and reloading still renders the full app shell.
- ~~Accessibility hygiene~~ — done: icon-only buttons labeled, mobile viewport confirmed zero horizontal overflow, a real missing-keyboard-focus-ring bug found and fixed.
- ~~Deploy the renderer to a protected HTTPS beta~~ — done for exact commit `39ea088175e69430fa9f2539681ea978b264675d` by Direct Upload to `https://accreatio.pages.dev`. Exact-production and wildcard-preview Access applications each allow only the owner-approved identity, and anonymous production/preview probes return `302`. Owner-authenticated hosted UX/header/offline/network/Lighthouse acceptance remains pending. See **DEC-009** and `docs/W1_RELEASE_READINESS.md`.
- Keep internal accreatio password accounts and project uploads out of scope. Cloudflare Access protects the portal externally.

### Phase W1.1 — Protected editorial channel (`0.8.0` deployed; authenticated acceptance pending)

- Add three founding Blog posts in D1 and read them through an authenticated same-origin Function.
- Production and preview D1 contain the reviewed migration and exactly those three rows. Candidate `ad90fee` passed the fresh Claude AEKR audit; documentation-equivalent commit `8735952` passed full Windows CI and was deployed successfully. Anonymous Access denial passed; authenticated hosted acceptance remains open.
- Let Ed Lopez publish through the web composer and separately allowlisted AEKR service identities publish through the same append-only endpoint. Every route validates the Access JWT signature, issuer, audience, lifetime, and strict actor shape; sensitive identifiers become safe labels and are not stored or intentionally logged.
- Keep project drafts/attachments/ZIPs and GitHub/IDE/AI credentials outside D1 and every Blog request. “Ephemeral-session” describes server-side project/integration state, not IndexedDB drafts or persistent posts.
- Build `dist/` and `dist-desktop/` from separate entry graphs. Blog, administration, PWA, Functions, migrations, and fixtures are absent from Electron.
- Keep production and preview D1 separate and stop before any paid requirement. Hosted agent publishing remains pending until a narrow Service Auth policy and a real allowlisted token are exercised.

### Phase W2 — Optional local companion

- Add local execution only through a separately installed, signed companion.
- Bind to loopback only; use an origin allowlist, one-time pairing, short-lived capability tokens, explicit confirmation per mutation, and a visible audit log.
- The hosted page must never receive arbitrary shell access or reusable local credentials.

### Phase W3 — SaaS collaboration (not yet authorized for implementation)

- Add accounts, organizations, shared templates/history, and billing only after product demand is demonstrated.
- Derive tenant identity from the authenticated session and enforce tenant isolation in database rows, object storage, caches, queues, logs, and rate limits.
- Treat uploads as hostile: signature/MIME validation, application-generated names, non-public object storage, malware scanning/CDR where applicable, retention/deletion controls, and quotas.
- Complete legal review, data-processing inventory, incident response, backup/restore testing, accessibility, observability, support policy, and cost guardrails before launch.

## Explicit non-goals

- No multi-tenant remote command runner.
- No dependency on AI for project generation.
- No silent upload of prompts, paths, discovery sources, credentials, or telemetry.
- No Blog/editorial code, content, or Cloudflare runtime in the Electron package.
- No publication of the private AI Engineering Knowledge Repo.
