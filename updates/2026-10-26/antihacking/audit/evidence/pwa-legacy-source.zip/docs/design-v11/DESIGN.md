# Design v11 — Guided project creation and touchable nebula

Date: 2026-09-04. Owner: Ed Lopez. Status: implementation authorized; user acceptance pending.

## Authority and recovered baseline

The owner requested recovery of the unfinished frontend, faster autonomous nebula motion without hover interaction, a left-click smoke burst, and a simple sequential project questionnaire designed with a UX/UI specialist. The owner authorized implementation and preparation for testing with minimal human interruption. This replaces the old wait for owner drawings in `docs/archive/2026-09-05/SESSION_HANDOFF_2026-08-13.md`; it does not accept the replacement before testing.

Git recovery found Claude's `e4eb570` intact, merged into `origin/main` at `de35588` with an identical tree. Cloudflare lists the successful v10 preview `e0a5bdf7-db12-4e67-a8f7-3b4ab7015c8e` (source `e4eb570`) and an idle production build `074cd189-60e3-40a3-bbb8-d65fbd2e9970` (source `de35588`). An idle build is not evidence of deployment. The existing successful production record is `11235c8c-108f-46f3-8cce-fb88a144330b`; retain these predecessor IDs and URLs for recovery.

## AEKR execution scope

Full governance is selected by the owner's explicit request. Reference: the current sibling AEKR `MASTER_SWITCH.md`, `toolkit/MASTER_SOP.md`, lifecycle SOP, Constitution sections 4–5, and audit checklist. This is a Mode 0 workflow conducted through the available Codex agents, not a claim that the experimental AEKR provider runner executed. The four available slots cover orchestration/integration, UX implementation, atmosphere implementation, and functional verification; a fresh-context auditor replaces a finished implementer for the single final parent audit. Self-checks are Verification, not independent Audit. AEKR is read-only reference material; no switch, P04, runtime, or export-payload migration belongs to this change.

Leaves: guided flow, atmosphere, integration/release preparation. Each receives checks appropriate to its behavior. One parent Audit follows their verification. The owner retains final UX acceptance. A protected Cloudflare preview is the testing target; production promotion is separate from this test handoff.

Scope update from the owner during implementation: accreatio is now web-first and desktop development is frozen. Adopt the supplied orbital branding as a surgical web asset change. Preserve the existing desktop assets and installer configuration; do not prepare or publish a desktop release. Earlier desktop checks are historical regression evidence only. Final gates target the web candidate, and shared source changes do not imply desktop acceptance.

## Design and Minimum Sufficient Change

Root causes: stages group unrelated decisions and require users to interpret technical navigation; the atmosphere couples pointer position to both geometry and shader light, and its autonomous time progression is too subtle.

Repository search identified reusable `ProjectDefinition`, validation/prompt/plan/export functions, creation stage controls, native dialogs, draft storage, shared theme tokens, the existing owned GLSL renderer, and its lifecycle gates. Ordered simplification ladder: (1) exclude new accounts, providers, services, dependencies, backend work and export format changes; (2) extend the existing form state and renderer; (3–5) use browser events, native controls, CSS transitions and the already-installed React/Playwright stack; (6) change presentation orchestration at the two existing UI boundaries. No general form engine, animation framework, new IPC, or server endpoint is justified.

The guided form presents one main question at a time: name, starting point, optional source files, purpose, limits, work route, team, delivery and review. Text uses an explicit Continue action. Discrete choices advance directly with a short entry transition; Back always preserves answers and never validates the screen being left. Review supports editing and return. Existing advanced team and delivery controls remain available through disclosure. Keyboard focus, error association, ES/EN copy, narrow screens and reduced motion are required. Domain validation and the final explicit dry-run/export confirmation remain authoritative.

The nebula moves autonomously faster and over a wider visible range. Pointer movement has no visual effect. A primary left click on exposed, visibly moving gas generates a short expanding smoke cavity/ripple. Clicks on UI, empty sky, right clicks, hidden tabs, paused/reduced-motion and fallback scenes do not trigger it. The shader itself supplies density picking, with the same time/coordinates and presentation mask, to avoid a rectangular fake hit area. Bursts are capped and expire. There is no network or product-state coupling.

The legacy creation implementation remains buildable until hosted acceptance under `CHANGE_CONTROL.md`'s archive policy. Historical decisions/audits remain dated evidence. Active SOP, map and README descriptions will follow the replacement. A build-time legacy selector may supply the required rollback toggle without adding a confusing product setting.

## Verification and risks

Baseline: 215/215 tests passed locally before implementation. Final candidate gates after the owner's desktop freeze: unit/contract tests, typechecks, formatting, generated artifact parity, web/Functions builds, Project Map smoke, complete web ZIP/draft/attachment/Blog regression flow, mobile/keyboard/reduced-motion and branding inspection, and Lighthouse. The previous full verification also exercised desktop builds and privileged execution; no refreshed desktop package is required or claimed for this web handoff. Functional tests must follow real controls and verify outputs, not replace them with preset project state.

Primary risks are form-state loss on navigation, incorrect conditional validation, focus disappearing during animation, click interception, picking invisible gas, excessive GPU work, and divergent web/desktop behavior. Mitigations are explicit transitions and state reuse, actual rendered functional checks, picking only on click, bounded bursts and the retained renderer limits. No paid feature, Access weakening, publisher activation, database change, or project data upload is authorized by this frontend work. Hosted owner-authenticated acceptance is distinct from local verification and deployment metadata.

Results, exact artifact inventory, audit verdict and deployment identity belong in `RESULT.md` when established; this design does not predeclare a pass.
