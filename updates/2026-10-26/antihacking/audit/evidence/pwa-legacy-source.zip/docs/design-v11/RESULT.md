# Design v11 — Verification and test handoff

Date: 2026-09-04. Status: ready for protected web testing; web verification and independent audit PASS. Owner acceptance remains pending.

## Delivered behavior

Recovered Claude's successful v10 preview source `e4eb570`, already merged at tree-equivalent `de35588`. The new web flow presents eight questions including Review, or nine when discovery files apply. Back preserves answers; required-field errors clear after correction; Review permits direct editing and return. Full manifest, deterministic plan and prompt remain available in closed disclosures. Dry-run defaults on, and a separate confirmation controls ZIP creation.

The nebula moves faster independently of the mouse. A primary left click on exposed visible gas creates a short smoke bubble. UI and empty-sky clicks do not trigger it. Shader density and presentation masks control picking; four bursts expire after 1.6 seconds. Reduced motion, save-data, visibility and renderer fallback behavior remain effective.

The owner's supplied orbital identity is adapted into local dark/light SVG marks and a geometric lowercase wordmark with the exact tagline `FROM IDEA TO STRUCTURE`. Header, welcome, About and confirmation branding, favicon, PWA icons and social preview use the new web assets. The previous desktop assets and installer settings remain intact. Desktop development and release work are frozen by the owner's subsequent instruction; this is a web handoff.

## Minimum sufficient change and recovery

- Reuse existing project definitions, validation, draft storage, prompts, plans, ZIP generation, team/delivery controls, host bridge and confirmation guards. No schema, backend or privileged execution change.
- Add a finite question-order module, guided presentation components and scoped CSS. No form framework or runtime dependency.
- Retain the previous form and Review components under `src/legacy/` until hosted acceptance, as required by Change Control. `VITE_CREATION_FLOW=legacy` selects the prior workflow at build time. These temporary copies are recovery capacity, with disposal requiring a separately recorded owner decision.
- Remove hover state/listeners. Add one passive click observer, a one-pixel picking framebuffer and a bounded burst pool. Cache twelve small star sprites locally.
- An isolated trace identified GPU waits during compositor Commit. Reducing the nebula drawing buffer on widths at most 600 pixels from scale 0.6 to 0.4 reduced Commit p95 from 22.76 to 12.35 ms in the diagnostic comparison. Larger screens retain 0.6; speed, frame cap and shader behavior stay the same. Removing filters/backdrops or adding a promoted layer did not help and was not adopted.
- Web branding has a separate local generator and stylesheet. Including SVG in the web precache preserves offline theme changes. Existing desktop source entry, original assets, icon generator and installer configuration have no diff.
- Compatible transitive patches address inherited dependency audit findings: `fast-uri` 3.1.5 → 3.1.7 and `@xmldom/xmldom` 0.8.13 → 0.8.15. No direct dependency was added.

The closed changed-source inventory, byte sizes, SHA-256 values and evidence hashes are in `VERIFICATION.json`. Its scope excludes mutable governance/deployment reports; the parent audit separately reviews the entire Git change from `de35588`.

## Final verification

The web sequence exited 0 after the desktop freeze. All twelve sequence commands exited 0; the following dependency audit also found zero vulnerabilities. The independent audit then found F-01: focused headings could overlap the sticky header at 390x600. A four-file correction measures the real header, removes the fixed scroll margin, and adds actual heading-placement assertions at that viewport. The corrected candidate again passed all 222 tests, formatting, the web build, full web functional sequence and Lighthouse (96/100/100/66). Unchanged parity, Functions, offline-branding and legacy evidence remains applicable.

| Check | Result |
| --- | --- |
| `npm test` | 222 passed; 0 failed |
| Blog seed, vendored AEKR, Project Map and generated Cloudflare types | All parity checks passed |
| `npm run typecheck` | App, retained Electron types and Functions passed |
| `npm run format:check` | Passed |
| `npm run cloudflare:functions:build` | Passed |
| `npm run build:web` | Passed; PWA precache includes new SVG/PNG assets |
| `npm run test:project-map` | 12 flows, 4 viewports, zero external requests |
| `npm run test:web` | Complete functional sequence passed |
| `npm run lighthouse` | Performance 96, accessibility 100, best practices 100; SEO 66 accepted only under the existing private-beta noindex exemption |
| `npm audit --audit-level=high` | Zero vulnerabilities |
| Legacy web build | Passed with `VITE_CREATION_FLOW=legacy`; prior five-stage runtime was also checked |
| Offline branding | All 7 new assets served through the controlling service worker while offline; response SHA-256 matched source bytes |

The functional sequence covers ES/EN, widths 320/390/760, reduced motion at 1280, both themes, required-field feedback, focus/keyboard, Back, Review editing, collapsed/open technical output, CTA contrast in rest and hover, dry-run without a download, ZIP contents including actual attachment bytes, draft restoration, Blog regression behavior and atmosphere interaction exclusions. Separate branding inspection covered welcome and About at 320/1280, both themes, no overflow, no page errors and no missing assets. Production visual inspection retained the gas appearance after compact-screen resolution adjustment.

Evidence in the local workspace:

- `.local/logs/legacy-20260905/.accreatio-web-final.log`: original mixed PowerShell encoding receipt; `.local/logs/legacy-20260905/.accreatio-web-final-readable.log`: encoding-normalized copy, with the original preserved.
- `lighthouse-report/lhr.json`: corrected-candidate measurement at 2026-09-04T21:48:59.076Z.
- `.local/logs/legacy-20260905/.accreatio-web-offline.log`, `.local/logs/legacy-20260905/.accreatio-legacy-build.log`, `.local/logs/legacy-20260905/.accreatio-capture-focus.log`.
- `output/playwright/guided-*.png`, `nebula-visible-click.png`, `web-branding-*.png`, `perf-ablation.json` and `perf-trace*.json`. The separate `guided-es-760-review-clean.png` is an earlier focus diagnostic, not final branding evidence.
- `.accreatio-focus-{build,web,tests,lighthouse}.log`: successful verification of the F-01 correction.

Earlier full candidate runs failed Lighthouse at 67/71; those failures are superseded by the corrected final web run, not credited as passes. Desktop builds and privileged smoke passed before the owner's freeze, and an earlier candidate received a packaged UI check. No final desktop package, desktop release or Windows CI run is claimed for this web handoff. The final gate scope follows the owner's later instruction.

## Independent audit and deployment

The fresh parent audit of `9d8c556` identified one MINOR finding, F-01, and correctly held that candidate. The same auditor independently verified the correction on `95c8ea1181f4b36c6d77b0c0747aebc4c02be07d` and appended a PASS delta to `AUDIT.md`, preserving the original finding. Fourteen heading/focus checks passed at 390x600 normal motion and 1280x800 reduced motion, with Back, Review editing and attachment/answer preservation intact. All 78 source/build/evidence hashes matched. No second audit layer was added. The exact audited source is now deployed for protected testing.

Production promotion, publisher activation, Access changes, database migration, new accounts and paid capabilities are outside this test handoff. User-authenticated hosted UX acceptance belongs to Ed; local verification and a successful upload do not claim it. Predecessor immutable deployment IDs remain recorded in `DESIGN.md` and Change Control.

## Protected testing deployment

- Test URL: [design-v11-preview.accreatio.pages.dev](https://design-v11-preview.accreatio.pages.dev).
- Immutable URL: [1afd10fa.accreatio.pages.dev](https://1afd10fa.accreatio.pages.dev).
- Deployment ID: `1afd10fa-f010-41d8-a658-3a5aa5224593`; environment `Preview`; branch `design-v11-preview`.
- Audited, verified and deployed implementation source: `95c8ea1181f4b36c6d77b0c0747aebc4c02be07d`. Later Git commits record audit/deployment documentation only; implementation and built-web hashes still match the verified manifest.
- Wrangler upload exited 0 and deployment readback identifies source `95c8ea1` as the successful preview. The Git integration also recorded an idle feature-branch build; that idle record is not the testing deployment.
- Anonymous Access check at `2026-09-04T21:55:31.916Z`: all six checks returned HTTP 302 to the existing Access login, covering the preview alias, immutable URL, Blog API, a new brand asset and production. No Access policy, D1 binding or publisher allowlist was changed.
- Production was not promoted. Previous immutable deployments remain archived. Owner-authenticated UX testing is the next acceptance step; desktop remains frozen.

Deployment and Access receipts are linked by byte hashes in the manifest deployment section. Source and documentation are pushed on `feat/guided-creation-nebula`.
