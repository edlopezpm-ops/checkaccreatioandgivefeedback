# Central sign-in and administrator-only Blog

**Superseded where conflicting:** the latest owner clarification permits anonymous Blog reading and reserves publishing for administrators. The explicit login, session recovery and public-route correction is documented in [PUBLIC_SIGNIN_2026-09-05.md](PUBLIC_SIGNIN_2026-09-05.md). Earlier checks below describe their historical candidate.

Owner correction, 2026-09-05: place sign-in after **What stays local** and before **What is your project called?**. The creator must require sign-in. Remove the upper sign-in/retry control and ordinary-user Blog access or unavailability messages.

## Design decision and independent review

A separately tasked designer-auditor compared a third welcome screen, an expanded access card inside privacy, and a modal. The third screen was selected for a clear sequence, native navigation and mobile focus handling:

`What you will make -> What stays local -> Sign in to start your project -> What is your project called?`

The central screen reuses the welcome card, Back, a single primary action, existing night theme and approved footer. It shows a verified email when available. A valid existing application session can resume directly. Session creation requires an explicit central action; the introductory screens do not silently create accounts.

The designer-auditor then inspected the implementation, API authorization and the 320/390/1280 screenshots. Verdict: **PASS**, no necessary corrections within the bounded review. This was an independent code/visual review; the auditor inspected the functional receipt without independently rerunning it. No hosted OTP acceptance is implied.

## Behavior and boundaries

- No creator subtree mounts without a verified application session. Initial loading, failed verification, offline transition, expiry and detected revocation return to the central gate. Draft state is preserved. Navigation, reload and stored onboarding completion grant no account authority.
- The signed identity endpoint only returns the verified email; it never creates an account. The central button creates the revocable application session. The server supplies its expiration time. Polling and visibility checks detect revocation; export APIs still independently enforce current authorization.
- Account errors are mapped to localized sign-in recovery, so the shared verifier's editorial wording cannot appear in the project flow. Account status is shown only inside the authenticated creator.
- Ordinary users have no Blog destination and do not request posts. The Blog list API requires the existing administrator allowlist before touching D1. Administrative capability is independent of D1 availability; verified admins receive an actionable read error inside their own area.
- Cloudflare Access still protects the entire restricted beta. Its email-code screen can appear **before the site loads**; the central card explicitly starts the project's application session using that verified identity. No embedded OTP form, new email sender, public access policy or production change is introduced. This is not a claim that provider OTP was moved inside the web card.

## Verification

`npm.cmd run log -- verify`: **PASS**. 239 tests, typechecks, formatting, branding, Blog seed, project map, generated Cloudflare types, Functions compilation, both builds, desktop boundary/Electron smoke, project-map browser smoke, full web smoke, account UI with real SQLite, Lighthouse. The existing vendor-check default path skips; pinned governance payload is unchanged from the preceding delivery.

Log: `.local/logs/2026-09-05T18-42-27-595Z-verify-603a3afa-00ac-45a3-a5bc-e592a36ebe3f.log`.

Functional evidence: `.local/logs/account-ui-1788633830726/receipt.json`; reviewed captures: `.local/logs/account-ui-1788633714981/signin-{320,390,1280}.png`. Tests cover no automatic session POST, correct screen order, keyboard focus, Back, database failure, no ordinary-user Blog reads/navigation, explicit sign-in, five exports/retry, revocation and locked reload. API tests additionally check identity disclosure without storage, authoritative expiry and administrative denial before database access.

Lighthouse: performance **96**, accessibility **100**, best practices **100**. SEO retains the intentional private-beta noindex exception. Desktop packaging remains frozen; no executable is released.

## Deployment lineage

The outgoing account preview is `af1f6b16-966a-4d75-a66e-322c15e1f609`, immutable URL `https://af1f6b16.accreatio.pages.dev`, source `db5c6c8c841175d6b3db4d4236448fa542cacf54`. Retain it as historical evidence; its permissive creator boundary is superseded by this correction. The stable review alias remains `https://archive-email-auth-preview.accreatio.pages.dev`. Production remains separately controlled.

## Authentication runtime correction

A bounded diagnostic reproduced the actual `access_keys_unavailable` failure in workerd at the project compatibility date. The shared Access verifier used `fetch(..., { redirect: "error" })`, which Workers rejects before making the JWKS request. Node-based identity fixtures had not exposed this incompatibility. The verifier now uses `redirect: "manual"`; its existing response-status check rejects redirects without following them. This fixes the failure rather than merely hiding its editorial wording.

Against both current public Access signing keys, the corrected source in workerd fetched JWKS with status 200 and rejected a deliberately invalid signature with 401. No real token, account or email code was used. Receipt `.local/logs/jwks-workers-diagnostic-1788634075441.json` records `manualRedirect:false` (no diagnostic override). The earlier failing runtime receipt is `.local/logs/jwks-workers-diagnostic-1788633986147.json`.

Final delta validation: **240/240 tests PASS**, including the no-follow redirect regression; Functions typecheck and compilation PASS. Logs: `.local/logs/2026-09-05T18-48-28-886Z-test-7f710ed0-cdf2-4a2c-96ca-6550749c8c0e.log` and `.local/logs/2026-09-05T18-48-31-399Z-cloudflare-functions-build-8a050ad8-9617-4349-a529-301aff2b3a2e.log`. The previously verified web bundle is unchanged by this server-only correction. Actual owner OTP acceptance remains separate.

## Delivered preview

Deployed source `b0bd09d13b7f7d0916b34705b8f0f7d1dc7d19a0` at `https://a3f4f09f.accreatio.pages.dev`, deployment `a3f4f09f-f24c-4a3e-abfd-d1a3fa34ce64`. Stable alias: [protected account preview](https://archive-email-auth-preview.accreatio.pages.dev). API readback confirms successful preview deployment, four account variables and both database bindings. Ten anonymous probes across the immutable URL and alias redirect to Access; an AJAX session probe with `X-Requested-With: XMLHttpRequest` correctly returns 401. Production remains `11235c8c-108f-46f3-8cce-fb88a144330b`.

The designer-auditor reviewed the final JWKS delta and retained **PASS**. No real OTP or owner identity was used for automated acceptance.
