# Activar Google OIDC en accreatio

Actualizado: 2026-09-08. Alcance: accreatio. El usuario confirmó Chile y Estados Unidos como países incluidos; esto no determina por sí solo domicilio del responsable, estado estadounidense, contratos ni obligaciones territoriales concretas.

El cliente Web está instalado sólo en preview y Google funciona con `aekr@aekr.io`; OTP permanece desactivado. Se corrigió el receptor de `fetch` del servidor y se verificaron intercambio real, sesión, recarga y logout. El incremento solicitado de perfil muestra Ed Lopez en el menú tras consentimiento real, conservando la cuenta y sus cinco exportaciones. El [recibo de activación](GOOGLE_OIDC_ACTIVATION_2026-09-08.md) identifica despliegues, migraciones, pruebas y límites.

El usuario confirmó que dispone de Google Workspace pagado y que su cuenta administradora es **`aekr@aekr.io`**. Usar esa identidad para el alta/administración inicial y asociar el proyecto a la organización Workspace disponible. Workspace facilita la propiedad y gestión corporativa; no crea por sí solo este cliente ni restringe necesariamente el acceso a empleados. La audiencia de accreatio seguirá siendo **External** para admitir cuentas de fuera de la organización. No hace falta otorgar superadministración a usuarios de la aplicación ni conservar credenciales de esa cuenta en accreatio. [Organización Google Cloud vinculada a Workspace](https://docs.cloud.google.com/resource-manager/docs/creating-managing-organization).

## Registro inicial en Google — referencia para reposición

El cliente del preview ya está instalado; estos pasos documentan su configuración inicial y no indican crear un duplicado.

1. Entrar en [Google Cloud Console](https://console.cloud.google.com/) con **`aekr@aekr.io`**. Crear o seleccionar un proyecto dedicado al preview, por ejemplo `accreatio-preview`, bajo la organización Workspace. Mantener producción en un proyecto separado, como exige la [política de entornos de Google](https://developers.google.com/identity/protocols/oauth2/policies#use_separate_projects_for_testing_and_production).
2. Abrir **Google Auth Platform** y completar el inicio/configuración de marca: nombre `accreatio`, correo de soporte y contacto del desarrollador `aekr@aekr.io`. El canal público de derechos ya publicado sigue siendo `edlopezpm@gmail.com`; usar el correo corporativo para esta configuración no modifica ni elimina aquel canal. Seleccionar audiencia **External** y estado **Testing** para este preview.
3. En **Data Access**, declarar `openid`, `https://www.googleapis.com/auth/userinfo.email` y `https://www.googleapis.com/auth/userinfo.profile`. El servidor solicita `openid email profile`: el propietario eligió expresamente mostrar el nombre de Google en el menú. Google puede devolver otros campos de perfil; accreatio sólo conserva el nombre y descarta foto y demás campos. No añadir Gmail, Drive, contactos ni acceso offline. Esta es la configuración prevista; la consola no fue modificada durante el cambio de menú porque exigió una nueva verificación de contraseña del administrador. La prueba de consentimiento y claims reales se registra en el recibo de activación.
4. Abrir **Clients → Create client → Web application**. Nombre sugerido: `accreatio-preview-web`. En **Authorized redirect URIs**, añadir exactamente:

```text
https://google-oidc-preview.accreatio.pages.dev/api/auth/v1/oidc/google/callback
```

Los orígenes JavaScript autorizados pueden quedar vacíos para este flujo: la aplicación no usa el SDK de Google en el navegador ni un intercambio OAuth por JavaScript contra Google. El callback anterior corresponde al preview estable; no reemplazarlo por el dominio de un despliegue con hash. [Registro del cliente Web y protección de sus credenciales](https://developers.google.com/identity/protocols/oauth2/web-server#creatingcred).

5. Crear el cliente y descargar inmediatamente su JSON. Google muestra el secreto completo al crearlo y puede no permitir recuperarlo después. Guardar el archivo exportado como `.local/private/auth-20260908/google-client.json` dentro de este checkout. Esa carpeta ya existe, está ignorada por Git y tiene ACL del usuario actual. No pegar el secreto en el chat ni en un documento público. El archivo debe conservar el objeto `web`, su `client_id`, `client_secret` y `redirect_uris` del formato de Google.

**Testing no es una lista de acceso suficiente para este caso.** Google documenta una excepción para los permisos básicos de OIDC: no se exige que cada usuario esté añadido como tester y no aplica la caducidad general de siete días de ese modo. El preview sigue limitado por su protección existente de acceso. [Comportamiento oficial de la audiencia](https://support.google.com/cloud/answer/15549945).

## Branding: exact preview fields in the English console

The following homepage and legal URLs returned HTTP 200 without authentication on 2026-09-08. Use this existing public preview for branding links; the Google login preview itself remains behind Access. These are preview values, not a production brand-verification claim.

| Field | Value |
| --- | --- |
| App logo | Click **Browse** and select `public/branding/accreatio-web-192.png` in this repository; existing square PNG under 1 MB. Optional for Testing. |
| Application home page | `https://archive-email-auth-preview.accreatio.pages.dev/` |
| Application privacy policy link | `https://archive-email-auth-preview.accreatio.pages.dev/legal/privacy` |
| Application terms of service link | `https://archive-email-auth-preview.accreatio.pages.dev/legal/terms` |
| Authorized domains | Click **Add domain**, enter `accreatio.pages.dev` without protocol, path or wildcard. |
| Developer contact information / Email addresses | `aekr@aekr.io`; the screenshot contained a transposition, `aerk@aekr.io`, which must be corrected. |

Click **Save** after entering the values. Keep **Audience → Publishing status → Testing** during preview acceptance. Do not change the OAuth client's redirect URI to the public branding alias.

Google requires the top private domain of the configured URLs; `pages.dev` is listed in the [Public Suffix List](https://publicsuffix.org/list/public_suffix_list.dat), making `accreatio.pages.dev` the applicable private domain. [Branding fields](https://support.google.com/cloud/answer/15549049) and [verification requirements and testing exception](https://developers.google.com/identity/protocols/oauth2/production-readiness/brand-verification).

## Instalación y aceptación a cargo de la implementación

La instalación de `GOOGLE_CLIENT_ID` y `GOOGLE_CLIENT_SECRET` en la configuración protegida de preview se completó mediante `.local/cache/auth-implementation-20260908/install-google-client.mjs`. Este helper modifica exclusivamente esas dos claves Google y conserva las claves existentes de cuenta, privacidad y OIDC. Antes de una reposición, comprobar el callback, el estado vigente y la copia de respaldo. El respaldo se crea con escritura exclusiva (`wx`): si ya existe, no repetir la instalación a ciegas ni borrar la copia para forzarla. Instalar o reponer el cliente Google no debe regenerar las claves de cuenta.

El inicio de sesión real y el nombre de perfil ya se comprobaron en el navegador conectado. Cancelación, adjuntos locales, cuotas, exportación/borrado y menús también cuentan con pruebas funcionales aisladas; no se eliminó la cuenta real del propietario. Conservar `ACCOUNT_OTP_ENABLED=false`. La implementación admite nuevas cuentas Gmail o Google Workspace con correo autoritativo; no promete admisión de cualquier dirección externa asociada a una cuenta Google.

El preview conserva una protección Cloudflare Access adicional. La política wildcard permite exactamente `edlopezpm@gmail.com` y `aekr@aekr.io`; su copia anterior está en `.local/logs/google-activation-20260908/access-policy-before-owner.json`. El navegador necesita ese acceso para llegar al callback; no confundirlo con el login de producto. La configuración para usuarios finales deberá permitir las rutas públicas de autenticación y los avisos, manteniendo protegidas las rutas administrativas.

## Paso posterior a producción

La prueba inicial no necesita presentarse como un lanzamiento público. Para producción, usar su proyecto/cliente y callback definitivos, un dominio cuya propiedad pueda verificarse y una página de presentación con política de privacidad accesible sin login. Completar la verificación/publicación de marca correspondiente en Google. Los permisos básicos no requieren una evaluación de permisos sensibles; los requisitos de marca y dominio siguen siendo independientes. [Requisitos y excepciones de verificación de marca](https://developers.google.com/identity/protocols/oauth2/production-readiness/brand-verification).

La revisión legal para Chile/Estados Unidos continúa en [operaciones de privacidad](ACCOUNT_PRIVACY_OPERATIONS.md). Crear credenciales Google no resuelve automáticamente esa evaluación. El [rollback compatible](GOOGLE_OIDC_ROLLBACK.md) preserva la identidad, las claves y las cuotas.
