# accreatio — Bounded technical abuse guard and rights access

Updated: 2026-10-22. Owner-authorized implementation contract; operator/contact: AEKR, [aekr@aekr.io](mailto:aekr@aekr.io). Scope: the separate web account service. This record does not certify legal validity, territorial compliance, hosted deployment or a real provider journey.

## Authority and source

The owner requested deterministic technical protection, temporary automatic restrictions, reviewed permanent closure, and continued own-data/deletion access. The implementation uses [the abuse guard](../functions/_lib/abuse.ts), [account handlers](../functions/_lib/accounts.ts), [rights-only proof](../functions/_lib/auth/rights.ts), [the OIDC store](../functions/_lib/auth/oidc-store.ts) and [scheduled maintenance](../workers/account-maintenance/index.ts). Public notices are [Terms](TERMS_OF_SERVICE.md), [Privacy](PRIVACY_POLICY.md) and [necessary storage](../public/legal/cookies.html). The Pages route boundary sends only `/api/*` through Functions: static pages, assets, branding and legal files do not consume application guard counters. Infrastructure/CDN/DDoS processing is separate; this record does not establish zone/WAF configuration or load-tested capacity.

Policy versions are `2026-10-22-privacy` and `2026-10-22-beta`; purpose remains `account-core-v1`. A visit, existing-session refresh, abuse decision or rights-only proof creates no acceptance or processing receipt. Existing receipts are not backfilled or redated. A deliberate ordinary-service continuation beside the current notice and valid account proof remains necessary.

## Minimum state and retention

| State                   | Fields and scope                                                                                                                  | Boundaries                                                                                                                                                                                                     |
| ----------------------- | --------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `account_abuse_buckets` | HMAC scope key, scope kind, fixed route class, fixed-window start/count, cooldown, bounded strike level, last-excess time, expiry | At most 8,192 rows; one-hour expiry after last admission/new cooldown; blocked retries do not extend expiry. At most 4,096 anonymous-network rows; 512 total slots reserved for rights/callback safety routes. |
| `account_abuse_state`   | Opaque account ID, level 0–3, at most two pending episodes, episode/restriction/recurrence/expiry dates, transition revision      | At most 4,096 accounts; 48-hour state expiry after the last eligible new episode; escalation recurrence stays 48 hours after a restriction. Soft deletion retains this minimum until expiry or earlier physical account-row removal; the foreign key cascades physical removal.                   |
| `account_abuse_gate`    | One fixed, transactionally overwritten gate row containing bounded reason/transition state                                        | Coordination scratch state, not a request/event history; no caller-supplied event ID or payload.                                                                                                               |
| Rights-only proof       | Existing linked account, hashed random proof, database time, action, security version, `rights_only=1`                            | Five minutes, data or delete only; separate HttpOnly cookie and ordinary service admission.                                                                                                                    |

Network keys use trusted Cloudflare connection headers, canonical IPv4 /32 or IPv6 /64 values, normalized IPv4-mapped addresses and distinct HMAC namespaces. Invalid/missing trusted addresses do not become a shared fallback key. The existing protected `ACCOUNT_AUTH_LOCATOR_KEY` is reused with separate network/account/session abuse domains. Raw addresses exist only during request processing; they are not stored by this guard. Session dimensions HMAC the existing token hash; account dimensions HMAC the opaque account ID. Do not call these values anonymous.

The guard stores no email, user agent, request/response body, project name/content, attachment, provider token or raw IP. No AI assessment, content keyword classifier, cross-product identity, permanent banned-person ledger or analytics purpose is added. Support correspondence is a separate protected surface with its own handling; do not copy it into guard tables.

## Request pacing and temporary restrictions

Counters use fixed 60-second windows. Current configured limits per minute are:

| Route class          |                                                 Network | Account | Session |
| -------------------- | ------------------------------------------------------: | ------: | ------: |
| Public API read      |                                                     180 |       — |       — |
| Auth start           |                                                      20 |       — |       — |
| Auth status          |                                                     120 |       — |       — |
| OTP request / verify |                                                 12 / 60 |       — |       — |
| Account read         |                                                     360 |     120 |      90 |
| Account write        |                                                     120 |      30 |      20 |
| Export authorization |                                                      60 |      12 |       8 |
| Rights               | 180 before known principal; omitted for known principal |      12 |       8 |
| Callback             |                                                     180 |       — |       — |

Network/session pacing may return `429` with `Retry-After` and cooldowns of 30 seconds, one minute, two minutes, five minutes and 15 minutes. Levels decay after 15 minutes; retries during an active cooldown do not extend it. Capacity/service failure is bounded and is not an account sanction. OTP remains disabled in production unless separately authorized and operated.

Account sanctions require an explicitly eligible ordinary business action, a currently valid full session and an account/session limit excess attributable to that account. Invalid input, missing/expired sessions, exhausted export allowance, network-only excess, callbacks and rights requests cannot accrue sanctions. Count at most one attributable episode per minute. Three within ten minutes cause a ten-minute restriction; recurrence within 48 hours escalates to one hour and then at most 24 hours. The transition increments the account security version and revokes ordinary sessions atomically. Existing rights-only rows do not grant ordinary access; a security-version change requires fresh rights proof.

The implementation does not automatically close an account permanently. Shared NAT/IP, use of different email addresses or email coincidence alone is never evidence for an account sanction. Any permanent closure needs a separate reviewed decision and implemented authority/process before activation; do not improvise SQL bans or an indefinite tombstone list.

## Rights, deletion and review

The sign-in rights panel starts `account_access` with `rightsOnly=true` for data or deletion, without an ordinary app session or current Terms/account-processing acceptance. Provider proof resolves only an already linked issuer/subject on an existing active account; it never links by matching email, creates/reactivates an account, refreshes profile, writes a policy receipt or resets allowance. Its five-minute `__Host-accreatio_rights` cookie is Secure, HttpOnly, host-only, Path=/ and SameSite=Strict. Data/delete requests explicitly select it. It cannot authorize the builder or other account routes.

Ordinary suspension does not block this separate identity-proof path. Identity proof still protects against disclosure/deletion by another person, and proportionate rights-route pacing remains. Rights-start admission has its own budget of 20 requests per protected network key/hour, 90 globally/hour and at most 1,024 retained rights transactions; ordinary sign-in traffic does not consume it. That finite budget can still delay a request under distributed excess. If the provider or proof is unavailable, route the request to [aekr@aekr.io](mailto:aekr@aekr.io); do not promise unconditional self-service or demand acceptance of new Terms to handle a request. OAuth success does not prove a password or MFA was entered again.

Account deletion immediately clears active contact/name, linked identities and authorization receipt and revokes sessions. Minimal account-abuse continuity and protected quota/deletion locators retain their stated 48-hour windows; HMAC buckets are not mapped back through an account foreign key and retain their one-hour expiry. This prevents deletion/re-registration from immediately resetting technical restrictions without storing deleted contact/subject in plaintext or retaining a permanent ban.

For a restriction review, record a random private case reference, requested action, minimum verified ownership, the technical category/time and the applicable response deadline. Keep correspondence in the protected support system. Never ask for passwords, OTPs, provider tokens or project files; never send/export raw HMAC keys or other users' activity. Explain the actual restriction and rights route. A review is separate from an automated sanction and from any future permanent-closure decision.

## Migration, release and recovery

Apply additive `migrations-auth/0007_abuse_guard.sql` and `0008_rights_only.sql` in order after the existing chain, before traffic uses the new code. The rights migration adds default-zero `rights_only` fields to auth transactions and session metadata; legacy ordinary rows remain ordinary. The guard migration adds bounded tables/indexes and coordination state, without acceptance or historical-episode backfill. Preserve existing account IDs, quotas, authorization receipts, security versions, identity/privacy keys and deletion continuity.

Both maintenance paths delete expired guard rows: at most 25 per guard table during a guard request and at most 500 per table in scheduled maintenance. Expiry is checked before use; physical cleanup can lag on failure/backlog. Use only aggregate eligible/backlog counts for operational evidence, and investigate repeated capacity or cleanup failure without dumping keys or payloads. Provider logs/backups have separate, unverified retention; these application TTLs do not establish theirs.

Rollback must preserve the additive schema and all later deletions/revocations. Do not restore a pre-guard/pre-rights database or a code version that treats a rights proof as an ordinary session. Before reopening traffic, retain equivalent rights-only rejection on ordinary routes, sanction/security-version gates and data/delete isolation. Do not rotate the shared HMAC key as a cosmetic reset: it also protects existing deletion/admission locators and needs its own coordinated migration. No rollback may fabricate acceptance, revive a deleted receipt/account or turn a temporary restriction into an indefinite one.

## Verification record

Required evidence is separate for source tests, local migration/runtime tests, final built UI, deployed migration/application readback and real provider ownership. Exercise same-network independent accounts, session/account excess, burst concurrency, stale-session replay, level/TTL/cap boundaries, scheduled/request cleanup, data/delete during suspension, wrong-provider/action/cookie rejection, null legacy receipts and no receipt/quota/profile mutation in rights-only flows. Inspect desktop/mobile light/dark footer cookie alignment separately. Release receipts own exact SHA, migration state, test totals and hosted versions; this document does not invent those outcomes.
