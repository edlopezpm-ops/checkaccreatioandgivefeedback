# Local logs, caches and archives

Owner decision: 2026-09-05. Standard source: AEKR `toolkit/project-scaffolds/docs-governance/local-artifacts.md`.

Use `.local/logs/<tool-or-run>/` for command logs and diagnostics, and `.local/cache/<tool>/` for reproducible caches. Both are ignored by Git. AI agents read them directly or use `rg --files --hidden --no-ignore .local/logs`. Logs do not belong in the repository root.

Run `npm.cmd run log -- test` (or another existing package script) for unique persistent output with the original exit status. The wrapper accepts no arbitrary shell commands or additional arguments. Never log credentials, email lists or project inputs.

Lighthouse writes `.local/logs/lighthouse/`; new guided browser captures use `.local/logs/playwright/`. Vite and Functions intermediates use `.local/cache/`. Existing `output/branding/` is canonical evidence; historical `output/playwright/` remains a referenced evidence set. `.wrangler/`, `.git/`, `.claude/`, `.playwright-cli/`, `node_modules/` and `dist*` retain tool/build contracts. Do not move live state or hide it with junctions.

## Migration on 2026-09-05

- Root `*.log` files moved into `.local/logs/legacy-20260905/`; its local `migration.json` binds old/new paths and SHA-256 hashes.
- Superseded designs and audits moved into [the documentation archive](archive/README.md), with original/resulting hashes.
- Desktop packages moved to sibling `accreatio-archive/2026-09-05/`, outside this checkout. Its manifest records 160 files and 1,466,479,248 logical bytes, checked by relative path and size after the move. All files were retained; no hash verification or compression is claimed for that move.

Promote minimal sanitized results to versioned docs when remote review needs them. Ignored logs are not guaranteed in another checkout. No automated cleanup or deletion is enabled.

Account deployment exception (2026-09-08): local runtime-key backups and provider client configuration belong under ignored `.local/private/`, with access restricted to the current Windows user. They are not diagnostic logs or reproducible caches; do not print their contents or apply cache-retention cleanup to them. Preserve the keys required by encrypted account records and compatible rollback. Store export backups with the same protection.
