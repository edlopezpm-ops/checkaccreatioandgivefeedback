# accreatio privacy and tracking baseline — 2026-10-20

Scope: accreatio. State: source `1d30f4d246099cb0d802d0c5f759381a8d35f4aa` is locally verified, pushed to `main` and deployed. It supersedes the initial privacy release with AEKR continuation wording and independent cookie refusal. Five account migrations, policy versions and protected runtime keys are unchanged. B10 remains a separate human acceptance scope. No optional analytics, advertising, cross-product identity use or personal-data sale is activated. This is an engineering baseline, not a legal-review certificate.

## Authority and product facts

The owner explicitly selected AEKR as the visible operator/authorization recipient, [aekr@aekr.io](mailto:aekr@aekr.io), Chile/United States operations and worldwide intent. This wording correction preserves the account purpose, permissions, policy versions and existing receipts. No entity, physical/service address, US state, treaty mechanism, provider agreement or worldwide exemption is inferred. Existing product data promises remain binding until a separately authorized prospective change.

The domain/free Google beta is operational under Google's Testing audience. See [Production setup](PRODUCTION_SETUP_2026-10-20.md); do not call the public origin the earlier Access-gated product or claim unrestricted Google publication. The account-policy release is newer than the observed real login; its local validation and migration receipt below do not establish a human acceptance of the new notices.

Contract versions: privacy `2026-10-20-privacy`, Terms `2026-10-20-beta`, purpose `account-core-v1`. [Public Privacy](PRIVACY_POLICY.md), [Terms](TERMS_OF_SERVICE.md), [operating inventory](ACCOUNT_PRIVACY_OPERATIONS.md), [cookies/device storage](../public/legal/cookies.html).

## Reference provenance and limits

| Reference                        | Exact provenance                                                                                                                                                                                    | Reusable lesson / limit                                                                                                                                                                                         |
| -------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| accreatio pre-change source      | `fd20023223a34d3e5e9256d39202ec7a147a320c`                                                                                                                                                          | Google production revival precedes this increment; no old scalar notice version proves a separate affirmative authorization                                                                                     |
| accreatio initial privacy source | `aa9629b635aa54c55c2211ba846a4048beb4be61`, initial privacy release, superseded below                                                                                                               | Full local verification and diagnostic packaged-host smoke passed; production migration, deployment and technical readback passed; new human authorization remains separate                                     |
| aekr-web local checkout          | `b0a0929887d5d9719b84fec20f5d2e6050b99176`, master behind seven, 30 dirty/untracked paths at inspection                                                                                             | Read-only; old local privacy/beacon/notice claims do not describe the later remote implementation; original checkout preserved; later isolated publication is recorded below                                    |
| aekr-web current remote          | `6a452eeb311ddfa302cf30144b2b079dda07a03a`, read via GitHub API without fetching into the dirty checkout                                                                                            | Policy v3 consent/collector/marginal counters are a technical reference, not accreatio collection or commercial permission                                                                                      |
| aekr-web v3 release provenance   | Merge `d6962b330086ae233eab8aceee5464d0d2719353`; [master receipt, lines 146-184](https://github.com/edlopezpm-ops/aekr-web/blob/6a452eeb311ddfa302cf30144b2b079dda07a03a/docs/master.md#L146-L184) | Dated migration/live tests and declared synthetic traffic; no completed report sale or universal legal approval                                                                                                 |
| Shared timeKER baseline          | timeKER HEAD `4bb5c424d6e7d270cdca1479283896be77d581c3`; latest baseline-file commit `fbe48fbb92b2551112e73d3d822b80572648de0b`, `docs/legal/AEKR_PRIVACY_BASELINE.md`                              | Product separation, purpose/minimization, device-storage inventory, conditional territorial analysis and sanitized evidence; another product's personal/legal facts and operating retention are not transferred |

The aekr-web runbook's opening local-v3 wording is stale beside its master release receipt; its optional-usage implementation document explicitly preserves historical v1/v2 contracts. Use the selected v3 contract/code and dated master evidence rather than treating every paragraph as live status.

Fresh anonymous GETs on 2026-10-20 observed aekr.io's v3 `usage.js` and notice; no independent Insights beacon appeared in those HTML responses. accreatio's root and legal privacy HTML also showed no Insights beacon and retained self-only script/connect CSP; legal HTML had `no-transform`. These are bounded HTTP observations, not a fresh interactive browser/storage/provider-configuration audit. Cloudflare can inject analytics separately from source; [provider configuration](https://developers.cloudflare.com/web-analytics/get-started/) and [collection endpoints](https://developers.cloudflare.com/web-analytics/data-metrics/data-origin-and-collection/) require their own inventory. No authenticated page, cookie value, account payload or secret was read for that comparison.

## Patterns selected, deferred and excluded

aekr-web's current [consent client](https://github.com/edlopezpm-ops/aekr-web/blob/6a452eeb311ddfa302cf30144b2b079dda07a03a/public/usage.js#L4-L54) requires a current affirmative versioned choice, rejects expired/old/unavailable storage, applies GPC/DNT, synchronizes withdrawal and aborts requests. Its [collector](https://github.com/edlopezpm-ops/aekr-web/blob/6a452eeb311ddfa302cf30144b2b079dda07a03a/src/usage.js#L21-L84) has finite shapes, no credentials, exact origin, privacy-signal checks, bounded body/time and a backend kill switch. Its [store](https://github.com/edlopezpm-ops/aekr-web/blob/6a452eeb311ddfa302cf30144b2b079dda07a03a/src/analytics-store.js#L12-L85) keeps independent marginals with atomic budgets and purge, not event histories.

Those are reusable controls if accreatio later selects optional measurement. Its 180-day preference, 90-day totals, commercial research purpose, audience catalogue and recipient/licensing rules are aekr.io choices, not accreatio defaults or law. In particular:

- Keep account authorization and Terms separate from optional analytics/advertising. Necessary session/security storage gets accurate notice, not a misleading optional toggle.
- Keep accreatio's `DEFAULT_CONSENT` analytics/advertising false and adapters no-op. The legacy `AccountShell/PrivacyControls` preview has transient React state and is not a deployed consent manager.
- No project contents, names, attachment metadata, prompt text, raw URLs/referrers, account/provider/session IDs, security metadata or raw IP may become a new optional analytics dataset by calling it aggregate.
- Do not copy aekr.io's commercial-report permission or repurpose older accreatio account data. A materially new purpose requires a separately selected and assessed prospective contract.
- If optional measurement is selected later, use a closed minimal event catalogue, separate authority/store, applicable versioned refusal/withdrawal and signals, private reads, true retention/purge and cost/volume evidence. No optional collector is introduced. The later necessary-only Cookie preferences control is described below.

The selected change now is an explicit core-account authorization receipt, accurate local-storage/cookie notices, current contact and removal behavior. It does not create a research questionnaire, data dashboard, marketing list, ad adapter or payment service.

## Core-account authorization and deletion contract

`shared/accountPolicy.ts` owns `privacyNoticeVersion`, `termsVersion` and `purposeVersion`. Requests add separate `accountDataAuthorized` and `termsAccepted` booleans, both affirmatively true. No Google grant, existing session or notice-version scalar is substituted for that action.

The owner's follow-up replaces the two checkbox controls with a visible
continuation notice naming AEKR. Terms agreement and the stated necessary
account-processing instruction are explained before the action; Google, Send
code or existing-account Continue generates the payload only on deliberate
activation. Visiting, session refresh, cancellation or an unproved identity does
not create an account receipt. The purpose, permissions and three versions remain
unchanged. Optional collection is never authorized by this action.

The sign-in start/request captures database time and current versions in the bounded transaction. Only successful identity proof materializes the latest account receipt in the login batch. The receipt contains three versions and `authorized_at`, not IP/UA, project text, provider tokens or a raw event history. Repeating unchanged versions does not redate it. Existing-account POST policy authorization uses its valid session and exact Origin without resetting session/account/quota state.

Own-data exposes the five authorization fields plus ISO `authorizedAt`, or `null` for an unrecorded legacy choice. There is no historical backfill. Account deletion immediately purges the receipt; a deletion trigger preserves that rule for an older compatible writer. The receipt is not retained in 48-hour tombstones or a commercial ledger. Retention is active-account duration, not an invented new compliance-log period.

Separate rights-only `account_access` reauthentication requires a valid existing session and fresh proof of its same Google/provider account. It cannot register/resurrect an account, update profile/receipt or require new Terms/core-data acceptance. The existing own-download/delete freshness bound is five minutes. Without a valid session/proof, the product-contact fallback remains necessary; this is not unconditional self-service.

## Device storage and cache verification

Source: `src/draftStore.ts` defines onboarding schema 1 and persisted draft schema 5; `src/bridge/web.ts` holds transient ZIP recovery; `vite.config.mts` separates public precache from API/Access paths.

| Item                              | Evidence / precise bound                                                                                                                   | Removal and limit                                                                                                            |
| --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------- |
| `__Host-accreatio_session`        | 24h, Secure, HttpOnly, host-only, Path=/, SameSite=Strict                                                                                  | Logout/deletion revokes; expiry and physical server cleanup are separate                                                     |
| `__Host-accreatio_auth_tx`        | 10min, Secure, HttpOnly, host-only, Path=/, SameSite=Lax                                                                                   | Supports Google return; server admission metadata has a separate 1h window                                                   |
| Conditional Access cookies        | Earlier protected-origin evidence includes `CF_Session`; `CF_Authorization` depends on actual provider flow                                | Not product-session cookies; no current host/TTL claim without observed configuration                                        |
| `accreatio:onboarding`            | localStorage `{schemaVersion:1,completed:true}`; no TTL                                                                                    | Browser site-data control; not a project/account record                                                                      |
| `accreatio:cookie-preferences`    | localStorage schema 1, necessary=true, analytics=false, advertising=false and browser action time; written only on explicit rejection      | 180-day validity; expired value removed on next read or earlier browser site-data removal; no identifier/server transmission |
| `accreatio-drafts/drafts/current` | IndexedDB fields/options plus transient attachment count; persisted `attachments:[]`                                                       | Current-draft clear/replacement/eviction; no selected file names/bytes saved                                                 |
| Service-worker Cache Storage      | Final web build has 23 public precache entries, including cookies HTML; no API URL in the manifest; API/cdn-cgi navigation fallback denied | Rebuild/recount completed for this release. No authenticated account response cache is introduced                            |
| ZIP recovery                      | Blob/name/operation reference only in open-page memory; retry eligibility 48h                                                              | Until clear/replacement/New draft/reload; eligibility expiry alone does not prove Blob memory removal                        |

New draft clears the current draft and prepared ZIP recovery in the coordinated source change. It is not a logout, remote account deletion or full localStorage/Cache Storage purge. Account deletion does not erase downloaded files or other device-local projects.

## Closure matrix

| Area                             | Confirmed source / evidence                                                                                                                              | Remaining operating fact or boundary                                                                          |
| -------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| Operator/contact/country intent  | Direct owner instruction reflected EN/ES                                                                                                                 | Physical/service address and any state/establishment disclosures actually required                            |
| Public notices/storage inventory | Script-free EN/ES notices inspected; local 390px legal-page/contact/storage checks and exact new-release hosted HTML/CSP/cache readback passed           | B10 human authorization remains separate from document delivery                                               |
| Affirmative authorization        | Production additive migration applied; false/stale/missing, isolation, DB-time/idempotence, legacy-null, deletion and integrated policy UI checks passed | New human authorization journey remains pending; earlier Google login is not acceptance of these notices      |
| Local data lifecycle             | Browser regression passed: cancel retains ZIP retry; confirmed New draft removes old recovery without account/quota changes; precache recounted to 23    | Device downloads, unrelated local data and provider copies retain their separate boundaries                   |
| Provider/edge surfaces           | Local GPC/DNT scan passed without optional collection; fresh public HTML showed no independent beacon or Set-Cookie; no configured Web Analytics/Engine  | Anonymous public readback is bounded; Pages Logpush/observability and provider retention remain unverified    |
| Retention                        | App windows; first bounded production probe purge observed, separate from provider copies                                                                | Cleanup backlog/failure handling, actual log/recovery/mailbox schedules and restore behavior                  |
| Rights/incidents                 | Own-export/delete, fresh rights without new acceptance, revocation and fallback-contact UI checked locally                                               | Named operating workflow, due-date/appeal/incident handling rehearsal and provider escalation facts           |
| Territorial assessment           | Current Chile authorization concern and upcoming transition; conditional EU/UK/US map                                                                    | Actual role/location/market/threshold facts, effective agreements/transfers and qualified review where needed |
| Optional analytics/advertising   | No-op/off, explicit necessary-only refusal with no invented optional grant; local network/storage scan passed                                            | Separate future scope before any activation; this row is not an implementation backlog authorization          |

No diagnostic record may contain raw project/contact content, person-linked IDs, raw IP, tokens or callback/query bodies. Fixed redacted error categories and aggregate operational counters are separate from optional metrics; no new log collector or unverified retention SLA is claimed.

Cookie preferences is a web-only, honest necessary-only control: analytics and
advertising are unused/off, so there is no invented opt-in to an unspecified
collector. Reject non-essential cookies saves the local refusal independently
of account access. No preference is written before that action. A blocked store
leaves optional purposes off and reports tab-only persistence. A future optional
purpose needs a new applicable choice before activation; the local refusal is
not account consent, a cross-product permission or a server audit record.

Provider readback refreshed at `2026-10-20T21:25:29.360Z` found no configured Pages production/preview Web Analytics and no Analytics Engine bindings. Logpush/observability fields were not returned for Pages; missing metadata is not an OFF or deletion claim. Maintenance reported Logpush false and its hourly minute-17 schedule. Sanitized receipt: `.local/logs/privacy-readiness-20261020/provider-readback.json`. The contact domain's Google MX exists; actual mailbox delivery remains untested by this check.

The first scheduled production cleanup pass was observed after the 21:17 UTC tick: expired synthetic probe count `1` at `2026-10-20T21:14:33.795Z`, then `0` at `2026-10-20T21:17:24.722Z` in `.local/logs/revival-20261020/cleanup-after.json`. No manual or application-request cleanup was invoked; `maintainAccounts` runs only in the maintenance Worker. The active version was `19d1833c-cac5-47a4-afb7-f29835705fe5`, with existing production source `1b5a1ffe67e5d1c898f105ae8efb4ece75c32b84`. Migration `0005` and the new privacy/maintenance release were not yet deployed. This bounded observation is not evidence of ongoing monitoring, every retention category, backlog clearance or provider-copy deletion.

## Primary legal orientation — checked 2026-10-20

[Chile Law 19.628 Article 4](https://www.bcn.cl/leychile/navegar?idNorma=141599&idVersion=2023-05-09) is relevant to informed, express written authorization/revocation where applicable; the electronic receipt is evidence to assess, not legal approval. [BCN's commencement record](https://www.bcn.cl/balance-legislativo/detalle/ficha_LEY_21719_2024-12-13) dates Law 21.719's principal changes to 2026-12-01. Prepare transition separately.

[GDPR Article 3](https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng) depends on actual establishment/offering/monitoring; worldwide accessibility is not a universal scope determination. [ICO technology guidance](https://ico.org.uk/for-organisations/direct-marketing-and-privacy-and-electronic-communications/guidance-on-the-use-of-storage-and-access-technologies/what-are-storage-and-access-technologies/) covers device storage beyond cookies; [current exceptions](https://ico.org.uk/for-organisations/direct-marketing-and-privacy-and-electronic-communications/guidance-on-the-use-of-storage-and-access-technologies/what-are-the-exceptions/) remain purpose- and condition-specific. No terms checkbox, technical test, provider certificate or country-only answer establishes global compliance.

## Initial privacy-control delivery receipt

| Item                        | Confirmed result                                                                                                                                                                                                                                                                                                                               |
| --------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Application source          | `aa9629b635aa54c55c2211ba846a4048beb4be61`, pushed to remote `main` before the documentation-only delivery receipt; this is the exact deployed application source                                                                                                                                                                              |
| Full local verification     | `npm.cmd run log -- verify`: PASS, 332/332 unit tests; mailer tests/types/dry-run, pinned branding, Blog seed, project map, Cloudflare types, app/Electron/Functions typechecks, formatting, Functions build, web/desktop builds and functional smokes                                                                                         |
| Functional browser coverage | Web creation/layouts, account menu/OTP, rolling quota/retry, revocation/logout/delete, policy gate without backfill, rights without new acceptance, idempotent DB-time receipt, later-requirement checkbox reset, retained draft/attachments and Google popup/cancel/outage/expiry all passed with synthetic fixtures                          |
| Public privacy/browser scan | Privacy/Terms/cookies/contact and exact storage names passed at 390px; GPC/DNT scan observed same-origin requests, no optional collector/transmission/banner and no optional browser storage. This is local-bundle evidence, not a live-edge assertion                                                                                         |
| Cache and final web build   | Final `build:web` and `test:surface` passed; 23 public precache entries including cookies HTML; auth/API responses are excluded                                                                                                                                                                                                                |
| Diagnostic Windows package  | Actual packaged host PASS; 20 exact ASAR assets, onboarding, IPC execution/versioned rerun/failure recovery; unsigned local diagnostic, test-only no-sandbox workaround, no desktop publication                                                                                                                                                |
| Lighthouse                  | 96 performance / 100 accessibility / 100 best practices; SEO 66 under intentional private-beta `noindex`; configured gate passed                                                                                                                                                                                                               |
| Independent review          | Final backend/UI review found no open blocker. Reproduced expiry race was fixed with an atomic completion guard; independent directed tests 51/51 and workerd/D1 1/1 passed                                                                                                                                                                    |
| Production schema           | `0005_account_policy_authorization.sql` applied successfully to production `accreatio-accounts` (`84e68cab-6bbd-4a4b-a8fc-3d4eda2765d3`); 15 commands completed                                                                                                                                                                                |
| GitHub CI                   | [Run 39499823833](https://github.com/edlopezpm-ops/accreatio/actions/runs/39499823833) did not start verification: billing/spending-limit annotation, failed job with an empty steps list. This is not a remote test failure or PASS                                                                                                           |
| Production Pages            | Deployment `f854ab2d-55ec-4990-87f8-7551a71f6eb1`, source `aa9629b635aa54c55c2211ba846a4048beb4be61`, success at `2026-10-20T21:24:54.475295Z`                                                                                                                                                                                                 |
| Production maintenance      | Version `fbcce59c-3169-4ba5-9ebb-12a54ca78477`, deployment `55672748-4784-459e-b933-4d1d56595e5a`, 100% at `2026-10-20T21:25:19.999055Z`; hourly minute-17 schedule retained. The earlier observed cron pass belongs to the preceding version                                                                                                  |
| Hosted technical checks     | 11/11 new-release checks and 10/10 origin checks passed: public bytes match build; no independent beacon or public Set-Cookie observed; missing/false/stale authorization, sessionless rights and unauthorized policy requests fail closed; account/admin responses no-store; Google on/OTP off; HTTPS/canonical redirects preserve path/query |
| Pre-acceptance aggregate    | Retained readback at `2026-10-20T21:28:38.679Z`: five migrations, one live account, zero policy receipts/current receipts, zero export receipts and zero completed transactions retaining an issue marker. No personal account payload was retrieved                                                                                           |
| B10 human authorization     | Not established by this initial receipt. The owner later confirmed that access functions and requested AEKR wording plus the continuation notice and separate cookie refusal. That instruction is not a fabricated personal acceptance receipt. The subsequent UI supersedes the two-checkbox design                                           |

Sanitized local evidence:

- `.local/logs/2026-10-20T21-18-53-221Z-verify-878fb428-c22d-4e9f-9cec-6a994329f21d.log` (final full run, exit 0)
- `.local/logs/privacy-readiness-20261020/verify-final-console.log`
- `.local/logs/account-ui-1792531208815/privacy-signals-receipt.json` and that directory's screenshots/functional evidence
- `.local/logs/privacy-readiness-20261020/final-web-build-console.log`
- `.local/logs/2026-10-20T21-21-59-997Z-test-surface-a9eca27c-ddd0-4f87-a875-ec92d313289e.log`
- `.local/logs/privacy-readiness-20261020/packaged-smoke.log` and `.local/logs/packaged-privacy-1792530981239/result.json`
- `.local/logs/privacy-independent-audit-20261020T211256680Z/policy-oidc-tests.log`
- `.local/logs/privacy-independent-audit-20261020T211405625Z/oidc-worker-tests.log`
- `.local/logs/privacy-readiness-20261020/production-migration.log`
- `.local/logs/privacy-readiness-20261020/production-pages.log`
- `.local/logs/privacy-readiness-20261020/production-maintenance.log`
- `.local/logs/privacy-readiness-20261020/release-readback.json`
- `.local/logs/privacy-readiness-20261020/pre-authorization-readback.json`
- `.local/logs/privacy-readiness-20261020/http-readback.json`
- `.local/logs/privacy-readiness-20261020/origin-http-readback.json`

The missing legacy AEKR sibling vendor-folder comparison was explicitly skipped by the verifier; the four pinned branding files passed. No failed or interrupted earlier run receives final PASS credit. Earlier Google login/reload, the old-source scheduled cleanup and September preview acceptance remain bounded historical facts. Technical release/readback completion does not establish B10 human authorization or the remaining operating/legal facts above.

## Current continuation and cookie-refusal delivery receipt

Source `1d30f4d246099cb0d802d0c5f759381a8d35f4aa` is pushed to `main` and
deployed as Pages `7966e29c-2cca-49b5-95b7-d101b17fa95a`, successful at
`2026-10-20T22:01:55.343538Z`. No migration, key rotation or maintenance
redeployment was needed: five migrations and Worker
`fbcce59c-3169-4ba5-9ebb-12a54ca78477` remain current. All three account-policy
versions above are unchanged.

The final integrated `verify` passed 337/337 tests with no skipped tests, plus
typecheck/format/generated types, Functions, web/desktop builds, branding,
mailer/Blog checks and functional web/account/project flows. Final unpacked
packaged-host smoke passed with 20 exact ASAR assets; the Electron 43.8.1 binary
is unsigned and unpublished. Lighthouse was 96/100/100, with intentional
private-beta SEO 66. The existing PWA upgrade regression also passed. The
missing historical sibling vendor-folder comparison remains explicitly skipped;
four pinned branding files passed.

The integrated run includes a deliberate native IndexedDB RED/GREEN regression.
The saved draft remained durable, but the first editable frame preceded async
hydration. The web editor now waits for the saved draft; the first rendered,
hydrated and persisted values agree. This is a premature-frame repair, not a
demonstrated loss of saved data. Independent cookie and hydration reviews passed.

Canonical-origin inspection confirmed EN/ES AEKR continuation wording, no
checkboxes and usable Google/Cookie preferences actions. An explicit cookie
rejection displayed “Preferencia guardada: solo necesarias.” without an account
Terms action. Eleven privacy/negative API checks and ten origin/auth/admin/Blog/
redirect checks passed against current build bytes. Pages Analytics/Engine
remain unconfigured; unreturned Pages Logpush/observability settings remain
unknown. Maintenance configuration is not proof of a new-version cron execution.

At `2026-10-20T22:02:30.759Z`, sanitized aggregates showed two accounts/Google
identities, one current authorization receipt and zero live sessions/exports.
Counts do not identify the owner or establish personal acceptance on this
specific release. The earlier zero-receipt migration snapshot is retained above;
no historical backfill is inferred. [GitHub run 39505013084](https://github.com/edlopezpm-ops/accreatio/actions/runs/39505013084)
started no job steps because of the account billing/spending block. No payment
setting was changed and no remote test PASS is claimed.

Evidence: `.local/logs/2026-10-20T21-58-40-423Z-verify-36471c56-b66c-4155-9c0b-81207eb2245d.log`,
`.local/logs/account-ui-1792533596516/`,
`.local/logs/packaged-clickwrap-v2-1792533682001/result.json`,
`.local/logs/pwa-regression-vDMFRg/receipt.json`,
and `.local/logs/clickwrap-20261020/` readbacks/screenshots. Failed earlier runs
retain their status. Seven runtime values remain protected locally with matching
source ZIP/document copies; the four original non-exportable Blog values and a
D1 snapshot are not in that backup.

## Related AEKR wording corrections

The owner subsequently requested AEKR responsibility wording in related apps.
Those isolated source increments do not copy optional collection authority,
commercial permissions, authentication state or account receipts between apps:

- timeKER PH3: `190f5d4079fce3371a410d1c034ed13398cadaaa`, two public template
  phrases and their canonical documentation; 55 focused tests and six renders
  passed. Versions, acknowledgment, cookies and issuer facts are unchanged.
- timeKER PROD: `c53a5009163ed0615b19653a55eb07b1af3e6a89`, independently
  prepared from production `4bb5c424d6e7d270cdca1479283896be77d581c3`, not
  promoted from Stage. Its production policy versions are preserved; 55 focused
  tests and six exact render comparisons passed.
- aekr-web: `bc186c7e31e63654728fa85e84dab1e2ef14580a`, public privacy EN/ES
  responsibility wording and dated master receipt; full repository check and
  32 existing privacy browser scenarios passed. Policy v3, choices, purposes and
  retention are unchanged. The dirty original checkout is preserved.

aekr-web was published independently: remote `master`
`2006223fa9ea971676ea35df35a5a4de9dca9aca`, final Worker
`05940338-9ede-490a-9087-ab8d5f98b2a6`, deployment
`756d5b93-ee2e-4978-b208-5813bc477287` at `2026-10-20T21:54:59.768285Z`.
Public privacy EN/ES readback passed, as did eight route checks and two exact
operator checks. Six deployed file bodies matched Git blobs. Policy v3 and its
existing `OPTIONAL_USAGE_ENABLED=true` are preserved; accreatio's off state does
not describe aekr.io. GitHub validate run `39504101872` started no steps due to
the account billing block. Original dirty checkout remained unchanged. Its final
sanitized receipt is in the isolated worktree's
`.aekr/evidence/operator-wording-20261020/release.json`.

timeKER PROD was deployed independently from its production baseline, with
application source `c53a5009163ed0615b19653a55eb07b1af3e6a89`, Worker
`886eee79-2d46-47f0-abad-272403d2cc14` at 100% and deployment
`96ca1b86-0008-44b1-ac94-14aa5a578a96`. Public `/` and `/legal/policies`
show AEKR; live/ready checks returned 200. Forty binding fingerprints and
non-image container resources were preserved. Fresh encrypted production backup,
non-root image smoke and independent exact-diff review passed. [PR 4](https://github.com/edlopezpm-ops/timeKER-PROD/pull/4)
merged at `2026-10-20T22:07:53Z`; remote main is
`f4a444fc475322065173db6b77fc9ce9f56fa917`. Production Terms/Privacy
`2026-10-15.v2`, sign-in notice `2026-10-16.v1`, acknowledgments, cookies and
issuer facts remain unchanged. This does not promote PH3 or reopen PH2.

timeKER Stage was deployed separately as Worker
`e7cb99d7-3ff1-4812-b879-91411b4e6324` at 100%, deployment
`1a0acace-bdc6-4193-b6e2-0c26efc2d19f`, created at
`2026-10-20T22:08:01.87883Z`. Existing container application/instance version 39
was RUNNING at `22:09:00Z`, pinned image
`7d476836fd9627ff6163502fd96d55245bea65e12ea95296b94cd971dbabf484`.
Public [Stage](https://stage-timeker.aekr.io), `/legal/policies` and health checks
passed with the two AEKR wording changes; 46 binding fingerprints and non-image
resources were preserved. A fresh encrypted snapshot of 14 schemas/765 tables,
non-root image smoke and independent diff review passed. [PR 6](https://github.com/edlopezpm-ops/timeKER-Stage/pull/6)
merged at `2026-10-20T22:10:22Z`, publishing
`341d9deffd22ded9e96098be34088871731fd847` to existing `codex/ph3-stage`,
not `main`; runtime application source remains
`190f5d4079fce3371a410d1c034ed13398cadaaa`. Stage Terms/Privacy
`2026-10-18.v3` and sign-in notice `2026-10-18.v1` are unchanged. Existing Stage
and PROD remain distinct; original checkouts and frozen PH2 were preserved.
