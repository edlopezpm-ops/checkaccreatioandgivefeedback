# Revisión independiente del diff — 2026-10-21

Base: `70612512e2115036fa71a08075a596a04bbff942` (0.8.0).
Objeto: diff del árbol de trabajo de accreatio sobre esa base; no un commit
cerrado ni el artefacto desplegado. La fuente cambió durante la implementación;
se revalidaron los hallazgos afectados tras sus correcciones.

Revisión independiente enfocada en ZIP/contrato de inicio, persistencia,
adjuntos, rutas, entrega/reintento e identidad GitHub/Google. El revisor no
implementó los cambios de producto; añadió únicamente las regresiones de
persistencia autorizadas y este informe. No hizo commit ni despliegue.

## Hallazgos y cierre

Se emitieron siete hallazgos accionables: un P1 y seis P2. Los siete quedan
cerrados en la fuente revisada, con el método de revalidación indicado.

| ID  | Prioridad | Defecto reproducible                                                                                                                                      | Corrección y fuente                                                                                                                                                                                                                                   | Revalidación                                                                                                                                                                                      |
| --- | --------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| D01 | P1        | Un journal antiguo ocultaba un guardado posterior confirmado por IndexedDB cuando fallaba `localStorage.setItem`; la recarga recuperaba el dato viejo.    | Comparación de ambos almacenes por revisión monótona e invalidación del journal obsoleto: `src/draftStore.ts:223–308`.                                                                                                                                | Regresión con fallo de escritura y limpieza del journal: `tests/draftPersistence.test.ts:69–83`; PASS.                                                                                            |
| D02 | P2        | Sin Web Locks, una pestaña obsoleta no podía guardar, pero `clearDraft` sí eliminaba el borrador reciente de otra pestaña.                                | Comparación de revisión antes y después de esperar escrituras y dentro de la transacción de borrado: `src/draftStore.ts:315–358`.                                                                                                                     | Dos contextos aislados y almacenes compartidos: `tests/draftPersistence.test.ts:102–112`; PASS.                                                                                                   |
| D03 | P2        | Un schema futuro sin revisión interpretable podía quedar oculto por el otro almacén v5 y ser sobrescrito.                                                 | Rechazo de versión futura en cada almacén antes de comparar, guardar o borrar: `src/draftStore.ts:22–31`, `223–308`, `315–358`.                                                                                                                       | Caso mixto con schema futuro en cualquiera de los almacenes: `tests/draftPersistence.test.ts:135–151`; RED conservado y PASS posterior.                                                           |
| D04 | P2        | Recargar desde Opciones avanzadas sustituía la posición `team` por `review`, aunque la pantalla seguía soportada.                                         | El catálogo de restauración recibe la pregunta guardada como posición actual: `src/App.tsx:657–661`.                                                                                                                                                  | Lectura de la corrección y del catálogo `guidedQuestions`; el walkthrough de navegador corresponde a la verificación integrada.                                                                   |
| D05 | P2        | Volver de un artículo a la lista del Blog dejaba título, descripción y canonical del artículo anterior.                                                   | El efecto restablece los metadatos de la lista cuando no existe artículo seleccionado: `src/components/BlogExperience.tsx:376–399`.                                                                                                                   | Lectura del efecto y sus dependencias finales; navegación real a cargo de la verificación integrada.                                                                                              |
| D06 | P2        | Sesiones nuevas con `verification_action=NULL` o verificaciones sin acción permitían controles de datos/borrado sin una comprobación ligada a esa acción. | Acción obligatoria para `account_access` y coincidencia exacta para datos, borrado y proveedor que se conecta: `functions/_lib/auth/oidc.ts:552–565`, `functions/_lib/auth/oidc-store.ts:74–76`, `functions/_lib/accounts.ts:838–846`, `951`, `1029`. | Suite `githubIdentity`: 10/10 PASS; incluye rechazo de datos con sesión de sign-in nueva y rechazo de borrado tras prueba para datos (`tests/githubIdentity.test.ts:384–445`, `852` en adelante). |
| D07 | P2        | El retorno OAuth por redirección omitía `lang`; la normalización añadía inglés antes de hidratar el borrador e impedía recuperar el español guardado.     | La presencia original de idioma explícito se captura antes de normalizar; la hidratación recupera idioma y URL: `src/App.tsx:340`, `663–668`, `1221`.                                                                                                 | Lectura de la precedencia corregida; la comprobación funcional de redirección e idioma corresponde al walkthrough integrado.                                                                      |

Los rangos indican la fuente consultada al redactar este informe y pueden
desplazarse con el formateo posterior.

## Comandos y evidencia existente

Ejecutados desde la raíz del repositorio en PowerShell:

```powershell
node --import tsx --test tests/draftPersistence.test.ts 2>&1 | Tee-Object -FilePath '.local/logs/readiness-2026-10-21/review-draft-persistence-final.txt'
node --import tsx --test tests/githubIdentity.test.ts 2>&1 | Tee-Object -FilePath '.local/logs/readiness-2026-10-21/review-github-identity-final.txt'
npm.cmd exec -- prettier --write tests/draftPersistence.test.ts
```

Resultados observados: persistencia **6/6 PASS**; identidad **10/10 PASS**;
Prettier no cambió el archivo de regresión. Los procesos de prueba informaron
cero fallos en esos logs; el pipeline de PowerShell no sustituye esa lectura.

Evidencia previa de reproducción conservada en el mismo directorio:

- `review-stale-journal.txt`: guardado nuevo confirmado y recuperación antigua.
- `review-stale-clear-no-locks.txt`: borrado obsoleto reproducido sin Web Locks.
- `review-draft-persistence-mixed-version-red.txt`: fallo previo del caso mixto
  de schema futuro; queda reemplazado como resultado vigente por el log final.

La coordinación informó además una suite final estricta de identidad con
104 pruebas PASS y UI con backend sintético PASS; su referencia de evidencia
es `.local/logs/readiness-2026-10-21/identity-ui-1792595271120`. Esa ejecución
es evidencia integrada del equipo, distinta de las dos ejecuciones propias
enumeradas arriba.

## Límites

Las regresiones de persistencia ejecutan la fuente de producción en contextos
VM aislados y simulan I/O de almacenamiento y migración de dominio. No prueban
IndexedDB nativo, fallos físicos ni sincronización entre dispositivos. Las
pruebas de identidad usan proveedores sintéticos y almacenamiento de prueba;
no demuestran OAuth operativo contra Google o GitHub reales.

No se observó otro hallazgo accionable dentro del alcance revisado. Este
resultado no concede aprobación de release, aceptación de Ed, PASS global de
R01–R12 ni evidencia de preview/producción. La identidad del candidato final,
los recorridos de navegador, los proveedores reales y los gates de despliegue
pertenecen a la matriz integrada de readiness.
