# Security and Data Compliance

## Data inventory

accreatio handles project descriptions, local paths, selected discovery files, agent-role metadata, local execution logs, and optional GitHub account status. The web editorial channel separately handles published post text/metadata and a verified Access identity long enough to authorize and map it to a safe actor label. The UI does not request passwords, payment data, personal identity documents, or service-token secrets.

The separately authorized web account service handles encrypted contact email, opaque account IDs, linked Google issuer/subject, verification provenance, hashed revocable sessions, short sign-in transactions and quota receipts. It does not receive projects or retain user Google access/refresh tokens. OAuth client secrets are protected backend configuration, separate from user credentials and editorial authorization. The [account implementation status](AUTH_ROADMAP.md) distinguishes local controls from hosted acceptance; the [processing inventory and runbook](ACCOUNT_PRIVACY_OPERATIONS.md) define retention, rights, incidents and provider obligations.

The October 20 account-policy increment adds a minimal, versioned authorization receipt after affirmative choices and valid identity/session proof. It is separate from optional tracking and from a scalar notice-version label. The [privacy/tracking baseline](PRIVACY_TRACKING_BASELINE_2026-10-20.md) and [current readiness receipt](APP_READINESS_2026-10-20.md) own its verification and rollout state. Privacy, security and support contact: [aekr@aekr.io](mailto:aekr@aekr.io).

## Processing and retention

- Form data remains in application memory until execution.
- Settings and a 50-entry project ledger are stored in Electron's per-user application-data directory.
- Selected attachments are copied—not moved—to `docs/product/sources/`; originals remain untouched.
- W1 attachment bytes stay transiently in the active page, are omitted from IndexedDB drafts, and enter only a user-requested real ZIP export. Contents are never parsed or uploaded.
- W1 normalizes hostile/path-like names, resolves case-insensitive collisions deterministically, and revalidates metadata against Blob size immediately before ZIP construction.
- `.accreatio/project.json` records provenance without secrets or source paths.
- Project content has no telemetry, analytics, remote logging, hosted AI, or cloud sync. Published editorial posts are intentionally stored in D1; Cloudflare processes the request/authentication/security metadata needed for Pages, Functions, Access, and D1.
- The atmosphere normally combines one deterministic first-party Canvas2D star field with one first-party procedural WebGL nebula canvas and original local vectors/CSS. Reduced-motion, save-data/slow-update, and hidden-page states retain one static star canvas and omit WebGL. Missing, failed, or lost WebGL also omits that canvas while the bounded StarField can remain active unless another constrained state applies. Both layers receive only viewport, time, theme, media-preference, and fine-pointer state—never product text, draft or attachment data, storage, path, bridge/IPC, network, Git, credential, or orchestration state—and issue no runtime request to an image/CDN service.
- GitHub data leaves the machine only when the user explicitly connects through GitHub CLI or enables remote creation.

## Controls

- Electron context isolation, sandbox, and disabled renderer Node integration.
- Narrow allow-listed IPC methods.
- Execution IPC validates a single request envelope before a bounded, process-memory idempotency guard. Duplicate operation IDs cannot repeat side effects in one session, and concurrent equivalent requests coalesce without persisting or logging their payload fingerprint.
- Attachment extension allowlist, 20 files per run, 20 MB per file, and 100 MB per run.
- Attachments are never parsed, rendered, macro-enabled, or executed.
- Fixed Git/GitHub executable names and argument arrays; no shell interpolation.
- Versioned writes (`name (1).ext`) for every potentially colliding output.
- Browser export has the same session-only logical-operation guard around ZIP construction and the single download trigger. Restart/reload clears replay memory; this is not crash recovery.
- Remote repos default private; remote creation performs no push.
- No user GitHub, IDE or AI-provider credentials are stored by accreatio; GitHub CLI owns its authentication in the OS credential store. The separate web backend may use protected operator runtime secrets as documented above.
- Provider diagnostics use only the two compiled descriptors in `shared/providerRegistry.ts`. Electron runs fixed executable/argument probes without a shell, bounds and sanitizes captured output, exposes stable reason codes rather than raw authentication output, and never accepts a provider command through IPC.
- Provider availability is ephemeral. accreatio stores no Claude/Codex credentials or status output, and W1 truthfully reports that a browser cannot inspect local CLI state.
- Funding metadata contains no credential, payment method, billing response, or price lookup. Paid API is disabled; malformed/API funding blocks artifact writes, and desktop runtime preflight rejects paid-profile and legacy monetary keys without fallback.
- Atmospheric pointer handling is passive, presentation-only, and bounded inside the renderer. Fine-pointer input drives subtle parallax across three star depths; coarse input and restricted-motion modes omit that response. The fixed atmosphere root is `aria-hidden`/`pointer-events: none`, so it cannot capture project controls or become a product input surface. The Canvas2D star implementation is owned code over the native browser API and adds no dependency, remote asset, service, or paid cost.
- Every Blog route rejects a missing or invalid Access JWT and independently verifies RS256 signature, fixed issuer, accepted application audience, lifetime, and strict claim shape against the Access team JWKS.
- Human publishing requires the verified email and non-empty subject pair to resolve through the protected human-admin map. Service publishing requires no email, an empty subject, and an allowlisted verified `common_name` from a separately revocable Access service token. Mixed shapes fail closed.
- Publisher identifiers resolve immediately to bounded safe labels. Blog D1 stores no raw email, subject, client ID, JWT, service secret, IP address, project content, attachment, ZIP, local path, browser draft, or optional integration credential. The separate account D1 has the explicit account inventory above; Blog permission does not grant account export or project identity.
- Browser writes require the exact same origin, JSON, a custom header, bounded body/fields, and a UUID idempotency key. D1 access uses prepared statements and explicit columns; returned post content is rendered as React text, not executable HTML or Markdown.
- Web and desktop use separate Vite entry graphs and output directories. Electron loads/packages only `dist-desktop`; a boundary scan rejects Blog text/styles/API paths, PWA/Workbox artifacts, Functions, and D1 material in the desktop artifact.

## Web threat boundaries and release checks

| Risk                                 | Required control and evidence                                                                                                                                                                                                                 |
| ------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Project leakage through tracking     | Local project/attachment processing; no-op optional adapters; self-only script/connect CSP; actual browser/network checks and separate edge-provider inventory.                                                                               |
| Forged or stale authorization        | Two unchecked choices, strict bounded current-version payload and same-origin request; receipt tied to valid proof and database time, without historical backfill.                                                                            |
| Partially completed sign-in          | Atomic account/session/authorization completion; clock-boundary, rollback and revocation tests. A failed session must not leave a fabricated successful authorization.                                                                        |
| Forced agreement to exercise rights  | Fresh existing-account proof through the separate account-access purpose; same provider/account and live session/version, with no admission, resurrection, profile or authorization write. Public support fallback when proof is unavailable. |
| Account/quota reset through deletion | Immediate contact/method/session/authorization removal; only protected bounded quota continuity; atomic server-side admission and compatible recovery.                                                                                        |
| Secret or personal-data logs         | Fixed local error categories; no raw callback URLs, tokens, OTP, IP, claims, bodies or project/contact data. Provider logs and backups have their own unresolved configuration/retention facts.                                               |
| Old cached clients                   | Auth/account APIs bypass offline caching; stale/missing policy authorization fails closed; reviewed PWA upgrade and live source readback.                                                                                                     |

Run `npm.cmd run log -- security:inventory` for an installed CycloneDX SBOM and
dependency audit under a unique ignored `.local/logs/security-*/` directory.
The command fails on high/critical vulnerabilities and retains moderate findings
for assessment. It invokes npm metadata commands during development; it is not
app telemetry, license approval or a complete independent security assessment.
Keep its receipt with full verification and the exact deployed source. Do not
claim that a low advisory count proves absence of vulnerabilities.

## Legal and operational posture

The project workflow follows privacy-by-default, data minimization, purpose limitation, local retention, and user-triggered disclosure principles. The persistent editorial channel is a separate data class with no current edit/delete UI. The processing inventory and dependency checks above address engineering requirements; the current readiness record retains unresolved provider, recovery, rights/incident operations and jurisdiction-specific legal facts. The product is not represented as certified under SOC 2, ISO 27001, GDPR, CCPA, or another regime.
