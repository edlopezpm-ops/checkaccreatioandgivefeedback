# Iceland pearl design

Owner request: 2026-10-22. The public web design now opens in matte Iceland
pearl, independent of the operating-system theme. The existing theme button
also offers a soft charcoal appearance. Typography, page structure and the
procedural nebula are retained.

## Palette and hierarchy

| Role | Pearl default | Soft dark |
| --- | --- | --- |
| Page background | `#e8eae7` | `#242726` |
| Primary reading surface | `#eef0eb` | `#2b2e2c` |
| Bold headings | `#303235` | `#f0f1ed` |
| Body text | `#515852` | `#c5c9c5` |
| Subtext | `#5e655e` | `#b2b9b2` |
| Main action/detail | `#e2232a` | `#e2232a` |

Main actions and the current navigation hairline carry the red accent. Choices,
secondary buttons, selected states, reading surfaces and links use neutral
mineral colors. The owner supplied and selected the official accreatio logo
during this change. Its exact source image, symbol and custom lettering replace
the former orbital artwork on the web. The [branding record](ACCREATIO_BRANDING.md)
preserves the approved original and its provenance. Canonical AEKR artwork and
the accepted footer remain intact.

The owner's exact palette is matte Iceland pearl `#E8EAE7`, charcoal `#303235`
and intense red `#E2232A`. Related neutral shades provide the requested body and
subtext hierarchy. The image source is retained unchanged; the interface tokens
use these exact codes. The light logo retains its supplied pearl texture. The
owner subsequently requested removal of the pale plate on dark surfaces; the
documented native SVG filter now renders those same contours in pearl and red
with a transparent surround. The canonical original remains unchanged.

The owner clarified that the three supplied codes map to background, titles
and accents, and delegated body/subtext selection. The selected pearl-theme
reading values are `#515852` for body text and `#5E655E` for subtext, as already
implemented. This clarification does not change the published assets.

The same nebula field, autonomous motion, density mask, click response and
reduced-motion fallback use pearl, silver and charcoal instead of violet/blue.
Shadows and reading surfaces are subdued for the matte appearance. Existing
font families, type sizes and weight tokens remain unchanged.

The owner accepted this direction and requested a second visual pass on the
same date. The nebula now has broader gas coverage, stronger graphite wisps in
pearl mode and a denser reduced-motion fallback. Reading scrims, interaction
masks and autonomous motion remain intact. Alignment refinements cover the
welcome facts, creation toolbar, expanded team controls, review actions, result
column, About/Terms, cookie dialog and standalone legal navigation/tables.

The browser tab uses the approved symbol through a transparent, theme-aware
favicon at a new versioned URL. Tab titles follow `accreatio | <short section>`
in the active language, including the public legal documents. The Blog header
keeps its existing text layout: only the word **Blog** uses `#E2232A`; no logo is
added to that header, following the owner's final correction.

## Preference and functional boundaries

The active logo SVG embeds a proportionally scaled 631 x 155 derivative of the
supplied crop, sufficient for its 250px maximum display width at 2x density.
The original and full-resolution PNG crops remain intact. Full-resolution crop
duplicates and unused wordmarks are excluded from PWA precaching so the new
identity does not require downloading every archival representation at startup.

The web theme defaults to light without a storage write. Only using the theme
button saves `accreatio:theme` in same-origin localStorage. Storage failure does
not prevent switching themes. Reloads and the standalone legal pages read the
same explicit preference. The cookie inventory documents its purpose and
removal; it contains no account/project data and is not transmitted to the
server. It does not grant account authorization, Terms acceptance or optional
tracking permission.

Account, draft, export, filesystem, Git and provider logic are outside this
visual change. The retained desktop default setting is unchanged; its shared
visual tokens use the new palette. The PWA/browser color, favicons and social
artwork follow the pearl default.

## Preserved prior design

The [pre-change backup](design-backups/2026-10-22-pre-iceland/README.md) was
committed as `236748f` before editing the design. It includes the original
source archive, SHA-256 manifest, public asset metadata and desktop/mobile
screenshots. Restoration is a deliberate visual-file comparison, preserving
current account and security behavior.

## Verification record

The deployment receipt for this change records the exact source revision,
production deployment, local/hosted checks and retained evidence. Checks cover
the existing unit suite, semantic contrast, unchanged typography, web/desktop
builds, packaged executable, guided ZIP creation, theme preference, small
screens, public/account surfaces and canonical AEKR integrity.

The first full verification exposed an automatic default-theme storage write
in the privacy scenario. Persistence was moved to the explicit theme action;
the original privacy storage allowlist was retained.

The default AEKR payload drift check skips its historical missing sibling path.
An additional check against the current `AEKR` sibling found pre-existing
vendored-document drift. `shared/aekrPayload.generated.ts` is unchanged by this
design release; refreshing exported governance content is outside this scope.
The four pinned branding assets also pass comparison against that sibling.
