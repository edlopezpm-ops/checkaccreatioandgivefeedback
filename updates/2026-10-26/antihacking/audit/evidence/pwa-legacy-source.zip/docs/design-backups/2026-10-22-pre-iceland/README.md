# Design preserved before the Iceland pearl palette

Owner request: 2026-10-22. Source revision: `1b4b6f2` on
`codex/readiness-2026-10-21`. The tracked tree was clean before this backup;
pre-existing untracked review documents are outside this archive.

`design-source.zip` is a Git archive of the original `src/`, `public/`, web and
desktop HTML, Vite configuration, package manifest, theme/shell tests and web
brand generator. It preserves the typography, procedural nebula, styles, logo
artwork and original visual behavior without credentials or local account data.
`manifest.json` records the SHA-256 and size of every retained backup file.

`before-desktop.png` (1440 x 1000 viewport) and `before-mobile.png` (390 x 844
viewport) capture the anonymous public welcome screen at `https://accreatio.com/`.
`public-before.json` records public asset URLs and the computed theme/font.
The production deployment at capture was
`238ee6ee-e44b-4386-bb0a-290a807a8588`, source `a16c53d`.

To recover the design, extract the ZIP into a separate directory, compare the
needed visual files, and restore those files deliberately. Keep current account,
draft, export and security behavior when reusing an older visual design. This
backup covers source and anonymous visual evidence; it is not a database or
credential backup. Original AEKR assets remain pinned and unchanged.
