# Archive, local artifacts and email-account preview

**Historical account release:** [Own email OTP](OWN_EMAIL_OTP_2026-09-05.md) supersedes the Access product identity, 50-account cap, legacy sessions and previous transport assumptions below. Current code uses application-owned email verification and retains the existing rolling allowance and account identity continuity. The linked delivery record states actual hosted acceptance and zero-cost sending limits.

**Superseded where conflicting:** the latest owner clarification permits anonymous Blog reading and reserves publishing for administrators. The explicit login, session recovery and public-route correction is documented in [PUBLIC_SIGNIN_2026-09-05.md](PUBLIC_SIGNIN_2026-09-05.md). Earlier checks below describe their historical candidate.

Owner decisions: 2026-09-05. This candidate implements the cumulative account/quota/UX/test decisions in [the active roadmap](AUTH_ROADMAP.md). Production activation and actual hosted human sign-in are separate acceptance steps.

## Repository housekeeping

- 74 historical documents retained under `docs/archive/2026-09-05/`; the manifest binds original and resulting SHA-256 values. References were relocated and hash-bound payloads are protected from Git newline conversion.
- 76 root logs moved to `.local/logs/legacy-20260905/`, verified by SHA-256. Root log count: zero. Future logs/caches use [the local-artifact standard](LOCAL_ARTIFACTS.md), including the package-script logging wrapper, Vite, Functions build, Lighthouse and new browser captures.
- 160 desktop-package files, 1,466,479,248 logical bytes, retained in sibling `accreatio-archive/2026-09-05/`. This reduces checkout contents, not Git history or total disk usage. Packages were moved, not deleted or compressed.
- AEKR standard committed separately as `45fb186` on `chore/local-artifacts-standard`; 74 validator tests pass and the required fresh-context parent audit returned `PASS_WITH_OBSERVATIONS` with no Blocker/Major/Minor. No frozen P04/runtime work was invoked.

## Implemented account boundary

Existing managed Cloudflare Access email OTP supplies a signed human identity. Every account request verifies signature, issuer, audience and lifetime. The application stores only email as a profile field, plus opaque identity/account metadata, hashed revocable 24-hour sessions and export receipts in a separate D1 database. Session cookies are Secure/HttpOnly/SameSite=Strict; writes require the exact origin. Project data never enters account requests. No passwords or codes are stored by accreatio.

A conditional SQL write admits at most five new operations per account in a rolling 24 hours. Same-operation retries have a 48-hour recovery window. ZIPs remain local; authorization is counted when accepted, not when the browser confirms a save. Modified clients can produce local files. The fifth authorization shows thank-you/next availability, with draft editing and in-memory ZIP retry. Logout revokes the app token; deletion removes email and sessions while preserving active allowance through a protected identifier. Cleanup is bounded and opportunistic, not an exact physical-deletion deadline.

Application capacity is independently capped at 50 identities. This is a protected beta, not a public email-delivery deployment or a claim of billion-user capacity. No paid service was enabled and no email/contact copy was sent. Owner email extraction is paginated JSON with an additional, independent `ACCOUNT_EMAIL_ADMINS` allowlist; it remains disabled until that owner identity is configured.

## Verification

- `npm.cmd run log -- verify`: PASS, log `.local/logs/2026-09-05T18-09-36-539Z-verify-7c43a1a0-47c5-4baa-975b-99a9629940cc.log`. 235 tests, branding, Blog seed, project map, generated Cloudflare types, typecheck, formatting, Functions compilation, both builds, web/desktop surface boundary, Electron privileged smoke, project-map browser smoke, web functional smoke, account UI/real SQLite integration, Lighthouse.
- Browser evidence: `.local/logs/account-ui-1788631856583/receipt.json`, screenshots at 320/390/1280 pixels. Five real browser downloads, same-ZIP retry without a sixth receipt, reload exhaustion, draft retention and secure cookie flags. Access signatures in this test are synthetic fixtures; this is not evidence of live email delivery.
- Lighthouse: performance 95, accessibility 100, best practices 96. SEO 66 retains the existing explicit restricted-beta `noindex` exception.
- Remote preview D1: six concurrent executions of the production admission SQL inserted exactly five receipts. Synthetic identity and receipts were removed; follow-up counts were both zero. No real account data or email was used.
- The ordinary vendor check skips its obsolete default sibling path. Explicit comparison to current AEKR reports upstream drift. A separate read-only comparison verified all eight embedded texts against their declared source revision `efbda75a5ec63d05ca44ffe8913a39d3f5610c21`; this change deliberately does not update the generated project's governance payload.
- Final copy-only corrections rebuilt the web bundle. Desktop releases remain frozen; no new executable was packaged or published.

## Hosted scope

Only preview has `ACCOUNT_DB`, `ACCOUNT_ENABLED`, Access issuer/audience and a protected identity key. Database: `accreatio-accounts-preview`, migration `migrations-auth/0001_accounts.sql`. Production bindings/deployment remain unchanged. Preview Blog administrator configuration remains fail-closed, as before. Actual OTP delivery, owner login and owner email-export permission require hosted acceptance before production promotion.

Rollback: retain the existing production deployment. For a preview service stop, set preview `ACCOUNT_ENABLED=false`; authorization fails closed while local draft editing remains available. Never rotate `ACCOUNT_IDENTITY_KEY` casually: it binds deletion/re-registration quota continuity. Do not promote this candidate to production without a separate production account database and verified identity configuration.

## Deployment record

The initial preview `2e451918-dbdc-427a-955f-af9514c24b9f` (`https://2e451918.accreatio.pages.dev`, source `31a12d6edf20f92ce0e017b6c193a93d37652fc2`) is retained as historical evidence. Eight anonymous probes redirected to Access, but post-deploy metadata showed that Wrangler had omitted dashboard-only plain variables; account endpoints would fail closed. The replacement defines the three plain variables in `[env.preview.vars]`, preserving the secret key, and regenerated types/typecheck pass. This initial preview is not accepted for account testing.

The corrected candidate is deployed at [the protected review preview](https://archive-email-auth-preview.accreatio.pages.dev), immutable URL `https://af1f6b16.accreatio.pages.dev`, deployment `af1f6b16-966a-4d75-a66e-322c15e1f609`, source `db5c6c8c841175d6b3db4d4236448fa542cacf54`. API readback confirms successful preview status, all three plain account variables, the configured secret and both separate database bindings. All eight anonymous probes across the immutable URL and alias redirect to the expected Access issuer. Production remains `11235c8c-108f-46f3-8cce-fb88a144330b`. Ready for owner testing; actual human OTP sign-in and end-to-end hosted account acceptance are not yet claimed.

## Superseding owner correction

The [central sign-in correction](SIGNIN_FLOW_2026-09-05.md) supersedes this candidate's permissive creator access and rollback statement about editing without account verification. It requires a valid session before mounting the creator and reserves all Blog use for administrators. Earlier behavior above remains historical evidence.
