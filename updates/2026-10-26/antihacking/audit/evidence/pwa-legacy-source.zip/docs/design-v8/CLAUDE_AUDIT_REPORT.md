# Claude AEKR Audit Report — accreatio @ ad90feecd048b562bebebb616cfc759af534904e

## Audit Metadata

- **Exact commit audited:** `ad90feecd048b562bebebb616cfc759af534904e` (branch `main`)
- **Working tree state at audit time:** clean; `git diff --stat HEAD` empty for all tracked files
- **Untracked files present but explicitly out of scope:** `docs/archive/2026-09-05/CURSOR_UX_AUDIT.md`, `core.4360`, `core.43716`, `core.5730`, `core.798609` (none opened or relied upon)
- **Audit date:** 2026-08-06
- **Auditor:** Claude, fresh context, no prior authorship of this design
- **AEKR provenance trail:** `MASTER_SOP.md` → `project-lifecycle/SOP.md` → `docs-governance/audit-checklist-template.md` → `project-map-standard.md`
- **Mandate:** `docs/design-v8/DESIGN.md:213-219` and `docs/W1_RELEASE_READINESS.md` item 6 — *“In a fresh context, have Claude compare all current code/configuration with all current documentation and the canonical map at that pushed commit. Claude reports only.”*
- **Canonical Project Map:** `PROJECT_MAP.md` / `project-map.json` / `project-map.html` (JSON wins on disagreement, per `project-map-standard.md`)
- **Current design canon:** `docs/design-v8/DESIGN.md` (supersedes v2–v7, which were read as history only, not as current-behavior requirements)

## Scope and Method

All tracked code and configuration at this exact commit were compared against all tracked documentation and the canonical Project Map. Historical design docs (`docs/design-v2` … `docs/design-v7`) were read for context only. Verification combined prior research (parallel exploration of the auth path, storage/DB boundary, and CI/build chain) with direct spot-checks in this pass against the tracked repository: `DECISIONS.md` (DEC-016/DEC-017 supersession note and the 2026-08-06 restricted-beta decision), `wrangler.toml` D1 bindings, `content/blog/founding-posts.json`, `package.json`'s `verify` script, and `.github/workflows/ci.yml`. This is a report-only exercise; no files were edited and no deployment or infrastructure action was taken.

## Verdict

**PASS_WITH_OBSERVATIONS**

No Blocker, Major, or Minor findings survived verification. The one Major issue on record from prior design-cycle audits — the founding-post's “never phones home, no backend” claim contradicting the 0.8.0 Blog architecture — is resolved in this commit via an explicit self-correcting edit in the post body itself. Two Observations are noted; both reflect deliberate, documented design choices rather than gaps.

## Findings Table

| # | Severity | Area | Summary |
|---|----------|------|---------|
| 1 | OBSERVATION | Auth boundary | Draft/project-data paths have no in-app auth check; the access boundary is enforced at the Cloudflare Access edge layer, outside the repository, by design. |
| 2 | OBSERVATION | Zero-cost boundary | No CI/static check enforces zero-cost operation; it is documented as a manual provisioning-time gate (“if provisioning requires a paid plan, rollout stops before charge”), not a code-checkable invariant. |

No Blocker, Major, or Minor findings.

## Confirmed Parity (with file evidence)

1. **Local-first ephemeral project data** — `src/draftStore.ts` (IndexedDB `accreatio-drafts`/`drafts`; `localStorage` for onboarding) matches `README.md:3`, `WEB_ARCHITECTURE.md:7-9`, `PRIVACY_POLICY.md:23`.
2. **Separate D1 editorial Blog, isolated from project data** — `wrangler.toml:11-25` defines exactly one D1 binding (`BLOG_DB` → `accreatio-blog`, with a `accreatio-blog-preview` variant under `env.preview`); no other database binding exists. Matches `WEB_ARCHITECTURE.md` and `DECISIONS.md` DEC-016.
3. **Access JWT verification, human vs. service identity** — `functions/_lib/access.ts` implements RS256 verification against Access's own JWKS plus issuer/audience/exp/iat/nbf checks, and distinguishes human (`email`+`sub`) from agent/service (`common_name`, empty `sub`) claim shapes; `authorizePublisher` checks separate `BLOG_HUMAN_ADMINS`/`BLOG_AGENT_ADMINS` allowlists. Matches `docs/design-v8/DESIGN.md:89-122` and `docs/SECURITY.md`, and is restated in the founding-post body itself (`content/blog/founding-posts.json:27`: “checks the RS256 signature against Access's own JWKS, checks the token's issuer and audience... never from the mere presence of an Access-shaped header”).
4. **Web-only Blog, hard Electron exclusion** — dual Vite entry graphs (`main.web.tsx` imports `BlogExperience`; `main.desktop.tsx` does not), `electron-builder`'s packaged `files` limited to `dist-desktop/**/*`, and `scripts/surface-boundary-smoke.mjs` (wired into `verify` as `test:surface`) actively asserts Blog markers are absent from the desktop bundle and present in the web bundle — exceeding the doc claims in rigor.
5. **Founding-post fidelity, prior contradiction resolved** — `content/blog/founding-posts.json` contains all three posts (Codex, Claude, Ed Lopez). The Claude post (line 27) explicitly self-corrects the earlier “never phones home, no backend” claim: *“The previous edition of this post said the app never phones home and had no backend — true of that architecture, false of this one, and worth correcting outright rather than quietly editing away.”* `scripts/generate-blog-seed.mjs` plus `blog:seed:check` in `verify` enforces fixture↔migration parity.
6. **CI / verify chain matches documented behavior** — `.github/workflows/ci.yml` runs `npm ci` → `npm audit --audit-level=high` → Playwright chromium install → `npm run verify` → uploads `lighthouse-report/`. `package.json:32`'s `verify` script chains exactly what the docs describe: unit tests, blog seed check, project-map check, Cloudflare types check, typecheck, format check, functions build, web+desktop build, surface/electron/project-map/web smoke tests, and lighthouse. No separate automated deploy job exists, and no doc claims one — deployment is documented as a manual, owner-authenticated Wrangler CLI sequence (`docs/W1_RELEASE_READINESS.md`; also `DECISIONS.md`'s 2026-08-06 restricted-beta entry: “Cloudflare Pages Direct Upload may create/deploy the static W1 project through an owner-authenticated Wrangler session... only after the Full release gates pass”).
7. **Honest framing of pending vs. completed hosted acceptance** — `docs/W1_RELEASE_READINESS.md`'s Hosted Acceptance table is conditionally worded (several rows explicitly “or remains pending”), and historical 0.7.0 evidence is explicitly marked as not proving 0.8.0 status. `tests/webRelease.test.ts` CI-enforces the presence of these exact doc strings. Nothing in the tracked repository claims 0.8.0 is deployed or accepted.

## Residual Hosted Gates (out of scope for this audit)

Per `docs/W1_RELEASE_READINESS.md` and `DECISIONS.md`, the following remain open and cannot be closed by a static, report-only repository audit:

- Production data migration and exact-commit hosted deployment verification.
- Final publisher allowlist configuration (`BLOG_HUMAN_ADMINS`/`BLOG_AGENT_ADMINS`) on the live environment.
- Owner-authenticated hosted UX/header/offline/network/Lighthouse acceptance against the live origin.
- A real, allowlisted AEKR service-token exercise of the publish path against the deployed environment.
- Anonymous-access fail-closed probes and Access-policy drift checks against the live `*.pages.dev` origin.

These require live deployment and out-of-repository credentials; they are explicitly deferred to hosted acceptance procedures, not repository state.

## Statement of No Changes

No repository files were created, edited, or deleted as part of this audit, and no external state (deployment, infrastructure, credentials, or hosted environment) was accessed or modified. All verification was performed via read-only inspection (`Read`, `Grep`, `Bash` read-only commands) of the tracked repository at commit `ad90feecd048b562bebebb616cfc759af534904e`.
