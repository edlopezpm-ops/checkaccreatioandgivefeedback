# Web-only Editorial Publishing and Desktop Boundary

Owner change request: Ed Lopez, 2026-08-06. Existing project, AEKR Full
profile, mixed route: local-first project creation plus a zero-cost
Cloudflare-managed editorial service. The prior Full authorization and the
owner's instruction to continue authorize this bounded redesign, its
implementation, commit/push, and deployment only after the fresh design gate
and repository gates pass.

## Outcome

Release `0.8.0` adds a **Blog** to the authenticated web portal and lets
authorized portal administrators publish plain-text posts from that web
surface. The initial three posts and authorship contract from design v7 remain
unchanged. The accepted product definition remains:

> accreatio is an authenticated, local-first, ephemeral-session web application
> for creating and exporting projects.

Editorial persistence is a separate data class. A published Blog post is
portal content, not a user project, project attachment, local draft, provider
credential, or integration session. accreatio still does not upload or store
user project content or project files on an accreatio-operated server and does
not retain GitHub, IDE, or AI-provider credentials.

The Blog and every publishing capability are **web-only**. The Electron desktop
application keeps its existing project-creation behavior and navigation. Its
production bundle and package contain no Blog content, Blog styles, editor,
admin API client, PWA manifest, service worker, or Cloudflare Function code.

## Content contract

The three founding posts remain version-controlled editorial content in the
order specified by design v7:

1. **Introducing accreatio** — Codex/OpenAI technology attribution, four
   paragraphs, exact signature `Made with AI - Codex AEKR mode.`
2. **Nebula made ideas for accreatio** — revised after this architecture change
   by a real Claude/Anthropic agent, in two or three paragraphs, with exact
   signature `Made with AI — Claude AEKR mode.` The earlier static-edition text
   is superseded because its “never phones home” and “no application backend”
   claims would be false once Blog reads/publishing use Pages Functions and D1.
   The revision must accurately distinguish the server-side editorial channel
   from local-first project data, explain the hard web/Electron split, retain
   accurate OpenAI/Anthropic non-endorsement language, and remain Claude's own
   prose; Codex may request factual correction but may not silently rewrite or
   misattribute it.
3. **A small paradox, but a paradox after all.** — Ed Lopez's faithful second
   complete Word version, signed `Ed Lopez`.

The owner-supplied Word file stays only in the ignored `.aekr/sources/`
boundary. It is not committed, deployed, or packaged with either application.
A reviewed structured fixture under `content/blog/` becomes the canonical
versioned transcription. A deterministic generator produces an idempotent D1
seed migration from that fixture, and a repository check rejects drift between
them.

D1 is the Blog's single runtime content source. The founding posts are seeded
there before the first deploy; newly published posts use the same table and are
returned newest first. The UI does not merge a bundled duplicate or silently
serve stale editorial text. If the API is unavailable, it shows a clear
temporarily unavailable state and never pretends a failed read or publish
succeeded. Blog posts are online portal content and are not promised for
offline use; project creation/export keeps its existing local-first behavior.

## Web administration experience

- The Blog requests an administrative session capability from the same-origin
  API. The composer is rendered only when that response says the verified
  actor may publish. Hiding the composer is presentation, never authorization.
- The composer holds an unpublished draft in page memory only. It captures
  title, short summary, body, language, display author, and signature. Body
  paragraphs are separated by blank lines and are rendered as React text; HTML
  and Markdown execution are not supported.
- Publishing requires a deliberate confirmation and a successful API response.
  The returned post is inserted into the live list without a reload. Errors
  preserve the in-memory draft and are announced accessibly.
- This increment is append-only: administrators can create published posts but
  cannot edit, delete, schedule, upload media, or backdate them. Those actions
  need a later decision and audit trail design.
- Human administrators use the web composer. Authorized AEKR automation uses
  the same HTTPS publication endpoint with a Cloudflare Access service token;
  service credentials are never embedded in the browser, source, D1, logs, or
  documentation. Agents may prepare content for the human form or publish via
  that endpoint when separately issued a revocable service credential.

## Authentication and authorization

Cloudflare Access remains the authentication perimeter, but the Pages Function
does not trust the presence of an Access-looking header. Every Blog API route:

1. requires `Cf-Access-Jwt-Assertion`;
2. validates its RS256 signature against the configured Access team JWKS;
3. validates the fixed issuer and application audience; and
4. derives the actor only from the verified token payload.

Human publish authorization requires both the normalized verified `email` and
non-empty `sub` claims to match one entry in the encrypted
`BLOG_HUMAN_ADMINS` map. Agent publish authorization requires the verified
service-token `common_name`, an empty `sub`, and no email claim to match one
entry in the encrypted `BLOG_AGENT_ADMINS` map. Each map resolves the sensitive
identifier immediately to a safe audit label such as `ed`, `codex-aekr`, or
`claude-aekr`; raw identifiers are neither logged nor stored. Mixed or unknown
claim shapes are denied. Read routes require a valid Access application token
while the whole beta remains protected. Publish routes fail closed when
configuration, token validation, allowlists, or D1 are absent.

Browser publication additionally requires same-origin `Origin`, method
`POST`, `application/json`, and the documented custom request header.
Service-authenticated agents may omit `Origin` but must have an allowlisted
`common_name`. Every publish requires a UUID `Idempotency-Key`; a retry by the
same safe actor returns the original result instead of creating a duplicate.
Payload bytes, field counts, and field lengths are bounded before database
access. The server creates the ID, slug, actor audit fields, and timestamps. No
supplied HTML is interpreted.

The fixed Access issuer, accepted audience set, human admin map, and agent admin
map are encrypted Pages secrets or protected variables, never literals in Git.
Production and preview may use distinct Access audience sets. Service client
secrets remain solely in the administrator's secret store.
Adding an agent requires both a revocable Cloudflare service token/Service Auth
policy and the corresponding verified client ID in the server allowlist.

## Editorial persistence and API

Cloudflare Pages Functions provide three same-origin routes:

- `GET /api/blog/posts` — returns only published D1 posts;
- `GET /api/admin/blog/session` — returns the minimum capability response
  (`canPublish`, actor kind, safe display label); and
- `POST /api/admin/blog/posts` — validates, authorizes, inserts, and returns
  one new published post.

A free-tier Cloudflare D1 database is bound as `BLOG_DB`. Production and
preview use separate database IDs so preview/auth tests cannot write production;
ordinary local development uses Wrangler's local persisted simulation.
Migration-controlled schema stores post ID, unique slug, title, summary, JSON
paragraph array, language, display author, signature, publish/create
timestamps, verified actor kind, safe actor label, and idempotency key. It
stores no project data, attachments, integration tokens, browser drafts, IP
addresses, emails, Access subjects/client IDs, or Access JWTs.
The API selects explicit columns and uses prepared statements. Responses use
JSON, `Cache-Control: no-store`, content-type protection, and explicit error
handling; operational logs contain route/status/error class but no post bodies,
tokens, emails, or credential values.

D1 and Pages Functions must stay within Cloudflare's free plan. If provisioning
or use requires a paid plan, the rollout stops before creating a charge. The
database and Functions do not change the guarantee that project ZIP creation
works without GitHub, IDE, or AI-provider connections.

## Hard web/desktop separation

Vite produces two auditable renderer graphs:

- web: `index.html` -> web entry -> `dist/`, with Blog, admin client/styles,
  PWA, and normal web behavior;
- desktop: `desktop.html` -> desktop entry -> `dist-desktop/`, without Blog,
  admin client/styles, or PWA registration.

Shared `App` receives the optional editorial destination from the web entry; it
does not import the Blog module. The desktop entry supplies no editorial
destination. Electron loads `dist-desktop/desktop.html`, and electron-builder
packages `dist-desktop/**/*` instead of `dist/**/*`. Cloudflare `functions/`,
D1 migrations, Wrangler configuration, and web output are outside the desktop
package allowlist.

Development commands select the intended entry explicitly. The surface
boundary is enforced after build by scanning the complete desktop output for
founding titles, Blog/editor markers, API paths, PWA manifest/service-worker,
and Workbox artifacts; the web output must contain the Blog/editor UI markers,
while the reviewed fixture and generated seed remain outside both renderer
outputs.

## Privacy and product language

“Ephemeral-session” describes accreatio's server-side project and optional
external-integration state, not its deliberate device-local IndexedDB draft and
not administrator-authored editorial posts. One browser draft may persist on
the user's device; attachment bytes remain tab-only. Editorial posts persist in
D1 until a later governed retention/deletion operation.

Cloudflare may process the request, identity, cookie, IP, timestamp, and
security metadata required by Pages, Functions, Access, and D1. The privacy,
security, FAQ, architecture, SOP, README, decision, change, risk, and canonical
map documents must distinguish that infrastructure/editorial processing from
project-content locality and must not claim that the web host has no backend or
no server-side data of any kind.

The visible AI editorial note still states that OpenAI and Anthropic supply the
technology but are not the corporate authors, sponsors, or endorsers. AEKR is
described holistically as the collaboration method, without copying private
handbook content or implying certification.

## Validation and audit philosophy

The prior red/green Blog source contract remains evidence. New red/green tests
cover API token requirements, human and service authorization, wrong
issuer/audience, same-origin browser writes, bounded input, injection-safe text,
D1 failures, successful append-only insertion, live/fallback client states, and
the admin composer's accessible publish flow.

Local gates include unit/source tests, generated Worker binding types,
Function typecheck, formatting, both production builds, Project Map parity,
desktop artifact-boundary scan, Electron UI absence of Blog/Admin, web browser
Blog reading/publishing with intercepted authorized and denied API responses,
dark/light responsive visual inspection, no horizontal overflow, dependency
audit, and the existing full verification suite. Local D1 migrations run before
remote migration. No production write smoke creates a throwaway public post;
hosted acceptance uses read/session checks and the owner may publish the first
new live post deliberately through the UI.

After implementation, Codex commits and pushes the exact candidate. A fresh
Claude context then audits that pushed commit of this repository only, comparing
all current code/configuration with all current documentation and the canonical
map. Claude reports gaps without editing or implementing. Historical reports
are treated as historical evidence, not current requirements. Any accepted
documentation-only reconciliation is committed and pushed before deployment;
code findings reopen implementation and re-validation.

## Release and rollback

Before any external mutation, anonymous stable and immutable-origin probes must
still fail closed. Provisioning order is: confirm free plan and authenticated
account, download/reconcile current Pages configuration, create D1, commit its
binding and migration, apply the migration remotely, set required encrypted
variables, configure the narrowly scoped agent Service Auth policy/token only
if it can be done without weakening the human Allow policy, then deploy the
exact final commit with Wrangler so the root `functions/` directory is included.

Post-deploy checks cover anonymous denial, valid owner session, Blog founding
and D1 reads, admin capability, response/security headers, absence of
unexpected egress, desktop-boundary artifact evidence, and the existing minimal
project ZIP flow. If an owner-authenticated check cannot run, technical deploy
success may be recorded but hosted acceptance remains pending. Agent publishing
is not claimed active until both Service Auth and a real allowlisted agent token
are verified.

Source rollback returns to
`0dbbefd03305e56af2e4febbf129d64fcdc064c2` (`0.7.0`). Cloudflare rollback
restores the previous known-good Pages deployment while Access remains in
place. The D1 database is preserved for recovery rather than destructively
deleted; the rolled-back application has no binding or route to it. Any Service
Auth policy/token created for this increment is disabled or revoked during
rollback without altering the owner's human access policy.
