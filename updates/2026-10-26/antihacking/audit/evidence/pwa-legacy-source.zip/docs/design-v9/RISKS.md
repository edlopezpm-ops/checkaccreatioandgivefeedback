# Design v9 risk register

**Status:** Proposed. Root `RISKS.md` is updated only for accepted new/changed
project risks; this register also tracks design-stage risks.

| ID | Risk | Probability | Impact | Mitigation / rollback | Owner | Closed |
|---|---|---:|---:|---|---|:---:|
| V9-R01 | Human identity or session material leaks while obtaining `user_uuid` | Low | Critical | HOE-only local endpoint use; share only sanitized capability; rollback map to `{}` and invalidate exposed session | HOE/Security | false |
| V9-R02 | Service Auth broadens or replaces human access | Low | Critical | Separate exact-token Service Auth; reject Bypass/Any token; rollback policy/map/token only | HOE/Security | false |
| V9-R03 | Access email OTP is mistaken for open safe registration | Medium | High | Explicit invitations; reject all-valid-email policy; public accounts need new gate | Product/Security | false |
| V9-R04 | Account scope creeps into SaaS multi-tenancy and persistent project data | Medium | Critical | Separate product decision; keep ZIP/local-first and no account rows in beta | HOE/Product | false |
| V9-R05 | GitHub web token/private key is exposed or retained | Medium | Critical | GitHub App, protected narrow backend, short operation memory, no refresh token, revoke and ZIP fallback | Security/Engineering | false |
| V9-R06 | Partial GitHub mutation leaves confusing repo state | Medium | High | Empty private repo only, idempotent step ledger, no auto-delete/force, report repo URL, ZIP | Engineering | false |
| V9-R07 | “Connect ChatGPT/Claude” misrepresents consumer subscription capability | High | High | No such promise; manual prompt copy/no-AI; official provider boundary | Product | false |
| V9-R08 | AI/SMS/Codespaces/Actions/signing silently incurs cost | Medium | Critical | Preflight entitlement/budget; no auto-recharge; stop before charge; local alternatives | HOE/Release | false |
| V9-R09 | D1 Time Travel retention is mistaken for durable backup | Medium | High | Seven-day Free retention documented; encrypted export rotation and drills | HOE/Engineering | false |
| V9-R10 | D1 restore overwrites correct data | Low | Critical | Pre-restore export/bookmark, preview rehearsal, explicit UTC target, previous-bookmark undo | HOE/Engineering | false |
| V9-R11 | Editorial correction/delete destroys history or exceeds agent authority | Medium | High | Immutable revisions, reversible withdrawal, human-only destructive action, hard-delete gate | HOE/Legal | false |
| V9-R12 | Three/Vanta lazy chunk harms first load or fails after update | High | Medium | Enforced budgets, dynamic boundary, static fallback, import-error handling, rollback | Engineering/Test | false |
| V9-R13 | Visual preservation conflicts with motion/accessibility/battery | Medium | High | Reduced-motion/save-data/hidden/WebGL fallbacks; metric and visual gate | Design/Test | false |
| V9-R14 | Windows package evidence comes from unsuitable host or spends Actions overage | Medium | High | Owned Windows primary; exact host evidence; check minutes before hosted runner | Release | false |
| V9-R15 | Unsigned Windows package is promoted as broadly safe/trusted | Medium | High | Private limited distribution, truthful warning; paid signing requires explicit cost change | HOE/Release | false |
| V9-R16 | Provider UI/price/token assumptions age before execution | High | High | U1 30-day expiry, official changelog/source preflight, stop on mismatch | Implementer/Auditor | false |

## Stop conditions

Any credential/identity disclosure, anonymous portal access, project-data egress,
unexpected canonical deployment, destructive restore ambiguity, broad auth rule,
or paid prompt stops the future micro-sprint. Stopping preserves evidence and
does not authorize compensating deployment/mutation.

