# Design v9 handoff

**Status:** Independent design audit PASS; Blocked pending explicit HOE decisions
and implementation GO.

## Start here

Read only:

1. the owner master prompt;
2. the latest Sprint D3 memory capsule in `SPRINT_LEDGER.md`;
3. `DESIGN.md`, `ROADMAP.md`, and the document/SOP for the selected micro-sprint;
4. U1 official sources used by that micro-sprint, reopened on execution date.

Do not reload historical design v2–v7 or re-audit the accepted implementation.

## First future execution micro-sprint

**R0.1 — Human publisher configuration.** It is governed by
`BLOCKER_RESOLUTION_DESIGN.md` D1.1 and `HOE_SOPS.md` H-01.

### Inputs

- Independent design verdict and reconciled final commit.
- Explicit HOE GO naming production or preview.
- Decision whether to activate before a real post is ready.
- Current official Cloudflare identity/Pages-secret documentation.
- Owner baseline: anonymous denial and empty/fail-closed map.

### Roles

- HOE performs authenticated identity/configuration actions and retains all
  sensitive material.
- Implementer/agent supplies checklist and interprets only sanitized evidence.
- Independent auditor is a fresh context and is not the implementer/design
  author. No self-review may be called independent.

### Exit criteria

Owner session reports `canPublish:true` with safe label; non-admin is false when
available; anonymous remains denied; no raw identity/session evidence; no post,
deployment, code, D1, or variable other than `BLOG_HUMAN_ADMINS` changed;
rollback to `{}` has a reviewed procedure. Live rollback is not required by
R0.1 and needs a separate explicit mutation GO. Failure leaves the map empty/
fail-closed.

## Dependency locks

- R0.2 acceptance follows R0.1 or an explicit publisher defer.
- R0.3 Service Auth follows human-path confirmation and agent/duration decisions.
- Editorial mutation follows backup/recovery design acceptance.
- GitHub implementation follows transient-backend and exact permission decisions.
- Public accounts, paid AI, SMS, signing, anonymous access, and custom domain are
  not authorized by this handoff.

## Safe evidence contract

Return only safe labels, booleans, counts, status/header values, timestamps,
opaque IDs/SHA where required, and sanitized issue descriptions. Never return
cookie, JWT, OTP, secret, token, API key, email map, full identity, HAR, project
content, attachment, ZIP, private backup, or credential-bearing command output.

## Rollback authority

Each SOP's rollback is bounded to the value/policy/token it creates. It never
authorizes deployment, D1 deletion, source reset, broad policy change, or
compensating external mutation. Stop and request HOE direction if the observed
state falls outside the SOP.
