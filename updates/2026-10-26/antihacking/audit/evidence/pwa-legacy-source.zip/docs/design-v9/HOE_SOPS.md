# HOE standard operating procedures

**Status:** Proposed; do not execute without the independent design gate and
explicit HOE GO.
**HOE:** Ed Lopez
**Source consultation:** 2026-08-06

## H-01 — Configure the human Blog publisher

1. **Objective.** Set only Ed's email+Access user ID allowlist entry and verify
   capability without publishing.
2. **Why HOE.** The operation uses Ed's authenticated browser and protected
   Cloudflare configuration; an agent must not receive the session or identity
   payload.
3. **Prerequisites.** Independent gate passed; explicit GO; owner can sign in;
   anonymous denial is known good; current protected value is recoverable as
   safe status (never copied to chat); USD 0 remains confirmed.
4. **Official site.** `https://dash.cloudflare.com/`; identity contract:
   `https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/application-token/`.
5. **Current navigation.** Pages project → Settings → Variables and Secrets (the
   exact label is U1 and may change). Identity is obtained locally from the
   documented team-domain `/cdn-cgi/access/get-identity` endpoint.
6. **Safe values.** One-line JSON:
   `{"<lowercase-email>":{"sub":"<user_uuid>","label":"ed"}}`.
7. **Do not change.** Access applications/policies, issuer, audiences, agent
   map, D1 binding, branches, build controls, or deployment.
8. **Never share.** Cookie, JWT, OTP, email+ID map, full identity JSON, browser
   storage, request headers, or Cloudflare credentials.
9. **Actions.** (1) Sign in normally. (2) In local browser DevTools, call the
   documented identity endpoint using the existing browser session; do not
   paste credentials. (3) Read only `user_uuid` locally. (4) Close/clear the
   response view. (5) Construct the JSON locally and validate its keys. (6)
   Open the intended Pages environment's protected variables. (7) Change only
   `BLOG_HUMAN_ADMINS`. (8) Save. (9) Reload portal. (10) Inspect only the
   session API result and confirm `canPublish: true`, actor kind `human`, label
   `ed`. (11) Confirm anonymous denial in a separate private window without
   signing in. (12) Do not publish.
10. **Expected result.** Owner capability true; anonymous still redirected;
    no post or deployment created.
11. **Safe validation.** Report environment, timestamp, `canPublish`, safe
    label, and anonymous HTTP class only.
12. **Safe evidence.** `production human-admin configured; label=ed;
    canPublish=true; anonymous=302; no publish attempted`.
13. **Common errors.** Using JWT `identity_nonce`; adding extra JSON fields;
    copying a display email with whitespace; setting preview instead of
    production; exposing DevTools headers.
14. **Stop conditions.** Paid prompt; unexpected policy/deployment change;
    identity response lacks `user_uuid`; session response contains raw identity;
    anonymous access succeeds; map format is uncertain.
15. **Rollback.** Set only `BLOG_HUMAN_ADMINS` back to `{}`; reload; confirm
    `canPublish: false` and anonymous denial. Preserve D1.
16. **Date/sources.** 2026-08-06; Cloudflare Application token, Validate JWTs,
    Authorization cookie, and Pages dashboard documentation in
    `PROVIDER_RESEARCH.md`. If UI differs, search Cloudflare docs for “Pages
    secrets variables” and do not guess.

## H-02 — Provision and revoke the AEKR Service Auth publisher

1. **Objective.** Create one narrowly scoped, separately revocable service
   identity without affecting human access.
2. **Why HOE.** Cloudflare reveals a Client Secret once; only Ed may handle and
   store it.
3. **Prerequisites.** H-01 accepted or deliberately deferred; explicit choice
   of agent label and duration; secret manager ready; owner and anonymous
   baselines recorded; zero-cost entitlement reconfirmed.
4. **Official site.** `https://dash.cloudflare.com/`; service-token and policy
   documentation linked in `PROVIDER_RESEARCH.md`.
5. **Current navigation.** Zero Trust → Access controls → Service credentials →
   Service Tokens; then Access controls → Applications → accreatio → Policies.
   Labels are U1. Fallback: dashboard search “Service Tokens” and official docs.
6. **Safe values.** Purpose/environment token name; chosen duration; exact-token
   Service Auth Include selector; agent map
   `{"<Client-ID>.access":"codex-aekr"}` (or separately approved label).
7. **Do not change.** Existing human Allow policy, application destinations,
   Bypass, human map, issuer/audience, D1, build controls, or deployment.
8. **Never share.** Client Secret, token headers, JWT, cookie, API token,
   credential-manager record, or full map. Client ID is sensitive operational
   identity and should stay out of chat/evidence unless strictly required.
9. **Actions.** (1) Create one token with approved name/duration. (2) Save Client
   ID/Secret directly into the approved local secret manager; do not place them
   in shell history. (3) Close the one-time secret screen. (4) Add a new policy
   with action `Service Auth`. (5) Include exactly that Service Token. (6) Save
   without editing human Allow. (7) Set only `BLOG_AGENT_ADMINS` to the exact
   Client-ID→safe-label JSON. (8) From an approved local client, make only a GET
   capability request with secret headers injected from the secret manager.
   (9) Confirm safe agent capability and no raw identity. (10) Recheck owner and
   anonymous behavior. (11) Do not POST until a real intended post is approved.
10. **Expected result.** One token can authenticate; safe label is returned;
    human access unchanged; anonymous denied; no post created.
11. **Safe validation.** Status codes, actor kind/label, token expiry date,
    owner access yes/no, anonymous HTTP class. Never command transcripts.
12. **Safe evidence.** `service-auth=<safe-label>; expires=<date>;
    capability=true; owner=unchanged; anonymous=302; write=not attempted`.
13. **Common errors.** Allow instead of Service Auth; `Any Access Service
    Token`; Bypass; putting secret rather than Client ID in map; sharing curl;
    overwriting the human policy.
14. **Stop conditions.** Paid prompt; broad selector; policy replacement;
    secret displayed in logs/history; owner access changes; anonymous succeeds;
    capability requires an undocumented claim.
15. **Rollback.** Disable/remove only new Service Auth policy; set agent map to
    `{}`; revoke token; delete local credential; verify owner/anonymous states.
16. **Date/sources.** 2026-08-06; Cloudflare Service tokens, Access policies,
    Application token, and Account limits. Re-open sources if older than 30 days.

## H-03 — Authenticated portal acceptance

1. **Objective.** Validate the hosted protected portal and local ZIP flow with
   safe, reproducible evidence.
2. **Why HOE.** Login/visual/responsive/browser-network evidence uses Ed's real
   authenticated session and human judgment.
3. **Prerequisites.** Intended configuration complete; no publication needed;
   clean browser profile/private window available; DevTools configured to hide
   sensitive headers; real project content is not used.
4. **Official site.** `https://accreatio.pages.dev`; Access behavior sources in
   `PROVIDER_RESEARCH.md`.
5. **Navigation.** Cloudflare Access login → portal Home/Blog; browser DevTools
   Network and responsive mode. Browser labels vary; use vendor help/search.
6. **Safe values.** A minimal non-sensitive sample project name/description;
   dark/light settings; standard wide and narrow viewport classes.
7. **Do not change.** Provider configuration, D1, posts, policies, variables,
   browser security settings, build/deployment controls.
8. **Never share.** OTP, email, cookies, JWT, request headers containing auth,
   identity payload, IP, project content, attachment, ZIP, or full HAR.
9. **Actions.** (1) Open root and complete Access login. (2) Confirm Home loads.
   (3) Open Blog and count exactly three founding posts; verify titles/order.
   (4) Confirm `/api/blog/posts` is authenticated JSON. (5) Confirm the session
   endpoint returns expected `canPublish` and only safe actor data. (6) Record
   API `Cache-Control: no-store`, `X-Content-Type-Options: nosniff`, and static
   CSP/frame/referrer/permissions/noindex headers without exporting headers.
   (7) Toggle dark/light. (8) Inspect wide/narrow layout, keyboard order, focus,
   announcements, and horizontal overflow. (9) Create a minimal project without
   GitHub/IDE/AI, select no attachments, and request ZIP download. (10) Confirm
   Blog/API traffic contains no project payload. (11) Record request host/path/
   method list only. (12) Sign out using the documented Access logout route and
   confirm protected re-entry requires authentication.

   Header pass/fail contract: API JSON must contain `Cache-Control: no-store`
   and `X-Content-Type-Options: nosniff`. Static responses must contain:

   - `Content-Security-Policy: default-src 'self'; script-src 'self'; style-src
     'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src
     'none'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'`
   - `Referrer-Policy: no-referrer`
   - `X-Content-Type-Options: nosniff`
   - `X-Frame-Options: DENY`
   - `Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(),
     usb=()`
   - `Cross-Origin-Opener-Policy: same-origin`
   - `X-Robots-Tag: noindex, nofollow, noarchive`

   Egress pass/fail contract: application/API/service-worker requests only to
   `https://accreatio.pages.dev`; authentication redirects/requests only to the
   configured `https://<team>.cloudflareaccess.com` learned from the login
   redirect. Ignore browser-internal requests. Any other network host fails the
   gate; use a clean profile with extensions disabled.
10. **Expected result.** All listed surfaces pass; exactly three posts; correct
    capability; ZIP request works locally; expected egress only.
11. **Safe validation.** Checklist booleans, counts, sanitized header values,
    viewport/theme, host/path/method, and issue descriptions without payloads.
12. **Safe evidence.** Fill a local checklist and paste only its sanitized
    summary; screenshots must crop all identity/browser chrome and network data.
13. **Common errors.** Treating cached shell as API success; exporting HAR;
    publishing a test post; using sensitive project text; confusing browser
    download request with confirmed filesystem persistence.
14. **Stop conditions.** Anonymous access; raw identity returned; unexpected
    third-party egress; project data in API; missing security headers; composer
    visible to non-admin; any charge.
15. **Rollback.** No mutation is expected. On critical failure, sign out, stop,
    preserve sanitized evidence, and if publisher authorization is implicated
    execute H-01/H-02 rollback only.
16. **Date/sources.** 2026-08-06; Cloudflare Authorization cookie, Validate JWTs,
    project W1 readiness, and deployed architecture. UI is U1.

## H-04 — Triage CI, Pages `idle`, and historical alerts

1. **Objective.** Classify operational noise without canceling valid evidence or
   triggering deployment.
2. **Why HOE.** Cancellation and production interpretation affect shared
   operational history and require owner authority.
3. **Prerequisites.** Read-only access to GitHub Actions and Cloudflare Pages;
   intended SHA/deployment ID known; automatic builds expected disabled.
4. **Official sites.** GitHub repository Actions UI and Cloudflare Pages project;
   Pages Git integration/API sources in `PROVIDER_RESEARCH.md`.
5. **Navigation.** GitHub → Actions → run; Cloudflare → Workers & Pages → project
   → Deployments. Fallback: search official docs/API for deployment status and
   branch controls.
6. **Safe values.** Run ID, deployment ID, SHA, branch, timestamps, status,
   environment, trigger, stage, and skip reason.
7. **Do not change.** Branch controls, canonical deployment, workflows,
   deployment, policy, secrets, or repo.
8. **Never share.** Log sections with secrets, cookies, tokens, identities,
   environment values, or private payloads.
9. **Actions.** (1) Correlate alert to exact ID/SHA/time. (2) Determine whether
   GitHub run is unique/required or duplicate. (3) Determine Pages status/stage/
   skip reason. (4) If `idle` plus disabled-deployment skip reason, record as
   expected skip. (5) If actual failure, record failed stage and stop. (6) If
   success unexpectedly changed canonical production, escalate immediately.
   (7) Cancel only an older truly duplicate active run after confirming a newer
   equivalent required run exists; otherwise leave it. (8) Archive stale email
   only after correlation.
10. **Expected result.** Every signal is classified as required CI, duplicate,
    expected disabled skip, actual failure, unexpected deployment, or stale
    alert.
11. **Safe validation.** Compare IDs/SHA/status/skip reason and canonical
    deployment metadata; do not rely on email subject or dashboard color.
12. **Safe evidence.** Sanitized one-line record per signal with the fields in
    step 6 and chosen action.
13. **Common errors.** Calling `idle` a failed build; assuming push promoted;
    canceling the only required run; redeploying to “fix” a notification.
14. **Stop conditions.** Canonical deployment changed; auto-build controls
    enabled; status/skip reason unavailable; secret appears; mutation required.
15. **Rollback.** Read-only triage has none. An accidental cancellation is not
    silently rerun; report it. Configuration/deployment remediation requires a
    separate authorized release SOP.
16. **Date/sources.** 2026-08-06; Cloudflare Pages Git integration, Branch
    deployment controls, Pages API, and GitHub Actions documentation. Recheck U1
    sources before future action.

## H-05 — Invite a private-beta user with Access email OTP

1. **Objective.** Add one invited email to the existing human Allow boundary;
   this does not create an accreatio account.
2. **Why HOE.** The HOE approves each beta participant and handles PII in
   Cloudflare without exposing it to agents.
3. **Prerequisites.** D2.1 accepted; privacy notice accurate; OTP IdP already
   available or owner has a separately verified login path; zero-cost plan
   reconfirmed; participant consent/contact established outside project docs.
4. **Official site.** Cloudflare dashboard; official One-time PIN and Access
   policies pages in `PROVIDER_RESEARCH.md`.
5. **Current navigation.** Zero Trust → Integrations → Identity providers for
   OTP; Access controls → Applications → accreatio → Policies for invitation.
   U1 fallback: dashboard search and the official OTP page.
6. **Safe values.** One exact invited email in the existing bounded Allow rule;
   current OTP login method only if required.
7. **Do not change.** Do not add `Everyone`, `Emails ending in` a broad domain,
   or `Login Methods = One-time PIN` as the sole Include; do not change Service
   Auth, destinations, session duration, publisher maps, D1, or deploy.
8. **Never share.** Email, PIN, session/cookie/JWT, login logs, IP, or screenshots
   containing PII.
9. **Actions.** (1) Confirm owner access. (2) Confirm OTP IdP current state. (3)
   If absent and approved, add One-time PIN without removing the owner IdP. (4)
   Add exactly one email to the intended Allow rule. (5) Save. (6) Have the user
   navigate to the portal and request a code. (7) User enters the single-use
   code privately. (8) Confirm portal access and `canPublish:false`. (9) Confirm
   another non-invited address receives no actual code. (10) Record sanitized
   outcome only.
10. **Expected result.** Invited user signs in; non-invited user remains denied;
    neither is a publisher; owner remains able to sign in.
11. **Safe validation.** Boolean invited/non-invited/owner outcomes and time;
    inspect PII logs only inside authorized dashboard.
12. **Safe evidence.** `invite=<opaque label>; login=pass; publisher=false;
    non-invited=denied; owner=pass`.
13. **Common errors.** Broad all-email rule; expecting a log before code entry;
    mail scanner consumes link/code; replacing the owner IdP.
14. **Stop conditions.** Broad selector, owner lockout, paid prompt, OTP sent to
    non-invited user, publisher capability, or UI differs materially.
15. **Rollback.** Remove only the invited email; verify it can no longer obtain
    access. Disable newly added OTP IdP only after confirming owner alternative.
16. **Date/sources.** 2026-08-06; Cloudflare OTP, IdP, policies, and changelog.
    Re-open within 30 days of execution.

## H-06 — Register a future accreatio GitHub App

1. **Objective.** Register the least-privilege App required by the accepted
   implementation design; no repository operation is part of registration.
2. **Why HOE.** App ownership, callback URLs, private key/client secret, and
   organization installation authority belong to the HOE.
3. **Prerequisites.** D2.2 explicitly accepted; transient backend designed and
   audited; exact callback origin/routes fixed; endpoint-to-permission table
   freshly verified; secret store ready; ZIP fallback complete.
4. **Official site.** `https://github.com/settings/apps`; GitHub App registration,
   permission, token, and revocation docs in `PROVIDER_RESEARCH.md`.
5. **Current navigation.** GitHub Settings → Developer settings → GitHub Apps →
   New GitHub App. Organization-owned Apps use organization settings. U1
   fallback: GitHub Docs search “Registering a GitHub App”.
6. **Safe values.** Name, homepage and exact HTTPS callback URL from accepted
   design; user token expiration enabled; only freshly proven repository/account
   permissions; installation limited to selected repositories.
7. **Do not change.** No broad organization/admin permissions, webhook unless
   design requires it, OAuth App substitute, device flow for the portal, public
   repo default, or automatic install.
8. **Never share.** Client secret, private key, access/refresh/installation
   token, authorization code, full callback URL with query, or secret-manager
   evidence.
9. **Actions.** (1) Recheck official registration UI and permission mapping. (2)
   Enter approved public metadata/callback. (3) Keep expiring user tokens
   enabled. (4) Select only accepted permissions. (5) Register. (6) Transfer
   generated secret/private material directly to protected runtime storage. (7)
   Record App ID/name and permission names only. (8) Install on one selected
   test account/repository only in a separately authorized implementation test;
   stop here during registration.
10. **Expected result.** App exists with exact callback and minimal permissions;
    no repo was created/changed and no token is retained by accreatio.
11. **Safe validation.** Compare public App metadata and permission names to the
    approved table; verify secret presence by boolean only.
12. **Safe evidence.** App name/ID, owner type, callback host/path (no query),
    permission names, expiring-token enabled, secret configured yes/no.
13. **Common errors.** OAuth App instead; excessive permissions; callback typo;
    disabling expiry; downloading key into repo/workspace.
14. **Stop conditions.** Permission ambiguity, paid requirement, secret exposed,
    unexpected organization approval, callback mismatch, or backend not gated.
15. **Rollback.** Uninstall/revoke authorization, delete protected secret, then
    delete the App only after confirming no accepted installation depends on it.
    ZIP remains available.
16. **Date/sources.** 2026-08-06; GitHub Apps overview/differences/permissions/
    user-token/revocation docs. Re-open all U1 sources before execution.

## H-07 — Export and restore editorial D1

**Decision status: Blocked. This is not executable.** R1.0 must first record the
owner-approved backup locations, cipher/tool, key custody, plaintext disposal,
and retention. R1.1 must then replace this draft with exact reviewed
parameterized Wrangler/encryption commands, decrypt-and-verify steps, rotation,
and tested rollback. No future session may execute the draft actions below.

1. **Objective.** Create a verified encrypted backup or recover Blog data
   without confusing Time Travel with long-term retention.
2. **Why HOE.** Export destination/decryption key and destructive production
   restore require owner custody and confirmation.
3. **Prerequisites.** Editorial maintenance window; exact environment/database;
   current schema/count; protected local storage with two copies; current
   Wrangler auth held by HOE; preview rehearsal for restore.
4. **Official site.** Cloudflare D1 Import/export and Time Travel docs in
   `PROVIDER_RESEARCH.md`.
5. **Current navigation.** Prefer reviewed fixed Wrangler commands; dashboard D1
   view is read-only corroboration. UI paths are U1; docs/CLI are fallback.
6. **Safe values.** Blocked pending exact database binding/name, UTC timestamp/
   bookmark, owner-approved encrypted path/cipher, checksum, row count, schema
   version, retention, and plaintext-disposal method.
7. **Do not change.** Wrong environment, D1 binding, migrations, Access,
   deployment, project data, or retention without approval.
8. **Never share.** SQL export, encryption key, Cloudflare token/session, full
   command environment, post bodies, or local path containing identity.
9. **Actions.** **Not executable until H-07 is finalized.** Intended sequence:
   Export: (1) pause editorial writes; (2) verify database; (3)
   obtain current bookmark; (4) run official full remote export to protected
   temp location; (5) encrypt/move to approved storage; (6) checksum and verify
   schema/count in isolation; (7) create second copy; (8) delete plaintext
   recoverably/securely per owner storage policy; (9) resume. Restore: (10)
   record/export current state and bookmark; (11) rehearse target on preview or
   isolated DB; (12) name exact production UTC target and confirm; (13) invoke
   Time Travel restore; (14) verify schema/founding posts/intended rows; (15)
   if wrong, restore using returned previous bookmark; (16) re-enable writes.
10. **Expected result.** Verified encrypted export, or production restored to the
    approved state with an undo bookmark and no project/credential data.
11. **Safe validation.** Environment, UTC, schema version, counts, checksum,
    success boolean, bookmark fingerprint/last characters only if needed.
12. **Safe evidence.** Sanitized backup/restore manifest; never SQL or key.
13. **Common errors.** Seven-day Free retention assumed permanent; raw SQLite
    import; wrong remote/local flag; restore without pre-export; export during
    traffic (it can block requests).
14. **Stop conditions.** Paid prompt; DB identity ambiguity; plaintext cannot be
    protected; export verification fails; preview differs; target time unclear;
    writes cannot be paused.
15. **Rollback.** Export has no DB rollback. Restore uses `previous_bookmark`;
    keep writes paused and escalate if verification still fails.
16. **Date/sources.** 2026-08-06; D1 Time Travel, API, Import/export, pricing and
    release notes. Re-open within 30 days. The final SOP records exact source and
    tool versions.

## H-08 — Produce Windows release evidence

1. **Objective.** Package on a real Windows host at USD 0 and preserve verifiable
   artifact evidence; do not sign or publish.
2. **Why HOE.** Host/release-store custody and any Actions cost decision belong
   to the owner.
3. **Prerequisites.** Separately authorized release micro-sprint; exact green
   source SHA; normal non-symlink Windows workspace; supported toolchain; enough
   local disk; prior known-good artifact/hash.
4. **Official site.** Electron distribution/code-signing docs and GitHub-hosted
   runner billing docs in `PROVIDER_RESEARCH.md`.
5. **Current navigation.** Local PowerShell/terminal on owned Windows is primary.
   GitHub Actions → workflow run is secondary only after billing/usage check.
6. **Safe values.** Source SHA, version, tool versions, artifact name/size/hash,
   test status, sanitized host class.
7. **Do not change.** Electron functionality, Blog boundary, certificates,
   workflow, release page, deployment, source, or auto-update.
8. **Never share.** Signing certificate/key/password, username/path, Actions
   token, environment dump, private artifact, or logs with secrets.
9. **Actions.** (1) Confirm owned Windows x64 host and clean exact SHA. (2) Record
   tool versions. (3) Run only the already-approved verification/package
   commands. (4) Record real output. (5) Hash artifact. (6) run packaged process
   smoke. (7) scan complete artifact for excluded Blog/admin/API/PWA/Function/D1
   markers. (8) collect SBOM/notices/audit evidence. (9) store artifact and
   manifest in approved release store. (10) Do not sign/publish. If using Actions,
   first confirm remaining included minutes and a hard zero-spend setting; stop
   if overage is possible.
10. **Expected result.** Portable artifact tied to SHA with passing smoke,
    exclusion scan and SHA-256; no external release/deploy.
11. **Safe validation.** Compare hash/source/version and pass/fail counts; inspect
    artifact locally.
12. **Safe evidence.** Sanitized manifest and command exit summaries; private
    artifact stays in release store.
13. **Common errors.** Linux/container artifact called Windows evidence;
    symlinked output omitted; hosted-minute overage; unsigned artifact described
    as signed/trusted.
14. **Stop conditions.** Charge prompt, dirty/wrong SHA, symlink workspace,
    excluded web material, high vulnerability, smoke failure, signing request.
15. **Rollback.** Quarantine failed artifact and retain prior known-good by
    verified hash. Do not change user data/source/deploy automatically.
16. **Date/sources.** 2026-08-06; Electron Code Signing/official guides and
    GitHub Actions hosted-runner/billing docs. Re-open U1 billing before use.
