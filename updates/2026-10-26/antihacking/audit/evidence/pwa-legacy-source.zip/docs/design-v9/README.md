# accreatio design v9 — discovery and execution design

**Status:** Proposed
**Governance:** AEKR Full/high-risk
**Role:** Architect (design only)
**Route:** Mixed — local-first project creation with a zero-direct-cost,
vendor-managed web editorial boundary
**Started:** 2026-08-06
**Independent design gate:** PASS — 2026-08-06

This package designs resolution of the accepted release blockers, unfinished web
capabilities, operator procedures, and the dependency-ordered roadmap. It does
not authorize or describe implementation, provider configuration, deployment,
migration, retrotesting, or desktop changes.

## State vocabulary

- **Implemented baseline** — accepted fact supplied by the owner; not re-audited.
- **Proposed** — design recommendation awaiting the applicable gate.
- **Accepted** — explicitly accepted by the HOE and recorded in the project
  decision log.
- **Blocked** — cannot proceed without a named dependency or decision.
- **Deferred** — intentionally outside the current execution horizon.

`Workflow status: Completed` means a design micro-sprint/document is finished;
it never means a Proposed decision is Accepted or implementation is authorized.

## Completed design package

The required design documents were added incrementally under the single active
Sprint → Micro-sprint discipline recorded in `SPRINT_LEDGER.md`.
`DECISION_RECORDS.md` supplies complete comparable fields for every major
recommendation. The independent audit passed; until the HOE explicitly accepts a
decision and authorizes work, all new content remains Proposed, Blocked, or
Deferred as marked.

## Authority and boundaries

The owner-supplied master prompt is the session baseline. Current repository
documents may supply focal context but cannot silently override it. AEKR remains
in `/workspaces/ai-engineering-toolkit`; no private AEKR handbook content is
copied here. Git history is document history, not evidence that a design was
implemented.
