# Design v9 sprint ledger

Only one sprint and one micro-sprint may be active. Checkpoints are concise
re-entry records; detailed evidence remains in the named design document.
Every `Completed` below is workflow status only. Decisions/capabilities retain
their separate Proposed, Accepted, Blocked, Deferred, or Implemented baseline
status and no completion entry authorizes implementation.

## Sprint D0 — Baseline and design control

**Status:** Completed
**Active micro-sprint:** None

### D0.1 checkpoint — Baseline lock

- Completed: accepted facts, read-only controls, scope, and exclusions frozen.
- Decision: treat owner baseline as authoritative and do no retro-review.
- Evidence: both paths, exact HEAD, and eight allowed documents confirmed.
- Pending: define official-source and uncertainty protocol.
- Blocker: none.
- Next micro-sprint: D0.2 — Research protocol.

### D0.2 checkpoint — Research protocol

- Completed: first-party admission, evidence fields, uncertainty, and expiry.
- Decision: volatile claims expire at 30 days; other setup research at 90 days.
- Evidence: initial Cloudflare and GitHub official-source register created.
- Pending: populate provider-specific evidence in its assigned micro-sprint.
- Blocker: none.
- Next micro-sprint: D1.1 — Human publisher.

### Sprint D0 memory capsule

- Owner baseline is locked; no implementation fact was re-audited.
- Documentation HEAD matched `d6823c6e54a144a020f9438655ce968b238d5580`.
- Both required repositories and all allowed context documents exist.
- Excluded files were identified but not opened or incorporated.
- Scope is design/research/SOP/roadmap only; external state is immutable.
- AEKR Full/high-risk and Architect role govern this package.
- Provider decisions require official primary sources dated 2026-08-06.
- U1 volatile facts expire after 30 days; other provider setup after 90 days.
- Inferences stay labeled and carry future acceptance tests.
- No audit by this author may be called independent.
- Next: D1.1 Human publisher.

## Sprint D1 — Current blocker resolution

**Status:** Completed
**Active micro-sprint:** None

### D1.1 checkpoint — Human publisher

- Completed: identity acquisition, exact protected map, capability and rollback.
- Decision: configure human path first; runtime JWT remains authoritative.
- Evidence: Cloudflare identity/JWT docs plus focused parser contract read.
- Pending: HOE decides whether to activate before a real post is ready.
- Blocker: none documental.
- Next: D1.2 — AEKR Service Auth publisher.

### D1.2 checkpoint — AEKR Service Auth publisher

- Completed: exact-token policy, map, lifecycle, validation, and rollback.
- Decision: one dedicated token per agent; reject broad token and Bypass.
- Evidence: Cloudflare policy, service-token, and application-token docs.
- Pending: HOE chooses agents and 90-day proposed duration.
- Blocker: no secret may be supplied to an agent/chat.
- Next: D1.3 — Authenticated acceptance.

### D1.3 checkpoint — Authenticated acceptance

- Completed: safe HOE browser/headers/responsive/ZIP/egress SOP.
- Decision: no test post; return sanitized checklist only.
- Evidence: W1 contract and Cloudflare auth/session documentation.
- Pending: HOE execution after publisher decision.
- Blocker: requires HOE's authenticated browser.
- Next: D1.4 — Operational hygiene.

### D1.4 checkpoint — Operational hygiene

- Completed: CI/Pages/alert classification and stop conditions.
- Decision: `idle` is expected only with an explicit disabled skip reason.
- Evidence: Pages branch controls and deployment API status schema.
- Pending: none for design.
- Blocker: none.
- Next: Sprint D2, D2.1 — Self-service authentication.

### Sprint D1 memory capsule

- Human publisher uses exact JSON email → `{sub,label}` protected map.
- `get-identity.user_uuid` may be handled locally; session material never leaves HOE.
- Runtime authorization still trusts only the independently verified JWT claims.
- Configure human authorization before optional service authorization.
- Service Auth uses a dedicated exact-token selector, never Bypass or broad token.
- Agent map is exact Client ID/common name → safe label; secret is never mapped.
- Agent activation and proposed 90-day duration require HOE decisions.
- Acceptance creates no throwaway post and returns sanitized evidence only.
- ZIP acceptance uses non-sensitive content and no integrations.
- Pages `idle` requires an explicit disabled skip reason to be considered expected.
- Canonical-deployment change is a stop condition, not a redeploy trigger.
- Next: D2.1 Self-service authentication.

## Sprint D2 — Unfinished capabilities

**Status:** Completed

### D2.1 checkpoint — Self-service authentication

- Completed: beta/public account, OTP, passkey, external and own-auth comparison.
- Decision: “register” means invited Access session during private beta.
- Evidence: Cloudflare OTP/IdP, W3C WebAuthn, Supabase/Auth0 official docs.
- Pending: HOE decision before any persistent/public accreatio account.
- Blocker: SMS and open public identity are incompatible with current constraints.
- Next: D2.2 — Optional GitHub.

### D2.2 checkpoint — Optional GitHub

- Completed: App/OAuth/device, permission, backend, expiry and failure design.
- Decision: GitHub App; new empty private repo; no retained refresh token.
- Evidence: current GitHub App, permissions, token and revocation docs.
- Pending: HOE accepts/rejects a transient integration backend.
- Blocker: exact endpoint permissions require a fresh implementation preflight.
- Next: D2.3 — Preferred IDE.

### D2.3 checkpoint — Preferred IDE

- Completed: desktop, web, Codespaces, companion and JetBrains comparison.
- Decision: selection generates instructions; VS Code is preferred, no web execution.
- Evidence: Microsoft, GitHub, and JetBrains official documentation.
- Pending: none for basic ZIP instructions.
- Blocker: Codespaces must stop before paid usage.
- Next: D2.4 — Optional AI provider.

### D2.4 checkpoint — Optional AI provider

- Completed: consumer/API boundary, credential, cost and no-AI design.
- Decision: no provider connection at USD 0; manual copy is the honest option.
- Evidence: official OpenAI and Anthropic billing/product documentation.
- Pending: paid API architecture only if HOE changes the cost constraint.
- Blocker: API use has unavoidable provider cost; consumer sessions are not bridges.
- Next: Sprint D3, D3.1 — Editorial governance.

### Sprint D2 memory capsule

- Private beta “registration” is an invited expiring Access session, not an account.
- Allowlisted email OTP may expand beta; never allow all valid OTP emails.
- Public accounts require explicit product/data/legal/recovery decisions.
- Passkeys are a preferred future factor, not a substitute for account lifecycle.
- SMS OTP is rejected under USD 0.
- Future GitHub integration uses a GitHub App and a narrow transient backend.
- No pasted PAT, retained refresh token, force push, or nonempty-repo overwrite.
- ZIP is the mandatory recovery/fallback for every GitHub failure.
- IDE preference produces artifacts/instructions; it does not control an IDE.
- VS Code is preferred; Codespaces is optional and cost-gated.
- ChatGPT/Claude subscriptions are separate from their paid APIs.
- Default AI path is no-AI; manual prompt copy sends nothing from accreatio.
- Next: D3.1 Editorial governance.

## Sprint D3 — Recommended roadmap

**Status:** Completed

### D3.1 checkpoint — Editorial governance

- Completed: backup, restore, retention, revision, correction, withdrawal, audit.
- Decision: Time Travel plus encrypted exports; immutable revisions; human delete.
- Evidence: D1 Time Travel, export/import, API, limits/pricing official docs.
- Pending: HOE chooses backup retention and correction visibility.
- Blocker: seven-day Free Time Travel alone is not long-term backup.
- Next: D3.2 — Web performance.

### D3.2 checkpoint — Web performance

- Completed: lazy visual boundary, budgets, metrics, fallbacks and rollback.
- Decision: critical content first; Three/Vanta optional dynamic chunk.
- Evidence: Vite build guidance and web.dev code-splitting/performance guidance.
- Pending: measure implementation baseline and accept/amend budgets.
- Blocker: none for design.
- Next: D3.3 — Desktop/release.

### D3.3 checkpoint — Desktop/release

- Completed: Windows host, artifact evidence, signing and zero-cost constraints.
- Decision: owned Windows host primary; signing deferred at USD 0.
- Evidence: Electron signing and GitHub runner/billing documentation.
- Pending: HOE accepts limited unsigned distribution or funds later signing.
- Blocker: hosted-runner overage/signing cost cannot be silently accepted.
- Next: D3.4 — Integrated roadmap.

### D3.4 checkpoint — Integrated roadmap

- Completed: R0–R4 dependency/risk/value/cost/HOE/AI/exit ordering.
- Decision: close protected beta and recovery before optional integrations.
- Evidence: all v9 micro-sprint outputs and official source register.
- Pending: listed HOE product/activation/retention/budget/signing decisions.
- Blocker: independent design audit and sponsor GO before implementation.
- Next: final independent design audit.

### Sprint D3 memory capsule

- Finish human/authenticated W1 acceptance before new capabilities.
- Add editorial recovery before edit/correct/withdraw mutation.
- Free D1 Time Travel is seven days; encrypted exports supply longer retention.
- Restore is destructive and requires pre-export/bookmark/preview/undo evidence.
- Editorial changes create immutable revisions; agent destructive actions excluded.
- Three/Vanta moves behind an optional dynamic presentation boundary.
- Proposed budgets: 250 KiB gzip initial JS and 250 KiB lazy visual chunk.
- Static/reduced-motion/save-data/WebGL failure must remain fully usable.
- Windows packaging evidence comes from owned Windows first.
- Private GitHub runner overage is chargeable; stop before it.
- Signing is deferred under USD 0; unsigned distribution stays limited/truthful.
- Roadmap order is R0 beta closure → R1 recovery → R2 perf/release → R3 invites → R4 integrations.
- Independent audit passed; explicit HOE GO still blocks implementation.

## Final design gate

- Initial independent verdict: FAIL; 0 Blocker, 5 Major, 3 Minor, 2 Observation.
- Reconciliation: official evidence, decisions/matrix, H-03/H-07, rollback,
  states, roadmap and handoff corrected.
- Final independent verdict: PASS.
- Open findings: none.
- Auditor: fresh Codex review agent; Claude was not available/executed.
- Implementation authorization: not granted; explicit HOE GO remains required.
- First future micro-sprint: R0.1 — Human publisher configuration.
