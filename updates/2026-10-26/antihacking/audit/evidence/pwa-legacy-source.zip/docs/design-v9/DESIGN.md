# accreatio blockers, pending capabilities, and roadmap design

**Version:** 9.0
**Date:** 2026-08-06
**Workflow status:** Design complete; independent audit PASS
**Decision status:** Proposed — explicit HOE acceptance/GO pending
**Governance:** AEKR Full/high-risk; Architect role; explicit HOE GO required
before coding or configuration

## 1. Outcome

This package turns the accepted `0.8.0` protected-beta state into executable
future micro-sprints without changing code, provider state, deployment, D1, or
Electron. It closes documentary ambiguity around publisher authorization and
authenticated acceptance; recommends invited Access sessions rather than public
accounts; preserves ZIP/no-AI operation; and gates every vendor integration by
cost, credentials, revocation, and local-first constraints.

## 2. Governing invariants

1. Project input/files/ZIPs and optional integration credentials are never
   stored by accreatio servers or in Blog D1.
2. ZIP project creation remains available without GitHub, IDE, or AI.
3. Blog persistence is a separate web-only data class.
4. Electron contains no Blog/admin/Pages/D1 integration and is unchanged by this
   design.
5. No cookie, JWT, OTP, API key, service secret, provider token, or full identity
   payload enters chat, Git, docs, D1, logs, or project artifacts.
6. Direct service cost remains USD 0; stop before charge, paid tier, purchased
   credit, or automatic recharge.
7. Proposed architecture is not implementation. Audit PASS is not coding GO.

## 3. Proposed architecture

```text
Protected web portal
  ├─ local project domain → in-browser ZIP (always available)
  ├─ Access identity perimeter → validated app JWT
  │    ├─ invited human session → protected email/sub publisher map
  │    └─ optional exact Service Auth token → protected common_name map
  ├─ web-only editorial API → versioned future Blog model → production D1
  └─ optional future adapters
       ├─ GitHub App transient exchange (no retained refresh token)
       ├─ IDE instructions/link to already-known remote resource
       └─ no-AI/manual prompt transfer (default)

Electron → existing local privileged boundary only
```

## 4. Blocker decisions

- Human publisher: exact protected JSON email→`{sub,label}`; HOE obtains
  `user_uuid` locally; only sanitized capability evidence returns.
- Agent publisher: one exact-token Service Auth policy and one token per agent;
  no Bypass, broad token, or human-session automation.
- Acceptance: HOE validates login/content/headers/themes/responsive/ZIP/egress;
  no throwaway post and no HAR/session evidence.
- Operations: Pages `idle` is expected only with a documented disabled skip
  reason; unexpected canonical deployment is a stop.

## 5. Authentication and integration decisions

- Private beta registration means invited, expiring Access session—not a
  persistent accreatio account. Allowlisted email OTP may extend beta.
- Public accounts, passkey recovery, deletion and open signup require a new
  product decision. Phone/SMS is excluded under USD 0.
- Future GitHub uses a GitHub App, short operation token, no refresh-token
  retention, new empty private repo only, and deterministic ZIP fallback.
- IDE selection changes generated guidance only. VS Code instructions are the
  default; Codespaces is optional and stops before paid usage.
- AI remains optional through no-AI/manual prompt copy. Consumer ChatGPT/Claude
  subscriptions are not third-party API credentials; paid APIs are blocked.

## 6. D3.2 — Web performance design

### Loading strategy

- Keep semantic Home/project shell, typography, theme, and static atmosphere
  fallback in the critical path.
- Load the procedural starfield adapter and Three/Vanta through one dynamic
  presentation boundary only after feature/preferences/visibility checks.
- Never preload the optional visual chunk before critical content. On reduced
  motion, save-data, slow update, hidden page, WebGL failure, or chunk failure,
  retain the static local composition and usable content.
- Release one Vanta instance on route/visibility teardown; preserve the separate
  bounded 2D star layer only when its own constraints pass. No project data,
  telemetry, CDN, or remote visual asset.
- Handle dynamic-import/preload errors as recoverable presentation failure, not
  an application crash or reload loop.

### Proposed budgets

Budgets are compressed transfer sizes measured from a clean production build;
the implementation sprint first records the current baseline and may request a
signed amendment if these ceilings are infeasible without visual regression.

| Budget | Proposed ceiling |
|---|---:|
| Initial application JavaScript excluding service worker | 250 KiB gzip |
| Initial CSS | 60 KiB gzip |
| Any single lazy visual JavaScript chunk | 250 KiB gzip |
| Initial route transferred resources excluding cached Access navigation | 500 KiB |
| LCP (mobile p75 target) | ≤ 2.5 s |
| INP (p75 target) | ≤ 200 ms |
| CLS (p75 target) | ≤ 0.1 |

CI must fail on budget regression; warning-threshold suppression is prohibited.
Lab runs compare cold/warm cache, narrow/wide, dark/light, reduced motion,
save-data fallback, WebGL failure/context loss, and visual parity. Preserve the
accepted atmosphere only where it does not obscure content, consume excessive
CPU/GPU/battery, or violate accessibility preferences.

### Rollback

Revert only the lazy-loading increment to the previous verified visual loading
path, retaining static fallback and no new dependency. If visual code fails,
disable the optional dynamic boundary rather than blocking Home/project/Blog.

## 7. D3.3 — Desktop/release design

### Windows packaging host

Primary zero-cost path: an owner-controlled Windows x64 host with the supported
Node/package toolchain and a normal non-symlink workspace. It produces the
portable Windows artifact and executes the process smoke where Windows behavior
is real. A GitHub `windows-latest` runner is secondary only after checking the
private-repository included-minute balance and disabling/avoiding overage; hosted
minutes beyond quota are chargeable.

### Evidence bundle

- exact source SHA, clean status, dependency lock hash, Node/npm/Windows and
  packaging-tool versions;
- exact package command/result and artifact filename/byte size/SHA-256;
- packaged process launch/exit smoke and application version;
- complete scan proving absence of Blog/admin/API/PWA/Functions/D1/migrations/
  founding content;
- SBOM/third-party notices and zero-high dependency-audit result;
- safe failure log with no paths/usernames/secrets beyond necessary sanitized
  diagnostics.

Artifacts are retained in the approved release store with hash and source SHA;
they are not committed to Git unless existing release policy explicitly says so.

### Signing

Electron recommends signing distributed apps; unsigned Windows distribution can
trigger OS warnings. A trusted code-signing certificate normally introduces a
cost/identity process, so signing is **Deferred and incompatible with the
mandatory USD 0 phase unless a no-new-cost owner credential already exists and
is separately approved**. Never generate, request, or upload a certificate in an
ordinary coding session. Until signed, distribution remains limited/private and
truthfully labeled; do not coach users to bypass security warnings broadly.

### Rollback and boundary

Rollback selects the prior known-good desktop artifact by verified hash/SHA;
user data is preserved. Desktop never receives Blog, Access, D1, GitHub web App,
or AI API logic. Packaging failure cannot trigger web deployment or source
rollback automatically.

## 8. Decisions requiring HOE

1. Activate human publishing now or keep maps empty until a real post is ready.
2. Activate which agent(s), and accept/change proposed 90-day service-token
   duration.
3. For beta, add allowlisted Access OTP invitations or remain owner-only.
4. Whether public persistent accreatio accounts are ever desired.
5. Accept/reject a narrow transient backend for future GitHub App operation.
6. Backup location/rotation and editorial correction/withdrawal visibility.
7. Accept proposed performance budgets or require a measured amendment.
8. Keep desktop private/unsigned at USD 0 or fund a future signing gate.

## 9. Acceptance and handoff

The independent design gate passed after reconciliation and is recorded in
`INDEPENDENT_AUDIT_REPORT.md`. It checked every blocker/SOP, provider evidence/
freshness, zero-cost honesty, local-first/Electron boundaries, dependency
ordering, decision status, rollback, and the first future implementation
micro-sprint. `HANDOFF.md` is the only execution entry point after explicit HOE
GO.

Complete mandatory decision fields and the cross-option comparison are
normative in `DECISION_RECORDS.md` and `OPTIONS_MATRIX.md`; this master design
summarizes rather than duplicates them.
