# Current blocker resolution design

**Status:** Proposed
**Sprint:** D1
**Implementation/configuration performed:** None

## D1.1 — Human publisher

### Objective and accepted inputs

Enable only Ed's verified Access identity to receive `canPublish: true`, without
collecting a cookie/JWT/OTP and without widening the current Access Allow
policy. The deployed runtime already validates the Access header, signature,
issuer, audience, time claims, and human claim shape. Both admin maps are empty
and fail closed.

### Official identity findings

- An identity-authenticated Access application token contains verified `email`
  and `sub`; Cloudflare documents `sub` as the user ID unique to an email per
  account. Removal/re-addition or another organization can change it.
- The full identity endpoint returns `user_uuid`, described as the user ID.
- The endpoint requires the user's `CF_Authorization` cookie. That cookie must
  never be copied into chat, a screenshot, shell history, or documentation.
- Runtime authorization must use claims from the independently validated
  application JWT. `get-identity` is only a safe operator-assisted way to learn
  the identifier for configuration.

### Exact protected-value contract

The current parser expects one JSON object with at most 32 properties. Each
property name is a normalized email and each value has exactly `sub` and
`label`:

```json
{"owner@example.com":{"sub":"ACCESS-USER-UUID","label":"ed"}}
```

This is a shape example, not a value to copy. Replace the email and
`ACCESS-USER-UUID` locally. The safe label must be lowercase ASCII alphanumeric
with internal hyphens, 1–40 characters; `ed` is recommended. No additional
properties are allowed. Email is trimmed/lowercased by the runtime; `sub` is
case-sensitive and must be copied exactly. The focused contract check found
that the runtime encodes the pair as JSON `[normalized-email, sub]` before
constant-time comparison.

The HOE may provide only the `user_uuid` to a future operator agent if needed.
Safer still, he should assemble and set the complete JSON locally and report
only: environment, safe label, configuration succeeded/failed, and
`canPublish`. He must never provide the cookie, JWT, OTP, full identity response,
email-plus-identifier map, screenshots containing those values, or any secret.

### Proposed sequence and authorization boundary

1. In an authenticated browser, the HOE obtains only `user_uuid` through a
   local DevTools request to the documented `get-identity` endpoint; he does
   not send the response anywhere.
2. He locally constructs the exact JSON map and validates it is one-line valid
   JSON with only the expected keys.
3. He updates only `BLOG_HUMAN_ADMINS` in the intended Pages environment. He
   does not change issuer, audiences, D1, Access policy, or agent map.
4. He reloads the portal and verifies the minimum session endpoint reports
   `canPublish: true` and safe actor label, with no raw identity.
5. A valid non-admin identity, when available, must remain `canPublish: false`.

### Failure, rollback, and acceptance

- Missing, malformed, oversized, duplicate-normalized, or nonconforming maps
  return administration unavailable and do not authorize publication.
- A changed `sub` after identity removal/re-addition fails closed until the HOE
  deliberately updates the map.
- Rollback is replacing the value with `{}` (or restoring the prior empty
  protected value), then confirming `canPublish: false`. Do not weaken Access.
- Future acceptance: owner `true`, non-admin `false`, anonymous still denied,
  no sensitive identifier in API/D1/log evidence, no test post created.

**Decision:** Proposed — configure the human map before Service Auth because it
closes the owner path with the smaller policy surface.
**HOE decision required:** whether to activate human publishing now or leave it
fail-closed until an intended real post is ready.

## D1.2 — AEKR Service Auth publisher

### Objective and alternatives

Permit separately revocable AEKR automation without replacing or broadening the
human Allow path.

| Alternative | Result |
|---|---|
| One dedicated service token + Service Auth policy | **Recommended**; narrow, attributable, independently revocable |
| Reuse a broad token or `Any Access Service Token` | Rejected; excessive blast radius |
| Bypass policy | Rejected; disables Access enforcement/logging |
| Human cookie/JWT automation | Rejected; wrong credential class and unsafe retention |

### Proposed policy and map

- Keep the current human Allow policy unchanged.
- Add a separate `Service Auth` policy whose Include selector names exactly the
  new service token. Never use `Everyone`, `Any Access Service Token`, Bypass,
  email, or login-method selectors for this path.
- Scope it to the existing application destination. A separate path-only Access
  application for `/api/admin/blog/*` may reduce exposure but is **Deferred**
  unless its audience interaction with the deployed validator is designed and
  accepted; do not improvise it during setup.
- Create one token named for purpose/environment, with the shortest practical
  duration that does not cause unsafe emergency renewal. Proposed initial
  duration: 90 days, `HOE decision required`.
- Current official JWT contract: the token's Client ID appears as
  `common_name`, `sub` is empty, and there is no email.
- `BLOG_AGENT_ADMINS` expects JSON mapping exact Client ID/common name to a safe
  label:

```json
{"CLIENT-ID.access":"codex-aekr"}
```

This is shape-only. Client secret never enters this map. At most 32 mappings;
labels follow the same 1–40 safe-label contract.

### Credential lifecycle

- The HOE stores Client ID and Client Secret in a local credential manager or
  protected runtime secret store outside Git, docs, chat, logs, D1, browser
  storage, project ZIPs, and shell history.
- Cloudflare displays the secret only once. Loss means create a replacement;
  never ask an agent to recover or echo it.
- Rotate by create-before-revoke: create replacement token and exact policy
  selector, update the agent map/client credential locally, perform non-writing
  session acceptance, then revoke old token and remove its map entry.
- Revoke immediately on suspected disclosure, lost device, unexpected request,
  or owner decision. Remove the policy selector and map entry; human Allow stays
  untouched.
- A real intended post is the first write acceptance. No throwaway post.

### Acceptance and rollback

Future acceptance requires anonymous denial unchanged; owner access unchanged;
valid service token receives an Access application JWT and safe agent
capability; wrong/expired/revoked token fails; and one deliberate real publish
is idempotent. Rollback order: remove/disable Service Auth policy, set agent map
to `{}`, revoke token, recheck human/anonymous behavior. Never delete D1 rows as
credential rollback.

**Decision:** Proposed — dedicated token and exact-token Service Auth policy.
**HOE decision required:** activate Codex only, Claude only, both as separate
tokens, or defer agent publication; select token duration.

## D1.3 — Authenticated acceptance

Acceptance is a human browser exercise governed by SOP H-03. It validates:

- Access login, Home, Blog, and exactly three founding posts;
- authenticated Blog API and minimum editor capability;
- API `Cache-Control: no-store` and `X-Content-Type-Options: nosniff`;
- static CSP/anti-frame/referrer/permissions/noindex expectations;
- dark/light, narrow/wide, keyboard/focus, and error announcements;
- local ZIP creation without GitHub, IDE, or AI integration;
- network egress limited to the protected origin, Access/team domain, and
  normal Cloudflare delivery required for that flow.

Evidence must be sanitized status, counts, header names/values, viewport/theme,
and request host/path/method only. No cookies, request authorization headers,
JWTs, identity response, OTP, email, IP, post body, project content, or ZIP.

**Decision:** Proposed — run after the human allowlist is configured, with
publication itself still optional until a real post exists.

## D1.4 — Operational hygiene

### Classification

| Signal | Meaning | Action |
|---|---|---|
| GitHub run queued/in-progress with a newer equivalent run | Possible duplicate | Keep the run attached to the intended SHA; cancel older duplicate only if clearly redundant and cancellation cannot hide required evidence |
| GitHub run completed failure | CI failure | Inspect first-party logs; fix only in a separately authorized implementation session; never call it a disabled Pages build |
| Pages deployment/stage `idle` with skip reason `production_deployments_disabled` or `preview_deployments_disabled` | Expected skipped automatic deployment | Record/ignore; it did not build or promote |
| Pages `failure` after build/deploy stage started | Actual Pages failure | Escalate; do not promote or compensate automatically |
| Pages `success` for an unapproved deployment | Unexpected deployment | Stop, preserve IDs/SHA, compare canonical deployment read-only, do not redeploy |
| Historical failure email with no current failed required run/deployment | Stale notification | Correlate by ID/SHA/time, then archive/ignore |

Cloudflare's API explicitly distinguishes `idle`, `active`, `success`,
`failure`, and `canceled`, and supplies skip reasons. Dashboard labels alone are
not enough: correlate deployment ID, environment, trigger, branch/SHA, stage,
status, skip reason, and canonical deployment. A pushed commit with disabled
branch builds may create metadata without a build or promotion.

### Stop and rollback

Stop if the canonical production deployment changes unexpectedly, automatic
production/preview controls appear enabled, a charge/upgrade is requested, or
identity/build evidence would require sharing secrets. Operational cleanup does
not authorize deployment. Rollback of an accidental policy/build-control
change is restore the last recorded controls; rollback of an unexpected
deployment requires a separately authorized release decision, not an automatic
redeploy.

**Decision:** Proposed — treat documented `idle`+disabled skip reason as
expected metadata, not failure. Never cancel a unique required CI run.

