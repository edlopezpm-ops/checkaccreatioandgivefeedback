# Editorial governance design

**Status:** Proposed
**Micro-sprint:** D3.1
**Boundary:** Blog data only; never project data, credentials, drafts, paths,
attachments, or ZIPs

## Recovery tiers

1. **Immediate recovery — D1 Time Travel.** Current Workers Free retention is
   seven days and restore is in-place/destructive. It is always on for the D1
   production backend. A bookmark immediately before a restore and the returned
   previous bookmark are required rollback evidence.
2. **Portable recovery — encrypted SQL export.** Once per editorial release and
   at least weekly while posts change, the HOE exports schema+data to an
   encrypted local owner-controlled backup, records SHA-256/count/schema version,
   and keeps two owner-controlled copies. Export can block database requests, so
   schedule a small maintenance window and stop if the database grows beyond the
   accepted low-volume profile.
3. **Long retention.** Proposed rotation: 4 weekly + 12 monthly encrypted
   exports, subject to HOE storage/privacy approval. No R2/paid backup dependency
   is introduced. Review retention annually and on any legal request.

Backups inherit published-content confidentiality and safe actor-label data.
They must not include runtime secrets, Access identifiers, request logs, or
project data. Backup filenames/evidence contain date/environment/schema only.

## Restore protocol design

- Stop editorial writes; keep portal read behavior explicitly unavailable or
  maintenance-marked rather than serving stale bundled content.
- Record current row count/latest post IDs and obtain current bookmark. Export
  current state before destructive restore when safe.
- Select a timestamp/bookmark inside verified retention; obtain HOE confirmation
  naming environment and target UTC time.
- Restore production only after preview rehearsal where the incident permits.
- Validate schema version, founding three posts, intended later-post count,
  unique slugs/idempotency, and safe actor labels. Re-enable writes separately.
- If wrong, use the previous bookmark to undo. Never “fix” a restore by deleting
  unexplained rows manually.

Importing a SQL export into a new recovery database is preferred for forensic
inspection; overwriting production from export is a separately gated migration.

## Versioned editorial lifecycle

The current append-only publisher stays unchanged until a future implementation
adds this model:

- `blog_posts`: stable post identity, current published revision pointer,
  lifecycle (`draft` is out of scope; `published`, `corrected`, `withdrawn`).
- `blog_post_revisions`: immutable revision ID, post ID, complete content,
  revision number, created time, safe actor kind/label, reason code, and optional
  replaces revision ID.
- `blog_editorial_events`: minimal event ID, post/revision IDs, action,
  timestamp, safe actor kind/label, reason code; no raw identity or body copy.

Editing creates a new revision atomically and advances the current pointer; it
never overwrites history. A correction exposes the current text and a visible
correction note/date. Withdrawal hides body from ordinary listing while keeping
the audit/recovery record; hard deletion occurs only for an approved legal/
privacy/security requirement with a separately documented backup-retention
decision. Scheduling/media/comments remain Deferred.

## Roles, moderation, and authorization

- Publisher: create a new published post.
- Editor: propose/commit a corrected revision.
- Owner: withdraw/restore and approve hard deletion.
- Service agents remain publisher-only by default; edit/withdraw are human-only
  until a new explicit policy and audit.

The server, never the UI, authorizes each action. High-impact withdrawal/hard
delete requires fresh human reauthentication or a documented confirmation
ceremony and idempotency. Minimum moderation is pre-publication owner review,
truthful attribution/non-endorsement, no secrets/PII/project content, and a
reason code for correction/withdrawal.

## Observability and cost

Track safe counts/status/error classes, D1 rows read/written/storage, latest
successful backup date, and restore drill result. Do not log bodies, raw actor
identifiers, headers, or tokens. Free-plan daily limit exhaustion returns errors;
it must not auto-upgrade. Stop before any charge.

## Acceptance and rollback

- Backup can be decrypted only by HOE and restores into an isolated target with
  matching schema/count/checksum expectations.
- One preview recovery drill per schema change and at least quarterly while the
  Blog is actively edited; no production drill without incident/change gate.
- Revision creation is atomic and old revision remains inspectable to authorized
  owner; withdrawal is reversible; hard delete has explicit legal approval.
- Rollback of versioned editing disables new mutation routes and returns to
  append-only reads/publish while retaining already-created revision tables and
  data. Never downgrade schema destructively.

**HOE decisions required:** backup location/retention; whether public correction
history is visible; withdrawal vs hard-delete policy; who may edit besides Ed.

