# Optional integrations design

**Status:** Proposed
**Sprint:** D2
**Invariant:** ZIP creation/export remains available without GitHub, an IDE, or
an AI provider.

## D2.2 — GitHub

### Recommendation

Use a **GitHub App** if the HOE later authorizes a web integration. GitHub itself
prefers Apps over OAuth Apps because Apps have fine-grained permissions,
repository selection, and short-lived tokens. Do not ask users to paste personal
access tokens and do not use Device Flow in a browser-capable portal merely to
avoid designing the normal web authorization flow.

### Capability boundary

- Connect means user-authorized GitHub App installation/web flow, never reuse of
  the HOE's `gh` desktop session.
- Request only permissions proven necessary for: identify installation/user,
  create a repository if selected, and write repository contents. Exact endpoint
  permission mapping must be rechecked against GitHub's current endpoint docs
  before implementation; GitHub Apps start with no permissions.
- User selects repository/account and visibility; new repositories default
  private, matching the existing product rule.
- accreatio constructs the same deterministic archive manifest used by ZIP.
  Upload order, commit tree, and final branch/ref update must be designed as an
  idempotent transaction with a visible partial-failure ledger.
- Never automatically push, overwrite a nonempty repository, force-update a
  branch, or silently make a repository public.

### Browser/backend and token lifecycle

The browser cannot safely own a GitHub App client secret/private key. A narrow
web backend is required to exchange authorization and/or mint installation/user
tokens. That backend must be separate from Blog data, hold credentials only in
protected runtime configuration, and retain no user token after the operation.

Default GitHub App user tokens expire after eight hours; refresh tokens last six
months when expiration is enabled. accreatio should **not retain refresh tokens**.
Use one short operation session, keep the access token only in protected memory,
discard it on success/failure/logout/timeout, and require reauthorization later.
The user can revoke the App; 401 is treated as revoked/expired and never retried
with broader credentials.

### Partial failure and recovery

1. Before mutation, show repo owner/name/visibility and exact file count.
2. If repo creation succeeds but content write fails, report the repository URL
   and completed step; do not delete it automatically.
3. If some Git objects exist but the target ref was not updated, report no final
   publication; retry only with a new explicit confirmation and idempotency key.
4. If target is nonempty or changed concurrently, stop and offer ZIP; no force.
5. Always offer the locally generated ZIP from the same manifest.

**HOE decision required:** whether this new transient integration backend is
acceptable at all, and whether v1 supports only creating a new empty private repo
or also an explicitly selected empty existing repo. Recommendation: new private
repo only.

## D2.3 — Preferred IDE

### What “connect an IDE” means

In the zero-cost/local-first phase it means **select a preferred IDE and generate
portable instructions/artifacts**, not remotely control an editor:

- ZIP with README, prompt, plan, governance, and optional editor-neutral files;
- IDE-specific “after extraction” instructions;
- optional user-initiated link only when an official, safe URI can identify a
  resource the user already chose;
- no arbitrary command, extension install, terminal execution, filesystem path
  probing, or remote executor.

### Comparison and decision

| Surface | What is official | Cost/data | Limitation | Decision |
|---|---|---|---|---|
| VS Code desktop | `code <folder>` and `vscode://file/<absolute-path>` | Free; local | Browser does not know the eventual ZIP extraction path; a crafted absolute path is unsafe/unreliable | Preferred instructions; no automatic deep link from pure web |
| VS Code for Web | Can open GitHub repos at `vscode.dev/github/org/repo`; local folder access depends on browser File System Access | Free; browser/provider sees normal metadata | No full runtime/terminal; depends on GitHub for repo URL | Optional after GitHub repo, not a ZIP replacement |
| GitHub Codespaces | Browser/desktop cloud environment and stable codespace links | Included usage may be limited; charges possible | Cloud compute, repo required, organization policy; stop before spend | Optional, explicitly cost-gated |
| JetBrains desktop | Official command-line launcher opens a local folder | Product/license varies | Web portal cannot safely invoke local arbitrary paths | Generate instructions only if user selects it |
| Companion/extension | Could receive consented local path and open editor | Development/maintenance and new attack surface | Not needed for basic export | Deferred W2; separate design/audit |

Recommended generated instruction: extract ZIP, open its folder, then run
`code .` from that folder or choose **File → Open Folder**. An IDE selection may
alter instructions and optional metadata only; project content stays identical.

## D2.4 — Optional AI provider

### Officially supported boundary

- OpenAI documents API service/billing separately from ChatGPT subscriptions;
  API use is usage-billed. A ChatGPT consumer session/subscription is not an API
  credential for an arbitrary third-party web application.
- Anthropic likewise documents Claude.ai plans and Console/API usage as separate;
  API usage requires separately purchased credits.
- The research found no official general-purpose mechanism by which accreatio
  can import a user's consumer ChatGPT or Claude web session. Therefore the
  portal must not promise “Connect ChatGPT” or “Connect Claude” as consumer
  session reuse.
- Provider API keys are developer credentials, not user login. They must never
  enter D1, repository, ZIP, logs, analytics, IndexedDB, localStorage, or Blog.

### Options

| Option | Cost | Credential/data path | Revocation | Decision |
|---|---|---|---|---|
| No AI; deterministic prompt/plan/ZIP | USD 0 | No provider receives project input | N/A | **Default and always available** |
| Manual copy/download prompt into user's chosen AI product | User's separate product terms | accreatio sends nothing; user deliberately transfers text | User controls product session/history | **Recommended optional UX now** |
| Bring-your-own OpenAI/Anthropic API key | Unavoidable usage cost; incompatible with current phase | Needs protected transient backend or risky browser exposure | Revoke at provider; accreatio must discard immediately | **Blocked by USD 0 and architecture** |
| accreatio-funded API | Direct recurring/usage cost | accreatio processes prompt through provider | Central billing/key controls needed | **Rejected current phase** |
| Local/open-weight model through companion | Potential zero marginal provider cost; local hardware/maintenance | Local only when honestly implemented | Stop local process/remove config | **Deferred W2/local route** |

### Proposed truthful UX

The provider selector is a formatting preference, not authentication. accreatio
generates a provider-neutral prompt and, where useful, provider-specific usage
instructions. The call to action says “Download/copy prompt” rather than
“Connect.” A notice states that ChatGPT/Claude subscriptions do not provide API
access to accreatio; any manual submission is governed by that provider and may
be retained there. No provider request is made by accreatio.

### Future paid/API gate

Stop before implementation until the HOE explicitly changes USD 0, chooses a
provider/data-processing boundary, approves protected backend credential
handling, sets hard spend caps with no automatic recharge, defines redaction/
retention and incident response, and obtains a new independent design audit.
Ephemeral provider tokens, where officially available for a specific API, do
not eliminate billing, backend issuance, or data-processing decisions.

