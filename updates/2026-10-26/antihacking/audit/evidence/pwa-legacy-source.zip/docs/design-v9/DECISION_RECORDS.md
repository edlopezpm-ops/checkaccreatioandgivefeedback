# Proposed decision records

**Workflow status:** Design completed
**Decision status:** Proposed unless explicitly marked otherwise

These compact records make the mandatory criteria traceable. “Recurring cost”
includes provider usage and operator burden; every U1 value is rechecked before
execution.

## V9-P01 — Human publisher

- **Context/alternatives:** empty fail-closed map; compare exact human map,
  service-only, or remain disabled.
- **Recommendation/reason:** exact protected email+`sub`→label map first; smallest
  change and preserves human ownership.
- **Dependencies:** H-01, current Access identity contract, HOE activation choice.
- **Cost:** initial/recurrent $0 within Access Free (50-user limit); minimal HOE
  renewal work if identity changes.
- **Data/retention:** protected email+`sub`; Cloudflare identity/session metadata;
  no D1/raw-log identity. Map retained until removal.
- **Security/token/revocation:** validated JWT only; no cookie capture; set map
  `{}` and end/revoke session by supported Access mechanism.
- **Observability:** sanitized capability, anonymous denial, safe label/error class.
- **Work:** HOE obtains ID/sets secret; AI prepares checklist/interprets sanitized
  result.
- **Acceptance/rollback:** owner true/non-admin false/anonymous denied; rollback
  procedure reviewed, live rollback only as incident/change micro-sprint.
- **State:** Proposed; activation decision required.

## V9-P02 — Agent publisher

- **Context/alternatives:** dedicated exact token, broad token, Bypass, human
  automation, or defer.
- **Recommendation/reason:** one dedicated exact Service Auth token per agent;
  independent attribution/revocation, no human-policy change.
- **Dependencies:** human path, agent/duration decision, H-02.
- **Cost:** $0 within current Access Free/account limits; recurring rotation work.
- **Data/retention:** Cloudflare token metadata; protected Client ID→safe label;
  secret retained only in HOE secret manager.
- **Security/token/revocation:** proposed 90 days; create-before-revoke; remove
  policy/map and revoke token.
- **Observability:** expiry, safe label, capability/status; no secret/header logs.
- **Work:** HOE provisions/custodies; AI prepares non-writing client contract.
- **Acceptance/rollback:** exact token succeeds; wrong/revoked denied; owner and
  anonymous unchanged; bounded rollback per H-02.
- **State:** Proposed; agents/duration required.

## V9-A01 — Beta and public authentication

- **Context/alternatives:** owner-only Access, allowlisted OTP, own D1 accounts,
  external auth, passkeys, SMS.
- **Recommendation/reason:** invited Access session; optional allowlisted email
  OTP. Avoid account lifecycle and product/data expansion.
- **Dependencies:** privacy/invite approval, Access entitlement, H-05.
- **Cost:** $0 under current Access Free ≤50 users; recurring invite/support work.
  Public email delivery/SMS cost unresolved or paid.
- **Data/retention:** Cloudflare email/session/security metadata; no accreatio
  account/phone/password/OTP row.
- **Security/token/revocation:** explicit email rules, logout/session expiry/
  invitation removal; never all-valid-email. Passkeys need recovery architecture.
- **Observability:** PII remains in Access logs; project evidence uses opaque
  invite label/booleans only.
- **Work:** HOE approves/removes invite; AI supplies sanitized checklist. Public
  account implementation is future AI work only after new gate.
- **Acceptance/rollback:** invited pass/non-invited deny/publisher false/owner
  pass; remove invite without deleting last owner path.
- **State:** Proposed for beta; public account Blocked pending HOE decision.

## V9-G01 — GitHub

- **Context/alternatives:** OAuth App, GitHub App, pasted PAT, Device Flow, ZIP.
- **Recommendation/reason:** GitHub App, new empty private repo only; GitHub's
  fine-grained repository selection/short-lived tokens reduce blast radius.
- **Dependencies:** transient backend approval, exact endpoint permissions,
  fresh audit, H-06.
- **Cost:** initial development/HOE setup; no added API charge established, but
  plan/organization policy U1; recurring maintenance/re-auth.
- **Data/retention:** GitHub holds repo/App metadata; accreatio retains no access
  or refresh token and no server project copy.
- **Security/token/revocation:** protected backend exchange, memory-only token,
  App/user revocation; no PAT, force, or nonempty overwrite.
- **Observability:** idempotent step ledger, repo URL, statuses/error classes; no
  token/body logging.
- **Work:** HOE owns/registers App; AI implements/tests narrow adapter after GO.
- **Acceptance/rollback:** private empty repo exact manifest; partial failure
  reported; revoke/uninstall; ZIP always available.
- **State:** Proposed; transient backend decision and permissions Blocked.

## V9-I01 — IDE

- **Context/alternatives:** instructions, URI, VS Code Web/Codespaces, companion,
  extension, JetBrains.
- **Recommendation/reason:** preference generates ZIP instructions; VS Code
  default. Pure web cannot safely know extracted local path.
- **Dependencies:** none for instructions; GitHub for remote repo links; spend
  gate for Codespaces.
- **Cost:** $0 instructions; Codespaces may consume included/paid compute;
  companion has recurring maintenance.
- **Data/retention:** local preference/draft only; remote provider gets data only
  when user chooses it.
- **Security/token/revocation:** no command execution/path probing; close remote
  session/revoke GitHub separately.
- **Observability:** artifact/instruction generation only; no IDE telemetry added.
- **Work:** AI generates artifacts; HOE/user extracts and opens folder.
- **Acceptance/rollback:** `code .`/Open Folder works; remove IDE-specific metadata
  and retain neutral ZIP.
- **State:** Proposed; companion/extension Deferred.

## V9-AI01 — AI provider

- **Context/alternatives:** no-AI, manual transfer, BYO API key, funded API,
  local companion, consumer-session reuse.
- **Recommendation/reason:** no-AI plus manual copy. It is honest, local-first,
  and has no direct accreatio cost/credential backend.
- **Dependencies:** none; paid/local paths require new design and GO.
- **Cost:** $0 for accreatio path; OpenAI/Anthropic API usage recurring/paid;
  consumer subscriptions separate.
- **Data/retention:** accreatio sends nothing; manual provider submission follows
  provider retention. API path would send prompt/content.
- **Security/token/revocation:** no key. Future keys require backend secret
  manager, provider revoke/delete and hard spend controls.
- **Observability:** local generation status only; no provider telemetry/API log.
- **Work:** AI generates deterministic prompt; user deliberately transfers it.
- **Acceptance/rollback:** complete project/ZIP with no network provider request;
  rollback removes provider-specific wording.
- **State:** No-AI Proposed; direct APIs Blocked by cost; consumer bridge U3.

## V9-E01 — Editorial governance

- **Context/alternatives:** Time Travel only, encrypted exports, versioned
  correction, destructive overwrite/delete.
- **Recommendation/reason:** Time Travel plus owner-encrypted exports; immutable
  revisions and reversible withdrawal; preserves recovery/audit.
- **Dependencies:** HOE storage/cipher/retention decisions; finalized H-07; fresh
  schema/API audit.
- **Cost:** D1/Functions $0 within quotas; owner storage/operations recurring.
- **Data/retention:** Blog/revision/safe actor labels only; proposed 4 weekly/12
  monthly exports pending HOE.
- **Security/token/revocation:** HOE encryption keys outside repo/chat; human-only
  withdrawal/delete; pause writes during restore.
- **Observability:** backup age/hash/count/schema, safe events, D1 usage; no body/
  raw identity logs.
- **Work:** HOE chooses/custodies/executes destructive restore; AI finalizes SOP
  and future versioning implementation after GO.
- **Acceptance/rollback:** isolated restore verified; previous bookmark undo;
  disable mutation routes without destructive downgrade.
- **State:** Blocked until backup custody/cipher/retention choices.

## V9-R01 — Performance and desktop release

- **Context/alternatives:** eager vs lazy visual runtime; owned Windows vs hosted
  runner; unsigned vs signed.
- **Recommendation/reason:** optional dynamic visual boundary and owned Windows
  packaging; lowest startup/cost and real host evidence.
- **Dependencies:** measured baseline/budget acceptance; Windows host; signing
  funding decision.
- **Cost:** local initial/recurring owner time; private hosted overage and trusted
  signing may charge.
- **Data/retention:** bundle metrics and release artifact/hash only; no project/
  identity data.
- **Security/token/revocation:** no CDN/remote assets; signing key if ever used is
  HOE-only; quarantine bad artifacts.
- **Observability:** chunk sizes/CWV/CPU-GPU fallbacks; SHA/toolchain/smoke/SBOM.
- **Work:** AI implements/tests after GO; HOE packages/custodies/signing decision.
- **Acceptance/rollback:** budgets/fallback/visual parity; real Windows smoke and
  exclusion scan; prior verified artifact/dynamic fallback rollback.
- **State:** Proposed; signing Deferred under USD 0.

