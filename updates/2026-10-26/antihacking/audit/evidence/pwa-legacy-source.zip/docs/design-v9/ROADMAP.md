# Recommended roadmap

**Status:** Proposed
**Micro-sprint:** D3.4
**Ordering rule:** security/access and recoverability before new integrations;
ZIP/no-AI remains functional at every phase.

## Phase R0 — Close protected beta acceptance

| Order | Future micro-sprint | Depends on | AI work | HOE work | Exit criteria | Cost |
|---|---|---|---|---|---|---|
| R0.1 | Human publisher configuration | Design v9 GO | Prepare sanitized verification checklist | Execute H-01 locally | Owner true, non-admin false, anonymous denied; rollback procedure reviewed, not live-tested | USD 0 |
| R0.2 | Authenticated portal acceptance | R0.1 (or explicit publisher defer) | Interpret sanitized evidence only | Execute H-03 | Home/Blog/3 posts/API/headers/theme/responsive/ZIP/egress pass | USD 0 |
| R0.3 | Service Auth publisher | R0.1, HOE agent/duration choice | Prepare client contract; never receive secret | Execute H-02 | Narrow token works, human unchanged, wrong/revoked denied | USD 0 within limits |
| R0.4 | W1.1 closure checkpoint | R0.1–R0.3 or explicit deferrals | Reconcile docs/risks/evidence | Sponsor GO/NO-GO | No ambiguous publisher/acceptance status | USD 0 |

## Phase R1 — Editorial resilience

| Order | Future micro-sprint | Depends on | Exit criteria |
|---|---|---|---|
| R1.0 | Backup custody decision | R0.4 | HOE records locations, cipher/tool, key custody, plaintext disposal, retention |
| R1.1 | Finalize executable H-07 | R1.0 | Exact commands, decrypt/verify, rotation and rollback independently reviewed |
| R1.2 | Execute encrypted export and recovery drill | R1.1 GO | Preview restore from export/Time Travel evidence; no secret/project data |
| R1.3 | Revision/correction/withdrawal schema design gate | R1.2, lifecycle decisions | Fresh audited migration/API/UI design; human-only destructive actions |
| R1.4 | Versioned editorial implementation | R1.3 explicit GO | Atomic revisions, reversible withdrawal, safe audit, recovery drill |

## Phase R2 — Web performance and release hygiene

| Order | Future micro-sprint | Depends on | Exit criteria |
|---|---|---|---|
| R2.1 | Measure bundle/runtime baseline | R0.4 | Reproducible compressed chunk inventory and visual/runtime metrics |
| R2.2 | Lazy-load Three/Vanta and enforce budgets | R2.1 | Critical budgets pass; visual/fallback/a11y parity; no desktop contamination |
| R2.3 | Windows packaging evidence | R0.4, intended desktop release | Owned Windows host package/smoke/hash/SBOM; no Blog artifacts |
| R2.4 | Signing decision | R2.3 | Either funded certificate process accepted or unsigned distribution explicitly limited |

## Phase R3 — Private-beta identity expansion

| Order | Future micro-sprint | Depends on | Exit criteria |
|---|---|---|---|
| R3.1 | Allowlisted Access OTP invite | R0.4, privacy/invite approval | H-05 invited pass/non-invited deny/owner pass/publisher false |
| R3.2 | Beta operations | R3.1 | Join/leave/revoke/support/PII evidence SOP works without accreatio account rows |

Open public registration is not in R3. It requires a separate product decision
and architecture phase covering accounts, deletion, recovery, abuse, legal and
email delivery. SMS remains excluded under USD 0.

## Phase R4 — Optional local-first enhancements

| Order | Future micro-sprint | Depends on | Exit criteria |
|---|---|---|---|
| R4.1 | IDE preference/instructions | R0.4 | ZIP opens through documented manual instructions; no command execution |
| R4.2 | GitHub App detailed design/PoC | HOE transient-backend decision, R0.4 | Exact endpoint permissions proven; token never retained; ZIP fallback |
| R4.3 | GitHub new-private-repo implementation | R4.2 fresh audit/GO | Empty private repo only, idempotent operation, partial-failure ledger/revocation |

## Deferred/blocked horizon

- Public persistent accreatio accounts: HOE product decision required.
- Passkeys: after account/recovery architecture; preferred future factor.
- Phone/SMS OTP: blocked by cost/privacy/abuse in USD 0 phase.
- Direct OpenAI/Anthropic API: blocked by provider cost and credential backend.
- Consumer ChatGPT/Claude session connection: unsupported by established
  official contract; do not promise.
- Local AI companion, arbitrary IDE opening, extensions, and remote execution:
  separate W2 design; no arbitrary portal execution.
- Anonymous portal, custom domain, billing, SaaS multi-tenancy, shared projects,
  project cloud storage, analytics, and Electron Blog remain out of scope.

## Cross-cutting gates

Every implementation micro-sprint reopens U1 sources, declares data/cost, passes
its security/privacy/accessibility/recovery checks, updates docs, receives an
independent audit where Full/high-risk requires it, and waits for explicit HOE
GO. Any paid prompt, automatic recharge, anonymous exposure, credential leakage,
or project-data egress is an immediate stop.

R0 is strictly first. After R0.4, R1 is recommended next by data-loss risk. R2
may run alongside the R1 horizon only by taking its turn in the single active
sprint/micro-sprint slot. R3/R4 are lower-priority optional lanes and should not
displace recovery work, although their listed dependencies do not require R1/R2.
