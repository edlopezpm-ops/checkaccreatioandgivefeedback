# D0 baseline lock

**Micro-sprint:** D0.1
**Workflow status:** Completed
**Decision status:** Implemented baseline facts locked; new decisions Proposed
**Recorded:** 2026-08-06
**Evidence type:** Owner-accepted baseline plus read-only path, HEAD, and file
existence checks

## Product baseline — Implemented baseline

- accreatio is an authenticated, local-first, ephemeral-session web application
  for creating and exporting projects.
- A project can be created and downloaded as ZIP without GitHub, IDE, or AI
  provider integration.
- accreatio servers do not store project files or project content and do not
  retain GitHub, IDE, or AI-provider credentials.
- Blog data is a separate, web-only class persisted in Cloudflare D1.
- Electron remains unchanged and excludes Blog, administration, Pages
  Functions, and D1.

## Accepted release state — Implemented baseline

- Protected origin: `https://accreatio.pages.dev`.
- Deployed source: `8735952c01560218d9dc5d95d5f298329f18d6e5`.
- Cloudflare deployment: `11235c8c-108f-46f3-8cce-fb88a144330b`.
- Current documentation HEAD: `d6823c6e54a144a020f9438655ce968b238d5580`.
- Required CI run `31126788525` succeeded on that HEAD.
- The implementation audit verdict is `PASS_WITH_OBSERVATIONS`, with no
  Blocker, Major, or Minor findings.
- Production and preview D1 contain the migration and exactly the three
  founding posts.
- Anonymous Access requests receive HTTP 302.
- Automatic Pages builds are disabled. Push-created `idle` records do not by
  themselves build or promote a deployment.
- `BLOG_HUMAN_ADMINS` and `BLOG_AGENT_ADMINS` are empty and fail closed.

These facts are accepted inputs and were not independently re-tested in this
design session.

## Open outcomes — Proposed design scope

- Enable neither human nor agent publication during this session; design both
  future paths and their rollback.
- Design authenticated portal acceptance, which has not yet been completed.
- Design user self-service authentication/OTP; it does not yet exist.
- Design optional web GitHub, IDE, and AI-provider capabilities; they are not
  implemented.
- Maintain USD 0 direct service cost and stop before any paid requirement.

## Read-only control evidence

On 2026-08-06 the session confirmed:

- `/workspaces/accreatio` exists.
- `/workspaces/ai-engineering-toolkit` exists and its complete
  `toolkit/MASTER_SOP.md` was read before design work.
- Repository HEAD equals the accepted documentation HEAD above.
- All eight allowed current context documents exist: design v8, its Claude
  audit, W1 readiness, web architecture, web strategy, root decisions, risks,
  and change control.
- `docs/design-v9/` did not already exist.

No implementation, provider state, deployment, database content, CI result, or
runtime behavior was revalidated.

## Scope exclusions

This session must not:

- change or audit application code, Functions, Electron, migrations, tests, or
  build configuration;
- run builds, tests, Lighthouse, packaging, retrospective audits, migrations,
  deployments, promotions, or manual CI;
- change Cloudflare, GitHub, provider, DNS, policy, secret, repository, or
  workflow state;
- create test posts, credentials, tokens, plugins, packages, or services;
- collect cookies, JWTs, OTPs, keys, secrets, or full identity payloads;
- change Electron or portray proposed architecture as implemented.

The following owner-excluded files are neither opened nor incorporated:
`docs/archive/2026-09-05/CURSOR_UX_AUDIT.md`, `core.4360`, `core.43716`, `core.5730`, `core.798609`, and
the ignored original Word source under `.aekr/sources/`.

## Design controls

- One sprint and one micro-sprint may be active at a time.
- Provider claims require current official primary sources and a dated evidence
  record.
- Durable product changes remain `HOE decision required` until explicitly
  accepted.
- Full/high-risk requires an independent audit in a fresh context. The design
  author cannot represent self-review as independent.
- A passing audit does not authorize implementation; explicit HOE GO remains
  mandatory.
