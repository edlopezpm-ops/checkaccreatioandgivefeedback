# Provider research and evidence register

**Status:** Proposed
**Protocol version:** 1.0
**Consultation date:** 2026-08-06 unless a row says otherwise

## Research protocol

### Source admission

1. Technical claims must come from first-party documentation, specifications,
   dashboards/API schemas exposed by the provider, or first-party changelogs.
2. Pricing and quota claims require the provider's current pricing or limits
   page. Marketing summaries are insufficient.
3. UI navigation uses the provider's current documented path. When a provider
   documents only the capability and not the current dashboard route, the SOP
   labels the route volatile and supplies documentation/search fallback instead
   of inventing controls.
4. Search-engine snippets are discovery aids only. A decision cites the direct
   official page and records whether the conclusion is explicit or inferred.
5. No community answer, aggregator, memory-only claim, or undocumented observed
   behavior is normative.

### Evidence record fields

Every admitted source records:

- provider and exact title;
- direct URL and consultation date;
- decision(s) supported;
- frequently changing surface;
- known limits, restrictions, and costs relevant to this design;
- conclusion type: **Explicit**, **Inference**, or **Unknown**.

Conflicting first-party sources are retained as a contradiction. The more
specific/current source governs only after the reason is documented; ambiguity
becomes `HOE decision required` or an implementation-phase verification gate.

### Uncertainty classes

| Class | Meaning | Required treatment |
|---|---|---|
| U0 — explicit/stable | Direct first-party contract or protocol with low churn | Cite and use; verify again before destructive execution |
| U1 — explicit/volatile | Current first-party UI, price, quota, plan, beta, or product behavior | Date-stamp; add preflight recheck and UI fallback |
| U2 — inferred | Supported by first-party facts but not stated as the proposed conclusion | Label inference; retain alternatives and acceptance test |
| U3 — unresolved | Official sources are absent, contradictory, or insufficient | Do not promise; assign owner and blocking decision |

### Change detection and expiry

- Prices, free-plan limits, dashboard paths, beta status, token lifetime
  defaults, product availability, and provider auth offerings are U1 by default.
- A future execution session must re-open every U1/U3 source used by its active
  micro-sprint. Research older than 30 days is presumptively stale for pricing,
  quotas, and UI paths; older than 90 days is stale for other provider setup.
- Check the page's displayed last-updated date and the provider changelog where
  one exists. Record material changes in this file before changing a decision.
- Runtime or account state may be queried read-only only when documentation
  cannot settle an execution prerequisite. It never substitutes for product
  documentation and must not expose identity or secrets.
- A provider setup is tagged **high churn** when it involves dashboard
  navigation, preview/beta features, plan entitlements, or consumer/API product
  boundaries; **medium churn** for token/policy configuration; **low churn** for
  open protocols and stable request contracts.

### Decision discipline

- USD 0 compatibility means no required direct charge at expected beta usage;
  it does not mean unlimited capacity or that third-party users bear no cost.
- If responsible phone/SMS OTP requires a paid messaging path, it is
  incompatible with this phase and must be stated plainly.
- Consumer subscriptions and developer APIs are evaluated separately.
- No capability is accepted merely because the incumbent vendor offers it.
- Proposed steps remain non-executable until the independent design gate and
  explicit HOE GO.

## Evidence register

This table begins with protocol-establishing sources. Later micro-sprints add
the exact identity, GitHub, IDE, AI, email, and operational sources they use.

| ID | Provider | Official source | Consulted | Supports | Volatile surface | Limits/cost relevant here | Conclusion |
|---|---|---|---|---|---|---|---|
| CF-ACCESS-POLICY-01 | Cloudflare | [Access policies](https://developers.cloudflare.com/cloudflare-one/access-controls/policies/) | 2026-08-06 | Separate Allow, Service Auth, Block and Bypass actions; evaluation behavior | Policy selectors, ordering guidance, dashboard terminology | Misconfigured `Everyone`/all-valid-email Allow can widen access; Service Token selector requires Service Auth | Explicit; U1 for UI/order details |
| CF-ACCESS-TOKEN-01 | Cloudflare | [Service tokens](https://developers.cloudflare.com/cloudflare-one/access-controls/service-credentials/service-tokens/) | 2026-08-06 | Token components, creation path, duration, renewal/revocation design | Dashboard route, API schema, role availability | Client secret is shown once; Service Auth is required; secret handling is an HOE operation | Explicit; U1 |
| CF-ACCESS-MGMT-01 | Cloudflare | [Manage Access policies](https://developers.cloudflare.com/cloudflare-one/access-controls/policies/policy-management/) | 2026-08-06 | Reusable policy management and current UI path | Dashboard route and optional policy controls | Policy changes affect perimeter access and require rollback-ready HOE steps | Explicit; U1 |
| CF-ACCESS-CHANGE-01 | Cloudflare | [Access changelog](https://developers.cloudflare.com/cloudflare-one/changelog/access/) | 2026-08-06 | Change-detection source for Access setup | Entire product surface | No cost claim; used to detect new/changed capabilities | Explicit; U1 |
| CF-PAGES-LIMIT-01 | Cloudflare | [Pages limits](https://developers.cloudflare.com/pages/platform/limits/) | 2026-08-06 | Current Pages Free limits and Functions quota relationship | Plan quotas | Free plan currently lists 500 builds/month, 20,000 files, 25 MiB/file; Functions consume Workers quota | Explicit; U1 |
| CF-PAGES-UPLOAD-01 | Cloudflare | [Direct Upload](https://developers.cloudflare.com/pages/get-started/direct-upload/) | 2026-08-06 | Distinguish explicit prebuilt upload from Git integration | Wrangler/UI workflow | Direct Upload project cannot later switch to Git integration; deployment is an explicit future action | Explicit; U1 |
| CF-D1-PRICE-01 | Cloudflare | [D1 pricing](https://developers.cloudflare.com/d1/platform/pricing/) | 2026-08-06 | Free-plan budget feasibility | Quotas and prices | Current Free allowance: 5M rows read/day, 100k written/day, 5 GB total | Explicit; U1 |
| CF-D1-RECOVERY-01 | Cloudflare | [Time Travel and backups](https://developers.cloudflare.com/d1/reference/time-travel/) | 2026-08-06 | Recovery architecture and retention | Retention by plan and restore tooling | Always on for production backend; current retention is 7 days Free/30 days Paid; restore overwrites in place | Explicit; U1 |
| GH-OAUTH-01 | GitHub | [Authorizing OAuth apps](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/authorizing-oauth-apps) | 2026-08-06 | OAuth web/device authorization, user review, and revocation research entry point | OAuth behavior and token lifecycle | Exact permissions/storage decision deferred to D2.2 | Explicit source; conclusions pending |
| CF-ACCESS-JWT-01 | Cloudflare | [Application token](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/application-token/) | 2026-08-06 | Human `email`/`sub`, service `common_name`/empty `sub`, and full-identity `user_uuid` contract | Claim set and endpoint response | `sub` can change after removal/re-add or across organizations; identity endpoint requires the session cookie | Explicit; U1 claim details |
| CF-ACCESS-VERIFY-01 | Cloudflare | [Validate JWTs](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/validating-json/) | 2026-08-06 | Header, RS256/JWKS, issuer and audience validation | JWKS rotation guidance and dashboard path | Header presence is insufficient; audience changes if application is recreated | Explicit; U1 |
| CF-ACCESS-COOKIE-01 | Cloudflare | [Authorization cookie](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/) | 2026-08-06 | Browser session/logout and why session material stays with HOE | Cookie settings/defaults | Cookie carries identity JWT and must not be collected as design evidence | Explicit; U1 |
| CF-ACCESS-OTP-01 | Cloudflare | [One-time PIN login](https://developers.cloudflare.com/cloudflare-one/integrations/identity-providers/one-time-pin/) | 2026-08-06 | Current OTP setup/behavior for later D2.1; owner login context | UI, default IdP, delivery behavior | PIN single-use, 10-minute expiry; only policy-allowed addresses receive email | Explicit; U1 |
| CF-ACCESS-IDP-01 | Cloudflare | [Identity providers](https://developers.cloudflare.com/cloudflare-one/integrations/identity-providers/) | 2026-08-06 | Multiple IdPs and current Cloudflare IdP default | Supported providers/defaults | Access-managed identity is not an accreatio account | Explicit; U1 |
| CF-ACCESS-LIMIT-01 | Cloudflare | [Account limits](https://developers.cloudflare.com/cloudflare-one/account-limits/) | 2026-08-06 | Access scale and service-token limit | Plan limits | Current defaults include 50 service tokens and 1,000 email addresses/rule | Explicit; U1; pricing still needs separate source |
| CF-PAGES-GIT-01 | Cloudflare | [Git integration](https://developers.cloudflare.com/pages/configuration/git-integration/) | 2026-08-06 | Disable automatic production and preview deployments while retaining Git connection | Dashboard path/control names | Git-integrated project can deploy explicitly with Wrangler after automatic branches are disabled | Explicit; U1 |
| CF-PAGES-BRANCH-01 | Cloudflare | [Branch deployment controls](https://developers.cloudflare.com/pages/configuration/branch-build-controls/) | 2026-08-06 | Production toggle and preview `None` semantics | Dashboard path and API fields | Save is required; controls are per Pages project | Explicit; U1 |
| CF-PAGES-API-01 | Cloudflare | [Pages API](https://developers.cloudflare.com/api/resources/pages/) | 2026-08-06 | Deployment/stage status and skip-reason classification | API schema | `idle` is distinct from failure; disabled production/preview are explicit skip reasons | Explicit; U1 |
| W3C-WEBAUTHN-01 | W3C | [Web Authentication Level 3](https://www.w3.org/TR/webauthn-3/) | 2026-08-06 | Passkey/WebAuthn relying-party, credential and recovery design | Candidate Level 3 features/browser support | RP server must manage challenges/public credentials; passkeys do not create an account lifecycle by themselves | Explicit protocol; U0/U1 for Level 3 maturity |
| SUPA-AUTH-01 | Supabase | [Auth overview](https://supabase.com/docs/guides/auth) | 2026-08-06 | External-provider comparison: email OTP, phone providers, sessions/JWTs | Plans, providers, MAU pricing | New provider stores user/session data; phone relies on messaging provider | Explicit; U1 |
| SUPA-RATE-01 | Supabase | [Auth rate limits](https://supabase.com/docs/guides/auth/rate-limits) | 2026-08-06 | Antiabuse and built-in email limitations | Default/custom limits | Built-in email defaults are unsuitable as an assumed unrestricted production delivery service | Explicit; U1 |
| AUTH0-PWLESS-01 | Auth0 | [Passwordless authentication](https://auth0.com/docs/authenticate/passwordless) | 2026-08-06 | External-provider passkey/email/SMS capability comparison | Plan support and pricing | SMS requires delivery; hosted provider retains identity/session data | Explicit capabilities; cost pending/U1 |
| GH-APP-DIFF-01 | GitHub | [Differences between GitHub Apps and OAuth apps](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/differences-between-github-apps-and-oauth-apps) | 2026-08-06 | Prefer GitHub App, fine-grained repository selection and short-lived tokens | Token duration/features | App installation/admin requirements and exact permissions vary by target | Explicit; U1 |
| GH-APP-PERM-01 | GitHub | [Choosing permissions for a GitHub App](https://docs.github.com/en/apps/creating-github-apps/registering-a-github-app/choosing-permissions-for-a-github-app) | 2026-08-06 | Least-privilege contract | Endpoint permission mapping | Apps have no permissions by default; select only required endpoints | Explicit; U1 |
| GH-APP-TOKEN-01 | GitHub | [Generating a user access token](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) | 2026-08-06 | Browser web flow/device-flow distinction and default token expiry | Optional token expiration behavior | Default user token 8h; authorization can be revoked; device flow is for headless/no-browser clients | Explicit; U1 |
| GH-TOKEN-LIFE-01 | GitHub | [Token expiration and revocation](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/token-expiration-and-revocation) | 2026-08-06 | Revocation/failure design | Token policy | Revoked/expired token cannot be restored; reauthorization needed | Explicit; U1 |
| VSC-CLI-01 | Microsoft | [VS Code command line interface](https://code.visualstudio.com/docs/configure/command-line) | 2026-08-06 | Local folder instructions and official `vscode://` form | URI/client behavior | Pure browser cannot know safe post-extraction absolute path | Explicit facts; conclusion inferred/U2 |
| VSC-WEB-01 | Microsoft | [Visual Studio Code for the Web](https://code.visualstudio.com/docs/remote/vscode-web) | 2026-08-06 | Browser editor and GitHub URL support | Technical Preview/features/browser support | Lightweight; runtime/terminal needs desktop/Codespaces/remote | Explicit; U1 |
| GH-CODESPACE-01 | GitHub | [Opening an existing codespace](https://docs.github.com/en/codespaces/developing-in-a-codespace/opening-an-existing-codespace) | 2026-08-06 | Official browser/desktop links | Availability/UX | User can only open own codespaces | Explicit; U1 |
| GH-CODESPACE-COST-01 | GitHub | [Troubleshooting codespace creation](https://docs.github.com/en/codespaces/troubleshooting/troubleshooting-creation-and-deletion-of-codespaces) | 2026-08-06 | Included-usage/spend stop condition | Included usage/pricing | Creation may require remaining included usage or payment method/spend limit | Explicit; U1 |
| JB-CLI-01 | JetBrains | [Open files from the command line](https://www.jetbrains.com/help/idea/opening-files-from-command-line.html) | 2026-08-06 | Alternative IDE instructions | Launcher/version/license | Local launcher required; opening folder may create `.idea` | Explicit; U1 |
| OAI-BILL-01 | OpenAI | [How can I move my ChatGPT subscription to the API?](https://help.openai.com/en/articles/8156019-how-can-i-move-my-chatgpt-subscription-to-the-api) | 2026-08-06 | Consumer subscription/API separation and cost gate | Billing/pricing | API is managed/billed separately and usage-charged | Explicit; U1; retrieved through official-domain web fallback because Docs MCP was unavailable |
| ANT-BILL-01 | Anthropic | [Claude.ai plan vs API Console](https://support.anthropic.com/en/articles/9876003-i-subscribe-to-a-paid-claude-ai-plan-why-do-i-have-to-pay-separately-for-api-usage-on-console) | 2026-08-06 | Consumer subscription/API separation | Billing/entitlements | Claude.ai plan does not include API usage | Explicit; U1 |
| ANT-CREDIT-01 | Anthropic | [How do I pay for API usage?](https://support.anthropic.com/en/articles/8977456-how-do-i-pay-for-my-api-usage) | 2026-08-06 | Zero-cost incompatibility | Credit terms/pricing | API requires prepaid usage credits; auto-reload must not be enabled in zero-cost phase | Explicit; U1 |
| CF-D1-EXPORT-01 | Cloudflare | [Import and export data](https://developers.cloudflare.com/d1/best-practices/import-export-data/) | 2026-08-06 | Portable encrypted-backup/restore design | Wrangler commands/limits | Export can block requests; produces SQL; raw SQLite is not directly importable | Explicit; U1 |
| CF-D1-API-01 | Cloudflare | [D1 API](https://developers.cloudflare.com/api/resources/d1/) | 2026-08-06 | Export task/bookmark and recovery evidence | API schema/signed URL behavior | Export download URL is time-limited; export data must remain protected | Explicit; U1 |
| CF-D1-TTAPI-01 | Cloudflare | [Time Travel API](https://developers.cloudflare.com/api/resources/d1/subresources/database/subresources/time_travel/) | 2026-08-06 | Restore/undo design | API response | Restore returns previous bookmark usable to undo | Explicit; U1 |
| VITE-BUILD-01 | Vite | [Building for production](https://main.vite.dev/guide/build) | 2026-08-06 | Dynamic visual chunk and load-error design | Current main-branch configuration is high churn | Dynamic imports split chunks; preload errors need handling; exact config must match installed Vite version | Explicit; U1 |
| WEBPERF-SPLIT-01 | Google web.dev | [Reduce JavaScript payloads with code splitting](https://web.dev/articles/reduce-javascript-payloads-with-code-splitting) | 2026-08-06 | Performance rationale/metrics | Guidance is stable; examples aged | Dynamic imports reduce startup payload/main-thread work; measure before/after | Explicit guidance; U0/U1 metrics |
| ELECTRON-SIGN-01 | Electron | [Code Signing](https://www.electronjs.org/docs/latest/tutorial/code-signing) | 2026-08-06 | Signing/value and unsigned-distribution limitation | Tooling/OS requirements | Electron recommends signing; unsigned distribution causes OS warnings; macOS example explicitly needs paid program | Explicit; U1; Windows certificate cost inferred from market and therefore not asserted as provider fact |
| GH-RUNNER-01 | GitHub | [GitHub-hosted runners reference](https://docs.github.com/en/actions/reference/runners/github-hosted-runners) | 2026-08-06 | Appropriate Windows host and zero-cost gate | Runner images/specs/pricing | Private repo uses included minutes then per-minute charges | Explicit; U1 |
| GH-ACTIONS-BILL-01 | GitHub | [GitHub Actions billing](https://docs.github.com/en/billing/concepts/product-billing/github-actions) | 2026-08-06 | Stop-before-charge control | Quotas/rates | Private repo overage is billed to repository owner | Explicit; U1 |
| CF-ZT-PRICE-01 | Cloudflare | [Zero Trust plans and pricing](https://www.cloudflare.com/plans/zero-trust-services/) | 2026-08-06 | Access Free entitlement and identity scale | Price, user limit, log retention | Free is currently $0 forever for up to 50 users; standard log retention up to 24 hours | Explicit; U1 |
| CF-WORKERS-PRICE-01 | Cloudflare | [Workers pricing](https://developers.cloudflare.com/workers/platform/pricing/) | 2026-08-06 | Pages Functions zero-cost envelope | Price/limits | Pages Functions use Workers pricing; Free currently includes 100,000 requests/day and 10 ms CPU/invocation; paid plan minimum is $5/month | Explicit; U1 |
| CF-WORKERS-LIMIT-01 | Cloudflare | [Workers limits](https://developers.cloudflare.com/workers/platform/limits/) | 2026-08-06 | Free failure behavior | Limits | Free daily request excess returns error 1027; no automatic paid capacity is assumed | Explicit; U1 |
| CF-PAGES-FNPRICE-01 | Cloudflare | [Pages Functions pricing](https://developers.cloudflare.com/pages/functions/pricing/) | 2026-08-06 | Connect Pages Functions to Workers quota | Pricing | Function requests are billed as Workers requests; Free resets daily | Explicit; U1 |
| OAI-AUTH-01 | OpenAI | [API reference — Authentication](https://platform.openai.com/docs/api-reference/authentication) | 2026-08-06 | API authentication and browser/backend boundary | API reference/keys | Bearer API key is secret and must not be exposed client-side | Explicit; U1; official web fallback |
| OAI-KEYSAFE-01 | OpenAI | [API key safety](https://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety) | 2026-08-06 | Backend requirement, monitoring, rotation | UI/security guidance | OpenAI says never deploy a key in browsers/mobile; route through backend and rotate on leak | Explicit; U1; official web fallback |
| OAI-KEYREVOKE-01 | OpenAI | [Delete an API key](https://help.openai.com/en/articles/9047852) | 2026-08-06 | Revocation design | UI path | Deleted API key stops working and may halt applications | Explicit; U1; official web fallback |
| ANT-AUTH-01 | Anthropic | [Authentication](https://platform.claude.com/docs/en/manage-claude/authentication) | 2026-08-06 | API key/WIF auth, expiration, rotation and revocation | Auth offerings | Static key or short-lived WIF bearer; keys support expiry; store in secret manager and revoke leaks | Explicit; U1 |
| ANT-API-OVERVIEW-01 | Anthropic | [API overview](https://platform.claude.com/docs/en/api/overview) | 2026-08-06 | Required headers and WIF token contract | API/auth | `x-api-key` or short-lived WIF bearer is required; WIF is workload identity, not consumer Claude session OAuth | Explicit facts; latter conclusion inferred U2 |
| ANT-WORKSPACE-01 | Anthropic | [Workspaces](https://platform.claude.com/docs/en/manage-claude/workspaces) | 2026-08-06 | Key scoping, spend/rate limits and bulk revocation | Console/limits | Workspace archive immediately revokes its keys; spend limits and notifications available | Explicit; U1 |

## Research gaps queued by micro-sprint

- D1.1–D1.4: completed for design; every U1 setup fact must be reopened before
  execution. Exact admin-map serialization was confirmed by a narrow read-only
  contract inspection of the deployed-source parser, not by provider docs.
- D2.1–D2.4: design research completed. Before implementation, GitHub endpoint
  permissions, provider prices/quotas, Access plan entitlement, and every UI
  path remain U1 rechecks. No official general-purpose consumer-session bridge
  for ChatGPT/Claude was established; the design therefore does not promise one.
- D3.1–D3.3: research completed. D1 retention/pricing, Vite configuration,
  runner billing, and signing requirements are U1 and must be rechecked. D3.4
  integrates prior evidence and adds no new provider premise.

## Explicit unresolved provider conclusions

- **U3:** No official OpenAI contract was established for a general third-party
  application to reuse a consumer ChatGPT session. Do not claim such support.
- **U3:** No official Anthropic contract was established for a general
  third-party application to reuse a consumer Claude.ai session. Anthropic WIF
  is workload identity federation for controlled infrastructure, not evidence of
  consumer-session delegation.
- **U3:** No responsible zero-direct-cost SMS delivery contract was established.
  Phone OTP stays blocked.
- **U3:** Exact GitHub endpoint-to-permission mapping for repository creation and
  atomic content publication awaits the implementation preflight.
