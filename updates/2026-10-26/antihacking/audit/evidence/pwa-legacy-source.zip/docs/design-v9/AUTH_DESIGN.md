# Authentication design

**Status:** Proposed
**Micro-sprint:** D2.1
**Product decision:** HOE decision required before any public/self-service
identity architecture

## Meaning of “register”

For the current private beta, “register/sign in” should mean **obtain a
Cloudflare Access-authenticated, expiring session after matching an owner-managed
Allow rule**. It is not an accreatio account. accreatio stores no profile,
password, phone, recovery secret, or project data; Cloudflare processes identity
and session metadata.

An open self-service account is materially different: it adds a persistent user
record, lifecycle, deletion, recovery, antiabuse, notices/consent, and operational
support. That would change the product toward a multi-user service and therefore
requires an explicit HOE decision, updated privacy/legal review, fresh threat
model, and independent gate.

## Options

| Option | Direct cost / USD 0 | Identity retained | Token handling/revocation | Security/abuse | UX/accessibility | HOE/AI complexity | Local-first and Electron | Decision |
|---|---|---|---|---|---|---|---|---|
| Current owner-only Access beta | Current Free-compatible; recheck plan | Cloudflare identity/session; protected allow rule | Access logout, policy removal, session expiry | Smallest current surface | Good for invited beta, not public signup | Low | Preserved/web-only | **Recommended now** |
| Access email OTP for explicitly allowed emails | No direct email fee documented for current Access flow; plan/limits U1 | Cloudflare email/session and policy membership | Single-use 10-minute PIN; remove Allow and expire session | Enumeration-resistant response; mail scanners can consume code | Simple but email-dependent | Low–medium | Preserved/web-only | **Recommended beta expansion** |
| Open Access rule using Login Method=OTP | USD 0 may appear possible | Any valid email can reach portal | Access sessions | Cloudflare explicitly warns this allows all valid emails | Easy but uncontrolled | Low | Boundary weakened | **Reject** |
| Own Workers/D1 email account/OTP | Email delivery may require third party; operational burden | accreatio must retain account/email, OTP state, consent/deletion data | Must build secure sessions, rotation, recovery, deletion | High antiabuse/account-takeover surface | Fully controllable | High | Web-only but changes product/data classes | **Defer; not justified** |
| External provider (Supabase/Auth0 class) | Free tiers exist but quotas/pricing/U1 and production email/SMS may cost | Provider stores account/profile/session | Provider SDK/JWT/revocation | Mature features but new vendor/data processor | Strong hosted flows | Medium; migration/lock-in | Electron can remain excluded | **Defer; compare again if public accounts accepted** |
| Passkeys/WebAuthn | Protocol itself has no usage fee; service/account backend still needed | RP stores user handle, credential ID/public key/counters | Credential removal and account recovery required | Phishing-resistant; recovery is load-bearing | Excellent where supported; fallback needed | High without provider | Web-only possible; new account system | **Preferred future factor, not an account substitute** |
| Phone/SMS OTP | SMS delivery is not responsibly free | Phone and delivery metadata | Provider-dependent | SIM swap, abuse, regional/delivery risks | Useful for some users, excludes others | High and paid | Web-only | **Blocked by USD 0; reject this phase** |

## Proposed beta flow

1. Visitor reaches the Access perimeter.
2. Only an email explicitly named in the Allow rule is eligible for OTP.
3. Access gives the same outward “code sent” response whether allowed or not;
   the single-use PIN expires after ten minutes.
4. Successful authentication yields an Access session; accreatio validates the
   application JWT for API routes and does not create an account row.
5. Logout uses the team-domain Access logout endpoint. Removal means remove the
   email from the Allow rule and, when immediate invalidation matters, revoke/
   invalidate sessions using supported Access administration before reporting
   completion.
6. Project creation/ZIP remains local and usable without GitHub/IDE/AI.

## Data minimization and lifecycle

- accreatio stores no phone, email profile, password, OTP, recovery token, or
  Access JWT in D1.
- Cloudflare retains the identity/session/security metadata governed by its
  service; the privacy notice must describe this accurately.
- Blog audit stores safe actor labels only under the accepted editorial design.
- “Delete my accreatio account” for beta means there is no accreatio account to
  delete; the HOE removes Access eligibility and explains which Cloudflare-held
  data is governed by Cloudflare/account policy. Do not promise deletion outside
  accreatio's control.

## Antiabuse, recovery, observability

- Do not use an all-valid-email Allow rule. Maintain explicit invited emails or
  a deliberately bounded domain only after HOE approval.
- Cloudflare suppresses OTP email for blocked users and logs an attempt only
  after a code is submitted. Use Access authentication logs without copying PII
  into project evidence.
- Recovery is request-new-code and operator review of allowlist/mail filtering;
  there is no accreatio password reset.
- Logout, policy removal, and session expiration must be distinguished; policy
  removal alone must not be described as immediate revocation without a current
  verified mechanism.

## Future public-account gate

Before open registration, the HOE must choose: persistent accreatio account vs.
external managed identity; acceptable identity retention; email delivery
provider/cost; deletion/recovery SLA; antiabuse/rate limiting; age/region/legal
requirements; and whether passkeys are primary or an upgrade factor. Public
signup remains **Blocked** until those decisions and a fresh design/audit.

## Acceptance and rollback

- Invited beta user succeeds; non-allowlisted address receives no OTP; anonymous
  portal access remains denied; no accreatio account/profile row exists.
- Sign-out requires login again; removed invitation no longer authenticates.
- Rollback removes only newly invited emails or disables the OTP IdP if it was
  newly introduced, preserving owner access through a confirmed alternative.
  Never remove the last verified owner path during rollback.

