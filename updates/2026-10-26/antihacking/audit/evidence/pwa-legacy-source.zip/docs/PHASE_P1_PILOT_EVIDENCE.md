# Phase P1 Pilot Evidence — W0 Bridge Abstraction via AEKR Mode 1

**Status:** First real AEKR Mode 1 pilot on accreatio, completed 2026-08-03. Code change is implemented and locally verified; not yet committed at the time of writing (pending this record).

## What ran

AEKR's `toolkit/orchestrator` Mode 1 runner (`runtime.cli`), against `--project-dir` = this repository, `role_sequence` = Implementador (`codex`, `workspace-write`) → Auditor (`claude_code`, fresh context, read-only), per `toolkit/orchestrator/config/orchestrator.config.yaml` (gitignored, project-specific). Task text pointed both roles at the already-approved design in `docs/WEB_ARCHITECTURE.md`'s W0 section rather than re-deriving it.

## Outcome

**Real, verified code change.** `src/types.ts` (+`Bridge`/`WebAttachment`), `src/bridge/{index,electron,web}.ts` (new), `src/App.tsx` (all 8 `window.accreatio` call sites replaced with `bridge.*` + explicit `hostMessage` error surfacing), `tests/bridge.test.ts` (new, 2 tests). Confirmed independently, not just on the agent's claim: `npm test` 16/16, `npm run typecheck` clean, `npm run build` succeeds, zero remaining `window.accreatio` references in `src/App.tsx` (grep-verified).

## Adapter defects found and fixed (all in AEKR, not accreatio)

Three real, environment-specific defects in AEKR's `codex` adapter surfaced only by actually running it, not by code review:

1. **Health-check stream mismatch** — `codex login status` prints to stderr on this machine's installed CLI (`codex-cli 0.146.0`); the adapter checked stdout only, so a genuinely valid ChatGPT login was reported unavailable. Fixed: check both streams.
2. **Removed CLI flag** — `codex exec` on this version rejects `--ask-for-approval` outright (exit 2); the flag doesn't apply to non-interactive `exec` at all. Fixed: removed it.
3. **Missing Windows sandbox helper** — real file writes under `--sandbox workspace-write` were silently rejected regardless of that setting, because `--ignore-user-config` (deliberate, for run isolation) also drops the user's own `[windows] sandbox = "elevated"` config key, and Windows has no Linux-helper/execve-wrapper sandbox mechanism (`codex doctor` confirmed). This one produced a **false-positive `TaskStatus.DONE` with zero files written** on the first full attempt — caught only because a human (not the gate mechanism itself) checked `git status` after the run completed. Fixed: request the Windows helper explicitly per invocation; verified no elevation prompt and no change to actual `--sandbox` permission semantics.

All three fixes are committed and pushed to AEKR (`ai-engineering-toolkit`, commits `46ebfcf`, `c4d8f9b`, `83560de`), each with a regression test, full suite re-verified at 179/179 after the third fix.

## Gates: what worked, what didn't

- **Pause/resume**: exercised once, cleanly — paused at the pre-execution gate (zero cost, before any provider call), resumed with `--new-work-session`, per-entity budget correctly reset on the new session as documented.
- **Recovery from a completed-but-empty run**: after the sandbox bug produced a false `DONE`, the run had already advanced to `COMPLETED` — AEKR's CLI has no supported "retry a completed run" path by design (the control-plane state is intentionally not something the runtime, an agent, or casual tooling reopens). Getting a fresh attempt required the human operator to explicitly archive the state/journal file pair by hand. This is a legitimate, deliberate protection, not a gap — but it means "redo this exact increment" isn't a one-command operation today.
- **Honest limitation — the result-review gate is only as good as actual human attention at that moment.** For pipeline convenience, I (the operator) pre-supplied all six gate decisions (`Approve`) via piped stdin before either provider result existed, rather than reading each result and deciding live. The empty-diff `DONE` from the sandbox bug sailed through that gate uncaught — it was only caught afterward, by manually running `git status`. The gate mechanism did exactly what it was designed to do (stop and ask); it does not, and cannot, substitute for the human actually reading the answer before pressing Approve. Worth stating plainly for Phase P3's UI design: a "batch-approve" convenience path defeats the one thing Mode 1 is for.
- **Auditor's own tool limitation surfaced honestly, not silently**: the Auditor role's fixed read-only toolset (`Read`, `Glob`, `Grep` — no shell) meant it could not run the verification commands its own task asked for, and it said so explicitly rather than fabricating results. That's the adapter's role-scoping working as intended (`_TOOLS_BY_ROLE` in `claude_code.py`) — the task prompt I wrote should not have asked a read-only role to run shell commands; a future task for this role should ask it to review code/tests as text, not execute anything.

## Cost and count

5 real provider invocations total across the pilot (3 `codex`, 2 `claude_code`); well inside the configured caps (`max_provider_invocations: 20`, per-entity cap reset by each new Work Session). `codex` reports no measurable USD cost by design; `claude_code` stayed under its configured `max_budget_usd: 2.0` per call.

## Comparison to the likely Mode 0 workflow

Most of this session's elapsed time went to discovering and fixing the three adapter defects above — friction that exists in the `codex` CLI/Windows integration itself, not something Mode 1 introduced or Mode 0 would have avoided (a Mode 0 operator pasting the same prompt into a bare `codex exec` call would have hit the identical stream/flag/sandbox issues, just with less structured evidence of *why*). Where Mode 1 concretely helped: no manual prompt copy-paste, a durable journal that let this evidence section be written from fact rather than memory, and a real (if under-used, see above) point to stop and check the agent's claim before trusting it.

## Verdict

Increment accepted: real, tested, reviewed code exists for W0; Definition of Done's pause/resume requirement is met. Not yet committed — see chat for the commit/push decision.
