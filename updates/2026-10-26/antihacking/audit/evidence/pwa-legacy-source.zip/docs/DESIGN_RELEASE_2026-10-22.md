# Iceland pearl and official logo — deployed receipt

Date: 2026-10-22. Published at [accreatio.com](https://accreatio.com/).
The owner will review the visual result on that final site.

## Published identity

- Application source: `82b9ac3b2680a6f2735441bb7d2755ec9188f7d4`.
- Saved remote branch: `codex/iceland-pearl-2026-10-22`; source SHA verified with
  `git ls-remote`. Direct Pages upload uses the existing production branch
  mapping; it does not imply a Git merge into `main`.
- Production deployment: `0c32f01a-95f0-45b2-a2de-baa3c74e67fc`.
- Immutable deployment: <https://0c32f01a.accreatio.pages.dev>.
- Previous production retained: `238ee6ee-e44b-4386-bb0a-290a807a8588`.
- Pre-change design custody: commit `236748f`,
  [original sources, hashes and public captures](design-backups/2026-10-22-pre-iceland/README.md).

The owner-selected logo and exact palette are recorded in
[official branding](ACCREATIO_BRANDING.md); the original uploaded PNG remains
byte-identical, SHA-256
`0c53ade5c085e5867541ab933a53288b35e8157f9b1e7698c6536725e5a4b71a`.
The [design record](DESIGN_ICELAND_PEARL_2026-10-22.md) describes the pearl
default, optional soft dark, gray text hierarchy and restrained red accents.
System typography and the neutral procedural nebula are preserved. The original
logo's pearl plate remains visible in dark mode; no inverse artwork was invented.

## Public verification

[Readback receipt](design-evidence/2026-10-22/hosted-readback.json): **PASS**.
Started at `2026-10-22T15:11:53` UTC, following the production deployment.

- 26 served files match local build bytes by SHA-256, including HTML, JS, CSS,
  logo derivatives, PWA assets and legal documents.
- Six routes verified. Public legal pages return 200; public method discovery
  retains Google/GitHub availability and disabled email OTP. Anonymous account
  session returns 401 with `no-store`.
- Desktop and mobile public views verify the exact pearl/title colors,
  complete official logo, zero overflow and zero runtime errors.
- An operating system set to dark still opens pearl. A visit saves no theme
  preference; an explicit dark choice persists through reload and is honored
  by standalone legal pages.

Public captures:
[desktop](design-evidence/2026-10-22/desktop-pearl.png) and
[mobile](design-evidence/2026-10-22/mobile-pearl.png).
These are anonymous browser checks, not personal account login or whole-product
human acceptance.

## Local verification

- Full `verify`: **PASS**, 387/387 unit tests, types, formatting, Functions build,
  web/desktop builds, surface boundaries, Electron, Project Map, guided ZIP,
  account/privacy and identity functional flows.
- After the final web-only logo download/PWA optimization: web build and full
  web functional smoke **PASS**; 18 focused theme/shell/typography assertions
  **PASS**; final formatting including Vite configuration **PASS**.
- Final Lighthouse: performance **93**, accessibility **100**, best practices
  **100**, SEO **69**. Existing deliberate beta `noindex` remains the sole
  permitted SEO exception. Scaling the display logo reduced its SVG from
  663,699 to 191,505 bytes; the canonical original/full-resolution PNG crops are
  unchanged.
- Local visual checks: 21 final-logo views at 320/390/1440px, Spanish/English,
  pearl/dark, About, Blog, cookies, sign-in, creation and reduced motion; no
  runtime errors or overflow, controls at least 44px, draft input preserved
  while switching themes. Contrast checks include selected and muted surfaces.
- Packaged retained desktop: **PASS**, actual packaged executable and 22 ASAR
  assets equal the final desktop build; isolated synthetic IPC creation,
  concurrent calls, versioned reruns, failure recovery and history checked.
  This is an unsigned, unpublished package with an isolated test profile and
  test-only `--no-sandbox`. The published web identity does not unfreeze desktop
  releases or replace its historical bundled logo.
- Official logo: original/source SHA equality, exact full-resolution crops,
  proportional display derivative and deterministic generation checked.
  Canonical AEKR integrity: 4/4 pins, including upstream comparison, **PASS**.

The historical default AEKR payload checker skips its missing old sibling path;
an explicit current-sibling check finds pre-existing vendored-document drift.
The vendored payload is unchanged and the separate branding pins pass. This
limitation is recorded, not represented as a refreshed governance payload.

## Local evidence paths

- `.local/logs/2026-10-22T15-04-50-381Z-verify-7a337f47-c265-4852-acf9-3f38eb5e9f95.log`
- `.local/logs/2026-10-22T15-10-06-483Z-test-web-c7921535-f97b-4bb3-aa1e-f9b9d932db50.log`
- `.local/logs/2026-10-22T15-10-52-310Z-lighthouse-de9edd25-110b-4ea6-9d2f-d5caceb21bb6.log`
- `.local/logs/iceland-20261022/final-logo/visual-audit.json`
- `.local/logs/packaged-iceland-1792681569030/result.json`
- `.local/logs/iceland-20261022/production-deploy.log`
- `.local/logs/iceland-20261022/hosted/readback.json`

Minimal sanitized public evidence is versioned above. Full command logs and
synthetic fixtures remain ignored under `.local/`. Existing untracked review
documents were preserved. No database migration, provider/DNS change, personal
authentication or credential backup was performed in this design delivery.
