# Release 0.9.0 — operación y estado de ejecución

## Aviso de vigencia — entrega final 0.9.1

La entrega vigente es **0.9.1**, desplegada en
[accreatio.com](https://accreatio.com/) desde la fuente
`a16c53dba5c29c5da15ff31e9f41d5a7610ad7d1`. El
[recibo de entrega final](FINAL_PRODUCT_RELEASE_2026-10-21.md) contiene la
identidad exacta de la publicación y sus resultados. La autoridad actual es la
instrucción del propietario de entregar el producto final mediante IA, sin
añadir un gate humano de release o UAT.

La verificación integral terminó **387/387 PASS**, con builds y smokes;
Lighthouse **97/100/100/69**. El recorrido UI combinado produjo doce casos PASS
y un timeout posterior en WebKit. Su reproducción dirigida sobre el mismo
asset pasó; la causa del timeout no está demostrada. No se afirma OAuth
personal, controles/exportación autenticados de producción con una sesión
personal de proveedor ni Safari en un iPhone físico a partir de esos datos.
Estas limitaciones no son nuevas condiciones de entrega.

Este runbook conserva a continuación la **operación histórica de 0.9.0 y el
checkpoint R01–R12**. Sus estados “no completado”, gates, acciones humanas y
aceptación pendiente son de esa etapa. No sustituyen el recibo final 0.9.1 ni
imponen un gate vigente; los hechos de proveedores, migraciones y pruebas se
conservan con su fecha y alcance originales.

## Inicio del registro histórico 0.9.0

Fecha: 21 de octubre de 2026. Versión 0.9.0 desplegada en
[accreatio.com](https://accreatio.com/), con autorización expresa de Ed para
desplegar en `.com`, además de su aprobación de configuración y textos.
Último hito demostrado: despliegue de la fuente `97f0b485`, ajuste de botones
y readback público anónimo de producción a las 16:08:09 UTC.
Estado global: **0 — NO COMPLETADO — EN CURSO O BLOQUEADO**. Las rondas OAuth
reales, los controles de cuentas enlazadas, la exportación autenticada desde
producción y Safari en iPhone físico siguen pendientes; no se declara el estado 3.
La [matriz R01–R12](READINESS_2026-10-21.md) es el único estado de aceptación.

Antecedente de preview: código `0dec26d9fc299e8612b32fd8b93f090361cc25cc`, preview
`176390b5-2148-4010-8bac-de88f2b592c9` desplegada con éxito a las 15:45 UTC en
`google-oidc-preview`, con el nuevo D1 aislado. Cloudflare Access no se retiró:
la verificación personal de esa preview quedó BLOCKED por acceso del propietario.
Ed dirigió el despliegue a `.com`; esto no convierte la preview en PASS ni
acredita OAuth real. El recibo de producción y sus límites figuran abajo.

## Identidad, migración y configuración

El [runbook de identidad](GITHUB_IDENTITY_ACTIVATION.md) contiene la decisión
GitHub App, permisos mínimos, nombres de bindings, callbacks exactos, migración
aditiva `0006` y fallback compatible. Las claves existentes no se sustituyen.
Google se conserva; GitHub no usa permisos de repositorios ni organizaciones.
Los tokens del proveedor solo existen durante la petición del backend.

Configuración ejecutada el 21 de octubre, con autorización de Ed:

| Entorno            | GitHub App registrada        | App ID    | Audiencia                 |
| ------------------ | ---------------------------- | --------- | ------------------------- |
| Preview controlada | `accreatio-preview-identity` | `5412791` | Privada; solo propietario |
| Producción         | `accreatio-web-identity`     | `5412799` | Pública                   |

Ambas Apps tienen únicamente **Email addresses: Read-only** (`emails:read`),
sin permisos de repositorios u organizaciones. Webhooks y comodines de callback
están desactivados. Cada entorno tiene sus cuatro bindings GitHub cargados:
`GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET`, `GITHUB_REDIRECT_URI` y
`ACCOUNT_GITHUB_ENABLED`. Ambos entornos tienen ahora el flag en `true`.
La carga inicial con `false` se conserva solo como antecedente operativo.
Los App ID de la tabla identifican las Apps; no son Client ID ni
credenciales. Este runbook no incluye valores secretos. La configuración
completada y la capacidad habilitada no acreditan un inicio de sesión real.

Callback exacto registrado para la preview controlada:
`https://google-oidc-preview.accreatio.pages.dev/api/auth/v1/oidc/github/callback`.
Callback exacto registrado para producción:
`https://accreatio.com/api/auth/v1/oidc/github/callback`.
No hay comodines ni secretos de producción compartidos con la preview.

Antes de tocar un D1 compartido se deben inventariar sus despliegues escritores,
aliases y callbacks. Los runtimes incompatibles no pueden quedar escribiendo
cuentas enlazadas. Una preview nueva debe usar un entorno controlado compatible
o un store aislado; nunca copiar cuentas, cookies ni claves de producción.

El respaldo de la cuenta de preview se restauró en SQLite aislado y su
comprobación de integridad resultó correcta. Además se creó el D1 remoto
aislado `accreatio-accounts-readiness-preview`, UUID
`57a35f00-dc04-4d6d-a485-c96e1d534ed2`, para impedir que writers antiguos
compartan las nuevas cuentas y pruebas por acción. Se importó el snapshot de
preview correspondiente a las migraciones `0001`–`0004`, manteniendo sus datos
cifrados, y se aplicaron `0005_account_policy_authorization.sql` y
`0006_github_identity_linking.sql`: PASS.

La comparación posterior conservó idénticas todas las filas y columnas
originales: dos cuentas, dos identidades y cero sesiones, transacciones o
recibos de cuota. Se comprobaron cero recibos de política fabricados,
integridad correcta y cero errores de clave foránea. No se descifraron ni
incluyeron payloads en este runbook. El D1 de preview anterior permanece
intacto. Producción se migró posteriormente sobre su D1 existente, como se
registra a continuación.

El mantenimiento de preview ya apunta al nuevo D1 y se desplegó con versión
`36970b73-ea3b-4267-8266-028f9e38aa36`, conservando el cron horario existente.
Este recibo de mantenimiento no acredita el recorrido hosted de la aplicación
ni un acceso OAuth real. La evidencia de preservación queda en
`.local/logs/readiness-2026-10-21/preview-migration-preservation.json`.

## Producción anterior ejecutada y readback

Ed autorizó el despliegue en `.com`; la promoción ya se ejecutó y no espera
otra aprobación de despliegue. Deployment
`3027a9b5-f62e-4f68-99eb-45731f06a630`: **success**,
`2026-10-21T15:53:03Z`, código
`0dec26d9fc299e8612b32fd8b93f090361cc25cc`.
El JavaScript servido `index-CbFRb9nV.js` tiene 488184 bytes y SHA-256
`b3007c5b6cc7f106cda2b1bdf8df51d17b6f86ca074750351e4d82413456c5b7`,
idénticos al artefacto local comprobado.

Se aplicó la migración aditiva `0006` al D1 de producción existente: PASS.
Los respaldos protegidos anterior/posterior se compararon en SQLite aislado;
todas las columnas y filas originales permanecen idénticas: dos cuentas,
dos identidades, un recibo de política, un recibo de exportación y cero
sesiones o transacciones. No se bifurcó el D1 de producción, ejecutó
DROP/RESET ni descifraron datos personales. El mantenimiento de producción
existente permanece compatible y sin modificar.

El readback de métodos en producción confirma Google disponible, GitHub
disponible y OTP deshabilitado, con `Cache-Control: no-store`. Rutas públicas,
avisos `2026-10-21-*` y bytes de la muestra: PASS. La UI real del navegador
integrado mostró ambos proveedores y el ejemplo de bienvenida. El service
worker anterior se actualizó en la siguiente recarga sin borrar el borrador.
Este smoke fue anónimo; no acredita autenticación ni una exportación propia.

Pendientes del alcance:

1. Accesos reales Google/GitHub, conexión de ambos métodos y controles de la
   misma cuenta con prueba OAuth nueva por acción y cuota común. Esas pruebas
   no se ejecutaron; no se asumió el consentimiento personal.
2. Preparación y exportación básica autenticadas desde la UI de producción;
   descargar e inspeccionar ese ZIP y correlacionarlo con R02/R11/R12.
3. Recorrido Safari en iPhone físico. La emulación y WebKit local no lo
   sustituyen.

No se solicitan nuevas autorizaciones para repetir configuración o promoción
ya aprobadas. Las verificaciones personales pendientes y el estado global
se conservan en la matriz.

## Ajuste de botones verificado y desplegado

Fuente `97f0b485c14374ebb9711015b8f2914578f83cb9`, que incluye el ajuste
CSS/layout `357d297`. Se modificaron únicamente el contenedor de proveedores
y su CSS: columnas iguales en escritorio, altura 44 px, gap 12 px y pila
a todo el ancho disponible en móvil. Detalles de privacidad y navegación
tienen separación vertical de 20 px. No cambió la lógica de autenticación,
las APIs, los avisos ni la marca Google; no se añadió un icono GitHub.

Diagnóstico local: **PASS**, seis combinaciones ES/EN × 1280/390/320 px.
Escritorio: 250.14/250.16 × 44 px; móvil: 262 × 44 px a 390 y 246 × 44 px
a 320, con gap 12 px. Etiquetas completas, sin desbordamiento de página.
Evidencia: `.local/logs/readiness-2026-10-21/provider-buttons-smoke.json`
y sus seis PNG. Es un navegador Edge local con capacidades de fixture,
no una autorización OAuth real ni un dispositivo móvil físico.

Artefacto comprobado: `index-BO-vhWup.js`, 488442 bytes, SHA-256
`7fd03978c22af76fe65b3ad9020e82292899794019113f571160876e8e0e5470`.
La nueva ejecución completa de `verify` terminó con **exit 0**: 355/355
pruebas, builds y smokes aprobados; Lighthouse 96/100/100/69 con el mismo
gate noindex. Recibo canónico:
`.local/logs/2026-10-21T16-04-47-541Z-verify-5b7242e8-d5b5-4111-aa44-1717ed014ec4.log`.
La omisión del checkout fuente AEKR externo permanece identificada; payloads,
licencia y ZIP sí se verificaron. El recibo `3027a9b5`/`0dec26d` de arriba
conserva su alcance histórico.

Producción: deployment `434eef0b-6693-46c1-a789-d356d4b37e25`, creado a las
`2026-10-21T16:07:38Z`, **success** a las `2026-10-21T16:07:42Z`, fuente
`97f0b485c14374ebb9711015b8f2914578f83cb9`. Readback
`2026-10-21T16:08:09Z`: **PASS**, JavaScript servido idéntico en bytes y
SHA-256 al build local indicado. Métodos, rutas y estado D1 con migración
`0006` se conservan; no se ejecutó otra migración para este ajuste visual.
Esto no acredita OAuth real, controles enlazados ni exportación autenticada.

El checker de muestras admite `--check` contra el SHA registrado, por lo que
un commit posterior no invalida su reproducción. Las muestras regeneradas
en `357d297e2c0ff1889d20e8449dcf4f78438fa1d4` solo cambian sourceRevision
en `.accreatio/project.json`; handoff, adjuntos e instrucciones permanecen
byte a byte iguales. La muestra básica tiene 19635 bytes y SHA-256
`bbf72008cecfdf648718ba85c86f1e234e14877f2c5c2d33b56f21b2d9225b57`;
el readback de producción coincidió con esos bytes locales.
`public/examples/manifest.json` conserva su procedencia. No se retocó un ZIP
manualmente.

## Verificación local anterior ejecutada — fuente `0dec26d`

`npm.cmd run log -- verify` terminó con **exit 0**: 355/355 pruebas, mailer,
branding, Blog seed, ejemplos, Project Map, tipos Cloudflare, typecheck,
formato, Functions build, builds web/escritorio y smokes de fronteras,
Electron, mapa, web, cuentas e identidad. Recibo canónico:
`.local/logs/2026-10-21T15-38-11-245Z-verify-9bd10e53-848c-40c0-a41a-da53563e82af.log`.

Lighthouse local: rendimiento 96, accesibilidad 100, prácticas 100 y SEO 69.
El gate legado permite el noindex de la beta; ese resultado no acredita
SEO 90 ni conformidad WCAG completa. El check del checkout fuente AEKR externo
se omitió porque no estaba disponible; los payloads vendorizados, licencia
y ZIP reales sí se comprobaron. Estas comprobaciones locales y el smoke
anónimo de producción no sustituyen las rondas OAuth reales ni el recorrido
autenticado de producción.

## Fallback preparado

Deshabilitar `ACCOUNT_GITHUB_ENABLED` conserva los datos válidos y las sesiones
propias; retener el backend compatible con `0006`. No hacer rollback de esquema,
rotar claves ni borrar identidades o recibos. Una reversión de artefacto requiere
una versión que entienda identidades conectadas y pruebas específicas de acción.
Los usuarios GitHub-only que necesiten nueva prueba durante una interrupción
dependen de reactivación o del contacto de derechos publicado; el correo no
fusiona cuentas. No se ejecutó fallback ni restauración en producción.

## Textos aplicables: aprobados y desplegados en producción

Ed aprobó los textos y versiones siguientes. Las fuentes Markdown, los HTML
de Privacidad/Términos, el inventario de cookies y `shared/accountPolicy.ts`
ya usan `2026-10-21-privacy` y `2026-10-21-beta`. Se conserva
`account-core-v1`, la retención existente y la independencia de cookies
opcionales, sin aceptación histórica inventada. El journal local y los datos
de identidad Google/GitHub están descritos en ES/EN. Las frases internas sobre
entidad/jurisdicción se sustituyeron por el contacto AEKR existente.
El readback público de producción confirmó las versiones `2026-10-21-*`.
La aprobación y el despliegue no afirman revisión jurídica formal. Los pasajes
aprobados son:

**Alcance y contacto — ES:** «Estos Términos cubren la beta web gratuita en
https://accreatio.com/. Operador: AEKR. Para consultas sobre el servicio, la
cuenta o derechos, contacta aekr@aekr.io. El acceso utiliza los métodos
habilitados en la aplicación y puede estar sujeto a los límites de admisión
del proveedor. El desarrollo de la edición de escritorio separada está
congelado.»

**Scope and contact — EN:** “These terms cover the free web beta at
https://accreatio.com/. Operator: AEKR. For service, account or rights questions,
contact aekr@aekr.io. Access uses the sign-in methods enabled in the application
and may be subject to provider admission limits. Development of the separate
desktop edition is frozen.”

**Identidad — ES:** «Google y GitHub, cuando están habilitados, proporcionan los
datos de identidad necesarios para el acceso conforme a sus propias políticas.
El acceso con GitHub no solicita permisos de repositorios ni organizaciones.
accreatio emite su propia sesión revocable y no conserva tokens de acceso de
terceros como credenciales de cuenta. Conecta un segundo método explícitamente
desde tu cuenta iniciada; coincidir en correo no combina cuentas. La cuota,
exportación y eliminación corresponden a la misma cuenta interna. Las acciones
sensibles requieren una nueva comprobación OAuth de una identidad conectada,
ligada a esa acción y válida durante cinco minutos; no acredita que se haya
introducido de nuevo una contraseña o MFA.»

**Identity — EN:** “Google and GitHub, when enabled, provide the identity data
required for sign-in under their own policies. GitHub sign-in does not request
repository or organization access. accreatio issues its own revocable session
and does not retain third-party access tokens as account credentials. Connect a
second method explicitly from your signed-in account; matching email alone does
not combine accounts. Allowance, export and deletion belong to the same internal
account. Sensitive actions require a new OAuth check of a connected identity,
bound to that action and valid for five minutes; it does not establish that a
password or MFA was entered again.”

**Borrador — ES:** «Las respuestas y opciones del borrador y su posición se
guardan en este navegador mediante un journal local de escritura inmediata y
IndexedDB. Para adjuntos solo se conserva la cantidad: no sus nombres ni bytes.
Los archivos seleccionados y el ZIP preparado permanecen en memoria de la
pestaña. No se sincroniza el contenido del proyecto con el servicio de cuenta.
Este borrador no es una copia de seguridad; puede perderse al borrar los datos
del sitio o si el navegador elimina su almacenamiento.»

**Draft — EN:** “Draft answers, options and position are saved in this browser
using an immediate local journal and IndexedDB. Only the attachment count is
retained, without file names or bytes. Selected files and the prepared ZIP remain
in tab memory. Project content is not synchronized with the account service.
This draft is not a backup; it may be lost when site data is cleared or the
browser removes its storage.”

**Continuación deliberada — ES:** «Al elegir Continuar con un proveedor
habilitado, Enviar código cuando esté disponible o Continuar con una cuenta
existente junto al aviso visible, aceptas estos Términos y autorizas el
tratamiento necesario de la cuenta por AEKR, descrito por separado en ese aviso
y la Política de privacidad, finalidad account-core-v1. Iniciar sesión no
autoriza analítica, publicidad ni marketing opcionales; las preferencias de
cookies siguen siendo independientes.»

**Deliberate continuation — EN:** “By choosing Continue with an enabled
provider, Send code when available, or the existing-account Continue action
beside the visible notice, you agree to these Terms and authorize AEKR's necessary
core-account processing, described separately in that notice and the Privacy
Policy, purpose account-core-v1. Signing in does not authorize optional analytics,
advertising or marketing; cookie preferences remain independent.”

Se añadieron el enlace de [autorizaciones GitHub](https://github.com/settings/apps/authorizations)
y su política del proveedor junto a Google. Eliminar accreatio no elimina la
cuenta de Google/GitHub ni revoca automáticamente su autorización. Se conserva
la continuidad antiabuso documentada de 48 horas y no se añade colección opcional.
Las frases internas finales se reemplazaron por contacto y derechos aplicables,
sin seleccionar jurisdicción ni afirmar revisión jurídica formal.

## Copy aplicado y derechos ya establecidos

C01–C10/C61–C64 se aplican a bienvenida, muestra, About, FAQ y Blog; la creación
y cuenta cubren C11–C60 según su estado real. C39 afirma que no se creó ZIP
porque el worker dry-run sale antes de construirlo. C45 aclara que tampoco se
guardan nombres. El ejemplo básico está en ES y el avanzado en EN, identificados
en el manifiesto; la instrucción de inicio usa la misma función ES/EN que START
y el resultado de exportación. El navegador confirma la solicitud, no el guardado
físico. La próxima disponibilidad viene del servidor y se muestra con zona horaria.

La licencia del software accreatio sigue siendo de uso privado autorizado. La
copia literal MIT de las plantillas reutilizadas viaja en el ZIP con procedencia;
permite los usos que esa licencia concede conservando su aviso. No se conceden
derechos sobre marcas, la aplicación o material de terceros por inferencia.

Tras cerrar los gates obligatorios, se recomienda observar a 5–8 personas del
público objetivo con consentimiento, sin telemetría nueva: comprensión del
producto, llegada al primer ZIP y utilidad de la primera acción posterior.
