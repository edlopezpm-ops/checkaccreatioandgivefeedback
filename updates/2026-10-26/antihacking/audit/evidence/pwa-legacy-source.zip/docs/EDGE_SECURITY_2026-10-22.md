# Edge protection — 2026-10-22

Owner-authorized, zero-additional-cost hardening of the `accreatio.com` Cloudflare zone. Configuration was applied through the authenticated Cloudflare dashboard in the Codex in-app browser, then reopened and read back. No attack traffic, flood, load test, account mutation, paid upgrade, or new subscription was used to validate these settings.

## Applied configuration

| Control                               | Before        | After                    |
| ------------------------------------- | ------------- | ------------------------ |
| Zone plan                             | Free          | Free                     |
| Bot Fight Mode                        | Off           | **On**                   |
| AI bot policy: Agent                  | Allow         | **Block on all pages**   |
| AI bot policy: Training               | Allow         | **Block on all pages**   |
| AI bot policy: Search                 | Allow         | Allow                    |
| Bot Preference Sync                   | On            | On, preserved            |
| Rate limiting rules                   | 0 of 1        | **1 of 1, Active**       |
| HTTP DDoS attack protection           | Always active | Always active, preserved |
| Cloudflare default managed protection | Always active | Preserved                |
| Under Attack Mode                     | Off           | Off, preserved           |

The rate limiting rule is `accreatio-domain-burst-100-per-10s`, ID `58e2ebcb98ae4a718e7ad688278dc598`:

```text
Match: (http.request.uri.path wildcard r"/*")
Characteristic: IP
Threshold: 100 requests per 10 seconds
Action: Block
Mitigation duration: 10 seconds
Status: Active
Order: First
```

The Free plan editor offered URI Path rather than a hostname field. Consequently, this is a zone-wide rule for all proxied paths, including static assets, HTML, API endpoints, authentication callbacks, and account-rights routes. It is a short network burst gate; it does not create an account sanction, compare email addresses, or permanently ban a shared network. There are no path exclusions that an attacker could use to avoid this rule. A busy shared network may encounter a temporary block; the selected threshold and short duration limit that interruption.

## What the layers cover

Cloudflare documents automatic, unmetered DDoS mitigation across layers 3, 4 and 7 for all plans. The dashboard confirmed HTTP DDoS protection as always active for this zone. This is the network and HTTP flood layer; adding a database counter to every static request would unnecessarily spend the application's finite storage/runtime budget. [Cloudflare DDoS protection](https://developers.cloudflare.com/ddos-protection/about/)

Bot Fight Mode challenges recognized bot patterns across the zone. It does not depend on a particular AI provider name or on an application call to an AI model. It can also challenge legitimate automation, and Free Bot Fight Mode cannot be skipped with WAF custom-rule exceptions. Ordinary interactive Home and Blog navigation succeeded after activation. [Bot Fight Mode](https://developers.cloudflare.com/bots/get-started/bot-fight-mode/)

Agent and Training policies apply to Cloudflare's classified bot behaviors, including applicable verified and unverified bots. They are an additional restriction on recognized AI traffic. They cannot prove that every browser, rotating proxy, undisclosed agent, or spoofed client is identified. Search remains allowed. The existing robots preference synchronization was preserved; robots instructions are advisory rather than an access-control boundary. [AI bot policies](https://developers.cloudflare.com/bots/additional-configurations/block-ai-bots/)

The application abuse guard remains a separate deterministic layer for route, account and session budgets. Its account restrictions are based on attributable excess episodes, not AI content assessment or the coincidence of an IP address and multiple emails. Cloudflare necessarily processes network traffic for its edge service; the application's HMAC-only abuse-store rules do not assert that the provider never handles network metadata. See [the abuse-guard runbook](ABUSE_GUARD_2026-10-22.md).

## Operational limits

- Cloudflare Free currently includes one rate limiting rule with a 10-second period and 10-second mitigation. No paid Bot Management or advanced rate limiting was enabled. [Rate limiting availability](https://developers.cloudflare.com/waf/rate-limiting-rules/)
- Rate counters are distributed and may allow excess requests during propagation. This rule is not an exact global ceiling or a guarantee of uninterrupted service under every attack. [Request-rate calculation](https://developers.cloudflare.com/waf/rate-limiting-rules/request-rate/)
- The zone controls protect requests routed through the `accreatio.com` zone. Separate `*.accreatio.pages.dev` deployment aliases are not covered by this zone's rate rule or bot settings. The accompanying application change must reject noncanonical production API hosts **before D1 work**, using a separately configured exact allowlist for a preview environment. Such early denial still invokes a Pages Function and does not eliminate every platform quota cost. Do not describe a source-only host check as deployed until its deployment receipt exists.
- Authenticated callbacks, own-data export and deletion were not exercised by this edge-only task. Their separate regression checks remain required for the application release. Public Home and Blog navigation is narrower evidence.
- No browser-readable page can be made impossible to inspect or copy. These controls reduce abusive automation; secrets and privileged operations must remain behind server-side authorization.

## Evidence and recovery

Local evidence is retained under `.local/logs/edge-security-20261022/`, including `edge-change-receipt.json`, complete configuration readbacks and screenshots:

- `rate-rule-active.png`: rule listed Active after deployment.
- `rate-rule-stored-parameters.png`: reopened rule with 100 requests, 10-second period and 10-second Block duration.
- `bot-fight-mode-enabled.png`: persisted enabled setting after page reload.
- `ai-bot-policies-blocked.png`: reopened Agent/Training Block and Search Allow configuration.
- `ddos-always-active.png`: provider's always-active DDoS setting.
- `benign-home-after-protections.png` and `benign-blog-after-protections.png`: ordinary production navigation.

These security screenshots show the zone and settings without credentials. Raw accessibility readbacks also contain account navigation metadata and must be sanitized before public publication. No token, cookie, Turnstile secret, or credential-store contents were saved in the evidence.

Recovery is reversible in Cloudflare Security: disable this rate rule or adjust its threshold, turn off Bot Fight Mode if confirmed false positives make it necessary, or restore the previous AI presets. Record the reason and resulting state. Do not remove the application authorization/abuse guard or disable DDoS protection as a workaround.

The first read-only API attempt used an expired existing OAuth credential and returned HTTP 403. That response was not interpreted as proof of WAF permission or provider configuration. The successful dashboard readback is the authority for the applied edge state.
