# Troubleshooting Whitepaper — accreatio (Internal / Support)

**Audience:** support staff and anyone troubleshooting accreatio on someone else's behalf. This is not user-facing — for end-user instructions, hand the user `docs/SOP_DESKTOP.md` or `docs/SOP_WEB.md` instead.

**Status:** living document. Add to it whenever a new real issue is found and resolved; don't let it silently go stale — cross-check against current code before citing a specific line number or behavior as still true.

## 1. Architecture quick reference (what to keep in mind while diagnosing)

- **Two hosts, one codebase.** `src/core.ts` + `shared/domain.ts` hold host-agnostic domain logic. `src/bridge/{electron,web}.ts` implement the same `Bridge` interface differently per host. When a user reports a bug, the first question is always: **desktop or web?** — many "bugs" are one host correctly reporting a capability the other host doesn't have.
- **Desktop** = Electron. Privileged operations (filesystem, Git, GitHub CLI, provider CLI detection) live in `electron/main.ts`, reached only through the narrow IPC surface in `electron/preload.ts`. Its separate renderer/package contains no Blog, publisher, PWA, Function, or D1 code.
- **Web** = a PWA (`vite-plugin-pwa`, service worker) whose project creation/export path remains browser-local. Its web-only Blog reads and publishes editorial content through same-origin Pages Functions backed by D1. `webBridge` still rejects privileged desktop methods defensively.
- **No application telemetry or remote session inspection.** There is no client error-reporting service. Cloudflare may retain bounded infrastructure/authentication/Function metadata, while the Functions intentionally avoid tokens, raw publisher identifiers, and post bodies in logs. Every project-workflow diagnosis still starts from what the user can show directly: the on-screen message, a screenshot, or their own console/log output.

## 2. Shared visual system

### 2.1 Visual atmosphere, motion, and brand navigation

- The active atmosphere is generated locally by two presentation layers: accreatio's deterministic Canvas2D `StarField` and the first-party procedural WebGL nebula in `nebula.ts`, mounted by `Atmosphere.tsx`, with CSS depth/fallback layers in `styles.css`. The star field is first-party code over the native browser Canvas2D API; it adds no package, remote asset, service, or paid cost. Neither layer is a downloaded astronomy image, CDN script, telemetry client, or runtime network request.
- The root `.atmosphere` element reports `data-renderer="loading"`, `"webgl"`, or `"fallback"` for the nebula layer. In normal motion, exactly one `.atmosphere__starfield` Canvas2D canvas and one `.nebula-canvas` WebGL canvas are expected. Repeated canvases of either kind after navigation or theme changes are a lifecycle defect.
- The star field has three deterministic depth bands, right-weighted density, distinct bounded drift rates, and fine-pointer parallax. It consumes only viewport, time, theme, media-preference, and fine-pointer state; it has no product-data, storage, IPC, network, Git, or credential input.
- Under `prefers-reduced-motion`, save-data mode, `(update: slow)`, or a hidden tab, the static CSS composition and one static star canvas remain; no `.nebula-canvas` is expected. Missing WebGL, initialization failure, or lost WebGL context also removes `.nebula-canvas`, but the bounded StarField remains active unless another constrained state applies. Coarse pointers intentionally omit pointer-driven parallax and the cursor-local glow.
- When the tab becomes hidden, the WebGL effect is released, the star canvas holds a static frame, and `data-paused="true"` is set. Normal motion is recreated when the tab becomes visible. One static star canvas in a hidden tab is correct; repeated canvases or a failure to return from fallback after normal tab visibility should be escalated.
- If motion is unexpectedly absent, first inspect OS/browser reduced-motion, data-saver, battery/browser performance settings, hardware acceleration, `(update: slow)`, `data-paused`, and `data-renderer`. Browser console WebGL/context messages plus browser/GPU/version are the useful evidence; do not ask the user to clear drafts or all browsing data.
- If the nebula is blank but stars and the form remain, the fallback is fulfilling the product contract; the stars may be active or static according to the independent lifecycle/preferences above. Reproduce in a current hardware-accelerated browser before treating it as a functional outage. Project creation/export behavior is independent from the renderer.
- The header symbol/name and the About brand return to home/welcome. Inside welcome, the brand returns to step one. If this fails, check button focus/click handling before diagnosing routing; the app intentionally has no URL router.
- The logo SVG and AEKR signature have transparent canvases by construction. A rectangular image background indicates a stale asset/service-worker version; accept the normal update prompt or unregister only the localhost service worker/cache for that origin while preserving IndexedDB/site data, then reload.

## 3. Desktop — common issues

### 3.1 Windows SmartScreen blocks launch

**Cause:** the portable `.exe` is unsigned (code signing is a known, deliberately deferred cost — see `RISKS.md`/`docs/archive/2026-09-05/AUDIT_REMEDIATION_2026-08-02.md`). Not a virus, not a bug.
**Fix:** "More info" → "Run anyway." If a user's org policy blocks this entirely, that's a legitimate organizational control, not something to route around.

### 3.2 "Corrige las validaciones" / start button stays disabled

**Cause:** a required field is invalid. Map of every validation code (`shared/domain.ts::validationErrors`) to what it means:

| Field          | Code                  | Meaning                                                                       |
| -------------- | --------------------- | ----------------------------------------------------------------------------- |
| `name`         | `required`            | Project name is empty                                                         |
| `name`         | `invalid`             | Name is >80 chars or produces an empty slug (e.g., only symbols)              |
| `context`      | `required`            | Known context is empty                                                        |
| `destination`  | `required`            | Destination folder is empty                                                   |
| `agents`       | `uniqueRolesRequired` | 0 agents, >4 agents, or two agents share a role                               |
| `openIde`      | `requiresRepoGit`     | "Open IDE" is on but Git isn't enabled, or Action is tracking-only            |
| `createRemote` | `requiresRepoGit`     | Same, for "Create on GitHub"                                                  |
| `tracking`     | `missingTrackingPath` | Action is not "repository-only" and Settings' `future_projects` path is empty |
| `attachments`  | `invalid`             | Over 20 files, a file >20 MB, total >100 MB, or a disallowed extension        |

**Fix:** read the red text under the specific field — it already names the problem. `tracking`'s error shows its own inline banner with a direct link to Settings.

### 3.3 "Destination already exists" / run stops without writing

**Cause (intentional — DEC-003):** any planned root target that already exists causes a hard stop rather than a merge. This protects against accidental overwrites of an unrelated existing folder.
**Fix:** if the user genuinely wants to augment an existing accreatio-managed project, that's supported — re-running against a folder accreatio itself previously created uses versioned writes (`AGENTS (1).md`, etc.) rather than failing. The hard-stop case is specifically an _unexpected_ existing root the user didn't intend to target — confirm the destination path is actually what they meant.

### 3.4 GitHub shows "not installed" or "not connected"

- **Not installed:** `gh --version` failed. The user needs GitHub CLI installed and on `PATH`; this is unrelated to accreatio itself.
- **Not connected:** `gh --version` succeeded but `gh api user --jq .login` failed (no active `gh` session). Clicking **Conectar GitHub** runs `gh auth login --web --git-protocol https` as a detached process — it opens the user's default browser for GitHub's device-code flow. If nothing visibly happens, check for a browser window that opened behind the main one, or a browser that isn't the user's default.
- accreatio polls status again automatically ~4 seconds after a connect attempt (`setTimeout(refresh, 4000)`), so a status that looks stale for a few seconds is normal — wait before assuming it failed.

### 3.5 "Check providers" reports a provider as unavailable

Real logic, in `electron/main.ts`:

- **Claude Code:** runs `claude --version` (absent → "claude CLI not found"), then `claude auth status`, parses its JSON output. Requires `loggedIn: true` **and** `authMethod: "claude.ai"` — API-key or non-subscription auth is deliberately reported as unavailable, not silently accepted, since the orchestration path assumes subscription billing.
- **Codex:** runs `codex --version`, then `codex login status`. **Reads both stdout and stderr** — some installed CLI builds print the human-readable status line to stderr even on success (this was a real bug found and fixed upstream in AEKR's own adapter during this project's Phase P1; accreatio's own check was written the same correct way from the start). Looks for `"chatgpt"` (available) vs. `"api key"`/`"apikey"` (available but wrong auth mode) in the combined output.
- **If a user insists a CLI is installed and logged in but accreatio disagrees:** have them run the exact commands above themselves in a terminal and compare output. One real, known cause: if a `CODEX_API_KEY` environment variable is set in the shell/session accreatio was launched from, `codex login status` itself typically reports API-key mode rather than ChatGPT-subscription mode — accreatio doesn't read that variable directly, it just reflects whatever the CLI itself reports, and correctly treats API-key mode as "not usable for this purpose" rather than silently conflating the two billing models.
- This check **only exists on desktop.** On web, every provider always reports unavailable with reason "Provider detection requires the desktop app" — that's correct, not a bug, a browser cannot query installed local software.

### 3.6 Settings don't persist / reset after reopening

**Where they actually live:** `%APPDATA%\accreatio\settings.json` and `history.json` (Electron's per-user `userData` path, product name `accreatio`). If a user upgraded from a build named **Inflaton** or **Periastron**, accreatio auto-migrates those files from `%APPDATA%\Inflaton\` / `%APPDATA%\Periastron\` on first run of the new build — but only if `%APPDATA%\accreatio\<file>` doesn't already exist. If migration seems to have not happened, check whether an `accreatio` folder already existed (blocking the copy) before assuming it's broken.

### 3.7 App won't launch at all / crashes immediately

- Confirm it's actually the portable `.exe` and not a corrupted/partial download (check file size against what was distributed).
- Electron apps occasionally fail to launch cleanly after a Windows update; a reboot resolves this more often than it should.
- If it launches then immediately closes, there is currently no log file surfaced to the user — this is a known gap (electron/main.ts's privileged path has no user-visible crash log; see `docs/archive/2026-09-05/ENGINEERING_AUDIT.md` TST-1). Escalate to engineering with exact Windows version and whether antivirus/EDR software is present.

### 3.8 A confirmation appeared to run twice

Within one running app session, accreatio caches each operation ID and coalesces equivalent concurrent requests across both renderer and main-process boundaries. Rapid click/key repetition should therefore create one artifact set and one history row. A later fresh Review/Confirm is deliberately a new operation and creates versioned copies. After a process crash, inspect the completed-action log and destination before choosing a fresh rerun: replay memory is not persisted, and a failure after local writes can leave partial output.

### 3.9 Result says “Some work completed”

This means at least one durable effect finished before a later step failed. Do not delete or assume rollback: compare the exact Produced items paths with the Completed/Not completed lists, inspect the filesystem and any GitHub remote, and correct the failed step. A fresh Review/Confirm is a new run, not resume, and may create versioned copies. Redact usernames and other sensitive path segments before sharing evidence.

### 3.10 Blog or admin controls appear in Electron

This is a release-blocking surface-boundary defect. Confirm Electron loaded `dist-desktop/desktop.html` and that the package allowlist uses `dist-desktop/**/*`, not `dist/**/*`. Run both builds plus `scripts/surface-boundary-smoke.mjs`; do not hide the unexpected control with CSS or a runtime flag.

## 4. Web edition — common issues

### 4.1 The protected beta URL is unavailable

Check `CHANGE_CONTROL.md` before sharing or diagnosing any hosted URL or assuming which version is live. If no verified `0.8.0` deployment is recorded, the earlier protected build may legitimately have no Blog. If a protected URL is recorded, unauthenticated denial is expected: confirm the identity is approved and diagnose Cloudflare Access before treating the application as down. Do not replace the protected link with an anonymous or custom-domain deployment.

### 4.2 A desktop-only control or startup host error appears

W1 no longer calls or displays folder browsing, settings persistence, GitHub connection/status, history, or tracking-only controls. A message about one of those during ordinary startup is a defect, not an expected state. Local discovery attachments are supported only as transient browser bytes for ZIP export. Provider detection remains visibly disabled with an explanation because Mode 1 preparation itself is still available in W1.

### 4.3 ZIP won't download on Execute

- Check the browser's download-blocked indicator (often a small icon in the address bar) — some browsers block automatic downloads triggered without a fresh user gesture in certain configurations.
- Confirm dry-run is actually off — with dry-run on, no download is expected at all (this is correct behavior, not a failure).
- Check the browser console for errors; `webBridge.execute()` fails closed with a returned error message (not a silent hang) for validation failures and unsupported tracking-only exports — if the UI shows nothing at all, that's a real bug worth escalating, not expected behavior.
- Rapid repeated confirmation in one page session is guarded as one logical export and should produce one download. A later fresh Review/Confirm intentionally starts another download. Reloading clears the in-memory replay cache.
- “ZIP prepared; download requested” proves only that the ZIP manifest was built and the browser request API returned. It does not prove disk persistence. Check the browser Downloads UI, blocked-download indicator, filename changes, and alternate save locations; then open the ZIP and compare its entries with the displayed manifest.

### 4.4 Offline reload doesn't work

- The service worker only registers in a **web production build** (`npm run build:web` + serving `dist/`), not the plain dev server (`npm run dev`/`vite` alone) — confirm which one the user/tester is actually running.
- Confirm the page was loaded at least once **online** first, so the service worker had a chance to install and precache. A first-ever visit while offline cannot work — there's nothing cached yet.
- Check the browser DevTools → Application → Service Workers panel for registration/activation status.
- Offline applies to the cached project shell, not Blog data. Access, Functions, and D1 are required for Blog reading/publishing; an unavailable Blog while the project form works offline is correct.

### 4.5 Draft doesn't persist between visits

- Confirm the browser isn't in a private/incognito window (IndexedDB in private mode is often cleared on close, by browser design, not an accreatio bug).
- Confirm the user hasn't cleared site data/cookies for that origin between visits.
- Draft save is debounced ~500ms after the last keystroke — closing the tab within half a second of typing could in theory race the save; this hasn't been observed in practice but is worth knowing if a report is oddly specific about timing.
- A legacy draft is normalized against current defaults before rendering. If the user selects **New draft**, a confirmation appears and the current record is deleted before a fresh draft is saved.

### 4.6 Repeated "new version available" prompts

By design, an update never applies silently — the user must accept the reload prompt. If it reappears every visit, the service worker may not be completing activation; check DevTools → Application → Service Workers for a worker stuck in "waiting" state, and confirm the user actually clicked reload (a dismissed prompt reappears next load, correctly).

### 4.7 Blog unavailable, composer absent, or publish failed

- A plain Vite preview serves assets only. It does not provide Pages Functions, an Access assertion, or D1; the Blog unavailable state is expected there.
- On the hosted portal, inspect only the API status and public error code/message. Never copy an Access JWT, cookie, email, subject, service client ID/secret, or post body into a ticket or log.
- `401` means the Access assertion is missing/invalid; `403` means the verified actor or browser write boundary is not authorized; `503` means Access keys/configuration or D1 is unavailable. Do not weaken validation to distinguish a user in production.
- The composer appears only when `GET /api/admin/blog/session` returns `canPublish: true`. Client-side DOM changes cannot grant publish permission because `POST /api/admin/blog/posts` authorizes independently.
- Publishing requires same-origin `Origin` for humans, JSON, `X-Accreatio-Publish: blog-v1`, and a UUID `Idempotency-Key`. Authorized service identities may omit `Origin` but must match the protected agent map. A retry with the same key and safe actor returns the original post.
- Keep the page open after a failed publish because the draft exists only in memory. Do not create a production throwaway post as a smoke test. Agent publishing is not active until the narrow Service Auth policy and a real allowlisted token are recorded as accepted.

## 5. Diagnostics for support staff

Commands to run yourself (or ask a technical user to run) when investigating:

```powershell
# Desktop: verify GitHub CLI state directly
gh --version
gh auth status

# Desktop: verify AI provider CLI state directly (same checks accreatio makes)
claude --version
claude auth status
codex --version
codex login status

# Desktop: locate persisted settings/history
explorer "%APPDATA%\accreatio"

# Web: reproduce the project shell against a real production build
npm run build:web
npm run preview
# open the printed localhost URL

# Web: run the same accessibility/performance gate CI uses
npm run lighthouse
```

If a report doesn't match anything in §2/§3/§4, reproduce it locally first using the same host (desktop vs. web), build type, and API environment the user was actually on. A Vite preview, local Wrangler simulation, protected preview, and protected production are deliberately different contexts.

## 6. Escalation

If an issue isn't covered above and isn't reproducible with the steps in §4, capture: host (desktop/web), exact on-screen message or console error, the field values that triggered it if relevant, and whether it's reproducible on a clean run. File it as a real engineering issue rather than guessing at a workaround — this document should grow from real resolved cases, not speculation.
