# v14 verification and testing handoff

Date: 2026-09-04. Scope: [DESIGN](DESIGN.md).

Implemented the UI/UX adviser's proposal: a full-width agent/role configuration card with explanatory text; individually boxed export choices with purple selection; centered FAQ/ToS below the reassurance. Native disclosure and radio keyboard behavior remain intact. The card carries the keyboard focus indicator, avoiding a duplicate outline on its radio. No export-domain, account, quota, provider, Blog or desktop behavior is changed.

## Verification

- Repository tests: 228/228 PASS (`.local/logs/legacy-20260905/.accreatio-v14-tests.log`). App/Electron/Functions typecheck and formatting PASS (`.local/logs/legacy-20260905/.accreatio-v14-types.log`, `.local/logs/legacy-20260905/.accreatio-v14-format.log`). No new implementation-mirroring unit tests were added for these presentation changes; existing browser selectors now use the clearer web label.
- Web and retained desktop builds, surface boundary and privileged Electron execute smoke PASS (`.local/logs/legacy-20260905/.accreatio-v14-build.log`, `.local/logs/legacy-20260905/.accreatio-v14-desktop.log`, `.local/logs/legacy-20260905/.accreatio-v14-surface.log`, `.local/logs/legacy-20260905/.accreatio-v14-electron.log`). No desktop package was published.
- Production-build browser workflow PASS at English 390x600, Spanish 320/760 and English 1280 with reduced motion (`.local/logs/legacy-20260905/.accreatio-v14-ui.log`). Includes existing confirmation mode changes, final execution/cancel guards, real ZIP contents, draft/attachment recovery, role/name limits and footer/nebula regressions.
- Focused current-build checks PASS at 320/390/1280 (`.local/logs/legacy-20260905/.accreatio-v14-cards.log`, `output/playwright/v14-cards-receipt.json`): full-width bordered team disclosure, Enter toggle, adding a role, native arrow-key radio selection, selected/unselected computed border and background, minimum touch height, FAQ/ToS below the reassurance and mathematically centered, no overflow or page errors.
- Initial focused color snapshots ran before the browser applied the radio style state; the final check waits for the actual selected border before comparing colors. The receipt above is from the completed passing run.
- Nine screenshots under `output/playwright/v14-{320,390,1280}-{help,team,confirm}.png` were inspected by the independent UI/UX reviewer. No blocking visual findings. The last card-level focus cleanup was rebuilt and the focused checks rerun; the full web workflow passed before that CSS-only cleanup.

The [independent parent review](AUDIT.md) passed with no blocking findings, covering UI/UX and the authentication proposal. Authentication remains unimplemented; hosted authenticated user acceptance remains separate from local browser verification and anonymous Access checks.

## Authentication discovery

The explicitly requested ultra-effort researcher produced [AUTH_ENFORCEMENT_OPTIONS](../AUTH_ENFORCEMENT_OPTIONS.md), with official primary sources and future acceptance cases. It supersedes the old UTC-day proposal with a rolling 24-hour window. The recommended strict official-service path is server generation/issuance with atomic account quota and immutable same-artifact retry binding. Email identifies an account; IP supports minimal, disclosed abuse controls and does not create fresh quota when it changes.

This requires a product decision about transient project uploads/processing and a capacity prototype: today's 100 MiB attachment allowance cannot simply be assumed to fit Free Worker body/memory/CPU limits. Keeping all project bytes local permits a narrower official-authorization guarantee. Neither approach can stop copying downloaded files, running old/local code, or using additional mailboxes. Applicable privacy obligations and processor retention must be resolved before activation; pseudonymized IP is not claimed anonymous.

## Protected preview release

Implementation and research committed/pushed as `53343211a2176be487c17fa8f58202146f3eac7e`. Wrangler exited 0. Cloudflare confirms successful preview `4dff21cf-d9cc-4ed4-94fe-4b11b5bf532e`, exact source SHA and `commit_dirty: false`.

- Testing: https://design-v14-preview.accreatio.pages.dev
- Immutable artifact: https://4dff21cf.accreatio.pages.dev
- Seven anonymous probes (alias, Blog API, brand asset, legal terms, immutable, retained v13 and production) return Access login redirects. Receipts: `.local/logs/legacy-20260905/.accreatio-v14-deploy.log`, `output/playwright/v14-access-after.json`.
- Retained v13 still points to `77e26090-6da5-4ef8-9627-6808760cef88`; canonical production remains `11235c8c-108f-46f3-8cce-fb88a144330b`, source `8735952c01560218d9dc5d95d5f298329f18d6e5`.

No production promotion, authentication activation, account or email operation, Access policy, D1 or desktop release change. A later documentation-only commit records the release.
