# Boxed configuration choices and rolling-quota discovery

Date: 2026-09-04. Owner-requested increment after v13, with an explicitly requested UI/UX adviser and an independent research agent at ultra reasoning effort for authentication options.

## Web UI

- Replace the small team disclosure with a full-width boxed **Configure agents and roles** control. Show an agent icon, explanatory line and disclosure chevron. Keep native details/summary semantics and existing automatic expansion for invalid roles. Scope the revised text and appearance to web; retained desktop behavior stays unchanged.
- Give each Confirm export radio option its own control card. Purple border, tinted background and the checked radio identify selection. Keep one visible card-level keyboard focus ring and the separate final execution button. Mode switching and execution logic are unchanged from v13.
- Place the reassurance first, then a centered row of FAQ/ToS controls beneath it. Keep both help targets at least 44px high, in document flow and present through the result screen.

The UX adviser proposed these changes before implementation. Existing control colors, radius, spacing, native inputs and night appearance are reused. The old AEKR footer stays intact.

## Authentication scope

Investigation only: the owner now specifies a maximum of five ZIPs within **any rolling 24-hour period**, not a fixed UTC calendar day. Evaluate a verified-email account, IP as a proportionate abuse signal, authoritative server enforcement, concurrency/retries, local/offline bypass limits, privacy and zero direct service cost. Do not implement sign-in, email sending, quota endpoints, storage or provider configuration in this increment. Record concrete choices and the achievable guarantee in `docs/AUTH_ENFORCEMENT_OPTIONS.md`.

## Verification and retention

Check repository tests, types, formatting, web/retained desktop builds, surface boundary and Electron smoke; exercise existing production-build web flow plus focused 320/390/1280 screenshots and keyboard/card/centering checks. Independent UI/UX review follows verification. No new implementation-mirroring unit tests are needed for these reversible presentation changes.

Retain v13 immutable deployment `77e26090-6da5-4ef8-9627-6808760cef88`, source `0f7e216a42783458f81bc6854c8f320c407b3052`, and `https://design-v13-preview.accreatio.pages.dev`. Use a new v14 protected preview for the verified increment. Production, Access policy, D1 and publisher configuration remain outside scope.
