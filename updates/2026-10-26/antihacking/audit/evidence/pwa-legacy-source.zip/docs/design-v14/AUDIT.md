# v14 independent parent review

Date: 2026-09-04. Reviewer: delegated UI/UX adviser and bounded parent reviewer, separate from the source implementer and authentication research author. The reviewer proposed the UI treatment but made no application source edits. Verdict: **PASS for this UI increment and discovery/design delivery**. No blocking findings. This is not authentication implementation acceptance or a legal compliance certification.

## UI evidence

Reviewed the five-file implementation/smoke diff, web versus desktop entrypoint imports, and nine `output/playwright/v14-{320,390,1280}-{help,team,confirm}.png` screenshots. Inspected `.local/logs/legacy-20260905/.accreatio-v14-ui.log`, `.local/logs/legacy-20260905/.accreatio-v14-cards.log` and `output/playwright/v14-cards-receipt.json`.

- Team configuration is a full-width boxed disclosure, with readable agent/role wording, supporting copy, icon and chevron at all three widths. Native details/summary behavior and invalid-role automatic expansion remain intact. The web-only CSS import and `isWeb` markup branch preserve the retained desktop presentation.
- Confirm export has separate native radio cards. Selected border is purple `rgb(177, 160, 248)` and selected background differs from the unselected surface. The card receives the visible focus ring. Observed card heights are at least 49px. The existing mode-change handler and separate final execution action are unchanged.
- FAQ/ToS follow the reassurance in DOM and visual order. Their measured center deviation is 0px at 320, 390 and 1280px, with approximately 5.6px between reassurance and navigation. They remain in document flow without overlaying the project surface or global footer.
- Production-build functional smoke reports PASS for ES 760px, EN 390px, ES 320px and reduced-motion EN 1280px, including validation, back/review navigation, keyboard use and confirmed ZIP bytes. Focused card checks report native keyboard operation, purple selection, centering and no browser errors.

Inspected the root's completed gate logs: 228 tests passed, zero failed; typechecks and formatting passed; web and retained desktop builds completed; surface boundary reported `ok: true`; Electron privileged execute smoke passed. These are reviewed execution receipts, not tests independently rerun by this reviewer.

## Authentication design evidence

Reviewed [AUTH_ENFORCEMENT_OPTIONS.md](../AUTH_ENFORCEMENT_OPTIONS.md) against the current local generator and domain attachment limits. The document correctly separates verified mailbox accounts, IP abuse signals and unique humans. It does not promise control of arbitrary locally generated ZIPs or a human-wide limit from email plus IP.

The rolling interval `(t - 24 hours, t]` replaces the earlier UTC calendar-day proposal. The design calls for a single authoritative atomic admission, account identity derived from the server session, account/operation uniqueness, immutable artifact binding, unchanged-content retries, final quota admission before release, bounded preparations and fail-closed failures. Concurrency and exact-window behavior are future acceptance cases, not claimed operational results.

Option C is conditional on accepting transient project upload/processing and proving capacity within zero direct service cost. Options B and D are explicitly narrower authorization/certificate limits. Current maximum attachment sizes, immutable retries, retention, account deletion/re-registration and provider logs are treated as unresolved design constraints rather than silently accepted changes. No auth endpoint, quota table, email sender, provider configuration or desktop implementation was added by the reviewed patch.

Primary-source spot checks support the principal feasibility and privacy boundaries: [Cloudflare Workers limits](https://developers.cloudflare.com/workers/platform/limits/) publish finite request, CPU and memory allowances; [D1 batch documentation](https://developers.cloudflare.com/d1/worker-api/d1-database/#batch) describes transactional batches and rollback. The proposed exact SQL/concurrency guarantee still needs a prototype. [GDPR](https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng) identifies IP-related online identifiers and conditions legitimate-interest processing on necessity and balancing. The research makes applicability conditional on jurisdictional facts and does not treat HMAC as anonymization or TTL as complete provider deletion.

The outstanding product decisions and acceptance cases are appropriate discovery outputs. This review does not authorize implementing C, changing the local-first privacy promise, adding paid services, or declaring authentication already enforced.

## Reviewed artifact hashes

SHA-256 of the reviewed working files:

| File | SHA-256 |
| --- | --- |
| `src/App.tsx` | `FE11279E54A74444F7E64DBDAEF3C6E4DB4578855CB4B64E05A225F58F591BA7` |
| `src/components/creation/GuidedCreation.tsx` | `9BCD75C351D0C7B9D7E5B568BD2C274875727805687D2558177DC7B0EC4C31DE` |
| `src/components/creation/ProjectHelp.tsx` | `8752685E1D23626E372EF733265C4757CFA6D861F7CD59D8BA3BE875A8D31EE2` |
| `src/web-branding.css` | `DB508870D7BD69CD98B3B107D636903DDE55C8E424E83316C36095212E44DE20` |
| `scripts/web-functional-smoke.mjs` | `A527B7D9BDAB988EEEC3AB3BBB23A541DC1B6DDB33C79A72AB2F52BE0CAB623E` |
| `docs/AUTH_ENFORCEMENT_OPTIONS.md` | `E6FCAE533E8C4AEA0B4972CF79BA8D84B68A4C82801552EF5E95E8D580B36D55` |

Deployment/readback remains the orchestrator's separate release evidence; this record makes no claim about a not-yet-inspected v14 deployment.
