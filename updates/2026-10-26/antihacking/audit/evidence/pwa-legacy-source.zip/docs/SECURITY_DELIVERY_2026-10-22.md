# Security delivery — 2026-10-22

Owner authorization covers security fixes, strict Word/PDF/image attachment admission, web-only retirement, provider-independent bot/flood protection, commit, push, merge and production publication.

## Independent baseline and candidate review

The immutable Standard scan 381e927b-528f-4962-88f9-4aee8c91eccd reviewed baseline c2235dccf759da2ff106d84d63a8496a5befcc65. It sealed two findings: medium CWE-1333 in the public Blog slug validator, and low conditional CWE-426 in retained Windows desktop command resolution. Coverage is partial: 104 tracked files fully reviewed from a 610-file inventory, with other files searched or selectively inspected. Independent production browsing used 45 GET responses, no login/mutation. Hostile DOM/ZIP and benign parent reproductions ran only in isolation; no production damage or flood test occurred.

A fresh pre-patch read-only investigator traced shared ingress and final export boundaries. A fresh candidate bypass reviewer identified two PDF admission cases: shared-child/cyclic page trees could expand before a bounded walk, and external stream file specifications could survive rewriting. The parent confirmed the source paths and both were corrected with regressions. The reviewer's subsequent turn was interrupted by OpenAI's cybersecurity filter. No retry or claim of a completed clean additional review is made.

## Outcomes and narrow boundaries

- **fixed — public Blog availability:** shared bounded linear slug admission is used for URL initialization/popstate and API records. The isolated long failing-input regression no longer blocks; published slugs and legacy trailing-hyphen behavior remain accepted.
- **retired — legacy desktop exposure:** documented desktop dev/build/test/package commands fail closed; default delivery is web-only. Electron/build tools were removed from active dependencies, while historical source/metadata remain in custody. The old bare-spawn source is not represented as patched or safe for independent execution.
- **implemented — strict local attachments:** DOCX/PDF/PNG/JPEG only; actual bounded parsing/reconstruction, a disposable worker and private Blob/filename proof at selection and final ZIP construction. Rejected inputs cannot reach archive retention, authorization or download. PNG/JPEG decode/re-encode strips original metadata/suffixes. See ATTACHMENT_SECURITY_2026-10-22.md for deliberately restricted compatibility.
- **implemented — provider-independent request controls:** production exact host allowlist before D1; preview has its separate exact hostname. Early unsupported method, URL and declared-body-size rejection; user-agent/provider/email aliases never receive new network budgets. Existing rights-only access and account-sanction attribution are preserved.
- **applied — Cloudflare edge:** Free plan Bot Fight Mode on; Agent/Training Block, Search Allow; zone-wide 100 requests/IP/10s, Block 10s; managed DDoS preserved. Dashboard settings were saved/reopened in the in-app browser; normal public browsing passed. No paid upgrade or traffic load test.
- **updated — notices and recovery:** privacy 2026-10-22b-privacy and Terms 2026-10-22b-beta disclose necessary provider security processing, attachment controls and web-only lifecycle; account-core-v1 unchanged, no historical acceptance backfill. Malformed browser draft shapes recover visibly without installing unsafe render values.

## Verification gates

1. Syntax/import/build: application and Functions TypeScript, generated Cloudflare types, Prettier, Functions compilation and web/PWA build PASS.
2. Security triggers/alternate forms: Blog long failing/percent-decoded values PASS; attachment renamed files, active/encoded/compressed PDF objects, external streams, page-tree DAG/cycle, XML entities/macros/relationships and expansion bounds PASS. Fourteen attachment tests include ordinary PDF navigation/annotation flags and deterministic DOCX controls.
3. Legitimate workflows/owning checks: `npm.cmd run log -- verify` exit 0, 452/452 tests; mailer/local dry run, pinned branding, Blog seed, examples, project map, publication/surface gate, web/account/identity/rights functional checks and Lighthouse PASS. Local log: .local/logs/2026-10-22T19-33-22-521Z-verify-0cc49a17-674f-40d7-aa56-a338b46feb4e.log.
4. In-app browser: disposable production-build attachment harness 10/10 PASS under equivalent self-only CSP; PNG/JPEG reconstruction/private proof, DOCX/PDF controls, forged SVG and active document rejection. Evidence: .local/logs/attachment-security/iab-validation-final.png.
5. Dependency inventory: npm audit reports zero known vulnerabilities after removing obsolete desktop tooling. This is a registry advisory result, not proof of unknown-vulnerability absence.
6. Lighthouse: performance 91, accessibility 100, best practices 100, SEO 69 under deliberate beta noindex; gate PASS.

The external AEKR checkout is unavailable, so its optional source-vendor comparison reports skipped; the pinned local assets/vendor payload/license checks pass. No personal Google/GitHub provider consent, physical Safari or account-rights action was performed on production. Local synthetic account proofs are distinct from real provider journeys.

The two synthetic sample ZIPs now contain admitted DOCX references, are extracted/read back, and carry source-file hashes independently of their recorded base revision. Generated project Markdown/JSON/YAML remain controlled product outputs.

## Release and limits

Production/source/merge/readback receipts are recorded below. No new D1 migration is required. Existing account/privacy configuration, quotas, security versions and policy/rights separation remain in force.

Browser code cannot be encrypted against its recipient or made impossible to inspect. File admission is not antivirus certification; complex unsupported documents fail closed, and unknown reader flaws remain possible. Zone protections do not cover every separate pages.dev alias; API host denial prevents D1 work but still invokes a Function. Distributed/rotating-IP attacks and shared-network interruption remain operational limits. There is no promise of unbreakable availability, permanent automatic closure or exhaustive audit clearance.

Workbench usage receipt: 26,449,235 total tokens (26,349,621 input, 99,614 output; 25,609,472 cached input; 27,498 reasoning output), source codex_rollout, seven bound threads. This is the tool's aggregate long-running thread measurement, not an isolated fresh-audit cost attribution.

## Production receipt

- Implementation source: `e30c6983b7df569ff50af81865e7e865500b8048`; inspected samples pinned by `fe8c14abb4a3d66e22acb1d732c998f9a1694db1`.
- PR [#10](https://github.com/edlopezpm-ops/accreatio/pull/10) merged as `a2fe8edee6358f5618b1013feb57d6fb7958a5c7`.
- The final visual pass found stale allowed-format/desktop wording in the public FAQ. PR [#11](https://github.com/edlopezpm-ops/accreatio/pull/11) aligns its ES/EN UI, full FAQ and web guide; final runtime/source is `e239ccb8bd8c9f3f715f6937eceaa685e1cee2bb`. Enforcement is unchanged. Thirteen affected existing tests and final web typecheck/build/publication checks pass.
- Production Pages deployment: `febdda0b-d860-4bf3-9cfc-48a123a72676`, https://febdda0b.accreatio.pages.dev, branch main, source e239ccb. Custom domain: https://accreatio.com/.
- Anonymous readback PASS: twelve exact-byte artifacts, including main JS/CSS, worker, SW, legal documents and sample exports. HTML shell matches after accounting for one expected Cloudflare Bot Fight Mode security injection; raw HTML is intentionally not byte-identical. Evidence: `.local/logs/security-release-20261022/readback.json`.
- Blog GET 200, unauthenticated account session 401, HSTS present. Both the default and deployment-specific pages.dev API hosts return 302 to the existing Cloudflare Access service before Functions. The canonical-host guard has local regression coverage and deployed source; a live 403 behind Access was not observed or claimed.
- In-app browser confirmed current web-only/obsolete/never-release About copy, the strict attachment policy and the final expanded FAQ after the normal service-worker update/reload. Evidence: `.local/logs/security-release-20261022/production-about.png`.
- New privacy/Terms/cookie versions are deployed. Existing account receipts were not backfilled; rights-only access remains independent.
- GitGuardian on PR10: PASS. Remote GitHub Actions cannot start the verify job because account payments/spending restrictions block execution; its check annotation confirms no steps ran. No spending limit, paid plan or billing setting was changed. Local full verification is the executed test evidence.

The first security deployment `201aeacc-02d7-4f9d-8b38-2db8f124e8b9` is superseded by the final FAQ-aligned deployment above. Historical earlier-day design/abuse receipts retain their original source and runtime scope. The public consolidated dossier is [the October 22 update](https://edlopezpm-ops.github.io/checkaccreatioandgivefeedback/update-2026-10-22.html).
