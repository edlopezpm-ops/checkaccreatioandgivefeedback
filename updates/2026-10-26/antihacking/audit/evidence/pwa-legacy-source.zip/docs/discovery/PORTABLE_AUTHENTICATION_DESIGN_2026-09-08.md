# Diseño portable de autenticación — accreatio, kommiBo y leudani

Fecha: 2026-09-08. Estado: **DISEÑO PROPUESTO; implementación y aceptación operativa pendientes**. Alcance autorizado: discovery y documentación. No cambia producto, infraestructura, proveedores, correo, facturación ni despliegues. Baseline coordinado: `origin/main` `8d44f75040fe923643f993a097b04f86aebde169`; el código de cuentas inspeccionado en `7daa9d73ae9f3e1de7b005880b4badd528c0b6ef` no cambia entre ambos según la comparación de rutas del coordinador. Las pruebas históricas del 05-Sep no son pruebas ejecutadas hoy.

## 1. Decisión propuesta y problema real

La mejor opción para este contexto es **Google mediante OIDC de servidor en accreatio, conservando sus cuentas, sesiones y cuotas propias**, y reutilizar políticas/contratos mediante adaptadores que respeten el sistema de cada producto. Google satisface la preferencia por un tercero de confianza alta y reduce dependencia del correo para ese login; no se promete fiabilidad del 100%. Conservar OTP con transporte intercambiable y capacidad explícita, sin anunciarlo como disponible para todo el público mientras no exista entrega aceptada y coste demostrado. Compartir un módulo TypeScript pequeño, inicialmente dentro de accreatio, y extraer un paquete cuando un segundo consumidor real lo necesite. No crear un servidor de identidad, un protocolo nuevo ni una base global de personas.

Cloudflare no es requisito de identidad: puede seguir alojando el backend y D1. Sustituir el transporte de correo no obliga a sustituir sesiones, cuentas, hosting o cuotas. La federación con Google evita enviar un correo OTP de la aplicación en cada login Google; no arregla por sí sola la entrega de correo de recuperación ni atiende a quien no quiera usar Google.

**accreatio ya tiene OTP propio.** `functions/_lib/accounts.ts` emite y verifica códigos y crea sesiones; `workers/account-mailer/` entrega los mensajes. El documento [OWN_EMAIL_OTP_2026-09-05](../OWN_EMAIL_OTP_2026-09-05.md) distingue implementación local de aceptación de entrega alojada. No describirlo como ausencia de OTP ni como autenticación del producto delegada actualmente a Access. Access conserva una frontera administrativa separada. La disponibilidad/configuración viva del proveedor no se revalidó en este diseño.

Defaults que permiten implementar sin nuevas decisiones de producto: **Google como login normal por defecto en accreatio**, OTP aislado/opcional y sólo ofrecido cuando su transporte tenga aceptación y capacidad, altas limitadas, cero gasto adicional, ninguna fusión automática, sesiones por producto y permisos locales. Passkeys se incorporan en el incremento de operaciones sensibles. Entra ID sólo ante una audiencia empresarial concreta; AD FS sólo compatibilidad con infraestructura existente. Ninguna de estas decisiones autoriza activaciones o gastos. Una cuenta legacy sin otro método disponible no puede migrarse por coincidencia de email: se conserva y se exige recuperar prueba del método original antes de linking, aunque temporalmente no pueda entrar.

## 2. Separación de conceptos

SSO es la experiencia de reutilizar una autenticación entre aplicaciones; IdP es el rol que emite identidad; OIDC y SAML son protocolos de federación; OTP, contraseña y passkeys son métodos de autenticación. No son alternativas del mismo nivel. OAuth sin la validación de identidad correspondiente tampoco basta para autenticar. El objetivo es una integración sencilla y segura, no maximizar el número de métodos.

| Capa             | Responsabilidad                                                                      | No demuestra                                                               |
| ---------------- | ------------------------------------------------------------------------------------ | -------------------------------------------------------------------------- |
| OTP propio       | Crear reto, secreto de un uso, vencimiento e intentos; verificar posesión del correo | Persona única, identidad legal, segundo factor independiente               |
| Transporte email | Entregar un mensaje solicitado                                                       | Cuenta autenticada; aceptación SMTP/API tampoco prueba llegada a inbox     |
| Federación OIDC  | Validar una identidad emitida por un IdP                                             | Permiso de publicar, tenant autorizado, MFA reciente por el nombre del IdP |
| Sesión propia    | Mantener autenticación y revocación de este producto                                 | Que otra aplicación de la suite deba confiar en ella                       |
| Autorización     | Resolver actor, producto, tenant, recurso y acción                                   | Que un correo verificado sea administrador                                 |
| Step-up          | Obtener una prueba adicional o más reciente para una acción                          | Conformidad NIST automática                                                |

Email OTP es un acceso de conveniencia de garantía limitada. NIST SP 800-63B-4 excluye email como autenticación fuera de banda; no etiquetar esta ruta como MFA robusto ni AAL2. Una passkey con verificación de usuario puede aportar propiedades fuertes, pero la clasificación AAL depende de implementación, autenticador, política y recuperación completas. Este diseño no certifica niveles. [NIST SP 800-63B-4](https://pages.nist.gov/800-63-4/sp800-63b.html).

Google documenta `amr` y `auth_time` **opcionales**, sujetos a solicitud y habilitación. La ausencia de esas claims equivale a garantía federada no especificada. `iat` no sustituye `auth_time`; mostrar selector de cuenta tampoco exige MFA reciente. Sólo un adaptador con contrato de claims probado puede mapearlas a una política explícita. [Google OIDC](https://developers.google.com/identity/openid-connect/openid-connect).

## 3. Fronteras y portabilidad

El BFF, cookie propia y esquema descritos a continuación son la implementación recomendada **para accreatio**. El contrato común expresa identidad validada, política, autorización y resultados; no obliga a que leudani, cuyo ADR excluye BFF y fija Supabase Auth, replique ese backend. kommiBo conserva su implementación existente. Esta distinción es normativa para todo el documento.

```mermaid
flowchart LR
  B[Navegador del producto] -->|Cookie propia| F[BFF HTTP del producto]
  F --> A[Servicio de autenticación y políticas]
  A --> O[Adaptador OIDC con biblioteca mantenida]
  O --> G[Google o IdP empresarial permitido]
  A --> E[OTP y transporte email enchufable]
  A --> W[Adaptador WebAuthn opcional]
  A --> S[Almacén de identidad y sesiones del producto]
  F --> P[Autorización local de recursos y tenants]
  P --> Q[Cuotas y operaciones del producto]
  B --> L[Borradores locales; sin contenido en autenticación]
```

El núcleo acepta Web `Request`/`Response` sólo en su frontera HTTP; reglas y DTOs no importan D1, Wrangler, React, Electron ni SDK de correo. `IdentityStore` expresa operaciones atómicas concretas, no SQL arbitrario. Implementar primero D1 y un almacén local de prueba con las mismas invariantes; un adaptador Node/SQLite o PostgreSQL se construye cuando exista un consumidor. El contrato portable no promete que todos los motores tengan el mismo aislamiento.

Almacenes iniciales separados para cada producto: identificadores, secretos, cookies, clientes OIDC, RP ID, rate limits y retención propios. Una persona puede tener tres cuentas independientes. No correlacionarlas por email; no compartir cookies de dominio padre. No trasladar cuentas/borradores/cuotas a kommiBo o leudani. SSO central, SCIM, directorio común, SAML y delegación entre servicios quedan fuera hasta necesidad concreta. Es una reducción de superficie operativa y de impacto entre productos, no una limitación del estándar.

`ProviderConfig` se despliega como configuración confiable: `providerKey`, issuer HTTPS exacto, client ID, referencia de secreto, redirect URI exacta, scopes, capacidades probadas y política de claims. No aceptar discovery URL, issuer, redirect ni tenant arbitrarios aportados por el navegador. Un nuevo IdP empresarial requiere un registro configurado y validado; sin descubrimiento dinámico de dominios de usuarios. Ninguno de los tres productos necesita hoy multi-tenancy: no crear tablas/membresías por anticipación. La frontera tenant sólo se activa si un producto futuro la requiere expresamente.

## 4. Bibliotecas y alternativas de implementación

La selección se contrasta con cuatro familias. La decisión es A para accreatio; las otras filas explican por qué no abren roadmaps paralelos.

| Familia                                           | Evaluación frente a seguridad, simplicidad y coste                                                                                                                          | Decisión                                                                                           |
| ------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| A. IdP reconocido + cuentas/sesiones del producto | Google OIDC con biblioteca mantenida cambia poco del backend existente; mantiene control de cuotas y minimiza datos. Requiere validar integración y operar sesiones propias | **Elegida para accreatio**, por menor migración y ajuste al proveedor de confianza alta solicitado |
| B. Framework OSS completo                         | Better Auth facilita más funciones, pero sus defaults/esquemas requieren adaptar linking, sesiones y almacenamiento de tokens; no elimina correo/hosting                    | No reemplazar ahora un sistema existente sólo por uniformidad                                      |
| C. Auth gestionado                                | Supabase Auth encaja en leudani por contrato existente; Entra External ID es otra plataforma CIAM, distinta de añadir login Microsoft                                       | Mantener Supabase en leudani; no migrar accreatio sin necesidad adicional                          |
| D. IdP operado por nosotros                       | Keycloak o una nueva granja AD FS añaden servidor, copias, certificados, actualizaciones y respuesta a incidentes                                                           | No elegirlos para este alcance y presupuesto; AD FS sólo integración de cliente que ya lo opere    |

Microsoft Entra ID es la extensión empresarial preferida si existe una audiencia real; Microsoft recomienda migrar de AD FS a Entra en su guía de despliegue. No hay evidencia de una infraestructura AD FS existente y gratuita para estos productos. SAML queda reservado a exigencia empresarial concreta; LDAP/AD directo, WS-Federation y contraseñas del IdP recogidas por nuestra app no forman parte del perfil nuevo. [Microsoft AD FS](https://learn.microsoft.com/en-us/windows-server/identity/ad-fs/ad-fs-deployment), [Entra OIDC](https://learn.microsoft.com/en-us/entra/identity-platform/v2-protocols-oidc).

Contraseñas propias se preservan donde ya existen (kommiBo; objetivo de internos leudani), sin introducirlas en accreatio. SMS añade coste, recuperación y riesgos de canal; no se selecciona. TOTP puede ser segundo factor cuando la plataforma lo soporte y la política lo requiera, pero no aporta resistencia al phishing de passkeys. Magic links siguen dependiendo de correo y pueden filtrarse/abrirse por escáneres; no resuelven el problema de transporte. No incorporar proveedores adicionales de menor confianza por el solo hecho de ofrecer un free tier.

| Componente         | Selección propuesta                                                                  | Evidencia y límite                                                                                                                                                                                                                                            |
| ------------------ | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Cliente OAuth/OIDC | `openid-client` v6 mantenido; fijar versión exacta y lockfile al implementar         | MIT; documenta Workers, Electron y Node 20+ con Fetch/WebCrypto. Validación real de bundling, metadata y callback pendiente. [Repositorio oficial](https://github.com/panva/openid-client)                                                                    |
| WebAuthn           | `@simplewebauthn/server` y `@simplewebauthn/browser`, fase posterior                 | MIT. Documentación actual del servidor: Node 22+ y Deno 2.4+; compatibilidad del bundle con Workers exige spike. [Servidor](https://simplewebauthn.dev/docs/packages/server), [licencia](https://github.com/MasterKale/SimpleWebAuthn/blob/master/LICENSE.md) |
| Sesiones/OTP       | Conservar contratos y controles actuales y extraer funciones pequeñas                | No reimplementar JWT, JOSE, PKCE, WebAuthn ni primitivas criptográficas. Usar bibliotecas y WebCrypto/CSPRNG; pruebas de flujo siguen siendo responsabilidad del producto                                                                                     |
| Framework de auth  | Better Auth como alternativa a evaluar si el segundo producto necesita más funciones | La selección definitiva requiere demostrar mapeo de IDs, hashing/revocación, concurrencia, linking y migración. No adoptar esquemas por defecto que cambien cuentas o activen linking por email                                                               |

La recomendación no es construir un mini-IdP. Se añade un cliente OIDC mantenido a un sistema pequeño ya existente. Better Auth permite impedir linking implícito, pero su esquema documenta campos de tokens OAuth, IP y user-agent: evitar una cookie o cifrar tokens no evita persistencia en DB. Cualquier adopción futura exige demostrar nuestras invariantes; hoy no se abre esa migración. Auth.js sigue mantenido, aunque sus mantenedores recomiendan Better Auth para proyectos nuevos. [Better Auth database](https://better-auth.com/docs/concepts/database), [linking](https://better-auth.com/docs/concepts/users-accounts), [anuncio oficial Auth.js](https://better-auth.com/blog/authjs-joins-better-auth).

Snapshot de mantenimiento verificado por el agente de alternativas con API GitHub oficial el 08-Sep: `openid-client` 6.8.8 (MIT, 05-Sep), Better Auth 1.7.3 (MIT, 06-Sep), Auth.js `next-auth` 4.24.15 (ISC, 20-Jul), Keycloak 26.7.3 (Apache-2.0, 31-Ago), repositorios no archivados. Revalidar versión/advisories al implementar; esto no audita dependencias ni demuestra compatibilidad. [openid-client release](https://github.com/panva/openid-client/releases/tag/v6.8.8), [Better Auth release](https://github.com/better-auth/better-auth/releases/tag/v1.7.3), [Auth.js release](https://github.com/nextauthjs/next-auth/releases/tag/next-auth%404.24.15), [Keycloak release](https://github.com/keycloak/keycloak/releases/tag/26.7.3).

## 5. Identidad, vinculación y autorización

La clave primaria de dominio sigue siendo `accounts.id`. Identidad federada = pareja validada `(issuer, subject)` dentro del producto; `subject` conserva mayúsculas y bytes. Email es un atributo/contacto con estado de verificación, procedencia y fecha, no una clave federada. No eliminar puntos, sufijos `+` ni aplicar equivalencias de Gmail. La normalización legacy de accreatio (`trim().toLowerCase()` en el subconjunto ASCII actual) queda intacta para sus identidades previas.

Política cerrada v1: **alta federada nueva sólo con Gmail (`@gmail.com`) o Google Workspace**, ID token validado, email presente y `email_verified=true`; para Workspace exigir `hd` no vacío validado. Este uso de `hd` prueba la autoridad de Google sobre el buzón, no añade restricción empresarial ni permiso. Mostrar la cobertura junto al alta. Una cuenta Google con email externo sin `hd`, incluso con `email_verified=true`, no crea/reserva una cuenta por ese email en v1: puede vincularse a una cuenta existente después de probar su método actual, cuando linking esté aceptado. Una cuenta sin Google tampoco queda cubierta por este piloto hasta que OTP tenga transporte aceptado. No exigir entrega OTP para altas Gmail/Workspace. Ampliar a email externo requerirá verificación separada del buzón y aceptación de esa capacidad; no cambiar silenciosamente este default.

Una identidad **ya vinculada** sigue entrando por issuer/sub aunque cambie su email o pierda `hd`; eso no cambia el principal ni las cuotas. Si la nueva claim no tiene autoridad suficiente sobre el buzón, no sobrescribir el contacto de recuperación verificado: conservar el contacto previo y marcarlo para revisión proporcional en UI. Una claim externa observada sólo vive en la transacción; no se guarda ni reserva otro email automáticamente. Tampoco un contacto verificado confiere privilegios o recupera una cuenta fuerte por sí solo.

Flujo de resolución:

1. Una identidad externa ya vinculada resuelve el mismo `account_id`, aunque cambie su email. Comprobar que cuenta/identidad no están revocadas o suspendidas.
2. Identidad nueva sin colisión: alta explícita, aceptación informada y transacción que crea cuenta e identidad. Mantener el techo de cuentas y controles de admisión globales en **todos** los métodos, no sólo OTP.
3. Si el email coincide con una cuenta previa, no iniciar sesión en ella ni crear automáticamente una cuenta alternativa. Mostrar un paso neutro: iniciar sesión mediante un método existente para vincular. La respuesta pública no confirma existencia ni revela métodos inscritos. Se puede ofrecer siempre “Ya tengo una cuenta” en la pantalla de alta; los errores usan el mismo resultado genérico.
4. Linking exige sesión actual, reautenticación reciente y prueba del nuevo IdP en una transacción dedicada `purpose=link`. Fijar `targetAccountId`, sesión iniciadora y versión de seguridad en servidor; el callback no puede cambiar el destino. Un usuario OTP existente puede acreditar nuevamente OTP para el primer enlace: mejora conveniencia, no aumenta la garantía del método original. En cuentas con passkey/política fuerte, exigir ese nivel; el correo no lo rebaja.
5. La restricción única `(issuer, subject)` hace que dos enlaces concurrentes tengan un único ganador. Si está vinculada a otra cuenta, rechazar sin trasladarla. Fusión de dos cuentas existentes queda deshabilitada; no resetear ni sumar parcialmente cuotas mediante un cambio de identidad.
6. Desvincular exige prueba reciente y otro método utilizable. Nunca quitar el último método ni el último factor exigido por política. Revocar sesiones creadas con la identidad retirada y transacciones pendientes.

Google advierte que el email cambia y no sirve de identificador único; el `sub` sí es estable para la cuenta. Las restricciones Workspace, cuando se pidan, verifican la claim `hd` validada, no el sufijo visible del email. Tampoco `hd` otorga por sí sola roles internos. [Referencia Google OIDC](https://developers.google.com/identity/openid-connect/reference).

El permiso se evalúa con `actor + product + tenant + resource + action`, en servidor y por defecto denegado. `tenantId` enviado por cliente sólo selecciona contexto; comprobar membresía activa. Cambio de rol incrementa versión de autorización e invalida cachés/sesiones de privilegio. No conceder acceso editorial por tener una cuenta normal. La frontera actual de Blog/administración permanece separada durante esta migración.

## 6. Flujo web OIDC y cookies

```mermaid
sequenceDiagram
  participant U as Navegador
  participant B as BFF del producto
  participant D as Store
  participant I as IdP permitido
  U->>U: Persistir y confirmar borrador
  U->>B: POST /api/auth/v1/oidc/google/start
  B->>D: Crear transacción breve con state, nonce y PKCE
  B-->>U: URL autorizada y cookie transaccional Lax
  U->>I: Navegación al authorization endpoint
  I-->>U: Redirección al callback registrado
  U->>B: GET callback con code y state
  B->>D: Reclamar transacción ligada al navegador
  B->>I: Canjear code con PKCE S256
  I-->>B: Tokens
  B->>B: Biblioteca valida firma, issuer, audience, nonce y tiempos
  B->>D: Resolver identidad y crear sesión en operación atómica
  B-->>U: Cookie propia Strict y 303 a ruta limpia
  U->>B: GET sesión propia
```

Usar Authorization Code con PKCE S256, `state` y `nonce` independientes, aleatorios y de un uso. TTL de transacción propuesto: 10 minutos. Fijar issuer, client y callback por configuración; defensa de mix-up por respuesta issuer validada o callback distinto por IdP. El retorno es una clave de ruta interna permitida, no una URL abierta. Rechazar parámetros duplicados críticos. La biblioteca verifica firma/algoritmo, `iss`, `aud`, `azp` cuando corresponda, `exp`, `iat`, nonce y requisitos del flujo; algoritmo permitido por configuración y metadata confiable. [OAuth Security BCP, RFC 9700](https://www.rfc-editor.org/info/rfc9700/), [OIDC Core](https://openid.net/specs/openid-connect-core-1_0.html).

Guardar hashes de `state` y del secreto de vinculación al navegador; **guardar nonce original y verificador PKCE juntos en un ciphertext breve** con clave independiente, versión y TTL. Descifrar el nonce para pasar `expectedNonce` a `openid-client` durante canje/validación; un hash de nonce no sustituye ese valor. Borrar nonce/PKCE al completar, fallar o expirar. `state` no lleva email, borrador ni tokens. Cookie transaccional `__Host-<product>_auth_tx`: Secure, HttpOnly, Path=/, SameSite=Lax, sin Domain; valor opaco 256 bits. La sesión final puede conservar SameSite=Strict. La cookie Strict actual no llega en el retorno externo; un linking callback usa la sesión capturada en la transacción y comprueba en store que sigue activa y no revocada. No confiar en un `accountId` del callback.

Mantener un solo flujo interactivo activo por navegador/perfil y producto; iniciar otro cancela el anterior de forma explícita. El binding de transacción se conserva hasta su TTL para que la pestaña original pueda observar el resultado del popup; completar callback elimina los secretos de canje pero no invalida esa consulta de estado. El binding no concede sesión ni permite consumir otra vez el callback. Claims críticas ausentes o alta fuera de la política Gmail/Workspace impiden crear cuenta; identidades ya vinculadas se resuelven según sección5. Nunca rellenar claims con valores del navegador.

`start` es una mutación same-origin con protección CSRF; devuelve JSON con URL generada exclusivamente por servidor para navegación explícita. El callback externo tiene su validación específica, no la regla `Origin` de los POST de la aplicación. `SameSite=Lax` funciona para el callback GET de este perfil; `form_post` queda deshabilitado salvo diseño separado. Callback y rutas auth: `Cache-Control: no-store`, `Referrer-Policy: no-referrer`; ningún recurso tercero ni render con el código en URL. Tras validar, 303 a ruta limpia; fallos también limpian parámetros sin reflejar contenido del IdP.

Guardar ID/access tokens únicamente durante validación y descarte en memoria. Solicitar `openid email`; añadir `profile` sólo si existe un uso aprobado. No `offline`, `offline_access`, Drive, Gmail, Calendar ni refresh tokens para autenticar. Secretos de cliente son configuración del backend, nunca frontend; no son credenciales del usuario. El navegador sólo recibe la sesión propia.

La aplicación actual usa `fetch` con redirecciones rechazadas en `src/account/webClient.ts`. Mantener ese comportamiento para APIs existentes; introducir una acción de navegación específica. **El flush actual no conserva adjuntos:** `src/draftStore.ts` guarda `attachments:[]` y contador; `flushDraftBeforeSignIn` de `src/App.tsx` no persiste bytes de `webAttachments`. Por tanto guardar campos no permite prometer conservación de archivos después de una redirección principal.

Estrategia elegida sin nuevos almacenes/uploads: si hay adjuntos transitorios, **mantener viva la pestaña de edición y abrir OAuth en una ventana separada**. Preabrir ventana vacía same-origin durante el click para obtener handle y detectar bloqueo; anular `opener` antes de navegarla al IdP, sin usar una opción `noopener` que impida obtener ese handle. Luego crear transacción same-origin y navegar esa ventana al IdP. El callback escribe cookie propia y muestra resultado mínimo; no necesita `opener` ni envía tokens por `postMessage`. La pestaña original consulta estado de su transacción cada 2s como máximo, con backoff hasta 10s, cancela al vencer 10min y relee la sesión cuando el servidor informa `completed`. El polling sólo consulta identificador opaco ligado al secreto transaccional del navegador; devuelve estado, nunca tokens/subject/email. No interpretar `window.closed` como éxito o fallo definitivo: COOP puede separar contextos.

Popup bloqueado/cancelado, error de persistencia, pérdida de red o soporte insuficiente en PWA: conservar campos/bytes en la pestaña y ofrecer reintento o seguir editando; **nunca fallback automático a redirección principal con adjuntos**. Sin adjuntos, la navegación principal es admisible sólo tras confirmar persistencia de campos. Un cambio de cuenta no borra ni sube el borrador. Este mecanismo no protege contra cerrar/crashear la pestaña original; explicarlo al usuario en la acción pertinente, sin fingir persistencia de bytes. No reutilizar el `.catch(() => {})` actual de `onBeforeSignIn` para redirección. Probar con blobs reales, popup bloqueado, COOP, PWA vieja/nueva y fallo IndexedDB; no enviar borrador al IdP ni usarlo en state.

## 7. OTP y entrega intercambiable

Mantener base actual: seis dígitos uniformes CSPRNG; 10 minutos; cinco intentos; espera de reenvío de 60 segundos; límite por identidad, IP seudonimizada y global; HMAC-SHA-256 con secreto independiente, propósito, challenge e identidad. La clave OTP no se reutiliza como identidad ni sesión. Separar propósito `sign_in`, `link_existing`, `verify_contact` y `recovery`; un código de un propósito no autoriza otro.

Puerto propuesto `EmailTransport.sendOtp({deliveryId, recipient, code, expiresAt, locale, templateVersion}) -> {status: accepted|rejected|unknown}`. Datos transitorios mínimos; remitente y plantilla controlados por servidor. No HTML de usuario, píxeles, suscripciones ni contenido de proyecto. Timeout y errores se traducen a códigos públicos estables; nunca volcar respuesta cruda del proveedor.

`accepted` significa aceptación del proveedor, no inbox. `unknown` tras timeout no dispara fallback automático que pueda duplicar mensajes; invalidar el reto y permitir un nuevo intento tras cooldown, contando también el intento fallido en capacidad. Cambiar de transporte requiere idempotencia documentada y prueba de entrega; por defecto es una conmutación de configuración para nuevas solicitudes, no reintentos entre proveedores.

Los defaults actuales de admisión son 5 solicitudes/email/hora, 20/IP/hora, 90/global/24h y 1.000 cuentas activas; son configuración de producto, no promesa de capacidad gratuita. Mantenerlos inicialmente y reducirlos si el proveedor permite menos. Presupuestar todos los mensajes, incluidos recuperación, cambios de método y avisos. Reservar una fracción operativa para recuperación antes de aceptar nuevos OTP. Si no hay cuota, fallo controlado que conserva el borrador y permite métodos alternativos ya vinculados; nunca activar facturación automática.

El vínculo al navegador y propósito también aplica a nuevos retos OTP. Las ventanas/contadores y el consumo se deciden mediante reloj y escritura condicional del store. Un código correcto sólo gana una vez aunque lleguen solicitudes concurrentes desde varias instancias. No usar memoria local o KV eventualmente consistente como autoridad de consumo/revocación.

## 8. Sesiones, step-up y recuperación

Sesión web opaca de 256 bits, hash SHA-256 en store, cookie `__Host-<product>_session`, Secure/HttpOnly/Strict, Path=/ y sin Domain. Mantener duración absoluta de 24h en accreatio al introducir OIDC; no introducir renovación silenciosa de terceros ni “recordarme” de larga duración. El perfil administrativo futuro usa TTL absoluto de 8h, inactividad de 30min y prueba fuerte de menos de 5min para operaciones críticas. Son políticas propuestas, no garantías actuales.

Rotar token propio tras login, step-up, recuperación y elevación de privilegios; no rotarlo en cada request. La transacción inserta nueva sesión y revoca la anterior mediante CAS/versionado: sólo un ganador y sin período de gracia que permita mutaciones con el token viejo. Una pestaña concurrente rechazada vuelve a leer sesión; no sobrescribe ni borra una cookie nueva por recibir un 401 antiguo. Una respuesta perdida tras la rotación permite reautenticarse, no recuperar el token a partir del hash.

Logout revoca la sesión actual; “cerrar todas” incrementa `security_version` y revoca todas. Cada operación sensible comprueba versión y estado actual de cuenta en la misma frontera transaccional que la autorización; sólo un precheck fuera de transacción deja una carrera con logout. Logout del producto no cierra Google. Revocación o suspensión del IdP puede no propagarse inmediatamente: la sesión propia vive hasta su TTL o una revocación local. Integrar señales/back-channel sólo si proveedor y caso real lo permiten; mientras tanto no prometer logout global.

Passkeys: activación posterior, RP ID y orígenes HTTPS estables por producto; enrolamiento ligado a sesión con prueba reciente. `userVerification=required` para step-up, challenge aleatorio de un uso, TTL 5min, verificación por biblioteca de challenge/origin/RP ID/firma/UV. Guardar clave pública, credential ID, contador y flags de respaldo; nunca clave privada ni biometría. Política inicial sin attestation identificadora (`none`). Tratar contadores y credenciales sincronizadas según biblioteca/especificación; contador cero no prueba clonación. [WebAuthn Level 3](https://www.w3.org/TR/webauthn-3/).

Los RP ID no se transfieren automáticamente entre dominios. No prometer una sola passkey para tres sitios; usar credenciales por producto. No fijar RP ID al hostname efímero de preview para credenciales de producción. Los orígenes accreatio documentados son `accreatio.pages.dev` y el alias `archive-email-auth-preview.accreatio.pages.dev`; no se acredita un dominio personalizado nuevo. Elegir y verificar origen/RP ID estable **antes** de enrolar passkeys y validar propiedad/branding del callback Google por entorno. Cambiar a un dominio propio puede exigir reenrolamiento. La prueba virtual del navegador sirve para protocolo; hace falta una passkey real y recuperación en navegador/dispositivo soportado antes de habilitarla.

Política de garantía: `email-possession`, `federated-unspecified`, `webauthn-uv` y, sólo con contrato probado, `federated-policy:<id>`. Son etiquetas de política interna, no AAL. La capacidad solicitada define prueba requerida y antigüedad; el usuario ve una acción concreta, no estas etiquetas. Añadir passkey no debe dejar una vía OTP que eluda la misma protección para cambiar métodos o recuperar control.

Recuperación propuesta: ofrecer segunda passkey y ocho códigos de recuperación de al menos 128 bits aleatorios, mostrados una vez, hashes en store y consumo atómico. Un código crea **sesión restringida** de 10min para enrolar un método de reemplazo, sin exportar datos, cambiar permisos, vincular IdP ni eliminar la cuenta; completar recuperación revoca sesiones y códigos restantes y exige generar un juego nuevo. Para cuentas privilegiadas se requiere otro factor previamente inscrito o procedimiento del tenant documentado; no correo como bypass.

Cuenta básica sin passkeys puede repetir su método OTP/IdP disponible. Si pierde todos los métodos/códigos, no recuperar por coincidencia de email, información pública o solicitud a soporte. Mantener bloqueo y proceso excepcional definido por producto, o reconocer que no existe recuperación segura automática. No crear un sistema de prueba de identidad legal. Si se pierde acceso al correo pero sigue disponible una passkey fuerte, permitir cambiar contacto con prueba reciente y verificar nuevo correo, sin cambiar `account_id` ni cuotas. La indisponibilidad de transporte impide verificar nuevo contacto, no destruye la sesión o borrador.

## 9. Modelo de datos aditivo y versiones

Este es un esquema lógico para la implementación; no se ejecuta SQL en discovery. Conservar tablas `accounts`, `account_sessions`, `export_authorizations`, `account_otp_challenges` y sus datos. Una migración nueva no modifica `0001`/`0002` ni vuelve a ejecutar su `DELETE FROM account_sessions` histórico.

| Entidad propuesta                  | Campos esenciales e invariantes                                                                                                                                                                                                                                                                           |
| ---------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `accounts` ampliada                | `security_version DEFAULT 0`, `authz_version DEFAULT 0`, `identity_scheme DEFAULT legacy-email-v1`; `email_ciphertext`, `email_encryption_key_version`, `email_lookup_key`, `email_lookup_key_version`, `email_verification_source`, `email_verified_at`; conserva id, identity_key, timestamps y borrado |
| `account_external_identities`      | id, account_id FK, issuer, subject, provider_key, created_at, last_authenticated_at, revoked_at; UNIQUE(issuer,subject), índices por account_id; cuenta asignada inmutable salvo proceso explícito futuro                                                                                                 |
| `account_auth_transactions`        | id, purpose, state_hash UNIQUE, browser_binding_hash, encrypted_nonce_and_pkce, key_version, provider_key, target_account_id nullable, initiator_session_hash nullable, captured_security_version, return_route, status, claim_nonce, expires_at; purpose/estado con CHECK                                |
| `account_auth_tombstones`          | account_id FK, locator_kind, key_version, locator_hmac, expires_at; UNIQUE(locator_kind,key_version,locator_hmac); sólo localizadores protegidos de email e issuer/sub, sin PII cruda                                                                                                                     |
| `account_session_metadata`         | token_hash PK/FK a account_sessions, session_id UNIQUE, method, credential_or_identity_id nullable, authenticated_at, step_up_at nullable, assurance_policy, security_version, authz_version, created_at; índice por cuenta vía sesión                                                                    |
| `account_webauthn_credentials`     | credential_id UNIQUE, account_id FK, user_handle opaco estable, public_key, counter, backed_up/device_type, created_at, last_used_at, revoked_at; sin biometría                                                                                                                                           |
| `account_recovery_codes`           | code_hash UNIQUE, account_id FK, batch_id, created_at, consumed_at; consumo y sesión restringida indivisibles                                                                                                                                                                                             |
| `account_security_events` opcional | event_id, event_type, outcome, policy_version, time_bucket; sin email, IP ni ID estable del usuario; sólo si se autoriza retención operacional                                                                                                                                                            |

No implantar tablas de passkeys/recuperación hasta su fase. V1 usa **una sola ubicación de email: `accounts` ampliada**, para todos los métodos. No añadir `account_contacts` ni un flujo completo de cambio de contacto por adelantado. `email_lookup_key=HMAC(EMAIL_LOOKUP_KEY, normalizedEmail)` con secreto por producto distinto de `ACCOUNT_IDENTITY_KEY`/AEAD; índice único para contactos de cuentas activas. Colisión, alta, exportación, backfill y tombstones usan el mismo contrato de lookup/versionado. `accounts.email` plaintext sólo convive temporalmente durante expand/contract de sección14 y se retira al terminar. V1 incluye identidad externa, transacciones, localizadores de continuidad, versión y metadatos de sesión. Membresías de tenant sólo para productos que las requieran.

Detalle de compatibilidad: `accounts.identity_key` actual es `NOT NULL UNIQUE`. Las cuentas legacy conservan exactamente `HMAC(ACCOUNT_IDENTITY_KEY, normalizedEmail)`. Para alta exclusivamente federada usar `identity_scheme=federated-v1` y un identificador opaco con prefijo no hexadecimal, por ejemplo `fed-v1:<UUIDv4>`, independiente del email. El prefijo no colisiona con los hashes legacy de 64 hex. Las futuras altas OTP también deben consultar la política de contactos/identidades para no duplicar una cuenta federada; si se detecta colisión requieren linking explícito desde esa cuenta. No hacer `UPSERT` de cuenta por email OIDC.

`ACCOUNT_IDENTITY_KEY` se conserva y no rota como parte de esta migración. Su futura rotación necesita índice de alias versionado y transición que siga resolviendo tombstones/cuotas; no basta reemplazar el secreto. Secretos separados para OTP, cifrado breve OIDC y seudonimización de abuso, con key IDs. Rotar el secreto OTP invalida retos pendientes de forma acotada; rotar OIDC permite lectura breve con clave anterior o cancela transacciones. Los tokens propios aleatorios no necesitan clave de firma.

Continuidad obligatoria v1: al borrar una cuenta, **antes de retirar subjects/email crudos**, crear en la misma transacción localizadores de todos sus métodos en `account_auth_tombstones`. Para federación: `locator_hmac=HMAC(AUTH_LOCATOR_KEY_v, UTF8(JSON.stringify(["external-subject-v1", issuer, subject])))`, serialización JSON compacta de array de strings con issuer/subject validados, sin concatenaciones ambiguas; persistir versión, `account_id` y expiración a 48h del borrado. Para email usar su lookup protegido y versión. La clave locator es independiente; fixtures fijan bytes/digests de serialización entre adaptadores. Revocar sesiones/transacciones, retirar identidad externa cruda y purgar contacto en esa operación. No existe tombstone con subject crudo.

Todo login/alta consulta localizadores vigentes antes de crear cuenta. Prueba del mismo issuer/sub dentro de ventana reactiva **el mismo account_id y receipts**; otro subject con email coincidente no lo recupera. Reingreso OTP exige su propia prueba. Restore del mapping, estado de cuenta y sesión comparte una transacción; unicidad/nonce determina un ganador concurrente. Si la identidad/localizador apunta a otra cuenta, abortar y mantener datos, sin traslado o fusión. No renovar TTL por consultas ni intentos fallidos. Expirado el localizador, se elimina con mantenimiento acotado; una nueva alta fuera de ventana sigue la política publicada. Preservar la semántica legacy `ACCOUNT_IDENTITY_KEY` y cleanup actual durante transición; la purga programada objetivo de sección14 evita retención indefinida. Probar delete/recreate Google-only y carrera contra otra alta antes de aceptar A6.

Versionar contrato `auth.v1`, políticas con identificador inmutable y migraciones por número/checksum. Campos nuevos opcionales en DTOs existentes; no alterar tipos ni nombres de `/api/account/*` durante compatibilidad. Nuevos campos de seguridad sólo se aceptan de servidor. Un consumidor debe soportar explícitamente la versión; nunca degradar silenciosamente una política no reconocida.

## 10. Contratos y endpoints

```ts
// Contratos propuestos, no código instalado.
type AuthMethod = "email-otp" | "oidc" | "passkey" | "recovery-code";
type Purpose = "sign-in" | "link" | "step-up" | "verify-contact" | "recovery";
interface AuthContextV1 {
  version: "auth.v1";
  actor: { kind: "human"; accountId: string }; // Sólo backend
  productId: string;
  sessionId: string;
  method: AuthMethod;
  assurancePolicy: string;
  authenticatedAt: string;
  securityVersion: number;
}
interface PublicSessionV1 {
  version: "auth.v1";
  status: "authenticated" | "restricted";
  expiresAt: string;
  capabilities: readonly string[]; // UI orientativa; servidor revalida
}
interface IdentityStore {
  claimTransaction(input: ClaimInput): Promise<ClaimResult>;
  completeLogin(input: ValidatedIdentityInput): Promise<SessionResult>;
  linkIdentity(input: AuthorizedLinkInput): Promise<LinkResult>;
  consumeOtp(input: OtpAttemptInput): Promise<SessionResult>;
  rotateSession(input: AuthorizedRotationInput): Promise<SessionResult>;
  revokeAccountSessions(input: AuthorizedRevocationInput): Promise<void>;
}
```

Los tipos `Input/Result` anteriores son nombres de contratos, no imports existentes: especificarlos junto a los fixtures de cada operación. `ValidatedIdentityInput` sólo se construye dentro del adaptador validado; nunca deserializarlo directamente de JSON del cliente. Resultados de store contienen códigos de conflicto y expiración, no excepciones con datos personales.

| Endpoint propuesto                               | Entrada mínima / salida                           | Protección y efecto                                                                                                                    |
| ------------------------------------------------ | ------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| `GET /api/auth/v1/methods`                       | Métodos habilitados y disponibles globalmente     | Sin email; no enumera cuentas ni revela métodos de otra persona                                                                        |
| `POST /api/auth/v1/oidc/:provider/start`         | purpose permitido, returnRoute enum; URL servidor | Origin+CSRF; linking/step-up exige sesión y versión; no aceptar accountId                                                              |
| `GET /api/auth/v1/oidc/:provider/callback`       | code/state o error IdP                            | Transacción/browser/issuer de un uso; termina en 303 limpio                                                                            |
| `GET /api/auth/v1/transactions/:id/status`       | pending/completed/failed/expired                  | Sólo transacción iniciada por ese navegador y TTL; no tokens/email; rate limit y no-store; permite completar OAuth en ventana separada |
| `GET /api/auth/v1/session`                       | PublicSessionV1                                   | Cookie propia, no-store; 401 si no autenticado; sin refresh de terceros                                                                |
| `POST /api/auth/v1/logout` / `logout-all`        | cuerpo vacío o scope enum                         | Origin+CSRF; revocación persistida antes de éxito                                                                                      |
| `GET /api/auth/v1/identities`                    | Métodos propios y fechas, sin subject crudo       | Sesión activa; lista sólo del actor                                                                                                    |
| `POST /api/auth/v1/identities/:id/unlink`        | intento idempotente                               | Prueba reciente, último método protegido, CAS de versión                                                                               |
| `POST /api/auth/v1/passkeys/register/options     | verify`                                           | Respuestas WebAuthn acotadas                                                                                                           | Fase posterior, sesión reciente; opciones/verificación ligadas al mismo actor |
| `POST /api/auth/v1/passkeys/authenticate/options | verify`                                           | Aserción WebAuthn acotada                                                                                                              | Reto de un uso; neutralidad de enumeración; permitir login discoverable       |
| `POST /api/auth/v1/recovery/consume`             | recovery code                                     | Fase posterior, rate limit; sólo sesión restringida                                                                                    |

Mantener `/api/account/otp/request`, `otp/verify`, `session`, `authorize`, `data`, `delete`, `logout` como adaptadores compatibles a medida que se extraiga servicio. Los endpoints de cambios de contacto y emisión de códigos de recuperación se añaden únicamente en la fase correspondiente con la misma prueba reciente. IDs en ruta son selectores, no autorización. Respuestas de error: `{error:{code,message,retryAfter?}}`, 400 formato, 401 sesión, 403 política, 409 conflicto, 429 cuota, 503 dependencia; no distinguir públicamente “email existe”. Cuerpos JSON limitados por endpoint; WebAuthn admite tamaño explícito mayor sin abrir límites generales.

## 11. Máquinas de estado y concurrencia

```mermaid
stateDiagram-v2
  [*] --> Anonymous
  Anonymous --> ChallengePending: OTP o inicio OIDC
  ChallengePending --> Anonymous: cancelar, expirar o fallar
  ChallengePending --> Authenticated: prueba válida y commit
  Authenticated --> StepUpPending: acción sensible
  StepUpPending --> Authenticated: prueba suficiente
  StepUpPending --> Authenticated: cancelar sin elevar
  Anonymous --> RecoveryRestricted: código recuperación válido
  RecoveryRestricted --> Authenticated: método nuevo y revocación global
  RecoveryRestricted --> Anonymous: vence o cancela
  Authenticated --> Anonymous: logout, revocación o vencimiento
```

Transacción OIDC persistida: `created -> claimed -> completed`, o `created/claimed -> failed|expired`. CAS `created` a `claimed` incluye TTL y hash del navegador; un segundo callback no canjea code. Crash después del canje y antes del commit termina sin sesión y exige nuevo login; no reabrir ni reutilizar el code. Tras `completed`, borrar verificador PKCE/nonce y conservar recibo mínimo sólo por TTL operacional. Claim fallida no crea cuenta ni sesión. Linking comprueba nuevamente versión/sesión iniciadora al completar para resistir logout concurrente.

OTP: `issued -> provider_accepted -> consumed`, con salidas `delivery_failed`, `expired`, `locked`, `superseded`. Nuevo reto autorizado invalida el anterior para identidad y propósito; una entrega tardía no reactiva el código viejo. Consumo incrementa intento con condición, gana nonce único y crea sesión dentro de una transacción; fallo de transacción no puede dejar cuenta válida sin la prueba consumida de forma coherente. Rate limit y revocación requieren consistencia fuerte del store.

En D1 usar escrituras condicionales y batch transaccional para dependencias conocidas, sin simular una transacción con múltiples round-trips independientes. En otro motor usar transacción/locks/CAS equivalentes y probar carrera real. El contrato define resultado observable, no impone un algoritmo SQL universal. No activar lecturas de réplica para decisiones de revocación, linking, consumo ni cuota sin garantizar currentness.

## 12. Amenazas e invariantes verificables

| Riesgo                                 | Invariante / verificación exigible                                                                                                |
| -------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| Robo de cuenta por email coincidente   | Token válido de otro issuer/sub con mismo email no abre ni vincula cuenta existente                                               |
| CSRF, mix-up, replay o login injection | State+browser+PKCE+nonce+issuer y callback exactos; callback doble tiene un único efecto                                          |
| SSRF por discovery/JWKS                | Providers preconfigurados, destinos HTTPS permitidos, límites de fetch/cache; ninguna URL del usuario gobierna red interna        |
| Sesión robada/fijación                 | Token nuevo tras autenticación/elevación; HttpOnly y no-store; revocación se verifica en acciones protegidas                      |
| XSS                                    | No tokens en JS/storage; CSP y render seguro siguen necesarios: cookie HttpOnly no impide acciones ejecutadas por XSS             |
| Escalada entre productos/tenants       | No aceptar sesión de otra app; comprobar membresía/recurso en cada acción; email y claims de perfil no son roles                  |
| Abuso OTP/coste                        | Admisión atómica por identidad/IP/global, límites de verificación y presupuesto de mensajes; ningún fail-open o compra automática |
| Alta federada para evadir cuotas       | Mismo account_id tras linking/relogin; no fusión automática; límites de alta comunes y tombstones multi-método                    |
| Recuperación más débil                 | OTP no permite saltar passkey exigida; recuperación restringida no realiza acciones privilegiadas                                 |
| Caída del IdP o correo                 | Borrador preservado, sesiones propias válidas según política, alternativas inscritas; ninguna identidad fabricada                 |
| Borrado seguido de login               | Revocar todos los métodos y mantener continuidad de cuota durante ventana declarada sin retención ilimitada                       |

No se afirma “una persona, una cuenta”: cuentas Google múltiples, buzones compartidos y nuevas identidades siguen siendo posibles. La cuota es por cuenta verificada. La autenticación portable tampoco transforma la producción local del ZIP en una barrera criptográfica: preservar la distinción del [diseño de enforcement](../AUTH_ENFORCEMENT_OPTIONS.md).

## 13. Perfiles humanos, desktop, CLI y automatización

| Perfil                                 | Default propuesto                                                                                                                      |
| -------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| Usuario web accreatio                  | OTP existente o Google; sesión 24h; cuota propia; borrador local                                                                       |
| Administrador/editor                   | Frontera administrativa existente intacta; futura integración exige autorización explícita y step-up fuerte                            |
| Usuario de futuro producto con tenants | Cuenta local al producto, membresía explícita y permiso de recurso; OIDC no aprovisiona roles automáticamente                          |
| Desktop accreatio                      | Mantener ejecución local sin cuenta obligatoria; no implementar auth desktop en esta fase                                              |
| CLI humana futura                      | Navegador externo + authorization code/PKCE; Device Authorization sólo cuando proveedor/cliente/scopes lo admitan y exista caso de uso |
| Agente/servicio                        | Principal no humano distinto, credencial de workload o token propio de alcance corto según runtime; nunca OTP humano ni cookie copiada |

Para una futura app nativa, RFC 8252 recomienda navegador externo y clientes públicos con PKCE. No poner secretos OAuth en Electron ni usar webview embebida. El retorno loopback utiliza loopback real y validación del flujo; cualquier deep link requiere asociación y validación de plataforma. Guardar sólo credencial **propia** de la aplicación en almacén seguro del OS si se autoriza ese servicio; el renderer no obtiene privilegios ni tokens de terceros. Un diseño nativo final debe definir audiencia, emisión, renovación y revocación del backend; no reutilizar un ID token Google como bearer universal. [RFC 8252](https://datatracker.ietf.org/doc/html/rfc8252).

RFC 8628 define Device Authorization para entrada limitada, con polling y expiración propios. No todos los proveedores, clientes o scopes lo permiten; el hecho de que exista metadata no autoriza cualquier CLI. Google publica restricciones específicas de dispositivos/scopes. Ninguna CLI queda habilitada por este documento. [RFC 8628](https://www.rfc-editor.org/info/rfc8628/), [Google limited-input devices](https://developers.google.com/identity/protocols/oauth2/limited-input-device).

### Estado real de los otros consumidores

kommiBo remoto `2e5cdcf7c242f65014b9a8290d51385687e63988`: master declara `GENERAL_CONSOLE_LIVE_ON_WITH_CONCERNS`, release general `NOT_READY`. Su consola privada de propietario único ya usa contraseña propia y passkeys opcionales, D1 con sesiones hasheadas, cookie Strict, 8h absolutas/30min de inactividad y origen aislado. El registro central acredita ensayos anteriores; este discovery no repitió login ni verificó Cloudflare en vivo. No es greenfield ni CLI-only. Conservar singleton, métodos y credenciales; Google sólo podría enlazarse desde autenticación del propietario existente, sin alta pública ni autoridad GitHub automática. Los actores writer/reviewer y ejecución permanecen separados. [Master fijado](https://github.com/edlopezpm-ops/kommiBo/blob/2e5cdcf7c242f65014b9a8290d51385687e63988/docs/master.md), [revisión vigente](https://github.com/edlopezpm-ops/kommiBo/blob/2e5cdcf7c242f65014b9a8290d51385687e63988/docs/operations/CONSOLE_REVIEW.md).

leudani remoto `2fea5cd219dab7c3a6f2c9d3dfa6007dbff02196`: ocho fuentes contractuales comparadas por blobs coinciden con checkout local `825ef54783c6abe792b3edb14ff883069b799e96`. `GO_V3_F1=0`; runtime/SQL/infraestructura ausentes. Su diseño aceptado es **una empresa, cuatro roles OWNER/ADMIN/OPERADOR/CLIENTE, Supabase Auth/PostgreSQL/RLS/RPC**, sin BFF paralelo. Internos usan contraseña y CLIENTE OTP de 600s; MFA de aplicación es un gap pendiente y SMTP productivo es prerrequisito del piloto. No introducir tenants ni sustituir `auth.users`/`auth.uid()`/sesiones de Supabase por las tablas de accreatio. Aplicar el contrato mediante adaptador Supabase y sus pruebas de autorización; cambios de método requieren el ADR y autorización propios antes de código. [Estado](https://github.com/edlopezpm-ops/leudani-V1/blob/2fea5cd219dab7c3a6f2c9d3dfa6007dbff02196/orquestacion/v3/PROJECT_STATUS.md), [identidad](https://github.com/edlopezpm-ops/leudani-V1/blob/2fea5cd219dab7c3a6f2c9d3dfa6007dbff02196/docs/architecture/identity-and-permissions.md), [ADR 0010](https://github.com/edlopezpm-ops/leudani-V1/blob/2fea5cd219dab7c3a6f2c9d3dfa6007dbff02196/docs/architecture/adr/0010-v2b-platform-hosting-security-and-readiness.md).

La reutilización no autoriza arrancar servicios en otros proyectos, cambiar sus gates ni reemplazar decisiones aceptadas. A nivel común se prueban identidad/autorización, separación de actores y no downgrade; a nivel de adaptador se prueban los mecanismos efectivos de cada plataforma.

## 14. Privacidad, branding, capacidad y coste cero

Login Google exige registrar aplicaciones y redirects por entorno con dominio controlado, nombre y soporte comprensibles, páginas públicas de privacidad/términos coherentes y scopes mínimos. Producción no debe depender indefinidamente de “test users”; verificar el estado de publicación y cualquier revisión de branding/scopes que Google exija para el cliente concreto. Usar el botón/assets aprobados y texto reconocido de Google, sin redibujar logotipo ni insinuar aval. Consentimiento OAuth no equivale a consentimiento de marketing/analítica. [Políticas OAuth Google](https://developers.google.com/identity/protocols/oauth2/policies), [branding Google](https://developers.google.com/identity/branding-guidelines).

La documentación actual contempla una excepción al allowlist de test users cuando sólo se piden scopes básicos `openid/email/profile`; no aplicar universalmente un límite de 100 testers. Eso no elimina verificación de marca ni requisitos de publicación. GIS es otra integración posible de Google, con contrato de callback propio; este roadmap elige OIDC code de servidor y no confunde un ID token `credential` de GIS con code+PKCE. [Production readiness](https://developers.google.com/identity/protocols/oauth2/production-readiness/overview), [brand verification](https://developers.google.com/identity/protocols/oauth2/production-readiness/brand-verification).

Explicar que Google procesa el acceso elegido y que el producto recibe identificador y email; el borrador no se transmite. No pedir contactos ni acceso a servicios. No afirmar cumplimiento jurídico certificado: publicar finalidades, datos, retención, eliminación, contacto y proveedores reales antes de lanzamiento según territorios del producto. Esta tarea produce diseño técnico, no dictamen legal.

Operación sin telemetría de proyectos: ningún contenido, token, OTP, email, subject, IP cruda o request/response completa en logs. Métricas agregadas mínimas de éxitos, fallos por categoría, latencia y consumo se pueden obtener en proceso/pruebas; persistir nuevos eventos operacionales sólo con retención y autorización aplicables. Seudónimos HMAC siguen siendo datos correlacionables, no “anónimos”. Para el rate limit usar clave con propósito/ventana separados, TTL 48h máximo inicial y no reutilizar identity_key. Diagnósticos locales bajo `.local/logs/`; evidencia versionada sólo sanitizada.

Coste cero adicional es un presupuesto duro, no sinónimo de capacidad ilimitada. Evaluar hosting actual, store, llamadas OIDC, correo total, dominios existentes y mantenimiento. Un proveedor “free” puede exigir tarjeta, permitir overage, limitar proyectos o suspender por inactividad. No habilitar upgrades, SMS, APIs cobradas ni fallback automático. Si el límite impide servir el volumen, mantener servicio acotado y comunicar indisponibilidad; el HOC decide sobre un gasto concreto por separado, no sobre cada detalle de diseño.

Defaults de factibilidad: mantener hosting/store existentes, preferir Google para reducir correo de login, mantener OTP sólo con destinatarios/capacidad admitidos y verificar un transporte público sin coste antes de prometer email para todos. No migrar todo a otro hosting por un fallo de envío. Google OIDC directo no publica en la documentación consultada una tarifa por MAU; el objetivo $0 es estimación de este alcance, no readback de facturación. No activar Identity Platform ni APIs de datos como parte del login.

Supabase Free publica 50.000 MAU, dos proyectos activos y pausa tras una semana inactiva; SMTP incorporado sólo cubre equipo del proyecto, dos mensajes/hora y sin SLA. Entra External ID publica 50.000 MAU core gratuitos agregados por suscripción, con add-ons aparte. Ninguno garantiza tres productos con entornos ilimitados y correo público gratuito. Keycloak requiere infraestructura de producción propia. Estas cifras son snapshot de documentación, no entitlements de cuentas actuales. [Supabase precios](https://supabase.com/pricing), [SMTP](https://supabase.com/docs/guides/auth/auth-smtp), [Entra precios](https://learn.microsoft.com/en-us/entra/external-id/external-identities-pricing), [Keycloak producción](https://www.keycloak.org/server/configuration-production).

### Conservar correos con finalidad y protección explícitas

Sí se conservan los emails necesarios. En accreatio: contacto/autenticación, recuperación autorizada y exportación de los datos de la propia cuenta; no marketing ni circulación entre productos. Registrar fuente, `verified_at` y versión del aviso. Google con email externo no siempre prueba titularidad actual del buzón aunque `email_verified=true`; distinguir contacto observado de contacto verificado para cambios/recuperación. No sobrescribir un contacto de recuperación validado al cambiar una claim de perfil. [Validación Google](https://developers.google.com/identity/gsi/web/guides/verify-google-id-token).

Propuesta de almacenamiento: **AES-256-GCM mediante WebCrypto**, clave backend de 256 bits separada/versionada, nonce de 96 bits generado con CSPRNG sin reutilización por clave y tag de 128 bits. AAD versionado = UTF8 del array JSON compacto `["email-v1", productId, accountId]`; almacenar versión/nonce/ciphertext+tag, nunca clave junto al registro. Error de autenticidad/clave falla cerrado. Índice HMAC distinto para búsqueda. El código actual **no tiene ese cifrado aplicativo de email**. Preservar `ACCOUNT_IDENTITY_KEY` legacy como índice de identidad, sin usarlo para cifrar. Migración expand/contract acotada: añadir ciphertext/key_version, backfill idempotente, lectura cifrada con fallback temporal, verificar exportación y rollback compatible, luego eliminar plaintext sólo cuando todo lector esté migrado; no mantener dos copias perpetuas. Retirada de plaintext requiere build de contingencia que descifre; no volver a un binario que dependa de plaintext borrado. Probar nonce/tag/AAD alterados, claves incorrectas y round-trip en el runtime real; no implementar primitivas criptográficas propias.

Este cambio aplica al store propio de accreatio y, si se adopta expresamente, a stores propios equivalentes. No cifrar/reemplazar unilateralmente `auth.users.email` de Supabase ni duplicar esos emails en otra base de leudani: el servicio gestionado necesita su formato para login. Su adaptador verifica controles de acceso, cifrado del proveedor, contratos, retención y exportación disponibles; distingue cifrado del proveedor de cifrado aplicativo y documenta límites sin fingir equivalencia.

| Dato                             | Finalidad y plazo propuestos para accreatio                                                                                     | Control                                                                               |
| -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------- |
| Email/contacto y verificación    | Mientras exista finalidad de cuenta activa; revisión anual de necesidad y umbral de inactividad publicado antes del lanzamiento | Cifrado recuperable, lectura mínima autorizada, rectificación sin cambio de principal |
| Código/PKCE/nonce en store       | Sólo reto 5–10min según flujo; eliminar material secreto al consumir/cancelar/expirar                                           | Verificador/hash o ciphertext breve; limpieza programada                              |
| Sesión                           | Hasta revocación/24h; limpiar tokens expirados                                                                                  | Sólo hash, comprobación actual del estado                                             |
| Tombstone/recibos de cuota       | Máximo 48h de ventana operacional propuesta antes de purga programada                                                           | Sólo localizadores protegidos mínimos, ningún email necesario para la cuota           |
| Eventos de seguridad autorizados | Máximo 30 días propuestos, menos si basta; incidentes con excepción motivada                                                    | Sin email/IP cruda/tokens/query OAuth; acceso restringido, propósito separado         |
| Copias del proveedor             | Plazo real inventariado y publicado antes de activar                                                                            | Expiración declarada; restauración reaplica supresiones antes de abrir tráfico        |

Borrado: revocación inmediata en transacción y objetivo operativo de purga de PII primaria <=24h, con mantenimiento programado y comprobación incluso sin tráfico. Es una mejora propuesta respecto de la limpieza oportunista actual. No prometer borrado granular instantáneo de backups ni borrar cuentas Google/Entra externas. No trasladar los 48h de cuota a la trazabilidad comercial/facturas de leudani, ni retenciones empresariales de leudani a accreatio.

Exportación administrativa de emails conserva autorización separada, paginación por cursor y JSON estructurado; añadir prueba fuerte reciente y registro mínimo del acto sin la lista exportada antes de ampliar su uso. No envío automático a correo/CRM/marketing. El titular tiene canal verificable para acceso, rectificación y supresión con prueba proporcional; no pedir documentos de identidad rutinariamente. Marketing permanece desactivado; retirar un consentimiento opcional no bloquea por sí solo autenticación con otra base aplicable.

ISO/IEC 27001:2022 y 27701:2025 orientan gestión de seguridad/privacidad; sólo se consultaron fichas públicas, no su texto de pago ni una certificación. OWASP ASVS 5.0 y NIST aportan controles técnicos comprobables. Ninguno es una ley internacional universal ni queda satisfecho por elegir Google. RGPD aplica según su alcance y exige finalidad/base/plazo, con derechos y transferencias sujetos a condiciones; su mes de respuesta no se impone aquí como deadline mundial. [ISO 27001](https://www.iso.org/standard/27001), [ISO 27701](https://www.iso.org/standard/27701), [OWASP ASVS](https://github.com/OWASP/ASVS/tree/v5.0.0/5.0), [EDPB principios](https://www.edpb.europa.eu/sme/learn-the-basics/data-protection-basics_en), [derechos](https://www.edpb.europa.eu/sme/be-compliant/respect-individuals-rights_en), [transferencias](https://www.edpb.europa.eu/sme/be-compliant/international-data-transfers_en).

leudani fija Chile/CLP en F1 y separa email Auth de contacto comercial. Sus proveedores/región São Paulo son targets, no residencia integral ni contratos efectivos. Su anexo legal está marcado `LEGAL_REVIEW_REQUIRED — NOT_PUBLISHABLE_AS_IS`; no extender una aprobación vieja al nuevo diseño. La Ley chilena 21.719 entra generalmente en vigor el 01-Dic-2026, después de este discovery; validar tratamiento actual bajo normativa vigente y preparar la transición sin importar automáticamente bases RGPD. [Política leudani fijada](https://github.com/edlopezpm-ops/leudani-V1/blob/2fea5cd219dab7c3a6f2c9d3dfa6007dbff02196/docs/legal/privacy-policy.md), [Ley 21.719, transitorio primero](https://www.bcn.cl/leychile/navegar?idNorma=1209272), [Diario Oficial](https://www.diariooficial.interior.gob.cl/publicaciones/2025/06/17/44176/01/2660255.pdf).

## 15. Migración y rollback sin pérdida

1. Inventariar esquema y ledger efectivos del entorno de implementación, backups exportables protegidos y recuentos/hashes sanitizados de cuentas/receipts. No publicar emails ni secretos. Ensayar primero en copia sintética con cuentas legacy, sesiones, cinco cuotas, tombstones y retos activos.
2. Extraer contratos detrás de endpoints actuales y comprobar igualdad de comportamiento antes de OIDC. Mantener claves e identidad exactamente; ni nueva normalización, ni reset de cuotas, ni limpieza de storage local.
3. Aplicar migración aditiva nueva, `OIDC_ENABLED=false`. Introducir metadatos y resolver sesiones antiguas con política explícita `legacy-email`; no promoverlas a step-up fuerte. Nunca asumir que sesión sin metadatos tiene el nivel más alto.
4. Añadir Google con cliente de prueba separado y cuentas de prueba autorizadas; ensayar login/alta Gmail-Workspace, rechazo de email externo no vinculado, colisión y delete/recreate con continuidad de recibos. Linking se prueba localmente con casos positivos/negativos, pero su flag permanece deshabilitado hasta verificar en entorno autorizado ambas pruebas reales requeridas. La falta de entrega OTP no bloquea aceptación de Google para nuevas cuentas cubiertas ni identidades ya vinculadas; sí mantiene pendientes las cuentas legacy sin otro método probado.
5. Activación por entorno/cohorte y flags independientes: OIDC, linking, passkey. Mantener OTP de usuarios previos. UI obtiene métodos del backend, sin ofrecer capacidades deshabilitadas; nuevo bundle sigue entendiendo errores del viejo backend y viceversa durante transición.
6. Extraer paquete portable únicamente tras validar el segundo consumidor; semver, API documentada, pruebas de contratos y adaptador del runtime. No mover datos entre productos.

Rollback de aplicación: desactivar nuevos flujos/transacciones, conservar tablas aditivas y volver al último código compatible con esas tablas. Revocar sólo sesiones afectadas por un incidente mediante versión/selector; un fallo general de seguridad puede justificar todas, pero no es efecto automático de cada despliegue. No restaurar base vieja sobre cuentas/cuotas nuevas. Conservar evidencia de la versión y checksums, sin credenciales.

**Cuenta sólo Google:** no tiene garantizado OTP compatible después de volver a un binario pre-OIDC. Por ello mantener un build de rollback compatible que resuelva identidades y sesiones v1 pero deshabilite nuevas federaciones/enlaces; alternativamente detener acceso a la función afectada conservando datos y edición local. Nunca convertirla silenciosamente en identidad HMAC(email), transferirla a otra cuenta ni afirmar rollback transparente. Probar este caso antes de activación, junto con cuota agotada y usuario eliminado. El rollback histórico de Access no es rollback de esta arquitectura.

Prueba de rollback exigida: crear cuenta legacy y federada, consumir recibos, vincular y revocar, desplegar código de contingencia sobre esquema ampliado, verificar mismo account_id/receipts y ausencia de privilegios indebidos; volver al candidato y repetir login sin duplicar. El ensayo se registra con resultado real; este documento sólo especifica el criterio.

## 16. Único roadmap de implementación y aceptación

Ejecutar en el orden indicado, empezando por accreatio y reutilizando después en kommiBo y leudani. Las configuraciones/activaciones futuras necesitan la autorización de implementación correspondiente; este roadmap no levanta gates de otros repositorios. No hay roadmap paralelo de framework, IdP central ni transporte. Si un componente opcional no supera su condición, queda deshabilitado y no bloquea el login Google que no lo utiliza.

| Ficha                                  | Archivos previstos; alcance                                                                              | Criterio de cierre                                                                                                                                                                                                              |
| -------------------------------------- | -------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| A1 Contratos y baseline                | `shared/auth/`, `functions/_lib/accounts.ts`, `src/account/webClient.ts`, tests de cuentas               | OTP/sesión/cuota existentes sin cambio observable; cero contenido de proyecto en backend                                                                                                                                        |
| A2 Validar biblioteca elegida          | módulo aislado en `.local/cache/`, evidencia en `.local/logs/`; lockfile de openid-client                | Bundle Worker real y Node de prueba, OIDC validado, licencia/SBOM, sin servicio cobrado; cambiar selección sólo ante incompatibilidad concreta demostrada                                                                       |
| A3 Persistencia y email protegido      | `migrations-auth/0003_*`, adaptador D1 y fixtures; cifrado expand/contract                               | IDs/HMAC/cuotas idénticos; transacciones/races/revocación/tombstones reales; email recuperable y exportable con control; rollback compatible                                                                                    |
| A4 Google BFF                          | `functions/_lib/auth/oidc.ts`, `functions/api/auth/v1/`, configuración tipada                            | Login/alta Google y state/nonce/issuer/PKCE/callback negativos; scopes mínimos; tokens terceros descartados. Linking: contratos/negativos locales; flag apagado mientras falten pruebas reales de ambos métodos                 |
| A5 UX y PWA                            | `WebAccountBoundary.tsx`, `webClient.ts`, `src/account/contracts.ts`, scripts de smoke                   | Campos guardados antes de redirect sin adjuntos; con blobs transitorios ventana separada y polling, sin perder bytes ni navegación principal ante bloqueo/error; COOP/cancel/back/multitab/PWA/IndexedDB fallido; accesibilidad |
| A6 Aceptación accreatio Google         | runbook, configuración Google del entorno y pruebas alojadas autorizadas                                 | Login Google real, cero gasto adicional verificable, continuidad de cuenta/cuota/borrador y rollback; OTP oculto/no disponible si no tiene prueba de entrega, sin bloquear Google                                               |
| A7 Protección de operaciones sensibles | tablas/adaptadores WebAuthn y recuperación, UI de métodos; hardening export email                        | Runtime probado, credencial real, UV, recuperación restringida y no downgrade; no ampliar operaciones privilegiadas antes de esta aceptación                                                                                    |
| A8 Aplicar contrato a kommiBo          | adaptador pequeño en repositorio cuando esté autorizado; extraer paquete sólo si reduce duplicación real | Mantener singleton/password/passkeys/RP ID/sesiones/actores GitHub; linking opcional del propietario probado; ninguna alta pública ni permiso extra                                                                             |
| A9 Aplicar contrato a leudani          | documentación/ADR de adaptación primero; módulo Supabase y pruebas sólo tras GO del proyecto             | Mantener Auth/RLS/RPC y cuatro roles; resolver MFA y SMTP propios antes de su piloto; dos clientes aislados, desactivación y aprobaciones verificadas; sin BFF/segundo IdP                                                      |

Pruebas de A1–A6 necesarias antes de habilitar Google: tests de unidad/política, integración con SQL real y Worker local/preview, typecheck, Functions build, web+desktop build, packaged/Electron smoke y pase UI funcional conforme a AGENTS.md. A6 exige Google real dentro de su cobertura, carreras/colisión/continuidad/rollback, pero **no entrega email ni linking legacy real mientras esas capacidades estén deshabilitadas**. Probar negativos y aislamiento de flags en ese caso. Entrega real se exige para habilitar OTP y linking real de una cuenta legacy mediante ese método; el resto del login Google puede aceptarse antes. No activar un transporte alternativo sólo para completar un checklist. Usar `npm.cmd run log -- <script>` para scripts existentes. Cambios sólo documentales no requieren fingir ese pipeline de producto ejecutado.

Casos adversariales mínimos: issuer equivocado; firma inválida y clave JWKS rotada; audience/azp incorrectos; nonce/state/PKCE incorrectos; reloj vencido/futuro; callback duplicado y timeout de token; subject distinto con mismo email; linking concurrente; logout durante callback; 6.º intento OTP; entrega tardía tras reenvío; límites comunes en altas OIDC y OTP; sesión revocada desde otra instancia; acceso cruzado tenant/producto; último método; recuperación seguida de intento de acción prohibida; delete/recreate con receipt vigente; rollback con cuenta sólo federada. Usar bounded concurrency y reloj controlado para pruebas, además de almacenamiento real.

Mocks permiten simular errores/claims, no prueban integración Google, soporte de runtime, propagación de cookies cross-site, envío a inbox, facturación, ni autenticador físico. Aceptación alojada exige flujo Google con cuenta de prueba autorizada, observación de scopes/callback/cookies y borrador, y correo recibido si se declara habilitado. No registrar códigos o tokens en la evidencia. Si algún requisito depende de configuración externa todavía inexistente, marcarlo pendiente y conservar esa función deshabilitada; no dar crédito al test simulado.

## 17. Decisiones cerradas por defecto y pendientes verificables

Queda seleccionado para el roadmap: Google OIDC de servidor por defecto en accreatio, con cuentas/sesiones/cuotas propias preservadas; OTP separado y condicionado a capacidad real; contrato portable adaptado a kommiBo existente y Supabase en leudani; no linking por email, SSO central ni MFA inferido; emails necesarios protegidos y cero gasto adicional. No hace falta elegir un IdP empresarial ni dominio de passkeys de todos los productos para implementar el primer incremento.

Pendientes de la fase que corresponda: cliente Google y publicación/branding efectivos; disponibilidad pública y presupuesto real del correo; compatibilidad exacta de versiones en Worker; esquema vivo y rollback; dominio estable de passkeys; requisitos reales de tenant/automatización en cada consumidor; política de recuperación privilegiada. Son condiciones para activar capacidades concretas, no afirmaciones de que la arquitectura esté desplegada, certificada o plenamente validada.

Revisión del diseño cerrada el 08-Sep: `auth_architect` preparó la arquitectura, `auth_product_inventory` contrastó los otros productos y `auth_options` realizó una revisión independiente completa y verificó la resolución de sus cinco hallazgos. Se corrigieron nonce OIDC, ubicación/cifrado de email, continuidad de cuotas federadas tras borrado, aceptación Google independiente del transporte OTP y cobertura de emails externos. Resultado: **apto como diseño propuesto para implementación, sin hallazgos materiales abiertos en esa revisión**. Este resultado no acredita pruebas runtime, entrega de correo, facturación, migración/rollback ejecutados ni certificación de seguridad o cumplimiento.
