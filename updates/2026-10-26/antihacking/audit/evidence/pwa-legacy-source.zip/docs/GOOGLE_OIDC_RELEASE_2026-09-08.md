# Google OIDC and account privacy — implementation receipt

Date: 2026-09-08. Scope: **accreatio only**. This implementation does not modify another product or introduce a shared identity service. Google OIDC is implemented and tested locally; a real Google login is **not yet accepted** because the environment has no Google OAuth Web client. The establishment/launch-market information requested from the operator is also outstanding. This is not a statement of worldwide legal compliance.

Follow-up on 2026-09-08: the user confirmed **Chile and the United States** as countries in scope. Establishment, relevant US states and the remaining operator/provider facts still require determination; the earlier receipt is preserved as its original checkpoint. The concrete next step is documented in [Google OAuth activation](GOOGLE_OAUTH_ACTIVATION.md).

CI follow-up: [PR verification 34244184042](https://github.com/edlopezpm-ops/accreatio/actions/runs/34244184042) passed on `df36547`; merge `4cd20d7` has the identical Git tree. The automatic [main run 34245174810](https://github.com/edlopezpm-ops/accreatio/actions/runs/34245174810) subsequently failed a WebGL canvas `boundingBox()` timeout in `scripts/web-functional-smoke.mjs`, after the 300 tests, builds, Electron, project-map and both footer popups passed. This repeated graphic-smoke failure remains unresolved; it is not evidence of a Google authentication failure. No runtime changes or test relaxation were made in the OAuth setup documentation follow-up.

## Delivered behavior

- Google authorization code flow through pinned `openid-client@6.8.8`, with PKCE S256, state, browser binding, encrypted nonce/verifier, mandatory JWS verification and issuer/audience/authorized-party checks. Only `openid email`; no refresh token or Google token storage. New accounts require authoritative Gmail/Workspace email; no automatic linking or quota reset by email.
- Existing opaque accounts, legacy identity key and rolling allowance survive. Session tokens remain hashed, revocable and host-only. OIDC cancellation/logout and sensitive operations recheck authorization at the database write. OTP fails closed if privacy keys are lost from an encrypted/federated store.
- Versioned AES-256-GCM account email protection with separate lookup/continuity keys, bounded idempotent legacy backfill, own-data export and deletion. Export/deletion require local login within five minutes, without claiming recent Google MFA. Deletion clears active email and raw external identity, revokes sessions and preserves only protected continuity records for 48 hours.
- OAuth with transient attachments retains the editing page and uses a separate window; blocked/cancelled/expired flows preserve the exact file bytes. Redirect without files requires confirmed draft persistence. Google branding assets and the font's OFL license are supplied locally.
- Public ES/EN privacy, terms and FAQ describe actual purposes, processors, account controls, local draft limitations and the separate Google connection. [Processing inventory and operator duties](ACCOUNT_PRIVACY_OPERATIONS.md) distinguish implemented controls from territorial, contractual and operational facts still to establish.

## Validation and independent review

The default `npm.cmd run log -- verify` pipeline passed: unit/policy tests, real SQLite, real local workerd/D1 OIDC execution with a simulated Google HTTP endpoint, mailer checks, typecheck, formatting, Functions bundle, web/desktop builds, Electron execution and surface smoke, functional web/account/PWA checks and Lighthouse. Google transport fixtures do not count as Google-hosted acceptance.

After independent review found an OTP downgrade when privacy keys were missing, the fix and regression passed; the final unit run is **300/300**. The compatible rollback suite is **6/6**. The OIDC/endpoints/frontend review found no confirmed material vulnerability; a separate reviewer checked account storage/privacy/migration, and confirmed resolution of its one finding. These are bounded engineering reviews, not certification.

The first hosted CI run passed those tests, builds and privileged Electron checks, then failed the pre-existing Instagram footer popup fixture. The fixture now runs in a separate Chromium process before the WebGL motion checks, preserving the real popup/opener/destination assertions and blocking external network access. The focused full web smoke passes; hosted CI confirmation is recorded separately. The underlying Chromium failure is not claimed as proven from a timeout alone.

Functional evidence includes byte-identical attachment ZIP extraction after popup blocking, COOP separation, cancellation, network failure, expiry, reauthentication and service-worker activity. Lighthouse: performance 97, accessibility 100, best practices 100; indexing remains intentionally disabled for the restricted beta. The final dependency audit reports zero vulnerabilities.

Baseline exception: the default AEKR vendor comparison skipped because its historical source directory no longer exists. An explicit read-only check against the current canonical `AEKR` directory reports pre-existing generated-payload drift. `shared/aekrPayload.generated.ts` and the vendor generator are unchanged in this implementation; no AEKR payload update is included. The pinned branding integrity check passed.

Sanitized detailed logs reside in `.local/logs/auth-implementation-20260908/` and the timestamped `verify`/`test` logs. The privacy downgrade regression is versioned in `tests/accountRollback.test.ts`; the Worker compatibility test is `tests/oidcWorker.test.ts`.

## Prepared environment

Implementation commit: `948aac2f53b9cc26bf6fa42a12aea7a657fff189`; [PR #8](https://github.com/edlopezpm-ops/accreatio/pull/8). The compatible web/Functions deployment `a2c34f21-8622-431d-b7a2-95b572fada51` completed successfully at 15:04:54 UTC with that exact commit. [Protected preview](https://google-oidc-preview.accreatio.pages.dev). Unauthenticated requests to the homepage, account API and public assets receive the existing Cloudflare Access redirect; this verifies protection, not authenticated hosted application acceptance. The Google client is still absent. The public OAuth homepage/notices and provider callback must be reachable under the selected launch configuration before real Google acceptance.

| Item                  | Confirmed state                                                                                                                                                                   |
| --------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Account D1            | Preview only: `3c42de52-6883-4f1a-b81a-3c693abab64d`; zero accounts/sessions/receipts before migration                                                                            |
| Migration             | `0003_google_oidc_privacy.sql` applied remotely; `0001`/`0002` not replayed and `ACCOUNT_IDENTITY_KEY` not changed                                                                |
| Runtime protection    | Four independent new secrets installed for OIDC transactions, account email, email lookup and federated continuity                                                                |
| Google callback       | `https://google-oidc-preview.accreatio.pages.dev/api/auth/v1/oidc/google/callback`                                                                                                |
| Google activation     | Disabled; `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` absent                                                                                                                    |
| Email OTP             | Disabled; Google acceptance does not depend on its transport                                                                                                                      |
| Maintenance           | `accreatio-account-maintenance-preview`, version `ab484bac-6efc-48ec-9295-3b38ce68f396`; enabled, no HTTP routes/workers.dev, cron `17 * * * *` read back from the API            |
| Maintenance execution | A PII-free expired transaction sentinel remained at 15:12:44 UTC and was purged by the hourly Worker by 15:18:25 UTC; provider event status is still awaiting analytics ingestion |
| Production            | Existing canonical deployment `11235c8c-108f-46f3-8cce-fb88a144330b`; no account-service production activation in this receipt                                                    |

Secrets and the pre-migration database backup are held under `.local/private/auth-20260908/`, with Windows ACL restricted to the current user. Never print those files, commit them, or treat them as disposable build caches. No password, mailbox message or external user credential was collected to replace missing Google configuration.

The [preview writer cutover](GOOGLE_OIDC_PREVIEW_CUTOVER_2026-09-08.md) moved the historical alias onto the compatible build and retired six obsolete account-writing deployments. The final inventory contains only two enabled account deployments, both compatible with Google/OTP off, and one older account-disabled deployment. Account/session/receipt counts remain zero after the scheduled probe; no personal data was used for that check. Scheduled status/failure monitoring uses Cloudflare's `workersInvocationsScheduled` metadata, without application event logging.

## Remaining activation work

1. Supply a dedicated Google Cloud project/Web OAuth client for this preview tier with the exact callback above and minimal scopes. Configure its owner/contact, authorized domain and public homepage/privacy/terms; validate Google publication/brand requirements for the intended audience. This session has Cloudflare access but no authenticated Google Cloud session or OAuth client to perform that registration.
2. Put the client ID/secret into protected **preview** runtime configuration. A Google-exported Web-client JSON may be placed locally at `.local/private/auth-20260908/google-client.json`; never paste the secret in chat or commit it. The session's ignored configuration helper can read that file, validate the callback and install its values without logging them. It does not enable Google automatically.
3. Enable only this preview's Google flag, deploy the matching configuration and exercise a real authorized Google account through the application. Record login/cookies/scopes, cancellation, local files, export/deletion, same-account quota continuity and compatible rollback. Do not claim this acceptance from the existing fixtures.
4. Record actual establishment/launch markets, effective provider terms/transfers, log/backup retention, rights handling and continued maintenance monitoring. Apply any additional jurisdiction-specific requirements before broad release. The implemented self-service protections and notices remain useful while those facts are supplied.

These are external configuration/factual dependencies, not a request to approve completed engineering work. The public beta is not promoted as universally available or legally certified.

## Compatible rollback

[Executable fallback and artifact hashes](GOOGLE_OIDC_ROLLBACK.md). The compatible tag is pushed to origin; source, web and Functions recovery artifacts are saved alongside the protected configuration/database backup.

Disable new Google sign-in using `ACCOUNT_OIDC_ENABLED=false`; keep the compatible account reader, session/allowance endpoints, encryption keys and scheduled retention controls. A compatible code rollback preserves schema0003, opaque IDs, raw active identity mappings, encrypted contacts and existing receipts; use the saved candidate source/bundle, never the old Access-only or plaintext-only application.

The automated rollback rehearsal creates an encrypted Google-only account, consumes its allowance concurrently, disables Google admission, verifies existing account/session/data behavior and unchanged receipts, rejects OTP substitution and re-enables Google without duplicating the principal. Losing a privacy key fails closed. No stale database snapshot is restored over subsequent accounts or receipts.

The pre-migration SQL backup is for controlled isolated recovery and evidence. Restoring it over later live state would lose account/deletion/receipt information and is not the application rollback procedure. Preserve deletion and revocation decisions across any isolated restore before serving traffic.
