# Approved pearl design — visual polish delivery

Date: 2026-10-22. Published at [accreatio.com](https://accreatio.com/).
The owner accepted the pearl design direction and requested stronger nebula
visibility, dark-logo transparency, a global alignment pass and browser identity
updates. The final Blog instruction is **Blog in red**, with no logo added to
that heading.

## Published revision

- Final application source: `a73944022af327c566a4ea66627b9215d6f04059`.
- Main polish implementation: `bc6478559aab9df21e00ef1b7b285449aec48533`.
- Remote branch: `codex/iceland-pearl-2026-10-22`; exact SHA verified with
  `git ls-remote`. Direct Pages deployment uses its existing production branch
  mapping; this is not a merge into `main`.
- Final production deployment: `862e26ff-eb87-4e8e-983b-2df2a12edaa5`.
- Immutable deployment: <https://862e26ff.accreatio.pages.dev>.
- The preceding polish deployment, `44da77e3-02c3-48cf-bf53-3b2516fa0555`,
  remains recoverable. The first pearl release remains
  `0c32f01a-95f0-45b2-a2de-baa3c74e67fc`.
- Original design backup: commit `236748f`,
  [source archive, hashes and screenshots](design-backups/2026-10-22-pre-iceland/README.md).

## Delivered behavior

The existing procedural nebula has broader gas coverage and stronger mineral
wisps against pearl, plus a denser reduced-motion fallback. The reading scrim,
interaction mask and motion behavior are preserved. Typography and the accepted
pearl/charcoal/red palette remain as documented in the
[design record](DESIGN_ICELAND_PEARL_2026-10-22.md).

Dark logo variants retain the approved raster contours through native SVG
alpha/color filters, eliminating the pale rectangle. The canonical PNG,
full-resolution PNG crops and light SVGs remain unchanged. The
[branding record](ACCREATIO_BRANDING.md) documents the owner authorization,
filter derivation and new transparent, theme-aware v2 favicon.

Alignment refinements cover the welcome facts, creation toolbar and status,
summary chevrons, advanced roles, copy/download controls, review action wrapping,
result/help column, About/Terms reading inset, cookie dialog and standalone legal
navigation/tables. The final header/About home targets and modal plan disclosure
also have 44px minimum hit areas.

Browser titles follow `accreatio | <short section>` in the active language. Blog
posts retain that short tab title while keeping their specific description,
canonical URL and social title. The existing Blog heading renders only **Blog**
in `#E2232A`. No extra logo was inserted.

## Public readback

[Final hosted receipt](design-evidence/2026-10-22-polish/hosted-readback.json):
**PASS**. All 28 checked public files match the final local build by SHA-256,
including the new favicon, transparent dark logos, HTML, JS, CSS and legal files.
Six routes retain their expected status and account-method configuration.

Desktop/mobile checks confirm pearl remains the default even with a dark OS,
visiting does not save a theme choice, explicit dark persists through reload,
the stronger home density is applied, dark logo corners are transparent and
both pearl strokes and the red dot remain visible. Blog list/article titles,
red heading text, absence of added header images and all four legal titles/
favicons are checked. Eight public app views and eight legal checks report zero
runtime errors and no horizontal page overflow.

Public captures: [desktop pearl](design-evidence/2026-10-22-polish/desktop-pearl.png),
[desktop dark](design-evidence/2026-10-22-polish/desktop-dark.png),
[mobile pearl](design-evidence/2026-10-22-polish/mobile-pearl.png) and
[Blog heading](design-evidence/2026-10-22-polish/desktop-blog-light.png).

## Local verification

- Full `verify`: **PASS**, 387 unit tests, account mailer, types, formatting,
  Functions, web/desktop builds, surface boundaries, Electron, Project Map,
  guided ZIP creation, account/privacy and identity functional checks.
- The last two web-only hit-area rules were followed by a new web build, focused
  visual recapture and the complete web functional smoke: **PASS**.
- Visual matrix: 146 full-flow views at 1440/390/320px, English/Spanish and both
  themes; zero runtime errors or page overflow. A final 24-capture pass covers
  header/welcome, About, Blog and the confirmation modal after the hit-area fix.
  Final identity/legal checks: 20 **PASS**. Full local account views use synthetic
  fixtures; they do not authenticate a real person or consume production quota.
- Final CTA normal/hover/active checks: 18 states, minimum text contrast
  **4.6588:1**, no 320px review label/subtitle overlap. The focused final census
  finds no visible button, select or disclosure summary below 44px.
- Packaged retained desktop: actual executable **PASS**, `isPackaged: true`,
  accreatio 0.9.1, Electron 43.8.1; 22 ASAR assets equal the final desktop build.
  Onboarding, sandboxed preload, themes, synthetic IPC creation/coalescing,
  versioned rerun, failure recovery and history pass. The package is unsigned,
  unpublished and uses an isolated profile with test-only `--no-sandbox`.
  A Windows extraction rename error was resolved using installed Electron of
  the same version in a fresh local package directory.
- Lighthouse from the full verification: performance **93**, accessibility
  **100**, best practices **100**, SEO **69** with the existing deliberate beta
  `noindex` exception. Final changes only enlarge the two web hit areas.
- Official original SHA remains
  `0c53ade5c085e5867541ab933a53288b35e8157f9b1e7698c6536725e5a4b71a`.
  Dark derivative perimeters and 16/32/64px favicon variants pass browser pixel
  checks. Canonical AEKR branding: **4/4 pins**, including upstream comparison.

The default AEKR payload check still skips its historical missing sibling path;
the separately documented pre-existing vendor-payload drift is outside this
visual increment. The payload and canonical AEKR assets were not changed.

## Evidence custody

- Full verification: `.local/logs/2026-10-22T16-06-49-386Z-verify-8c89ea0e-951e-4fc2-a449-616dfc6a4ee7.log`.
- Final web functional smoke: `.local/logs/2026-10-22T16-15-44-936Z-test-web-3da55e52-8ea8-4998-a908-36bd13f065d0.log`.
- Visual review: `.local/logs/nebula-alignment-20261022/visual-review.md`;
  full matrix `final-built-v2/`, final focused pass `final-hitarea/`.
  The interrupted `final-built/` set crossed a rebuild and is excluded.
- Package result: `.local/logs/packaged-nebula-alignment-1792685446515/result.json`.
- Deploy and readback: `.local/logs/nebula-alignment-20261022/production-deploy-final.log`,
  `deployments-final.json` and `hosted/readback.json`.

Minimal anonymous public evidence and a compact local verification summary are
versioned [alongside this receipt](design-evidence/2026-10-22-polish/).
Full logs and synthetic captures remain ignored. Existing unrelated review
documents were preserved. No database, DNS or provider configuration was changed;
no personal authentication or desktop publication was performed. The owner will
review the final visual result on the public site.
