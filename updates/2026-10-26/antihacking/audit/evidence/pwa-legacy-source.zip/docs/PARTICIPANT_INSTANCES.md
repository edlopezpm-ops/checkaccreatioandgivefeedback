# Participant instances and current AEKR compatibility

accreatio stores an ordered list of one to six participant instances. Each participant has a stable, case-sensitive `id`, one canonical role (`generalist`, `architect`, `implementer`, or `auditor`), and an optional descriptive label. Roles may repeat; identity and Mode 1 assignments are joined by participant ID, while array position is the only order.

These are planned participants in a generated user project. A separately allowlisted AEKR service identity that publishes an accreatio Blog post is portal administration, not a participant instance, and is never written into the project definition or orchestration YAML by that action.

Participant IDs are 1–64 characters and use the safe pattern `^[A-Za-z0-9][A-Za-z0-9._-]*$`. New participants receive the lowest unused `participant-NN` ID from `participant-01` through `participant-06`. Changing a role does not change the participant ID, provider, or edited task.

## Draft and provenance migration

Browser draft envelopes use schema version 4. Unversioned direct drafts and version 1/2/3 envelopes remain readable. Legacy `agents[]` entries become `participants[]` in their original order. Valid safe unique IDs, roles, labels, provider selections, tasks, limits, and explicit funding data are preserved. Legacy role-keyed orchestration entries are matched to the first unmatched participant with that role. Invalid or ambiguous IDs are replaced deterministically and surfaced as a recovery warning. Unknown future envelope versions fail closed.

Generated `.accreatio/project.json` uses schema version 2 and replaces `plannedAgents` with ordered `plannedParticipants`. It also records the execution-wide `fundingPolicy`; legacy drafts with no funding migrate only to the zero-paid-use subscription default. Historical provenance version 1 maps `plannedAgents` directly to version 2 `plannedParticipants`; accreatio does not currently import generated provenance as an editable draft.

## Current AEKR contract boundary

Planning, prompt, governance, and provenance support every valid one-to-six topology. The currently consumed AEKR YAML contract is role-keyed and cannot retain distinct identities for repeated roles. Therefore runnable Mode 1 YAML remains available only for one to four participants whose canonical roles are unique. Compatible YAML keeps the existing schema and includes comments correlating participant IDs with roles.

If Mode 1 is enabled for repeated roles or five/six participants, validation returns `orchestrationContractUnsupported` and save/execution/export is blocked without changing the project input. Mode 0/manual remains available. accreatio never drops, merges, aliases, or silently reduces participants. Participant-aware AEKR emission requires a separately approved, versioned upstream contract.

At bootstrap, availability must be verified for each participant instance and concrete context/tool allocation. A role or installed provider count alone does not prove independent realization. An auditor is independent only when its context/tool invocation is separate from the work it audits; otherwise the activity must be labeled self-review.
