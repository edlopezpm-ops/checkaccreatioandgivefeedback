# Web Architecture

**Current scope, 2026-10-22:** accreatio is web-only. The desktop prototype is obsolete, was never released, and will never be released under the owner's direct instruction. Source and historical artifacts remain for custody. [Web-only delivery](WEB_ONLY_DELIVERY_2026-10-22.md) owns that lifecycle boundary; dated release receipts and `CHANGE_CONTROL.md` record deployment evidence.

## Product and data boundary

> accreatio is a local-first browser/PWA application for preparing and exporting project handoffs.

The browser owns project definition, validation, prompt/plan generation, attachment selection, and ZIP construction. An account/session-bound project draft may persist locally; attachment bytes remain in the active page and must be reselected after reload. Sign-out clears the site draft and prepared ZIP. Project fields, attachments, ZIPs, local paths, and optional GitHub/IDE/AI-provider credentials do not enter the account or editorial stores.

The separate account service handles identity, hashed revocable sessions, encrypted email/display name, policy receipts, allowance, bounded abuse controls and own-account export/deletion. It receives no project contents and retains no third-party credentials. See [account privacy operations](ACCOUNT_PRIVACY_OPERATIONS.md), [identity configuration](GITHUB_IDENTITY_ACTIVATION.md) and [the abuse-guard runbook](ABUSE_GUARD_2026-10-22.md).

The Blog is a separate data class. Published administrator-authored posts persist in its own Cloudflare D1 store and are served through same-origin Pages Functions. Cloudflare may process the request, identity, cookie/token, IP, timestamp, and security/operational metadata needed by Pages, Functions, Access, and D1. Browser-local project drafts and published Blog posts have different persistence boundaries.

## Runtime topology

| Surface | Entry/output | Capabilities |
| --- | --- | --- |
| Web | `index.html` → `src/main.web.tsx` → `dist/` | Project PWA, IndexedDB draft, local ZIP, Blog reader, admin composer, editorial API client |
| Account edge | `functions/api/account/**` | Identity, sessions, allowance, account rights and bounded technical abuse controls |
| Account store | Separate D1 binding `ACCOUNT_DB` | Minimum account data and receipts; no project contents or third-party credentials |
| Editorial edge | `functions/api/**` | Access verification, minimum admin capability, published-post read, append-only publish |
| Editorial store | D1 binding `BLOG_DB` | Published Blog rows only; production and preview use distinct database IDs |

`src/main.web.tsx` injects the Blog destination into the shared `App`. Web builds emit `dist/`; root `functions/` supplies the edge routes. `dev`, `start`, `build`, `typecheck` and CI `verify` use the web delivery path. The documented desktop development/build/test/package commands fail closed.

The retained `desktop.html`, `src/main.desktop.tsx`, `electron/` source, desktop renderer branch and packaging metadata describe the unreleased prototype only. They are excluded from the web artifact and do not define an active runtime or release candidate.

The PWA service worker caches the project application shell, not a durable Blog snapshot. Blog reads/publishing are online operations. When their API is unavailable, the UI reports an unavailable state instead of merging a bundled fallback.

## Current verification

The default pipeline checks unit/API behavior, generated Worker types, application/Functions types, formatting, seed/vendor/example/map consistency, Functions compilation, the web build and publication boundary, web surface markers, Project Map rendering, browser flows, account/identity/rights behavior and Lighthouse. It does not build, run, package or certify Electron. Dependency audit and exact-source deployment/readback remain distinct evidence. Existing historical source tests may inspect prototype files without making desktop support claims.

## Historical protected editorial architecture

The following sections preserve the protected `0.8.0` editorial baseline, including its original Access perimeter, release gates and deferred roadmap. They are historical context, not current account architecture or authorization to revive desktop delivery. Current account and release records linked above take precedence.

<details>
<summary>Preserved 0.8.0 editorial design and operations</summary>

## Editorial API

All routes are same-origin and return JSON with `Cache-Control: no-store` and MIME-sniff protection.

| Route | Method | Result |
| --- | --- | --- |
| `/api/blog/posts` | `GET` | Published D1 posts, newest first |
| `/api/admin/blog/session` | `GET` | Minimum `{canPublish, actor}` capability for the verified Access identity |
| `/api/admin/blog/posts` | `POST` | One newly published post (`201`) or the same-actor idempotent replay (`200`) |

Returned post fields are `id`, `slug`, `title`, `summary`, `paragraphs`, `language`, `author`, `authorRole`, `signature`, and `publishedAt`. The client renders paragraph strings as React text; it does not execute HTML or Markdown.

Publishing accepts exactly title, summary, paragraph array, language (`en` or `es`), display author, author role, and signature. The Function creates the ID, collision-resistant slug, timestamp, actor audit fields, and publication state. Body bytes, field count, paragraph count, and field lengths are bounded before D1 access. Browser requests require:

- `POST` and `Content-Type: application/json`;
- `X-Accreatio-Publish: blog-v1`;
- a UUID `Idempotency-Key`; and
- an `Origin` equal to the request origin.

An allowlisted service identity may omit `Origin`, but it follows the same endpoint, validation, idempotency, and database path. This increment is append-only: no edit, delete, scheduling, media upload, or supplied backdate.

## Access authentication and publisher authorization

Cloudflare Access is the portal perimeter and not a substitute for route-level verification. Every Blog route requires `Cf-Access-Jwt-Assertion` and independently:

1. parses a bounded three-part JWT;
2. accepts only RS256 and selects the matching key from the configured Access team JWKS;
3. verifies the signature;
4. verifies the fixed HTTPS Access issuer, one accepted application audience, token type, expiration, issue time, and optional not-before time; and
5. accepts exactly one supported actor claim shape.

Human identity requires a valid normalized `email` and non-empty `sub`, with no service `common_name`. Publishing requires the email-plus-subject pair in the protected human-admin map. Service identity requires a valid `common_name`, empty `sub`, and no email; publishing requires it in the protected agent-admin map. Mixed or unknown shapes fail closed.

The maps resolve sensitive identifiers immediately to bounded labels such as `ed`, `codex-aekr`, or `claude-aekr`. D1 and intentional application logs receive only the safe label and actor kind, never raw email, subject, client ID/common name, JWT, cookie, or service secret. Hiding the composer is presentation only; the publish Function authorizes every request again.

Required issuer, accepted audiences, human map, and agent map are protected runtime values, never Git literals. Production and preview may have distinct audience sets. AEKR automation additionally needs its own revocable Access service token and narrow Service Auth policy. It is not active merely because server support exists; hosted acceptance must exercise one real allowlisted token without weakening the owner human Allow policy.

## Editorial persistence

The migration-controlled `blog_posts` table stores:

- generated ID and unique slug;
- title, summary, JSON paragraph array, language, display author/role, and signature;
- published/created timestamps and publication state;
- verified actor kind and safe actor label; and
- same-actor idempotency key.

It stores no project data, attachments, ZIPs, paths, browser project drafts, integration credentials, IP addresses, raw Access identifiers, JWTs, cookies, or service-token secrets. Queries use prepared statements and explicit selected columns.

The three founding posts live in the reviewed `content/blog/founding-posts.json` fixture and an idempotent generated seed migration. The raw owner Word source remains ignored under `.aekr/sources/` and is never committed, deployed, or packaged. D1 is the only runtime post source; fixture/migration drift is a repository-check failure.

Production and preview bind different D1 databases as `BLOG_DB`. Local development uses Wrangler's persisted local simulation. D1 and Pages Functions must remain within Cloudflare's free plan; rollout stops before any paid requirement or charge.

## Blog administration UX

The Blog always requests published posts. It separately requests the minimum session capability. The composer renders only for `canPublish: true` and holds its unpublished draft in page memory. A deliberate confirmation precedes publish; success inserts the returned post into the current list, while failure preserves the draft and announces the error accessibly.

The visible authorship note states that Codex and Claude wrote their signed posts as AI systems collaborating with Ed Lopez through AEKR. OpenAI and Anthropic provide the respective technologies but are not corporate authors, sponsors, endorsers, or partners. AEKR is described as the collaboration method, not a certification, and private handbook material is not copied into the product.

## Project export boundary

The existing web project flow stays client-side:

1. validate a typed project definition with the shared pure domain;
2. hold selected allowlisted attachment bytes in page memory;
3. generate governed text and a deterministic safe archive manifest;
4. construct the ZIP locally; and
5. request one browser download.

The web app does not promise where the browser saved the ZIP. GitHub, IDE, or AI-provider connections are optional and not required for project creation/export. No Blog call contains project input.

## Verification and operations

Release gates cover unit/API authorization failures and success, generated Worker types, Function/application typecheck, formatting, D1 migration/seed parity, both production builds, complete desktop artifact scan, Electron absence of Blog/admin, web reader/composer behavior with allowed/denied API responses, dark/light responsive inspection, Project Map parity, dependency audit, exact-commit CI, and the existing project ZIP flow.

Deployment order is fail-closed: verify the free account and anonymous Access denial; reconcile the existing Pages configuration; provision separate D1 databases; commit bindings/migrations; apply migrations; set protected values; configure Service Auth only without weakening human access; then deploy the exact audited commit with Wrangler so root `functions/` is included. The installed GitHub source connection has automatic production and preview deployments paused, so it cannot bypass those gates. Direct dashboard asset upload is insufficient for this release because it omits Functions.

No production smoke test creates a throwaway post. Hosted acceptance covers anonymous denial, owner session, founding D1 reads, admin capability, response/security headers, unexpected egress, and the minimal local ZIP flow. Agent publishing stays pending until a real allowlisted service credential is exercised.

Source rollback returns to `0dbbefd03305e56af2e4febbf129d64fcdc064c2` (`0.7.0`) or the latest separately approved known-good deployment. D1 is preserved for recovery rather than deleted; the rolled-back application has no route/binding to it. Any new service token/policy is disabled or revoked without altering the owner's human policy.

## Deferred boundaries

W2 remains an optional loopback-only, paired, per-run-consent local companion. W3 remains an unauthorized tenant/account/shared-project/billing architecture sketch. The editorial Blog is neither a hosted command runner nor a tenant project store and does not authorize either phase.

</details>
