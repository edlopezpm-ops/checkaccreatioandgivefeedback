# v13 verification and testing handoff

Date: 2026-09-04. Implementation follows [DESIGN](DESIGN.md); independent parent review: [AUDIT](AUDIT.md), PASS.

Implemented: static web onboarding brand on both screens; final-dialog dry-review/ZIP choice that changes the captured request; persistent FAQ/ToS controls through project outcome; expanded bilingual About help and full synchronized legal documents. Help navigation retains project state and selected files; complete documents open isolated tabs. Header/About home navigation clears stale help fragments. Copyright remains Ed Lopez per LICENSE and the owner's conditional instruction.

[Authentication roadmap](../archive/2026-09-05/AUTH_ROADMAP.md) is discovery/design only. No account UI, email sending, quota enforcement, Access/provider configuration or D1 mutation was introduced. Desktop development remains frozen; its retained build and runtime were checked for regression.

## Evidence

- Final repository tests: 228/228 PASS, `.local/logs/legacy-20260905/.accreatio-v13-tests.log`. An initial run overlapped the documentation agent's replace operation; it is superseded by the complete final run. The previously observed desktop temporary-file EPERM did not recur in the final run.
- Typecheck for app/Electron/Functions; format; web and desktop builds; Functions build; surface isolation; Electron privileged execute smoke: PASS. Receipts `.accreatio-v13-{typecheck,format,build,desktop-build,functions,surface,electron}.log`. The first surface check raced the unfinished web build; the final check after both builds passed.
- Production-build browser functional pass: English 390x600, Spanish 320/760, English 1280 reduced motion, plus main workflow. Covers mode changes in both directions, choice without execution, cancellation, real ZIP contents, duplicate activation, attached-file preservation through help/new-tab navigation, all-step help presence, existing draft/roles/name/footer/nebula regressions. `.local/logs/legacy-20260905/.accreatio-v13-ui.log`.
- Additional current-build checks: FAQ/ToS/operation/security deep links at 320/390/1280, no welcome interception, heading focus, no horizontal overflow, 44px help controls in document flow, and header/About home fragment cleanup followed by reload. `.local/logs/legacy-20260905/.accreatio-v13-help.log`, `output/playwright/v13-help-receipt.json`. Screenshots `v13-{320,390,1280}-{help,confirm,faq}.png`; mobile confirmation and mobile/wide help inspected visually.
- The home-helper delta required updating the existing shell test's inline-callback source assertion to its named-handler equivalent; the final full 228-test run and delta formatting pass cover it. Browser checks exercise the behavior directly.
- Lighthouse: performance 96, accessibility 100, best practices 100; SEO 66 passes only the existing intentional private-beta noindex exemption. `.local/logs/legacy-20260905/.accreatio-v13-lighthouse.log`. Measured before the bounded home-fragment helper delta; that delta does not change rendered layout or loading dependencies.
- Canonical FAQ/ToS versus complete static text parity independently checked in the parent review. These remain restricted-beta product drafts, not a claim of formal legal review.

Hosted authenticated acceptance is separate from local browser verification and anonymous Access boundary checks. Deployment metadata will be recorded below after the exact committed candidate is uploaded.

## Protected testing deployment

Committed and pushed implementation: `0f7e216a42783458f81bc6854c8f320c407b3052` on `feat/guided-creation-nebula`. Wrangler exited 0; Cloudflare readback reports successful preview `77e26090-6da5-4ef8-9627-6808760cef88`, this exact commit, and `commit_dirty: false`.

- Testing URL: https://design-v13-preview.accreatio.pages.dev
- Immutable artifact: https://77e26090.accreatio.pages.dev
- Eight anonymous checks of the new alias, Blog API, brand asset, FAQ, ToS, immutable URL, retained v12 alias and production all redirect to Cloudflare Access. Receipts: `.local/logs/legacy-20260905/.accreatio-v13-deploy.log`, `output/playwright/v13-access-after.json`.
- Retained v12 and canonical production IDs/SHAs still match the pre-deployment records. No production promotion, Access policy change, account/email operation, D1 mutation or desktop release occurred.

The final documentation-only commit records this verified deployment. Owner testing uses the existing approved Access identity; no authenticated hosted session was borrowed or bypassed for local verification.
