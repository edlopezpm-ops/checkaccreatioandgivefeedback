# Independent parent review: v13

Date: 2026-09-04. Reviewer: independent `parent_review` agent. Scope: the working-tree v13 increment described by DESIGN.md, including the authentication proposal. No source changes, implementation delegation, deployment, or legal certification were performed by this reviewer.

## Verdict

PASS for the reviewed implementation and design scope. No material unresolved finding. Authentication and the daily allowance remain design only. Deployment and the final source/deployment identity readback belong to the orchestrator's release record.

## Findings and evidence

- Confirm export changes both directions by replacing the captured definition's `dryRun`, allocating a fresh operation ID, and synchronizing project state. The captured settings and attachment sidecar survive the replacement. Mode selection does not call execute. The final operation-ID check, synchronous duplicate gate, cancellation cleanup, and subsequent bridge validation remain intact.
- FAQ and ToS controls appear below every guided question, review, and outcome. Navigation changes the destination without replacing the project or in-memory attachments. Target headings receive focus and measured-header scroll placement. Full legal pages open isolated tabs. The web onboarding mark becomes decorative; the desktop callback remains unchanged.
- Independently compared canonical document paragraphs/headings with the corresponding static HTML, ignoring markup and whitespace: all 62 FAQ entries and all 51 ToS entries were present. The About summary consistently describes current local generation, draft/file boundaries, protected access, and separate editorial storage. No new account/quota behavior is asserted as live.
- LICENSE expressly identifies Ed Lopez. Keeping that copyright follows the user's conditional instruction; AEKR branding is not treated as a documented ownership assignment. Terms remain an explicitly bounded product draft with legal-review gaps acknowledged, without an invented legal entity, jurisdiction, or liability cap.
- AUTH_ROADMAP distinguishes five new server authorizations from five successful local saves, preserves idempotent retries, identifies the limits of enforcement when code remains local/offline, and separates export policy from hosting traffic protection. It specifies that email-only profile collection still needs session/quota metadata, no name/password or persistent provider credentials, provider/free-tier constraints, and explicit later implementation decisions. No authentication, Access policy, quota endpoint, or account-store implementation appears in the diff.

Reviewed terminal evidence: `.local/logs/legacy-20260905/.accreatio-v13-tests.log` (228/228), typecheck, formatting, web and desktop builds, Functions compilation, Electron privileged smoke, and final surface smoke. The earlier overlapping/incomplete-build surface run is not credited. Reviewed browser smoke evidence covers Spanish 760px and 320px, English 390px and 1280px with reduced motion, both confirmation mode transitions, no download on selection/cancel/dry review, real ZIP contents, duplicate activation, and selected-file preservation through help.

Additional root-produced evidence inspected: `.local/logs/legacy-20260905/.accreatio-v13-help.log` and `output/playwright/v13-help-receipt.json`, covering FAQ/ToS/operation/security deep links at 320px, 390px and 1280px, without onboarding interception, horizontal overflow, or console errors. Help controls are in normal flow with 44px minimum height. Browser receipts are implementation evidence reviewed independently; this review does not claim a separate duplicate browser execution.

## Bounded correction

Source review identified a minor stale About fragment when returning to welcome. The orchestrator corrected it with the shared `openWelcome` helper used by header and About home controls. A bounded delta review confirms it clears the About target and URL fragment while preserving pathname/search and existing welcome behavior. The orchestrator will record the rebuilt-artifact home-navigation check; no full audit restart is warranted for this contained correction.

## Limits

This is an engineering parent review, not formal legal advice, an authentication implementation acceptance, a real-device certification, or a production release approval. Provider limits are dated discovery inputs and must be checked again before provisioning. Production, Access policy, and Blog publisher authority remain outside this increment.
