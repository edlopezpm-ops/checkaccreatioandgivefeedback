# Confirm export, persistent help, and sign-in discovery

Date: 2026-09-04. Owner-requested web increment after accepted v12 footer restoration. Desktop remains frozen; no authentication, quota, provider, Access policy, D1, or Blog publisher implementation is authorized in this increment.

## UI scope

- The onboarding logo/name is decorative on both welcome steps. The header's home control remains available.
- Confirm export contains an explicit two-option radio choice: review without downloading or create/download ZIP. Changing it updates the captured pending request, its operation ID, project state, preview and final button together. Selecting a mode never executes. Cancel and duplicate-submit gates remain effective; selected files remain in memory.
- FAQ and ToS appear in a quiet icon/text row below every project question, final review and outcome. On question screens they precede the existing reassurance. The row stays in document flow, wraps on mobile and uses 44px targets.
- Help controls open the corresponding About section without reloading the app or dropping the draft/files. Section headings receive focus below the measured sticky header. Full legal documents open isolated new tabs. Allowed About fragments also work from the static documents.
- Web About includes expanded bilingual practical FAQ and a terms overview. Canonical FAQ/ToS and their complete static copies are expanded together. Existing desktop About content is retained.
- Keep Ed Lopez as legal copyright holder because LICENSE expressly identifies him and no ownership assignment to AEKR is recorded. AEKR remains the associated brand. This follows the owner's conditional instruction to retain his name if appropriate.

## Authentication: design only

[AUTH_ROADMAP](../archive/2026-09-05/AUTH_ROADMAP.md) compares existing protected Access OTP, public email-code delivery, Google and Apple; proposes no name/password, minimal identity/session/quota data, and five new ZIP authorizations per account per UTC day with idempotent retries. It separates official-client policy from impossible claims of hard control over locally available ZIP code. It also distinguishes the export allowance from hosting traffic protection. No sign-in or quota behavior is activated.

## Verification and archive

Run repository tests, typecheck, format, both builds and surface/privileged smoke to protect the retained desktop graph, plus production-build browser checks. Browser coverage must include both modal mode transitions, cancellation, no download on selection, real ZIP contents, duplicate activation, attachment survival through help, all-step help availability, deep links and small viewports. One independent parent review follows the required leaf checks; no leaf audits.

Retain v12 preview `5650337d-81fd-4213-83ce-e9a91c8aac45` / `https://5650337d.accreatio.pages.dev`, source `b1d106f1f88f63fb41883c2105fa7bbdfd98d397`. Publish the verified candidate to a new `design-v13-preview` alias. Production remains separate (`11235c8c-108f-46f3-8cce-fb88a144330b`, source `8735952c01560218d9dc5d95d5f298329f18d6e5`). These IDs were read back before this increment's deployment.
