# Google OIDC compatible rollback

Scope: accreatio preview only. Prepared 2026-09-08. Six automated rollback cases pass in `tests/accountRollback.test.ts`.

The safe fallback disables new Google admission while retaining the account implementation that understands encrypted contacts and schema 0003. Existing account IDs, session revocations, deletion decisions and allowance receipts must survive. This fallback intentionally prevents fresh sign-in; account controls that require recent authentication can expire while sign-in is disabled. The published rights contact remains available.

## Immutable recovery material

- Git commit: `948aac2f53b9cc26bf6fa42a12aea7a657fff189`.
- Remote tag: `rollback/google-oidc-privacy-20260908`.
- Compatible preview deployment: `a2c34f21-8622-431d-b7a2-95b572fada51`.
- Account D1: `3c42de52-6883-4f1a-b81a-3c693abab64d`, migration 0003 applied.

Recovery files are retained in `.local/private/auth-20260908/`, outside disposable caches and Git. The directory is restricted to the current Windows user. The source and web archives contain no runtime secrets.

| Artifact               | SHA-256                                                             |
| ---------------------- | ------------------------------------------------------------------- |
| `source-948aac2.zip`   | `e473de0313d5f57c0aefadd5c3330d498c16e81bde20bc49f71dda61137e5c92`  |
| `web-948aac2.zip`      | `827548a65a003d10ea294d852fa3e1b20a88ef9d2ffeea4dd0e7755304d48adfe` |
| `functions-948aac2.js` | `6808d0c1b391682652441a3e78a8c9c2810c771339c97b1d9e0cf9b5f55255a7`  |

`preview-before.sql` is a pre-migration backup for isolated recovery, not an application rollback. `pages-before.json` records provider configuration; its pre-existing identity/OTP secrets are redacted and cannot be recovered from that JSON. `preview-keys.json` and `maintenance-keys.json` hold the new keys created for this implementation. Never print or commit these files. Keep the original `ACCOUNT_IDENTITY_KEY` and all encryption/lookup/continuity keys in their current runtime configuration. This is a compatible application rollback, not a claim that every pre-existing provider secret has a new recoverable local backup.

## Execute the compatible fallback

Use the same account and preview deployment branch; do not target `main` or production. From the repository, create a separate checkout so ongoing work is preserved:

```powershell
git fetch origin refs/tags/rollback/google-oidc-privacy-20260908:refs/tags/rollback/google-oidc-privacy-20260908
git worktree add .local/cache/google-oidc-rollback rollback/google-oidc-privacy-20260908
Set-Location -LiteralPath .local/cache/google-oidc-rollback
npm.cmd ci
npm.cmd run log -- build:web
npm.cmd run log -- cloudflare:functions:build
$env:WRANGLER_LOG_PATH = '.local/logs/wrangler'
node node_modules/wrangler/bin/wrangler.js pages deploy dist --project-name accreatio --branch google-oidc-preview --commit-hash 948aac2f53b9cc26bf6fa42a12aea7a657fff189
```

Run the commands sequentially and stop on any failure. The tagged preview configuration contains `ACCOUNT_OIDC_ENABLED=false` and `ACCOUNT_OTP_ENABLED=false`; Wrangler applies these plain variables while retaining the protected runtime secrets. The existing preview access policy remains in force. Do not use a code rollback to an older Access-only or plaintext-only version, turn OTP on as an emergency substitute, replay migrations 0001/0002, remove schema 0003, rotate identity keys or restore the old database over newer state.

After deployment, read back its successful stage, exact branch/commit, preview bindings and disabled flags. With an existing authorized session, verify account identity and allowance continuity; without authentication, private account/admin endpoints must remain denied. Verify eligible cleanup continues on `accreatio-account-maintenance-preview` and preserve the keys it needs. The source-tag fallback does not modify its schedule or introduce a public maintenance endpoint.

If a key is missing, recover that exact protected key or keep the affected operation unavailable. Do not create replacement key material under the same version. Database restoration is a separate isolated procedure: reconcile every newer deletion, revocation and receipt before any restored store can serve requests.

## Re-enable after recovery

Use a corrected reviewed build and actual Google client configuration, then enable Google only in preview. Exercise a real Google exchange, existing issuer/subject account continuity, quota retry, local attachments, account export/deletion and scheduled retention. The six fixture-based rollback cases verify the local contracts; they do not establish a Google-hosted login or a live rollback after real user traffic.

## Profile-name and header-menu increment

Migration `0004_google_display_name.sql` is additive and remains installed during rollback. Keep the original encryption key. Its deletion trigger clears the new ciphertext even if an older compatible writer only sets `deleted_at`; do not drop the trigger or column.

Preferred menu rollback: tag `rollback/google-profile-backend-20260908`, commit `b8dc78a2cad607e6ff2cbc995664556e105608e7`, retains the profile-aware account backend and notices with the preceding account layout. Build it in an isolated checkout and deploy only `google-oidc-preview`, using the same procedure above with this tag and commit. It keeps the name readable in own-account export and removable on deletion. Re-check the displayed Google consent/notice, session and allowance after restoration.

Tag `rollback/google-profile-menu-20260908` (`11d765f`, deployment `e0ce4a5c-d486-44b6-a163-e1094b1cdb08`) is the earlier proven email-only Google login. It can read the account after 0004 and its deletion is protected by the trigger, but its data export omits the additional stored name. It is therefore an emergency fallback with incomplete profile export, not the preferred privacy-compatible menu rollback. Prefer the profile-aware tag and retain the published rights channel during any outage. Never restore an old database over later deletions, revocations or receipts.
