# AEKR asset preservation

**Current status ? 2026-09-05:** The owner accepted this pilot and approved the README rollout under Documents > VS Code, excluding archive and master archiving. The pilot verification below is a historical receipt for commit `9948dda`, not a requirement for another GO. The approved banner is now the AEKR root/scaffold default. The rollout PR targets accreatio `main` with only the PNG and corresponding embedded Project Map bytes; this branch retains the complete accepted pilot and preservation tools.

Owner instruction: 2026-09-05. AEKR is the source of truth for the master logo, README banner and existing web footer. Copy the approved source assets; do not redraw, regenerate, retype, trace, recolor or substitute their logo, lettering or orbital forms. Preserve local copies so rendering needs no remote image request.

## Canonical sources and local copies

Paths in the AEKR column are relative to the sibling `AEKR` repository. Its [branding guide](../../AEKR/toolkit/project-scaffolds/project-branding/README.md) defines reuse and pilot status.

| Surface | AEKR canonical source | accreatio copy / consumer |
| --- | --- | --- |
| Master logo | `assets/aekr-logo.png` | `assets/aekr-logo.png`; preserved source asset, not a new UI placement |
| Soft-edge banner pilot | `assets/aekr-banner-soft-v1.png` | `assets/aekr-banner.png`; root README and generated Project Map |
| Footer mark | `toolkit/project-scaffolds/project-branding/web-footer/assets/aekr-mark.svg` | `src/assets/aekr-mark.svg` |
| Footer component | `toolkit/project-scaffolds/project-branding/web-footer/components/AekrSignature.tsx` | `src/components/AekrSignature.tsx` |
| Footer styling | `toolkit/project-scaffolds/project-branding/web-footer/aekr-footer.css` and its reuse README | Exact existing rules in `src/styles.css`, `src/responsive.css` and `src/web-branding.css` |

The banner is owner-approved. Copy the exact approved PNG from AEKR for existing README consumers and new project seeds. The current rollout uses one pull request per applicable repository; it does not authorize merges or deployments.

## Existing footer contract

The current footer is preserved without runtime or CSS changes. Its accepted appearance is recorded in [Original footer restoration](design-v12/FOOTER_RESTORATION.md): existing orbital SVG, uppercase lettering and tracking, translucent badge, 21px artwork, shared social styling, 44px targets, mobile text collapse and layout in document flow. AEKR and Instagram retain their existing destinations and isolated new tabs; X and LinkedIn remain inert pending profiles.

When reusing it elsewhere, copy the AEKR bundle and its license notice. Only asset/type import paths and an equivalent `"en" | "es"` locale type may be adapted during integration. Preserve the markup, SVG geometry, CSS declarations and documented visual token values. Any visual or behavior change requires an explicit owner request and a new version; do not silently fork the canonical bundle.

## Bounded change rationale

Before implementation, the source search found one shared PNG for the README and Project Map, plus an existing accepted footer component, SVG and CSS. The defect is the banner's outer fringe and the absence of one reusable canonical home for the complete footer. The selected Minimum Sufficient Change level is reuse: exclude the multi-repository rollout and product redesign, preserve the existing source bytes, and document the upstream/downstream mapping. The manifest and read-only integrity command add one bounded maintenance surface to detect accidental replacement; they introduce no dependency, service, runtime abstraction or UI behavior. The default check is local and offline. Set `AEKR_PATH` explicitly to also compare the pinned assets with that upstream checkout; the checker does not infer a sibling location.

Replacing the local banner requires regenerating `accreatio-project-map.html` with `npm.cmd run project-map:build`; the generator embeds the local PNG bytes. Verify with `npm.cmd run project-map:check` and the existing Project Map tests. The preservation bundle's source equality and footer token dependencies are verified separately from visual acceptance of the banner.

## Pilot verification — 2026-09-05

The original master logo in AEKR is already byte-identical to the owner's attached `AEKR.png`; the accreatio copy preserves those bytes. The original banner remains in AEKR at `assets/aekr-banner.png` for comparison and rollback. Its root README and scaffold consumers retain that original during the pilot.

The first imagegen edit was rejected because it changed proportions. The installed variant instead uses a local alpha-only mask over the original PNG: same 1474 × 420 canvas, no RGB changes anywhere, no interior changes, and a 12-pixel smoothstep feather inside the rounded perimeter. The enclosing silver fringe becomes transparent. No generated artwork enters either repository.

| Check | Result |
| --- | --- |
| Pixel preservation | PASS: 0 RGB pixels changed; 63,122 alpha pixels changed at the perimeter |
| Browser alpha and light/dark preview | PASS: corner and old border alpha 0; feather sample 128; interior sample 255 |
| Unit tests | PASS: 228/228 |
| Typecheck, web and retained desktop builds | PASS |
| Project Map generation, consistency and functional smoke | PASS: 12 flows, 4 viewports, zero external requests |
| Web functional smoke | PASS: guided flows at 320/390/760/1280; footer destinations, isolated tabs and inert profiles |
| Retained Electron execute smoke and surface boundary | PASS |
| Asset integrity | PASS: all 4 local pins and AEKR sources match; altered asset rejected in an isolated temporary copy |
| Formatting and whitespace | PASS |

The retained Electron smoke uses compiled development output. A new portable package was not produced: desktop releases remain frozen and these README/master assets are outside `build.files`. This is not a claim of packaged-release verification, hosted deployment or visual acceptance.

Review the [light/dark comparison](../output/branding/banner-comparison.png), [pixel receipt](../output/branding/banner-verification.json) and [browser receipt](../output/branding/browser-alpha-verification.json). Named command logs are `.accreatio-branding-*.log`. The output manifest in `output/branding/changed-artifacts.json` binds the bounded changed artifacts; unchanged runtime files are outside that manifest.

After implementation: one local banner replacement and its regenerated map, one master-logo copy, canonical footer references in AEKR, a four-file provenance manifest and a read-only hash check wired into `verify`. No new dependency, runtime abstraction or public API was introduced. The checker adds only a bounded file loop and optional upstream comparison; it never writes or regenerates assets. Existing footer source/CSS and scaffold defaults are reused unchanged. Human visual acceptance and downstream PRs remain pending the owner's requested GO.

Run `npm.cmd run aekr:branding:check` to verify the canonical paths and pinned hashes in `assets/aekr-branding.json`; set `AEKR_PATH` to the canonical checkout when needed for upstream comparison. Preserve PNG/SVG bytes and the footer component's source content; line-ending normalization does not authorize rewriting it. The documented exact CSS excerpts remain the styling reference. A changed asset must be an explicit new version with updated provenance, not a silent manifest refresh that blesses an accidental redraw.

The footer preservation leaf verified exact byte equality of the SVG, component and source license, exact unchanged excerpts from all three source stylesheets, and documentation of all 12 CSS custom properties used by those excerpts. Its only accreatio changes are this source mapping and the AGENTS preservation pointer; product footer source and styles remain unchanged. The AEKR inventory consists of its branding README update and the bundle's README, SVG, component, CSS excerpts and original source license. Those copies add no runtime branch, complexity or dependency to accreatio.
