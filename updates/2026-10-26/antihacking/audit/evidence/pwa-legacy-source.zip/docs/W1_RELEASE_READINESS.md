# Protected Web Portal — Release Readiness Runbook

**Status:** release `0.8.0` was deployed on 2026-08-06 from exact commit `8735952c01560218d9dc5d95d5f298329f18d6e5` after full Windows CI and the fresh Claude AEKR audit of its code-equivalent candidate. Production and preview D1 both have the reviewed migration plus exactly three founding rows. Anonymous Access denial is verified. Publisher authorization and owner/service-authenticated hosted acceptance remain pending, so human and agent publishing are not represented as active. `CHANGE_CONTROL.md` is authoritative for the live evidence.

DEC-009's protected free `*.pages.dev` restriction remains. DEC-016 supersedes only its “no Functions/backend/database” boundary for the web-only editorial channel; it does not authorize anonymous access, custom DNS/domain cost, analytics, hosted AI, project uploads/storage, billing, a remote executor, or broad promotion. DEC-017 keeps all Blog/editorial/PWA/Cloudflare material out of Electron.

## Frozen `0.8.0` contract

- Product definition: “accreatio is an authenticated, local-first, ephemeral-session web application for creating and exporting projects.”
- Cloudflare Access protects the portal; accreatio has no internal password/account system.
- Project form content, attachments, ZIPs, paths, and optional GitHub/IDE/AI credentials remain local and never enter the editorial API/D1.
- One project draft may persist in local IndexedDB; attachments remain tab-only. Published Blog posts persist separately in D1.
- Three same-origin Pages Function routes provide authenticated post reads, minimum admin capability, and append-only publish.
- Ed Lopez may publish through the web composer after server verification. Separately allowlisted AEKR service identities use the same endpoint with their own revocable Access service token.
- No agent path is called active until its narrow Service Auth policy and one real allowlisted token are exercised.
- `dist/` is web-only. `dist-desktop/` is Electron-only and contains no Blog, admin, API, PWA/Workbox, Function, migration, or founding-content material.
- Pages Functions and D1 must remain within the zero-direct-cost constraint. Stop before any charge.

## Repository release artifacts

- Web entry/output: `index.html`, `src/main.web.tsx`, `dist/`.
- Desktop entry/output: `desktop.html`, `src/main.desktop.tsx`, `dist-desktop/`.
- Editorial routes: `functions/api/blog/posts.ts`, `functions/api/admin/blog/session.ts`, and `functions/api/admin/blog/posts.ts`.
- Shared edge implementation: `functions/_lib/`.
- D1 schema/seed: `migrations/`; reviewed source fixture: `content/blog/founding-posts.json`.
- Pages/D1 bindings: `wrangler.toml`; generated binding types: `functions/types.d.ts`; safe local placeholders: `.dev.vars.example`.
- Pages route scope: `public/_routes.json` must invoke Functions only for `/api/*`.
- Static headers/legal: `public/_headers` and `public/legal/`.
- Canonical architecture: `project-map.json` plus generated `accreatio-project-map.html`.

The owner Word source remains ignored under `.aekr/sources/` and is not a release artifact. The browser has no bundled Blog-content fallback; D1 is the sole runtime post source.

## Protected runtime configuration

Production and preview bind separate D1 databases as `BLOG_DB`. The following values are protected runtime configuration and must never be committed or copied into release evidence:

| Name | Purpose |
| --- | --- |
| `BLOG_ACCESS_ISSUER` | Fixed HTTPS Access team issuer |
| `BLOG_ACCESS_AUDIENCES` | JSON array of accepted application audiences; preview may differ from production |
| `BLOG_HUMAN_ADMINS` | Protected email-plus-subject map to bounded safe labels |
| `BLOG_AGENT_ADMINS` | Protected service `common_name` map to bounded safe labels |

Service client IDs/secrets remain only in the administrator's secret store. Human and service maps contain sensitive identifiers; release notes record only safe labels and whether the gate passed.

The current Pages project is GitHub-connected, but branch control disables automatic production deployments and sets automatic preview deployments to `none`. The source connection may remain installed; `0.8.0` is released only through the reviewed Wrangler command after the exact commit is green.

## Pre-mutation gates

1. Confirm the authenticated Cloudflare account and D1/Pages Functions use remain within the free plan. Stop before a paid plan, purchase, or charge.
2. Confirm anonymous requests to the stable and preview origins still fail closed through Access. Do not weaken the existing human Allow policy.
3. Download/reconcile the current Pages configuration before committing bindings. Production and preview must not share a D1 database ID.
4. Complete local migration and founding-seed parity checks against Wrangler's local persisted simulation.
5. Pass tests, generated Worker types, Function and application typechecks, formatting, both production builds, Project Map parity, desktop artifact scan, Electron/Web functional smokes, responsive visual inspection, dependency audit, and the existing project ZIP flow.
6. Commit and push the exact candidate; require green CI.
7. In a fresh context, have an independent reviewer compare all current code/configuration with all current documentation and the canonical map at that pushed commit. The reviewer reports only and must not have authored the candidate. Reconcile accepted findings, rerun gates, and push the final exact commit before deployment.

## Provisioning and deployment order

1. Create separate production and preview D1 databases only after the free-plan gate.
2. Commit the actual bindings and migration configuration; do not commit protected values.
3. Apply the reviewed migration/seed to preview, verify three founding rows, then apply to production.
4. Set the four protected runtime values for each environment.
5. Configure a narrowly scoped agent Service Auth policy/token only if it can coexist with—never replace or broaden—the owner human Allow policy. Otherwise leave agent publishing pending.
6. Reprobe anonymous stable/preview access before upload.
7. Deploy the exact final commit with Wrangler from the repository root so `functions/` is included. A dashboard static-asset upload is not a valid `0.8.0` release path.
8. Record deployment ID, immutable URL, branch/SHA, migration result, safe configuration status, policy shape, anonymous probes, and rollback in `CHANGE_CONTROL.md` without secrets or raw identities.

## Hosted acceptance

| Gate | Required evidence |
| --- | --- |
| Access perimeter | Anonymous production and preview denied; owner sign-in succeeds |
| Exact release | Deployment metadata matches the final pushed/audited SHA and clean source |
| Blog read | Authenticated `GET /api/blog/posts` returns exactly the seeded founding posts from D1 |
| Human admin | Owner session returns `canPublish: true`; non-admin valid identity returns false |
| Publish | Owner deliberately publishes a real intended post, or leaves this acceptance pending; never create a throwaway public post |
| Agent admin | Narrow Service Auth plus a real allowlisted token succeeds without changing human access, or status remains explicitly pending |
| Failure behavior | Missing/wrong issuer/audience/claim shape/config/D1 fail closed; cross-origin browser writes fail |
| Headers/privacy | JSON/API no-store/nosniff; static CSP/anti-frame/referrer/permissions/noindex remain correct; no secret/body/identity logging |
| Local project boundary | Project text/attachments/ZIP/credentials absent from Blog traffic; minimal ZIP creation works with no external integration |
| Desktop boundary | Packaged artifact contains no Blog/admin/API/PWA/Function/D1/founding-content material |
| Browser quality | Dark/light and narrow/wide Blog/project flows, no horizontal overflow, accessibility announcements, online/offline boundary, and expected egress inspected |

If an owner-authenticated or service-token check cannot run, deployment metadata may be recorded but the corresponding hosted acceptance must remain pending.

## Current protected deployment evidence (`0.8.0`)

| Evidence | Recorded value |
| --- | --- |
| Stable protected origin | `https://accreatio.pages.dev` |
| Immutable deployment origin | `https://11235c8c.accreatio.pages.dev` |
| Deployment ID | `11235c8c-108f-46f3-8cce-fb88a144330b` |
| Created / completed | `2026-08-06T19:12:57Z` / `2026-08-06T19:12:59Z` |
| Environment / trigger | `production` / Wrangler Direct Upload (`ad_hoc`) |
| Branch / commit | `main` / `8735952c01560218d9dc5d95d5f298329f18d6e5` |
| Cloudflare result | `deploy: success`; `commit_dirty: false` |
| CI | GitHub Actions run `31126665469`: success |
| D1 | Production and preview migrated; production read-only query returned the three founding rows with `release-seed` actor labels |
| Anonymous probes | HTTP `302` on stable root, stable `/api/blog/posts`, and immutable deployment root |
| Publisher state | Human and agent allowlists deliberately empty/fail-closed; authenticated acceptance pending |

## Historical first deployment evidence (`0.7.0` static beta)

| Evidence | Recorded value |
| --- | --- |
| Stable protected origin | `https://accreatio.pages.dev` |
| Immutable deployment origin | `https://5e1ab5c8.accreatio.pages.dev` |
| Deployment ID | `5e1ab5c8-67ca-4c4f-a574-990ad34fa973` |
| Created | `2026-08-06T15:26:20Z` |
| Environment / trigger | `production` / Direct Upload (`ad_hoc`) |
| Branch / commit | `main` / `39ea088175e69430fa9f2539681ea978b264675d` |
| Cloudflare result | `deploy: success`; `commit_dirty: false` |
| Access applications | Exact `accreatio.pages.dev` plus wildcard `*.accreatio.pages.dev`; one owner-only Allow policy on each |
| Anonymous probes | HTTP `302` to Cloudflare Access on stable production and immutable deployment origins |

This table is historical evidence only. It does not prove `0.8.0` Functions, D1, Blog, publisher, new policy shape, or hosted acceptance.

## Rollback

Source rollback returns to `0dbbefd03305e56af2e4febbf129d64fcdc064c2` (`0.7.0`) or another separately approved known-good deployment while Access remains in place. Preserve D1 for recovery rather than deleting it; the rolled-back application has no route or binding to the database. Disable/revoke any `0.8.0` Service Auth policy/token without altering the owner's human policy. Reprobe anonymous denial after rollback and record the action.
