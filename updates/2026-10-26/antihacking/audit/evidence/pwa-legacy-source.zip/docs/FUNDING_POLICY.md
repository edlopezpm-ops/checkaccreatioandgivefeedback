# Funding policy

accreatio defaults every orchestration definition to `subscription_cli`: USD `0`, with paid API use prohibited. The existing `maxProviderInvocations` remains a separate aggregate call-count safety limit; it is not a monetary estimate or guarantee.

The web-only Blog's Cloudflare Pages Functions and D1 usage is a separate infrastructure decision under DEC-016, not AI-provider funding. It must remain inside Cloudflare's free plan; provisioning or rollout stops before any paid requirement or charge.

Paid API mode is visible but unavailable. Neither current compiled provider has an evidenced model profile or versioned AEKR runtime contract capable of enforcing an exact cumulative, currency-denominated hard stop before overspend. Estimated, post-hoc, or per-invocation limits do not qualify. accreatio never falls back to paid use.

Generated `.accreatio/project.json` records `fundingPolicy`. Runnable AEKR YAML does not receive an unsupported funding block and no longer emits Claude's fixed `max_budget_usd: 1.0` or the commented `budget.ceiling: 10.0`. Browser draft schema v4 defaults only an absent legacy funding field to subscription; explicit malformed or API-shaped state is preserved and blocks validation.

Future API enablement requires owner approval plus compiled provider/model-profile evidence, exact cumulative pre-invocation enforcement in a versioned AEKR contract, currency and serializer tests, fresh execution preflight, and updated security/support documentation. No flag, credential, or dynamic manifest can bypass that review.
