# GitHub identity: registration, activation and compatible fallback

Prepared 2026-10-21. The implementation and local evidence use synthetic HTTPS providers and real SQLite/D1. Current registration, runtime configuration, deployment and real-provider outcomes belong to the integrated [readiness record](READINESS_2026-10-21.md). Local tests do not establish those outcomes; any required hosted journey without its own successful evidence remains **BLOCKED**.

## Decision and verified provider contract

### Execution receipt — 2026-10-21

Ed explicitly authorized configuration and completed GitHub's access confirmation
personally. Two separate GitHub Apps were registered: preview
`accreatio-preview-identity` (5412791, owner-only) and production
`accreatio-web-identity` (5412799, public). Actual permission readback is only
`emails:read`; callback wildcards, webhooks, device flow and authorization during
installation are disabled. No repository installation or user grant was performed.

The four GitHub bindings were uploaded separately to each Pages environment.
Both initially used `ACCOUNT_GITHUB_ENABLED=false`. Secrets are encrypted runtime
configuration, held locally only in an ignored owner-restricted custody directory;
their values never enter source, logs or this report. A configured App does not
establish successful real-provider sign-in.

Old preview deployments were inventoried. Their OAuth origin check does not
disable legacy account writers or make them understand action-specific proof.
Therefore the controlled preview receives a new isolated account D1,
`accreatio-accounts-readiness-preview`, UUID
`57a35f00-dc04-4d6d-a485-c96e1d534ed2`. The protected old-preview snapshot with
migrations 1–4 was restored only into that new target, then migrations 5 and 6
were applied successfully. All original columns/rows compare identically:
two accounts, two identities and no sessions, transactions or allowance receipts.
There are zero backfilled policy authorizations, integrity is ok and FK errors
are zero. Payloads were not displayed or decrypted. The old preview D1 and
production D1 remain unchanged. The preview maintenance worker now binds the
new target, version `36970b73-ea3b-4267-8266-028f9e38aa36`, with its existing
hourly schedule and privacy keys. Evidence: `preview-migration-preservation.json`
and `preview-maintenance-deploy.log` in the readiness evidence directory.

A separate SQLite restore verified the protected snapshot before migration.
This is preview recovery evidence, not a destructive production restore. Hosted
deployment, activation and real OAuth outcomes are recorded separately below
and in the readiness matrix as they occur.

The preview flag was subsequently set to true and candidate
`0dec26d9fc299e8612b32fd8b93f090361cc25cc` deployed at 15:45 UTC as
`176390b5-2148-4010-8bac-de88f2b592c9` in `google-oidc-preview`.
Provider API readback confirms that source and the isolated D1 binding.
Cloudflare Access still requires the owner's browser sign-in before hosted
methods/UI/OAuth can be checked. Access was not disabled or bypassed.
That was the initial preview-only state. Ed subsequently authorized deployment
directly to accreatio.com. Production migration 0006 passed on the existing
account D1 after a protected snapshot and isolated SQLite restore; all original
columns/records compare identically, including two accounts/two identities,
one policy authorization and one allowance receipt. No payload was displayed
or decrypted; no destructive restore or historical acceptance backfill occurred.

Production GitHub is now enabled. Deployment
`3027a9b5-f62e-4f68-99eb-45731f06a630` completed at 15:53:03 UTC, same code
`0dec26d9fc299e8612b32fd8b93f090361cc25cc`. accreatio.com serves the tested
final JS bytes; methods report Google/GitHub available and OTP unavailable,
with no-store. The in-app browser displays both provider buttons and the new
public example. This is deployment/capability evidence, not real user OAuth.
Provider consent, linking, action-specific account controls and authenticated
production export have not been performed. Preview Access remains enabled.

The subsequent button-layout correction is now served by production deployment
`434eef0b-6693-46c1-a789-d356d4b37e25`, code
`97f0b485c14374ebb9711015b8f2914578f83cb9`, completed at 16:07:42 UTC.
Full local verification passed again and production serves identical final
artifact bytes. Authentication logic, account D1 and migration state did not
change in this correction; the real-provider checks above remain unperformed.

Use **one GitHub App**, exclusively its user authorization web flow. Do not register an OAuth App for this implementation. GitHub documents PKCE `S256` and a `code_verifier` for this flow; permissions come from the App registration, rather than OAuth App scopes. The application requests no `scope`, offline access, installation, repository or organization access. See [GitHub App user authorization](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) and the [authorization/installation distinction](https://docs.github.com/en/apps/using-github-apps/authorizing-github-apps).

The only account permission is **Email addresses: Read-only**. `/user` establishes the numeric identity on every authorization; `/user/emails` supplies a primary verified email, including a private address. Email retrieval follows fixed numbered pages, up to ten pages of 100 entries, failing closed if more remain. The API version is `2026-03-10`. See [email permissions and pagination](https://docs.github.com/en/rest/users/emails). No installation access token, App private key, webhook, repository read, GitHub write or refresh-token storage is required.

## Actual runtime configuration

| Binding/variable               | Destination and meaning                                                                                                                                                                                                      |
| ------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `ACCOUNT_GITHUB_ENABLED`       | Runtime flag (currently stored as a protected Pages binding), exactly `true` after controlled activation; missing/false keeps GitHub unavailable.                                                                            |
| `GITHUB_CLIENT_ID`             | Server configuration for the GitHub App's **Client ID**, not its numeric App ID.                                                                                                                                             |
| `GITHUB_CLIENT_SECRET`         | Protected Pages secret only, distinct for each environment. Never send it in chat, logs or source.                                                                                                                           |
| `GITHUB_REDIRECT_URI`          | Exact server callback URI for that environment, without query, fragment or wildcard.                                                                                                                                         |
| `ACCOUNT_DB`                   | Existing separate account D1 with migrations `0001` through `0006`. Never the Blog database.                                                                                                                                 |
| Existing identity/privacy keys | Preserve `ACCOUNT_IDENTITY_KEY`, `ACCOUNT_EMAIL_ENCRYPTION_KEY`, `ACCOUNT_EMAIL_LOOKUP_KEY`, `ACCOUNT_AUTH_LOCATOR_KEY` and `ACCOUNT_OIDC_TRANSACTION_KEY`. Reuse their existing versions; do not generate replacement keys. |
| Existing Google variables      | Preserve `ACCOUNT_OIDC_ENABLED`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URI`. Google remains independent of GitHub availability.                                                                       |

Endpoints added: `POST /api/auth/v1/oidc/github/start` and `GET /api/auth/v1/oidc/github/callback`. The existing `/api/auth/v1/methods` now reports `github.available`; the account session reports `connectedProviders`. UI availability and account actions derive from those responses. A visible button is not proof that a provider login has passed.

Fixed callback values prepared for the existing environments:

- Controlled preview: `https://google-oidc-preview.accreatio.pages.dev/api/auth/v1/oidc/github/callback`
- Production: `https://accreatio.com/api/auth/v1/oidc/github/callback`

Use separate GitHub App registrations/secrets for these environments. Do not give an arbitrary preview the production secret. If a different controlled preview is authorized, record its full origin and register that exact callback before changing its matching variable. Request host headers and frontend return values never construct the callback. The only allowed application return destination is the builder; final URLs omit authorization code and state.

## Registration and hosted verification checklist

1. In the intended GitHub owner/organization's **Settings → Developer settings → GitHub Apps**, register a dedicated preview GitHub App. Supply the controlled preview callback above. Disable callback wildcard matching; no setup/install redirect, installation-on-authorization, webhook or device flow is needed. Enable user authorization. Set **Account permissions → Email addresses → Read-only**; leave all other account, organization and repository permissions at no access. An unavoidable UI metadata baseline is not authorization to install the App in a repository or to add repository permissions. For a public beta, configure the intended audience explicitly.
2. Install the preview App's Client ID and client secret in its protected Pages runtime configuration as `GITHUB_CLIENT_ID` and `GITHUB_CLIENT_SECRET`, with the exact preview `GITHUB_REDIRECT_URI`. Do not paste or export their values into evidence. Keep `ACCOUNT_GITHUB_ENABLED=false` until migration and compatible source are installed. Secret/configuration presence does not prove a successful provider login.
3. Complete the migration/deployment sequence below in the authorized controlled environment. Enable `ACCOUNT_GITHUB_ENABLED=true` there. With authorized test accounts and human consent/MFA, verify new and existing Google/GitHub sign-in, explicit linking both ways, private verified primary email, cancellation, stale proof, logout, rights verification, own export and deletion, shared allowance and retry. Use synthetic accreatio accounts for deletion. Capture sanitized outcome/version/environment, never callback parameters, tokens or cookies.
4. The independent production App and secret are already configured with GitHub disabled. Only after preview evidence and release authorization, deploy the same tested artifact/migration, enable it and repeat bounded hosted checks. Existing production Google success does not satisfy the new GitHub or linked-account criteria. Ed retains release acceptance.

These are registration/configuration/human-provider checks; they cannot be replaced by the local fixtures. No request for a password, OTP, MFA code, private key or client secret is necessary in chat.

## Transaction, account and rights invariants

The shared transaction store retains an encrypted state/nonce/PKCE envelope for at most ten minutes, keyed by transaction ID. The browser cookie is host-only, Secure, HttpOnly, Lax; own sessions stay host-only, Secure, HttpOnly, Strict for at most 24 hours. Callback claims use one conditional update on state hash, browser hash, provider, purpose and live server-side account/session context. Only the winning claim can complete. Completion erases the secret envelope, rotates the initiating session and uses the existing D1 transactional batch/integrity trigger. D1 [batch statements are transactional](https://developers.cloudflare.com/d1/worker-api/d1-database/).

`(issuer, subject)` remains unique. GitHub uses issuer `https://github.com` and the exact numeric ID lexeme as text, including values beyond JavaScript's safe-integer range. Username/email/profile are never identity keys. New GitHub admission needs one primary verified email; there is no Gmail/Workspace restriction. Existing stable identities retain their verified contact if it changes or disappears upstream. A deleted-account restoration requires a current admissible verified contact. No email equality links, transfers or merges accounts, grants Blog/admin privileges, or bypasses a conflicting account: sign in with the usual provider, then explicitly connect from that account.

`link_provider` captures the current account ID, initiating session hash, security version and authentication time in the server transaction. The existing five-minute freshness rule applies at start and completion, and the newly added provider must authorize afresh. The Strict session cookie is **not** needed on the external callback: the server checks its captured still-live session/version, and rejects revocation, logout, account changes, deletion or stale proof. Link completion changes identities/session only, without new account, profile overwrite, policy receipt or allowance reset. Already-owned identities cannot be transferred; existing accounts cannot be merged.

An ordinary sign-in, including a fresh or legacy session, does not authorize account controls or linking. The account UI obtains a new `account_access` authorization with **mandatory** `verificationAction=data`, `delete`, `link_google` or `link_github`. That proof must resolve to an identity already connected to the same active internal account. The issued session carries this exact action restriction for the existing five-minute freshness window; a data proof cannot delete or connect, and a link proof cannot authorize another target. This purpose never admits/resurrects an account, updates profile/consent or connects a provider. Legacy sessions retain ordinary app/allowance access but need action-specific proof for controls. Both sensitive reads and writes recheck the live session/version, freshness and exact action inside their database statements. Connecting then requires a second, new authorization from the provider being added.

Own-account export includes all connected issuer/subjects and their timestamps, the verified contact, display name, minimal sessions, receipt and allowance records. Deletion removes **all** connected identities, contact/name/receipt and sessions; only the previously documented protected antiabuse continuity remains for 48 hours before maintenance. Rejoining through a retained locator preserves the internal ID and allowance during that window.

GitHub access tokens exist only in backend request memory while calling fixed provider endpoints. Refresh tokens and other profile data are discarded. Discarding is not revocation. Accreatio sign-out revokes its session; accreatio deletion erases its account under the existing retention policy. Neither deletes a GitHub/Google account nor automatically revokes its provider authorization. The account menu points to [GitHub authorized Apps](https://github.com/settings/apps/authorizations) and [Google connections](https://myaccount.google.com/connections), according to connected providers. No unlink action or durable provider token was added.

## Additive migration and rollout order

`migrations-auth/0006_github_identity_linking.sql` adds provider, intent, action, fixed failure code and initiating-authentication-time columns to existing transactions plus action metadata to sessions, and a linking completion integrity trigger. It copies only the existing transaction purpose into intent; it does **not** backfill account acceptance, create accounts, remap identities, replace keys or change allowance records. Existing account IDs, relationships, roles, policies, encrypted data and uniqueness remain intact. Existing migrations/trigger `0005` remain installed.

1. Confirm the exact target account database and current migration state. Obtain its existing protected backup/recovery material using the authorized environment procedure. This task does not claim a production backup or restore was executed.
2. Keep GitHub disabled; allow existing pending OAuth transactions to expire or cancel them through the ordinary browser transaction route before switching application versions. Avoid mixed-version in-flight linking.
3. Apply additive migration `0006` to the correct account store, then deploy the compatible tested application. Never deploy the new writer before the migration exists. Do not touch the Blog store or the previous schema.
4. Read back capabilities and Google session/account continuity, then configure/enable the controlled GitHub registration and perform the owner checklist. Migration success alone is not provider readiness.

## Compatible fallback

Set `ACCOUNT_GITHUB_ENABLED=false` in the affected environment and retain this provider-aware account backend and migration `0006`. Do not erase connected identities, drop columns/triggers, reset D1, rotate keys or restore an older database over newer deletions/revocations/receipts. Existing own sessions, quota and controls remain governed by the same state; Google remains available when configured. GitHub-only accounts requiring new proof will need GitHub reactivation or the published rights channel during the outage. Do not silently link by email as recovery.

If an application artifact rollback is necessary, use a reviewed artifact that understands `0006`, provider-linked accounts, action metadata and compatible deletion/export. Keep a protected exact-version backup and test restoration in an **isolated** database; reconcile later deletes, revocations and receipts before any restored database can serve traffic. No destructive production restore or fallback deployment was executed here.

## Local evidence and remaining acceptance

`tests/githubIdentity.test.ts` exercises actual handlers/cryptography/SQLite with synthetic GitHub HTTPS responses: S256, stable large ID, private paginated primary verified email, missing permission/email, timeout, cancellation, invalid code, redirect rejection, browser/provider binding, atomic replay, collision, explicit links both ways, shared allowance, account export/deletion, 48-hour continuity, stale/revoked/foreign verification and no Strict callback dependency. Its isolated backup/restore case copies the **post-deletion** synthetic database to a unique `.local/cache/identity-backup-fixture-*` directory, opens the copy read-only and compares accounts, identities, sessions, transactions, tombstones, policy erasure and allowance receipts. This establishes local SQLite preservation only; it is not a production D1 backup/restore claim.

`tests/githubWorker.test.ts` repeats the GitHub exchange in workerd with real local D1. Google OIDC/store/rollback and account suites are retained. `scripts/identity-functional-smoke.mjs` uses the built app in local Edge/Chromium with actual auth/account handlers and SQLite, substituting only Google/GitHub HTTPS. It checks ES/EN and 320/390/1280 layouts, GitHub sign-in, action-bound proof followed by explicit Google connection, shared quota, own export, logout/Google sign-in and deletion of both identities. Run it with `node --import tsx scripts/identity-functional-smoke.mjs` after `build:web`. This is local technical evidence, not real provider consent, hosted release acceptance or production activation.
