# Design v10 — Guided flow and a real export

**Status:** Proposed. No implementation until HOE GO.
**Sprint:** E1. **Author:** Claude, 2026-08-13.
**Supersedes:** nothing. v9 stays authoritative for R0; this is additive.

## The two complaints, stated as defects

**D1 — The flow is not guided.** The creation UI presents stages, but a user
must still decide what to do next, and controls for one decision live on a
different screen than the decision (dry-run being the named example). Buttons of
different weight sit adjacent without hierarchy. Copy explains instead of
instructing.

**D2 — The export is a stub.** It emits six files. The stated product promise is
that the exported folder is ready to start a project from one prompt. Six
markdown files do not meet that promise, and the gap is not small: there is no
constitution, no orchestrator, no runnable entry point.

## Non-negotiable constraints these must respect

Taken from existing accepted decisions, not reopened here:

- Zero direct service cost (`AGENTS.md`).
- No AI provider required, no telemetry, no project cloud sync (`AGENTS.md`).
- Never overwrite an existing project file; versioned copies only.
- Never pass user-authored text to a shell command.
- Electron and web keep separate renderer graphs; no Blog material in desktop.
- `DECISIONS.md:29` typography roles and "do not add or download a font".

## D2 — Export payload (do this first)

The export is the product. The UI exists to produce it. Fixing the UI around a
stub export optimises the wrapper of an empty box, so this comes first.

### Source of truth

`meta/ACCREATIO_RELATIONSHIP.md` already specifies what accreatio may ship: a
**light derivative** of AEKR, explicitly excluding
`toolkit/tools/new-project-prompter.ps1` and Mode 0's copy-paste workflow, which
stay AEKR-exclusive. Everything below is derived from material that already
exists in AEKR; none of it is newly invented.

| Exported path | Derived from | Purpose |
|---|---|---|
| `CLAUDE.md` / `AGENTS.md` / `CODEX.md` | `toolkit/governance-templates/ENGINEERING_CONSTITUTION.template.md` | Byte-identical copies of one pinned core revision, per that template's own rule |
| `OWNER_PROFILE.md` | `OWNER_PROFILE.template.md` | Seeded from the wizard's answers, not blank |
| `docs/master.md` | `project-scaffolds/docs-governance/master-doc-skeleton.md` | Status line the constitution's §0 bootstrap reads |
| `docs/delivery/definition-of-done.md` | `definition-of-done-template.md` | Objective stopping conditions |
| `docs/delivery/orchestration-loop.md` | `orchestration-loop-template.md` | Increment gates |
| `docs/adr/0001-record-architecture-decisions.md` | `adr-template.md` | ADR habit starts populated |
| `project-map.json` + `PROJECT_MAP.md` | `project-map/` templates | Machine-readable graph from day one |
| `orchestrator/BUILD_ORCHESTRATOR.md` | `toolkit/orchestrator/` behaviour, described not copied | Specification the user's AI implements locally — see "No executable files" |
| `orchestrator/orchestrator.config.yaml` | the `.example.yaml` files | Inert config, pre-filled with the roles the wizard declared |
| `START.md` | new, thin | The one-prompt entry point (below) |
| `PROJECT_PROMPT.md` | current generator, trimmed | Kept, shortened |

### The one-prompt promise, made literal

`START.md` is the whole onboarding. It contains, in this order:

1. One paste-ready prompt block. The user opens the folder in any IDE, pastes
   it into that IDE's AI chat, and work begins. This is the default path and
   must work with zero configuration.
2. A one-line CLI alternative for users who have a CLI installed.
3. A **preflight result**, written at export time — not instructions to run a
   check, but the answer already computed for the choices the user made.

### No executable files — the load-bearing constraint

**The export contains only text: Markdown, JSON, and YAML. No `.ps1`, `.py`,
`.sh`, `.bat`, or `.cmd`, ever.** A test asserts this over the full generated
manifest, because it is a security boundary and not a preference.

`orchestrator/BUILD_ORCHESTRATOR.md` therefore *describes* the orchestrator
precisely enough for an AI to implement it: the PowerShell launcher's role as a
thin entry point that sets `PYTHONPATH` and forwards arguments, the Python
runtime's separation of gates from adapters, the rule that phase transitions and
destructive operations stay `HUMAN_ONLY`, the adapter contract for invoking a
CLI, and the config schema. It states which behaviour is mandatory and which is
the implementer's choice.

This is strictly better than shipping the code, not a compromise: the user reads
the script as their own AI writes it, in their own editor, before anything runs.

### Preflight is described, not run and not shipped

accreatio runs in a browser and cannot inspect the user's machine —
`docs/SECURITY.md` already commits to saying so truthfully. The export ships no
preflight script either. `START.md` states which declared role needs which CLI,
and says plainly that nothing has been verified. The generated orchestrator spec
includes the preflight as one of the things the user's AI builds. No fabricated
green checkmarks, and nothing to unblock in an antivirus dialog.

### What is deliberately excluded

Mode 0's copy-paste workflow and `new-project-prompter.ps1` (AEKR-exclusive by
`ACCREATIO_RELATIONSHIP.md`); any bundled AI credential; any network call at
export time; any executable file of any kind.

## D1 — Guided flow

### The model

One decision per screen. A screen may not present a choice whose consequence is
explained on a different screen. Concretely: the dry-run choice moves to the
screen where the user commits to the export, because that is where it applies.

Progress is a single bar at the top with named steps, always showing where the
user is and how much remains. Back is always available and never destructive;
forward is blocked only by a validation error, announced in place.

### Copy rules — the binding part

The complaint is that there is too much text, and it is correct. These are
enforceable, not aspirational:

- One sentence per field label. No paragraph under a field.
- No screen may exceed **60 words** of instructional copy, excluding user data,
  field labels, and button text.
- Explanations move behind a disclosure, closed by default. If a user must read
  it to proceed, the screen is wrong, not the disclosure.
- Every button says the action, not the concept: *Export ZIP*, not *Proceed*.
- On each screen, exactly one primary button. Everything else is secondary or a
  text link. Two adjacent same-weight buttons is a defect.

A test asserts the 60-word budget per screen so this cannot rot.

### Not changing

The atmosphere contract, the theme system, the typography roles, the
accessibility contract (currently Lighthouse 100), and the ZIP mechanics.
This is an information-architecture and copy change, not a visual redesign.

## Versioning and archival — standing policy

Recorded here because the HOE stated it as a general rule on 2026-08-13:
**archive, never delete.**

**Hosted.** Cloudflare Pages already implements this. Every deployment keeps a
permanent immutable URL; the stable alias points at whichever deployment is
promoted. Deploying v2 does not remove v1 — v1 keeps its immutable URL and can
be re-promoted. The rule to write down is therefore: record the outgoing
deployment ID in `CHANGE_CONTROL.md` before promoting a replacement, so the
archived version is findable by name and not only by dashboard archaeology.

**In-repo.** The v1 creation flow is not deleted when v2 lands. It moves to a
clearly named legacy path and stays buildable until v2 has passed hosted
acceptance, following the existing `docs/design-vN/` precedent of keeping
superseded work as dated evidence.

**Applies to.** Deployments, design documents, generated artifacts, and audit
reports. Not to secrets or credentials, which are revoked and removed.

## Sequencing

| Step | Content | Gate |
|---|---|---|
| E1.1 | Export payload derived from AEKR, with a fixture test asserting the full file manifest | HOE GO |
| E1.2 | `START.md` one-prompt entry and generated preflight | E1.1 |
| E1.3 | Guided flow restructure and the copy budget with its test | E1.2 |
| E1.4 | Archival policy written into `CHANGE_CONTROL.md` conventions | any time |

E1.1 and E1.2 are the ones that make the product true. E1.3 is what the user
feels. Doing E1.3 first would polish the wrapper of an empty box.

## Decisions — Ed Lopez (HOE), 2026-08-13

1. **Implementation of the whole of E1 is assigned to this session**, including
   the E1.3 guided flow. Consequence to hold in view, not to relitigate: the
   contractor's frontend scope now needs redefining, because E1.3 was the work
   he was hired for. Raised once and recorded; the assignment stands.
2. ~~The export ships the Python orchestrator runtime, vendored and pinned.~~
   **Superseded the same day, before implementation, by decision 4.**
3. **v1 of the creation flow is archived as a buildable legacy path**, not as a
   frozen diff. It keeps compiling until v2 passes hosted acceptance, so
   rollback is a toggle rather than a git operation. Accepted cost: two flows
   coexist in the tree for one release window.
4. **The export ships no executable file.** It ships a specification the user's
   own AI reads and implements locally. This supersedes decision 2, on the
   HOE's reasoning that a browser-downloaded ZIP containing `.ps1` and `.py`
   is exactly the shape security tooling blocks, and that transparency is
   better served by the user watching their own AI write the script than by a
   vendored blob nobody inspects.

   Supporting evidence for the reversal: a ZIP saved from a browser carries
   Mark-of-the-Web, PowerShell's default execution policy refuses unsigned
   `.ps1`, and managed environments block both outright — so the shipped
   runtime would frequently not run at all. It also contradicted this
   product's own posture, `docs/SECURITY.md`: *"Attachments are never parsed,
   rendered, macro-enabled, or executed."* Shipping an executable runtime
   would have made accreatio a code-distribution channel, which is a
   liability it does not currently carry and should not acquire before any
   SaaS step. The reversal also removes decision 2's accepted cost entirely:
   there is no vendored runtime to resync with AEKR, and ~172 KB leaves the
   bundle.

## Constitution revision pinning

Still to resolve at implementation time, not a blocking question: the export
copies one pinned revision of AEKR's `ENGINEERING_CONSTITUTION.template.md`
(currently marked V2 in its own header). The exact AEKR commit is recorded in
`.accreatio/project.json` alongside the runtime revision, so a generated project
states which upstream core it was built from and can be upgraded deliberately
rather than silently — which is the template's own stated rule.
