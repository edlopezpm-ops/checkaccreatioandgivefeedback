# Google preview activation - 2026-09-08

The owner supplied a Google-exported Web OAuth client JSON in the prepared private directory. The client schema and exact redirect URI were validated without printing the client ID or secret. The file inherits the directory's current-user-only Windows access rule.

Only `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` were installed as Cloudflare Pages preview secrets. No account key was read for this installation or written; pre-existing variables, D1 bindings, production configuration and canonical deployment were compared before/after. The protected before-configuration snapshot is `.local/private/auth-20260908/pages-before-google-activation.json`.

## Deployed configuration

- Current runtime commit: `2b9e3193e06b1d1d1621cb88bd8cd9aa7f7165cd` (profile backend `b8dc78a`; fetch correction `11d765f`).
- Preview deployment: `72d27164-d406-4a33-8288-bab4aee5ddb7`, successful provider stage.
- Alias: <https://google-oidc-preview.accreatio.pages.dev>.
- `ACCOUNT_OIDC_ENABLED=true`; `ACCOUNT_OTP_ENABLED=false`.
- Both client credentials are present as secret bindings in the deployment.
- Callback: `https://google-oidc-preview.accreatio.pages.dev/api/auth/v1/oidc/google/callback`.
- The archive alias serves deployment `2e2ca239-3850-4ada-989b-4c469b5edd95` with the current public notice and Google/OTP off. It was staged from the same tested files with only the Google flag disabled. Exact-origin validation also prevents using Google from that alias or immutable deployment hosts.
- Production was not deployed or enabled for accounts.

## Verification and limits

Thirty-five focused API, workerd/D1, account storage and compatible rollback tests passed. The account UI/SQLite smoke passed, including popup/COOP isolation, cancellation, expiry, outage, active service worker, exact file-byte preservation, session revocation and quota continuity. Cloudflare generated types were regenerated for the changed flag; the subsequent generated-type check, full typecheck and web build passed.

These tests use simulated Google responses and do not prove a Google-hosted login. The integrated browser connection now works and reaches the protected application and Google. No Access bypass or synthetic Google identity was introduced for acceptance.

Hosted owner sign-in now passes. Broader launch/brand verification remains separate from enabling this restricted preview. Do not describe client installation as legal certification.

### Hosted attempt follow-up

After the owner reported completing sign-in, a read-only aggregate query against preview D1 found two failed redirect transactions with a non-null callback claim. Both had cleared transaction secrets and neither bound an account. The database contained zero accounts, external Google identities, sessions and export authorizations. This does not pass hosted login acceptance. The callback accepted the transaction binding, but the existing generic failure path does not retain enough diagnostic detail to distinguish provider rejection, token validation, account admission or a cancellation racing the callback.

The owner subsequently opened the integrated browser, making live UI testing available. Its initial Access page rejected the account: the preview policy allowed only the existing Gmail address. The policy now permits that address and the owner-confirmed `aekr@aekr.io`; no domain-wide or public allowance was added. The prior policy is backed up in `.local/logs/google-activation-20260908/access-policy-before-owner.json`.

A new owner Workspace attempt reached the callback. The diagnostic deployment emitted only the fixed code `token_exchange` at 16:48:56 UTC. A local workerd reproduction using fictitious credentials then established that storing ambient `fetch` on the dependencies object causes an incorrect-receiver exception before contacting Google. A bound wrapper reaches Google and receives the expected rejection of fictitious credentials. The previous OAuth worker fixture replaced this dependency with an arrow function, masking that runtime defect. Commit `11d765f` preserves the global receiver; its new native-workerd regression fails on the prior implementation and passes with the fix. The complete 302-test suite, typecheck and formatting checks passed.

The corrected preview completed a real Google Workspace sign-in through the connected browser. The app displayed the owner's account and five available exports. A separate read-only D1 review at 16:57:07 UTC found one completed transaction with secrets cleared, one encrypted account with no plaintext email, one Google identity and one coherent hashed OIDC session with a 24-hour TTL. There were zero export receipts. The browser retained the account across reload, then returned to sign-in after logout. The account-data download action produced no application error; the browser's saved download file was not observed, so this is not a verified hosted file receipt. Actual account deletion was not performed on the owner's account; deletion/export semantics are covered by the isolated tests.

Live browser verification also confirmed all three blog articles have justified body paragraphs, the former post-navigation buttons are absent, and the editorial note is inside the footer.

Sanitized receipts: `.local/logs/google-activation-20260908/`; account UI evidence: `.local/logs/account-ui-1788883944770/`.

### Profile name and header menu acceptance

The owner explicitly selected the Google profile name and requested account controls in a dropdown beside New project, visible only while signed in. The menu contains exports used/remaining over the rolling 24-hour window, own-data download, logout and confirmed deletion. It is available on project, Blog and About views; the separate email/quota panel was removed.

Google now receives `openid email profile`. Its actual consent page showed the selected owner's name/profile-picture and email categories. After consent, accreatio displayed Ed Lopez in the header button; the menu showed zero exports used and five remaining. The name and session persisted after reload. No photo or other profile field is retained. Anonymous UI was checked before sign-in and contained no account button.

Migration `0004_google_display_name.sql` was applied only to preview before deployment. The name is encrypted with distinct account-bound AAD using the existing key, exported to its account holder and erased on deletion; the compatibility trigger also purges it for the older deletion writer. No key or identity was replaced. A separate read-only D1 review at 17:26:12 UTC confirmed one active account and Google identity, two completed callbacks for that same account with cleared secrets, one coherent active hashed OIDC session, encrypted email/name, notice `2026-09-08-profile`, and zero quota receipts.

All 307 application tests passed. Full account browser smoke passed for quota, real local file bytes, popup/COOP/cancellation, data download/deletion, desktop/mobile menu positioning, keyboard dismissal and ES/EN. That smoke uses a synthetic provider; the hosted Workspace exchange is separate real-provider evidence. Typecheck, formatting, generated Cloudflare types, four pinned branding assets, web/desktop builds, surface separation and Electron privileged smoke passed. The Windows portable package was built; packaged desktop assets match the tested build and contain no web-auth bundle. This is not a complete interactive packaged-desktop journey.

The public archive privacy notice returns anonymous HTTP 200 and matches reviewed source byte-for-byte, including name processing. Google preview still redirects anonymous requests to Access. Production remains deployment `11235c8c-108f-46f3-8cce-fb88a144330b` with only its prior Blog D1 binding; automatic production deployment remains disabled.

Evidence: `.local/logs/google-activation-20260908/hosted-profile-success-d1.json`, `profile-release-check.json`, and `.local/logs/account-ui-1788887838334/`. Console Data Access was not changed during this increment because Google Cloud requested administrator password verification; the requested profile scope, consent and name return were verified through product login. No broader production publication, brand verification or legal certification is asserted.

## Rollback

Remote tag `rollback/google-activation-20260908` points to `e7675a965abe8a0bf28c990c8f420234f9a15288`, preserving the accepted blog layout with both sign-in methods off. Deploy that source from an isolated checkout to `google-oidc-preview`, retaining existing secrets and schema 0003. The prior compatible deployment is `7e5d03c9-e25f-48fa-bf7c-da079fa616ec`.

Alternatively revert the activation commit, regenerate/check the bindings and deploy the disabled configuration. Preserve all account keys, identities, revocations, contacts and quota receipts. Do not restore a database snapshot over subsequent user activity. The detailed compatibility constraints in [the rollback runbook](GOOGLE_OIDC_ROLLBACK.md) remain applicable.

To revert only the owner email addition, restore the prior `include` list from the Access policy backup to policy `d8c1d7d4-861b-4e00-9c4e-2f2c6185566e` in app `83866585-f72a-4a59-82af-821724093774`, retaining all other current fields. Read the current policy first; do not overwrite unrelated subsequent changes.

Remote tag `rollback/google-profile-menu-20260908` preserves `11d765f`, the working Google exchange before the profile-name/menu follow-up. Its deployed equivalent is `e0ce4a5c-d486-44b6-a163-e1094b1cdb08`.
