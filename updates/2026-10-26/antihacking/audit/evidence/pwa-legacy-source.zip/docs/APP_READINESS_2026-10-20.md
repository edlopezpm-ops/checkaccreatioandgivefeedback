# accreatio release readiness — 2026-10-20

The target is a complete, supportable release with an explicit acceptance scope.
There is no universal security or privacy percentage. A working domain, a green
test suite and an actual Google login close different requirements. Paid release
also needs the commercial and billing requirements below.

The owner requested a comparison against aekr-web and timeKER and authorized
repair of accreatio's privacy, cookies and tracking gaps. Source baseline:
`fd20023223a34d3e5e9256d39202ec7a147a320c`. Sibling repositories initially served
as references. The owner then requested isolated AEKR wording corrections in
those products, tracked separately below. Their policies, consent, agreements
and data do not become accreatio's.

## Current free-beta requirements

| ID  | Requirement                                            | State and closure evidence                                                                                                                                                                                                                                                                                                        |
| --- | ------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| B01 | Canonical origin, HTTPS and isolated account service   | Delivered previously: `accreatio.com`, www redirect, separate production Account/Blog stores and Google client. Exact earlier deployment in the production receipt.                                                                                                                                                               |
| B02 | Accurate data and device-storage inventory             | Implemented in the privacy baseline and public cookies page: account identity/contact, authorization receipts, sessions, allowance, local draft/preferences/cache and transient files/ZIP; provider copies are separate.                                                                                                          |
| B03 | Current notices and usable rights contact              | EN/ES Privacy/Terms/FAQ and account authorization identify AEKR and `aekr@aekr.io`, following the owner's wording correction. Purpose, permissions and policy versions are unchanged. Versioned notices are reachable before sign-in; exact establishment/address facts remain B11.                                               |
| B04 | Affirmative account authorization and Terms acceptance | Deployed visible AEKR continuation notice beside Google/Send code/Continue, without checkboxes or acceptance on visit/refresh. Intentional action plus valid proof records exact versions/DB time; own-data/deletion behavior retained. No historical backfill. Human acceptance remains B10.                                     |
| B05 | Rights without forced acceptance of new Terms          | Deployed and tested data/deletion/logout without a current receipt. A valid existing Google session can reauthenticate the same account for five-minute proof without account/profile/receipt writes. Expired or inaccessible proof uses the public contact.                                                                      |
| B06 | No optional collection by default                      | Analytics/advertising unused/off. Separate Cookie preferences permits explicit necessary-only refusal, locally valid for 180 days, with no identifier/API transmission or auth/quota change. Refusal/GPC/DNT checks and live UI passed. Pages Web Analytics/Engine unconfigured; provider logs/backups remain unverified.         |
| B07 | Bounded retention, failures and recovery               | 24h sessions, 10min transactions, 1h OIDC admission and 48h quota/deletion windows. First old-version scheduled production purge observed at 21:17 UTC. New maintenance version is deployed with the same hourly cron; its first scheduled execution, ongoing monitoring, protected recovery and provider copies remain separate. |
| B08 | Local discard and product flows                        | New draft removes ZIP recovery. Actual IndexedDB RED/GREEN repair prevents editing an empty frame before draft hydration; saved data stayed durable. Integrated draft/attachment/quota/account/viewport flows and independent review passed. Broader human acceptance remains separate.                                           |
| B09 | Reproducible release and independent review            | Final full verify PASS, 337/337 tests; typecheck/format/Functions/builds, pinned branding, final packaged host (20 assets) and functional UI passed. Independent authorization/cookie/hydration reviews passed. GitHub run 39505013084 started no steps due to account billing; no spending change.                               |
| B10 | Human final-release acceptance                         | Earlier owner Google login/reload/profile/5-of-5 allowance was observed; owner later confirmed access functions. Canonical continuation/cookie UI is inspected and refusal saved. Latest aggregate has one current receipt, without identity attribution; no personal acceptance on this specific release is asserted.            |
| B11 | Real operating and legal facts                         | Chile/US operations and worldwide intent are confirmed. Exact establishment/address/state where required, provider terms/roles/transfers/logs/backups, inactivity/closed-support retention, incident response and applicable rights handling remain to be settled from actual facts.                                              |
| B12 | Broad-release product assurance                        | Public-use license decision, brand/trademark review, capacity/abuse/recovery measurements and a broader independent security/accessibility assessment remain separate from this privacy repair. Frozen desktop signing/publication is a different release.                                                                        |

The current product can remain a bounded free beta while unresolved broad-release
requirements are closed. Do not advertise universal compliance, unlimited
capacity, guaranteed retention/uptime or a completed paid service from this work.

## Additional requirements for a subscription micro SaaS

| ID  | Requirement                     | Current state                                                                                                                                                                                                                       |
| --- | ------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| S01 | Repeatable paid value and offer | Define the paying customer, recurring benefit, free/paid boundary and support commitment. Five service exports are a free allowance, not a subscription.                                                                            |
| S02 | Commercial decisions            | Price, currency, allowance, refund/cancellation/grace policies, operator/seller facts and permission for transaction fees remain unset. No upgrade or fee is inferred from the domain purchase.                                     |
| S03 | Payment provider and account    | Choose and verify seller/product eligibility, provider agreement, merchant/tax responsibilities and separate Sandbox/Live configuration. No merchant or checkout is implemented.                                                    |
| S04 | Billing and entitlements        | Implement additive account-linked billing/entitlements, atomic quotas, authenticated idempotent webhooks, reconciliation and cancellation/renewal/failure/refund lifecycle. Then prove actual Sandbox and authorized Live journeys. |
| S05 | Additional identities           | GitHub adapter and explicit independent linking remain unimplemented. Basic Google identity is sufficient for the free-beta path; each added provider needs minimal scopes, separate config and real acceptance.                    |

The [micro SaaS backlog](MICRO_SAAS_LAUNCH_2026-10-20.md) contains the concrete
architecture, dependencies and acceptance criteria. No collector is enabled to
finance the product, and no project contents become a commercial dataset.

## Initial privacy-control rollout receipt

Application source: `aa9629b635aa54c55c2211ba846a4048beb4be61`, pushed to `main`.
Production migration `0005_account_policy_authorization.sql` applied before the
new Pages and maintenance code; production has five account migrations.

| Evidence                    | Observed result                                                                                                                                                                                                                                                                                  |
| --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Pages                       | `f854ab2d-55ec-4990-87f8-7551a71f6eb1`, exact application source above, successful at `2026-10-20T21:24:54.475295Z`                                                                                                                                                                              |
| Maintenance                 | Version `fbcce59c-3169-4ba5-9ebb-12a54ca78477`, deployment `55672748-4784-459e-b933-4d1d56595e5a`, 100% at `2026-10-20T21:25:19.999055Z`; minute-17 hourly cron, production D1 and unchanged privacy keys                                                                                        |
| Local validation            | Final full `verify` PASS: 332/332 tests, no skips. After the final FAQ whitespace change, web build and public surface checks passed again                                                                                                                                                       |
| Diagnostic package          | Actual unpacked packaged host PASS with 20 exact ASAR assets, Electron 43.8.1, isolated profile and test-only `--no-sandbox`; unsigned and unpublished, portable wrapper not exercised                                                                                                           |
| Browser/performance         | Functional web/account/project flows PASS; Lighthouse 96 performance, 100 accessibility and 100 best practices. SEO 66 is intentional private-beta `noindex`                                                                                                                                     |
| Branding                    | Four pinned assets PASS; old missing vendor-folder comparison explicitly SKIPPED                                                                                                                                                                                                                 |
| Security inventory          | CycloneDX 709 components; zero high/critical and eight moderate findings. Vite patched to 8.3.4; remaining inherited packaging findings have no compatible fix in the current chain                                                                                                              |
| Hosted readback             | 11/11 privacy/negative API checks and 10/10 origin/auth/admin/Blog/redirect checks PASS; exact public build bytes, self-only script CSP, legal `no-transform`, auth `no-store`, Google enabled and own OTP off                                                                                   |
| No fabricated authorization | Retained pre-acceptance readback at `2026-10-20T21:28:38.679Z`: one live account, one Google identity, zero policy receipts and zero export receipts                                                                                                                                             |
| Remote CI                   | [Run 39499823833](https://github.com/edlopezpm-ops/accreatio/actions/runs/39499823833): billing/spending-limit failure before job steps; neither a remote test PASS nor an executed test failure                                                                                                 |
| Human acceptance            | The initial two-checkbox UI was visible. The owner subsequently confirmed that access functions and requested AEKR wording, continuation notice and independent cookie refusal. This receipt does not establish a personal acceptance of the later UI                                            |
| Protected custody           | Seven runtime values retained unchanged in owner-only, Git-ignored `.local/private/production-20261020/accreatio-production.config.json`, with matching source ZIP and current receipt copies. Four original Blog values are still non-exportable; no D1 snapshot or external backup is included |

Retain the ignored evidence separately when needed:

- `.local/logs/2026-10-20T21-18-53-221Z-verify-878fb428-c22d-4e9f-9cec-6a994329f21d.log`
- `.local/logs/packaged-privacy-1792530981239/result.json`
- `.local/logs/security-2026-10-20T21-09-43.634Z-8baf4e7d-39e2-4e82-a6f8-652a33d88822/`
- `.local/logs/privacy-independent-audit-20261020T211256680Z/policy-oidc-tests.log`
- `.local/logs/privacy-independent-audit-20261020T211405625Z/oidc-worker-tests.log`
- `.local/logs/privacy-readiness-20261020/` migration/deploy, HTTP/provider/D1 and browser receipts.

The new migration is additive and creates no acceptance rows for existing
accounts. Apply it before the new Pages/maintenance code. Preserve production
keys, database identities, quotas and all later deletion/revocation state.
An older writer cannot be treated as a compatible policy-aware rollback merely
because it can read the database: pause account/export admission before an
emergency rollback, retain rights handling through the operator, and restore a
reviewed policy-aware build before reopening. Do not clone preview over live data.

## Current continuation and cookie-preference release

Application source `1d30f4d246099cb0d802d0c5f759381a8d35f4aa` is pushed to
`main` and deployed. It supersedes the initial two-checkbox UI above. The owner
requested a visible “By continuing / Al continuar” notice beside the intentional
sign-in action. It identifies AEKR, links the Terms/Privacy/Cookies notices and
explains only necessary account processing. No visit, session refresh or cookie
choice creates account acceptance. Policy versions, account migrations, runtime
keys and maintenance deployment are unchanged.

| Evidence                 | Current observed result                                                                                                                                                                                                                                                  |
| ------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Pages                    | `7966e29c-2cca-49b5-95b7-d101b17fa95a`, source above, successful at `2026-10-20T22:01:55.343538Z`; canonical `https://accreatio.com`                                                                                                                                     |
| Full local validation    | `verify` PASS, 337/337 tests, no skipped tests; typecheck, generated types, format, Functions, web/desktop builds, mailer, Blog seed and functional web/account/project flows passed                                                                                     |
| Cookie refusal           | Web-only accessible preferences dialog; analytics/advertising unused/off; explicit rejection saves necessary-only preference for 180 days with no identifier or server transmission; live Spanish UI showed “Preferencia guardada: solo necesarias.”                     |
| Draft hydration repair   | Actual IndexedDB RED/GREEN regression: saved draft remained durable, but an empty editable frame appeared before async hydration; editor now waits for hydration and its first value equals the saved draft. Independent review passed                                   |
| Final diagnostic package | Unpacked packaged host PASS, 20 exact ASAR assets, Electron 43.8.1, isolated profile and test-only `--no-sandbox`; actual binary NotSigned, unpublished; portable wrapper not exercised                                                                                  |
| Hosted checks            | 11/11 privacy/negative API checks plus 10/10 origin/auth/admin/Blog/redirect checks PASS; exact current public build bytes, self-only script CSP, legal `no-transform`, auth `no-store`, Google enabled/own OTP off                                                      |
| Browser/performance      | EN/ES continuation notice, no checkboxes, Google action available and independent cookie refusal inspected on canonical origin; local Lighthouse 96 performance, 100 accessibility, 100 best practices, intentional private-beta SEO 66                                  |
| Provider settings        | Readback `2026-10-20T22:02:30.624Z`: no configured Pages Web Analytics or Analytics Engine binding; Pages Logpush/observability not returned, so not assumed disabled; maintenance Logpush false                                                                         |
| Account aggregate        | At `2026-10-20T22:02:30.759Z`: five migrations, two live accounts/Google identities, one current policy receipt, zero live sessions/exports. Only aggregate counts read; no attribution to an owner or claim of personal acceptance on this specific release             |
| Remote CI                | [Run 39505013084](https://github.com/edlopezpm-ops/accreatio/actions/runs/39505013084), verify job `118911642252`: no steps started, GitHub account billing/spending-limit block; local PASS is separate, and no spending change was made                                |
| Protected custody        | Seven runtime values retained in owner-only Git-ignored configuration, matching `source-1d30f4d.zip`, historical configurations/source archives and current document copies; four original Blog values remain non-exportable; no D1 snapshot or external backup transfer |

The separately authorized operator-copy changes are also published on aekr.io,
timeKER PROD and timeKER Stage. Each preserves its own policy versions,
permissions, cookie behavior and data. Stage was not promoted to production;
the exact sources, independent checks and deployment receipts are in the
[related AEKR wording section](PRIVACY_TRACKING_BASELINE_2026-10-20.md#related-aekr-wording-corrections).

Current ignored evidence:

- `.local/logs/2026-10-20T21-58-40-423Z-verify-36471c56-b66c-4155-9c0b-81207eb2245d.log`
- `.local/logs/account-ui-1792533596516/`
- `.local/logs/account-ui-1792533386149/google-draft-hydration-receipt.json` (deliberate RED) and `.local/logs/account-ui-1792533433404/google-draft-hydration-receipt.json` (GREEN)
- `.local/logs/packaged-clickwrap-v2-1792533682001/result.json`
- `.local/logs/pwa-regression-vDMFRg/receipt.json`
- `.local/logs/clickwrap-20261020/` (deployment, provider/aggregate/HTTP readbacks and canonical-origin screenshots)

Earlier failed or interrupted verification runs retain their failure state. The
final integrated run includes both test-discovery synchronization and the actual
draft hydration fix. No personal Terms action was performed by automation.

References: [privacy and tracking baseline](PRIVACY_TRACKING_BASELINE_2026-10-20.md),
[processing and rights operations](ACCOUNT_PRIVACY_OPERATIONS.md),
[earlier production cutover](PRODUCTION_SETUP_2026-10-20.md),
[local artifacts](LOCAL_ARTIFACTS.md).
