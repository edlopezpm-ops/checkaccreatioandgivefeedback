# W3 / SaaS Architecture Sketch (Phase P8)

**Status: sketch only, not authorized for implementation.** This document exists to preserve future optionality without committing to it. It does not authorize internal customer accounts, billing, hosted orchestration, multi-tenant project storage, or shared project history — see `docs/WEB_STRATEGY.md` Phase W3, DEC-016/DEC-017, and this repo's zero-cost constraint. The implemented web-only Blog/Pages Functions/D1 editorial boundary is not W3: it stores portal posts, not tenant projects, and remains explicitly outside Electron.

## Why this exists now

W0 (Bridge abstraction), W1 (export-first PWA — drafts, ZIP export, offline shell, accessibility), the web-only editorial channel, and the orchestration-config surface (P3/P4) are distinct boundaries. Before any of them accidentally grows hosted-multi-tenant assumptions, this sketch records what a real SaaS edition would require. The editorial D1 table and Access publisher allowlists are not a tenant/project data model.

## Trust boundaries a SaaS edition would introduce

Today, accreatio has separate trust boundaries: Electron's contextBridge for local privileged work, and the web portal's Access-verified Pages Functions/D1 editorial channel. Neither is a tenant/project service. Everything in the project workflow remains the same user/device session, while Blog posts are persistent portal content authorized through bounded publisher maps.

A SaaS edition adds boundaries that don't exist today:

- **User ↔ tenant.** Which authenticated identity may see/act on which project's data. Does not exist; there is no concept of "another user" anywhere in the current data model.
- **Tenant ↔ tenant.** Two customers' project definitions, attachments, and orchestration configs must never cross, at every layer (rows, object storage keys, cache keys, queue messages, log lines, rate-limit buckets) — this is the one requirement `docs/WEB_STRATEGY.md`'s existing W3 section already names and this sketch doesn't relax.
- **Hosted service ↔ user's local machine/AI subscription.** If Mode 1 orchestration were ever offered as a hosted feature (not proposed here — see "What must never become hosted" below), the service would need to broker access to a user's own `claude`/`codex` subscription without ever holding their credentials, which is a fundamentally different trust model than today's "accreatio never touches provider auth" design (AEKR's adapters read local CLI auth state directly; a hosted service has no local CLI to read).

## Tenant isolation requirements (if ever built)

- Tenant identity derived from an authenticated session, never from a client-supplied field.
- Enforced at the data layer (row-level or equivalent), not only in application logic.
- Uploaded attachments treated as hostile: signature/MIME validation, application-generated storage keys (never the user's filename), non-public object storage, retention/deletion controls, per-tenant quotas.
- No shared caches, queues, or background workers that don't partition by tenant.

None of this tenant model exists today, and none of it is implied by the Blog's human/service publisher allowlists.

## Local vs. hosted responsibility split

The local-first design already drew this line for W0–W2 without needing SaaS to force the question:

| Stays local, always | Could become hosted, only with explicit future authorization |
|---|---|
| Project definition editing, validation, prompt/plan generation (`src/core.ts`) | Optional shared team history/templates (not proposed; would need real demand) |
| Real filesystem/Git/GitHub writes (`electron/main.ts`) | — |
| Draft autosave (IndexedDB, W1) | — |
| ZIP export generation | — |
| AEKR Mode 1 orchestration execution (always runs against the user's own local AEKR checkout and local provider CLIs) | — |
| Provider credentials (`claude`/`codex` auth) | Never. See "What must never become hosted." |

The right-hand column is intentionally almost empty. That's not an oversight — it reflects that no concrete collaboration use case has yet justified moving anything out of the left column (see below).

## Data classification

- **Project content** (name, context, restrictions, attachments, generated docs): today, never leaves the user's machine or browser; no Blog/API request contains it. Classify as sensitive-by-default if ever hosted — it can contain unreleased product plans, client names, internal constraints.
- **Editorial content** (Blog title, summary, paragraphs, display author/signature, timestamps, safe actor label): intentionally persists in D1 and is not project/tenant content. Access and Cloudflare process the request/authentication/security metadata needed to protect it.
- **Orchestration config** (`orchestration.yaml`, P4): contains role/provider mapping and budget limits, not secrets — but its generated `task` fields could contain anything the user typed, so treat identically to project content.
- **Provider credentials**: never accreatio's to classify, store, or transmit, hosted or not — see below.
- **Usage/telemetry**: none exists; `docs/WEB_STRATEGY.md` and `PRIVACY_POLICY.md` already commit to none. A SaaS edition would need to decide this explicitly rather than inherit silence.

## Identity options

- **GitHub OAuth** remains the most plausible primary identity if SaaS is ever authorized: accreatio already integrates with GitHub CLI locally (`gh`), users doing this kind of work already have GitHub accounts, and it avoids inventing a new credential system. Nothing here commits to it — a genuine evaluation would need to happen at W3 authorization time, not now.
- Email/password or a generic OAuth provider are not ruled out, just not evaluated, since there is no current trigger to evaluate them against.

## Collaboration use cases that would justify SaaS

None are confirmed today. Candidates worth naming so a future decision has something concrete to test against, not because any is approved:

- Shared project-definition templates across a team (vs. each person maintaining their own toolkit locally).
- Shared visibility into an in-progress Mode 1 run for a teammate who isn't at the keyboard.
- Centralized audit trail across multiple people's local orchestration runs.

None of these currently have a real user asking for them. Per this program's Section 14 (anti-slop), the correct response to "no evidenced demand" is to build nothing, not to build "just in case."

## What must never become hosted

Restated from `docs/WEB_STRATEGY.md`, unchanged and non-negotiable regardless of what else this sketch discusses:

- No multi-tenant remote command runner (the original reason W1 is export-first and W2, if ever built, stays a local companion).
- No proxying, storing, or transmitting a user's `claude`/`codex`/`gh` credentials through a hosted service.
- No dependency on AI for core project generation (that stays deterministic, local, and free regardless of hosting).
- No publication of the private AI Engineering Knowledge Repo, wholesale or otherwise.

## Migration seams W0–W2 already created (whether or not W3 ever happens)

These exist for host-portability reasons already justified by W0/W1/W2, not because SaaS was anticipated — but they happen to be exactly what a hosted edition would also need:

- **`Bridge` interface** (`src/types.ts`, W0): already separates "what the UI needs" from "how the current host provides it." A hypothetical hosted bridge implementation would slot into the same interface — but implementing one is not proposed here.
- **Shared template functions** (`shared/domain.ts`: `generatePrompt`, `governance`, `discoveryMd`, `projectSignature`, `renderOrchestrationConfig`, P2.2/P4): host-agnostic by construction, so a hosted renderer would generate identical content to desktop/web without new duplication.
- **`webExport.ts`'s pure `buildProjectFiles`**: already separates "what to generate" from "how to deliver it" (ZIP download today; nothing else is implied).

No new seam is being added by this sketch. The existing ones are simply being pointed out as relevant, since they were built for good reasons already true today (host portability across Electron/browser), not spliced in for SaaS.

## Explicit triggers required before W3 can be authorized

All of the following, not any one:

1. A real, named collaboration use case with an actual requesting user (Ed, or a real prospective user) — not a hypothetical.
2. Explicit owner authorization to begin, separate from DEC-009 and DEC-016's protected portal/editorial authorization. Those decisions do not authorize W3 or hosted project data.
3. Legal/trademark review completed (already flagged as a public-release gate in `docs/WEB_STRATEGY.md` and `RISKS.md`).
4. A specific, evaluated identity provider decision (not deferred the way this sketch defers it).
5. A concrete tenant-isolation design reviewed before any multi-tenant data model is written, not after.
6. Threat model, dependency/SBOM automation, signed updates, accessibility audit, privacy terms, abuse controls, and an independent security assessment — the same "Deferred gates" list `docs/WEB_STRATEGY.md` already names for public release, which SaaS inherits and extends.

## Costs and operational responsibilities that do not exist today

Naming these so a future SaaS decision is made with eyes open, not because any is imminent:

- Hosting/compute cost for tenant project services or object storage (today: not authorized; the bounded editorial Functions/D1 must remain inside Cloudflare's free plan).
- On-call/incident response for a customer project service (today: none; Blog availability is best-effort and project ZIP creation remains local).
- Customer project-data handling obligations (breach notification, data export/deletion requests, backups) that begin only if accreatio stores customer projects. Editorial retention/deletion and Cloudflare metadata obligations already require legal review on their own terms.
- Payment processing and billing support, if any tier is ever paid.
- Ongoing security patching for a future tenant attack surface beyond the already bounded Access/Functions/D1 editorial surface.

None of this is provisioned, budgeted, or staffed today, and nothing in this program authorizes starting to.
