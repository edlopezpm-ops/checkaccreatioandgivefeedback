# Recovery from the repeated update dialog

**Authentication supersession:** The Access-form navigation checks below describe the historical recovery candidate. [Own email OTP](OWN_EMAIL_OTP_2026-09-05.md) replaces product login with an in-app email/code flow while preserving this service-worker recovery and local-draft behavior. Current verification and hosted acceptance are recorded there.

The owner's recording `Recording 2026-09-05 174058.mp4` shows the native update confirmation returning after every accepted reload. The installed client reloaded without activating its waiting service worker, so the same cached application and confirmation returned. Clearing the ordinary browser cache did not resolve that worker lifecycle.

The generated worker now activates with `skipWaiting`. The current application uses native service-worker registration without an update confirmation or an automatic reload listener. The replacement shell becomes available on navigation. API and Access navigation still bypass the app-shell fallback.

An already installed legacy client can perform one final reload through its existing listener when the replacement worker activates. Saved IndexedDB drafts remain intact. The worker cannot recover edits that the legacy application has not yet persisted; attachments remain transient. Subsequent clients do not install that reload listener.

This supersedes the close-all-tabs workaround and the no-forced-legacy-activation statement in [the previous sign-in delivery](PUBLIC_SIGNIN_2026-09-05.md). No site-storage deletion or manual browser-cache clearing is required by this repair.

The change is limited to web PWA registration and activation. Authentication, quotas, Blog permissions and desktop behavior retain their existing implementation. The three deferred assets (`idb`, ZIP generation and the nebula) retain their previous content hashes in this migration.

Preserve outgoing preview deployment `a6446cfd-1356-49a2-9ffd-7e4e80295e6c`, source `80362c391888a1bafc18c06077c2ca1996bbeecc`, at <https://a6446cfd.accreatio.pages.dev> before replacing the stable preview alias. Production remains deployment `11235c8c-108f-46f3-8cce-fb88a144330b`.

Reference: [Workbox update activation](https://developer.chrome.com/docs/workbox/handling-service-worker-updates).

## Verification

- Full `npm run verify` passes: 245 tests, types, formatting, web/desktop and Functions builds, branding, surface/Electron/project-map/web/account smoke and Lighthouse (95/100/100; intentional private-beta noindex). Receipt: `.local/logs/2026-09-05T21-49-55-121Z-verify-b57e14c4-e94f-40f3-bf12-9ef8cbb42fee.log`.
- The actual legacy build at `c0793dca9620e14d31a0685ac93b57a1ddb7287a` repeats three update prompts after two accepted reloads. After serving the candidate, a normal page reload discovers and activates the repair in the same tab, without calling `registration.update()` for recovery, closing tabs or clearing storage. The saved draft survives. Fresh and recovered clients retain their documents and drafts through a subsequent worker update; login navigation reaches the network. Receipt and screenshots: `.local/logs/pwa-regression-donABt/`. Local account responses are fixtures; this is not a live email-code acceptance.
- Reproduce with `node scripts/pwa-upgrade-smoke.mjs --legacy-dir <legacy-build> --waiting-dir <previous-preview-build> --candidate-dir dist`. The harness records the input paths, entry filenames and worker digests in its receipt. Build inputs and evidence stay under `.local/`.
- Independent implementation review found no additional required fixes. The primary agent completed the final browser regression after correcting its document-identity fixture.

## Hosted delivery

Source `b7ae71ca271d5352bde3e920cbd237fb8d728736` is deployed successfully as `95a45883-726b-4ec2-b93d-a1f145f0ade4` at [the existing preview](https://archive-email-auth-preview.accreatio.pages.dev), immutable <https://95a45883.accreatio.pages.dev>. The outgoing deployment remains available.

Real Chromium verification passes with an active controlling worker, no waiting update and no unexpected dialog: public shell 200, three public Blog posts, no administrator composer, and the central sign-in button reaches the real Cloudflare email-code form. Protected account and admin probes return 401; there are no JavaScript page errors. Receipt/screenshots: `.local/logs/live-signin-1788645380432/`. Completing an actual email-code exchange remains distinct from this navigation check.

Delivery PR: [#5](https://github.com/edlopezpm-ops/accreatio/pull/5). The existing two-identity delivery path applies; this is not an execution by the unavailable kommiBo runtime.
