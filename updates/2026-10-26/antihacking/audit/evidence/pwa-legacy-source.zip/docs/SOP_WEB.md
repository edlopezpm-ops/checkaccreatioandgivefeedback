# accreatio web guide — 0.9.0 candidate

The exact live release and acceptance state are recorded in [the readiness matrix](READINESS_2026-10-21.md). This guide describes the 0.9.0 candidate. Earlier Access-only instructions remain in [the dated archive](archive/2026-10-21/SOP_WEB.before-readiness.md); they are historical, not instructions to reject the current public domain.

Open https://accreatio.com/. The welcome, generated fictional sample, About and Blog are public. Account sign-in protects the builder and export allowance. Google and GitHub appear only when their server configuration is enabled. The desktop prototype is obsolete, was never released and will never be released; accreatio is web-only. Reading or downloading the public sample uses no account allowance.

## Prepare and review

1. Name the project (up to 50 characters).
2. Choose its current phase. Research phases offer optional supporting files.
3. Describe the complete idea and intended audience.
4. Record constraints; unknown decisions may remain unresolved.
5. Review the brief, all constraints, attachments and effective options. Advanced options can change the local/managed approach, one to four unique planned roles, optional orchestration and Git/GitHub/IDE guides. Defaults are one generalist, local approach and orchestration off. Roles do not run or hire agents.

Attachments: up to 20 files, 20 MiB each and 100 MiB total. Supported types are shown at selection. Content stays in this browser while using accreatio; sharing an export with another service is a later user decision under that service's controls. No project content is sent to account or Blog APIs.

Choose the action once in Review. Check without download is on by default and consumes no allowance; no ZIP is created. Create and download ZIP prepares the archive in this tab and asks the browser to download it. The final dialog confirms the chosen action. The browser may block, rename or cancel the download; accreatio cannot establish physical persistence.

## Continue in a coding assistant

Extract the ZIP, open its folder in your editor and follow START.md. The same starting instruction is available to copy on the result page. It directs the assistant to the actual goal, constraints, phase, discoveries and pending decisions. Basic preparation needs no external AEKR checkout, Python or orchestrator. Advanced orchestration includes its configuration and setup guides; review requirements and generated code before running anything. Generated scripts are not certified safe and do not bypass PowerShell execution policy.

The Git/GitHub/IDE options add guides in the web edition. They do not run local tools, access repositories or push code. GitHub sign-in supplies identity only and is separate from those guides.

## Draft recovery

Answers, options, position and locale are saved using an immediate localStorage journal and ordered IndexedDB writes. Saving, saved and error states reflect completed storage operations. Only attachment counts persist; names and file bytes do not. After reload, reselect missing files or explicitly continue without them. Export cannot silently omit a recorded missing attachment.

One tab owns writes where Web Locks is available; a second tab keeps its edits in memory and reports the conflict. Without locks, revision checks protect writes and reset. Reload after closing the other tab to recover the saved draft. A newer draft schema is protected from overwrite. If both stores fail, keep the tab open, copy your brief or export before leaving. The draft is not a backup and can disappear through browser eviction or site-data clearing. New draft requests confirmation before discard and clears the previous ZIP retry.

## Account and allowance

Five new export authorizations per internal account in any rolling 24-hour window. It is not a midnight reset. Review, editing and cancellation consume none. Connected Google/GitHub identities share the same account and allowance; email equality never merges accounts. The server supplies the next available time, displayed in the user's timezone when known.

Retry reuses the same operation ID, authorization and exact in-memory ZIP for up to 48 hours from its original server receipt. It does not consume another authorization. Closing/reloading the tab or starting a new draft can remove the ZIP before the authorization expires. A changed project uses a new export operation. No ZIP is stored on the server.

Connect a second provider explicitly in the account menu. Account data/deletion and provider connection require a new OAuth check of an already connected identity, bound to the requested action and valid for five minutes. This is not a guarantee of fresh password or MFA entry. Re-authentication must resolve to the same internal account. Sign-out revokes the accreatio session; account deletion and provider authorization revocation are different operations. Use the provider's authorized-app settings to manage its grant.

## Updates and support

The worker updates public application assets; auth/account APIs remain network-only and uncached. A release does not reload an open project automatically. Browser drafts do not move between origins. Public queries preserve view, article and language through direct entry, reload and Back/Forward, without putting project data in URLs.

Use Help/FAQ and the applicable [Privacy](../public/legal/privacy.html), [Terms](../public/legal/terms.html) and [storage inventory](../public/legal/cookies.html). Contact aekr@aekr.io for access or rights questions. Formal legal review and Ed's release acceptance are distinct from local checks. Developers should use [the release runbook](READINESS_RELEASE_2026-10-21.md) and [identity activation](GITHUB_IDENTITY_ACTIVATION.md).
