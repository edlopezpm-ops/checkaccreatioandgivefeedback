# Design v12 — Independent parent audit

Date: 2026-09-04. Verdict: **PASS for the scoped engineering candidate.** No unresolved blocking product finding. Protected hosted deployment, Access readback and owner visual acceptance remain pending and are separate from this verdict.

This is the single independent, fresh-context Parent Audit after leaf verification. The auditor did not implement the candidate, consult prior agents/chats, run another leaf verification cycle, deploy, commit, inspect the Blog roadmap or execute desktop/package/provider work. Only this record and ignored `output/playwright/` audit evidence were written.

## Candidate and evidence

Baseline: `e2d67029f1461751dc1b0b041bedbf1b973375f5`. Audited the frozen working-tree/staged candidate against that baseline, `AGENTS.md`, `DESIGN.md`, `RESULT.md` and `VERIFICATION.json`. Independently recomputed actual-byte SHA-256 hashes: **27 source + 28 built files + 17 evidence files = 72 matches, zero mismatches**. The original 70 entries stayed unchanged while two bounded evidence entries were added during this audit. Working-tree CRLF hashes are intentional; Git text normalization is a separate representation.

Reviewed the changed App initialization, web validation, role controls, progressive summary, dry-review/ZIP handoff, execution snapshots/guards, confirmation cancellation/focus, onboarding/attachment copy, branding/footer components, generated assets and CSS. Also inspected the existing draft serialization/migration and operation guard to check the boundaries those changes rely on. Diff inspection confirms no changes to Electron source, shared domain, core, desktop assets/icons/entry, package graph, Functions, D1 or runtime configuration.

Reviewed leaf receipts for 228 passing tests, typechecks, formatting, Functions/web builds, final production-built browser smoke, Project Map 12 flows/four viewports/zero external requests, dependency audit and Lighthouse. These are **inspected leaf evidence**, not independently rerun suites. Lighthouse's recorded scores are 96/100/100/66; its only failing scored SEO audit is the intentional private-beta `is-crawlable` restriction.

## Independent functional inspection

Served the hashed `dist` with Vite preview at `http://127.0.0.1:4180`. The bounded probe used the repository's installed Playwright Chromium, Spanish browser locale, light OS preference, reduced motion and 390×600 viewport. External navigation was blocked in this probe; safe popup behavior additionally rests on the inspected final leaf receipt.

The final probe exited **0** and independently established:

- English/night startup, no theme switch, Spanish session selection and English/night after reload.
- Go back → welcome → form preserves the entered name; web name input has a 50-character maximum.
- Four distinct roles, all three occupied alternatives unavailable in each select, and disabled fifth addition.
- Actual one-file/four-participant summary with phase, local route, delivery and guide state.
- Review footer in document flow, 8px after content, no horizontal overflow at 390px. Inspected the auditor's welcome/review images and the leaf's final short-viewport review image; text and actions remain readable without footer overlap.
- Dry review produces no download and immediately offers Download ZIP. Its new confirmation says Create now and identifies the selected attachment. Cancel preserves the outcome text and button focus, with no download.
- Two synchronous activations of the final confirmation produce one browser download. The downloaded ZIP contains 17 entries; independent .NET ZIP extraction verified the selected 21-byte fixture exactly, including newline, NUL and UTF-8 text.
- The project and four roles survive reload after the existing autosave delay. Stored attachments are empty; the one-file reselection count survives. No page errors were recorded.

Replay/evidence: `output/playwright/v12-parent-audit-probe.mjs`, `v12-parent-audit-probe.json`, `v12-parent-audit-download.zip`, `v12-parent-audit-welcome-390x600.png`, and `v12-parent-audit-review-390x600.png`. The probe was authored independently. Initial harness attempts used incorrect optional/disclosure/heading locators and an immediate reload; they were corrected without product edits. The final JSON includes the stored draft read before reload.

## Findings and resolved scope

**Evidence accuracy — resolved.** The original result table gave vendor parity PASS although `.local/logs/legacy-20260905/.accreatio-v12-build.log` explicitly skipped the default check because its former sibling path was unavailable. Integration corrected `RESULT.md` to SKIPPED and supplied a separately identified read-only check of eight payload documents against pinned revision `efbda75a5ec63d05ca44ffe8913a39d3f5610c21`. Reviewed that check's implementation and receipt and verified their hashes. This gives no current-HEAD parity or payload-upgrade credit.

**Attachment-copy ambiguity — nonblocking owner wording.** “Names and counts” appears in the owner's requested wording. Actual storage preserves project names/participant labels and attachment count; it does not preserve selected filenames or file bytes. The nearby reselection warning and onboarding disclosure are accurate. This audit does not interpret that phrase as a promise to restore selected filenames.

**Existing autosave timing — bounded limitation.** Saving is debounced by 500ms. A machine-speed reload before that write can lose recent edits; the final persistence check waits 800ms and reads the stored record first. Go back preservation does not depend on this delay and passed directly. No immediate-reload persistence guarantee or autosave redesign is credited to v12.

The current web workflow meets the reviewed acceptance scope. Legacy workflow retention and desktop remain frozen; no refreshed packaged smoke, desktop release, live provider behavior, backend mutation, production promotion or owner-hosted acceptance is claimed. Continue with the authorized integration/release sequence; retain the separate hosted and owner gates.
