# Design v12 — Night-only web polish and direct ZIP handoff

Date: 2026-09-04. Owner: Ed Lopez. Implementation authorized; hosted owner acceptance pending.

## Scope and authority

The owner requested a night-only web UI that always starts in English, the Blog accreatio typography across the web brand, transparent marks without the tagline, linked AEKR/Instagram footer art with inert X/LinkedIn placeholders, simpler copy, a 50-character project name, four unique roles, a progressive summary, and an explicit ZIP action after dry review. Complete frontend work and commit/push before reviewing the Blog roadmap. Desktop remains frozen.

This continues the authorized AEKR Mode 0 workflow from design v11: root integration, an independent UX/UI implementation leaf, a form implementation leaf, and functional verification, followed by one fresh-context parent audit. Each leaf verifies its changes. No AEKR provider runtime, P04 execution, switch change, paid service, backend migration, Access change or production promotion belongs to this increment.

## Minimum sufficient change

Reuse App state, existing dialogs, web bridge, native form controls, summary/outcome components, CSS tokens and asset generator. No new dependency or schema. Web validation wraps the existing domain validator, enforcing limits both at navigation and execution while retaining the desktop contract. Restored invalid drafts remain editable; participants and names are not silently truncated or removed.

After a successful dry review, Download ZIP opens a fresh explicit confirmation with dryRun disabled. Cancel preserves the review result and attachment bytes. Only final confirmation invokes the existing guarded web execution. The summary reports actual attached-file and participant counts, route, phase and included delivery guides as the user progresses.

The wordmark uses the same heading family, weight and tracking as the existing Blog title. Web marks and installed-web icons are transparent; the tagline is hidden in the web UI and removed from generated web wordmarks/social art. AEKR and Instagram use ordinary links with target=_blank and rel=noopener noreferrer. Unconfigured social icons have no interactive role, href or focus stop.

The owner's requested locality copy is shortened with a factual qualification: the current web product delivers ZIPs, and project data is not retained on accreatio servers. The UI does not promise live project linking or deny the existing local draft. The requested attachment reminder remains explicit about reselecting files after reload.

## Verification and recovery

Verify web behavior with unit/contract tests, typechecks, formatting, generated parity, Functions and web build, Project Map and real browser flow, ZIP content including attachment bytes, restored invalid drafts, focus/short viewports, night/English defaults, footer navigation, transparent branding, and Lighthouse. No refreshed desktop build/package/release is required under the owner's freeze. One parent audit follows verification; any finding receives only a bounded delta.

The previous test deployment is 1afd10fa-f010-41d8-a658-3a5aa5224593, source 95c8ea1181f4b36c6d77b0c0747aebc4c02be07d, immutable https://1afd10fa.accreatio.pages.dev and alias https://design-v11-preview.accreatio.pages.dev. Preserve both. New testing uses a separate design-v12-preview alias. Production 11235c8c-108f-46f3-8cce-fb88a144330b remains unchanged. Existing legacy workflow remains buildable; v11 design and audit evidence stays dated and unchanged. This increment modifies the current presentation rather than introducing another workflow implementation or archive copy.

Final evidence, audit verdict and deployment identity are recorded separately when established. No pass is predeclared here.
