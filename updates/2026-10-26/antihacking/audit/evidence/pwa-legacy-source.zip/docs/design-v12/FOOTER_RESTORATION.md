# Original footer restoration

Date: 2026-09-04. The owner approved the rest of the current frontend and requested restoration of the previous Built with AEKR banner, retaining its hyperlink and matching the social icons to its size and style. This records frontend acceptance only.

The web footer reuses the original signature CSS and existing AEKR mark from `e2d6702`: uppercase type, original tracking, translucent background, radius, opacity and 21px artwork. Instagram, X and LinkedIn use the same visible badge styling. Original responsive text collapse is preserved. Transparent outer targets provide 44px click areas without enlarging the artwork. Footer layout remains in document flow.

Only `src/components/AekrSignature.tsx` and `src/web-branding.css` change product behavior. AEKR and Instagram still open separate tabs with `noopener noreferrer`; X/LinkedIn remain inert. Desktop, shared styles, accepted form/branding/nebula behavior and Blog code are unchanged.

Verification: web build and app typecheck PASS; 25 focused shell/accessibility/theme/web-release tests PASS; format and diff checks PASS. A real production-build browser pass at 320/390/760/1280 verifies the original rem-scaled badges and 21px icons, equal social styling, transparent 44px targets, safe popups, no opener/referrer, inert placeholders, and no footer overlap, overflow or page errors. Wide and mobile screenshots were inspected. Receipts: `.local/logs/legacy-20260905/.accreatio-footer-build.log`, `.local/logs/legacy-20260905/.accreatio-footer-scoped-tests.log`, `.local/logs/legacy-20260905/.accreatio-footer-ui.log`, `output/playwright/restored-footer-receipt.json` and `restored-footer-*.png`.

The optional whole-repository test run returned 227/228; the unchanged desktop orchestration test failed with Windows `EPERM` when creating its exclusive temporary `STOP` file, including an isolated retry. See `.local/logs/legacy-20260905/.accreatio-footer-tests.log` and `.local/logs/legacy-20260905/.accreatio-footer-orchestration-retry.log`. This is not credited as an all-tests pass, and desktop code is not changed under its freeze.

The independent bounded delta review passed; see `FOOTER_AUDIT.md`. The outgoing deployment `77613898-363c-4d3a-b048-52a6985ddc15`, source `7fc8b93c1128e78670a92397bc968bf5735ac1b8`, remains archived at `https://77613898.accreatio.pages.dev` after updating the existing `design-v12-preview` alias. Production remains separate.

Release completed: committed/pushed implementation `b1d106f1f88f63fb41883c2105fa7bbdfd98d397` deployed to preview `5650337d-81fd-4213-83ce-e9a91c8aac45`, immutable `https://5650337d.accreatio.pages.dev`, alias `https://design-v12-preview.accreatio.pages.dev`. Wrangler exited 0; Cloudflare reports success and `commit_dirty: false`. Both source hashes still match the independent review. Six anonymous checks of site/API/asset/immutable/prior preview/production redirect to Access. Production remains `11235c8c-108f-46f3-8cce-fb88a144330b`.

Deployment receipts: `.local/logs/legacy-20260905/.accreatio-footer-deploy.log`, `output/playwright/footer-deployments-after.json` and `output/playwright/v12-access-footer-after.json`. Later documentation-only commits record this release without changing its implementation.
