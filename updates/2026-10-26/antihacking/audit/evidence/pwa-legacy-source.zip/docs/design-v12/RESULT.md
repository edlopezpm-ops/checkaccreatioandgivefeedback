# Design v12 — Verification and release record

Date: 2026-09-04. Ready for protected owner testing. Engineering verification, independent parent audit and preview deployment PASS. Owner acceptance remains separate.

## Delivered behavior

Web opens in English and night mode on every load. Spanish remains available for the current session. The accreatio wordmark uses the existing Blog heading font, weight and tracking; marks and installed-web icons are transparent and the web tagline is removed. The footer presents Instagram and AEKR links in isolated new tabs, with inactive X/LinkedIn placeholders. The footer follows the page content so it cannot cover the form.

The guided workflow uses a 50-character name limit and one to four unique roles. Already-selected roles are disabled in other lists. Restored oversized or duplicate-role drafts are preserved and blocked until corrected. The progressive summary reports actual attachment/participant counts and the current phase, route and delivery choices. Go back reopens the welcome without discarding the draft.

Successful dry review offers Download ZIP immediately. This opens a new explicit confirmation with dryRun disabled and preserves selected file bytes. Cancel retains the result and restores button focus. Final confirmation uses the existing execution guard; repeated activation produces one archive. The locality copy accurately describes ZIP delivery and no project retention on accreatio servers without claiming live linking or denying local draft storage.

## Verification

| Gate | Evidence |
| --- | --- |
| Unit and contract tests | 228/228 PASS, `.local/logs/legacy-20260905/.accreatio-v12-final-tests.log` |
| Seed/Project Map parity; Cloudflare type parity | PASS, `.local/logs/legacy-20260905/.accreatio-v12-build.log` |
| AEKR payload | Default current-HEAD vendor check SKIPPED because its old sibling path is unavailable. Separate read-only check of all eight bundled documents against pinned revision `efbda75a5ec63d05ca44ffe8913a39d3f5610c21` PASS with line endings normalized; `.local/logs/legacy-20260905/.accreatio-v12-pinned-aekr.log`. No upgrade/current-HEAD parity claimed. |
| App, retained Electron and Functions typechecks; formatting | PASS, `.local/logs/legacy-20260905/.accreatio-v12-build.log`; final CSS and functional scripts format check PASS |
| Functions bundle and web build | PASS, `.local/logs/legacy-20260905/.accreatio-v12-build.log`, `.local/logs/legacy-20260905/.accreatio-v12-final-build.log` |
| Production-built web functional UI | PASS, `.local/logs/legacy-20260905/.accreatio-v12-final-web.log`, explicit exit 0 |
| Project Map browser smoke | PASS: 12 flows, four viewports, zero external requests; `.local/logs/legacy-20260905/.accreatio-v12-map.log` |
| Lighthouse | 96 performance / 100 accessibility / 100 best practices / 66 SEO; existing private-beta noindex is the sole SEO exemption; `.local/logs/legacy-20260905/.accreatio-v12-lighthouse.log` and `lighthouse-report/lhr.json` |
| Dependencies | Zero vulnerabilities; `.local/logs/legacy-20260905/.accreatio-v12-dependencies.log` |
| Branding and footer geometry | Transparent SVG/PNG corners, Blog font parity, links at least 44px; final welcome/review at 320, 390x600 and 1280px without overlap or overflow |

Functional coverage includes Spanish and English, widths 320/390/760/1280, reduced motion, short-viewport heading visibility and focus, night/English startup under Spanish browser locale and light OS, isolated footer popups with no opener/referrer, inert social placeholders, name/team limits and saved invalid draft repair, Back/welcome/edit preservation, summary counts, attached files after reload/reselection, dry review followed by ZIP cancellation/confirmation, duplicate activation, actual ZIP contents and attachment bytes, Blog regression behavior, atmosphere motion/click exclusions and fallbacks.

The first expanded browser test used an incorrect summary-stage expectation; its failure and corrected rerun remain in `.local/logs/legacy-20260905/.accreatio-v12-web.log`. Visual review then found the fixed footer overlapping content at 390x600. The footer was moved into document flow; final focal geometry, rebuilt-web full functional suite and Lighthouse all passed. Final evidence is distinguished from those earlier attempts.

`VERIFICATION.json` hashes the changed implementation and final build plus terminal/evidence files. Desktop entry/assets/icons, Electron source, shared domain, package graph, AEKR runtime, Functions, D1 configuration, publisher allowlists and Access policy are unchanged. Desktop release work remains frozen; no new Windows installer or hosted owner acceptance is claimed.

## Audit and deployment

The single fresh-context parent audit passed after the completed leaf verifications; see `AUDIT.md`. It independently verified all 72 inventory hashes and exercised the built UI at 390x600, including real ZIP bytes and reload after the existing autosave delay. There is no unresolved blocking product finding. The reviewed candidate is deployed in the separate protected `design-v12-preview` alias. The outgoing v11 immutable deployment and production identity are preserved in `DESIGN.md` and Change Control.

## Protected testing deployment

- Test URL: https://design-v12-preview.accreatio.pages.dev.
- Immutable URL: https://77613898.accreatio.pages.dev.
- Deployment: `77613898-363c-4d3a-b048-52a6985ddc15`, Preview, `design-v12-preview`, success, `commit_dirty: false`.
- Audited implementation, committed/pushed and deployed: `7fc8b93c1128e78670a92397bc968bf5735ac1b8` on `feat/guided-creation-nebula`. Later documentation-only commits record release evidence without changing that implementation.
- Wrangler upload exited 0. Cloudflare deployment readback confirms source and alias. All 72 audited source/build/evidence hashes still match after upload.
- Six anonymous checks return HTTP 302 to Access, including preview site, Blog API, brand asset, immutable URL, previous preview and production. Production remains deployment `11235c8c-108f-46f3-8cce-fb88a144330b`; v11 remains `1afd10fa-f010-41d8-a658-3a5aa5224593` with its original alias.
- Receipts: `.local/logs/legacy-20260905/.accreatio-v12-deploy.log`, `output/playwright/v12-deployments-after.json`, `output/playwright/v12-access-after.json`; hashes are recorded in the manifest deployment section.

No production promotion, Access change, publisher activation, database mutation or desktop release occurred. Local functional verification and successful protected upload do not substitute for the owner's authenticated visual acceptance.
