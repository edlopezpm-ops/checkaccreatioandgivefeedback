# Auditoría UI/UX — accreatio (frontend web)

**Modo:** AEKR · evidence-based · solo lectura de código/CSS  
**Fecha:** 2026-08-06  
**Alcance:** `src/App.tsx`, `src/components/`, `src/styles.css`, `src/responsive.css`, `src/extras.css`, `src/polish.css`, rutas visibles web (creación, onboarding, blog, about, diálogos). Fuera de alcance: Electron, scripts, tooling.

## Limitación explícita

**No hay navegador ni pantalla renderizada en esta auditoría.** Los hallazgos salen de estructura JSX, tokens CSS, breakpoints y contraste *calculado* sobre hex planos. El contraste real sobre nebulosa animada, blur, `mix-blend-mode` y tipografía fallback del SO **no se midió en captura**. Tratar ratios como estimaciones de riesgo, no como certificación WCAG.

## Resumen

La base es sólida (targets táctiles ~44px, `focus-visible`, `prefers-reduced-motion`, Atmosphere con degradación, etapas con `aria-*`, Mode 1 en `<dialog showModal>`). Los mayores riesgos de experiencia no son “más features”, sino **tipografía no servida**, **outline/idioma del documento**, **contraste sobre atmósfera**, y **ruido/jerarquía** en el flujo web de creación.

---

## Hallazgos (priorizados por impacto)

### 1. Tipografías de marca declaradas pero no cargadas
**Severidad: alta**

**Qué:** `--font-brand` / `--font-heading: "Posterama"` y `--font-body` / `--font-ui: "Inter"` (también JetBrains Mono) aparecen en `styles.css`, pero **no hay `@font-face` ni archivos `.woff/.woff2` en el repo**. `index.html` no enlaza fuentes.

**Por qué importa:** La jerarquía visual planeada (display serif + UI sans) colapsa a `serif`/`sans-serif` del sistema. Marca, headings y ritmo tipográfico dejan de ser controlables (percepción de calidad + consistencia cross-OS). Heurística Nielsen #4 (consistencia); tipografía como señal de marca.

**Recomendación:** Servir **solo** las familias que el producto necesita (self-host, `font-display: swap`), o **cambiar los tokens** a stacks reales ya disponibles. No declarar nombres que el build no entrega. Trade-off: self-host añade peso; tokens honestos sin Posterama son peores en “lujo” pero mejores en verdad operativa.

---

### 2. Dos `<h1>` concurrentes en el flujo de creación
**Severidad: alta**

**Qué:** En `App.tsx`, `.section-head` renderiza `<h1>{t.title}</h1>` (“Crear un nuevo proyecto”) **y** cada stage (`FoundationStage`, etc.) tiene su propio `<h1 id="…-title">`.

**Por qué importa:** Outline confuso para AT y para escanear (WCAG 2.4.6 Headings; 1.3.1 Info and Relationships). Compite la promesa de página con el título de etapa.

**Recomendación:** Un solo `h1` por vista: el de etapa. Convertir el título de panel en `p`/`h2` o eyebrow. Trade-off: se pierde un “título de producto” redundante; el beneficio de orientación por etapa es mayor.

---

### 3. `lang` del documento no sigue el locale de UI
**Severidad: alta**

**Qué:** `index.html` fija `<html lang="es">`. El toggle de idioma en `AppFrame` actualiza estado React (`s.locale`) pero **no** `document.documentElement.lang` (solo se setea `dataset.theme`).

**Por qué importa:** WCAG 3.1.1 Language of Page. Lectores de pantalla y diccionarios usan el idioma equivocado en EN. El blog marca `lang="en"` en artículos (bien a nivel de fragmento), pero la página raíz sigue en `es`.

**Recomendación:** En el mismo `useEffect` del tema (o al cambiar locale), `document.documentElement.lang = s.locale`. Coste casi cero; no añade complejidad de producto.

---

### 4. Modal de exportación: trap de teclado sin inerte del resto
**Severidad: media**

**Qué:** El confirm de ejecución (`role="dialog"`, Tab cycle, Escape) es custom. Mode 1 usa `<dialog>.showModal()` (inerte nativo). El modal de exportación **no** marca el shell detrás como `inert`/`aria-hidden`.

**Por qué importa:** WAI-ARIA APG Dialog: el foco puede quedar atrapado por teclado, pero AT puede seguir leyendo el fondo. Inconsistencia entre dos patrones de diálogo en la misma app (Nielsen #4).

**Recomendación:** Preferir `<dialog showModal>` como Mode 1, **o** `inert` en `.app-shell` mientras `confirm`. No reinventar un segundo focus-trap si el nativo basta. Trade-off: migrar el markup del confirm; evita deuda a11y dual.

---

### 5. Gate de etapas en móvil: selector sin explicación del rechazo
**Severidad: media**

**Qué:** ≤767px oculta `.stage-navigation` y muestra `.stage-selector`. `changeCreationStage` bloquea salida si la etapa actual es inválida y enfoca el primer error — correcto — pero el `<select>` controlado **vuelve al valor anterior** sin mensaje de estado global.

**Por qué importa:** Nielsen #1 (visibilidad del estado) y #9 (reconocer errores). En desktop el rail muestra “Needs attention”; en móvil el snap-back parece un bug.

**Recomendación:** Al rechazar el cambio, anunciar con `role="alert"` / `aria-live` una línea (“Completa Fundamentos antes de continuar”) además del focus al campo. No hace falta un wizard más complejo. Trade-off: un string de copy vs. UX opaca.

---

### 6. Contraste: tokens planos OK; atmósfera y opacidad los debilitan
**Severidad: media**

**Qué:** Sobre fondos sólidos (`#151126` / `#f2f3fb`), `--text-muted` y placeholders **pasan ~4.5:1** (cálculo sRGB). Riesgos:
- Texto muted sobre midtones de nebulosa (~`#57417f`) ≈ **2.7:1** (falla AA).
- `.aekr-signature` usa `--text-muted` + `opacity: 0.52` → contraste efectivo ≈ **2.4:1**.
- Paneles `surface-instrument` + `backdrop-filter` sobre WebGL no garantizan el mismo fondo que el token.

**Por qué importa:** WCAG 2.2 1.4.3 Contrast (Minimum); 1.4.11 si el control depende del borde sobre fondo variable.

**Recomendación:** Scrim más opaco bajo copy crítica; subir opacidad de la firma o quitarla del plano de lectura; evitar texto muted fuera de superficies sólidas. Trade-off: menos “glow” vs. texto legible. No hace falta un segundo tema.

---

### 7. Jerarquía de marca inconsistente entre superficies web
**Severidad: media**

**Qué:**
- **About:** marca en header + `about-brand-link` + `<h1>accreatio</h1>` (triple señal).
- **Blog:** hero tipográfico “Blog”; la marca queda en chrome/footer.
- **Creación:** brand en header; el primer viewport de trabajo lo dominan título de formulario + etapas.

**Por qué importa:** Coherencia de producto y reconocimiento (Nielsen #4). About es marca-first; Blog se siente plantilla editorial genérica si se ignora el nav.

**Recomendación:** Una regla simple: en marketing (about/blog/onboarding) la marca es hero o co-hero; en tool UI basta el mark del header. En Blog, bajar el peso de “Blog” o prefijar con accreatio en el lede, sin añadir cards. Trade-off: menos “magazine”; más producto.

---

### 8. Estado duplicado en edición web
**Severidad: media**

**Qué:** Paralelamente: `StatusNotice` en header (borrador/ZIP), `WebExperienceIntro` (`role="status"` + draft-state), chip “PWA local · beta”, y a veces `hostMessage` alert.

**Por qué importa:** Nielsen #8 (minimalismo). El usuario debe inferir cuál es la fuente de verdad del guardado.

**Recomendación:** Un canal de estado de borrador (header **o** intro, no ambos con el mismo mensaje). Mantener el intro solo para el *modelo mental* web (ZIP / sin cuenta) y mover “Guardado…” al status del shell. Trade-off: menos redundancia de confianza vs. menos repetición.

---

### 9. Microtipo y densidad: labels/errores legacy demasiado pequeños
**Severidad: media**

**Qué:** `.control em` (errores del `Field` legacy) a **11px**; en `responsive.css`, `.field-label small` / `.segment button` a **0.74–0.76rem**. Las etapas nuevas usan `.field-error` a `--text-sm` (mejor).

**Por qué importa:** No es fallo automático de contraste, pero degrada legibilidad y reflow (WCAG 1.4.4 Resize Text en la práctica). Dos sistemas de error coexisten.

**Recomendación:** Unificar errores a `--text-sm` / token de danger; eliminar 11px. No añadir componentes nuevos.

---

### 10. i18n de chrome vs. contenido del Blog
**Severidad: media**

**Qué:** UI del blog traduce eyebrow/lede/CTA; posts viven en inglés con `lang="en"` (correcto a nivel de fragmento). Un usuario en `es` ve chrome en español y cuerpo solo EN sin aviso previo en el índice.

**Por qué importa:** Expectativa de idioma (Nielsen #2 Match between system and real world). No es bug de `lang` en el artículo; es honestidad editorial.

**Recomendación:** En el índice o provenance, una línea fija: “Artículos en inglés” / “Posts in English”. Traducir posts es opcional y caro; el aviso es barato. Trade-off: no fingir bilingüismo.

---

### 11. Sticky header sin skip link; focus puede quedar bajo el chrome
**Severidad: media**

**Qué:** `.app-header` es `position: sticky; z-index: 5`. Hay `scroll-margin` en blog/review, **no** en campos del formulario. `focusCreationTarget` hace `.focus()` sin garantizar scroll por encima del header (~alto variable en móvil).

**Por qué importa:** WCAG 2.4.1 Bypass Blocks; 2.4.3 Focus Order / visibilidad del foco.

**Recomendación:** Skip link “Ir al contenido” hacia `main`; `scroll-margin-top` en inputs de creación acorde a la altura del header. Bajo coste, alto retorno teclado.

---

### 12. Estética púrpura-nebulosa + Inter nominal: riesgo de indistinción
**Severidad: baja**

**Qué:** Tokens dark violet (`#151126`, `#bfa1ff`) + nombre Inter (aunque no cargue) encajan en el cluster “AI purple dashboard”. Posterama mitigaría si se sirviera; hoy no.

**Por qué importa:** Diferenciación de marca a largo plazo, no un blocker de uso.

**Recomendación:** Con la fuente real cargada, re-evaluar; si se mantiene Inter, compensar con display distinto ya self-hosted. **No** rediseñar el sistema de color “porque sí” — solo si la marca lo pide. Trade-off: cambio cosmético vs. deuda tipográfica del hallazgo #1.

---

### 13. Atmosphere: buena degradación; coste residual cuando WebGL sí corre
**Severidad: baja**

**Qué:** `Atmosphere` respeta `prefers-reduced-motion`, `saveData`, `update: slow`, pausa por `visibilitychange`, fallback CSS — alineado con percepción de rendimiento y WCAG 2.3.3. Cuando carga Vanta+Three, hay parallax por `pointermove` + blur de paneles.

**Por qué importa:** En máquinas medias, el fondo puede competir con la tarea de formulario (RAIL / INP percibido), aunque no bloquee interacción.

**Recomendación:** Mantener el path de degradación; considerar densidad aún menor en `creation`/`review` (ya hay variantes). Evitar añadir más capas de motion. Trade-off: atmósfera memorable vs. tool calmada — el producto ya eligió densidad por variante; afinar, no reinventar.

---

### 14. `theme-color` fijo al dark
**Severidad: baja**

**Qué:** `index.html` meta `theme-color: #151126` no sigue `data-theme=light` (`#f2f3fb`).

**Por qué importa:** Chrome UI del browser/PWA desentonada en tema claro (pulido, no bloqueo).

**Recomendación:** Actualizar meta/`theme-color` al togglear tema. Cambio mínimo.

---

## Lo que no recomiendo (anti-complejidad)

- No convertir la creación en un design system de cards/dashboard.
- No duplicar navegación de etapas (rail + stepper + breadcrumbs).
- No añadir librería de a11y overlay si `<dialog>` / `inert` resuelven #4.
- No “arreglar contraste” subiendo saturación global: arreglar scrim y opacidad local (#6).

## Marcos de referencia usados

- Nielsen: visibilidad del estado, consistencia, minimalismo, reconocimiento de errores.
- WCAG 2.2: 1.3.1, 1.4.3, 1.4.4, 2.4.1, 2.4.3, 2.4.6, 3.1.1; APG Dialog.
- Rendimiento percibido: degradación de Atmosphere vs. costo WebGL residual.
