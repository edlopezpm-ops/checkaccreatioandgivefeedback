# Claude audit remediation - 2026-08-02

Source audit: `claude accreatio audit.pdf`, commit `03af351`, verdict `PASS_WITH_OBSERVATIONS`.

## Remediated

- SEC-1: attachment copies now use atomic exclusive creation with collision retry.
- SEC-2: deny-by-default window opening, navigation, permissions, and a restrictive CSP.
- COR-1: shared types, limits, slugging, and validation now cross the renderer/main boundary from one module.
- COR-2: UI Git cascades use a shared pure domain transition and have direct tests.
- COR-3: `preferredIde` is a literal union.
- COR-4: translation dictionaries have compile-time key parity.
- COR-5: React has a minimal bilingual recovery boundary.
- TST-1: the highest-risk filesystem mutation seams now have temp-directory integration coverage, including non-overwrite behavior. Full orchestration coverage for Git/GitHub/IDE remains a follow-up because those external tools need injectable adapters.
- DEP-1: all direct dependencies are pinned to the versions verified by this release.
- DOC-1: the security limit now agrees with code and the other documents.
- PROC-1: a Windows CI workflow independently runs install, tests, typecheck, and build.
- QUAL-1: source formatting is enforced through Prettier.
- DOC-2: legacy-name migration has an explicit 1.0.0 sunset.

## Accepted or deferred

- SEC-3: no demonstrated exploit path; dependency pinning and deliberate update hygiene are the stated mitigation.
- TST-2: shared UI domain transitions now have direct coverage; component-level React coverage remains proportional to future UI growth.
- DEP-3: Authenticode signing requires a trusted certificate and recurring cost. It remains a public-distribution gate, not a zero-cost private-MVP change.
- PROC-2: an AI-authored remediation cannot manufacture an independent human audit. This remains a governance caveat.
- QUAL-2: CSS consolidation is organizational debt with no behavioral or security impact and is deferred to a dedicated visual-regression-safe pass.
