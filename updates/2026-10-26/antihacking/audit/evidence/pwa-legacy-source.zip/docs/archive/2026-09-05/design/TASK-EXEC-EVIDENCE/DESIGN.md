# TASK-EXEC-EVIDENCE — Artifact verification and outcome feedback

Status: design complete; production implementation remains gated. Owner: EXEC-01. This record follows the authoritative objective, scope, non-goals, dependencies, acceptance criteria, risks, and evidence in `docs/archive/2026-09-05/design/TASK_BACKLOG.md`.

## Decision summary

One guarded logical operation produces one structured `ExecutionResult`, identified by the required `operationId` from `TASK-EXEC-IDEMPOTENCY`. The result keeps the dependency design's existing fields for atomic compatibility and adds an explicit outcome, step ledger, and artifact/delivery evidence. UI copy is derived from structured data, never parsed from logs.

Before confirmation, a host-aware pure preview states one of four effects:

- desktop tracking: create one version-protected `PROJECT_STATUS.md` in the displayed tracking directory;
- desktop repository: create/augment the displayed repository and write the displayed generated/attachment set;
- desktop both: perform both of those independently;
- W1 repository or both: build one ZIP with the displayed filename and complete deterministic manifest; W1 `both` means the same repository ZIP and does not claim browser tracking.

Dry-run remains on by default. Its confirmation banner says that no file, directory, remote, IDE launch, ZIP construction, or download request will occur. A successful dry-run is titled “Review complete — nothing was created” and offers the existing Dry run toggle as the next action.

Desktop execution records the exact paths returned by versioned writes/copies, plus the repository and tracking destinations. Each logical step is marked completed, failed, or skipped. If a later step fails, accumulated evidence is returned and retained; no completed output is deleted. W1 returns the exact ZIP filename and the exact resolved entry manifest. It may truthfully say that the app built the ZIP and requested a browser download, but never that the browser saved it. The user must verify the browser download and open the ZIP.

Application evidence and independent acceptance evidence are distinct. The app reports what its own APIs completed. The Test Engineer later inspects real directories and ZIP entries/bytes; a toast, `ok: true`, log line, anchor click, or returned path alone is not acceptance evidence.

## Contract decisions

### Host-aware execution preview

Add pure types and a pure builder in `src/types.ts` and `src/core.ts`:

```ts
type ExecutionHost = "desktop" | "web";

interface PlannedArtifact {
  kind: "repository" | "tracking" | "generated-file" | "attachment" | "zip" | "zip-entry";
  displayName: string;
  destination: string; // desktop absolute target/dir or W1 filename/archive path
  certainty: "planned";
}

interface ExecutionPreview {
  host: ExecutionHost;
  dryRun: boolean;
  action: Action;
  headline: string;
  artifacts: PlannedArtifact[];
  limitations: string[];
}
```

`buildExecutionPreview(definition, settings, host, resolvedWebManifest?)` is the only confirmation source. It shares slug and fixed generated-file projection helpers with execution. For W1 with attachments, it consumes the already resolved projection from `TASK-WEB-ATTACHMENTS`; it must not independently rename or reorder entries. The confirmation may describe an unknown desktop version suffix as “`PROJECT_STATUS.md` (or the next versioned copy)” because the exact collision-free name is decided atomically at write time. It displays the exact parent directory and expected content set, then the result displays the actual returned filename.

Correct the existing current-state mismatch as part of this Task: tracking-only preview contains tracking only. It must not inherit the current generic `planActions()` `docs` or attachment actions, because `electron/main.ts` performs neither for tracking-only. W1 rejects tracking-only before confirmation and explains that Repository or Both creates the ZIP; W1 Both must not claim a tracking artifact. `planActions()` may remain the setup/instruction planner, but confirmation and evidence must not use it as an execution manifest.

Preview repository generated entries are, in deterministic order: `PROJECT_PROMPT.md`, `docs/product/discovery.md`, `AGENTS.md`, `.accreatio/project.json`, optional `.ai-engineering/orchestration.yaml`, and W1-only `SETUP.md`; W1 resolved attachment entries follow in selection order under `docs/product/sources/`. Desktop attachment preview lists approved source basenames and the target directory, with a version-suffix caveat. Git initialization, GitHub repository creation, and IDE opening are shown as separate effects, not artifacts. GitHub copy repeats “no push.”

### Result schema

Extend, do not replace, the `TASK-EXEC-IDEMPOTENCY` result contract:

```ts
type ExecutionOutcome = "dry-run" | "success" | "partial" | "failure";
type ExecutionStepStatus = "completed" | "failed" | "skipped";

interface ArtifactEvidence {
  kind: "repository-root" | "tracking-file" | "generated-file" |
        "attachment" | "zip" | "zip-entry" | "git-repository" |
        "github-remote" | "ide-launch";
  location: string;       // absolute desktop path, ZIP filename, or archive path
  displayName: string;
}

interface ExecutionStepResult {
  id: string;             // stable planned-operation ID
  status: ExecutionStepStatus;
  summary: string;
  artifacts: ArtifactEvidence[];
  error?: string;
}

interface WebDeliveryEvidence {
  state: "not-requested" | "download-requested";
  filename: string;
  manifest: string[];
  browserPersistenceVerified: false;
}

interface ExecutionResult {
  operationId: string;
  ok: boolean;
  dryRun: boolean;
  projectPath?: string;       // retained for compatibility
  completed: string[];        // retained; stable completed step IDs only
  logs: string[];             // diagnostics, not UI evidence
  error?: string;
  outcome: ExecutionOutcome;
  steps: ExecutionStepResult[];
  artifacts: ArtifactEvidence[];
  webDelivery?: WebDeliveryEvidence;
}
```

Every host-produced result, including validation/caught failure and dry-run, echoes `operationId`. `ok` is true for `dry-run` and `success`, false for `partial` and `failure`. `outcome` is `partial` whenever the operation fails after any durable filesystem/remote effect or after any completed step; it is `failure` when nothing completed. Dry-run returns no artifact evidence and all mutation steps as `skipped` with a dry-run reason. `completed` mirrors only `steps` with status `completed`; it never means “planned.”

Stable step IDs are `repository-root`, `repository-docs`, `attachments`, `git`, `github`, `tracking`, `history`, and `ide` on desktop, and `zip-build` and `download-request` on W1. A step is completed only after its bounded effect finishes. File-level evidence is appended immediately after each successful `writeVersioned`/`copyVersioned`, so a failure midway through `repository-docs` still returns the individual files that exist even though that step is failed. This avoids overstating the current coarse `completed` array.

`ArtifactEvidence` is operation-local and rendered in the result panel. Do not persist it in history, telemetry, console output, or a new evidence file. Existing history schema is unchanged. Absolute paths are necessary feedback on desktop but may disclose usernames in screenshots; the UI labels them local, does not auto-copy them, and documentation warns users to redact paths before sharing diagnostics.

### Outcome rules and recovery

- Dry-run: no side effects; show the exact preview and “Turn off Dry run, review again, then confirm” guidance.
- Desktop success: show each actual repository root and/or exact tracking file, then a collapsible “Produced items” list. Repository success includes exact returned generated and copied-source paths.
- W1 success: title “ZIP prepared; download requested,” show filename and manifest, and say “Your browser may block, cancel, rename, or relocate the download. Check Downloads and open the ZIP to verify it.” Never use “ZIP saved” or “ZIP exported” as a completion claim.
- Partial: title “Some work completed,” list Completed and Not completed sections, identify the failed step/error, retain all paths, and advise inspection before a deliberate fresh review/rerun. Do not promise that rerun resumes; existing versioned writes may create new copies.
- Failure: title “Nothing was completed,” show the failed step/error and correction guidance. Preserve definition, settings, and transient W1 attachment selection as required by the dependency design.
- Git/GitHub/IDE/history failure after files exist is partial. A GitHub remote successfully created before a later history/IDE failure is listed explicitly, with “no push performed.” No rollback or deletion occurs.
- A W1 ZIP-build or DOM download-request error is failure with no delivery evidence. Once the download request returns, the app result is successful only as an app-generation/request outcome; disk persistence remains explicitly unverified.

Result ordering is deterministic: steps in planned execution order; artifacts in creation/manifest order. User-facing summaries are localized in `App.tsx`; the main process and bridge return stable IDs/data plus bounded technical errors, not English sentences that the UI must parse.

## Sprint 1 — Existing-result-contract discovery

Entry conditions: mandate, backlog, reproduction report, and both dependency designs read. Included: current result/planning/write/export paths. Excluded: production edits and live prohibited suites.

### MSS 1.1 — Reconcile the current shared/UI contract

1. **Reconfirm objective:** identify why current feedback cannot prove output.
2. **Inspect current state:** `src/types.ts`, `src/core.ts`, and `src/App.tsx` result/confirmation flow.
3. **Intended artifact:** this design record only.
4. **Bounded design work:** recorded that `ExecutionResult` has only `ok`, `dryRun`, optional `projectPath`, coarse `completed`, logs, and error; the result panel reduces success to a heading/event count; confirmation shows only one target and action count.
5. **Focused validation:** compared those fields to backlog acceptance and idempotency's required `operationId` extension.
6. **Result:** structured steps/artifacts and explicit outcome are required; logs cannot be evidence.
7. **Deviations/findings:** current `planActions()` advertises docs/attachments for tracking-only although desktop execution skips them; classified C/current Task.
8. **Status:** complete.

### MSS 1.2 — Reconcile desktop execution and versioning

1. **Reconfirm objective:** identify which actual paths can be returned without speculative checks.
2. **Inspect current state:** `electron/main.ts` and `electron/files.ts`.
3. **Intended artifact:** desktop evidence contract in this record.
4. **Bounded design work:** traced repository, generated files, attachments, Git/GitHub, tracking, history, and IDE ordering; confirmed `writeVersioned`/`copyVersioned` return exact paths currently discarded.
5. **Focused validation:** checked exclusive/versioned semantics and catch behavior against partial-failure requirements.
6. **Result:** accumulate returned paths as each effect completes; never delete on a later error.
7. **Deviations/findings:** a `docs` failure can occur after several durable writes but before the coarse step is marked complete; file-level evidence is mandatory.
8. **Status:** complete.

### MSS 1.3 — Reconcile W1 export and attachment dependency

1. **Reconfirm objective:** separate ZIP generation evidence from browser persistence.
2. **Inspect current state:** `src/bridge/web.ts`, `src/webExport.ts`, and `TASK-WEB-ATTACHMENTS/DESIGN.md`.
3. **Intended artifact:** W1 delivery/manifest contract in this record.
4. **Bounded design work:** traced fixed text entries, optional orchestration, dynamic ZIP build, anchor click, and the approved resolved mixed text/binary manifest.
5. **Focused validation:** checked naming/order/provenance against the attachment resolver decision and browser API limits.
6. **Result:** return filename + exact resolved manifest + `download-requested`, always with persistence false.
7. **Deviations/findings:** current `ok:true` after `a.click()` cannot justify “ZIP exported.”
8. **Status:** complete.

### Sprint 1 consolidation

Current writes/exports are real, but current result data is too coarse and the UI over-compresses it. Exact desktop paths are already obtainable from file helpers; exact W1 contents are obtainable from the dependency's one resolved manifest. Browser save completion is unavailable. The tracking-only planning mismatch must be corrected within this Task so pre-confirmation is truthful.

Sprint checkpoint: Sprint 1  
Objective: establish the real current execution/evidence contract.  
Micro-sub-sprints completed: 1.1–1.3.  
Files changed: design record only.  
Focused tests: static contract/path/manifest reconciliation.  
Results: evidence gaps and one Task-critical planning mismatch identified.  
New findings: partial docs writes are invisible to the coarse completed list.  
Residual risks: live host behavior remains for the Test Engineer.  
Deviations: none.  
Ready for next sprint: Yes.

## Sprint 2 — Pre-confirmation copy design

Entry conditions: Sprint 1 consolidated. Included: confirmation content and host/action distinctions. Excluded: changing default dry-run or idempotency controls.

### MSS 2.1 — Define desktop preview

1. **Objective:** state exactly what tracking/repository/both will attempt.
2. **Current state:** one modal target always displays the repository destination.
3. **Intended files for implementation:** `src/types.ts`, `src/core.ts`, `src/App.tsx`, focused core/UI tests.
4. **Design work:** use `ExecutionPreview`; tracking displays tracking directory/versioned filename, repository displays repository/artifact set, both displays two destination groups; optional Git/GitHub/IDE effects are separate.
5. **Validation:** mapped all `electron/main.ts` branches and action flags to one preview row.
6. **Result:** no desktop action is hidden or falsely grouped.
7. **Deviations/findings:** final versioned filenames cannot be known before exclusive writes; copy explains this explicitly.
8. **Status:** complete.

### MSS 2.2 — Define W1 preview and dry-run language

1. **Objective:** distinguish review from a real local ZIP request.
2. **Current state:** modal says Download/Export now even when dry-run; W1 Both semantics are implicit.
3. **Intended files:** `src/core.ts`, `src/App.tsx`, `src/webExport.ts` projection helper, tests.
4. **Design work:** dry-run warning says no ZIP will be built/download requested; real W1 shows exact filename and resolved entries; Repository/Both equivalence and tracking unsupported status are stated before action.
5. **Validation:** compared copy to W1 attachment final naming and backlog non-goals.
6. **Result:** host limitations and artifact set are visible at decision time.
7. **Deviations/findings:** none.
8. **Status:** complete.

### MSS 2.3 — Confirmation interaction/visual contract

1. **Objective:** keep dense evidence readable and actionable.
2. **Current state:** small undifferentiated target block and action count.
3. **Intended files:** `src/App.tsx`, existing result/modal CSS owned by the theme system, UI tests.
4. **Design work:** modal order is mode banner → destination groups → produced-item summary/expandable manifest → non-file effects → limitations → Cancel/Confirm. Confirm label is “Run dry review,” “Create tracking,” “Create repository,” “Create both,” or “Prepare ZIP,” localized. Consume semantic theme tokens only.
5. **Validation:** keyboard reading order, 320px layout, supported desktop sizes, 200% zoom, dark/light state checks.
6. **Result:** the decision is understandable without reading logs or internal IDs.
7. **Deviations/findings:** long manifests default to a count plus expandable list, while destinations and limitation remain visible.
8. **Status:** complete.

### Sprint 2 consolidation

Confirmation becomes a truthful host-aware artifact preview. Dry-run is unmistakably non-mutating. Desktop Both shows both destinations; W1 Both declares its repository-ZIP meaning. Unknown version suffixes are disclosed rather than guessed.

Sprint checkpoint: Sprint 2  
Objective: define exact pre-confirmation copy and interaction.  
Micro-sub-sprints completed: 2.1–2.3.  
Files changed: design record only.  
Focused tests: designed preview branch, localization, keyboard, responsive, zoom, and theme checks.  
Results: all pre-confirmation acceptance paths covered.  
New findings: none.  
Residual risks: very large manifests require accessible disclosure behavior.  
Deviations: none.  
Ready for next sprint: Yes.

## Sprint 3 — Result-state design: success, partial, failure

### MSS 3.1 — Define structured result state

1. **Objective:** make every result map to one guarded operation and stable steps.
2. **Current state:** dependency adds `operationId`; existing fields are coarse.
3. **Intended files:** `src/types.ts`, both bridges, `electron/main.ts`, `src/App.tsx`, tests/smoke harness.
4. **Design work:** add `outcome`, step ledger, artifact evidence, and optional W1 delivery while retaining dependency fields.
5. **Validation:** enumerated validation, dry-run, success, partial, failure, coalesced replay, and explicit-rerun returns.
6. **Result:** one immutable result snapshot per `operationId`; replay returns identical evidence.
7. **Deviations/findings:** no persisted migration or AEKR schema change.
8. **Status:** complete.

### MSS 3.2 — Define desktop partial/failure accumulation

1. **Objective:** report durable completed work without rollback.
2. **Current state:** one outer catch returns coarse completed IDs.
3. **Intended files:** `electron/main.ts`, `electron/files.ts` only for existing returned-path use, execution/files tests.
4. **Design work:** create step records before bounded effects; append returned file paths immediately; close each step completed/failed; derive outcome; preserve later steps as skipped. Do not delete output or auto-retry.
5. **Validation:** failure injection after folder, each generated write, attachment copy, Git, GitHub, tracking, history, and IDE.
6. **Result:** Completed/Not completed UI can be accurate even inside a failed composite step.
7. **Deviations/findings:** directory creation alone counts as a durable effect and makes a later error partial, even if no file was written.
8. **Status:** complete.

### MSS 3.3 — Define result presentation and recovery

1. **Objective:** present evidence before diagnostics.
2. **Current state:** heading plus event count and raw log disclosure.
3. **Intended files:** `src/App.tsx`, result CSS, localization/UI tests.
4. **Design work:** render outcome heading, concise explanation, destination/evidence groups, Completed/Not completed sections, recovery, then optional diagnostics. Never expose operation ID/fingerprint normally. Keep input untouched; deliberate rerun returns through Review.
5. **Validation:** screen-reader live announcement, focus restoration, keyboard disclosure, narrow/zoom, both themes, long/error path wrapping.
6. **Result:** success, partial, and failure cannot be confused by color alone.
7. **Deviations/findings:** raw local paths are intentionally shown but never persisted in new logs.
8. **Status:** complete.

### Sprint 3 consolidation

The additive result contract preserves idempotency compatibility while making partial work first-class. Outcome is derived from completed durable effects, not from a generic catch. UI prioritizes destinations and recovery over log volume.

Sprint checkpoint: Sprint 3  
Objective: define truthful success/partial/failure results.  
Micro-sub-sprints completed: 3.1–3.3.  
Files changed: design record only.  
Focused tests: designed contract, failure-injection, replay, UI state, accessibility, and localization checks.  
Results: complete outcome state machine and recovery contract.  
New findings: empty created directories are partial evidence.  
Residual risks: GitHub side effects may require user inspection outside the filesystem.  
Deviations: none.  
Ready for next sprint: Yes.

## Sprint 4 — Destination-evidence design

### MSS 4.1 — Desktop exact-path evidence

1. **Objective:** name actual outputs, including versioned copies.
2. **Current state:** helpers return exact targets; executor discards most of them.
3. **Intended files:** `electron/main.ts`, existing `electron/files.ts`, result tests and Electron smoke harness.
4. **Design work:** capture each helper return, repository root, exact tracking file, attachment targets, `.git`, remote URL/name when created, and IDE target; never infer a versioned filename after writing.
5. **Validation:** pre-existing collision fixtures and exact tree/content/hash inspection design.
6. **Result:** desktop result names what the operation actually produced.
7. **Deviations/findings:** repository root may pre-exist; label it “Repository used” and distinguish newly written/versioned files rather than claim the directory was created.
8. **Status:** complete.

### MSS 4.2 — W1 ZIP manifest and delivery boundary

1. **Objective:** prove app composition without claiming browser persistence.
2. **Current state:** logs list files after anchor click; attachment design supplies one mixed manifest.
3. **Intended files:** `src/webExport.ts`, `src/bridge/web.ts`, `src/App.tsx`, web export/bridge/UI tests.
4. **Design work:** pass the exact `ExportEntry[]` manifest through ZIP build into delivery evidence; include all generated and attachment archive paths; report `download-requested` only after the injected DOM adapter returns; hard-code persistence false.
5. **Validation:** unzip fixtures, compare order/path/text/binary bytes, inject ZIP/DOM failure, assert wording contains no saved certainty.
6. **Result:** W1 evidence is deterministic and honest.
7. **Deviations/findings:** ZIP container byte hash is not required because dependency design only guarantees entry order/path/content.
8. **Status:** complete.

### Sprint 4 consolidation

Desktop evidence is based on actual helper return values and distinguishes reused roots from newly written files. W1 evidence is the exact deterministic manifest and a bounded download-request state; browser save remains user-verifiable only.

Sprint checkpoint: Sprint 4  
Objective: define destination and ZIP evidence.  
Micro-sub-sprints completed: 4.1–4.2.  
Files changed: design record only.  
Focused tests: designed path collision, tree/hash, ZIP entry/byte, and download-adapter checks.  
Results: host-specific evidence contract complete.  
New findings: pre-existing repository roots require careful “used” language.  
Residual risks: browser policy/location and screenshot path disclosure.  
Deviations: none.  
Ready for next sprint: Yes.

## Sprint 5 — Verification and implementation delivery plan

### MSS 5.1 — Automated and smoke verification plan

1. **Objective:** give the Implementer focused proof obligations.
2. **Current state:** core/files/webExport/bridge tests and an Electron execute smoke harness exist.
3. **Intended files:** `tests/core.test.ts`, `tests/files.test.ts`, `tests/webExport.test.ts`, `tests/bridge.test.ts`, relevant UI tests, Electron smoke fixture/harness, plus implementation files below.
4. **Design work:** define branch/contract/failure matrices, one-operation replay equality, no-artifact dry run, exact returned versioned paths, partial accumulation, exact W1 manifest, DOM failure, and prohibited-certainty copy tests.
5. **Validation:** mapped every backlog acceptance criterion and dependency invariant to automated or later independent evidence.
6. **Result:** proportional focused and integrated tests specified.
7. **Deviations/findings:** Node/renderer tests cannot establish final browser download persistence.
8. **Status:** complete.

### MSS 5.2 — Independent Test Engineer evidence plan

1. **Objective:** verify actual artifacts rather than UI claims.
2. **Current state:** reproduction explicitly defers live desktop/W1 proof.
3. **Intended artifact:** later Test Engineer evidence record and disposable roots/fixtures only.
4. **Design work:** specified the independent matrix below.
5. **Validation:** includes dry-run, each host/action, collisions, attachments, partial failure, blocked download, keyboard/theme/responsive, and rerun behavior.
6. **Result:** acceptance cannot be satisfied by the Implementer’s result object alone.
7. **Deviations/findings:** browser save verification is necessarily observational/manual.
8. **Status:** complete.

### MSS 5.3 — File-level implementation sequence, migration, security, docs

1. **Objective:** eliminate undocumented implementation choices.
2. **Current state:** affected contracts span pure core, UI, hosts, tests, and SOPs.
3. **Intended artifact:** ordered file plan below.
4. **Design work:** specified additive schema, atomic bridge migration, no persisted data migration, local-path handling, and exact docs.
5. **Validation:** checked master boundaries, supplemental §§5/6/30/31, current schema, and both dependencies.
6. **Result:** implementation-ready delivery order complete.
7. **Deviations/findings:** no AEKR or upstream schema change is needed.
8. **Status:** complete.

### Sprint 5 consolidation

Automated tests prove structured behavior; independent live inspection proves actual outputs. Implementation order starts with pure contracts/projections, then hosts, UI, tests, and synchronized docs. No paid service, telemetry, browser filesystem access, rollback, auto-open, auto-push, or dry-run-default change is introduced.

Sprint checkpoint: Sprint 5  
Objective: complete verification and delivery design.  
Micro-sub-sprints completed: 5.1–5.3.  
Files changed: design record only.  
Focused tests: acceptance-to-evidence and mandate/schema cross-check.  
Results: implementation package complete.  
New findings: none.  
Residual risks: environment/browser policies and sensitive screenshot paths.  
Deviations: none.  
Ready for next sprint: Yes.

## UX decision records (supplemental §6)

### Decision A — Pre-confirmation artifact preview

1. **Goal:** understand and approve exactly what this host/action will do.
2. **Required information:** dry-run state, host, action, destinations/ZIP, artifact set, optional side effects, limitations.
3. **Optional information:** expanded long manifest and version-suffix explanation.
4. **Happy path:** Review → inspect mode/destinations → Confirm once.
5. **Failures:** invalid definition, unsupported W1 tracking, stale attachment projection, unavailable destination.
6. **Explanation:** inline localized reason beside the affected group; confirmation is blocked when unsupported/invalid.
7. **Recovery:** close without changes, correct the form/settings, and review again.
8. **Success confirmation:** this stage confirms only approval; post-result evidence confirms host work.
9. **Accidental repetition:** dependency synchronous gates/disabled controls and guarded operation identity.
10. **Narrow screens:** groups stack; destinations wrap; manifest disclosure stays within viewport.
11. **Keyboard:** semantic dialog, ordered headings/lists, focus containment/restoration, native disclosure/actions.
12. **Unavailable capabilities:** W1 tracking is explicitly unsupported; Both is explained as repository ZIP only.
13. **Implementation concepts:** no IPC, hash, Blob, anchor, or lock language.
14. **Terminology:** Dry run, Tracking, Repository, Both, ZIP, project tracking, and generated artifact names match current domain/artifacts.
15. **Host consistency:** same hierarchy; desktop shows paths and W1 shows ZIP/manifest plus browser limitation.

### Decision B — Completion/partial/failure result

1. **Goal:** determine what happened and the safe next action.
2. **Required information:** outcome, actual destinations, completed/not-completed steps, error, recovery.
3. **Optional information:** diagnostics log and expanded produced-item list.
4. **Happy path:** result is announced, evidence inspected, user continues or deliberately reviews again.
5. **Failures:** validation, filesystem, copy, Git/GitHub, history, IDE, ZIP, or DOM request failure; browser may block/cancel afterward.
6. **Explanation:** name failed step in user language; retain bounded technical detail under diagnostics.
7. **Recovery:** form and attachments remain; inspect existing output before a fresh deliberate rerun.
8. **Success confirmation:** actual desktop paths or exact ZIP filename/manifest plus bounded download-request status.
9. **Accidental repetition:** one result per operation ID; normal Review action creates a legitimate new rerun.
10. **Narrow screens:** status groups stack and long paths wrap/copy only on deliberate user action.
11. **Keyboard:** live status, logical heading order, reachable disclosure, visible focus, restored action focus.
12. **Unavailable capabilities:** browser persistence is explicitly “not verified”; no tracking claim in W1.
13. **Implementation concepts:** step labels are product actions; operation IDs/fingerprints remain hidden.
14. **Terminology:** “completed,” “not completed,” “download requested,” and “versioned copy” match actual semantics; never “retry” for rerun.
15. **Host consistency:** shared outcomes/layout; evidence differs only where host capability differs.

### Decision C — Destination and ZIP evidence disclosure

1. **Goal:** locate and independently inspect the produced artifact.
2. **Required information:** exact desktop path(s), or ZIP filename and every archive entry.
3. **Optional information:** copied/generated categorization and diagnostic timestamps.
4. **Happy path:** user opens the named local location/download and checks contents.
5. **Failures:** path exists but contents are incomplete; ZIP request blocked/cancelled/renamed; sensitive path shared accidentally.
6. **Explanation:** app evidence is labelled as app-reported; browser limitation and inspection step are explicit.
7. **Recovery:** inspect partial output, correct cause, then make a deliberate version-safe rerun.
8. **Success confirmation:** Test Engineer inspects actual tree/ZIP; UI evidence alone is not final acceptance.
9. **Accidental repetition:** inspection does not trigger execution; rerun remains behind Review/Confirm.
10. **Narrow screens:** break paths at safe boundaries and place manifests in a single non-nested scroll/disclosure region.
11. **Keyboard:** evidence is text/list content; copy, if provided, is a labelled native button with feedback.
12. **Unavailable capabilities:** no “reveal in folder” or browser saved-location action is shown unless actually supported and separately authorized.
13. **Implementation concepts:** archive paths are product artifact names; local API details are absent.
14. **Terminology:** paths match real casing/names; ZIP entries match prompt/provenance resolved names.
15. **Host consistency:** both give inspectable names; only desktop can give final filesystem paths.

## Visual and UX acceptance

This Task makes no new brand palette, imagery, typography, or animation decision. Confirmation and result surfaces consume the approved semantic theme tokens. Neutral surfaces dominate long paths/manifests; accent is reserved for primary confirmation/focus. Success, warning/partial, danger/failure, and information/dry-run use icon + heading + text, never purple or color alone. Controls define default/hover/focus/disabled/busy states in dark and intentionally designed light themes. Text/status contrast meets WCAG expectations, focus is unmistakable, and a static status icon is preferred; any spinner respects `prefers-reduced-motion`.

At supported desktop/web sizes, 320px narrow width, and 200% zoom, destinations wrap without horizontal page scrolling, actions remain visible, and long manifests use one accessible disclosure rather than nested scrolling. Desktop and W1 use the same hierarchy and component language. No galactic working-surface imagery is added. Token mapping: existing approved `surface-*` for panels, `text-*` for evidence hierarchy, `border-*` for grouping, `information` for dry-run/requested, `success`, `warning`, `danger` for outcomes, and `focus-ring`/control tokens for actions. Thus applicable supplemental §30 criteria 1–9 and 11–16 are explicit; criterion 10 (six-participant dialog) is unaffected and remains owned by `TASK-UX-MODE1`.

Against supplemental §31, the design explains the action and desktop/W1 differences before execution; preserves input; relies on the dependency for duplicate prevention and legitimate rerun; carries approved attachment status/names into the manifest; evidences output; separates completed/not completed; supports keyboard/responsive use; hides internal identity/locking mechanisms; and never presents browser persistence or W1 tracking as available. Provider, paid budget, six-participant, long-task, numeric-limit, and Mode 1 save/cancel criteria remain with their owning Tasks and are not redefined here.

## Exact implementation order and file-level changes

1. `src/types.ts`: layer the preview, step, artifact, delivery, and outcome types onto the already approved `ExecutionRequest`/`operationId` migration; retain existing result fields.
2. `src/core.ts`: add pure host-aware `buildExecutionPreview` and shared deterministic generated-artifact projection; ensure tracking-only and W1 semantics match real execution. Do not put localized rendered result prose in the domain layer.
3. `src/webExport.ts`: expose/reuse the exact ordered `ExportEntry` manifest from the attachment design for preview, ZIP creation, and result evidence; do not add a second resolver.
4. `electron/main.ts`: within the idempotency-guarded worker, create/settle step records, capture every `writeVersioned`/`copyVersioned` return, derive outcome, echo operation ID, and return partial evidence on caught failure. Preserve execution order and never roll back.
5. `electron/files.ts`: no behavioral change expected; only adjust exported typings/helpers if needed to make already returned exact paths explicit. Do not weaken exclusive/versioned writes.
6. `src/bridge/web.ts`: inside the guarded worker, build once from the resolved manifest; return ZIP filename/manifest and bounded download-request evidence; catch ZIP/DOM failures; never claim persistence.
7. `src/bridge/electron.ts`, `electron/preload.ts`, and Electron execute smoke caller/harness: carry the approved request/result envelope atomically; no evidence reinterpretation in preload.
8. `src/App.tsx`: render preview and localized mode-specific confirm copy; keep dependency busy/idempotency behavior; replace bare result/event count with outcome, destination, Completed/Not completed, recovery, browser limitation, and optional diagnostics. Preserve form/attachments.
9. Existing semantic CSS files determined by `TASK-DESIGN-THEME`: add only layout/state selectors needed for preview/result; use approved tokens, no raw colors.
10. `tests/core.test.ts`: preview matrix for desktop tracking/repository/both, W1 repository/both/tracking rejection, dry-run, optional effects, orchestration, and attachments.
11. `tests/files.test.ts` and desktop execution tests/smoke fixtures: exact versioned returns, pre-existing roots, per-write failure injection, partial evidence, no deletion, dry-run no artifacts, and operation replay equality.
12. `tests/webExport.test.ts` and `tests/bridge.test.ts`: exact manifest including binary attachments, dry-run no build/request, ZIP/DOM failures, `download-requested` only, persistence always false, and same-operation one-result/one-request behavior.
13. Existing UI test location: EN/ES copy; all four preview effects; dry/success/partial/failure; path/manifest disclosure; screen-reader announcement; focus; narrow/zoom/theme states; banned certainty phrases.
14. `docs/SOP_DESKTOP.md`: document tracking/repository/both destinations, versioned names, partial-output inspection, and rerun behavior.
15. `docs/SOP_WEB.md`: document exact ZIP evidence, attachment manifest, download request versus browser save, blocked/cancelled troubleshooting, and W1 Both/tracking semantics.
16. Relevant troubleshooting/FAQ output section, `docs/PRIVACY_POLICY.md` only if it currently characterizes result-path retention, `CHANGE_CONTROL.md`, and maintained Project Map/bridge contract documentation: synchronize shipped schema/copy and clarify that result paths are in-memory and may be sensitive. Do not perform unrelated stale-document cleanup.

The implementation must complete the idempotency and attachment dependencies first, then apply this sequence atomically where TypeScript contracts require coupled compilation changes.

## Migration, compatibility, security, and architecture impact

- **Domain/schema:** additive `ExecutionResult` fields plus dependency-required `operationId`; pure preview types/functions. Existing fields remain during this increment. No `ProjectDefinition`, settings, draft, history, YAML, project signature, or AEKR change.
- **Migration:** internal bridge callers, preload, IPC, web bridge, smoke harness, and tests migrate atomically with `TASK-EXEC-IDEMPOTENCY`. No persisted-data migration. Old history remains readable and does not gain evidence records.
- **Security/privacy:** never execute user text in a shell; paths/attachment names are display data and React-escaped. Do not emit them into analytics (none exists), new persistent logs, operation fingerprints, or telemetry. Do not auto-copy paths. Advise redaction before screenshot sharing. W1 bytes remain local/transient per attachment design. No upload, browser filesystem access, auto-open, auto-push, secret storage, or paid dependency.
- **Failure safety:** retain exclusive/versioned writes, never delete completed output, never auto-retry, and never imply atomic rollback. Idempotency replay returns the same evidence for the same operation.
- **AEKR:** no upstream or consumed orchestration schema change; evidence concerns accreatio project launch/export only.
- **Dependencies:** no new package. Reuse current path/fs APIs, `client-zip`, shared generators, and approved semantic theme system.

## Verification matrix for the Implementer and Test Engineer

Automated focused/integrated checks must prove:

- all host/action/dry-run preview branches and exact expected artifacts;
- dry-run performs no mkdir/write/copy/Git/GitHub/history/IDE/ZIP/download side effect and never claims creation;
- each exact desktop versioned return appears once in artifacts and the correct step;
- injected failure after every durable boundary produces partial/failure correctly, lists later work skipped, preserves prior output, and does not retry;
- same `operationId` replay returns identical outcome/evidence and causes no duplicate artifact/download/history effect; fresh-ID rerun remains possible;
- W1 manifest exactly equals entries passed to ZIP, including resolved attachment names/order and byte fixtures; ZIP/DOM failure returns no requested-delivery success;
- W1 successful adapter call uses “download requested,” `browserPersistenceVerified:false`, and no saved/exported certainty;
- result/UI localization, keyboard status/focus, dark/light states, narrow widths, and 200% zoom behavior.

The independent Test Engineer later uses disposable locations and records, for each desktop action (tracking, repository, both) and a collision rerun: requested action/dry state, operation ID in test evidence only, UI destinations, recursive directory tree, exact generated filenames, opened content, attachment hashes against sources, tracking content, `.git`/remote/no-push facts where enabled, and comparison to result steps. Dry-run requires before/after tree snapshots and history comparison proving no artifact.

For W1 Repository and Both with and without the approved attachment set, the Test Engineer records the displayed filename/manifest, browser download UI outcome, locates the actual downloaded file manually, opens/unzips it, lists entries in order, compares generated text fixtures and binary attachment hashes, and verifies prompt/provenance names. A blocked/cancelled-download case must demonstrate that the app only reports a request and gives recovery guidance. The tester also injects or uses a controlled failure after a desktop durable write to verify partial reporting and preservation. UI screenshots cover desktop/W1, both themes, supported widths/320px/200% zoom, keyboard-only focus/reading order, and path redaction in shared evidence.

Passing unit tests, a toast, logs, `ExecutionResult`, `a.click()`, or existence of a directory alone is insufficient. Final acceptance requires the independent artifact inspections above plus the repository-required test, typecheck, build, packaged smoke, and functional passes at their authorized later stage. The current 41-test/typecheck baseline must remain preserved and expanded proportionately.

## Open questions and residual risks

No owner decision blocks implementation. The deliberate product decisions are: W1 `both` remains a repository ZIP only; browser disk persistence is never claimed; desktop exact paths are displayed in-memory; and completed work is never rolled back.

Residual risks for implementation/test are browser download policy/renaming/location, sensitive absolute paths in screenshots, GitHub partial external state, pre-existing repository contents, and environment differences from the owner’s machine. These are handled through bounded language, redaction guidance, versioned writes, explicit step evidence, and independent inspection—not by broadening scope.

## Task acceptance mapping

- Exact pre-confirmation effect: host-aware `ExecutionPreview` and confirmation matrix.
- Dry-run truth: explicit no-side-effect banner/result/recovery plus zero-effect tests.
- Desktop destination proof: actual helper-return paths, step/artifact ledger, independent tree/content/hash inspection.
- W1 ZIP proof: exact resolved manifest and download-request-only state, followed by independent unzip/byte inspection.
- Partial/failure truth: file-level accumulation, Completed/Not completed sections, no deletion, deliberate rerun guidance.
- W1 tracking/default safety: explicit unsupported state; dry-run default unchanged.

Ready for Orchestrator consistency review and the human design gate: **Yes**.
