# TASK-EXEC-IDEMPOTENCY — Duplicate-safe logical operations

Status: design complete; production implementation is gated. Owner: EXEC-02. This record follows the authoritative scope in `docs/archive/2026-09-05/design/TASK_BACKLOG.md` and does not redesign artifact-result messaging owned by `TASK-EXEC-EVIDENCE`.

## Decision summary

One logical execution is represented by an `ExecutionRequest` containing a fresh opaque `operationId`, the project definition, and settings. The UI creates the ID synchronously when Review/Export is activated and holds it through confirmation. A synchronous `useRef` gate closes before any state update or `await`; React rendering and modal unmounting are presentation only.

Both hosts independently enforce the operation. A shared, pure `LogicalOperationGuard` records operation IDs and a canonical request fingerprint before invoking side effects. A repeated ID returns the original promise/result. A different ID with an identical fingerprint is coalesced only while the first request is in flight. When it settles, its fingerprint lock is released, so a later explicit rerun with a fresh ID executes and uses existing deterministic versioning. Settled IDs remain in a bounded, session-memory replay cache so delayed delivery of the same logical operation cannot execute again. Nothing is persisted across process/page restart.

The fingerprint is SHA-256 over a length-delimited canonical JSON representation of `{definition, settings}` (object keys sorted recursively; array order retained; JSON scalar types only), computed in application code with Web Crypto in W1 and `node:crypto` in Electron. The guard installs an ID reservation synchronously before fingerprint computation and installs the fingerprint reservation before calling the mutation/download function. It never invokes a shell, never logs the canonical payload or digest, and rejects reuse of one ID with a different payload. The opaque ID is generated with `crypto.randomUUID()` and is safe to expose in diagnostics, but is not a secret.

This is in-process, session-scoped idempotency, deliberately not a distributed or crash-recovery protocol. It covers all calls reaching one running W1 page or Electron main process. A process crash can leave partial output; existing exclusive/versioned writes remain the recovery protection, and `TASK-EXEC-EVIDENCE` owns better partial-result feedback.

## Contract and state model

Add to `src/types.ts`:

```ts
export interface ExecutionRequest {
  operationId: string; // UUID generated at the initiating UI boundary
  definition: ProjectDefinition;
  settings: Settings;
}

export interface ExecutionResult {
  operationId: string;
  // existing fields unchanged
}
```

Change `Bridge.execute` and `accreatioApi.execute` to accept exactly one `ExecutionRequest`. Do not make `operationId` optional: all callers must migrate atomically and TypeScript must expose any missed call site. Validate at each host boundary that the request is a plain object, `operationId` is a canonical UUID string, and definition/settings are objects; existing domain validation remains authoritative for their contents. Every normal, dry-run, validation-failure, and caught-failure result echoes the operation ID. A malformed envelope rejects before guard admission or side effects.

The guard has these observable states:

```text
new ID -> reserved/fingerprinting -> in flight -> settled cached
                  |                     |
same ID + same payload -----------------+--> same promise/result
same ID + different payload ----------------> reject protocol misuse
new ID + same in-flight fingerprint --------> same promise/result
new ID + same settled fingerprint ----------> new execution (intentional rerun)
```

The guard API is a pure coordinator accepting injected `fingerprint(request)` and `run(request)` functions. Its maps are updated before yielding to either asynchronous function. The settled replay cache stores both successes and failures, is capped at 128 IDs using insertion-order eviction, and lives only for the host session. Eviction affects only very late/reused IDs, never the in-flight map. In-flight entries are removed in `finally`; ID reservations become settled results in the same completion path. Synchronous throws and rejected promises become the same settled failure for all coalesced callers and release the fingerprint lock. The implementation must not offer automatic retry.

`operationId` identifies intent; the fingerprint is concurrency control, not durable identity. Exclude no execution-affecting fields: canonicalize the complete current `ProjectDefinition` and `Settings` passed to execution. Desktop attachment metadata includes local paths and is therefore sensitive; only the digest is retained transiently, and neither payload nor digest is written to logs/history. When W1 binary attachments land in the separate attachment Task, its design must extend canonicalization with content identity rather than attempting to stringify `Blob`; until then this Task validates the current schema only.

## Boundary design

### UI boundary (`src/App.tsx`)

Add `useRef` and two refs: `reviewGateRef` and `executionGateRef`; add `pendingOperationId` state for rendering. The initial action handler performs a synchronous check-and-set on `reviewGateRef`, creates a UUID, stores it in the ref/state, and opens confirmation. A second mouse or keyboard activation in the same render frame returns immediately. Cancel/close clears the pending identity and review gate.

The confirmation handler synchronously checks and sets `executionGateRef` before changing state or calling the bridge. It snapshots the displayed definition/settings into the `ExecutionRequest`; it does not read later edited state. Keep the modal mounted while awaiting. Set `running`, clear the prior result, disable initial action, Close, Cancel, and Confirm, apply `aria-busy="true"` to the dialog, and change Confirm copy to “Exporting…”/“Executing…” (and Spanish equivalents) with the existing icon/control system. Ignore Enter/Space repeats because the native disabled button plus the ref gate both block them; Escape must not dismiss while running. Focus stays on the disabled confirmation control or moves to a non-interactive status node announced with `role="status"`; on settlement, close the modal and restore focus to the initial action.

In `finally`, clear both refs, pending identity, and `running` on success, returned failure, or thrown bridge error. The next deliberate activation creates a new UUID. The form definition and settings remain unchanged. Do not add an always-visible “rerun” button in this Task: returning to the normal Review/Export action is the explicit user action and avoids implying automatic retry.

The modal needs `role="dialog"`, `aria-modal="true"`, an `aria-labelledby` reference, and an in-flight status announcement. If the existing modal lacks focus trapping/restoration, implement the minimum scoped focus containment/restoration needed for this execution modal; do not redesign the general dialog system. Styling must consume the approved `TASK-DESIGN-THEME` semantic disabled/focus/status tokens, with no new raw palette.

### Electron renderer, preload, and privileged IPC

`src/bridge/electron.ts` forwards the one request envelope unchanged. `electron/preload.ts` exposes `execute(request)` and invokes `project:execute` with one value, narrowing the writable IPC surface.

In `electron/main.ts`, construct one process-lifetime guard inside `app.whenReady()` and wrap the `project:execute` handler with it. Boundary validation happens before admission. Fingerprinting and the guard run in the main process; renderer correctness is not trusted. Move/rename the current mutation function to an injected guarded worker accepting the validated request and always echoing its ID. The IPC event sender is not part of the fingerprint: two windows/callers targeting the same operation must not bypass coalescing. Conversely, the operation-ID replay key should be scoped to this application process, because UUID collision/reuse with different payload is rejected.

The fingerprint lock must cover validation, directory/file work, Git/GitHub/IDE effects, and history insertion as one in-flight interval. Do not put a narrower lock in `electron/files.ts`: that would still allow duplicated history and external effects. `writeVersioned`/`copyVersioned` remain unchanged and continue to supply atomic `wx`/`COPYFILE_EXCL` collision handling for intentional reruns and unrelated concurrent writes.

The current history read-modify-write is safe for coalesced identical requests but can still lose entries for distinct concurrently executing projects. That broader history-serialization defect is category D, outside this Task; record it for Orchestrator backlog rather than silently adding a global execution mutex. GitHub creation can fail after local writes; replaying the same ID returns that failure rather than re-running partial work. A new intentional run may create versioned local files and retry later effects, which is existing deterministic behavior and must be explained in troubleshooting.

### W1 bridge boundary

`src/bridge/web.ts` owns a module-lifetime guard independent of the component. Its guarded worker performs validation, ZIP construction, and exactly one `triggerDownload`. Reserve the operation synchronously on entry, before validation or dynamic `client-zip` import. Thus direct concurrent `webBridge.execute` calls with the same ID, or different IDs with the same simultaneous request fingerprint, share one promise and one anchor click. Validation and ZIP failures are cached for their IDs and release the fingerprint lock.

Refactor download triggering behind an injectable/internal adapter or export a test-only factory (`createWebExecutionBridge({ download, fingerprint })`) while `webBridge` uses the real DOM adapter. This makes one-download assertions possible under the existing Node test runner without adding jsdom or a dependency. Do not infer browser acceptance of the download from `a.click()`; that result-evidence distinction remains for `TASK-EXEC-EVIDENCE`.

## Failure, cancellation, and rerun semantics

- “Cancel” before execution discards the unused operation ID; no host call exists to cache.
- Once confirmed, UI cancellation is disabled. This Task does not claim to cancel filesystem/Git/download work.
- A returned `{ok:false}` or thrown error settles and caches that ID, releases the equivalent-payload in-flight lock, restores controls, preserves input, and shows the existing result/error path.
- Repeated delivery of that ID returns the same failure and never retries possibly partial work.
- The user reviews and confirms again to intentionally rerun. This creates a fresh ID; because no fingerprint is in flight, the host executes it. Desktop creates normal versioned copies; W1 starts a fresh download.
- Dry-runs use the same guard. Concurrent duplicates produce one logical result (and no mutation); a later fresh-ID dry-run is allowed.
- Distinct simultaneous payload fingerprints execute independently. Canonical equality avoids object key-order differences; array order remains meaningful.
- Reload/restart clears memory and therefore clears replay history. Persistent suppression is explicitly out of scope and undesirable.

## UX decision record (supplemental §6)

1. **Goal:** safely review and initiate one desktop execution or W1 ZIP export.
2. **Required information:** current definition, settings, host/action/dry-run summary, and confirmation.
3. **Optional information:** none added; the operation ID and fingerprint remain internal.
4. **Happy path:** Review opens once, Confirm becomes busy once, one result returns, controls restore, and a later review can intentionally rerun.
5. **Failures:** invalid envelope/definition, ZIP/filesystem/Git/GitHub/IDE/history errors, bridge rejection, or page/process loss.
6. **Explanation:** retain existing localized result/error presentation; announce in-flight status and never label failure as success. Rich partial-output copy belongs to the next Task.
7. **Recovery:** definition/settings remain; after settlement the user can correct inputs or explicitly review and run again.
8. **Success confirmation:** the existing result is tied to the echoed operation ID internally; destination/ZIP proof is deferred to `TASK-EXEC-EVIDENCE`.
9. **Accidental repetition:** synchronous UI refs, disabled modal controls, operation-ID replay, and host fingerprint coalescing.
10. **Narrow screens:** modal remains within the viewport, actions wrap/stack without hiding busy status, and no horizontal scroll is introduced.
11. **Keyboard:** native buttons, dialog semantics, focus containment/restoration, disabled repeat activation, announced busy state, and Escape ignored only in flight.
12. **Unavailable capabilities:** existing host-specific labels remain; no new capability is claimed.
13. **Implementation concepts:** IDs, hashes, locks, and IPC are not exposed in normal UI.
14. **Terminology:** retain Review, Confirm execution/export, dry run, and desktop/W1 action names; do not call failure recovery an automatic retry.
15. **Host consistency:** desktop and W1 share the same confirmation/busy/recovery interaction; only the already-declared artifact differs.

## Visual and UX acceptance

This Task introduces no palette, logo, imagery, animation, typography, or general layout decision. Its visual decision is limited to execution-control state. The busy control uses the theme Task's semantic control background, disabled text/border, focus ring, and information/status tokens. Disabled and selected states remain distinguishable by more than purple; text/icon plus disabled behavior communicate state. Contrast must meet WCAG expectations in both themes, focus must remain unmistakable, and no spinner may ignore `prefers-reduced-motion` (static icon/text is preferred). At supported desktop/web widths and 200% zoom, the dialog status and both actions remain visible without nested scrolling. Desktop and W1 use the same component treatment. This satisfies the applicable supplemental §30 criteria; criteria concerning six-participant forms, long working forms, and brand imagery are unaffected rather than redefined.

Against supplemental §31: the action and host difference remain visible before execution; duplicate action prevention and legitimate rerun are explicit; failure unlocks without losing input; keyboard and responsive behavior are required; no unsupported capability or internal locking terminology is exposed. Artifact destination proof, partial-completion detail, attachments, provider/funding, participant layout, and numeric-limit criteria remain owned by their authoritative Tasks.

## Migration, compatibility, and security impact

This is an internal bridge-contract breaking change with an atomic migration: update shared UI types, both bridges, preload, IPC handler, smoke harness, and tests in one implementation Task. There is no persisted project, draft, settings, history, YAML, or AEKR schema migration. Existing history rows do not gain operation IDs in this Task because history is not used as the idempotency store and writing IDs would broaden its public/data contract. No AEKR upstream change is needed.

Security boundaries improve: malformed IPC envelopes are rejected; renderer calls cannot bypass the main-process guard; W1 callers cannot bypass the module boundary; canonicalization is pure data processing; no user text reaches a command for hashing/locking; no raw request or digest is logged/persisted. Cap canonical serialization at the already validated project/attachment limits and fail closed on unsupported values, cycles, `undefined`, functions, symbols, non-finite numbers, or future `Blob` values. Hashing does not authorize a request and must not replace normal domain/path validation. The cache is bounded to prevent unbounded memory growth.

## Exact implementation sequence and file-level plan

1. Add `ExecutionRequest`, echoed result identity, and one-argument execute signatures in `src/types.ts`.
2. Add `src/operationGuard.ts`: canonical JSON, browser SHA-256 adapter, request-envelope validation usable in W1, and the generic bounded guard. Add `electron/operationFingerprint.ts` only for the Node SHA-256 adapter if conditional imports cannot keep browser bundles clean.
3. Add `tests/operationGuard.test.ts` for synchronous reservation, same-ID replay, different-ID/same-fingerprint in-flight coalescing, payload mismatch, success/failure release, bounded eviction, canonical ordering, and no payload logging.
4. Refactor `src/bridge/web.ts` to accept `ExecutionRequest`, install the module guard, isolate injectable download behavior, and echo IDs. Extend `tests/bridge.test.ts` with deferred-promise/concurrent calls and an injected download spy.
5. Update `src/bridge/electron.ts` and `electron/preload.ts` to forward one envelope.
6. Refactor `electron/main.ts` so all privileged execution passes through one validated main-process guard; leave `electron/files.ts` behavior intact.
7. Extend the existing Electron smoke path in `electron/main.ts` and `scripts/electron-execute-smoke.mjs` to issue concurrent calls and inspect one artifact set and one history row, using its isolated `accreatio-execute-*` temp root. Do not introduce a second unguarded test-only execution path.
8. Update `src/App.tsx` last, after contracts/guards are stable: synchronous refs, request snapshot/ID, mounted busy modal, disabled/keyboard/focus behavior, and unconditional cleanup.
9. Add or extend `scripts/web-functional-smoke.mjs` for rapid mouse/keyboard confirmation and one browser download, and update execution/troubleshooting, bridge/Project Map, security/risk, and `CHANGE_CONTROL.md` documentation required by the backlog. These documentation changes occur during implementation, not this design-only pass.

No production change is planned for `electron/files.ts`; it receives concurrency regression tests in `tests/files.test.ts` proving two intentional writes still create base and `(1)` files. No dependency is required.

## Verification plan

Focused commands during implementation:

```text
node --import tsx --test tests/operationGuard.test.ts
node --import tsx --test tests/bridge.test.ts tests/files.test.ts
npm run typecheck
npm test
```

Concurrency tests must use deferred promises/barriers, never timing sleeps. The pure guard test calls `guard.run()` multiple times without awaiting, asserts the worker call count is one before resolving the deferred worker, then awaits all promises and asserts identical results. Repeat with two different IDs but canonically equal payloads. Resolve/reject the barrier, call with a fresh ID, and assert the worker count increments. Reuse an old ID and assert it does not. Reuse an ID with changed payload and assert rejection.

The W1 Node test uses the bridge factory with a download spy and controllable ZIP/download worker, launches concurrent calls, releases the barrier, and asserts one download. This fits `npm test` (`node --import tsx --test tests/*.test.ts`) and needs no DOM library. The Electron smoke harness launches at least two `window.accreatio.execute(request)` calls via `Promise.all` before either completes; a test-only barrier immediately inside the guarded worker may be enabled only by the existing validated smoke flag. It then inspects the isolated project for exactly one unversioned prompt/governance set, absence of `(1)` duplicates, and exactly one matching history entry in the smoke-isolated user data. A second call with a fresh ID after settlement must create `(1)` versions and a second history entry. The harness must also test same-ID failure replay without mutation and a fresh-ID recovery.

After implementation, the independent Test Engineer may run the previously prohibited functional commands: `npm run test:electron` and `npm run test:web`, plus a manual Playwright/real-browser keyboard and mouse stress pass. Required observations are one desktop mutation/history event, one W1 download, visible busy/disabled states, no Escape/Enter repeat while busy, focus restoration, failure unlock, and a deliberate second run producing versioned desktop files/a second W1 download. Full `npm run verify` remains the final regression gate; `package:win` is only run at the separately authorized packaging stage.

## Design Sprints and MSS record

### Sprint 1 — Existing-guard discovery

Objective: establish actual reentrancy and test seams. Entry: mandate/backlog read. Included: requested execution files and current tests; excluded: implementation.

- **MSS 1.1:** Reconfirmed EXEC-02; inspected `App.tsx`; artifact: current UI state trace. Validation: compared against backlog and reproduction report. Result: `running` disables only the initial action and is React-timing-dependent; modal Confirm has no guard. Complete; no deviation.
- **MSS 1.2:** Reconfirmed host-boundary discovery; inspected types, Electron bridge/preload/main, and versioned writes; artifact: boundary trace. Validation: followed IPC to all filesystem/history/external effects. Result: every invocation executes; exclusive writes prevent overwrite but intentionally produce duplicates, and history repeats. Complete; newly found distinct-request history lost-update risk is out of scope.
- **MSS 1.3:** Reconfirmed W1/test discovery; inspected web bridge, tests, scripts, and package commands; artifact: runnable test-seam inventory. Validation: checked against the Node test harness. Result: each call triggers independently and DOM download is not injectable; pure guard plus factory and existing smoke hooks make deterministic tests feasible. Complete; no deviation.

Sprint 1 consolidation: EXEC-02 is confirmed at UI, Electron, and W1. File-level atomic writes are not logical-operation protection. Existing unit tests are Node-native; Electron and web functional smoke scripts are the correct later host evidence. Ready for Sprint 2: Yes.

### Sprint 2 — Operation identity and UI-boundary design

Objective: define identity, synchronous initiation, and UX. Entry: Sprint 1 consolidated. Included: contracts/UI; excluded: host implementation.

- **MSS 2.1:** Reconfirmed one-operation identity; inspected current schema; artifact: `ExecutionRequest` and canonical fingerprint rules. Validation: tested semantics against simultaneous duplicates, replay, and rerun criteria. Result: opaque ID plus in-flight payload fingerprint is required; either alone is insufficient. Complete; no deviation.
- **MSS 2.2:** Reconfirmed synchronous UI protection; inspected state/modal lifecycle; artifact: ref/state flow and snapshot rule. Validation: walked double mouse activation, Enter/Space repeat, cancel, success, and throw. Result: refs close before state/await and cleanup is unconditional. Complete; no deviation.
- **MSS 2.3:** Reconfirmed UX/visual requirements; artifact: §6 answers and §§30–31 mapping. Validation: checked both locales/hosts, narrow/200% zoom, focus, disabled, busy, and reduced motion. Result: mounted busy dialog, semantic tokens, announcement, and focus restoration specified. Complete; dependency on theme tokens retained.

Sprint 2 consolidation: identity is invisible, request-scoped, synchronous at initiation, and compatible with explicit fresh-ID reruns. UX is part of the state machine rather than styling layered later. Ready for Sprint 3: Yes.

### Sprint 3 — Host/IPC and W1 boundary guards

Objective: independently enforce at both side-effect boundaries. Entry: Sprint 2 consolidated. Included: guard, IPC, W1, files/history implications; excluded: distributed persistence/global serialization.

- **MSS 3.1:** Reconfirmed privileged enforcement; inspected main handler/full worker; artifact: main-process guard placement. Validation: ensured lock spans validation through history/external effects. Result: one process guard around the complete worker; renderer is untrusted. Complete; no deviation.
- **MSS 3.2:** Reconfirmed W1 enforcement; inspected dynamic ZIP/download path; artifact: module guard and injectable download seam. Validation: traced concurrent calls to anchor click. Result: one guarded worker owns the sole download side effect. Complete; no deviation.
- **MSS 3.3:** Reconfirmed deterministic writes; inspected `files.ts` and history flow; artifact: boundary/non-goal decision. Validation: compared intentional rerun and distinct concurrency. Result: keep atomic versioned files; do not substitute file locks or add a global mutex. Complete; distinct-request history serialization is recorded for backlog.

Sprint 3 consolidation: each host rejects/coalesces duplicates without trusting UI. The fingerprint lock is in-flight only; ID replay cache is bounded/session-only. It covers download/mutation/history as one operation. Ready for Sprint 4: Yes.

### Sprint 4 — Failure and rerun semantics

Objective: ensure recovery without ambiguous retries or permanent suppression. Entry: host design consolidated. Included: settle/cache/cleanup; excluded: automatic retry and rich partial-result redesign.

- **MSS 4.1:** Reconfirmed failure recovery; artifact: failure state transitions. Validation: walked validation failure, synchronous throw, rejected promise, returned failure, and partial host mutation. Result: cache same-ID outcome, release fingerprint in `finally`, restore UI, preserve inputs. Complete; no deviation.
- **MSS 4.2:** Reconfirmed legitimate rerun; artifact: fresh-ID contract. Validation: compared same-ID replay with new-ID post-settlement execution. Result: normal review creates new intent and preserves versioned writes/download behavior. Complete; no deviation.
- **MSS 4.3:** Reconfirmed restart/security limits; artifact: session/cache/security statement. Validation: checked DEC-002, privacy, bounded memory, and crash semantics. Result: no shell, logs, persistence, or distributed claims. Complete; W1 future Blob fingerprinting is a dependency note for its owning Task.

Sprint 4 consolidation: failures unlock cleanly but are never automatically replayed; explicit reruns remain possible. Crash recovery is honestly out of scope. Ready for Sprint 5: Yes.

### Sprint 5 — Verification and delivery design

Objective: give the Implementer a decision-free sequence and executable evidence plan. Entry: all behavior consolidated. Included: exact files/tests/docs/order; excluded: running prohibited functional tests now.

- **MSS 5.1:** Reconfirmed concurrency evidence; inspected test scripts/harness; artifact: barrier-based unit/integration plan. Validation: mapped every backlog evidence item to an existing command or bounded harness extension. Result: concurrency can run deterministically in `npm test`, with host evidence in existing smoke commands. Complete; no deviation.
- **MSS 5.2:** Reconfirmed migration/security/test impact; artifact: exact implementation order and documentation list. Validation: checked current TypeScript bridge schema and master boundaries. Result: atomic internal contract migration, no persisted/AEKR migration, no dependency. Complete; no deviation.
- **MSS 5.3:** Reconfirmed design-gate completeness; artifact: this record. Validation: checked objective, scope, non-goals, dependencies, all acceptance criteria, §6, §30, §31, and required evidence. Result: implementation-ready. Complete; no deviation.

Sprint 5 consolidation: all requested boundaries, UX, domain/schema, migration, security, files, ordering, and test execution are explicit. No production code or out-of-path file was changed. Ready for design-gate packaging: Yes.

## Risks and open questions

- **Orchestrator backlog (not blocking):** distinct concurrent Electron operations can race the current history read-modify-write and lose an entry. This Task prevents duplicate identical operations but must not silently widen into global history transaction design.
- **Cross-Task coordination (not blocking):** `TASK-WEB-ATTACHMENTS` must define binary-content identity before W1 `Blob` values enter this fingerprint contract.
- **Test isolation detail (Implementer must verify):** the Electron smoke process must use isolated `userData` so history-count assertions cannot touch the user's normal history. If the current script does not already redirect it, add that only within the smoke harness.
- **No owner decision required:** cache size 128 and session-only lifetime are implementation parameters consistent with bounded duplicate protection and non-permanent suppression; the Orchestrator may revise them at design review if a documented operational constraint exists.

