# Reproduction Report

Scope: static reproduction of the eleven owner-mandated issues against accreatio 0.7.0. This report follows `AGENTS.md`, current code/tests, accreatio's consumed AEKR contract, and then current control/decision documents. It does not inspect or make claims about the independent upstream AEKR implementation beyond the contract accreatio emits and consumes. No live browser, packaged Electron, or provider execution was run in this step.

### UX-01 — Mode 1 configuration layout

**Status:** Partially confirmed

**Evidence:** `electron/main.ts:469-475` creates a 1480×940 desktop window with a 1080 px minimum width; `src/responsive.css:14-20` gives the desktop main form a two-column page layout and each field a label/control grid; `src/responsive.css:87-101` keeps that two-column page and narrows the form at 1001–1250 px; `src/responsive.css:103-147` does not switch to the materially roomier single-column/stacked Mode 1 layout until 1000 px, below Electron's allowed minimum width. Within the control, `src/extras.css:165-182` requires three columns with minima of 140 px, 150 px, and 220 px plus gaps, and gives each task textarea only a 72 px minimum height. `src/responsive.css:142-147` stacks the textarea only under 1000 px. `src/styles.css:223-225` and `src/extras.css:179-182` make textareas vertically resizable but otherwise leave their normal overflow behavior.

**Root cause:** At every reachable desktop window width, each role is forced into one horizontal row inside the already-narrow third column of the outer field grid. The role row's explicit minimum widths total 528 px including gaps, while the outer page continues reserving space for the preview column, icon, and field label. At narrower desktop widths this can overflow horizontally or compress the surrounding layout. Long deterministic task text starts in a 72 px-high textarea, so the native textarea scrolls internally until manually resized; this is the reported vertical compression/readability problem. In web, widths above 1000 px use the same defective structure. At 1000 px and below the page becomes one column and the task textarea spans a second row, and at 720 px the outer field also stacks, so the defect is reduced rather than universal.

**Notes:** Static CSS confirms the structural overflow risk, narrow default task editor, and internal textarea scrolling for long content. It does not prove pixel-level clipping, scrollbar appearance (browser/OS dependent), or the perceived severity at particular zoom/font settings. Desktop at 1080, 1250, and 1480 px and W1 at approximately 1024, 1280, and 1440 px need a real Test Engineer visual/keyboard pass. Confidence: high for layout mechanics, medium for exact rendered symptoms.

### UX-02 — Session duration and retry/failure limits

**Status:** Partially confirmed

**Evidence:** `shared/domain.ts:46-61` defines four limits and defaults: 1800 seconds, 1 iteration per entity, 4 provider invocations, and 1 consecutive failure. `shared/domain.ts:173-180` validates respective ranges of 60–7200 seconds, 1–10, 1–100, and 1–10. `src/App.tsx:919-945` exposes session duration as an editable number in minutes (1–120), converts it to seconds, and clamps every change. `src/App.tsx:946-968` exposes `maxConsecutiveFailures` but labels it “Max retries,” also clamping every change. No UI control exists for `maxIterationsPerEntity` or `maxProviderInvocations`. `shared/domain.ts:310-342` emits all four values to AEKR's `session.max_duration_seconds` and `budget` keys. `CHANGE_CONTROL.md:5-10` records the tightened defaults.

**Root cause:** Maximum duration is present and editable in current code, so a blanket claim that it cannot be edited is not confirmed. However, its controlled input immediately maps an empty/intermediate value to 1 (`Number(value) || 1`) and clamps on each keystroke; clearing then typing a replacement is awkward and can produce an apparent refusal unless the existing value is selected/replaced or steppers are used. “Max retries” is semantically inaccurate: it edits the threshold of consecutive provider failures, not a count of automatic retries, and current change control explicitly says there is no automatic retry (`CHANGE_CONTROL.md:7-10`). The other two schema limits are entirely hidden from the UI.

**Notes:** Current contract semantics are: `sessionMaxDurationSeconds`, wall-clock session ceiling; `maxIterationsPerEntity`, maximum iterations allowed for one governed entity/work item; `maxProviderInvocations`, aggregate provider-call ceiling within the applicable budget scope; `maxConsecutiveFailures`, failure streak that stops/blocks progress, not promised retry attempts. The emitted Claude adapter also has a separate fixed per-call `max_budget_usd` discussed under EXT-02. A live input-interaction pass should confirm keyboard editing behavior across Chromium number-input implementations. Confidence: high.

### UX-03 — Light-theme control contrast

**Status:** Confirmed

**Evidence:** Header language/theme icon buttons are rendered at `src/App.tsx:473-500`. Their container/button styles use dark-only literals at `src/styles.css:112-125` (`background: #11171f`) and receive no light-theme override in the light block at `src/styles.css:673-700`. The global button color is inherited (`src/styles.css:33-35`), so in light mode the icons inherit dark text while sitting on a nearly black background. There is no `.theme button:hover`, selected, or disabled rule anywhere; the controls have no selected/disabled state in `src/App.tsx:473-500`. Keyboard focus uses the global cream outline at `src/styles.css:234-240`. Settings-page language/theme selects are at `src/App.tsx:1866-1887`; their base background is `var(--input)` and border `#303a47` at `src/styles.css:211-221`, while light mode changes text color but not that literal border at `src/styles.css:693-697`.

**Root cause:** The light theme changes page variables and form text but does not theme the header control surfaces or define their interactive states. Thus the language/theme buttons remain visually dark by construction. Hover has no visual response; there is no selected state communicating current locale/theme; focus is visible but the cream ring is tuned to the dark palette and has weak differentiation from the light header; disabled styling is absent (and these two controls are never disabled). The Settings selects are more legible because `--input` becomes light and text is overridden dark, but they retain a dark-theme literal border and have no distinct hover/disabled theme treatment.

**Notes:** The report is accurate for default and focus styling and for the absence of hover/selected/disabled definitions. A live accessibility pass should measure actual contrast and native select/disabled rendering, which varies by browser/OS. Confidence: high from CSS, with numerical contrast pending live/computed-style testing.

### UX-04 — About branding

**Status:** Partially confirmed

**Evidence:** The About page leads with the mark and `<h1>accreatio</h1>` at `src/App.tsx:1961-1973`, followed by product security/documents sections at `src/App.tsx:1974-2000`. Its final prominent Copyright section names “© 2026 Ed Lopez” and personal-use licensing at `src/App.tsx:2001-2007`. The accepted product identity is lowercase accreatio in `DECISIONS.md:20-28`; `package.json:2-5` separately records package author Ed Lopez.

**Root cause:** Personal authorship is not the primary heading—the current page already presents accreatio first—but the only explicit identity in the closing branding/legal block is the individual owner, with no product-centered copyright/licensor phrasing. That makes the About page end on personal authorship rather than reinforce the product identity requested by the owner.

**Notes:** The verbatim issue overstates current heading order, so it is only partially confirmed. Whether the copyright holder must remain a person is a legal/ownership question; this report makes no replacement recommendation. Confidence: high.

### WEB-01 — Browser attachments

**Status:** Confirmed

**Evidence:** W1 resets attachments to an empty array in its initial definition and draft restoration at `src/App.tsx:209-215` and `src/App.tsx:270-280`. For non-Idea phases, the web branch renders only a desktop-only capability note, not a file input, at `src/App.tsx:571-594`. The web bridge rejects attachment selection at `src/bridge/web.ts:93-102`. ZIP construction includes only generated text files at `src/webExport.ts:31-58`; no attachment bytes are accepted or copied. The current SOP describes attachments as not yet supported at `docs/SOP_WEB.md:37-49`.

**Root cause:** This is an explicit host-capability exclusion, not a failing picker: web state normalization discards attachments, the UI withholds the control, the bridge rejects selection, the attachment type requires a desktop filesystem `path`, and the ZIP builder has no binary attachment inputs. Consequently W1 cannot attach discovery sources today, even locally.

**Notes:** The prior behavior was intentional and honestly labeled, but it does not meet the newly approved local-only attachment target. Incidentally, `docs/PRIVACY_POLICY.md:21` says web attachments live in IndexedDB even though current W1 has no attachment path and deliberately strips them; that documentation is ahead of implementation. Confidence: high.

### WEB-02 — Mode 1 overflow in web

**Status:** Partially confirmed

**Evidence:** W1 renders the same `App` and same Mode 1 markup at `src/App.tsx:754-977`; host branching only disables provider detection at `src/App.tsx:797-815`. The common three-column role layout and 72 px task editor are defined at `src/extras.css:160-182`. Web viewports above 1000 px retain the two-column page and horizontal role row (`src/responsive.css:87-102`); at 1000 px and below the page and task editor stack (`src/responsive.css:103-147`), with further compact reflow below 720 px (`src/responsive.css:149-213`).

**Root cause:** WEB-02 shares UX-01's common CSS cause at laptop/desktop browser widths. It is mitigated at narrower responsive breakpoints, so “the same defect occurs in W1” is true for relevant wide/near-breakpoint viewports but not every web viewport.

**Notes:** Requires a live W1 visual pass at the breakpoint boundaries and common browser zoom levels to confirm exact overflow/clipping. Confidence: high for shared mechanics, medium for pixels.

### EXEC-01 — Artifact creation confidence

**Status:** Partially confirmed

**Evidence:** Both hosts default to dry-run (`src/App.tsx:192-207`); desktop dry-run returns before any write at `electron/main.ts:197-218`, and web dry-run returns before ZIP construction/download at `src/bridge/web.ts:30-50`. In a real desktop run, repository/both creates directories and versioned `PROJECT_PROMPT.md`, discovery, `AGENTS.md`, attachments, provenance, and optional orchestration config at `electron/main.ts:219-268`; repository-only bypasses tracking at `electron/main.ts:304-313`. Tracking/both independently creates a versioned `PROJECT_STATUS.md` under `futureProjectsPath` at `electron/main.ts:203-205` and `electron/main.ts:304-313`; tracking-only bypasses repository creation at `electron/main.ts:220`. Non-dry executions append local history at `electron/main.ts:314-329`. Atomic versioned writes/copies are implemented at `electron/files.ts:5-42` and exercised at `tests/files.test.ts:8-29`. In W1, non-dry execute builds files, creates a ZIP Blob, and triggers an anchor download at `src/bridge/web.ts:51-78`; its contents are prompt, discovery, governance, provenance, setup, and optional Mode 1 YAML at `src/webExport.ts:31-58`, with coverage at `tests/webExport.test.ts:108-165`.

**Root cause:** The unqualified “did not create/save anything” observation is consistent with leaving the default dry-run enabled: review succeeds but intentionally produces no filesystem artifact or download. Static traces do not support a general absence of implementation for real runs. Desktop repository and tracking are separate conditional branches; each writes when selected and configured. W1's actual artifact is a browser download, which can additionally appear absent if browser download permission/policy blocks the synthetic anchor (`docs/SOP_WEB.md:51-73`).

**Notes:** This step did not execute the prohibited Electron/web functional tests, so successful end-to-end writes/downloads are not freshly established here. The repository contains unit/integration evidence for file composition/versioning and an existing IPC smoke hook, but the owner's actual environment and selections remain unknown. Classifying the issue as partially confirmed reflects a real confidence/feedback problem and an expected dry-run explanation, not a confirmed write-path failure. Confidence: high for code paths, low for the owner's specific runtime event without live reproduction.

### EXEC-02 — Duplicate review/export execution

**Status:** Confirmed

**Evidence:** The initial Review/Export button disables for `running` at `src/App.tsx:1106-1129`. The confirmation modal's execute button has no `disabled` prop or in-flight guard at `src/App.tsx:1255-1305`. `execute` closes the modal and sets React state before awaiting the bridge, but has no synchronous ref/mutex/idempotency key at `src/App.tsx:411-434`. Electron forwards every invocation through IPC (`electron/preload.ts:10-11`, `electron/main.ts:596`) and `execute` has no per-project/in-flight lock (`electron/main.ts:197-348`). Repeated desktop runs deliberately create versioned duplicates (`electron/files.ts:5-42`) and separate history entries (`electron/main.ts:314-329`). Each web invocation independently generates and clicks a download anchor (`src/bridge/web.ts:21-27`, `src/bridge/web.ts:68-78`).

**Root cause:** `running` protects only the form's first-stage review button after React commits state. It does not disable the modal confirmation control, synchronously reject re-entry, serialize IPC, or identify a logical run. A very rapid second activation before modal unmount can dispatch another call; repeated confirmation after the UI returns can certainly dispatch again. Desktop safely avoids overwrites but still creates duplicate versioned artifacts/history (and could race optional Git/GitHub actions); web starts duplicate ZIP downloads. There is no idempotency contract in either host.

**Notes:** React will normally unmount the modal promptly after the first click, reducing the rapid-double-click window, but that is timing mitigation rather than a guard. This static reproduction confirms duplicate potential; a live stress test is needed to quantify the rapid-click race. Confidence: high.

### EXT-01 — Provider extensibility

**Status:** Confirmed

**Evidence:** The provider union is closed to `claude_code | codex` at `shared/domain.ts:40-45`; availability is a fixed object with those two required keys at `shared/domain.ts:73-81`. New Mode 1 roles default to Claude Code at `src/App.tsx:299-309` and `src/App.tsx:769-784`; the selector hard-codes exactly two options at `src/App.tsx:817-889`. Desktop eligibility checks invoke fixed local CLI/status commands at `electron/main.ts:103-178`: Claude must report logged in with `authMethod === "claude.ai"`, and Codex must report ChatGPT login; API-key Codex is explicitly rejected. W1 cannot detect local CLIs and reports both unavailable at `src/bridge/web.ts:81-90`. YAML generation maps each role to its chosen `kind`; Codex receives role-based sandbox settings and Claude receives a fixed USD call budget at `shared/domain.ts:324-333`.

**Root cause:** Provider discovery, types, UI, health/auth eligibility, and YAML adapter-specific emission are all closed switches rather than a registry/descriptor model. “Available” currently means a recognized CLI is installed and authenticated through the allowed subscription login mode, not merely that an adapter name can be selected; the selector itself does not prevent choosing a provider that failed detection.

**Notes:** AEKR is independent and may have additional internal/test adapters; accreatio currently exposes and claims only Claude Code and Codex. This entry documents the bounded model and does not infer authority to modify upstream AEKR. Confidence: high.

### EXT-02 — API-funded execution

**Status:** Confirmed

**Evidence:** Governance requires zero direct service cost (`AGENTS.md:21-23`). Desktop eligibility accepts Claude only when its auth status says `claude.ai` subscription and rejects other/unknown auth at `electron/main.ts:103-137`; it rejects Codex API-key login and accepts ChatGPT login at `electron/main.ts:139-171`. The generated YAML hard-codes `max_budget_usd: 1.0` for every Claude role, emits no equivalent for Codex, and leaves an optional cumulative `budget.ceiling: 10.0` commented out at `shared/domain.ts:324-343`. The UI exposes only provider choice, session duration, and the mislabeled consecutive-failure threshold (`src/App.tsx:839-968`); it has no funding source, currency budget, consent, estimate, or API-funded mode. `docs/FAQ.md:7-10` only states the general zero-service-cost position.

**Root cause:** Current behavior is an implicit subscription/local-CLI-only eligibility policy, not an explicit funding model. API-key Codex is blocked, Claude authentication is subscription-specific, accreatio stores no credentials, and there is no user-selectable paid API path. The fixed Claude `max_budget_usd` and commented cumulative ceiling are runtime guard fields, but they do not identify who funds calls, authorize spend, give parity across providers, or expose cost controls to the user.

**Notes:** The generated `$1.00` Claude allowance is adjacent tension with the default zero-direct-cost boundary even when subscription billing makes actual incremental cost zero; its precise upstream accounting behavior cannot be established from accreatio alone. Any paid API support would require explicit owner change to the binding cost constraint; none exists today. Confidence: high.

### EXT-03 — Participant topology

**Status:** Confirmed

**Evidence:** The domain defines exactly four canonical roles and `MAX_AGENTS = 4` at `shared/domain.ts:1` and `shared/domain.ts:23-25`. Validation requires 1–4 agents and unique roles at `shared/domain.ts:121-138`. The UI hard-codes the same four role options, disables already-used roles, prevents removing the last role, and disables Add at four at `src/App.tsx:663-751`; Add chooses the next unused canonical role at `src/App.tsx:405-410`. Enabling Mode 1 creates one orchestration role config per planned agent and later reconciles it one-for-one at `src/App.tsx:298-317` and `src/App.tsx:769-784`. Validation requires the configured role set to equal the planned set and every task to be nonempty at `shared/domain.ts:164-182`. YAML emits one ordered `role_sequence` entry and one adapter mapping per configured role at `shared/domain.ts:291-340`; Auditor alone receives `EXECUTE_INDEPENDENT_AUDIT`, while other roles receive `EXECUTE_ROLE_STEP` (`shared/domain.ts:315-323`).

**Root cause:** “Agent” is modeled as one instance of one canonical role, so participant identity and role are effectively collapsed. Because roles must be unique, the product cannot express two participants with the same role, repeated role occurrences, more than four participants, or a participant distinct from its role assignment. The configured Mode 1 topology must exactly mirror planned role membership.

**Notes:** The four-role boundary is deliberate and documented (`AGENTS.md:16-19`, `docs/FAQ.md:23-25`), but it is the current extensibility limit. Provider assignments need not be unique: multiple different roles may select the same provider. Independent audit is represented structurally only for the Auditor role; planned-agent integrity still requires a runtime availability check and human decision before reducing topology. Confidence: high.

## Reconciliation summary

Confirmed real defects/gaps: UX-03 (light-theme control states), WEB-01 (no W1 attachments against the newly approved target), EXEC-02 (no end-to-end duplicate-invocation guard/idempotency), EXT-01 (closed provider model), EXT-02 (no explicit funding model), and EXT-03 (role and participant topology capped/collapsed). UX-01 and WEB-02 are structurally real at desktop/laptop widths but their exact visual severity and claimed clipping require live rendering. UX-02 is partly inaccurate because duration and the consecutive-failure field are editable; the actual defects are hostile controlled-number editing, a misleading retry label, and two hidden schema limits. UX-04 is partly inaccurate because accreatio is already the About heading, though the page closes on personal authorship. EXEC-01 is partly inaccurate because real write/export paths exist; default dry-run intentionally produces no artifact, and the reported runtime event needs a live environment reproduction.

Live Test Engineer pass required to fully close: UX-01/WEB-02 at the listed viewport and zoom matrix; UX-02 number-entry interaction; UX-03 computed contrast/native states; EXEC-01 actual desktop tracking, repository, both, and W1 download behavior; EXEC-02 rapid activation/concurrent IPC/download stress. These live checks do not change the static findings above.

Incidental in-scope findings, classified without fixes:

- **B — later in this same increment:** `docs/PRIVACY_POLICY.md:21` describes web attachments as already living in IndexedDB, while current W1 strips them and has no attachment capability. Reconcile the statement with the approved WEB-01 implementation and actual persistence design.
- **D — separate documentation/governance backlog:** `DECISIONS.md:46-50` and `docs/FAQ.md:39-45` still preserve an optional W2 loopback-companion direction, conflicting with the increment's binding “no W2 loopback companion” boundary. The historical decision record needs an explicit superseding decision rather than silent editing.
- **D — separate documentation backlog:** `docs/SOP_DESKTOP.md:82-85` and `docs/FAQ.md:43-45` say desktop does not launch/manage AEKR and P5 remains deferred, while 0.7.0 includes a desktop Orchestration Center (`CHANGE_CONTROL.md:5-13`, `src/App.tsx:1186-1192`). This is stale operator guidance, not evidence that the current execution code is absent.
