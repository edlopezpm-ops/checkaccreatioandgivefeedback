# Editorial Blog, Product Definition, and Authorship Provenance

> Superseded before release by `docs/design-v8/DESIGN.md` after the owner
> required authenticated web publishing and an explicit web/desktop boundary.
> This file remains as design-history evidence for the static Blog iteration.

Owner authorization: Ed Lopez, 2026-08-06. Existing project, mixed route
(local-first project data plus zero-cost vendor-managed static hosting/access),
AEKR Full profile. The owner's “Procede en full” is sponsor GO for this bounded
increment, its commit/push, and deployment to the existing protected Cloudflare
Pages beta after the repository gates pass.

## Outcome

Release `0.8.0` adds a static editorial **Blog** destination beside **New
project** and **About**. Its current product definition is:

> accreatio is an authenticated, local-first, ephemeral-session web application
> for creating and exporting projects.

This is a delivery and product-positioning statement, not authorization for a
new account system. The shipped W1 remains an owner-protected Cloudflare Access
beta with no accreatio application account or backend. Public landing,
self-service registration, email/phone OTP, hosted GitHub/IDE/AI connections,
and anonymous access remain outside this increment.

“Ephemeral-session” describes accreatio's server-side and external-integration
boundary: accreatio has no server-side project session, and future optional
provider tokens may not outlive the active connection session. It does **not**
mean that the deliberate local browser draft disappears on reload. Ordinary
draft fields remain in one user-controlled IndexedDB record on the device until
the user replaces it or clears site data; attachment bytes remain tab-only.

## Content contract

The Blog contains three English-language posts in this order:

1. **Introducing accreatio** — authored in this increment by Codex, an OpenAI
   AI coding agent, in collaboration with Ed Lopez through AEKR. Three or four
   substantive paragraphs describe the “nebula web” metaphor, prioritizing
   creation over repository administration, support for people still learning
   orchestration, local/export-first behavior, and the high-level role of AEKR.
   Exact signature: `Made with AI - Codex AEKR mode.`
2. **Nebula made ideas for accreatio** — authored independently by Claude, an
   Anthropic AI assistant, in collaboration with Ed Lopez, Codex, and AEKR. Two
   or three substantive paragraphs explain the technical idea holistically.
   Exact signature: `Made with AI — Claude AEKR mode.`
3. **A small paradox, but a paradox after all.** — authored and signed by Ed
   Lopez. Its body is transcribed faithfully from the second complete version
   appended in the owner-controlled Word document, beginning “The systems that
   run the world's largest businesses…” and ending “Meanwhile, let's keep
   building.” Codex and Claude must not rewrite or complete the prose. The
   owner-supplied `.docx` is retained locally under `.aekr/sources/`, ignored by
   Git so Office metadata and a duplicate publication source do not enter
   repository history; `src/content/blogPosts.ts` becomes the versioned content
   source.

Author labels identify the AI systems and their technology owners accurately,
while a single visible editorial note states that the posts are collaborative
AI-authored perspectives, not corporate statements or endorsements by OpenAI
or Anthropic. “Made with AEKR” describes the governed collaboration method at a
high level: deliberate scope, explicit decisions, bounded implementation,
evidence, and independent review. The Blog does not reproduce private AEKR
handbook content or imply certification.

## Product and privacy contract

Editorial copy may promise only the current or explicitly designed boundary:

- accreatio does not upload or store project content or project files on an
  accreatio-operated server;
- accreatio does not retain GitHub, IDE, or AI-provider credentials;
- any future optional connection must keep access tokens only for its active
  session and revoke them at sign-out/expiry;
- project creation and ZIP download remain available without an external
  GitHub, IDE, or AI-provider connection.

Those statements do not erase infrastructure reality. Cloudflare Pages and
Access continue to process essential request, identity, cookie, IP, timestamp,
and security metadata under their service. The Blog adds no form, cookie,
analytics, telemetry, API, external request, persistent state, or credential.
Current privacy/legal drafts remain authoritative for the protected beta.

## Interaction and presentation

- `AppDestination` gains `blog`; both web and desktop navigation expose it
  adjacent to **New project** and before **About**.
- The Blog is a semantic reading surface: one page `h1`, a labelled post index,
  and three independently labelled `article` elements with `h2`, byline,
  paragraphs, and signature.
- Native anchor links provide deterministic in-page navigation without a router
  or dependency. The destination itself remains state-local like the existing
  About surface; no unsupported deep-link contract is implied.
- The content uses the established Posterama/Inter role tokens and the existing
  translucent reading instrument. It reuses the calmer About atmosphere and
  remains monitor-agnostic: bounded reading measure on wide screens, one column
  on narrow/split layouts, no horizontal overflow, 44 px interactive targets,
  visible focus, and reduced-motion behavior inherited from the shared shell.
- The footer provides a clear **Create a project** action. The existing subtle
  global AEKR signature remains present.

## Documentation and map parity

The same increment updates the live README, decision/change/risk records,
current web strategy/architecture, release runbook, tests, and canonical Project
Map. Historical design/audit reports remain immutable evidence and are not
rewritten as current specifications. The map must represent the Blog as a
static renderer-owned content surface with no edge to project state, storage,
credentials, or external services.

## Validation and audit philosophy

At least one focused source/markup contract test must fail before the Blog
implementation and pass afterward. Local validation covers unit/source tests,
typecheck, formatting, production build, Project Map parity, real browser Blog
navigation, semantic landmarks, keyboard links, dark/light wide and narrow
frames, absence of horizontal overflow, absence of unexpected Blog egress, and
the existing repository verification gate. A dependency audit remains a manual
release check.

The final independent Claude audit is intentionally narrow in philosophy but
complete inside that boundary: inspect the exact pushed commit of this
repository only, compare all current code/configuration with all current
documentation and the canonical map, identify contradictions, stale claims, or
undocumented behavior, and report findings without editing or implementing.
Historical reports are checked for honest historical labeling, not treated as
live requirements. The auditor does not inspect unrelated repositories, broad
GitHub history, or external projects. Applicable AEKR guidance may be read only
to apply the requested method.

## Release and rollback

Deployment uses the existing zero-cost Cloudflare Pages Direct Upload project
and existing exact/wildcard owner-only Access applications. Before upload,
anonymous probes must still fail closed. After upload, both the stable and new
immutable deployment origins must again fail closed for anonymous requests.
The owner-authenticated session must then verify the Blog content, response
headers, absence of unexpected runtime egress, and the existing minimal W1
flow; if that positive-session check cannot be completed in this run, the
deployment may be recorded as technically successful but hosted acceptance
remains explicitly pending rather than being inferred. No Access policy,
identity provider, domain, DNS, Worker, Function, KV, database, analytics,
backend, paid service, or secret is added. The deployed asset must come from the
final documented commit.

Source rollback returns to `0dbbefd03305e56af2e4febbf129d64fcdc064c2`.
Rollback removes the static Blog destination/content and restores version
`0.7.0`; no user-data migration is required. Cloudflare rollback restores the
previous known-good protected deployment while leaving Access in place.
