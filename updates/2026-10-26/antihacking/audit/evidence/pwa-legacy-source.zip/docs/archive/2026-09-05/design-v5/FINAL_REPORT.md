# Dense Star Parallax, Faster Nebula, and Responsive Glass

Owner authorization: Ed Lopez, 2026-08-05. Baseline: `7876673ef55655b709f4386ba5b1fd08bd658c74` on `main`.

Implementation/evidence commit: `4e1a5be95fd9fc6626d0cc28788febad82891ddf`.
AEKR provenance integration commit: `51d30c6aaa5785e04b91217e6dac7a76382d32f1`.
Applicable AEKR governance commit: `d872514719520735f19fa107d87f7ba3e18f4b9d`.

## Outcome

accreatio now layers a deterministic first-party Canvas2D star field behind its locally bundled Vanta `FOG`/Three nebula. Far, mid, and near stars have different seeded positions, sizes, opacity, period, drift, and fine-pointer parallax. Their placement and alpha are weighted toward the right, so density dissolves continuously toward the left. Each star follows its own weighted multi-wave path inside an approximate 2/3/5 CSS-mm box; near stars travel farther and faster than mid stars, and mid stars farther and faster than far stars.

The autonomous Vanta speed is exactly doubled in every view: Home `0.56`, creation `0.44`, review `0.28`, export `0.48`, About `0.44`, and quiet `0.20`. The nebula retains bounded inverse-pointer movement, right-biased masking, view-specific scrims, local-only loading, and the existing fallback boundary.

About is capped at a fluid `62rem` instead of expanding to `100rem` on ultrawide displays. Its hero, explanation grid, instrument, and closing surface now respond to available width rather than a named monitor. Home/onboarding, creation, and About use the same more translucent instrument treatment, allowing the environment to remain subtly visible while the content scrim preserves readability. The established typography remains intact: display serif for editorial headings, sans for UI/body/control text, and mono for technical counters/code.

Two adjacent visual defects discovered during inspection were also removed: a legacy global `footer` rule no longer fixes the semantic About footer over its copyright, and the web-edition notice now gives its prose a full row instead of compressing it into a narrow column.

Before final audit, the owner supplied a full “Build with AEKR” PNG and expanded provenance scope. The asset now lives at `assets/aekr-banner.png` with its copy-along `assets/AEKR-BANNER-LICENSE.txt`, renders at full available width after the root README content for GitHub, and appears responsively beside the Project Map's canonical machine-readable source note. The generator embeds the exact bytes as a PNG data URI, preserving the map's single-file `file://`, restrictive-CSP, no-fetch, and no-remote-asset contract. The general rule for future AEKR projects was implemented independently upstream at `d872514719520735f19fa107d87f7ba3e18f4b9d`.

## Runtime and fallback behavior

- `StarField.tsx` owns one local Canvas2D plane. A fixed seed creates stable star pools; resize selects a stable prefix instead of reshuffling the sky.
- The star renderer is capped at 30 fps, bounds viewport population, caps backing DPR at 1.5, and receives only viewport, time, theme, media preferences, and fine-pointer coordinates.
- Autonomous per-axis weights sum to one, so drift remains inside the documented CSS-mm reference box. Pointer parallax is a distinct bounded depth offset.
- Normal supported motion has exactly two atmosphere canvases: one `.atmosphere__starfield` plus one Vanta canvas inside `.atmosphere__webgl`.
- Reduced motion, save-data, slow-update, and hidden-page states draw/hold one static star frame and omit Vanta WebGL.
- Missing, failed, or lost WebGL also omits Vanta; the StarField can continue its bounded motion unless another constrained state applies.
- Coarse pointers receive no pointer parallax. The complete atmosphere is `aria-hidden` and cannot receive pointer events.
- No project/draft/attachment data, storage, bridge/IPC, filesystem, Git, credential, provider, AEKR runtime, network request, or telemetry crosses into either visual layer.

## Visual-only validation evidence

By explicit owner direction, design v5 received visual testing only. No unit, integration, browser smoke, accessibility, Lighthouse, package, dependency/security-audit command, or full-regression execution is claimed for this increment. Existing automated v4 results remain historical evidence for `7da2707`, not v5 evidence. A production build was run only to generate the browser artifact used for inspection.

The artifact build completed successfully:

- application CSS: 65.62 kB / 12.51 kB gzip;
- main application JS: 351.61 kB / 110.40 kB gzip;
- Vanta lazy chunk: 12.37 kB / 4.35 kB gzip;
- Three lazy chunk: 724.20 kB / 184.68 kB gzip.

The existing >500 kB Three warning remains visible and unsuppressed. The affected source-level test and browser-smoke contracts were updated for the two-canvas architecture but were deliberately not executed.

Rendered evidence lives session-locally under `/tmp/accreatio-visual-v5/`. Its 34 accepted files are fixed by the committed `VISUAL_EVIDENCE.sha256` manifest; from the evidence directory, `sha256sum -c /workspaces/accreatio/docs/design-v5/VISUAL_EVIDENCE.sha256` must pass before review. Generated PNGs are not added to source history. The final matrix includes:

- Home 1920×1080 dark and light at `t00`, `t05`, `t10`, and `t15`;
- all four fine-pointer corners in both themes after the visual transform settled;
- isolated star layers at `t00`, `t05`, `t15`, top-left pointer, and bottom-right pointer;
- creation at 1440×900 in dark and light;
- About at 1920×1080 in dark and light, 2560×1440 ultrawide, 960×1080 split, 720×900 narrow split, and representative 200% zoom;
- Home at 390×844 and the 320×568 minimum;
- reduced motion at 1440×900 with the static star/fallback composition.
- the self-contained Project Map at 1440×900 and 390×844 with the embedded AEKR provenance footer.

Human inspection confirmed:

- a calm but clearly faster autonomous nebula between elapsed frames;
- strong right-side star density with a gradual left falloff;
- recognizable small/far, medium/mid, and larger/glowing near stars;
- distinct organic movement and depth-scaled pointer displacement without synchronized straight tracks;
- complete, readable content in dark/light and through translucent instruments;
- a materially narrower About card without horizontal clipping at ultrawide, split, 320 px, or 200% zoom;
- original typography roles across Home, creation, and About;
- a subordinate “Built with AEKR” signature with no literal collision in the accepted frames; the independent audit keeps a live-browser proximity check near 720 px open.
- a legible, responsive full AEKR banner in the Project Map footer without displacing canonical-source information.

During the long animated sequence, Chromium's headless screenshot encoder intermittently captured incomplete compositor tiles while WebGL, Canvas2D, masks, transforms, and backdrop-filter were updating. The DOM geometry remained intact, six isolation variants were nondiagnostic, and five lifecycle-frozen samples remained complete through 25 seconds. Final evidence therefore lets the page animate between checkpoints, waits 1.6 seconds after pointer changes, freezes only the selected compositor frame while encoding, and immediately resumes it. This is recorded as a capture-evidence risk, not claimed as a headed-browser defect; production visuals were not degraded to work around a headless race.

## Known limits and open risks

- Two visual canvases and a second bounded animation loop increase CPU/GPU/battery and lifecycle complexity. Frame/DPR/population limits reduce but do not eliminate that risk.
- Three remains a 724.20 kB lazy chunk, and Vanta's age/current-Three compatibility remains an explicitly accepted open risk.
- CSS millimetres are reference units (`96/25.4` CSS px), not a promise of identical physical movement on every display.
- Visual-only acceptance leaves functional and nonvisual regression uncertainty; current source test contracts have not been executed against v5.
- Missing-WebGL, constrained-mode, hidden-page, and context-loss behavior is implemented but lacks new automated v5 lifecycle coverage.
- The headless compositor race remains open as evidence tooling risk unless reproduced in a headed browser.
- Embedding the 938,282-byte source banner makes `project-map.html` approximately 1.33 MB; the deliberate single-file/no-request tradeoff remains tracked.
- At about 720 px, the fixed AEKR signature remains visibly separated from the third About step in the accepted static frame, but intermediate live-browser scroll positions remain an open Low visual check.
- Windows packaging remains a separate existing release gate. Public deployment remains on hold under DEC-009.

Every new design-v5 entry remains explicit with `Closed = false` in `RISKS.md`; the pre-existing portable-icon risk remains the sole row marked `true`. This visual increment does not silently close another release risk.

## Data, cost, deployment, and rollback

No schema, draft, attachment, business-flow, bridge/IPC, filesystem, Git/GitHub, credential, funding, provider, AEKR runtime, hosting, or deployment behavior changed. The star field is owned Canvas2D code with no new dependency or remote asset. Direct monetary cost is USD zero.

Rollback is source-only to `7876673ef55655b709f4386ba5b1fd08bd658c74`; no migration or user-data repair is required. The StarField, two-canvas contracts, doubled speed table, and responsive instrument changes should roll back together.

## Independent audit

Claude Code 2.1.222 reviewed the exact pushed accreatio commit 7a7e511595a8ab820e09b46de21903170b390e1c and pinned AEKR commit d872514719520735f19fa107d87f7ba3e18f4b9d from a fresh read-only context. The evidence manifest passed 34/34 before visual inspection. Claude changed nothing and returned **PASS WITH NON-BLOCKING IMPROVEMENTS** with no Critical, High, or Medium finding.

The sole code-side Low item is a live-browser spot check of the still-separated fixed AEKR signature and About step content near 720 px. A documentation-only Low note explains that the verbatim standardized banner license names its canonical AEKR source paths; Claude requested no correction. No code was changed after the audit. This documentation-only reconciliation records the verdict, preserves the proximity item as an open Boolean risk, and leaves all pre-existing release gates intact. See [CLAUDE_AUDIT_REPORT.md](CLAUDE_AUDIT_REPORT.md) for the full report.
