# SPRINT1-2 — Visual direction and design-system foundation

## 1. Selected direction: “Quiet formation”

The interface should feel like an idea settling into an organized system: editorial, calm, precise, and lightly atmospheric. Use asymmetric negative space, a restrained orbital/particle motif, and strong typographic hierarchy. Working surfaces remain opaque and practical; brand atmosphere belongs mainly to entry, header, onboarding, empty states, and completion—not behind every control.

Explicit exclusions: no pure/near-black dominant canvas, no generic AI-startup neon/cyberpunk, no chat-first façade, no pervasive glassmorphism, and no low-contrast lavender body copy. Gradients are static, broad, and limited to brand regions.

## 2. Existing shipped token reconciliation

The prior `TASK-DESIGN-THEME` contract is sound: semantic names, separate dark/light assignments, status families, control states, and focus semantics should remain. This increment extends it rather than replacing it. “Replace” below changes a value, not the token/API.

### Existing tokens — dark assignment

| Token | Decision and exact value | Reason |
|---|---|---|
| `--app-background` | **Replace** `#0B0912` → `#151126` | Removes near-black dominance while retaining deep violet identity. |
| `--surface-primary` | **Replace** `#12101B` → `#1C1730` | Establishes a readable first plane above the new canvas. |
| `--surface-secondary` | **Replace** `#181522` → `#231D39` | Creates a clearer grouped/navigation plane without bright borders. |
| `--surface-elevated` | **Replace** `#201B2C` → `#2B2443` | Makes dialogs/drawers visibly elevated by fill as well as shadow. |
| `--surface-overlay` | **Replace** `rgba(8,6,13,.78)` → `rgba(15,11,28,.72)` | Softer violet overlay; still isolates modal content. |
| `--surface-muted` | **Replace** `#17141F` → `#211B34` | Calmer wells and rows on the raised surface family. |
| `--border-subtle` | **Replace** `#2A2536` → `#312944` | Maintains low-frequency separators on lighter dark surfaces. |
| `--border-default` | **Replace** `#3A3349` → `#463B5C` | Preserves control boundaries at approximately 3:1 where meaningful states require it; panels should not all use it. |
| `--border-strong` | **Keep** `#655779` | Already fits hover/emphasis and the logo-neutral family. |
| `--text-primary` | **Keep** `#F4F1F8` | 16.48:1 on proposed app background; excellent AA/AAA margin. |
| `--text-secondary` | **Keep** `#C4BDCE` | Strong supporting text; high contrast on all proposed surfaces. |
| `--text-muted` | **Keep** `#958DA3` | Still exceeds 4.5:1 on proposed primary; restrict to metadata. |
| `--text-disabled` | **Keep** `#716A7B` | Existing disabled semantic remains distinct; not used for active instructions. |
| `--text-on-accent` | **Keep** `#160D20` | 8.77:1 on `#BFA1FF`. |
| `--accent-primary` | **Keep** `#BFA1FF` | Logo-derived, readable, and non-neon when used sparingly. |
| `--accent-primary-hover` | **Keep** `#CEB7FF` | Existing coherent hover step. |
| `--accent-primary-active` | **Keep** `#A17CE8` | Existing pressed step. |
| `--accent-primary-muted` | **Replace** `#2C2141` → `#392B55` | Selected fills need separation from raised working surfaces. |
| `--accent-secondary` | **Keep** `#8297D8` | Useful cool structural accent from the logo. |
| `--accent-secondary-hover` | **Keep** `#9AADEC` | Coherent hover step. |
| `--focus-ring` | **Keep** `#D1BBFF` | High-visibility focus color; retain 3px ring and underlay. |
| `--success`, `--success-muted` | **Keep** `#75D6A2`, `#153526` | Clear non-purple status family. |
| `--warning`, `--warning-muted` | **Keep** `#F1C46C`, `#3A2B12` | Clear warning family. |
| `--danger`, `--danger-muted` | **Keep** `#FF9B9B`, `#421D25` | Clear error family. |
| `--information`, `--information-muted` | **Keep** `#82B7FF`, `#172C49` | Clear informational family. |
| `--control-background` | **Replace** `#100E17` → `#181329` | Prevents inputs from returning to near-black. |
| `--control-background-hover` | **Replace** `#191522` → `#211A35` | Visible but quiet hover step. |
| `--control-background-selected` | **Replace** `#2C2141` → `#392B55` | Aligns selected controls with the revised muted accent. |
| `--control-border` | **Replace** `#40384F` → `#514466` | Makes interactive boundaries legible while allowing decorative panel borders to disappear. |
| `--control-border-hover` | **Keep** `#655779` | Existing strong outline is appropriate. |
| `--control-text` | **Keep** `#F1EDF5` | High-contrast control value. |
| `--control-placeholder` | **Keep** `#958DA3` | AA-capable on revised control background; never substitutes for label. |
| `--control-disabled` | **Replace** `#1B1822` → `#211C30` | Fits revised surface family. |
| `--control-disabled-border` | **Replace** `#302B39` → `#3B334B` | Keeps disabled boundary quiet but visible. |
| `--shadow-elevated` | **Replace** `0 24px 72px rgba(0,0,0,.48)` → `0 24px 64px rgba(8,5,18,.34)` | Less black/heavy; fill and border now carry more depth. |

### Existing tokens — light assignment

Keep the shipped light palette as-is except the following three extensions by value: `--app-background: #F8F7FC` (slightly cleaner canvas), `--surface-secondary: #F2EFF8`, and `--surface-muted: #F0EDF5`. Keep all other existing light values exactly: `--surface-primary/elevated #FFFFFF`, overlay `rgba(28,22,36,.52)`, borders `#E1DCE7/#CBC3D4/#877A94`, text `#211C29/#50485A/#6C6375/#8B8392`, accent family `#67419B/#563387/#472775/#E9DDF6`, secondary `#425E9B/#344D84`, focus `#7048A5`, all shipped status pairs, all shipped control values, and `--shadow-elevated: 0 24px 64px rgba(42,31,55,.18)`. These already form a designed counterpart rather than an inversion; changing more would add churn without solving the current IA/composition problem.

Representative contrast: `#211C29`/`#FFFFFF` = 16.63:1; `#50485A`/`#FFFFFF` = 8.69:1; `#6C6375`/`#FFFFFF` = 5.71:1; `#FFFFFF`/`#67419B` = 7.48:1. Dark: `#F4F1F8`/`#151126` = 16.48:1; existing `#C4BDCE`/the darker shipped secondary already measured 9.85:1 and remains safely above AA on the proposed family; `#160D20`/`#BFA1FF` = 8.77:1. Implementers must measure every final foreground/surface combination and preserve 4.5:1 normal text, 3:1 large text and meaningful component/focus boundaries.

## 3. New tokens to extend the system

### Typography

Use local/system stacks only (zero network/font dependency):

```css
--font-display: "Iowan Old Style", "Palatino Linotype", Georgia, serif;
--font-sans: "DM Sans", Inter, ui-sans-serif, system-ui, sans-serif;
--font-mono: "JetBrains Mono", "SFMono-Regular", Consolas, monospace;
--text-xs: 0.75rem; --text-sm: 0.875rem; --text-md: 1rem;
--text-lg: 1.25rem; --text-xl: 1.75rem; --text-2xl: clamp(2rem, 4vw, 3.5rem);
--leading-tight: 1.15; --leading-body: 1.55; --leading-reading: 1.7;
--tracking-display: -0.025em; --tracking-label: 0.02em;
```

Display serif is limited to entry/onboarding/empty/completion headlines. Product controls, data, and body copy stay sans; generated content/code stays mono.

### Spacing, size, radius

```css
--space-1: 0.25rem; --space-2: 0.5rem; --space-3: 0.75rem;
--space-4: 1rem; --space-5: 1.5rem; --space-6: 2rem;
--space-7: 3rem; --space-8: 4rem; --space-9: 6rem;
--content-reading: 45rem; --content-wide: 80rem; --nav-rail: 15rem;
--control-height: 2.75rem; --touch-target: 2.75rem;
--radius-sm: 0.375rem; --radius-md: 0.625rem;
--radius-lg: 1rem; --radius-xl: 1.5rem; --radius-pill: 999px;
```

Use 6–10px controls, 16px major cards, and 24px only for brand/entry compositions. Do not round every container; sections can use whitespace and separators.

### Elevation, surfaces, atmosphere

```css
--shadow-low: 0 1px 2px rgba(8,5,18,.18), 0 8px 24px rgba(8,5,18,.10);
--shadow-high: 0 28px 80px rgba(8,5,18,.28);
--brand-atmosphere-dark: radial-gradient(ellipse at 18% 12%, rgba(126,91,184,.22), transparent 48%), radial-gradient(ellipse at 82% 18%, rgba(94,116,184,.12), transparent 42%);
--brand-atmosphere-light: radial-gradient(ellipse at 18% 12%, rgba(151,115,205,.16), transparent 48%), radial-gradient(ellipse at 82% 18%, rgba(107,128,190,.10), transparent 42%);
```

Surface rules: canvas carries atmosphere; reading/work column uses `surface-primary`; grouped optional material uses `surface-muted`; drawers/dialogs use `surface-elevated`; selected state uses `accent-primary-muted`. Remove default borders from passive panels; use `border-subtle` only for grouping and `control-border` only for interactive boundaries.

### Motion

```css
--duration-fast: 120ms; --duration-base: 180ms; --duration-slow: 280ms;
--ease-standard: cubic-bezier(.2,.8,.2,1);
--ease-exit: cubic-bezier(.4,0,1,1);
```

Animate only disclosure height/opacity, drawer entry (maximum 16px travel), stage-state change, and success particle settling once. No looping ambient orbit. Under `prefers-reduced-motion: reduce`, set durations to `1ms`, remove transforms, and retain textual state changes.

## 4. Component primitives and composition

- `AppFrame`: quiet brand header, product navigation, scoped status; no permanent dashboard footer.
- `FormationMark`: integrated brand region using the actual transparent `src/assets/accreatio-mark-v2.png`, wordmark, negative space, and static atmosphere. Other available files are `accreatio-mark.png`, `accreatio-mark-chroma.png`, and `accreatio-mark-v2-chroma.png`; chroma variants are production/keyed variants, not green brand sources.
- `StageRail` / `StageStrip`: five-stage navigation with current, complete, attention states conveyed by text/icon/shape.
- `QuestionGroup`: heading, consequence, fields, optional help; primarily whitespace, not a bordered card.
- `ChoiceCard`: only for 2–4 consequential choices; normal fields remain standard controls.
- `AdvancedDisclosure`: summary names what is configured, not merely “Advanced.”
- `LocalityNote`: concise fact with location and lifecycle, not a decorative security badge.
- `SummaryDrawer`: invoked contextual summary on large screens, full-screen sheet on small screens.
- `ReviewManifest`: prompt sections, artifact tree, destination, limitations, and validation links.
- `StatusNotice` and `OutcomePanel`: icon + title + precise consequence/recovery; no color-only semantics.

## 5. Iconography and logo

Keep Lucide’s existing outlined family for operational actions, at 18–20px with 1.75–2px stroke. Do not place an icon beside every field; reserve icons for navigation, state, and unfamiliar actions. Never use sparkle/wand/robot icons as generic AI decoration.

The primary mark remains `src/assets/accreatio-mark-v2.png`. Remove its boxed 46px “app icon” presentation in the main header. On entry/onboarding, render it 72–112px, partially overlapping the atmospheric field with no border or tile; align the wordmark on its optical center and allow particles to dissolve into negative space. In the compact app header use a 28–32px unboxed mark plus wordmark. In confirmation, use a small unboxed watermark or omit it—the action’s consequence, not repeated branding, should dominate. Do not redraw or animate internal logo geometry.

## 6. Responsive and accessibility rules

- ≥1200px: 240px stage rail, centered 640–760px working column, optional 360px summary drawer.
- 768–1199px: horizontal stage strip, single 720px-max working column; summary becomes overlay.
- <768px: compact stage selector, single column, 16px gutters, sticky bottom primary action with safe-area padding; dialogs/sheets full-screen below 600px.
- Preserve 44px minimum targets, logical DOM order, visible labels, `:focus-visible` 3px ring, error summary links, native control semantics, polite live status, 200% zoom, and no horizontal scroll at 320 CSS px.
- Do not use color alone for completion, errors, Mode 1 lifecycle, or provider state. Disabled controls need adjacent reasons when unavailability is not self-evident.

This foundation deliberately keeps the prior semantic token API and the shipped Mode 1 interaction contract. The substantial rebuild should come from information architecture, disclosure, hierarchy, typography, and composition—not from discarding a working theme system.
