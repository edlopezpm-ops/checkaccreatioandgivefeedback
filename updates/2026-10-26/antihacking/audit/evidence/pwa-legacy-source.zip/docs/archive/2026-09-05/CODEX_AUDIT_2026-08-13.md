# Independent audit — Codex, 2026-08-13

**Auditor:** Codex CLI, fresh context, `--sandbox read-only`, not the author of
the changes under review.
**Candidate:** commit `b808928` on `chore/frontend-reconciliation-and-map-rename`,
diffed against parent `076e4ab`.
**Scope:** the five claims made by that commit's author, listed in the prompt as
the reconciliation counts, the no-product-change assertion, the Project Map
rename, the CI trigger change, and the new `CHANGE_CONTROL.md` entry.
**Instruction given:** report only; do not correct, rewrite, or commit.

## Verdict

**FAIL**

## Findings, verbatim

> 1. The 10/3/1 reconciliation is not supported as documented. Most sampled
>    closures are valid (`src/App.tsx:423-427,847,943-945,1169`;
>    `src/components/creation/CreationWorkspace.tsx:34-38`;
>    `src/components/BlogExperience.tsx:477,513`;
>    `src/components/AppFrame.tsx:52-54,114`). However,
>    `docs/archive/2026-09-05/FRONTEND_RECONCILIATION.md:33-45` classifies nine as already
>    closed/mitigated and four as non-defects/non-actionable, while `:21-26`
>    says three remain unsettled. Finding 8's evidence is inaccurate:
>    `src/components/WebExperience.tsx:17-36` neither says "no account" nor
>    duplicates routine save status. Finding 9's claim that all remaining 11px
>    rules are counters is refuted by `src/styles.css:1125-1126`.
>
> 2. The font-delivery condition is real (`src/styles.css:58-62`;
>    `scripts/project-map.template.html:9,33-37`), but "left undecided" and
>    "display voice inverts" are unsupported. Existing decisions accept the
>    fallback stacks and decline substitution (`CHANGE_CONTROL.md:20,33`), while
>    `DECISIONS.md:29` explicitly defines the intended role as display serif.
>    `docs/archive/2026-09-05/design-v6/DESIGN.md:45` also says installed named families render
>    before generic fallback, contradicting "every surface falls through."
>
> 3. The no-product-change and Project Map rename claims are supported. The diff
>    contains no `src/`, runtime, CSS, token, template, or JSON modification, and
>    the renamed viewer is byte-identical. The generator outputs the new name
>    (`scripts/generate-project-map.mjs:6,12-13,179-197`); parity and smoke use it
>    (`tests/projectMap.test.ts:20,57-60`;
>    `scripts/project-map-functional-smoke.mjs:8-13`); `project-map.json` remains
>    canonical (`PROJECT_MAP.md:5-6`).
>
> 4. The CI claim is overstated. `.github/workflows/ci.yml:7-10` correctly
>    restricts push runs to `main` and retains pull-request runs; `:24-27` retains
>    full verification. But this only triggers checks after a main push or on a
>    PR. The tree contains no branch-protection/ruleset configuration proving that
>    checks are required before merge or direct push, so "every commit reaching
>    main is still fully gated" is unsupported.
>
> 5. `CHANGE_CONTROL.md` contains additional unsupported statements. The
>    "preserved" one-command font patch at `:6`/`docs/archive/2026-09-05/FRONTEND_RECONCILIATION.md:69-80`
>    has no patch, command, artifact, or stash in the tree. The assertion at
>    `CHANGE_CONTROL.md:9` that all four `core.*` artifacts were gitignored is
>    false: `.gitignore:1-4` covers `node_modules`, `dist`, and `dist-electron`,
>    but `.gitignore:5-20` contains no `core.*` rule. The exact verification and
>    remote-state assertions at `CHANGE_CONTROL.md:11-12` have no tracked
>    candidate run evidence and cannot be established from this tree.

## Disposition

Every finding was re-verified against the tree by the author before being
accepted; none was taken on the auditor's word. The verification is recorded in
`docs/archive/2026-09-05/FRONTEND_RECONCILIATION.md` under "Audit corrections applied".

**Accepted and corrected:** findings 1, 2, 4, and the first two clauses of 5.
Finding 2 is the most consequential: `DECISIONS.md:29` does fix display serif as
the intended editorial role and does forbid adding or downloading a font, so the
author's "display voice inverts" rationale was wrong. The defect is that
appearance is *undetermined* — decided by what each visitor happens to have
installed — not that it is inverted. The remedy chosen by the HOE is unaffected
by this correction; its justification is not.

**Noted, not adopted:** finding 5's last clause, that `CHANGE_CONTROL.md`'s
verification and remote-state assertions cannot be established from the tree.
That is true of every entry in that file by design — it records operator-run
evidence such as CI run IDs, deployment IDs, and Lighthouse scores, which a
repository cannot contain. The convention is unchanged.

**Not in scope of this audit:** the typography change itself. It was reverted at
`b808928` and re-applied afterwards under the HOE's explicit 2026-08-13
decision, so the tree Codex reviewed did not contain it. A future audit pass
should cover the applied tokens and the two browser smokes updated with them.
