# Interactive Nebula, Orbital Identity, and AEKR Signature

Owner authorization: Ed Lopez, 2026-08-05. Baseline: `f37f91f` on `main`.

## Governance and objective

This is a Full/high-risk governed delivery because accreatio's complete product still prepares filesystem/Git work and optional human-gated AEKR orchestration. The visual change itself does not add privileged execution. The owner explicitly expanded visual scope while retaining the standing zero-direct-cost constraint and requested a final, read-only Claude audit of the pushed result against the complete repository and AEKR guidance.

The requested outcome is a deeper, soft nebula that is denser on the right, drifts autonomously like viscous fluid, and responds gently to mouse movement. The same visual system must support dark and light themes, preserve content legibility, use a new orbital lowercase-`a` identity without a visible image box, and carry a small unobtrusive “Built with AEKR” signature near the bottom.

The ESA/Webb nebula archive supplied by the owner is visual direction only. No ESA image, pixel data, metadata, or derivative raster is included in accreatio. The implementation is original procedural rendering and local vector work.

## Decision branch

The owner rejected the v3 CSS-only environment and explicitly permitted JavaScript/WebGL and broader scope. This design therefore supersedes only DEC-013's atmosphere technique, v3 logo geometry, and cream light-palette direction. It retains the guided five-stage flow, persistent shell, local-first data model, brand-to-home navigation, reduced-motion requirement, no-Skip onboarding, public-deployment hold, and all execution/security boundaries.

## Visual contract

### Atmosphere

- Use one persistent full-viewport atmospheric layer behind the application shell.
- Bias visible density from the right edge toward the left with a mask rather than stretching a source image.
- Use a low-resolution fog field for broad gel-like movement, a slower counter-moving CSS depth wash, a sparse star plane, a pointer-local glow, and a content-aware scrim.
- Apply bounded inverse pointer parallax only for a mouse/fine pointer. Maximum displacement is view-specific and never exceeds 16 px.
- Vary density, motion speed, parallax, and reading focus across `home`, `creation`, `review`, `export`, `about`, and `quiet` without remounting the atmosphere for ordinary navigation.
- Keep every atmospheric layer presentation-only: `aria-hidden`, `pointer-events: none`, and behind interactive content.

### Identity

- The runtime mark is an original transparent 256×256 SVG: lowercase `a`, two orbital paths, three satellites, and sparse particles.
- It contains no rectangle, raster image, or baked background. The shell displays it without a tile or border and uses glow/blending only to dissolve its particles into the surrounding atmosphere.
- The same source deterministically generates 192 px and 512 px PWA icons plus a 1200×630 social image. The 512 px render is also the Windows packaging source.

### Light theme

- Replace v3 cream/ivory with a cool ice, soft lavender, blue-violet palette derived from the new mark.
- Keep the identical semantic token contract as dark mode.
- Lower atmosphere saturation and density in light mode while retaining visible depth.
- Preserve a darker violet contour around the luminous central glyph so the mark remains recognizable on a pale surface.

### AEKR signature

- Render a local, original, transparent four-loop vector mark with the text “Built with AEKR.”
- Keep it fixed near the lower safe-area edge, non-interactive, low-opacity, and subordinate to product/status content.
- Collapse to the icon alone on narrow mobile screens.
- Do not copy AEKR handbook content or a private raster into the downstream repository. The signature records the owner's governed-build relationship; it is not a certification claim or third-party endorsement.

## Runtime architecture

- Runtime dependencies are pinned exactly to `vanta@0.5.24` and `three@0.185.1`, installed locally and loaded through dynamic imports. No CDN, API, analytics, remote image, external font, or service request is permitted.
- Vanta `FOG` supplies the autonomous shader motion. Because that effect does not use its mouse uniform, Vanta mouse/touch/gyro controls remain disabled and accreatio owns the bounded wrapper parallax.
- One effect instance lives in a ref. Theme/view updates call `setOptions`; ordinary navigation does not add canvases.
- Hidden documents destroy the effect and recreate it on return because Vanta exposes no supported pause API. Cleanup is idempotent and asynchronous initialization is cancellation-guarded.
- WebGL context loss destroys the effect and selects the static fallback. The fallback is always present behind the canvas.
- Vanta and Three are allowed only in the renderer presentation boundary. They receive no project content, persistence access, IPC bridge, credentials, or execution capability.

## Capability tiers and accessibility

Vanta is not imported or initialized when any of these applies:

- `prefers-reduced-motion: reduce`;
- `navigator.connection.saveData`;
- `(update: slow)`;
- the document is hidden;
- WebGL is absent or initialization fails.

Those states retain a static local CSS composition. Coarse pointers receive no cursor glow or touch tracking. Focus, DOM order, button semantics, native scrolling, and content contrast do not depend on the atmosphere. Both logo images are decorative where adjacent text already names the product/relationship.

## Performance and supply-chain limits

- Three/Vanta are split into their own lazy chunks, preventing them from inflating the main application chunk.
- The Vanta backing resolution is reduced with `scale: 3` and `scaleMobile: 6`; touch and gyro listeners remain disabled.
- Only one WebGL canvas is allowed. Hidden tabs release it rather than running an unseen animation loop.
- The dependency age and the unsupported Vanta/modern-Three pairing remain explicit open risks even when current browser validation passes.
- The Three chunk is expected to exceed the default 500 kB minified warning. This is accepted for the owner-authorized atmosphere but remains an open load/performance risk rather than being hidden by changing the warning threshold.

## Acceptance and evidence plan

Required automated evidence:

1. full tests, TypeScript, formatting, Project Map, production build, Electron smoke, project-map smoke, W1 functional smoke, Lighthouse, and npm audit;
2. exactly one atmosphere canvas after navigation/theme changes;
3. no remote runtime resource host;
4. pointer movement changes bounded local parallax state without intercepting clicks;
5. reduced-motion renders the fallback and no canvas;
6. brand SVGs contain no raster or rectangular background and the packaging icon points to the generated current asset.

Required rendered inspection:

- onboarding and creation in dark mode;
- creation in light mode;
- narrow mobile and ultrawide layouts;
- logo recognition/no visible asset box;
- right-biased depth, readable panels, and unobtrusive AEKR signature.

## Data, security, migration, and rollback

No project schema, IndexedDB record, attachment contract, bridge, IPC, filesystem/Git/GitHub operation, AEKR runtime contract, credential handling, telemetry, or hosting state changes. The only new network-capable code is ordinary npm-distributed renderer code bundled locally; runtime validation must prove that it contacts no external host.

Rollback is source-level: revert this phase to `f37f91f`. Drafts and project outputs require no migration. Service-worker users may need to accept the normal update/reload prompt to receive a rollback build. Public deployment remains unauthorized under DEC-009.
