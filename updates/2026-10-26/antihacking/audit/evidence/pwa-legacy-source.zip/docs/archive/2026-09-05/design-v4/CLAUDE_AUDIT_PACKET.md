# Independent Claude audit packet — design v4

Audit mode: read-only final pass after implementation commit and push. Do not modify files, implement fixes, commit, or push. Report findings to Codex so Codex can reconcile documentation-only gaps afterward.

## Controlling state

- Repository: `edlopezpm-ops/accreatio`
- Branch: `main`
- Base commit: `f37f91f`
- Controlling commit: the exact pushed `origin/main` HEAD supplied by Codex at invocation. Verify `HEAD`, `origin/main`, and the supplied hash are identical before reviewing. Do not audit an earlier commit, a dirty working tree, or design-v3 as the current implementation.
- Governance source: `/workspaces/ai-engineering-toolkit`, beginning with `toolkit/MASTER_SOP.md` and the Full/high-risk documents it routes to. Keep that private repository separate; do not copy its content into accreatio.

## Scope

Read the complete accreatio repository and its current documentation, not only the diff. Then inspect `f37f91f..HEAD`, dependency metadata/licenses, rendered evidence paths supplied by Codex, and the applicable AEKR guidance.

Primary implementation surface:

- `src/components/Atmosphere.tsx`
- `src/components/FormationMark.tsx`
- `src/components/AekrSignature.tsx`
- `src/components/AppFrame.tsx`
- `src/assets/accreatio-mark.svg`
- `src/assets/aekr-mark.svg`
- `src/styles.css`, `src/responsive.css`
- `scripts/render-brand-assets.mjs`
- `public/icons/`
- `package.json`, `package-lock.json`, `src/vendor.d.ts`
- visual/theme/shell/smoke tests

Current governing documentation includes DEC-014, the latest `CHANGE_CONTROL.md` entry, `RISKS.md`, `THIRD_PARTY_NOTICES.md`, both SOPs, troubleshooting, security, W1 readiness, Project Map material, and `docs/design-v4/`.

## Required review questions

1. Does the pushed code satisfy the owner's nebula, autonomous gel-like motion, mouse interaction, right-to-left density, depth/parallax, new orbital-`a` mark, cool light mode, borderless logo integration, and subtle AEKR-signature requests?
2. Are reduced motion, save-data, slow-update, hidden-tab, missing-WebGL, initialization-failure, and context-loss fallbacks truthful and safe?
3. Is there exactly one well-cleaned effect/canvas, with no listener/RAF/context leak across navigation, theme, StrictMode, or visibility transitions?
4. Are Vanta/Three local, pinned, license-documented, isolated from project data/privileged paths, and free of CDN/runtime egress?
5. Are performance, bundle, browser compatibility, supply-chain, accessibility, responsive, and service-worker implications accurately tested and recorded?
6. Do logo/icon generation, PWA references, Windows packaging, and visual evidence all use the current mark?
7. Does the AEKR signature remain subtle and truthful without copying private handbook content or implying certification?
8. Are current code and all current documentation consistent? Identify missing, stale, contradictory, or incomplete decisions, risks, change control, SOP, security, troubleshooting, readiness, report, or Project Map material.
9. Does the delivery follow the applicable AEKR Full/high-risk process without misrepresenting self-review as independent audit?
10. Are there regressions, untested claims, unnecessary complexity, or code/documentation gaps?

Separate code findings from documentation-only findings. Classify each as Critical, High, Medium, or Low and make it concrete/actionable. End with exactly one verdict:

- `PASS`
- `PASS WITH NON-BLOCKING IMPROVEMENTS`
- `REWORK REQUIRED`
