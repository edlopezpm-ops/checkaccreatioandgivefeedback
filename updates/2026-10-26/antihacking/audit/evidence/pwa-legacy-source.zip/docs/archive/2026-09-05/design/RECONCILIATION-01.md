# RECONCILIATION-01 — Execute contract and draft schema version

This authoritative addendum resolves only the two cross-Task conflicts identified by the Orchestrator's supplemental §27 consistency review. It introduces no capability, dependency, or scope beyond those resolutions.

## Conflict 1 — `Bridge.execute` / `accreatioApi.execute` signature

### Conflict statement

`TASK-EXEC-IDEMPOTENCY` requires a single `ExecutionRequest` envelope with an opaque `operationId`, while `TASK-WEB-ATTACHMENTS` independently specifies three positional arguments with a transient browser-attachment sidecar. These specifications target the same bridge, preload, IPC, and shared-type contract and cannot coexist.

### Resolution

All hosts and boundaries use exactly one argument:

```ts
export interface ExecutionRequest {
  operationId: string;
  definition: ProjectDefinition;
  settings: Settings;
  webAttachments?: readonly WebAttachment[];
}

execute(request: ExecutionRequest): Promise<ExecutionResult>
```

`operationId` remains required and opaque. `definition` and `settings` remain the complete execution snapshots. `webAttachments` is an optional, transient, in-memory W1 sidecar; it must never enter `ProjectDefinition`, draft persistence, generated provenance, logs, history, or any other persisted state. W1 supplies it when executing with browser attachments. Electron rejects a supplied `webAttachments` member as invalid host data.

The idempotency fingerprint canonicalization covers the execution-affecting identity of the complete request while excluding `operationId`: canonicalize the complete `definition` and `settings`, plus an ordered `webAttachments` identity projection containing count and, for each entry, `name`, `size`, and `extension`. Never canonicalize, stringify, hash, or otherwise read the `Blob` itself for the fingerprint. Existing boundary validation, Blob/metadata matching, attachment security, operation guarding, replay, and coalescing rules remain unchanged.

### Exact superseded-section pointers

- `docs/archive/2026-09-05/design/TASK-EXEC-IDEMPOTENCY/DESIGN.md`: in **“Decision summary”**, the fingerprint payload statement limited to `{definition, settings}` is superseded only by the attachment-aware canonicalization above. In **“Contract and state model”**, the three-field `ExecutionRequest` definition and its later W1-fingerprint deferral are superseded by the four-field envelope and identity projection above. The section's single-argument method shape, required `operationId`, validation, guard, cache, replay, failure, and security semantics stay unchanged. The boundary subsections continue to apply, with their `request` understood as the unified envelope.
- `docs/archive/2026-09-05/design/TASK-WEB-ATTACHMENTS/DESIGN.md`: in **“9. Exact file-level implementation plan”**, item 6's three-positional-argument `execute(d, s, transient?)` signature and its forwarding instructions are superseded by the single `ExecutionRequest` envelope above; items 7 and 11 consume/pass `request.webAttachments` instead of a third argument. The Task's transient-sidecar model, no-Blob persistence boundary, Electron rejection rule, export validation, ZIP behavior, cleanup, privacy, UX, and tests stay unchanged. The representation and security decisions in **“MSS 2.1 — Define representations and invariants”** remain authoritative.

`TASK-EXEC-EVIDENCE` result and evidence contracts are unaffected.

## Conflict 2 — IndexedDB draft envelope schema version

### Conflict statement

`TASK-PARTICIPANT-INSTANCES` and `TASK-WEB-ATTACHMENTS` independently assign different migrations to `DRAFT_SCHEMA_VERSION = 3`. The approved dependency order implements participant instances first, so version 3 belongs to that participant-model migration.

### Resolution

`TASK-PARTICIPANT-INSTANCES` retains `DRAFT_SCHEMA_VERSION = 3` exactly as designed. `TASK-WEB-ATTACHMENTS` must target `DRAFT_SCHEMA_VERSION = 4`. Its serializer writes a v4 envelope, and its attachment-stripping/count-marker behavior composes into the v3→v4 migration step. It must read the participant-aware v3 envelope, preserve all ordinary and participant-model data, force persisted `attachments: []`, discard attachment bytes and identifying metadata, and retain only the already-designed optional count notice. It must not introduce a separate v0–v3 envelope or rerun/redefine the participant migration.

All attachment persistence, privacy, reload-warning, future-version rejection, and no-IndexedDB-store-version-bump decisions remain otherwise unchanged.

### Exact superseded-section pointers

- `docs/archive/2026-09-05/design/TASK-WEB-ATTACHMENTS/DESIGN.md`: **“MSS 5.1 — Define schema version 3 persistence boundary”** is superseded only as to version: read it as schema version 4 and `StoredDraftV4 = { schemaVersion: 4; ... }`. In **“MSS 5.2 — Migration and reload/user behavior”**, its v3 reload behavior becomes the v3→v4 attachment-stripping migration and v4 reload behavior; the stripping and user-warning semantics stay unchanged. The version-3 references in **“Sprint 5 consolidation”**, **“9. Exact file-level implementation plan”** (items 9, 10, and 18), and **“10. Schema, migration, security, and regression summary”** are correspondingly superseded by version 4. No other part of those sections is superseded.
- `docs/archive/2026-09-05/design/TASK-PARTICIPANT-INSTANCES/DESIGN.md`: no section is superseded. **“MSS 3.1 — Pure migration function”** remains authoritative for the v3 participant migration, including `DRAFT_SCHEMA_VERSION = 3`.

## Implementation override

Implementers must apply this addendum as an authoritative override on top of `TASK-EXEC-IDEMPOTENCY` and `TASK-WEB-ATTACHMENTS`. Where either affected design conflicts with this file on the execute envelope, fingerprint input, or attachment draft version/migration composition, this addendum controls. All unaffected design requirements remain authoritative.
