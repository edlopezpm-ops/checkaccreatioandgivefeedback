# Independent Claude audit packet — design v5

Audit mode: final, fresh, and read-only after the controlling documentation commit is pushed. Do not edit files, implement fixes, run mutation-capable workflows, commit, or push. Report findings to Codex; Codex may reconcile documentation-only gaps afterward.

## Controlling state

- Repository: `edlopezpm-ops/accreatio`
- Branch: `main`
- Base commit: `7876673ef55655b709f4386ba5b1fd08bd658c74`
- Implementation/evidence commit: `4e1a5be95fd9fc6626d0cc28788febad82891ddf`.
- AEKR provenance integration commit: `51d30c6aaa5785e04b91217e6dac7a76382d32f1`.
- Applicable AEKR governance commit: `d872514719520735f19fa107d87f7ba3e18f4b9d`.
- Controlling audit commit: the exact pushed `origin/main` HEAD supplied by Codex at invocation. Before review, verify `HEAD`, `origin/main`, and that supplied 40-character hash are identical. Stop and report if they are not.
- Governance source: `/workspaces/ai-engineering-toolkit` at exact pushed commit `d872514719520735f19fa107d87f7ba3e18f4b9d`. Verify its `HEAD` and `origin/main` match before reading. Begin with `toolkit/MASTER_SOP.md`, follow the applicable Full/high-risk lifecycle, audit, definition-of-done, orchestration, project-branding, and operating-principle guidance, and keep the private AEKR repository separate from accreatio.

Ignore historical design-v2/v3/v4 as current implementation where DEC-015 or design v5 supersedes them. Do not audit an earlier commit, a dirty working tree, or an unpushed local state.

## Owner constraints

- Owner authorization: Ed Lopez, 2026-08-05.
- Direct monetary cost must remain USD zero; no paid API, service, asset, hosting, or purchase is authorized.
- Validation for this v5 increment is visual-only. Do not run unit, integration, smoke, Lighthouse, package, dependency/security-audit (including `npm audit`), or full-regression commands and do not reinterpret prior v4 automated results as v5 evidence.
- The audit is report-only. Do not fix code or documentation.
- Public deployment remains unauthorized under DEC-009.

## Scope

Read the complete accreatio repository and its current documentation, not only the diff. Then inspect `7876673ef55655b709f4386ba5b1fd08bd658c74..HEAD`, dependency/license metadata, the rendered evidence paths below, and the applicable AEKR guidance.

Primary v5 implementation surface:

- `src/components/Atmosphere.tsx`
- `src/components/StarField.tsx`
- `src/styles.css`
- `src/responsive.css`
- `src/extras.css`
- `tests/atmosphere.test.ts`
- `scripts/web-functional-smoke.mjs`
- `project-map.json`, `project-map.html`, and `PROJECT_MAP.md`
- `assets/aekr-banner.png`, `assets/AEKR-BANNER-LICENSE.txt`, `README.md`, `scripts/project-map.template.html`, `scripts/generate-project-map.mjs`, `tests/projectMap.test.ts`, and `scripts/project-map-functional-smoke.mjs`

Current governing documentation includes DEC-015, the newest `CHANGE_CONTROL.md` entry, `RISKS.md`, `README.md`, `THIRD_PARTY_NOTICES.md`, both SOPs, troubleshooting, security, W1 readiness, test notes, Project Map material, and all files under `docs/design-v5/`.

Rendered evidence is session-local under `/tmp/accreatio-visual-v5/`. Before inspection, run `sha256sum -c /workspaces/accreatio/docs/design-v5/VISUAL_EVIDENCE.sha256` from that directory; stop and report if a listed artifact is absent or mismatched. The committed manifest fixes the identity of the 34 accepted frames without adding generated screenshots to source history. Inspect the listed Home timed/corner files, isolated StarField files, creation/About responsive files, mobile/minimum files, reduced-motion file, and both Project Map AEKR-footer files. Diagnostic/corrupted intermediate captures are not acceptance evidence; their disposition is documented in `FINAL_REPORT.md` and `RISKS.md`.

## Required review questions

1. Does the exact pushed code satisfy the owner's doubled nebula speed, autonomous gel-like motion, fine-mouse interaction, denser right-to-left star falloff, three depth scales, distinct organic bounded 2/3/5 CSS-mm motion, and depth-scaled parallax requests?
2. Is the deterministic StarField mathematically bounded and stable across resize? Are count, alpha, size, period, shimmer, pointer interpolation, 30 fps, DPR 1.5, and constrained-area choices internally consistent and free of obvious leaks or unbounded work?
3. Are there exactly two presentation canvases in normal supported motion? Do reduced motion, save-data, slow-update, and hidden-page states retain one **static** StarField canvas with no Vanta canvas, while missing/failed/lost-WebGL and context-loss states retain one normally **active** StarField canvas unless a separate constraint applies? Are lifecycle, cleanup, theme, navigation, StrictMode, pointer, resize, and visibility transitions safe?
4. Is About materially narrower and monitor-agnostic at fullscreen, ultrawide, split, narrow, mobile, and 200% zoom? Do About/Home/creation transparency and typography preserve readability, original roles, and control hierarchy?
5. Did removal of the legacy global footer rule and the web-intro grid change fix the visible defects without causing collateral semantic/layout regressions?
6. Are Vanta/Three still local and pinned, is Canvas2D first-party with no new dependency/remote asset, and are the zero-cost, data-isolation, accessibility, security, privacy, offline/PWA, performance, and supply-chain boundaries accurately described?
7. Does the visual evidence support the claims without treating the headless compositor capture race or lifecycle-freeze technique as a product result? Is the owner-directed visual-only evidence limitation conspicuous and consistently stated?
8. Are current code, source-level test contracts, Project Map, decisions, risks (including Boolean closure status), change control, SOPs, security, troubleshooting, readiness, third-party notices, README, and design-v5 reports mutually consistent? Identify stale one-canvas/no-canvas claims or broken/current-vs-historical references.
9. Does delivery follow applicable AEKR Full/high-risk governance without copying private handbook content or presenting Codex self-review as independent?
10. Are there concrete code or documentation gaps, regressions, unjustified complexity, unsupported claims, or missing release blockers?
11. Is the owner-supplied AEKR banner stored once in the appropriate repository asset path with its copy-along license notice, rendered at full available width in GitHub README context, embedded byte-for-byte and accessibly in the Project Map, responsive at desktop/mobile, and still compatible with the map's restrictive CSP, `file://`, self-contained, and zero-request guarantees? Is the resulting size tradeoff explicit?

Separate code findings from documentation-only findings. Classify each as Critical, High, Medium, or Low, cite exact files/lines, and distinguish an evidence limitation from a product defect. Do not propose implementation as if it were already authorized.

End with exactly one verdict:

- `PASS`
- `PASS WITH NON-BLOCKING IMPROVEMENTS`
- `REWORK REQUIRED`
