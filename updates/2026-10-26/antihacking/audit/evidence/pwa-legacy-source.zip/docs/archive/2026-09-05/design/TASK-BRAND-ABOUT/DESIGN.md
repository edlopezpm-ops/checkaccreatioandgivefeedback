# TASK-BRAND-ABOUT — Product-first About and legal clarity

Status: design complete; production implementation remains behind the Human Design Gate.  
Owner: Participant B — Codex Solution Designer  
Authority: `docs/archive/2026-09-05/design/TASK_BACKLOG.md` entry `TASK-BRAND-ABOUT`; master prompt; supplemental §§5–6, 12–13, 30–31; DEC-008.  
Scope boundary: this record owns UX-04 only. It designs the About content hierarchy, localization, theme use, and evidence contract; it does not implement production code or change copyright ownership, license terms, package metadata, navigation, or deployment status.

## 1. Decision and current-state evidence

The About page will continue to open with the bundled mark and lowercase `accreatio`. It will continue to display the build version from `__APP_VERSION__`, which `vite.config.mts` defines from `package.json.version`. The existing copyright/private-use sentence will remain verbatim and continue to name Ed Lopez. A new, semantically separate product closing block will follow that legal paragraph, so the last heading/identity and last concise message are again `accreatio` and its verified principles rather than personal authorship alone.

Required closing copy:

| Element | English | Spanish |
|---|---|---|
| Closing identity | `accreatio` | `accreatio` |
| Closing principles | `Local-first project launch point · deterministic generation · no telemetry` | `Punto de partida local-first para proyectos · generación determinista · sin telemetría` |

The principle line is intentionally factual and narrow. It follows the repository mission and binding product boundaries. It does not claim trademark status, public availability, ownership, open-source licensing, cloud service, legal guarantees, or capabilities that are merely planned.

Evidence inspected:

- `src/App.tsx` currently renders one shared `About` component for desktop and W1. Its DOM order is mark → `h1` product name → version/license summary → privacy → Security → Documents → optional W1 legal links → Copyright → personal copyright/private-use paragraph.
- The page already opens product-first. UX-04 is therefore a closing-hierarchy defect, consistent with `docs/archive/2026-09-05/design/REPRODUCTION_REPORT.md`, not authority to replace the product heading or hide authorship.
- `package.json` declares name `accreatio`, version `0.7.0`, and author `Ed Lopez`. `vite.config.mts` injects the package version as `__APP_VERSION__`; no second version literal is needed.
- DEC-008 requires lowercase `accreatio` and states that product-name screening is not formal trademark clearance.
- `LICENSE` states `Copyright (c) 2026 Ed Lopez. All rights reserved.` and grants only bounded private use. The current About paragraph is a shorter UI summary of that position.
- `src/App.tsx` holds English/Spanish strings in the local `tr` object but also uses inline `es` branches throughout About. This Task should move all changed About copy into the same translation source without introducing a localization dependency.
- `src/extras.css` owns `.about-card` and `.legal-links`; `src/styles.css`/`src/polish.css` own the shared mark. The approved theme design supplies semantic tokens. No remote asset or theme-specific markup is needed.
- No focused About content/render test currently exists in the discovered test suite.

## 2. Content and semantic hierarchy

Required DOM/reading order after implementation:

1. `<section className="panel about-card" aria-labelledby="about-product-title">`.
2. Existing decorative mark with `alt=""`; it must remain ignored by assistive technology because the adjacent heading supplies the identity.
3. `<h1 id="about-product-title">accreatio</h1>`.
4. Localized version/license summary using `__APP_VERSION__`, followed by the existing localized privacy statement.
5. Existing Security section and content.
6. Existing Documents section and host-appropriate content; retain W1-only legal links and their localized navigation label.
7. Existing `Copyright` heading and legal paragraph, unchanged character-for-character in both locales.
8. `<footer className="about-product-close" aria-label={localized closing-label}>` containing a visually heading-like `<strong>accreatio</strong>` and the localized principles `<p>`. Do not add a second `h1`, imply that the footer supersedes the legal paragraph, or nest it inside the legal paragraph.

The closing block is a product signature, not a legal attribution. Separation through DOM structure, spacing, border, type weight, and localized accessible label prevents product identity, author, copyright holder, and license grant from being conflated. Its visual prominence must be below the page `h1` but above ordinary metadata. The copyright paragraph remains normal readable body text rather than being muted into a footnote.

### Legal wording boundary and approval branches

Baseline, approval-independent implementation:

- Keep `© 2026 Ed Lopez.` and the following English/Spanish private-use summary exactly as currently rendered.
- Keep the `Copyright` heading. Do not replace Ed Lopez with `accreatio`, append `accreatio` to the copyright notice, call `accreatio` the owner/licensor, or change the permission summary.
- Treat `package.json.author` as reference evidence, not as proof that a product name is a legal person or copyright holder.

Owner/legal approval is required before either optional branch:

- Explicitly label Ed Lopez as “copyright holder and licensor” / “titular de los derechos de autor y licenciante.” Although this may clarify roles, it makes an affirmative legal characterization not presently stated in the UI.
- Change any grant, restriction, holder, year, “all rights reserved” language, or relationship between the product name and Ed Lopez. If approved, synchronize the canonical `LICENSE` first or confirm that its current text remains controlling, then synchronize all UI/legal summaries in the same implementation Sprint.

Absence of approval does not block the baseline hierarchy correction.

## 3. UX decision — product-first opening and closing

This is the single UX-facing decision in this bounded Task; the content, semantics, localization, and presentation below are facets of the same About experience.

1. **User goal:** Identify the product, its installed version, operating principles, security/privacy posture, documents, author/copyright holder, and license boundary.
2. **Required information:** `accreatio`, runtime build version, license summary, privacy/security summary, document location/links, Ed Lopez copyright notice, and verified product principles.
3. **Optional information:** None in this Task; trademark, contact, build hash, and provider details are deliberately omitted.
4. **Happy path:** Open About, encounter product identity first, scan factual sections and legal text, and finish on a clear `accreatio` product signature.
5. **What can go wrong:** Version drift, missing/mismatched translation, legal-role conflation, low contrast, misleading host-specific document text, or heading/reading-order regression.
6. **Error explanation:** About has no mutable operation. Build/test failure must identify a missing locale key or version mismatch; broken links retain normal browser behavior and are tested separately in W1.
7. **Recovery without input loss:** Navigation away/back is safe; About has no input or persisted state to lose.
8. **Success confirmation:** The rendered order and copy themselves are the outcome; automated assertions and host/theme captures provide release evidence. No toast is appropriate.
9. **Accidental repetition:** Opening About repeatedly is read-only and idempotent; no duplicate-action guard is needed.
10. **Narrow screens:** Content remains one column, legal links wrap, the principle line wraps naturally, and no horizontal scrolling or clipped text appears at supported widths or 200% zoom.
11. **Keyboard-only:** Existing navigation reaches About; links remain in DOM order with visible focus. Static headings/text add no tab stops.
12. **Unavailable capabilities:** W1 shows only actual bundled legal links; desktop continues to direct users to project docs. Publication remains described as on hold.
13. **Implementation concepts:** Do not expose `__APP_VERSION__`, Vite, IPC, token names, package metadata, or internal locale codes.
14. **Terminology consistency:** Always lowercase `accreatio`; use “Version/Versión,” existing license language, and repository-defined “local-first,” “deterministic generation,” and “telemetry.”
15. **Desktop/web consistency:** Both hosts use the same component, product close, version source, locale keys, and theme tokens; only the already legitimate document-access paragraph/links differ by host.

## 4. Domain, schema, migration, security, and compatibility impact

### Domain and schema

- No `shared/domain.ts`, AEKR YAML/runtime, participant/provider, bridge, IPC, filesystem, Git, history, or settings contract change.
- Add About-only English/Spanish translation keys to the existing `tr` object in `src/App.tsx`: section labels, host-specific document copy, closing accessible label, and closing principles. Moving existing inline About branches into `tr` changes organization, not meaning.
- `__APP_VERSION__` remains the sole displayed version source. Do not hard-code `0.7.0`, read `package.json` at renderer runtime, or add a second version field.

### Migration and rollback

- No persisted-data or schema migration and no version bump solely for this design.
- Existing theme/locale settings continue to select the rendered copy and semantic token values.
- Rollback is removal of the new closing block/keys/styles/tests; it has no stored-state consequence. Legal text must not be rolled backward or forward independently of an owner-approved legal branch.

### Security, privacy, and legal safety

- Static local copy and the existing bundled mark only: no remote assets, font, fetch, telemetry, tracking, contact link, or privileged capability.
- Render translation strings as React text, never HTML. No `dangerouslySetInnerHTML`, user-authored content, or URL interpolation.
- Preserve the existing relative W1 legal links and desktop/W1 truth distinction; do not claim deployment or publication.
- Styling must not visually subordinate the actual copyright/license paragraph or imply `accreatio` is a legal entity. Product prominence is achieved by opening/closing hierarchy, not altered ownership language.
- The full `LICENSE` remains canonical. If the optional legal wording branch is approved, record the approval and perform a consistency review across `LICENSE`, About, Terms/FAQ, and relevant ownership/operator statements before changing copy.

## 5. Theme and visual contract

Consume the exact semantic tokens approved by `TASK-DESIGN-THEME`; do not add About-specific color literals:

- `.about-card`: `--surface-primary`, `--border-default`, `--text-primary` through shared panel rules.
- Secondary/version/privacy text: `--text-secondary`; reserve `--text-muted` for nonessential metadata only.
- Divider and closing-block separator: `--border-subtle` or `--border-default` where 3:1 non-text contrast is required.
- Product closing identity: `--text-primary`; one restrained accent edge or marker may use `--accent-primary`. The paragraph uses `--text-secondary`.
- Legal links: `--accent-secondary`, `--accent-secondary-hover`, and `--focus-ring`; never encode host, validity, or publication status by purple alone.
- Focus: inherit the theme design's `3px solid var(--focus-ring)`, offset, and contrasting underlay for W1 legal links. Static closing content receives no focus treatment.

Dark mode should carry the primary restrained violet/indigo identity; light mode uses the intentionally darker plum/blue-violet accent assignments from the theme contract. Structure, spacing, type scale, and emphasis remain identical. No gradient, glow, galaxy background, animation, transition, or extra logo instance is added to the closing block. Reduced-motion therefore has no About-specific motion to suppress.

Responsive requirements: preserve the current centered card, use logical spacing, allow all prose and link labels to wrap, keep a readable line length (current `max-width: 760px` is acceptable), remove any fixed/minimum width that causes overflow in supported W1 viewports, and verify 200% zoom. The shared application currently has a global `body min-width: 1000px`; `TASK-DESIGN-THEME`/responsive implementation must resolve supported-layout behavior rather than this Task introducing a competing one-off About override. Record any residual global overflow as a dependency finding, not as proof that About copy is acceptable.

### Supplemental §30 visual acceptance trace

| # | Design response |
|---:|---|
| 1 | About consumes the logo-derived dark semantic palette and existing bundled mark. |
| 2 | One restrained accent marker, neutral surfaces, no decorative effects. |
| 3 | Light consumes the separately defined light token values, not inversion. |
| 4 | The only About controls are links/navigation; all states come from the shared control contract. |
| 5 | Body/legal/secondary copy must meet WCAG 2.2 AA; muted tokens cannot carry essential legal text. |
| 6 | Legal links retain the unmistakable shared focus ring. |
| 7 | About introduces no selected/disabled control; shared navigation/link states remain distinguishable. |
| 8 | No semantic status is added and purple conveys no status. |
| 9 | Readable line length, opaque surface, normal prose contrast, and restrained hierarchy support long sessions. |
| 10 | Six-participant layout is outside About; no interference with the Mode 1 design is introduced. |
| 11 | No working-surface galactic imagery or duplicate closing logo. |
| 12 | One shared React component/token contract serves desktop and W1. |
| 13 | Existing logo, lowercase name, type hierarchy, links, and tokens form one system. |
| 14 | Matrix covers supported narrow/wide viewports and 200% zoom with no clipping. |
| 15 | No new motion; shared reduced-motion rules remain effective. |
| 16 | This section records rationale and exact token mapping. |

### Supplemental §31 UX acceptance trace

| # | Design response |
|---:|---|
| 1 | About is informational; legal links are plainly labeled and behave as links. |
| 2 | Documents copy explains the desktop/W1 difference before a user seeks a document. |
| 3–9 | Mode 1, numeric limits, providers, funding, and participants are unaffected and not represented here. |
| 10–13 | No save/cancel/validation/execute workflow exists; read-only reopening is safe and idempotent. |
| 14–16 | Attachments/output/failure are not presented on About; no false status claim is added. |
| 17 | Logical heading order, decorative-image semantics, native links, and shared visible focus support keyboard/AT reading. |
| 18 | Single-column flow, wrapping, and zoom matrix preserve all About content. |
| 19 | Copy excludes Vite, IPC, metadata keys, and other unnecessary internals. |
| 20 | Host document availability and publication hold remain truthful; principles describe current guarantees only. |

## 6. Exact implementation-ready file plan

Implement only after design approval, in this order:

1. `src/App.tsx`: extend both `tr.es` and `tr.en` with About-only keys; move the changed About labels/copy out of inline `es` branches; retain `__APP_VERSION__`; add `aria-labelledby` to the section; preserve the decorative mark; leave the legal paragraph verbatim; append the semantic `.about-product-close` footer with localized accessible label and exact approved principle copy. Keep the existing `isWeb` branch only for truthful document access.
2. `src/extras.css`: style `.about-product-close` and migrate touched `.about-card`/`.legal-links` declarations to the approved semantic tokens. Add no raw colors or theme-specific selectors. Adjust only About wrapping/spacing required by the responsive contract.
3. Focused test file following the repository's test convention discovered by the Implementer (prefer `tests/about.test.tsx` if the existing Node test harness can render React; otherwise introduce the smallest testable About content helper plus `tests/about.test.ts`): assert both locales, lowercase identity first and last, unchanged legal holder/license summary, package-derived version input, host-specific documents/links, decorative image semantics, heading order, and no unsupported product/legal claims. Do not add a dependency merely to snapshot markup.
4. `CHANGE_CONTROL.md`: record the approved UX-04 hierarchy/localization correction and explicitly say copyright ownership and license terms are unchanged.
5. Task implementation/evidence record at the Orchestrator-approved path: record exact files, tests, desktop/W1 dark/light screenshots, locale comparison, keyboard/AT order, 200% zoom, version-source check, and any deviations.

Conditional files, forbidden without explicit Ed approval of a legal wording branch:

- `LICENSE`, public Terms/FAQ/legal HTML/Markdown, `DECISIONS.md`, and ownership/operator documentation. If approved wording changes legal meaning, update the canonical decision/license record before or atomically with UI summaries and cite the approval.
- `package.json`: no change unless a separately proven factual inconsistency is owner-approved. Current author/version/product name support this design.

No change is expected in `shared/domain.ts`, `vite.config.mts`, Electron/preload/web bridges, assets, settings persistence, Project Map, or AEKR contracts.

## 7. Test and evidence plan

### Focused automated validation after implementation

- About content tests described in step 3 for English/Spanish and desktop/W1 variants.
- Static assertion/search that `© 2026 Ed Lopez` and both current private-use summaries remain present unless an owner-approved legal branch explicitly replaces them.
- Version-source check: About receives/uses the build-defined package version; no new semantic-version literal appears in About or translations.
- Existing `npm test`, `npm run typecheck`, `npm run format:check`, and `npm run build`.
- Theme static checks from `TASK-DESIGN-THEME`: no new raw color literals; both themes define every consumed token; no remote asset URL.

### Independent functional/visual verification

In Electron and local W1, test the matrix `English/Spanish × dark/light × normal/200% zoom`, plus supported narrow and wide W1 viewports:

- Product mark/name is first; `accreatio` is lowercase and is the final identity.
- Version equals the packaged/build version in each host.
- Copyright holder and private-use meaning are unchanged and readable, not visually hidden.
- Security/privacy/document statements remain accurate; W1 links exist and are reachable in tab order, while desktop shows no false clickable links.
- Heading hierarchy/read order is logical in accessibility inspection; the mark is not redundantly announced; focus is visible; no static text enters the tab order.
- Long Spanish copy and the closing principle line wrap without overlap, clipping, nested scroll, or horizontal About-card overflow.
- Contrast is measured for primary, secondary, legal, link default/hover/focus, divider, and accent marker pairs; capture computed ratios against WCAG 2.2 AA targets.
- Capture one screenshot for each host/theme/locale combination and additional narrow/200% evidence where wrapping changes.

Required design-gate evidence is this record plus owner disposition of the optional legal wording question. Required Task completion evidence is the focused test output, full regression/type/build results, locale/version comparison, keyboard/accessibility-order result, contrast measurements, and host/theme captures.

## 8. Design Sprints and MSS lifecycle record

All work below was design-only. “Files/artifacts” names what was read and what this record specifies; no production file was modified.

### Sprint 1 — Existing-content discovery

**ID:** `TASK-BRAND-ABOUT / SPRINT-1`  
**Objective:** Establish the real UX-04 defect and immutable factual/legal sources.  
**Entry conditions:** Mandate, reproduction report, and authoritative backlog available.  
**Included:** current About component/copy/styles, package version/author, version injection, DEC-008, `LICENSE`, theme dependency.  
**Excluded:** live UI execution, legal reinterpretation, production edits.  

#### MSS 1.1 — Reconfirm authority and defect

1. Reconfirmed objective: correct closing identity without redefining backlog scope.
2. Inspected master/supplemental prompts, Orchestrator log, reproduction report, and backlog.
3. Intended artifacts: those source records and this design record only.
4. Bounded design work: classified UX-04 as a closing-hierarchy defect, not a heading defect.
5. Focused validation: checked decision against backlog objective/non-goals/acceptance/risks/evidence.
6. Result: scope and dependency are stable.
7. Deviations/new findings: none.
8. Status: complete.

#### MSS 1.2 — Inspect content and legal/version sources

1. Reconfirmed objective: distinguish product, author, copyright holder, licensor, and version.
2. Inspected `src/App.tsx`, `package.json`, `vite.config.mts`, DEC-008, and `LICENSE`.
3. Intended artifacts: source files read-only; findings in this record.
4. Bounded design work: mapped DOM order, locale branches, host branches, version provenance, and controlling legal text.
5. Focused validation: compared UI wording with package/decision/license sources.
6. Result: product and version are already accurate; Ed Lopez must remain named; no licensor label is currently authorized.
7. Deviations/new findings: About translations are partly inline; classified C (current Task) because changed copy needs locale parity.
8. Status: complete.

#### MSS 1.3 — Inspect presentation and test surface

1. Reconfirmed objective: identify bounded presentation/test ownership.
2. Inspected About selectors in `src/extras.css`, shared mark styling, theme design, and current tests.
3. Intended artifacts: CSS/tests read-only; mapping in this record.
4. Bounded design work: identified semantic token consumers and absence of About-focused tests.
5. Focused validation: checked against supplemental §§30–31 and shared desktop/W1 architecture.
6. Result: `App.tsx`, `extras.css`, and focused tests are the minimal implementation surface.
7. Deviations/new findings: global responsive constraints belong to the theme/responsive dependency, not an About-only override.
8. Status: complete.

**Sprint 1 consolidation:** The opening identity is correct, package-derived version is correct, and one shared component serves both hosts. The defect is solely that the final legal block leaves Ed Lopez as the last identity. Legal sources support preserving that name and wording; they do not authorize calling the product the holder/licensor. Theme tokens and a focused content test are required inputs to the correction.  
**Focused validation/evidence:** cited source comparison and scope trace above.  
**Unresolved finding:** optional explicit licensor label requires Ed approval.  
**Sprint status:** complete; ready for Sprint 2: Yes.

### Sprint 2 — Content-hierarchy design

**ID:** `TASK-BRAND-ABOUT / SPRINT-2`  
**Objective:** Define exact copy, semantics, legal boundary, and file sequence without undocumented implementation choices.  
**Entry conditions:** Sprint 1 consolidated; theme token names available.  
**Included:** DOM hierarchy, product close, legal separation, domain/migration/security/test impacts.  
**Excluded:** legal ownership/license changes and implementation.  

#### MSS 2.1 — Define opening/closing hierarchy and copy

1. Reconfirmed objective: make `accreatio` the first and final product identity.
2. Inspected the consolidated DOM/content map and verified repository principles.
3. Intended artifacts: this record's §§1–2 only.
4. Bounded design work: specified exact English/Spanish closing copy and semantic DOM order.
5. Focused validation: checked each claim against mission, DEC-008, code, and current boundaries.
6. Result: implementation can add a product signature without altering legal meaning.
7. Deviations/new findings: no second logo is needed; duplicate imagery would weaken restraint/accessibility.
8. Status: complete.

#### MSS 2.2 — Define legal, schema, migration, and security boundaries

1. Reconfirmed objective: prevent branding from changing ownership or license meaning.
2. Inspected the current UI summary, `LICENSE`, package author, and backlog non-goals.
3. Intended artifacts: this record's §§2 and 4.
4. Bounded design work: defined baseline preservation, approval-only branches, no-schema migration, security, and rollback.
5. Focused validation: checked against master product boundaries and backlog legal acceptance criterion.
6. Result: baseline is unblocked; any legal characterization is explicitly gated.
7. Deviations/new findings: none.
8. Status: complete.

#### MSS 2.3 — Complete UX contract and delivery plan

1. Reconfirmed objective: make the design implementation-ready across UX and files.
2. Inspected supplemental §§5–6 and §31 plus current test/build conventions.
3. Intended artifacts: this record's §§3, 6, and 7.
4. Bounded design work: answered all 15 UX questions and specified ordered file changes/tests/evidence.
5. Focused validation: traced all 20 UX acceptance criteria and ensured non-applicable items are not claimed as delivered.
6. Result: Implementer has exact behavior, copy, semantics, order, and validation requirements.
7. Deviations/new findings: test file shape depends on the existing Node harness; no dependency addition is authorized merely for rendering.
8. Status: complete.

**Sprint 2 consolidation:** The approved-independent solution appends a distinct product signature after unchanged legal text. Exact bilingual copy, semantic reading order, no-schema migration, security/legal constraints, rollback, and ordered implementation/test files are defined. The optional licensor label remains outside baseline and needs direct owner approval.  
**Focused validation/evidence:** 15-question UX contract, §31 trace, legal-source comparison, file plan.  
**Unresolved finding:** Orchestrator must record Ed's answer if the optional licensor wording is desired; “no change” permits baseline implementation.  
**Sprint status:** complete; ready for Sprint 3: Yes.

### Sprint 3 — Localization/theme verification plan

**ID:** `TASK-BRAND-ABOUT / SPRINT-3`  
**Objective:** Ensure locale parity and visual/accessibility coherence across themes and hosts.  
**Entry conditions:** Sprint 2 consolidated; exact copy and semantic structure stable.  
**Included:** translation-key design, semantic-token mapping, responsive/zoom/keyboard/contrast evidence matrix.  
**Excluded:** broad theme implementation, navigation redesign, live prohibited tests in this design pass.  

#### MSS 3.1 — Define localization parity

1. Reconfirmed objective: preserve emphasis and facts in English and Spanish.
2. Inspected `tr.es`, `tr.en`, all inline About branches, and host-specific documents copy.
3. Intended artifacts: translation design and exact bilingual copy in this record.
4. Bounded design work: required paired About keys and retained legitimate `isWeb` differences.
5. Focused validation: compared identity, version, legal sentence, principles, and accessible labels locale-by-locale.
6. Result: no locale ends on personal authorship; neither locale changes legal meaning.
7. Deviations/new findings: unchanged legal sentences remain inline or may move to keys only if character-for-character equality is tested.
8. Status: complete.

#### MSS 3.2 — Define both-theme visual behavior

1. Reconfirmed objective: coherent product emphasis without decorative excess.
2. Inspected `TASK-DESIGN-THEME` tokens, About CSS, mark styling, and supplemental §30.
3. Intended artifacts: this record's §5 token/visual contract.
4. Bounded design work: mapped each About role to semantic tokens and prohibited one-off imagery/motion/colors.
5. Focused validation: answered all 16 visual acceptance criteria.
6. Result: one structure works in dark/light through token substitution.
7. Deviations/new findings: global `body min-width` remains a dependency verification item, not this Task's CSS scope.
8. Status: complete.

#### MSS 3.3 — Define verification and gate evidence

1. Reconfirmed objective: make acceptance observable in desktop/W1, locales, themes, keyboard, and zoom.
2. Inspected backlog evidence requirements and allowed/prohibited design-pass commands.
3. Intended artifacts: this record's automated and independent matrix.
4. Bounded design work: specified content/version assertions, contrast/read-order checks, and screenshot matrix.
5. Focused validation: checked the plan against current schema, master/supplemental prompts, and backlog acceptance criteria.
6. Result: evidence can distinguish correct hierarchy from merely changed styling.
7. Deviations/new findings: no prohibited live functional suite was run in this design pass.
8. Status: complete.

**Sprint 3 consolidation:** Paired locale keys, exact bilingual principles, shared semantic tokens, and a host/theme/locale/zoom/accessibility verification matrix close every Task acceptance criterion. The design adds no remote assets, motion, schema, or host divergence.  
**Focused validation/evidence:** §30/§31 traces and §7 matrix.  
**Unresolved finding:** only the optional legal wording question; it does not block the baseline.  
**Sprint status:** complete; ready for design-gate packaging: Yes.

## 9. Acceptance and handoff summary

| Backlog acceptance criterion | Design disposition |
|---|---|
| Product is primary first and last | Existing `h1` retained; exact product signature appended after legal text. |
| Roles/legal identity are not conflated | Legal paragraph remains separate/verbatim; product footer makes no ownership/licensor claim; approval-only branches explicit. |
| Version/principles accurate in hosts/locales | Package-derived `__APP_VERSION__` retained; principles are verified current boundaries; paired locale/host tests required. |
| Keyboard/theme/no-remote-asset coherence | Semantic structure/tokens, visible focus, matrix, and local bundled mark contract are explicit. |

Risks and controls:

- **Legal meaning drift:** verbatim baseline, approval branch, canonical-license comparison, audit.
- **Localization changes emphasis:** exact paired copy and locale-order assertions.
- **Version drift:** retain build-time package source; reject hard-coded version literals.
- **Product signature visually hides legal text:** require normal legal contrast and separate, subordinate closing hierarchy.
- **Theme/responsive regression:** consume theme tokens and test both hosts/themes at normal/200% zoom and supported widths.

Open question for Ed/Orchestrator: Should the UI explicitly characterize Ed Lopez as the “copyright holder and licensor” / “titular de los derechos de autor y licenciante”? This design recommends **no wording change by default** because the current license names Ed as copyright holder and permission grantor but the new label is a legal characterization. Direct approval is required to take that branch; otherwise implement the unchanged legal paragraph plus the product closing signature.

Design verdict: complete and implementation-ready for the baseline after the Human Design Gate. No production implementation was performed.
