# TASK-UX-MODE1 — Accessible Mode 1 configuration workflow

Status: design complete; production implementation remains gated by the Human Design Gate. This record owns UX-01, UX-02, and WEB-02 and is authoritative only for their UX integration. It consumes, without redefining, `TASK-DESIGN-THEME`, `TASK-PARTICIPANT-INSTANCES`, `TASK-PROVIDER-REGISTRY`, and `TASK-FUNDING-BUDGET`.

## 1. Outcome, scope, and fixed contracts

Replace the inline expanded editor with one centered, modal Mode 1 configuration dialog opened by **Prepare Mode 1 configuration**. The main form retains only the entry action and, after a successful save, a compact configuration summary plus **Edit configuration**. Electron and W1 render the same component, state model, validation, serialization-facing values, order, labels, and responsive behavior.

The authoritative backlog scope and non-goals are unchanged. This Task does not redefine participant identity, providers, funding, AEKR, general forms, Mode 2, execution, or idempotency. It introduces no draggable window and makes no unverified pixel-rendering claim.

Fixed upstream contracts consumed here:

- **Theme:** use the semantic tokens from `TASK-DESIGN-THEME`: overlay/elevated/primary/muted surfaces, semantic borders/text/control states, accent actions, semantic status colors, the 3px focus ring, and elevated shadow. No legacy or raw component colors are designed here.
- **Participants:** the target model is an ordered 1–6 `ParticipantInstance[]`; Mode 1 assignments join by stable `participantId`; canonical roles may repeat. However, current role-keyed AEKR YAML safely supports only 1–4 participants with unique roles. The dialog permits editing the persisted target model but blocks Mode 1 Save/export with an explicit compatibility error when the topology cannot currently serialize; it never invents aliases or promises execution.
- **Providers:** render the compiled descriptor order and store `providerId` per participant. Availability is ephemeral, never saved. Electron may check fixed subscription-CLI readiness; W1 always reports `unsupported_host` and can still prepare/export registered serializable choices. Unavailable is not the same as unsupported, disabled, invalid, or not checked.
- **Funding:** `subscription_cli` is selected by default and is the only valid current production mode. Paid API is shown disabled with the adjacent reason that no supported provider/profile can enforce an exact cumulative ceiling. Funding uses the single Execution limits invocation value and adds no duplicate. No credentials or payment/login path exists.

Current-code reconciliation: `src/App.tsx` directly mutates persisted project state while the editor is open, role-keys assignments, hard-codes providers, exposes only duration and consecutive failures, clamps on every keystroke, and mislabels failures as retries. `src/extras.css` forces a three-column participant row with a 72px textarea. `src/responsive.css` keeps that structure at all reachable Electron widths and wide W1 widths. `shared/domain.ts` confirms unchanged schema bounds: duration 60–7200 seconds, iterations per entity 1–10, provider invocations 1–100, consecutive failures 1–10.

## 2. Information architecture and component boundaries

Dialog source and focus order are fixed:

1. Header: title **Configure Mode 1**, concise consequence copy, Close button.
2. Error summary, only after blur or attempted Save; links focus the affected control.
3. **Participants**: one card/row per ordered participant, showing ordinal, stable participant label/ID, canonical role, task.
4. **Providers**: one assignment row per same participant order, descriptor-backed provider select and status/reason; Electron-only **Check provider availability** action.
5. **Execution limits**: four labeled numeric controls and help.
6. **Funding**: subscription selected; paid API disabled with reason; linked invocation summary.
7. Sticky footer: dirty-state text, **Cancel**, **Save configuration**.

Participant and provider content are separate required groups, not interleaved, so users can first establish responsibilities and then inspect execution tooling. Each group begins with a heading and one-sentence explanation; no collapsed section hides required fields. Six rows remain in normal document flow and use the dialog body as their only scrolling ancestor.

Implementation boundaries:

```text
App
└─ Mode1ConfigurationEntry (summary, Prepare/Edit action)
   └─ Mode1ConfigurationDialog (native modal shell, draft owner, save/cancel)
      ├─ Mode1ParticipantsGroup
      │  └─ AutoGrowTaskField
      ├─ Mode1ProvidersGroup
      ├─ Mode1ExecutionLimitsGroup
      │  └─ NumericDraftField
      └─ Mode1FundingGroup
```

Create `src/components/mode1/Mode1ConfigurationDialog.tsx` as the shell/state coordinator and `src/components/mode1/mode1Draft.ts` for pure draft conversion/validation. Keep the four small group components in the dialog file initially; extract only `AutoGrowTaskField.tsx` and `NumericDraftField.tsx`, whose behavior is independently testable and reused four times. This avoids both another monolithic `App.tsx` block and premature generic form abstractions.

`App.tsx` owns the persisted `ProjectDefinition`, host/provider observations, locale, and opening trigger. The dialog owns `open`, a deep-cloned `Mode1DialogDraft`, touched/error state, and the opener element reference. `open` may remain in `App` if needed to mount/unmount, but no draft setter writes `p.orchestration`. One active modal exists at a time.

## 3. Participant and provider design

### Participants group

Each row header reads, for example, **Participant 2 · participant-02** and below it the localized role/label. Stable ID is visible but visually secondary because repeated roles otherwise cannot be distinguished. Role is display-only here: participant topology editing remains in the main participant control and changes are reconciled by ID before opening. The task has a persistent label **Task for Participant 2 (Architect)** and optional character count; task is required after trimming, but whitespace/user text is preserved while editing.

Task textareas auto-grow from 120px to 240px on desktop/tablet and from 112px to 200px on narrow mobile. On every value change and dialog resize, set height to `auto`, then to `min(scrollHeight, bound)`. `overflow-y: hidden` below the bound and `auto` only when content actually exceeds it; no scrollbar is forced or permanently shown for ordinary content. `resize: none` prevents a second manual layout state. Long text wraps, preserves newlines, and is never horizontally scrolled. At the cap, the field itself may scroll while actively editing exceptionally long text; this is the bounded-control exception, not a second always-visible page scrollbar, and the full value remains available by keyboard. The Test Engineer must verify no always-on scrollbar at representative tasks and platform scrollbar settings.

The group does not add/remove/reorder/change participant roles. It consumes the main-form topology and provides an **Edit participants outside this dialog** non-destructive action only if product flow permits closing with confirmation; preferred v1 behavior is explanatory copy and Cancel, avoiding hidden mutation of the saved draft. If participants change after a saved Mode 1 configuration, ID reconciliation preserves matching provider/task assignments, supplies defaults for additions, removes deleted IDs, marks the summary **Needs review**, and requires reopening/Save before export.

### Providers group

For each participant ID, show participant ordinal/role, a native select populated from `PROVIDER_REGISTRY`, and a text+icon status. Assignment is editable even when availability is not checked because deterministic configuration/export and local execution readiness are different facts. Unknown/removed provider IDs preserve the raw draft for diagnosis, show **Unsupported provider**, and block Save; never silently choose Claude.

Electron starts at **Not checked**. **Check provider availability** updates ephemeral results without resetting selections or tasks; failures are shown per provider. Save may persist a serializable assignment without a readiness check, but desktop execution must perform the provider Task's fresh fail-closed preflight. W1 has no check button and immediately says: **This browser cannot check local CLI installation or sign-in. You can prepare and export this configuration, but Mode 1 cannot run in the browser. Verify providers in the desktop app before running.** It never says providers are absent.

When the participant topology is repeated-role or 5–6, place an error before the group: **This participant plan can be saved for project planning, but the current AEKR Mode 1 format cannot bind providers to these participant instances. Use one to four participants with unique roles for Mode 1, or wait for participant-aware AEKR support.** Because this dialog's Save means saving an executable/serializable Mode 1 configuration, Save is blocked. Cancel retains the last saved compatible configuration; topology reconciliation separately marks it stale rather than coercing it.

## 4. Execution-limit design

All four fields are visible in a two-column grid at wide sizes and one column on narrow/200% zoom. Exact English labels, stored property, bound, and help are:

| Label | Property | Range | Help text |
|---|---|---:|---|
| Maximum session duration (seconds) | `sessionMaxDurationSeconds` | 60–7200 | Stops the Mode 1 session after this wall-clock duration (1–120 minutes). |
| Maximum iterations per entity | `maxIterationsPerEntity` | 1–10 | Limits how many governed iterations one entity or work item may receive. |
| Maximum provider invocations | `maxProviderInvocations` | 1–100 | Limits aggregate provider calls for the execution. This is a call-count limit, not a monetary estimate. |
| Maximum consecutive failures | `maxConsecutiveFailures` | 1–10 | Stops or blocks progress after this many provider failures in a row. This is not an automatic retry count. |

Do not expose technical retry behavior because no configurable retry field exists. Use seconds rather than a minutes conversion so the UI edits the schema value exactly; the help supplies the human minute equivalent.

Each `NumericDraftField` owns a string, not a number. It accepts `""`, digit strings, and browser intermediate editing without updating the saved numeric contract. Prefer `type="text"`, `inputMode="numeric"`, and `pattern="[0-9]*"` to avoid Chromium number-stepper/intermediate-state variance; paste/filter validation reports invalid characters rather than deleting them. On blur, parse only a complete base-10 integer and show a range-specific inline error. Do not clamp, replace, round, or restore the old value. Save validates all strings, focuses the error summary/first invalid field, and leaves every draft value intact. Only successful Save converts strings to numbers. Reopening formats the saved integers as canonical decimal strings.

## 5. Funding design

Use a labeled **Funding mode** fieldset with two option cards. **Subscription/local CLI — no paid API use** is selected and displays `USD`, maximum cost `0`, and hard stop **Paid API prohibited** as read-only policy facts. Copy must say this preserves zero mandatory direct service cost; it must not claim the user's external CLI subscription is free.

**Paid API** is a disabled native radio/card. Adjacent, programmatically associated copy says: **Unavailable: no supported provider/profile can enforce an exact cumulative monetary hard stop.** Disabled styling and icon/text—not purple alone—communicate state. Do not render editable provider, model, currency, ceiling, or acknowledgment fields while the current registry has no eligible API profile; an optional disclosure may explain the evidence requirement, not simulate a workflow. The group repeats: **Also stops at no more than N provider invocations; edit in Execution limits.** It reads the same numeric draft and reflects invalid/empty as **Complete the provider-invocation limit above**.

If a later separately approved provider/AEKR contract enables API, this component may reveal the already-fixed upstream fields and behavior (provider/profile, USD, string maximum cost, unchecked acknowledgment reset on any material change), but no feature flag or UI-only change may enable it now.

## 6. Dialog shell, focus, keyboard, and responsive mechanics

Use the native HTML `<dialog>` opened with `showModal()` for top-layer modality, then add explicit focus/restoration tests rather than assuming browser behavior. Prevent form submission except through the Save handler. The shell has `aria-labelledby` and `aria-describedby`; the Close icon is named **Close and discard changes**. `cancel` (Escape) calls the same cancellation path as Cancel; `preventDefault()` is used until discard handling completes. Clicking the backdrop does not dismiss because an imprecise click must not discard edits.

Initial focus goes to the dialog heading with `tabIndex={-1}` so screen-reader and keyboard users receive context without unexpectedly entering a field. If opened after a failed/stale summary, initial focus still starts at the heading and the error summary follows. Tab/Shift+Tab remain inside the modal; native modal behavior is backed by a small sentinel/focusable-cycle fallback only if target Chromium testing proves it necessary. Focusable queries exclude hidden/disabled/inert elements. Escape, Close, and Cancel discard the dialog draft. Focus returns to the exact Prepare/Edit button that opened it; if that node disappeared, return to the Mode 1 entry container.

While open, native modality makes the background inert. Additionally add a body class only for `overflow: hidden` and scrollbar-gutter compensation; do not set `aria-hidden` on an ancestor containing the dialog. On cleanup—Save, Cancel, unmount, or error—remove the class and restore focus. No background pointer, wheel, or keyboard action may mutate the main form.

Desktop/tablet shell width is exactly `min(920px, calc(100vw - 32px))`, maximum height `calc(100dvh - 32px)`, using `--surface-elevated`, `--surface-overlay`, `--border-default`, and `--shadow-elevated`. It is a three-row grid: non-scrolling header, the **only intentional scroll container** `.mode1-dialog__body` (`min-height:0; overflow-y:auto; overflow-x:hidden; overscroll-behavior:contain`), and non-scrolling sticky-equivalent footer. The footer therefore remains continuously accessible without creating another scrolling box. Dialog content uses `min-width:0`, wrapping grid children, and no fixed child widths.

At desktop 1080/1250/1480 and W1 ~1024/1280/1440, width remains capped at 920px and two-column subgrids are allowed only where each column retains at least 280px. At 720px and below, all participant/provider/limit/funding rows stack. At 600px and below, the dialog uses `inset:0`, `width:100vw`, `max-width:none`, `height:100dvh`, `max-height:none`, no outer radius, safe-area padding, and a two-row footer only if two actions cannot retain 44px targets side by side. At 200% zoom, the same content-driven wrapping must produce the narrow layout without clipping or body horizontal overflow. Use dynamic viewport units with `100vh` fallback. No animation is required; reduced motion therefore changes no behavior.

## 7. Save, Cancel, persistence, and summary contract

State states are explicit:

```text
persisted ProjectDefinition.orchestration
        │ open: deep clone + numeric strings
        ▼
Mode1DialogDraft ── edit/validate locally ── Save success → normalized persisted config
        └─ Cancel / Escape / Close ─────────→ discard; persisted config unchanged
```

`savedConfig` is `p.orchestration`; `draftConfig` is created only on open. `dirty` is a pure deep comparison of canonical draft values with the open-time snapshot. Cancel/Escape/Close always discard immediately because the master explicitly defines Escape cancellation; the footer says **Unsaved changes will be discarded** when dirty. No close path writes project state. Successful Save performs dialog validation, domain validation, funding/provider/topology compatibility checks, then atomically replaces `p.orchestration` with the normalized config and `enabled: true`. It closes, restores focus, and announces **Mode 1 configuration saved** in the main form live region. Failed Save keeps the dialog open and all input.

First use: Prepare opens defaults derived from current participants, default tasks/providers/limits/funding; Cancel leaves Mode 1 disabled. Existing saved use: Edit opens a clone of the last saved config; Cancel restores exactly that saved config. Turning Mode 1 off is a separate explicit **Disable Mode 1** action beside the summary with confirmation when appropriate; disabling sets `enabled:false` but retains the last configuration values for re-enable/reopen instead of emptying assignments. This replaces the current toggle behavior that clears roles.

W1's existing debounced IndexedDB project-draft save runs only after successful dialog Save because only then does `p` change. Desktop retains the in-memory project-form behavior; this Task does not invent cross-launch desktop settings persistence. Within the current form session, both hosts reopen the last saved config. Upstream migration owns W1 schema versioning: legacy missing funding becomes subscription; participant/provider values migrate by participant ID; unknown/future/malformed paid data blocks visibly and is never coerced.

The compact summary contains: **Mode 1 configured**, participant count, provider display names (deduplicated only in the summary, not assignments), duration, the three budget/failure values, funding mode, and host status. For incompatible/stale topology it says **Needs review** and disables export/execute through existing validation. W1 additionally says **Configuration export only · provider detection and Mode 1 execution unavailable in browser**. Summary status uses icon+text+semantic token, never color alone.

## 8. Required UX decision answers (supplemental §6)

### UX decision A — dialog workflow, persistence, and summary

1. Goal: prepare, review, save, and later edit Mode 1 without disturbing the main form. 2. Required: four groups and valid values. 3. Optional: help disclosures. 4. Happy path: Prepare, edit, Save, confirmation/summary. 5. Failures: invalid fields, stale topology, unsupported capability, accidental dismissal. 6. Inline errors plus linked summary name the correction. 7. Draft is preserved on validation; Cancel restores prior saved state. 8. Live confirmation and compact summary. 9. Atomic Save and separate Disable prevent repeated/accidental mutation. 10. One stacked full-viewport mobile dialog. 11. Complete focus trap, Escape, visible focus, restoration. 12. Text distinguishes unavailable/unsupported/disabled/not checked. 13. No registry/YAML internals in primary copy. 14. Terms match AEKR artifacts. 15. Same component; W1 limitations are stated.

### UX decision B — participants, tasks, and providers

1. Goal: assign a clear task and supported provider to each planned participant. 2. Required: participant identity, task, provider. 3. Optional: diagnostic detail. 4. Happy path: review ordered rows, edit, optionally check desktop readiness. 5. Failures: empty task, unknown provider, unavailable CLI, unrepresentable topology. 6. Errors name participant and corrective action. 7. All draft rows survive errors/checks; Cancel restores saved assignments. 8. Saved summary and per-provider status. 9. Stable ID joins prevent role-change/repeat misassignment. 10. Rows stack and tasks remain bounded/readable. 11. Native controls, logical source order, labeled tasks/status. 12. W1 and desktop status copy is explicit and different only where factual. 13. Stable ID is shown for distinction but adapter/schema terms are not. 14. Participant/canonical role/provider language matches upstream contracts. 15. Configuration/export parity; detection/execution difference is honest.

### UX decision C — execution limits

1. Goal: bound work with understandable runtime limits. 2. Required: four integer strings resolving within schema bounds. 3. Optional: none. 4. Happy path: edit freely, blur/review, Save. 5. Failures: empty, partial, non-integer, out of range. 6. Field error states exact allowed range and meaning. 7. No clamp/reset; every draft value remains. 8. Saved summary and reopen show canonical values. 9. One field per schema property prevents duplicates. 10. Two columns collapse to one. 11. Labels/help/error associations and numeric keyboard. 12. No capability ambiguity applies; invalid is distinct. 13. No retry/runtime implementation jargon. 14. Labels map exactly to AEKR keys/semantics. 15. Identical values and serialization in both hosts.

### UX decision D — funding

1. Goal: understand and choose the permitted funding policy. 2. Required now: subscription mode and linked invocation limit. 3. Optional: enforcement disclosure. 4. Happy path: retain zero-paid-API default and Save. 5. Failures: invalid invocation limit or malformed/unsupported paid state. 6. Adjacent reason explains exact missing enforcement. 7. No paid data is coerced; validation preserves draft. 8. Summary says subscription, paid API disabled, and invocation ceiling. 9. Disabled API, no acknowledgment, validation/preflight, and no fallback prevent paid use. 10. Cards stack. 11. Fieldset/native disabled radio/reason association are keyboard/screen-reader clear. 12. Unavailable API has explicit text, not a fake selectable control. 13. No billing/registry implementation concepts unless diagnostic. 14. Funding/maximum cost/hard stop/invocations match upstream. 15. Same persisted/export semantics; W1 cannot execute.

## 9. Visual and UX acceptance trace

Visual decision: the dialog is an operational elevated surface, not a branded illustration. Dark mode derives identity through approved lavender focus/action accents on violet-neutral surfaces; light mode uses its approved plum counterpart. Working groups remain neutral and opaque. Controls implement every approved default/hover/selected/focus/disabled token state; status uses text/icon plus green/amber/red/blue semantics; focus is the approved unmistakable 3px ring. No glow, galaxy image, ornamental gradient, role color coding, or new motion appears. Typography and controls remain shared between Electron/W1. Six participants remain in one scroll flow; text wraps; 44px targets, responsive reflow, 200% zoom, and reduced motion are mandatory evidence.

Supplemental §30 trace: (1,3,16) consume the fixed theme palette/rationale; (2,9,11) neutral operational surfaces; (4–8) complete semantic control/status states and contrast measurement; (10) six-row single-scroll layout; (12–13) shared host component/token/typography/status system; (14) stated viewport/zoom matrix; (15) no new motion. Supplemental §31 trace: this Task directly covers 1–12 and 17–20. Item 13 remains `TASK-EXEC-IDEMPOTENCY`; 14 attachments remains `TASK-WEB-ATTACHMENTS`; 15–16 output evidence remains `TASK-ARTIFACT-VERIFICATION`. The dialog must not claim those unrelated criteria complete.

## 10. Domain/schema, migration, security, and compatibility impact

- **Domain/schema:** this Task adds no new participant/provider/funding semantics. It consumes the approved `participants`, `orchestration.participants`, `providerId`, `FundingPolicy`, and four numeric properties. UI draft strings are view-model state only. Successful Save emits numbers and upstream union values. Current AEKR compatibility guard remains mandatory.
- **Migration:** use the participant/provider/funding version-aware migration as fixed upstream: valid legacy roles/providers/tasks/limits are preserved; missing funding becomes exact subscription default; draft/provenance schema versions follow their implementation order; unknown future or explicit malformed paid data fails visibly. Do not add a parallel UI migration or schema version.
- **Security/privacy:** no user-authored text reaches a shell, CSS class, YAML key, command, provider diagnostic command, or HTML injection. React text rendering and shared serializers remain the boundaries. No network, secrets, credentials, telemetry, provider invocation, paid call, storage expansion, automatic fallback, commit, or push. `<dialog>` inertness prevents background mutation; cleanup prevents stuck body locks. W1 draft remains local IndexedDB state.
- **Compatibility:** Electron and W1 share the dialog and pure validation. W1 provider observation is unsupported-host, not unavailable. Planning can represent 1–6/repeated roles, but Mode 1 Save/export remains fail-closed for the role-keyed AEKR-incompatible subset until a separately approved contract lands.
- **Rollback:** revert the complete Mode 1 UI component integration while preserving migrated project data. Never downgrade or silently discard participant IDs/funding. The old inline editor is removed, not maintained in parallel.

## 11. Exact implementation order and file-level changes

Participant, provider, funding, and theme Tasks must land first. Then implement in this order:

1. `src/components/mode1/mode1Draft.ts` (new): define `Mode1DialogDraft`, numeric string conversion, deep-clone/open snapshot, dirty comparison, field/domain compatibility validation, and normalized Save result. Consume upstream types; define no domain duplicate.
2. `src/components/mode1/NumericDraftField.tsx` (new): labeled string input, help/error IDs, input mode, touched/blur behavior, and focus handle.
3. `src/components/mode1/AutoGrowTaskField.tsx` (new): measured bounded growth, overflow threshold, resize observation, accessible labeling/error, and cleanup.
4. `src/components/mode1/Mode1ConfigurationDialog.tsx` (new): native dialog lifecycle, four groups, provider status consumption, error summary, single body scroll, footer, atomic Save/Cancel, focus/inert/body-lock cleanup. Keep group subcomponents local unless file size/testing demonstrates a concrete split need.
5. `src/App.tsx`: remove inline `.orchestration-roles`, budget, provider check, and toggle-clearing markup; add entry/summary/Edit/Disable integration; own persisted config and provider observations; reconcile participant changes by ID; update English/Spanish copy and live confirmation. Do not change unrelated confirmation modal.
6. `src/extras.css`: delete obsolete Mode 1 row/budget layout rules; add dialog/group/card/task/limit/summary selectors using only theme semantic tokens and `min-width:0`/wrapping rules.
7. `src/responsive.css`: add 920px/32px dialog sizing, 720px stacking, 600px full-viewport/safe-area behavior, 200%-zoom-friendly content reflow, and footer target rules. Remove obsolete role-row breakpoint. `src/styles.css` changes only if the theme Task has not already provided shared `<dialog>`, focus, body-lock, and control primitives; if changed, add those generic primitives only and consume tokens.
8. `tests/mode1Draft.test.ts` (new): pure open/edit/cancel/save conversions, all numeric intermediate/range cases, dirty comparisons, compatibility, migration-shaped inputs, and no destructive normalization.
9. Add component tests in `src/components/mode1/Mode1ConfigurationDialog.test.tsx` if the approved test setup supports DOM rendering; otherwise establish the smallest repository-approved React DOM test harness and record it before adding assertions. Cover focus, Escape, trap, restoration, background inertness, task growth, Save/Cancel/reopen, errors, summary, provider host states, six rows, and disabled API. Do not substitute snapshots for behavior.
10. Update `tests/core.test.ts`, `tests/draftStore.test.ts`, and `tests/webExport.test.ts`/`tests/orchestration.test.ts`: exact four-limit persistence/serialization, composed upstream migration, compatible/incompatible participant topology, provider IDs, subscription policy, desktop/W1 deterministic parity, and invalid no-output behavior.
11. Documentation after implementation: Mode 1 user/operator guide and execution-limit glossary; `CHANGE_CONTROL.md`; Project Map for the new component/pure-helper boundary. Update `DECISIONS.md`/`RISKS.md` only for actual approved decisions/residuals, not to restate this record.

No Implementer may enable API, invent AEKR fields, add provider execution, change numeric bounds, or silently relax the participant compatibility guard while performing this file plan.

## 12. Verification and evidence plan

Focused automated evidence:

- Pure draft tests for empty/intermediate (`""`, leading zeros while editing, invalid paste), bounds ±1, blur, failed Save preservation, successful canonical conversion, cancel/reopen, first-use disabled state, and retained values after Disable/re-enable.
- Component tests for initial heading focus; forward/reverse trap; Escape/Close/Cancel; exact trigger restoration; backdrop non-dismissal; background inert/body cleanup; one scroll container; error-summary focus links; task growth below/at/above bound; six participants; provider states; W1 reason; API disabled reason association; live Save confirmation.
- Domain/draft/generation fixtures for all four exact properties/bounds, participant-ID joins, unknown providers, subscription funding, legacy migration, role-key compatibility guard, and byte-deterministic Electron/W1 serialization.
- Run focused Node/component tests after each implementation MSS, then `npm test`, `npm run typecheck`, `npm run format:check`, `npm run build`, and Project Map check. No test may call a provider or network.

Independent functional evidence in Electron and W1, dark and light: desktop 1080/1250/1480; W1 approximately 1024/1280/1440; 1000/720/600 breakpoint boundaries; representative narrow mobile portrait/landscape; browser zoom 100/125/150/200%. Record viewport/client/scroll widths proving no body horizontal overflow, only one intentional dialog scroll container, continuously reachable footer, and task scrollbars only beyond the documented cap. Test mouse, keyboard-only, screen reader semantics, focus capture/restoration, Escape, backdrop/background interaction, default/hover/selected/focus/disabled/error states, reduced motion, locale switching, and native control variance. Verify one/four compatible Save/export and repeated-role/five/six fail-closed messaging without losing input. Verify W1 ZIP YAML values and Electron generated YAML values, not UI success alone. Prohibited suites remain for the later authorized Test Engineer phase, not this design pass.

High-level regression: Mode 0 default, main participant editing, dry-run, theme/locale, existing project validation, W1 draft restore, one desktop generation, one W1 ZIP, settings/history, and unrelated execution confirmation modal behavior.

## 13. Design Sprints and MSS lifecycle record

Every MSS below followed: reconfirm objective → inspect current state → state intended design artifact/files → perform bounded design work → focused validation against mandate/upstream/current schema → record result/deviation → mark status. This design pass changes only this record.

### Sprint 1 — Existing-state discovery and upstream reconciliation

- **MSS 1.1 Mandate/backlog:** objective UX-01/02/WEB-02; inspected all five required governing records; artifact §§1,12–13; validated scope/criteria/prohibitions; result authoritative target fixed; deviation none; **complete**.
- **MSS 1.2 Upstream contracts:** inspected theme, participant, provider, funding designs in required order; artifact §§1,10; validated joins/status/funding and AEKR gap; result consumer boundaries fixed; deviation full expanded Mode 1 remains upstream-blocked; **complete**.
- **MSS 1.3 Current code/schema:** inspected `App.tsx`, all named CSS, domain, draft store, and tests; artifact §§1,3–7; validated reproduction citations and exact bounds; result root causes confirmed; deviation no live rendering claimed; **complete**.

Sprint 1 consolidation: current UI mutates saved state inline, role-keys data, hides two limits, clamps intermediates, and over-compresses tasks. Upstream target contracts solve identity/registry/funding but intentionally do not solve the AEKR participant-key gap. Ready for Sprint 2: **Yes**.

### Sprint 2 — Information architecture

- **MSS 2.1 Group/order design:** reconfirmed master §6; inspected current field placement; artifact §2; designed header/error/four groups/footer; validated exactly one visible required flow; no deviation; **complete**.
- **MSS 2.2 Component/state boundaries:** reconfirmed web-reusable architecture; inspected App/state/draft persistence; artifact §§2,7; designed component tree and ownership; validated no privileged logic or domain duplication; no deviation; **complete**.

Sprint 2 consolidation: a shared native dialog with four uncollapsed groups and a pure draft boundary replaces the inline editor. One body scroll container owns all six-row density. Ready for Sprint 3: **Yes**.

### Sprint 3 — Participant and provider groups

- **MSS 3.1 Participant/task design:** inspected participant handoff/current task fields; artifact §3; designed ID-visible rows and bounded auto-grow; validated 1–6, repeated roles, long text, narrow/zoom; deviation exceptional over-cap content scrolls only when necessary; **complete**.
- **MSS 3.2 Provider design:** inspected registry/status/W1 contracts; artifact §3; designed per-ID selection and host-specific status; validated no fake detection/execution; no deviation; **complete**.
- **MSS 3.3 UX/visual validation:** artifact §§8–9; answered all 15 questions and §§30–31 allocation; result implementation-ready; upstream compatibility error retained; **complete**.

Sprint 3 consolidation: identity and assignment remain per participant ID; W1 export is honest; expanded/repeated topology is editable planning data but cannot be saved as current Mode 1. Ready for Sprint 4: **Yes**.

### Sprint 4 — Execution-limit group

- **MSS 4.1 Semantics/labels:** inspected domain/YAML/reproduction; artifact §4; fixed four labels/help/ranges; validated no retries claim; no deviation; **complete**.
- **MSS 4.2 Numeric editing:** inspected current clamping; artifact §§4,7; designed string draft, blur/Save validation, no reset; validated boundary/intermediate matrix; no deviation; **complete**.
- **MSS 4.3 UX/visual validation:** artifact §§8–9; answered 15 questions and responsive/control criteria; result all limits visible/editable; **complete**.

Sprint 4 consolidation: seconds map exactly to schema; all four inputs preserve intermediate and invalid user text until corrected. Ready for Sprint 5: **Yes**.

### Sprint 5 — Funding group

- **MSS 5.1 Contract consumption:** inspected funding types/eligibility/serialization handoff; artifact §5; designed subscription facts, shared invocation link, disabled API reason; validated no new funding state; no deviation; **complete**.
- **MSS 5.2 UX/visual validation:** artifact §§8–9; answered all 15 questions and safety/state criteria; result paid use cannot be enabled or implied; no deviation; **complete**.

Sprint 5 consolidation: Funding is a first-class fourth group, zero-cost path selected, API visibly unavailable, and no duplicate invocation field exists. Ready for Sprint 6: **Yes**.

### Sprint 6 — Dialog shell, focus, and responsive mechanics

- **MSS 6.1 Modal/focus:** inspected existing non-semantic modal and shared theme contract; artifact §6; designed native modality, focus lifecycle, Escape, restoration, cleanup; validated keyboard/background criteria; deviation fallback trap only if target evidence requires; **complete**.
- **MSS 6.2 Scroll/responsive:** inspected current breakpoints/desktop minimum; artifact §6; designed 920px shell, single body scroll, fixed footer, 720/600 reflow; validated named widths/200%/mobile; no live result claimed; **complete**.
- **MSS 6.3 Visual consolidation:** artifact §9; mapped every §30 item and shared tokens; no new imagery/motion; **complete**.

Sprint 6 consolidation: shell meets the exact master width and modality target, with one scroll container and viewport-safe mobile behavior. Ready for Sprint 7: **Yes**.

### Sprint 7 — Save/cancel/persistence contract

- **MSS 7.1 State machine:** inspected direct App mutation and W1 autosave; artifact §7; designed saved/open snapshot/draft/normalized Save; validated every close path; no deviation; **complete**.
- **MSS 7.2 Reconciliation/summary:** inspected upstream migration and main validation; artifact §7; designed ID reconciliation, stale review, Disable retention, host summary; validated desktop/W1 truthfulness; no deviation; **complete**.
- **MSS 7.3 UX validation:** artifact §8; answered workflow questions and §31 save/cancel requirements; result Cancel/Escape cannot mutate persisted state; **complete**.

Sprint 7 consolidation: only successful Save changes project state; W1 persistence naturally follows that atomic update; desktop makes no new cross-launch promise. Ready for Sprint 8: **Yes**.

### Sprint 8 — Verification and delivery design

- **MSS 8.1 File plan:** inspected architecture and upstream implementation order; artifact §11; specified exact files/changes/order; validated no undocumented semantic decision remains; deviation test harness location depends on approved repository setup, behavior assertions do not; **complete**.
- **MSS 8.2 Test/evidence plan:** inspected scripts/backlog evidence; artifact §12; separated focused/integrated/manual/regression evidence and prohibited commands; no deviation; **complete**.
- **MSS 8.3 Final consistency:** cross-checked master §§6–7, supplemental §§5–6,12–13,30–31, backlog, four upstream designs, current schema, security, migration, and one-file scope; result Pass with inherited AEKR issue explicitly surfaced; **complete**.

Sprint 8 consolidation: the design is implementation-ready across UX, domain/schema consumption, migration, security, compatibility, exact file order, testing, and evidence. Production remains gated. Ready for design-gate packaging: **Yes**, subject to the inherited owner/AEKR dispositions below.

## 14. Risks, open questions, and gate recommendation

Primary risks are a custom dialog focus regression, draft/persisted leakage, six-row nested scrolling, textarea overflow differences, platform input variance, stale provider readiness, and UI wording that implies expanded AEKR or paid capability. Mitigations are native modality plus tested lifecycle, pure draft conversion, one scroll owner, measured textarea behavior, text numeric inputs, fresh execution preflight, and fail-closed compatibility/status copy.

No optional specialist is justified at design time. Escalate only if implementation evidence reveals a target-Chromium accessibility failure that cannot be bounded within the specified native dialog approach.

Open questions for Orchestrator/owner:

1. Resolve the inherited participant decision: authorize participant-keyed AEKR investigation/change, or approve the explicit fail-closed Mode 1 limitation for repeated roles and five/six participants.
2. Confirm the funding Task disposition that the shipped selector may show subscription selected and API unavailable until a separate exact-enforcement increment exists.
3. Confirm W1 may save/export registered provider assignments while stating detection and execution are unavailable; Electron execution still requires fresh readiness.

Recommendation: package for the Human Design Gate. Do not implement before approval.
