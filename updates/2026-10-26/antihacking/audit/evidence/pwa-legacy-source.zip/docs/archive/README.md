# Historical archive

Archived on 2026-09-05 under the owner instruction to reduce repository clutter. These records describe past baselines and do not authorize new work or override current decisions. Original and archived hashes are retained in [the manifest](2026-09-05/MANIFEST.json).

## Contents

- [Initial design and corrective increment](2026-09-05/design/FINAL_REPORT.md)
- [Design v2](2026-09-05/design-v2/FINAL_REPORT.md), [v3](2026-09-05/design-v3/FINAL_REPORT.md), [v4](2026-09-05/design-v4/FINAL_REPORT.md), [v5](2026-09-05/design-v5/FINAL_REPORT.md), [v6](2026-09-05/design-v6/FINAL_REPORT.md), [v7](2026-09-05/design-v7/DESIGN.md)
- [Original discovery](2026-09-05/PROJECT_DISCOVERY.md) and [original questions](2026-09-05/20-open-questions.md)
- [Engineering audit](2026-09-05/ENGINEERING_AUDIT.md) and [remediation](2026-09-05/AUDIT_REMEDIATION_2026-08-02.md)
- [Cursor UX audit](2026-09-05/CURSOR_UX_AUDIT.md), [frontend reconciliation](2026-09-05/FRONTEND_RECONCILIATION.md), [Codex audit](2026-09-05/CODEX_AUDIT_2026-08-13.md) and [August handoff](2026-09-05/SESSION_HANDOFF_2026-08-13.md)
- [P0 planning baseline](2026-09-05/PROGRAM_P0_RECONCILIATION.md)
- [Superseded authentication proposal](2026-09-05/AUTH_ROADMAP.md): its UTC-day reset is superseded by the rolling 24-hour policy.

## Current work retained

Archiving does not imply acceptance of unresolved historical checks. Current release/hosted acceptance is tracked in [W1 release readiness](../W1_RELEASE_READINESS.md); desktop remains frozen. The [web strategy](../WEB_STRATEGY.md) and [risks](../../RISKS.md) retain the existing automation and capacity boundaries. Authentication and quota follow [the current roadmap](../AUTH_ROADMAP.md). Designs v8-v14, branding evidence, runtime source and tests stay active.
