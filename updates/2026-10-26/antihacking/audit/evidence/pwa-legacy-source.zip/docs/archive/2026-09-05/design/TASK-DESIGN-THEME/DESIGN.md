# TASK-DESIGN-THEME — Semantic theme and control foundation

Status: design complete; production implementation is gated.  
Owner: Participant B — Codex Solution Designer  
Authority: `docs/archive/2026-09-05/design/TASK_BACKLOG.md` entry `TASK-DESIGN-THEME`; master prompt and supplemental §§1–6, 12–13, 30–31.  
Scope boundary: this record designs the theme foundation and UX-03 only. It does not implement code or redefine Mode 1, provider, participant, funding, About, or execution behavior.

## 1. Outcome and source evidence

Implement one shared semantic token contract, with dark mode as the primary restrained nebula expression and a separately designed light counterpart. All current controls consume semantic tokens and share explicit default, hover, selected/current, focus-visible, and disabled treatment. In particular, the header language/theme buttons and the Settings IDE/language/theme selects must stop inheriting dark literals in light mode.

Evidence inspected:

- `src/assets/accreatio-mark-v2.png` is an inspectable transparent RGBA asset and is the runtime mark imported by `src/App.tsx`; it visibly contains lavender, violet, pale blue-violet, white highlights, and deeper plum/indigo shading. I used the actual asset plus supplemental §1. The `*-chroma.png` files are RGB keyed-background production variants; their green is not a brand color.
- `src/styles.css` defines only `--bg`, `--panel`, `--panel2`, `--border`, `--muted`, `--cream`, `--cream2`, `--input`, `--danger`, and `--success`, then mixes them with many dark hex literals. Light mode changes only six variables and input text, leaving controls such as `.theme button`, navigation, buttons, modal surfaces, and numerous borders dark.
- `src/extras.css` repeats dark backgrounds/borders for option buttons, attachment actions, agent/provider controls, orchestration controls, evidence, gate actions, and state badges. `src/polish.css` adds more hard-coded control/status colors. `src/responsive.css` changes layout, not theme semantics.
- `src/App.tsx` renders the same shared application in Electron and W1. Current interactive elements are header navigation, language/theme icon buttons; text, number, checkbox, textarea, path, role/provider/project, IDE/language/theme selects; segmented/option/orchestration toggles; browse/add/remove/copy/review/save/confirm/cancel/close/connect buttons; expandable plan rows; orchestration actions/gates/cancel; links and `details/summary` disclosures.
- UX-03 root cause is confirmed: `.theme button { background: #11171f; }`, general secondary buttons retain dark literals, and light mode has no complete state contract. Settings selects get light text but continue using `var(--input)` with an incomplete native-control contract.

No remote asset, font, dependency, schema, bridge, persistence, or AEKR change is required.

## 2. Design principles

1. Neutral working surfaces dominate forms, tables, logs, previews, and settings. Purple is reserved for identity, primary/selected/focus states, and important workflow emphasis.
2. Color never carries status alone: status components retain icon/text labels and selected/current controls retain shape, border, background, and where appropriate `aria-current`, `aria-pressed`, checked state, or selected option semantics.
3. A theme is a complete value assignment to the same semantic API, not a selector patch over dark literals.
4. Focus is not hover or selection. Use a two-layer visible ring and preserve it in every theme/state except truly disabled controls, which are not focusable when native `disabled` is applicable.
5. No galaxy imagery on working surfaces; the transparent logo is the only image treatment in this Task. At most one restrained static radial tint may remain in the app background.

## 3. Token contract

Component rules may use only semantic tokens. Palette primitives may be declared privately for maintainability, but must not appear in component selectors. Values below are implementation requirements, subject only to a documented correction if measured contrast differs in a target engine.

### 3.1 Dark theme (`:root`, `[data-theme="dark"]`)

| Semantic token | Value | Purpose |
|---|---:|---|
| `--app-background` | `#0B0912` | near-black violet canvas |
| `--surface-primary` | `#12101B` | panels/forms |
| `--surface-secondary` | `#181522` | grouped/navigation surfaces |
| `--surface-elevated` | `#201B2C` | dialogs/cards above panels |
| `--surface-overlay` | `rgba(8, 6, 13, 0.78)` | modal backdrop |
| `--surface-muted` | `#17141F` | subdued rows/code wells |
| `--border-subtle` | `#2A2536` | separators |
| `--border-default` | `#3A3349` | control/panel outlines |
| `--border-strong` | `#655779` | emphasized/hover outlines |
| `--text-primary` | `#F4F1F8` | body/headings |
| `--text-secondary` | `#C4BDCE` | supporting copy |
| `--text-muted` | `#958DA3` | metadata/placeholders where allowed |
| `--text-disabled` | `#716A7B` | disabled labels only |
| `--text-on-accent` | `#160D20` | text on lavender accent |
| `--accent-primary` | `#BFA1FF` | primary/selected emphasis |
| `--accent-primary-hover` | `#CEB7FF` | primary hover |
| `--accent-primary-active` | `#A17CE8` | pressed/active |
| `--accent-primary-muted` | `#2C2141` | selected fill/subtle brand field |
| `--accent-secondary` | `#8297D8` | secondary structural highlight |
| `--accent-secondary-hover` | `#9AADEC` | secondary hover |
| `--focus-ring` | `#D1BBFF` | focus indicator |
| `--success` | `#75D6A2` | success foreground/icon |
| `--success-muted` | `#153526` | success surface |
| `--warning` | `#F1C46C` | warning foreground/icon |
| `--warning-muted` | `#3A2B12` | warning surface |
| `--danger` | `#FF9B9B` | error/destructive foreground |
| `--danger-muted` | `#421D25` | error/destructive surface |
| `--information` | `#82B7FF` | informational foreground |
| `--information-muted` | `#172C49` | informational surface |
| `--control-background` | `#100E17` | editable/control default |
| `--control-background-hover` | `#191522` | hover |
| `--control-background-selected` | `#2C2141` | selected/current |
| `--control-border` | `#40384F` | default outline |
| `--control-border-hover` | `#655779` | hover outline |
| `--control-text` | `#F1EDF5` | control value/label |
| `--control-placeholder` | `#958DA3` | placeholder |
| `--control-disabled` | `#1B1822` | disabled fill |
| `--control-disabled-border` | `#302B39` | disabled outline |
| `--shadow-elevated` | `0 24px 72px rgba(0,0,0,.48)` | dialog elevation |

### 3.2 Light theme (`[data-theme="light"]`)

| Semantic token | Value | Purpose |
|---|---:|---|
| `--app-background` | `#F7F5FA` | cool violet-tinted canvas |
| `--surface-primary` | `#FFFFFF` | panels/forms |
| `--surface-secondary` | `#F0EDF5` | grouped/navigation surfaces |
| `--surface-elevated` | `#FFFFFF` | dialogs/cards |
| `--surface-overlay` | `rgba(28, 22, 36, 0.52)` | modal backdrop |
| `--surface-muted` | `#EEEBF2` | subdued rows/code wells |
| `--border-subtle` | `#E1DCE7` | separators |
| `--border-default` | `#CBC3D4` | panel/control outlines |
| `--border-strong` | `#877A94` | emphasized/hover outlines |
| `--text-primary` | `#211C29` | body/headings |
| `--text-secondary` | `#50485A` | supporting copy |
| `--text-muted` | `#6C6375` | metadata/placeholders |
| `--text-disabled` | `#8B8392` | disabled labels only |
| `--text-on-accent` | `#FFFFFF` | text on plum accent |
| `--accent-primary` | `#67419B` | primary/selected emphasis |
| `--accent-primary-hover` | `#563387` | primary hover |
| `--accent-primary-active` | `#472775` | pressed/active |
| `--accent-primary-muted` | `#E9DDF6` | selected fill/subtle brand field |
| `--accent-secondary` | `#425E9B` | secondary structural highlight |
| `--accent-secondary-hover` | `#344D84` | secondary hover |
| `--focus-ring` | `#7048A5` | focus indicator |
| `--success` | `#237A4B` | success foreground/icon |
| `--success-muted` | `#E1F3E8` | success surface |
| `--warning` | `#8A5A00` | warning foreground/icon |
| `--warning-muted` | `#FFF0CE` | warning surface |
| `--danger` | `#B32636` | error/destructive foreground |
| `--danger-muted` | `#FBE4E7` | error/destructive surface |
| `--information` | `#245FA8` | informational foreground |
| `--information-muted` | `#E2EDFB` | informational surface |
| `--control-background` | `#FFFFFF` | editable/control default |
| `--control-background-hover` | `#F4F0F8` | hover |
| `--control-background-selected` | `#E9DDF6` | selected/current |
| `--control-border` | `#BFB5C9` | default outline |
| `--control-border-hover` | `#877A94` | hover outline |
| `--control-text` | `#2A2332` | control value/label |
| `--control-placeholder` | `#6C6375` | placeholder |
| `--control-disabled` | `#E9E5EC` | disabled fill |
| `--control-disabled-border` | `#D7D1DC` | disabled outline |
| `--shadow-elevated` | `0 24px 64px rgba(42,31,55,.18)` | dialog elevation |

### 3.3 Relationships and intentional differences

- Dark lavender `#BFA1FF` and light plum `#67419B` are relatives, not inversions. Light mode needs a darker action color for white-on-accent contrast and professional weight; dark mode needs a luminous-but-not-neon light accent against near-black surfaces.
- Indigo secondary and the violet-biased neutral surfaces directly echo the logo. Green, amber, red, and blue status families intentionally depart from the logo so purple never ambiguously means success, warning, or failure.
- Light surfaces are nearly neutral with a cool-violet bias; they do not carry the cream/beige legacy palette, which conflicted with the logo and made purple additions feel cosmetic.
- The sole optional background brand treatment is a static, low-opacity radial tint from `--accent-primary-muted` into `--app-background`; panels remain opaque enough for reliable contrast.

## 4. Contrast and motion rationale

- Target WCAG 2.2 AA: at least 4.5:1 for normal text, 3:1 for large text, and 3:1 against adjacent colors for focus indicators and meaningful component boundaries. Disabled text is exempt from text contrast but must remain legible and unmistakably disabled through fill, border, opacity, and cursor—not opacity alone.
- Representative required measurements: dark `--text-primary`/`--app-background` comfortably exceeds 7:1; dark `--text-secondary`/`--surface-primary` exceeds 7:1; light `--text-primary`/white exceeds 12:1; light `--text-secondary`/white exceeds 7:1; dark `--text-on-accent`/`--accent-primary` and light white/`--accent-primary` exceed 4.5:1. The Implementer must record tool-computed exact ratios for every text/background and status pair rather than relying on these estimates.
- Muted text is for secondary copy, not tiny essential instructions unless measurement is at least 4.5:1. Placeholder never replaces a visible label.
- Focus uses `outline: 3px solid var(--focus-ring); outline-offset: 2px` plus a 1px contrasting underlay (`box-shadow: 0 0 0 1px var(--app-background)`) where needed. Do not remove native outline unless this replacement is present.
- `prefers-reduced-motion: reduce` disables the spinner rotation and nonessential transitions/animated transforms. Busy status remains visible through text/icon; disclosure chevrons change instantly. Normal transitions are limited to color/background/border at 120–160ms; no ambient animation or glow.

## 5. Complete component-state contract

Every row applies in both themes by token substitution. `:focus-visible` composes with default, hover, selected, or active state; it never changes the semantic state.

| Current control family | Default | Hover | Selected/current/active | Focus-visible | Disabled/unavailable |
|---|---|---|---|---|---|
| Header language/theme icon buttons | secondary surface, control text/border; 44px minimum target; tooltip/accessible name states resulting action | hover surface + strong border | use `aria-pressed` for the represented current theme/language only if converted to choice buttons; current two action toggles otherwise have no false selected style | universal ring, no clipping by `.theme` container | not normally applicable; if pending persistence, native disabled, disabled tokens, cursor default |
| Header navigation and plan expandable rows | transparent/secondary surface, secondary text | control hover + primary text | nav uses selected fill, strong accent edge, primary text, `aria-current="page"`; disclosure uses `aria-expanded` and chevron orientation | universal ring around whole target | native disabled contract if introduced |
| Settings IDE/language/theme and all role/provider/project selects | control background/text/border; `color-scheme` matches active theme; explicit option background/text where supported | hover background/border | selected option remains native; closed select value stays high contrast | ring + focus border; no `!important` | disabled fill/border/text plus native `disabled`; unavailable provider also carries adjacent reason text (future Task owns provider behavior) |
| Text, path, number inputs and textareas | control tokens, visible label and placeholder | hover background/border | selection highlight uses accent muted with control text; invalid adds danger border plus error text/icon | ring; invalid state remains visible underneath | disabled tokens; read-only is visually distinct via muted surface but retains readable text and focus if navigable |
| Checkbox toggles | neutral labeled surface; native box border | surface/border hover for whole label | checked mark uses accent primary and visible check shape; label remains primary | ring on input/label via `:focus-visible`/`:has()` with fallback | disabled surface/text + disabled cursor; checked-disabled still visibly checked |
| Segment, role, output, Mode 1 option buttons | control surface/text/border | hover tokens | selected fill + accent border + primary text + check/pressed semantics; never color alone | ring | disabled fill/border/text, no hover; selected-disabled preserves check/shape |
| Primary buttons (`.start`, `.save`, `.confirm`, orchestration confirm) | accent primary + text-on-accent | accent hover | active accent active + 1px inset/pressed transform only when motion allowed | ring with contrasting underlay | disabled tokens, no opacity-only treatment; busy adds spinner/text and prevents repeat in owning Tasks |
| Secondary/browse/add/copy/settings/modal cancel/orchestration actions | control surface/text/border | hover tokens | active uses selected surface; persistent choices use pressed semantics | ring | disabled tokens; no hover |
| Destructive remove/cancel/reject/terminate actions | neutral surface with danger text/border and explicit verb/icon | danger-muted + danger strong | active retains danger semantics and pressed treatment | ring | disabled tokens and unchanged readable label |
| Close icon buttons | transparent, secondary text, 44px target | hover surface + primary text | active selected surface | ring | disabled contract if pending |
| Links | information color + underline (at least on hover/focus, always for inline prose) | secondary-hover equivalent/darker underline | visited may use accent-primary only if it retains 4.5:1 | ring | unavailable links render as text plus reason, not fake links |
| `details > summary` | secondary text with native/custom disclosure marker | primary text + muted surface | open state uses primary text and rotated marker (instant under reduced motion) | ring | not applicable currently |
| Status badges/results/notices | semantic foreground + muted status surface + border + icon/text | noninteractive: no hover | lifecycle state is label + shape/icon, not color alone | only if interactive | unavailable/unknown uses neutral tokens and explicit label, never success styling |

Specific UX-03 correction: remove `.theme button { background: #11171f; }` and light-mode `!important` patches; header controls and Settings selects must consume the table above. Set `color-scheme: dark` on dark root and `color-scheme: light` on light root so native arrows, option popups, checkboxes, and autofill affordances align. Test native select popup states on Chromium/Electron and supported W1 Chromium; where OS popup pixels are not CSS-controllable, require legible platform-native rendering and document the limitation rather than emulating a select.

## 6. UX decision records (supplemental §6)

### Decision UX-A — Theme and semantic appearance

1. Accomplish: work comfortably in a chosen coherent light/dark appearance.
2. Required: current theme and immediately applied visual state.
3. Optional: none.
4. Happy path: activate theme action or Settings select; all semantic surfaces update atomically.
5. Failure: stale mixed-theme values, unreadable native controls, persistence failure.
6. Explanation: nonblocking localized settings error if persistence fails; visible UI never silently reverts.
7. Recovery: retain all project input; retry or choose the prior theme.
8. Confirmation: entire app changes immediately; Settings value and next-action icon agree.
9. Repetition: toggling is reversible; no destructive or duplicate operation.
10. Narrow: 44px controls remain in header; no horizontal loss.
11. Keyboard: logical tab order, Enter/Space activation, visible focus.
12. Unavailable: disabled with reason only during a real pending/failure condition.
13. Internals: no token/CSS terminology exposed.
14. Terminology: localized “Theme/Dark/Light” remains consistent.
15. Hosts: identical shared state language in desktop and W1.

### Decision UX-B — Language action

1. Accomplish: switch application language.
2. Required: current locale and target locale in accessible name.
3. Optional: none.
4. Happy path: activate once; visible copy and Settings value update together.
5. Failure: persistence can fail; missing translation is a separate content defect.
6. Explanation: localized settings error where host persistence reports failure.
7. Recovery: project input remains; switch back/retry.
8. Confirmation: navigation/labels visibly change and action name updates.
9. Repetition: reversible, with one state update per activation.
10. Narrow: icon control remains 44px and does not displace navigation.
11. Keyboard: Enter/Space, visible focus, descriptive accessible name.
12. Unavailable: disable only if state cannot safely change, with reason.
13. Internals: locale codes are not shown in the header.
14. Terminology: language names in Settings remain human-readable.
15. Hosts: same shared behavior and styling.

### Decision UX-C — Settings selects, including UX-03

1. Accomplish: inspect/change IDE, language, and theme preferences.
2. Required: visible label, current value, available choices.
3. Optional: none.
4. Happy path: tab to select, choose value, save; theme/locale preview immediately as current behavior.
5. Failure: poor native contrast, invalid stored value, save failure.
6. Explanation: inline/localized error associated to the setting; invalid legacy value falls back via existing domain validation, not CSS.
7. Recovery: other settings/project input remain; user can reselect and save.
8. Confirmation: closed value, app appearance/copy, and Saved feedback agree.
9. Repetition: Save’s owning behavior must prevent duplicate host writes when later addressed; theme selection itself is idempotent.
10. Narrow: two-column grid collapses to one column; full-width 44px-min controls.
11. Keyboard: native arrows/Home/End/typeahead, visible focus, label association.
12. Unavailable: native disabled plus adjacent reason; unsupported values are not selectable.
13. Internals: no CSS/theme keys or provider implementation concepts.
14. Terminology: existing Settings/Theme/Language/IDE vocabulary remains.
15. Hosts: shared visual contract; host-specific IDE availability remains honest.

### Decision UX-D — Shared interactive-state language

1. Accomplish: distinguish actionable, current, focused, busy, disabled, and status states reliably.
2. Required: label/name, state, result/reason where relevant.
3. Optional: tooltip for icon reinforcement, never sole labeling.
4. Happy path: state changes preserve place and give immediate multimodal feedback.
5. Failure: color-only state, invisible focus, hover on disabled, mixed-theme literals.
6. Explanation: errors use danger icon/text and associated message, not border alone.
7. Recovery: validation preserves input and focus moves only when workflow requires it.
8. Confirmation: selected/check/current markers and completion message/status.
9. Repetition: disabled/busy semantics support owning operation guards; this Task styles but does not invent idempotency.
10. Narrow: targets stay at least 44px; wrapping does not hide labels/actions.
11. Keyboard: DOM order matches visual order, no positive `tabindex`, universal focus-visible.
12. Unavailable: disabled differs from unsupported; unsupported includes explanation and is not presented as actionable.
13. Internals: no implementation state enums unless already legitimate operator evidence.
14. Terminology: state language remains consistent with AEKR artifacts where AEKR lifecycle is shown.
15. Hosts: same semantic tokens/components; platform-native rendering differences are tested, not concealed.

## 7. Supplemental §30 visual acceptance trace

| # | Design response |
|---:|---|
| 1 | Actual transparent logo drives violet/lavender/plum/indigo palette; dark is primary. |
| 2 | Opaque neutral work surfaces, restrained accent use, no neon/glow. |
| 3 | Light uses darker plum accents and near-neutral surfaces, not inversion. |
| 4 | Complete state table covers every current control family. |
| 5 | AA thresholds and measured-evidence requirement are explicit. |
| 6 | 3px focus ring with offset/underlay is unmistakable. |
| 7 | Selected has marker/border/fill; disabled has native semantics/fill/text and no hover. |
| 8 | Green/amber/red/blue status families plus icon/text avoid purple-only meaning. |
| 9 | Neutral, opaque surfaces and high-contrast type support long sessions. |
| 10 | This Task supplies tokens/states; six-participant layout remains TASK-UX-MODE1, to consume them. |
| 11 | No working-surface imagery; optional static canvas tint only. |
| 12 | Shared React/CSS contract is used by Electron and W1. |
| 13 | Existing logo/system typography plus tokens/control/status language form one system; no remote font introduced. |
| 14 | Verification matrix includes supported breakpoints and browser 200% zoom. |
| 15 | Reduced-motion rule removes spinner/disclosure/nonessential animation dependence. |
| 16 | Sections 1–5 record source, rationale, mapping, and states. |

## 8. Supplemental §31 UX acceptance trace

This foundation directly satisfies §31.17 (keyboard), §31.18 (responsive critical functions), and the state clarity needed by §31.20 (unsupported is not actionable). It supplies consistent visible states for actions (§31.1), validation/error preservation (§31.12), duplicate-safe busy states (§31.13), status/limits (§31.14), output/failure feedback (§31.15–16), and later Mode 1/provider/funding tasks (§31.2–11), without claiming those workflows are redesigned here. Future Tasks must consume these tokens and independently satisfy their behavioral criteria; CSS alone is not evidence of completion.

## 9. Domain, schema, migration, security, and compatibility impact

### Domain/schema

- No change to `shared/domain.ts`: `Settings.theme` remains the closed `"dark" | "light"` union and locale/IDE values remain unchanged.
- No persisted-data migration or version bump. Existing saved `dark` and `light` values map to the new token assignments without reinterpretation.
- No AEKR YAML/runtime, bridge, IPC, execution, filesystem, Git, or GitHub contract change.

### CSS migration

Replace, do not indefinitely alias, legacy component usage in bounded passes:

| Legacy | Semantic destination |
|---|---|
| `--bg` | `--app-background` |
| `--panel` | `--surface-primary` |
| `--panel2` | `--surface-secondary` |
| `--border` | context-specific `--border-subtle/default/strong` |
| `--muted` | `--text-secondary`, `--text-muted`, or `--text-disabled` by meaning |
| `--cream`, `--cream2` | `--accent-primary`, `--text-on-accent`, or `--control-text` by meaning |
| `--input` | `--control-background` or `--surface-muted` |
| `--danger`, `--success` | same semantic names plus their muted surfaces |
| hard-coded dark/light literals | one documented semantic token; no theme-specific component override unless a genuine exception is recorded |

Do not use a long-lived compatibility block such as `--bg: var(--app-background)` because it hides incomplete migration. A temporary alias is permitted only within one implementation Sprint and must be removed before Task validation. A post-migration `rg` check must show no legacy custom-property consumption and no unexplained component color literals (logo asset and transparent overlay primitives excepted).

### Security/privacy

- CSS and local bundled logo only; no remote fonts, images, telemetry, storage, scripts, or content transmission.
- Do not interpolate user-authored values into styles or class names. Theme remains the validated union assigned to `document.documentElement.dataset.theme`.
- Preserve current CSP/build asset handling. Native controls are styled through static CSS; no custom select dependency or privileged bridge expansion.
- Status semantics must not imply capability, availability, success, or paid authorization. Visual disabled styling must match native/ARIA behavior; `aria-disabled` alone must not leave an action executable.

### Rollback

The implementation is CSS/UI-attribute only and can be reverted as one Task. Persisted settings remain compatible because enum values do not change. Keep the current transparent logo path, so rollback has no asset migration.

## 10. Exact implementation-ready file plan

Order is mandatory so later steps consume a stable contract:

1. `src/styles.css`: replace root legacy variables with the full dark semantic contract and `[data-theme="light"]` with the complete light assignment; add `color-scheme`; define shared control/focus/disabled/status/motion rules; migrate all literals/selectors in this file; remove light `!important` patches.
2. `src/extras.css`: migrate option, attachment, participant/provider, Mode 1, orchestration, gate, evidence, badge, action, and disabled selectors to semantic tokens and the shared state contract. Do not redesign their layout or information architecture.
3. `src/polish.css`: migrate plan disclosure, action description, fatal-error, and other remaining colors; put disclosure transition under reduced-motion rules or reuse the central rule.
4. `src/responsive.css`: add only theme-owned responsiveness needed for 44px targets and make `.settings-grid` one column at the existing narrow breakpoint; do not change Mode 1 architecture. Confirm theme group focus is not clipped. If no change is needed after computed inspection, record that explicitly rather than touch the file.
5. `src/App.tsx`: add semantic state attributes only where required: `type="button"` for non-submit buttons, `aria-current="page"` for active navigation, `aria-pressed` only for genuine pressed choice controls, and label associations/disabled reasons revealed by focused audit. Keep the header controls as actions (“Switch to …”), not falsely selected buttons. Do not change settings/domain behavior.
6. Focused UI test file(s), following current test conventions discovered by Implementer (prefer `src/App.test.tsx` if already established; otherwise one `src/theme.test.tsx`): assert theme dataset switching, header accessible action names, navigation current semantics, Settings select values/labels, disabled semantics, and absence of state regression. CSS computed contrast is verified with browser tooling, not snapshots alone.
7. `docs/archive/2026-09-05/design/TASK-DESIGN-THEME/IMPLEMENTATION.md` or the Orchestrator-approved Task change record: record mapping, deviations, exact contrast measurements, captures, and test evidence. Update `CHANGE_CONTROL.md`; update Project Map only if file/component boundaries actually change. User-facing guidance changes only if behavior changes beyond appearance.

The present design pass changes none of those production/evidence files; they are instructions for Participant C after the Human Design Gate.

## 11. Verification plan and required evidence

### Automated focused checks

- Existing tests, theme-focused component tests, `npm run typecheck`, `npm test`, and `npm run build` after implementation.
- Static checks: no legacy variable use; no unexplained color literals in migrated component CSS; both theme blocks define identical semantic token names; no remote URLs/assets.
- Component assertions test semantics and state transitions, not pixel snapshots alone.

### Independent functional/visual matrix

Run in Electron and W1 independently, dark and light:

- representative wide desktop, 1000px boundary, 720px narrow breakpoint, and the project-supported minimum; browser 200% zoom at representative desktop width;
- header language/theme actions; every Settings select; navigation; each input/textarea/checkbox/select; segment/options; primary/secondary/destructive/icon buttons; disabled/busy samples; modal buttons; plan disclosure; orchestration controls/gates; links/details; success/warning/danger/information examples;
- mouse default/hover/pressed, keyboard Tab/Shift+Tab/Enter/Space/arrows/Escape where relevant, selected/current, focus-visible, disabled and selected-disabled;
- computed foreground/background/border/outline values and exact contrast ratios, including focus against both component and surrounding surface;
- no body horizontal overflow or hidden critical action, 44px targets at narrow layout, readable forms at 200%, theme group ring not clipped;
- `prefers-reduced-motion: reduce`: no spinner rotation or nonessential transition while busy/status text remains understandable;
- native select closed control and open popup in Electron Chromium and W1 target Chromium. Record OS-controlled popup deviations.

Required package: before/after computed-style excerpts for UX-03, paired dark/light captures per host and width, keyboard focus captures, contrast report, reduced-motion evidence, focused test output, typecheck/build/test output, and residual platform differences. Packaging/lighthouse/Electron/web E2E commands remain excluded from this design-only pass; the Test Engineer uses the approved later test plan.

## 12. Design Sprints and mandatory MSS lifecycle

Each MSS below explicitly records lifecycle steps: objective; current-state inspection; intended design artifact; bounded design work; focused validation; result/deviation; status. “Files” in this design pass always means this `DESIGN.md` only.

### Sprint 1 — Existing-state discovery

Objective: establish authoritative scope, brand evidence, legacy-token defects, and complete control inventory. Entry: governing documents available. Included: mandate/backlog, assets, CSS, `App.tsx`, shared theme schema. Excluded: production edits and live rendering.

- **MSS 1.1 — Mandate/backlog.** Objective reconfirmed: TASK-DESIGN-THEME/UX-03 only. Inspected all named sources and supplemental §§1–6, 12–13, 30–31. Intended artifact: authority/scope sections. Work: reconciled objective, non-goals, risks, criteria. Validation: checked design scope against backlog. Result: no conflict/dependency. Deviation: none. **Complete.**
- **MSS 1.2 — Brand/current CSS.** Objective: ground palette in evidence. Inspected all `src/assets` files, runtime import, `styles.css`, `extras.css`, `polish.css`, `responsive.css`. Intended artifact: source evidence and migration inventory. Work: inspected actual RGBA logo and identified legacy variables/literals. Validation: runtime import points to transparent v2 mark; chroma green excluded. Result: logo-derived palette is feasible. Deviation: no formal existing extracted palette was found. **Complete.**
- **MSS 1.3 — Controls/schema.** Objective: inventory current interactions and compatibility. Inspected `App.tsx`, `Settings.theme`, imports and bridge boundary. Intended artifact: state table and impact. Work: grouped every current control family and theme-setting path. Validation: union remains dark/light; shared UI serves both hosts. Result: no schema migration. Deviation: native popup rendering requires later host measurement. **Complete.**

**Sprint 1 consolidation/checkpoint:** All evidence converges on incomplete semantic coverage rather than a theme-state/domain defect. Actual logo establishes violet/lavender/indigo; current cream accent is legacy, not binding. UX-03 is caused by dark literals and partial light overrides. Files changed: this design record only. Focused validation: source cross-check and `rg` inventory. New finding: keyed chroma green is non-brand. Residual risk: OS-native control rendering. Ready for Sprint 2: **Yes**.

### Sprint 2 — Token definition

Objective: define complete dark/light semantic APIs, relationships, contrast and restraint. Entry: Sprint 1 consolidated. Included: token values/rationale. Excluded: component CSS implementation.

- **MSS 2.1 — Dark tokens.** Reconfirmed dark-primary professional nebula objective; inspected logo/current dark surfaces; artifact: §3.1; bounded work: complete minimum list plus status-muted/disabled/shadow tokens; validation: semantics cover all inventoried uses and avoid purple-only status; result recorded; no deviation. **Complete.**
- **MSS 2.2 — Light tokens.** Reconfirmed intentional counterpart; inspected current cream light overrides; artifact: §3.2–3.3; bounded work: neutral-violet surfaces and darker plum actions; validation: same token keys, no mechanical inversion, readable accent pairing; result recorded; no deviation. **Complete.**
- **MSS 2.3 — Contrast/motion.** Reconfirmed accessibility/reduced-motion criteria; inspected focus/spinner/disclosure rules; artifact: §4; work: AA targets, ring model, motion limits; validation: checked against §§30.5–7, 14–15 and §31.17–18; result: implementation must measure exact ratios; deviation: design estimates are not substituted for browser evidence. **Complete.**

**Sprint 2 consolidation/checkpoint:** A single identical semantic API now has complete theme assignments. Light deliberately uses darker plum; semantic statuses depart from the logo for clarity. Exact computed ratios remain implementation/test evidence, not an open design choice. Files changed: design only. Residual risk: target-engine anti-aliasing/native controls. Ready for Sprint 3: **Yes**.

### Sprint 3 — Dark-mode application design

Objective: map dark tokens to current component hierarchy without decoration. Entry: stable token API. Included: dark surfaces/components/states. Excluded: layout redesign.

- **MSS 3.1 — Structural surfaces.** Reconfirmed neutral-work-surface hierarchy; inspected header/body/panels/modal/footer/previews. Artifact: §§2, 5, 10. Work: mapped canvas, primary/secondary/elevated/muted/overlay roles. Validation: §§30.1–2, 9, 11, 13. Result: optional static canvas tint only. Deviation: none. **Complete.**
- **MSS 3.2 — Dark control/status application.** Reconfirmed every current state must remain visible; inspected all control selectors. Artifact: §5. Work: common state contract and differentiated statuses. Validation: token coverage against inventory and §30.4–8. Result: no component needs a raw dark literal. Deviation: none. **Complete.**

**Sprint 3 consolidation/checkpoint:** Dark application communicates brand through canvas/accent/focus while forms/logs remain neutral and opaque. Every interaction has a semantic state mapping. Files changed: design only. Residual risk: migration breadth requires bounded implementation passes. Ready for Sprint 4: **Yes**.

### Sprint 4 — Light-mode application design

Objective: make light a complete coherent theme and eliminate partial overrides. Entry: dark mappings complete. Included: complementary surfaces/control/native behavior. Excluded: automatic inversion.

- **MSS 4.1 — Light structural mapping.** Reconfirmed professional complementary theme; inspected current light selectors. Artifact: §§3.2–3.3, 5. Work: mapped every structure to the same semantics. Validation: no dark literal is required and §30.3/12 holds. Result: remove component-specific light patches. Deviation: none. **Complete.**
- **MSS 4.2 — Native controls.** Reconfirmed select/form legibility; inspected Settings and other selects. Artifact: §§5, 10–11. Work: `color-scheme`, explicit closed-control tokens, platform-popup acceptance. Validation: checked UX-03 across default/hover/selected/focus/disabled. Result: honest native limitation and measurement plan. Deviation: popup appearance cannot be guaranteed identical across OSes. **Complete.**

**Sprint 4 consolidation/checkpoint:** Light mode is a full token assignment, not an override list. Closed native controls are fully styled; open popup must be legible but may remain platform-native. Files changed: design only. Residual risk documented. Ready for Sprint 5: **Yes**.

### Sprint 5 — Control-state fixes (UX-03)

Objective: finalize header theme/language and Settings-select UX plus shared control semantics. Entry: both themes mapped. Included: UX-03 and relevant semantics. Excluded: behavior redesign/idempotency.

- **MSS 5.1 — Header controls.** Reconfirmed action intent; inspected labels/toggle code and `.theme`. Artifact: §5 and UX-A/B. Work: preserve next-action labels, 44px targets, semantic states, avoid false pressed semantics. Validation: answered all 15 UX questions and §§30/31. Result: implementation-ready. Deviation: no selected state because these are action toggles, not visible choice-set members. **Complete.**
- **MSS 5.2 — Settings selects.** Reconfirmed IDE/language/theme choice intent; inspected markup/styles/schema. Artifact: §5 and UX-C. Work: native state/label/narrow/disabled contract. Validation: all 15 questions and UX-03 states checked. Result: implementation-ready. Deviation: OS popup parity is evidence-qualified. **Complete.**
- **MSS 5.3 — Shared states.** Reconfirmed consistency across every current interactive family; artifact: state table and UX-D. Work: selected/focus/disabled/status semantics. Validation: all 15 questions, §30 matrix, §31 trace. Result: later Tasks can consume foundation without behavior claims. Deviation: none. **Complete.**

**Sprint 5 consolidation/checkpoint:** UX-03 has an explicit correction for both header and Settings, including all requested states. Selected/current is used only where semantically true; focus composes; disabled differs from unsupported. Files changed: design only. Residual risk: implementation must align ARIA and executable state. Ready for Sprint 6: **Yes**.

### Sprint 6 — Verification and delivery design

Objective: provide exact file order, migration, security, tests, evidence, and gate package. Entry: UX decisions finalized. Included: implementation handoff/verification. Excluded: production execution.

- **MSS 6.1 — Impact/migration.** Reconfirmed no undocumented Implementer decisions; inspected architecture boundaries. Artifact: §§9–10. Work: exact files/order, legacy mapping, schema/security/rollback. Validation: master Participant B requirements all explicit. Result: no domain migration. Deviation: test filename may follow existing convention discovered at implementation; required assertions are fixed. **Complete.**
- **MSS 6.2 — Verification matrix.** Reconfirmed evidence criteria; inspected backlog required evidence and command exclusions. Artifact: §11. Work: host/theme/state/viewport/zoom/motion/contrast matrix. Validation: every backlog and §30 criterion has evidence. Result: independent-test-ready. Deviation: design-only pass did not run prohibited/live suites. **Complete.**
- **MSS 6.3 — Final design validation.** Reconfirmed authoritative objective; artifact: complete document. Work: cross-checked token minimum list, dark/light rationale, every current control family, UX-03, four 15-question records, §30/§31 traces, impacts and sprint lifecycle. Focused validation: source/mandate/schema review and repository diff scope. Result: design gate package complete. Deviations/new findings: only native popup variance and lack of prior extracted palette, both documented. **Complete.**

**Sprint 6 consolidation/checkpoint:** The design is implementation-ready across UX, visual system, domain/schema, migration, security, compatibility, file order, testing, evidence, and rollback. All design MSS are stable and complete. Production remains blocked solely by the Human Design Gate, as required. Files changed: `docs/archive/2026-09-05/design/TASK-DESIGN-THEME/DESIGN.md` only. Ready for design-gate packaging: **Yes**.

## 13. Open questions and gate recommendation

No owner decision is required to implement this bounded design. The Orchestrator should confirm only that the documented native-select popup variance is acceptable as a measured platform constraint, not a pixel-parity requirement. If exact contrast measurement finds a proposed token below its stated target in a real target engine, the Implementer may make the smallest same-family value correction, record old/new value and rationale, and return it through the Sprint checkpoint; a semantic or brand-direction change requires Orchestrator escalation.

Recommendation: package for the Human Design Gate. Do not start production implementation before approval.
