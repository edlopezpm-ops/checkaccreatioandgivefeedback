# TASK-PARTICIPANT-INSTANCES — Design record

Status: design complete; implementation remains gated by Human Design Gate and, for expanded Mode 1 emission, the AEKR contract decision recorded below. Issue owned: EXT-03. Authority: `docs/archive/2026-09-05/design/TASK_BACKLOG.md` lines 35–62. This record designs only this Task; it does not redesign the Mode 1 dialog, providers, funding, or upstream AEKR.

## Outcome and invariants

Replace the collapsed “agent = unique role” model with an ordered `ParticipantInstance`. A participant has a stable opaque identity and one canonical role assignment; roles may repeat. The array is the sole execution/display order. Valid project topology is 1–6 participants. A role describes responsibility, never identity. “Auditor” continues to mean an independently realized audit participant; changing another participant's role or asking an implementer to review itself never satisfies that claim.

Determinism means the same normalized definition produces byte-identical ordered artifacts (apart from the existing explicit `createdAt` provenance field). Reordering moves an existing participant, including its ID and Mode 1 assignment, rather than changing its identity. Labels remain descriptive user text and are neither identifiers nor adapter keys.

## Sprint 1 — Existing-model discovery

Objective: establish the current schema and all identity-collapse points. Entry: mandate, supplemental prompt, orchestration log, reproduction report, and authoritative backlog read. Included: current domain, UI reconciliation, draft normalization, generation, tests, desktop/web writers. Excluded: fixes and live/prohibited test suites.

### MSS 1.1 — Canonical domain and validation

1. Reconfirm objective: locate identity, role, bounds, and validation. 2. Inspect: `shared/domain.ts`, `src/types.ts`, `src/core.ts`. 3. Intended artifact: this discovery record only. 4. Bounded design work: traced `AgentRole`, `MAX_AGENTS = 4`, unique-role validation, role-set orchestration comparison, and re-exports. 5. Focused validation: compared declarations with EXT-03 evidence/backlog criteria. 6. Result: identity is an arbitrary `id`, but every meaningful association and validation is role-keyed. 7. Deviations/findings: `src/types.ts` is a re-export boundary, not a second schema. 8. Status: complete.

### MSS 1.2 — State, reconciliation, and persistence

1. Reconfirm objective: find creation, editing, association, and restore behavior. 2. Inspect: `src/App.tsx`, `src/draftStore.ts`, draft tests. 3. Intended artifact: this state-flow record. 4. Work: traced random initial IDs, next-unused-role addition, disabled duplicate roles, cap four, role-keyed Mode 1 enable/reconciliation/edit, and W1 schema-v2 shallow normalization. 5. Validation: checked every `agents`/`orchestration.roles` state path. 6. Result: changing a role implicitly changes orchestration identity; duplicate roles cannot be reconciled. 7. Finding: stored schema version is ignored during normalization and malformed nested values are trusted. 8. Status: complete.

### MSS 1.3 — Generated contracts

1. Reconfirm objective: determine what each artifact says. 2. Inspect: `generatePrompt`, `governance`, `projectSignature`, `renderOrchestrationConfig`, `electron/main.ts`, `src/webExport.ts`, generation tests. 3. Intended artifact: serialization finding. 4. Work: traced common desktop/web generators. 5. Validation: compared output shape with current types and fixtures. 6. Result: prompt/governance/provenance preserve array order and current IDs only in provenance; YAML has ordered role steps but adapters are keyed by canonical role. 7. Finding: `projectSignature.schemaVersion` is 1 and its `plannedAgents` embeds the old type. 8. Status: complete.

### MSS 1.4 — AEKR boundary

1. Reconfirm objective: prove sufficiency or isolate the exact gap. 2. Inspect: consumed schema comments/emission, AEKR launch boundary, orchestration snapshot types, repository documentation; upstream is unavailable per the Orchestrator log. 3. Intended artifact: compatibility decision. 4. Work: tested the schema structurally against two same-role participants. 5. Validation: a YAML mapping cannot contain two independently addressable `Arquitecto` adapter entries; `role_sequence` has no instance ID or adapter reference. 6. Result: current contract cannot preserve repeated-role identity/provider assignment; six instances necessarily repeat one of four roles. 7. Deviation: runtime acceptance cannot be verified without the independent upstream repository. 8. Status: complete, exact gap escalated.

Sprint 1 consolidation: The project array is ordered but identity is operationally discarded. Mode 1 is coupled by role equality. All artifact writers share domain generators, so one domain migration can keep hosts aligned. Expanded Mode 1 is impossible to represent honestly in the consumed contract as-is. No files changed during discovery.

## Sprint 2 — Domain type and validation design

Objective: define an implementation-ready participant contract. Entry: Sprint 1 consolidated. Included: shared domain/types and pure validation. Excluded: provider-registry redesign and UI layout.

### MSS 2.1 — Exact types and vocabulary

1. Reconfirm objective: separate instance identity from role. 2. Inspect: current declarations/re-exports and downstream names. 3. Intended implementation files: `shared/domain.ts`, then `src/types.ts`. 4. Design decision: make these literal changes:

```ts
export const MIN_PARTICIPANTS = 1;
export const MAX_PARTICIPANTS = 6;
export type CanonicalRole =
  | "generalist" | "architect" | "implementer" | "auditor";
export type ParticipantId = string;
export interface ParticipantInstance {
  id: ParticipantId;
  role: CanonicalRole;
  label: string;
}
export interface OrchestrationParticipantConfig {
  participantId: ParticipantId;
  provider: OrchestrationProvider;
  task?: string;
}
export interface OrchestrationConfig {
  enabled: boolean;
  participants: OrchestrationParticipantConfig[];
  sessionMaxDurationSeconds: number;
  maxIterationsPerEntity: number;
  maxProviderInvocations: number;
  maxConsecutiveFailures: number;
}
export interface ProjectDefinition {
  // unchanged fields omitted
  participants: ParticipantInstance[];
  orchestration: OrchestrationConfig;
}
```

Remove `MAX_AGENTS`, `Role`, `AgentRole`, `OrchestrationRoleConfig`, `ProjectDefinition.agents`, and `OrchestrationConfig.roles` after migration call sites are atomic. Do not retain aliases in the final internal model: they invite new role-keyed code. `src/types.ts` imports/exports the new canonical names only. `defaultRoleTask(role: CanonicalRole, ...)` remains role-based because responsibility templates are role semantics. New blank projects use `[{id: "participant-01", role: "generalist", label: localized responsibility}]`; UI addition chooses the lowest unused `participant-NN` in 01–06, while reorder/removal never rewrites surviving IDs.

5. Validation: type shape checked against prompt, governance, provenance, Mode 1, draft, and later provider dependency. 6. Result: every assignment joins through `participantId`; order exists only once in `project.participants`. 7. Finding: provider registry can later attach cleanly without redefining identity. 8. Status: complete.

### MSS 2.2 — Exact validation rules

1. Reconfirm objective: reject ambiguity while permitting repeated roles. 2. Inspect: current `validationErrors`. 3. Intended implementation: `shared/domain.ts`; focused tests in `tests/core.test.ts` and generation tests. 4. Decision:

- `participants.length` must be integer-bounded by 1 and 6 through array length.
- Every `id` must equal its trimmed form, be 1–64 characters, and match `/^[A-Za-z0-9][A-Za-z0-9._-]*$/`; IDs are case-sensitive and unique. This safe subset prevents Markdown/YAML ambiguity without executing user text.
- Every role must be one of the four canonical values. Repetition is valid. `label` is trimmed for display when generated, may be empty, and is limited to 120 characters; it never establishes identity.
- Array position is the deterministic order. No mutable `order` property is added, avoiding two competing orders.
- When Mode 1 is enabled, `orchestration.participants` must have exactly one entry per planned participant ID, no duplicates/extras/missing IDs, and the same order as `project.participants`. Each referenced participant must exist, each task must trim nonempty, provider/limit validation remains otherwise unchanged. Role is resolved from the participant and is not duplicated in orchestration state.
- Use distinct error codes: `participantCount`, `invalidParticipantIdentity`, `duplicateParticipantIdentity`, and `invalidOrchestrationParticipants`; remove `uniqueRolesRequired`. Repeated roles never error.
- Independent-audit integrity: any generated `EXECUTE_INDEPENDENT_AUDIT` must resolve to an `auditor` participant, but the presence of that role alone is not proof of a distinct live context. Governance and bootstrap warning must say so. No validation rule forces an auditor into every project.

5. Validation: boundary matrix 0/1/6/7, repeated roles, duplicate/unsafe IDs, mismatched/reordered Mode 1 mappings, and auditor semantics. 6. Result: identity, role, order, and audit honesty are independently testable. 7. Deviations: no general schema library is added. 8. Status: complete.

Sprint 2 consolidation: The final internal vocabulary is participant/participant ID/canonical role. IDs are stable safe strings, array order is authoritative, repeated roles are legal, and Mode 1 config is a one-to-one ordered association by ID. This does not force six or require an auditor.

## Sprint 3 — Lossless migration design

Objective: specify literal current-to-new behavior. Entry: Sprint 2 stable. Included: W1 drafts, in-memory initialization, generated provenance compatibility. Excluded: importing generated project files as editable drafts (no such path exists).

### MSS 3.1 — Pure migration function

1. Reconfirm objective: preserve every valid legacy definition's meaning and order. 2. Inspect: `normalizeDraft`, schema envelopes, legacy/current fixtures. 3. Intended implementation: add pure helpers in `shared/domain.ts`; call from `src/draftStore.ts`; tests in `tests/draftStore.test.ts`. 4. Literal behavior:

```ts
migrateProjectDefinition(raw, fallback): ProjectDefinition | null
```

If `raw` is a `{schemaVersion, project}` envelope, read `project`; otherwise treat `raw` as legacy W1-v1 direct project. Reject non-objects. If `participants` is an array, normalize the new shape and do not also consume `agents`. Otherwise map legacy `agents` in original index order to participants. For each valid legacy agent at zero-based index `i`: preserve its nonempty, unique, safe `id` verbatim; otherwise assign the first unused `participant-NN`, scanning 01–06. Copy `role` unchanged and copy `label` unchanged. A valid current 1–4 unique-role draft therefore loses no ID, label, role, or order.

For orchestration: if new `participants` exists, normalize it. Otherwise map each legacy `orchestration.roles` entry in its original order to the first not-yet-matched migrated participant with the same role, setting `participantId` to that participant's ID and copying `provider` and `task` byte-for-byte. Current valid unique-role drafts always yield one exact match. Then append configs for any unmatched planned participant, in planned order, using `claude_code` and `defaultRoleTask(participant.role, project.name)`. Discard legacy orchestration entries with no matching participant only when the overall stored value was already invalid, and return a migration diagnostic so the UI can state that Mode 1 needs review; never silently make an invalid draft executable. Copy all limit values through the existing fallback/validation behavior. Force web-only action/destination/attachment normalization afterward as today.

Envelope version becomes `DRAFT_SCHEMA_VERSION = 3`; saving always writes new names. Reading versions 1, 2, 3 and unversioned legacy values remains supported. Unknown future versions return `null` rather than being shallow-merged. The helper returns `{project, warnings}` (or `null`) so recovered invalid data is visible; `normalizeDraft` may retain its public wrapper if tests/callers need it.

Generated `.accreatio/project.json` becomes `schemaVersion: 2` and `plannedParticipants: project.participants`; it does not retain misleading `plannedAgents`. Version 1 remains a readable historical artifact, but is not currently ingested by accreatio. Document the v1→v2 field mapping.

5. Validation: literal fixtures for unversioned/v1/v2, all four legacy roles, missing IDs, corrupt duplicate IDs, missing orchestration tasks, new v3, and future-version rejection. 6. Result: every valid legacy definition is order/identity/role/label/provider/task/limit preserving. 7. Finding: UUID legacy IDs already satisfy the safe ID grammar. 8. Status: complete.

### MSS 3.2 — Initialization and identity lifecycle

1. Reconfirm objective: prevent post-migration identity churn. 2. Inspect: desktop/web initial state, Add/remove/change-role/reconciliation. 3. Intended implementation: `src/App.tsx` state helpers, preferably pure identity allocation in `shared/domain.ts`; focused component/core tests. 4. Decision: changing role mutates only `role`/default label; its `id`, Mode 1 provider, and edited task stay attached. Removing removes the matching orchestration entry by `participantId`. Adding allocates the lowest unused 01–06 ID, appends it, and appends config only when Mode 1 is enabled. Reordering moves both participant display order and the derived config order by ID. Restoring never regenerates a valid ID. 5. Validation: add/change/reorder/remove/restore sequences. 6. Result: identity is stable throughout normal editing. 7. Deviation: actual reorder UI belongs to later Mode 1 UX if none is exposed in this Task; domain functions still define it. 8. Status: complete.

Sprint 3 consolidation: Valid legacy drafts migrate losslessly and deterministically; corrupt/unknown data fails closed or produces a visible review warning. Schema versions advance independently for W1 draft envelope (3) and generated provenance (2). No generated project import capability is invented.

## Sprint 4 — Generation, serialization, security, and AEKR decision

Objective: preserve identity honestly across all outputs and define the upstream boundary. Entry: migration stable. Included: prompt, governance, provenance, YAML. Excluded: changing AEKR without approval.

### MSS 4.1 — Prompt, governance, and provenance

1. Reconfirm objective: expose participant identity and order without conflating role. 2. Inspect: shared generators and both writer paths. 3. Intended implementation: `shared/domain.ts`; fixtures in `tests/core.test.ts`/`tests/webExport.test.ts`. 4. Decision: each prompt/governance line uses `N. [participantId] Canonical role — optional label`; headings become “Planned participants”. Governance explicitly says repeated roles are separate planned instances, availability must be checked per instance, and an auditor is independent only when realized in a separate context/tool invocation from the work it audits. Provenance v2 stores `plannedParticipants` in array order. User strings continue to be interpolated as text/JSON, never command arguments. Markdown should escape control characters/newlines in ID/label; ID validation already excludes them. 5. Validation: exact one/four-legacy/six-with-repeats fixtures plus repeat-generation equality and desktop/web shared-output equality. 6. Result: human and machine artifacts preserve ID, role, label, and order honestly. 7. Finding: locale translates role labels, never participant IDs. 8. Status: complete.

### MSS 4.2 — Current YAML sufficiency finding

1. Reconfirm objective: decide whether current consumed AEKR YAML is sufficient. 2. Inspect: emitted `role_sequence`, `adapters`, action kinds, and launch/snapshot boundary. 3. Intended artifact: this exact escalation; no upstream edit. 4. Finding: **not sufficient**. Current shape is effectively:

```yaml
role_sequence:
  - role: Arquitecto
adapters:
  Arquitecto: { kind: codex }
```

It has no participant/step identity and adapter selection is keyed by role. Two architects may produce two sequence entries, but both collapse to the same mapping key and cannot retain distinct provider/configuration or stable identity. With four canonical roles, any five- or six-participant topology necessarily triggers that ambiguity. Accreatio must not invent role aliases because AEKR's role vocabulary and audit/write semantics are canonical.

The minimal upstream capability to evaluate/approve is: (a) a stable `participant_id` on every ordered sequence entry; (b) adapter/config binding keyed by or explicitly referenced from that participant ID rather than canonical role; (c) canonical `role` retained separately for permissions/action semantics; (d) runtime state/evidence exposes `participant_id` so gates and audit provenance remain attributable; (e) schema validation accepts 1–6 entries and repeated canonical roles while rejecting duplicate participant IDs. Illustrative target, not authority to implement:

```yaml
participants:
  participant-01: { role: Arquitecto, adapter: participant-01 }
  participant-02: { role: Arquitecto, adapter: participant-02 }
role_sequence:
  - participant_id: participant-01
    action_kind: EXECUTE_ROLE_STEP
    task: "Design A"
  - participant_id: participant-02
    action_kind: EXECUTE_ROLE_STEP
    task: "Design B"
adapters:
  participant-01: { kind: claude_code }
  participant-02: { kind: codex, sandbox: read-only }
```

5. Validation: structural collision proof plus required six/repeated fixture. 6. Result: exact upstream gap established; proposed keys are illustrative until AEKR owns/version-controls them. 7. Deviation: upstream runtime/schema unavailable, so no claim of compatibility. 8. Status: complete with escalation.

### MSS 4.3 — Safe compatibility behavior

1. Reconfirm objective: avoid false capability while preserving legacy use. 2. Inspect: current validation/generation and product honesty rules. 3. Intended implementation: `shared/domain.ts`, `src/App.tsx` status/error copy, generation tests, contract docs. 4. Decision: project planning/prompt/governance/provenance support all valid 1–6 topologies immediately. Mode 1 YAML generation under the existing contract is allowed only when participant roles are unique and count is 1–4; it emits the current role-keyed schema and adds comments correlating each participant ID to its unique role. If Mode 1 is enabled for repeated roles or 5–6 participants, validation returns `orchestrationContractUnsupported` and blocks save/execution/export of a claimed runnable YAML while preserving all input. UI copy says the project topology is valid but this installed/consumed AEKR contract cannot run it; Mode 0/manual workflow remains available. Do not silently drop, merge, reassign, or serialize aliases. After AEKR publishes and accreatio verifies a versioned participant-aware schema, a separately approved implementation may emit it and detect/reject older runtimes. 5. Validation: unique legacy YAML unchanged except identity comments; repeated/5/6 fail closed; no partial ZIP/desktop write claims. 6. Result: backward compatibility without dishonest expanded execution. 7. Finding: full Task acceptance criterion for expanded Mode 1 cannot be claimed until upstream resolution. 8. Status: complete design, implementation dependency open.

Sprint 4 consolidation: Prompt, governance, and provenance can adopt the model entirely within accreatio. Current AEKR YAML cannot. The compatibility branch preserves existing Mode 1 and blocks only unrepresentable expanded configurations with recoverable, honest guidance.

## Sprint 5 — Mismatch handling and UX contract

Objective: preserve Planned-agent integrity and define affected UX without redesigning the dialog. Entry: artifacts and AEKR boundary settled. Included: participant controls/status language and bootstrap governance. Excluded: visual-system implementation and full Mode 1 IA.

### MSS 5.1 — Planned-versus-available reconciliation

1. Reconfirm objective: keep the human gate when availability is lower than plan. 2. Inspect: current generated `AGENTS.md`, provider availability, and mandate. 3. Intended implementation: governance/prompt generation and later bootstrap/runtime contract documentation; no automatic topology mutation. 4. Decision: availability comparison is a count of independently realizable participant instances, not a set of roles or installed provider kinds. For each planned ID in order, bootstrap records `available`, `unavailable`, or `unverified` plus the concrete context/tool allocation. Any unavailable/unverified instance, any shared context proposed for an auditor and audited work, or inability to prove independence triggers a warning before execution. Choices are: configure the missing instance(s); continue in Mode 0/manual; explicitly approve a displayed reduced topology; or cancel. Reduction creates a proposed new ordered participant list and requires confirmation; it never mutates the saved plan or generated provenance silently. Removing an auditor removes the independent-audit claim; assigning its work to an existing worker is labeled self-review, not audit. Provider installation count alone never proves six independent contexts. 5. Validation: fixtures for exact availability, shortfall, repeated roles, shared auditor context, explicit reduction, cancel. 6. Result: AGENTS.md integrity rule remains stronger under instance identity. 7. Deviation: actual AEKR bootstrap implementation is upstream; accreatio can emit governance and preflight guidance but cannot claim enforcement until upstream evidence exists. 8. Status: complete.

### MSS 5.2 — UX decision A: participant identity and repeated roles

1. Reconfirm objective: make the new domain understandable in the existing editor pending the later dialog Task. 2. Inspect: current ordered rows, labels, Add/remove, responsive constraints. 3. Intended implementation: bounded vocabulary/state changes in `src/App.tsx`; later layout belongs to `TASK-UX-MODE1`. 4. Decision and supplemental §6 answers:

1. Goal: plan 1–6 distinct participants and assign responsibilities. 2. Required: ordered slot and canonical role. 3. Optional: descriptive label. 4. Happy path: add, choose repeatable role, optionally label, then configure Mode 1 by the same participant row. 5. Failures: count/ID/config mismatch or unsupported AEKR Mode 1 topology. 6. Errors name the participant ordinal/ID and corrective action. 7. Input stays intact; invalid save/export is blocked. 8. Saved summary and artifacts show the same ordered IDs. 9. Add disables at six; remove confirms only where saved work would be discarded and never allows zero. 10. Narrow screens stack fields in source order; the later dialog owns dimensions. 11. Native controls and buttons have labeled, logical keyboard order; reorder controls (when added) are buttons, not drag-only. 12. Unsupported Mode 1 is visibly “unsupported by current AEKR contract,” while Mode 0 remains available. 13. UI says participant/role, not adapter-map/schema internals. 14. Terms match artifacts: participant, participant ID, canonical role. 15. Desktop/W1 use identical domain behavior; only host execution availability differs.

5. Validation: review against §5, §6, §31 and downstream Mode 1 Task. 6. Result: UX follows the architecture rather than hiding it. 7. Deviation: no dialog redesign in this Task. 8. Status: complete.

### MSS 5.3 — UX decision B: mismatch/independence warning

1. Reconfirm objective: make reduction informed and recoverable. 2. Inspect: generated warning and available provider status semantics. 3. Intended implementation: governance copy and any existing preflight warning surface; upstream handoff. 4. Decision and §6 answers:

1. Goal: understand and resolve a planned/available instance mismatch. 2. Required: planned IDs/roles, available allocations, missing/unverified instances, audit-independence status. 3. Optional: reason/detail per availability check. 4. Happy path: all allocations verified, then proceed. 5. Failures: shortfall, shared context, unknown status, or unsupported contract. 6. Warning states exactly what cannot be realized and consequence of reduction. 7. Cancel/configure preserves the saved topology and tasks. 8. Proceeding shows the explicitly approved effective topology separately from the plan. 9. No default affirmative action and no automatic reduction. 10. Narrow screens use a linear comparison list with actions after it. 11. Focus enters the warning heading, choices are keyboard reachable, Escape cancels without mutation, focus returns. 12. Unavailable, unverified, unsupported, and disabled are distinct text statuses. 13. Runtime schema details remain in an expandable diagnostic, not primary copy. 14. Terms match governance/provenance and AEKR role vocabulary. 15. Desktop and web artifacts give the same bootstrap instruction; W1 does not pretend to detect local runtime availability. 

5. Validation: scenario review against AGENTS.md and §§5/6/31. 6. Result: a human decision remains mandatory and audit honesty is explicit. 7. Deviation: AEKR must implement runtime allocation enforcement; accreatio cannot substitute provider detection for it. 8. Status: complete.

### MSS 5.4 — Visual decision and §§30–31 acceptance

1. Reconfirm objective: constrain the participant presentation without taking theme/Mode 1 ownership. 2. Inspect: six-row density risks and supplemental criteria. 3. Intended implementation: no new visual tokens here; consume `TASK-DESIGN-THEME` tokens when available. 4. Decision: participant identity is always visible as ordinal plus stable ID; repeated role rows remain separately bordered/labeled; status uses icon/text as well as color; no galaxy imagery, animation, or role-specific purple coding. Six rows use the page/dialog's single intended scroll container and never introduce a nested participant-list scrollbar. At narrow widths and 200% zoom rows stack without horizontal overflow; controls retain visible default/hover/focus/selected/disabled states and keyboard ordering; reduced-motion has no new motion to suppress. Dark/light colors, contrast, focus ring, typography, and controls inherit the approved semantic system so desktop/W1 remain coherent. Long labels/tasks wrap or use the later bounded editor, not clipping. This satisfies §30 items 2, 4–15 for this Task; items 1, 3, 16 are owned by the theme record and are consumed, not redefined. It satisfies §31 items 5, 8–12, 17–20 directly; unrelated funding/attachment/output/idempotency items remain with their authoritative Tasks. 5. Validation: implementation visual matrix at supported widths, both themes/hosts, keyboard, 200% zoom, and reduced motion; no visual claim is complete from static design. 6. Result: six instances are legible without visual scope growth. 7. Deviation: pixel values intentionally deferred to approved theme/Mode 1 designs. 8. Status: complete.

Sprint 5 consolidation: Mismatch is per participant instance and per independently realized context, never per unique role. The two UX decisions answer all 15 required questions. Visual behavior is constrained and routed to existing dependent Tasks rather than duplicated.

## Sprint 6 — Implementation order and verification plan

Objective: leave no undocumented implementation choices and define proportional evidence. Entry: all design decisions consolidated. Included: file plan, tests, docs, gates. Excluded: implementation in this pass.

### MSS 6.1 — Exact file-level implementation sequence

1. Reconfirm objective: give Participant C a coherent atomic order. 2. Inspect: dependency graph and backlog files. 3. Intended artifact: this plan. 4. Sequence:

1. `shared/domain.ts`: introduce participant types/constants, pure ID allocation/migration helpers and validation; rename project/orchestration fields; update prompt, governance, signature v2; retain legacy YAML compatibility guard and do not emit an invented schema.
2. `src/types.ts`: replace old re-exports with participant names; update no unrelated bridge types.
3. `tests/core.test.ts`: update fixtures and add count/ID/repeated-role/order/audit/governance/prompt/provenance tests.
4. `src/draftStore.ts`: bump envelope to v3 and delegate to the pure version-aware migration, exposing warnings.
5. `tests/draftStore.test.ts`: add literal v1/v2/v3/future/corrupt/lossless fixtures.
6. `src/App.tsx`: rename state consumption and reconciliation to ID-keyed behavior; allow repeated roles/up to six; preserve assignments on role change; display migration/unsupported-contract messages. Do not redesign layout.
7. `tests/webExport.test.ts` (the current YAML fixture location): add one/four legacy success, repeat/5/6 fail-closed, provenance v2, and deterministic output tests. If separation improves clarity, create `tests/participantInstances.test.ts`; do not move unrelated tests.
8. `src/core.ts`, `src/webExport.ts`, `electron/main.ts`: update imports/call sites only as required; shared generator remains the single output source. `electron/preload.ts` and bridges require no shape change because they already transport `ProjectDefinition` structurally.
9. Documentation after behavior is approved/implemented: participant/migration/AEKR contract note under `docs/`; `docs/FAQ.md`; `DECISIONS.md`; `CHANGE_CONTROL.md`; and Project Map only if actual module boundaries change. Do not update stale unrelated W2/desktop guidance under this Task.
10. Upstream AEKR work is a separate owner/Orchestrator-approved change. Only after its versioned schema is available may accreatio replace the compatibility guard/emitter and add runtime-version preflight.

5. Validation: order checked against supplemental §14 (contracts→validation→tests→serialization→UI→integration→docs). 6. Result: each step is reviewable and preserves compilation via tightly coupled type/call-site patches where necessary. 7. Deviation: an atomic type rename may touch steps 1, 2, 6, and direct fixtures together; document that coupling in implementation MSS. 8. Status: complete.

### MSS 6.2 — Focused, integrated, regression, and security verification

1. Reconfirm objective: define evidence sufficient for acceptance. 2. Inspect: baseline scripts and current tests. 3. Intended artifacts: tests/evidence during implementation and Test Engineer pass. 4. Plan:

- Focused pure tests: 0/1/6/7 count; repeated roles; valid/invalid/duplicate IDs; unchanged IDs across role edit/reorder; exact Mode 1 ID/order matching; task/limit regression; auditor action only from auditor role.
- Migration fixtures: current one-, two-, and four-role definitions; direct v1, envelope v2, v3; missing/duplicate IDs; missing orchestration; byte-preserved labels/tasks; unknown future version fail-closed; save/reload stability.
- Generation fixtures: one, four legacy, six repeated for prompt/governance/provenance; same input twice is equal with fixed `createdAt`; desktop and web common content; Markdown/YAML-special label text remains inert text.
- AEKR boundary: current unique-role YAML parses/retains existing keys; repeated/5/6 are blocked with the exact error; no alias/collision output. After any upstream approval, add schema-validation and runtime fixture evidence before enabling.
- Mismatch matrix: enough allocations; fewer contexts; repeated roles with enough contexts; auditor sharing audited context; unverified availability; cancel/configure/reduce; saved plan unchanged after effective reduction.
- UX/manual: desktop/W1, dark/light, 1/6, repeat roles, keyboard add/change/remove/reorder where present, error recovery, narrow widths, 200% zoom, no nested scroll, accurate unavailable/unsupported language.
- Security: IDs constrained before serialization; labels/tasks serialized only as Markdown text/JSON-quoted YAML scalars; no user text reaches shell; migration rejects future/ambiguous structures; no new dependency, network, telemetry, secret, commit, or push behavior.
- Commands per allowed implementation phase: focused `node --test` targets, then `npm test`, `npm run typecheck`, `npm run format:check`, and `npm run build`; packaged smoke and functional suites are reserved for the authorized Test Engineer phase, not this design pass.

5. Design validation: checked against backlog required evidence and supplemental §§21–26, 30–31. 6. Result: evidence distinguishes focused, integrated, and regression checks. 7. Deviation: no tests run now because this record changes no production behavior; baseline 41/41 and clean typecheck are already recorded by the Orchestrator. 8. Status: complete.

### MSS 6.3 — Risks, rollback, dependencies, and gate readiness

1. Reconfirm objective: close design with explicit residuals. 2. Inspect: backlog risks and Task sequencing. 3. Intended artifact: final handoff. 4. Decisions: rollback is the participant-contract implementation checkpoint as one Task boundary; never downgrade saved v3 data silently. Provider registry and funding attach to `participantId`; Mode 1 UX consumes this contract. Primary risks are identity churn, corrupt shallow migration, artifact drift, false audit independence, and claiming unsupported AEKR execution; the preceding validation/compatibility rules mitigate each. Category C blocker: expanded Mode 1 upstream contract. No specialist activation is justified yet. 5. Validation: master/supplemental/backlog cross-check. 6. Result: design is ready for Orchestrator consistency review/Human Design Gate, but implementation cannot claim full expanded-Mode-1 acceptance until the owner decides the upstream escalation. 7. Deviations: none beyond the evidenced AEKR gap. 8. Status: complete.

Sprint 6 consolidation: The implementation order, security posture, migration evidence, UX/visual matrix, documentation impact, rollback boundary, and upstream dependency are explicit. No production file or upstream contract has been changed.

## Design-gate decisions and open questions

Decisions recommended for approval:

- Adopt `ParticipantInstance`/`CanonicalRole`, 1–6, repeatable roles, stable safe IDs, and array order as the single order.
- Migrate valid legacy definitions literally as specified; W1 envelope v3 and provenance v2.
- Join all Mode 1 assignment state by participant ID, never role.
- Preserve current unique-role AEKR YAML compatibility; fail closed for unrepresentable expanded Mode 1.
- Escalate the participant-keyed AEKR schema/runtime evidence contract separately; do not invent aliases or claim upstream support.

Open questions requiring Orchestrator/owner disposition before full implementation acceptance:

1. Authorize a separate AEKR contract investigation/change request for participant IDs, per-instance adapter binding, repeated roles, 1–6 entries, and runtime participant evidence?
2. If upstream change is deferred, approve shipping the participant model for planning/Mode 0 with the explicit current-AEKR Mode 1 compatibility block described above, understanding the Task's expanded Mode 1 acceptance remains partial?

## Task handoff summary

Objective: one-to-six stable participant instances distinct from canonical role. Sprints designed: six, all design MSS complete. Contracts changed by the approved future implementation: `ProjectDefinition`, `OrchestrationConfig`, W1 draft schema v3, provenance schema v2; existing AEKR YAML unchanged for compatible topologies. User-visible behavior: repeatable roles, six participants, stable ordered identity, honest unsupported-contract and mismatch warnings. Known limitation: current AEKR contract cannot represent expanded Mode 1. Dependencies created: provider registry, funding, and Mode 1 UX consume `participantId`. Required evidence and rollback are specified in Sprint 6.
