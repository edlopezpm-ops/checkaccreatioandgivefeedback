# SPRINT1-2-UX-AUDIT-DESIGN-DIRECTION — Current UX audit

Date: 2026-08-05. Scope: static, source-grounded audit of the current shared React UI in desktop and web hosts. This is design evidence, not an implementation report. The prior increment at `635f5b4` is the baseline: its semantic theme and Mode 1 dialog are treated as shipped behavior.

## 1. Product and users

accreatio is a zero-direct-cost, local-first launch point: it turns a small project definition into a deterministic prompt, governance/discovery material, configuration, and safe filesystem or ZIP output. It does not provide real authentication, billing, analytics, cloud project storage, or paid AI execution.

Minimal personas and jobs:

1. **First-time project starter (non-technical).** “Help me describe an idea, choose sensible defaults, and download a project I can hand to AI tools without learning orchestration first.” The web host explicitly promises no account/server/local execution and ZIP output (`src/components/WebExperience.tsx:27-33`).
2. **Local builder.** “Create a reproducible local repository safely, optionally initialize Git/open my IDE, and show exactly what will happen before writing.” Dry-run defaults on (`src/App.tsx:242-257`), and the confirmation enumerates destinations and limitations (`src/App.tsx:1611-1698`).
3. **Governance-minded operator.** “Configure and run a human-gated AEKR Mode 1 session using installed subscription CLIs, with limits and durable evidence.” The center describes local, human-gated control (`src/App.tsx:2135-2154`) and explicitly excludes a generic terminal, auto-commit, auto-push, and batch approval (`src/App.tsx:2229-2233`).

## 2. Section 4 hypotheses, one by one

The verdict describes the current repository, after the prior increment.

1. **“Exceso de negro casi absoluto” — PARTIALLY CONFIRMED.** The prior theme work replaced literal black with violet-biased semantics, but the dominant canvas remains `#0b0912`, with panels `#12101b` and controls `#100e17` (`src/styles.css:7-12`, `src/styles.css:36-45`). It is no longer absolute black, yet these values remain perceptually near-black across most of the working area.
2. **“Contraste visual agresivo o poco matizado” — PARTIALLY CONFIRMED.** The shipped system now has primary/secondary/muted text and three border levels (`src/styles.css:13-19`), so the original blanket claim is outdated. The light-on-near-black application canvas and frequent outlined controls still produce a high-frequency, hard-edged composition (`src/styles.css:211-253`, `src/styles.css:304-342`).
3. **“Grandes superficies oscuras sin suficiente profundidad” — PARTIALLY CONFIRMED.** Four dark surface levels and an elevated shadow now exist (`src/styles.css:8-12`, `src/styles.css:45`), plus a radial atmospheric tint (`src/styles.css:50-60`). Their luminance steps are small and the main form/preview remain large flat bordered slabs (`src/styles.css:164-178`, `src/styles.css:383-434`), so depth is semantically present but visually restrained to the point of flattening.
4. **“Sensación de dashboard técnico genérico” — CONFIRMED.** A sticky header, centered pill-like tab bar, two-column panel grid, status footer, settings cards, and orchestration dashboard constitute a conventional admin shell (`src/styles.css:75-171`, `src/App.tsx:704-769`, `src/App.tsx:1530-1563`, `src/App.tsx:2135-2353`).
5. **“Formulario excesivamente largo” — CONFIRMED.** The New Project page renders name, phase, conditional attachments, context, restrictions, route, participants, orchestration, action/destination, and four output toggles in one continuous form before the CTA (`src/App.tsx:794-1437`). Only Mode 1 details have moved into a dialog.
6. **“Demasiados bordes visibles” — CONFIRMED.** Panels, navigation, brand/icon tiles, every field separator, controls, segments, toggles, preview well, and plan rows all add borders (`src/styles.css:93-99`, `src/styles.css:113-143`, `src/styles.css:172-175`, `src/styles.css:211-253`, `src/styles.css:304-342`, `src/styles.css:423-447`).
7. **“Múltiples bloques con peso visual similar” — CONFIRMED.** Form, preview, and plan all use `.panel`; preview and plan share identical padding and similarly sized headings (`src/styles.css:172-175`, `src/styles.css:388-406`). Settings likewise repeats the same panel card (`src/App.tsx:2390-2488`).
8. **“Jerarquía insuficiente entre decisiones primarias y secundarias” — CONFIRMED.** Route, phase, action, orchestration, and ancillary Git/GitHub/IDE switches are rendered with repeated button/select families in the same uninterrupted column (`src/App.tsx:810-850`, `src/App.tsx:1019-1031`, `src/App.tsx:1357-1403`). The 72px accent CTA is clear, but there is no staged hierarchy before it (`src/styles.css:355-381`).
9. **“Navegación superior desaprovechada” — CONFIRMED.** Navigation is only a flat map of two web or five desktop tabs (`src/App.tsx:714-735`); numbered boxes are decorative indices, not progress. It provides no project identity, current-flow progress, contextual help, or primary action.
10. **“Logo como icono independiente” — CONFIRMED.** The imported runtime asset is `src/assets/accreatio-mark-v2.png` (`src/App.tsx:54`). It is placed inside a fixed 46px bordered rounded tile beside the wordmark (`src/App.tsx:705-713`; `src/styles.css:93-103`) and repeated as another isolated tile in About (`src/App.tsx:2537-2544`).
11. **“Controles con patrones muy repetidos” — CONFIRMED.** `Field`, `Seg`, and `Toggle` repeatedly compose icon/label/control rows and outlined rounded choices (`src/App.tsx:1790-1926`; `src/styles.css:211-342`). This consistency is useful, but the repetition makes unrelated decisions feel equivalent.
12. **“Botones y tabs previsibles” — CONFIRMED.** The header is a bordered rounded segmented container with a filled active state and accent underline (`src/styles.css:113-143`); most buttons are rounded bordered rectangles, while primary actions are solid purple (`src/styles.css:407-419`, `src/styles.css:671-692`).
13. **“Preview compite con el formulario” — CONFIRMED.** Desktop permanently assigns `minmax(370px, .88fr)` to the right column (`src/responsive.css:14-18`), where the live prompt preview appears first and has a 265px minimum code well (`src/App.tsx:1439-1459`; `src/styles.css:423-434`). It updates continuously and receives near-equal column weight despite being mostly review material.
14. **“Experiencia de scroll extensa” — CONFIRMED.** The form’s entire field sequence remains in document flow; the preview and plan are additional tall panels (`src/App.tsx:768-1494`). At ≤1000px the two-column grid stacks, placing preview and plan below the already long form (`src/responsive.css:104-132`).
15. **“Demasiada información simultánea” — CONFIRMED.** The new-project state exposes all core inputs, output toggles, full generated prompt, complete action plan, global header, and four-part footer simultaneously (`src/App.tsx:768-1563`). Conditional attachments and Mode 1 reduce some load but do not change the overall disclosure model.
16. **“Limitada sensación de progresión” — CONFIRMED.** There is no step model or completion indicator; validation only disables the final CTA and changes its small caption (`src/App.tsx:1411-1436`). Header numerals enumerate destinations, not creation progress (`src/App.tsx:724-734`).
17. **“About demasiado administrativa” — CONFIRMED.** About is one panel containing version/license, privacy, security implementation claims, legal-document links, copyright, and closing principles (`src/App.tsx:2530-2568`). It explains governance but offers little product story, example, creator context, or next action.
18. **“Lenguaje visual desconectado de futura landing” — PARTIALLY CONFIRMED.** Logo-derived purple tokens and the radial tint create a reusable identity basis (`src/styles.css:7-45`, `src/styles.css:54-60`), and web has a concise local-first intro (`src/components/WebExperience.tsx:23-40`). The admin-tab shell and dense configuration grid still do not establish an editorial marketing-to-product visual bridge.
19. **“Ausencia de transición clara entre marketing, onboarding y producto” — CONFIRMED.** The app’s initial state is directly `tab = "new"` (`src/App.tsx:266-269`) and immediately renders the creation form (`src/App.tsx:768-809`). No landing, sign-in, or onboarding state exists; web only inserts an operational draft banner (`src/App.tsx:787-793`).
20. **“Construida desde componentes antes que intención de producto” — CONFIRMED.** The page is assembled as a serial list of generic `Field`, `Seg`, and `Toggle` primitives followed by generic `.panel` preview/plan cards (`src/App.tsx:794-1493`; `src/App.tsx:1790-1926`). The primitives are competent, but the composition does not express a task narrative.

## 3. Current end-to-end journey

### Shared entry and creation

1. **App bootstrap/error boundary:** `src/main.tsx:23-49` mounts `App`; catastrophic failure becomes a reload screen.
2. **Host initialization:** desktop loads settings, GitHub state, and history; web restores/autosaves a browser draft (`src/App.tsx:317-377`).
3. **Global shell:** brand, tab navigation, language/theme actions, alert region, and status footer (`src/App.tsx:697-767`, `src/App.tsx:1530-1563`). Web exposes New/About; desktop additionally exposes Orchestration, Settings, and History (`src/App.tsx:714-724`).
4. **New Project / restored draft:** one long split-view workspace; web adds its draft/privacy/export intro (`src/App.tsx:768-809`; `src/components/WebExperience.tsx:23-40`).
5. **Define project:** name → phase → conditional source attachments → known context → constraints → route (`src/App.tsx:794-1031`).
6. **Plan participants:** choose 1–6 ordered canonical roles; responsibility is shown beside each (`src/App.tsx:1032-1142`).
7. **Optional Mode 1 configuration:** enable it, then open `Mode1ConfigurationDialog`; the shipped dialog contains participant tasks, provider availability, execution limits, funding, error summary, cancel/save, responsive full-screen behavior (`src/components/mode1/Mode1ConfigurationDialog.tsx:262-565`; `src/extras.css:538-784`; `src/responsive.css:231-271`). This is a genuine post-prior-increment improvement, not an audit target to redesign from the old inline state.
8. **Choose output and operational options:** repository/tracking/both, destination where applicable, dry-run, Git, GitHub, IDE (`src/App.tsx:1290-1409`). Web represents guides, not local execution (`src/App.tsx:1364-1401`).
9. **Continuous side preview:** prompt and expandable action plan remain visible alongside input (`src/App.tsx:1439-1489`).
10. **Validation gate:** invalid state disables the CTA; field-level errors appear where implemented (`src/App.tsx:478-512`, `src/App.tsx:1411-1436`).
11. **Review/confirm dialog:** displays dry/live mode, destinations, planned artifacts, limitations, attachment manifest, cancel and exact execution/export verb (`src/App.tsx:1564-1785`).
12. **Result state:** running and outcome evidence appears back in the right rail (`src/App.tsx:1490-1492`; result component begins `src/App.tsx:1927`). Web requests a ZIP download; desktop performs its safe local plan through the bridge.

### Desktop branches after creation

13. **Orchestration Center:** select a created project, toolkit and config; preflight; start/resume; inspect snapshot/evidence; make individually confirmed human-gate decisions or request cancellation (`src/App.tsx:2135-2353`).
14. **Settings:** choose locations, branch, IDE, language/theme and inspect/connect GitHub CLI (`src/App.tsx:2378-2490`).
15. **History:** inspect local execution ledger or its empty state (`src/App.tsx:2492-2528`).
16. **About:** inspect product/legal/security summary and, on web, open versioned legal drafts (`src/App.tsx:2530-2568`).

There is currently no marketing landing, registration/authentication, account, billing, analytics-consent, or cloud-project journey. Those are future boundaries only.

## 4. Additional friction not explicit in section 4

- **Host divergence is discoverable late.** Browser limitations are distributed across the intro, option labels, footer, Mode 1 dialog, and confirmation (`src/components/WebExperience.tsx:27-33`; `src/App.tsx:1369-1400`, `src/App.tsx:1555-1558`). A user can configure desktop-only concepts before fully understanding the handoff.
- **Terminology presumes orchestration knowledge.** “Route A/B,” “canonical role,” “Mode 1,” “provider invocations,” and “tracking” appear in primary UI (`src/App.tsx:1019-1025`, `src/App.tsx:1045-1048`; `src/components/mode1/Mode1ConfigurationDialog.tsx:45-90`). Explanations exist, but often after the decision or inside the advanced dialog.
- **Validation is partly a silent disabled-button problem.** The CTA caption says to fix validations (`src/App.tsx:1431-1435`), but there is no page-level error summary or first-invalid focus for the main form comparable to Mode 1’s strong error summary (`src/components/mode1/Mode1ConfigurationDialog.tsx:290-310`).
- **Global “Ready” is overconfident.** The footer always shows a green-dot Ready state (`src/App.tsx:1530-1534`) even while the form is invalid or host/provider checks may be unavailable.
- **Settings persistence differs by host without an IA boundary.** Web hides Settings, while header theme/language changes remain available and browser-local (`src/App.tsx:714-724`, `src/App.tsx:737-765`); desktop requires explicit Settings save (`src/App.tsx:1502-1524`).
- **Mobile navigation and content remain dense.** At ≤720px nav indices disappear but every tab label remains (`src/responsive.css:159-167`), while the entire form and preview stack; Mode 1 is the only flow with a purpose-designed full-screen mobile treatment (`src/responsive.css:244-271`).

## 5. Future UX direction decision (Sprint 1)

Use a **guided workspace, not a rigid wizard**. Introduce an optional two-screen onboarding, then a five-stage creation rail: Foundation, Context, Team, Delivery, Review. Preserve free navigation among completed/current stages, autosave, and desktop/web honesty. Each stage has one primary decision cluster, an optional “Advanced” disclosure, a short consequence statement, and a compact completion state. Move the full prompt and artifact tree to Review; earlier stages get a user-invoked contextual summary drawer. Keep Mode 1 as the already-shipped modal pattern, launched from Team’s advanced section, while progressively translating its technical concepts.

The completion sequence should be: entry/onboarding → Foundation → Context → Team → Delivery → Review → explicit dry-run/create/export confirmation → outcome with artifact actions → optional desktop orchestration. This preserves every current capability while turning configuration into a comprehensible narrative.
