# ACCREATIO — SUPPLEMENTAL AEKR SPRINT, DESIGN SYSTEM, AND EXECUTION DISCIPLINE

## 0. Relationship to the primary master prompt

This document supplements the previously approved:

**`ACCREATIO — MASTER AEKR CORRECTIVE AND EXTENSIBILITY INCREMENT`**

It does not replace, weaken, reinterpret, or contradict that master prompt.

All previously established requirements remain binding, including:

* participant separation;
* Claude as Orchestrator;
* Codex as Solution Designer;
* a separate Codex context as Implementer;
* Claude as Test Engineer;
* a fresh Claude context as Independent Auditor;
* human design and final acceptance gates;
* local-first behavior;
* deterministic generation;
* AEKR compatibility;
* zero-cost defaults;
* explicit paid-API authorization;
* no speculative provider capabilities;
* no autonomous Mode 2 persistent loop;
* no SaaS, W2, public deployment, automatic commits, or automatic pushes.

When this supplemental prompt appears to overlap with the primary prompt, apply both simultaneously.

If an actual conflict is discovered, stop and report it to the Orchestrator. Do not silently choose one interpretation.

---

# 1. Additional visual-design mandate

The visual identity of `accreatio` must be derived from its logo and core brand imagery:

> A soft-purple spiral nebula or galactic vortex, with predominantly restrained violet, lavender, plum, indigo, and atmospheric cosmic tones.

The objective is not to turn the application into a decorative science-fiction interface.

The objective is to translate the logo's visual language into a coherent, professional, modern design system suitable for a serious software-development tool.

The design must communicate:

* controlled complexity;
* structured creation;
* orchestration;
* depth;
* calm technical intelligence;
* clarity;
* precision;
* trust.

Avoid:

* neon cyberpunk excess;
* gaming aesthetics;
* saturated gradients everywhere;
* glowing borders on every component;
* ornamental galaxies behind working forms;
* low-contrast purple-on-purple text;
* illegible translucent surfaces;
* gratuitous animations;
* visual effects that compete with form completion;
* styling that makes the application appear experimental or unserious.

The logo is the conceptual and chromatic origin of the design system, not a decorative texture to repeat throughout every screen.

---

# 2. Dark-mode palette direction

Dark mode is the primary expression of the `accreatio` brand.

The Codex Solution Designer must create a semantic palette derived from the logo's soft-purple nebula tones.

The exact values must be selected by the Designer after inspecting:

* the actual logo;
* the current application;
* existing CSS variables;
* contrast requirements;
* component states;
* desktop and web rendering;
* the need to distinguish structural surfaces from interactive accents.

The palette should generally explore relationships among:

* deep near-black violet backgrounds;
* muted indigo or plum surfaces;
* soft lavender primary accents;
* restrained violet highlights;
* cool neutral text;
* subtle blue-violet secondary accents;
* warm or contrasting status colors only where semantically necessary.

The palette must not consist solely of different purples. Functional states require semantic differentiation.

The Designer must define, at minimum:

```css
--app-background
--surface-primary
--surface-secondary
--surface-elevated
--surface-overlay
--surface-muted

--border-subtle
--border-default
--border-strong

--text-primary
--text-secondary
--text-muted
--text-disabled
--text-on-accent

--accent-primary
--accent-primary-hover
--accent-primary-active
--accent-primary-muted

--accent-secondary
--accent-secondary-hover

--focus-ring

--success
--warning
--danger
--information

--control-background
--control-background-hover
--control-background-selected
--control-border
--control-border-hover
--control-text
--control-placeholder
--control-disabled
```

Equivalent token names are acceptable if the existing design system already has a coherent convention.

The tokens must express semantic purpose rather than specific colors such as:

```css
--purple-1
--purple-button
--dark-purple-box
```

Raw palette primitives may exist internally, but working components must consume semantic tokens.

---

# 3. Light-mode palette direction

Light mode must remain visually related to the primary nebula palette, but it does not have to mechanically invert dark mode.

The Codex Solution Designer has discretion to establish the light-mode counterpart based on professional visual-design principles.

The light palette may use:

* soft neutral or slightly violet-tinted backgrounds;
* restrained lavender or plum accents;
* darker violet for selected states;
* cool gray typography;
* subtle cosmic undertones;
* limited gradients where they provide hierarchy rather than decoration.

The Designer must account for the fact that colors that appear refined in dark mode can become:

* childish;
* overly saturated;
* low contrast;
* visually heavy;
* or excessively cosmetic

when transferred directly to a light surface.

Therefore, the light-mode system must be designed as a legitimate complementary theme, not produced through automatic inversion.

The Designer must document:

1. the principal dark-mode palette;
2. the light-mode counterpart;
3. which colors are direct relatives;
4. which colors intentionally differ;
5. the contrast rationale;
6. the treatment of interactive states;
7. the treatment of semantic statuses;
8. any deviations from the logo palette required for accessibility.

Design discretion is granted, but must remain traceable to the primary visual identity.

---

# 4. Brand restraint and application hierarchy

The strongest brand treatments should be reserved for:

* the application identity;
* the logo area;
* primary actions;
* selected navigation;
* focus and active states;
* important structural highlights;
* Mode 1 orchestration summaries;
* meaningful progress or workflow transitions.

Neutral surfaces should dominate working areas such as:

* forms;
* text fields;
* task descriptions;
* tables;
* provider configuration;
* file lists;
* logs;
* error details;
* generated-output previews.

This preserves concentration and prevents visual fatigue.

The design must support long working sessions.

Do not use the nebula palette as an excuse to reduce information density, increase ornamental whitespace excessively, or obscure operational information.

---

# 5. User-experience quality is a release requirement

Good user experience is not an optional visual enhancement.

It is a Definition-of-Done requirement for this increment.

A feature is not complete merely because:

* its state updates;
* its tests pass;
* its YAML serializes;
* its button works;
* its modal opens;
* its output exists.

It must also be understandable, predictable, efficient, and recoverable for a real user.

The Designer and Implementer must assess each affected workflow according to:

* discoverability;
* clarity of language;
* information hierarchy;
* visibility of system status;
* prevention of accidental actions;
* understandable validation;
* preservation of user input;
* error recovery;
* keyboard operability;
* responsive behavior;
* visual consistency;
* cognitive load;
* feedback after completion;
* distinction between available, unavailable, disabled, and unsupported states.

The Designer must not treat UX as styling applied after architecture.

The UX contract must be designed before implementation.

---

# 6. UX questions required for every affected feature

For each feature or correction, the Solution Designer must explicitly answer:

1. What is the user trying to accomplish?
2. What information is required?
3. What information is optional?
4. What is the expected happy path?
5. What can go wrong?
6. How is an error explained?
7. Can the user recover without losing input?
8. What confirms successful completion?
9. What prevents accidental repetition?
10. How does the workflow behave on narrow screens?
11. How does it behave with keyboard-only navigation?
12. How does the user understand unavailable capabilities?
13. Does the UI expose implementation concepts unnecessarily?
14. Is the terminology consistent with AEKR and the generated artifacts?
15. Is the same concept represented consistently in desktop and web?

These answers may be concise, but they must exist before implementation begins.

---

# 7. AEKR execution model: Task → Sprint → Micro-sub-sprint

The work must no longer be treated as one large continuous implementation.

Every approved body of work must be decomposed through three explicit levels:

```text
Task
├── Sprint
    ├── Micro-sub-sprint
    ├── Micro-sub-sprint
    ├── Micro-sub-sprint
```

This hierarchy is mandatory for Design and Implementation.

Its purpose is to:

* reduce context decay;
* minimize memory loss;
* maintain precise scope;
* isolate defects;
* allow frequent verification;
* preserve clear evidence;
* avoid large opaque diffs;
* make rollback easier;
* prevent an agent from editing many unrelated files before validating any of them.

---

# 8. Definition of a Task

A **Task** is a bounded product objective that produces a coherent user-facing or architectural result.

Examples:

* redesign Mode 1 configuration;
* create provider-registry extensibility;
* add W1 local attachments;
* prevent duplicate execution;
* establish the new theme system;
* correct artifact-verification behavior.

A Task must not be equivalent to "fix everything in the application."

Each Task must have:

* a unique ID;
* a concise title;
* an objective;
* an explicit scope;
* non-goals;
* dependencies;
* acceptance criteria;
* relevant files or subsystems;
* assigned participants;
* risks;
* required evidence;
* expected documentation impact.

Suggested identifier:

```text
TASK-UX-MODE1
TASK-DESIGN-THEME
TASK-WEB-ATTACHMENTS
TASK-EXEC-IDEMPOTENCY
TASK-PROVIDER-REGISTRY
```

Equivalent stable naming is acceptable.

---

# 9. Definition of a Sprint

A **Sprint** is a meaningful phase within one Task.

A Sprint should represent a coherent stage such as:

```text
TASK-UX-MODE1

Sprint 1 — Current-state discovery and UX contract
Sprint 2 — Shared dialog foundation
Sprint 3 — Participant and provider configuration
Sprint 4 — Execution-limit configuration
Sprint 5 — Persistence and serialization
Sprint 6 — Task-level validation
```

A Sprint must not contain the entire Task when the Task affects multiple concerns.

Each Sprint must define:

* sprint ID;
* sprint objective;
* entry conditions;
* included files or components;
* excluded files or components;
* micro-sub-sprints;
* sprint validation;
* evidence;
* completion status;
* unresolved findings.

Suggested identifier:

```text
TASK-UX-MODE1 / SPRINT-1
TASK-UX-MODE1 / SPRINT-2
```

---

# 10. Definition of a Micro-sub-sprint

A **Micro-sub-sprint** is the smallest controlled unit of work.

It should generally perform one narrowly defined action.

Examples:

* inspect one component and document its state flow;
* define semantic theme tokens;
* update one shared type file;
* update one React component;
* create one new component;
* modify one validation function;
* add unit tests for one contract;
* run those unit tests;
* correct one failed test;
* update one documentation file;
* verify one generated artifact.

A micro-sub-sprint should not normally:

* modify a large collection of unrelated files;
* implement a full feature across domain, UI, bridge, tests, and documentation at once;
* combine design, implementation, and final verification;
* introduce changes that cannot be independently understood;
* leave many files in a partially migrated state without explicit management.

Suggested identifier:

```text
TASK-UX-MODE1 / SPRINT-2 / MSS-2.1
TASK-UX-MODE1 / SPRINT-2 / MSS-2.2
TASK-UX-MODE1 / SPRINT-2 / MSS-2.3
```

The preferred written shorthand is:

```text
Sprint 2
- Micro-sub-sprint 2.1
- Micro-sub-sprint 2.2
- Micro-sub-sprint 2.3
```

---

# 11. Micro-sub-sprint sizing rule

The default unit should be:

> one primary change, in one principal file or tightly coupled file pair, followed by focused verification.

Examples:

```text
MSS 2.1 — Add Mode1Dialog component shell in one new file.
MSS 2.2 — Add focused component tests for dialog opening and closing.
MSS 2.3 — Integrate the dialog trigger into App.tsx.
MSS 2.4 — Test trigger, focus transfer, and cancellation.
MSS 2.5 — Add dialog footer and save contract.
MSS 2.6 — Test persistence and focus restoration.
```

Another example:

```text
MSS 3.1 — Add funding type to shared/domain.ts.
MSS 3.2 — Add unit tests for funding validation.
MSS 3.3 — Update YAML generation.
MSS 3.4 — Test generated YAML.
MSS 3.5 — Update Mode 1 UI controls.
MSS 3.6 — Test UI-to-domain serialization.
```

A single micro-sub-sprint may modify more than one file only when:

* the files form one inseparable atomic change;
* changing only one would leave the repository uncompilable;
* the coupling is documented before editing;
* focused validation occurs immediately afterward.

"Many files are related to the feature" is not sufficient justification.

---

# 12. Mandatory micro-sub-sprint lifecycle

Every Design and Implementation micro-sub-sprint must follow this sequence:

```text
1. Reconfirm objective.
2. Inspect relevant current state.
3. State intended files or artifacts.
4. Perform the bounded work.
5. Run focused validation.
6. Record result.
7. Record deviations or new findings.
8. Mark complete, failed, or blocked.
9. Continue only when the result is stable.
```

The agent must not silently move into the next micro-sub-sprint after a failed validation.

A failed micro-sub-sprint must be resolved through one of:

* immediate bounded correction;
* explicit redesign;
* blocked status;
* escalation to the Orchestrator;
* creation of a new corrective micro-sub-sprint.

---

# 13. Design must also use sprints and micro-sub-sprints

The Codex Solution Designer must not inspect the full repository and then deliver one enormous design artifact written from memory.

Design must itself be decomposed.

Example:

```text
TASK-DESIGN-MODE1

Sprint 1 — Existing behavior
  MSS 1.1 — Inspect current Mode 1 UI.
  MSS 1.2 — Inspect Mode 1 state and types.
  MSS 1.3 — Inspect AEKR serialization contract.
  MSS 1.4 — Reconcile findings.

Sprint 2 — UX structure
  MSS 2.1 — Define dialog information architecture.
  MSS 2.2 — Define participant-management behavior.
  MSS 2.3 — Define provider-selection behavior.
  MSS 2.4 — Define execution-limit behavior.
  MSS 2.5 — Validate the complete UX flow.

Sprint 3 — Technical architecture
  MSS 3.1 — Define component boundaries.
  MSS 3.2 — Define state ownership.
  MSS 3.3 — Define domain changes.
  MSS 3.4 — Define migration strategy.
  MSS 3.5 — Validate architectural coherence.

Sprint 4 — Delivery design
  MSS 4.1 — Produce file-level plan.
  MSS 4.2 — Produce test plan.
  MSS 4.3 — Produce documentation plan.
  MSS 4.4 — Assemble the design-gate package.
```

At the end of each Design Sprint, the Designer must consolidate findings before continuing.

This consolidation prevents later design decisions from relying on incomplete or forgotten observations.

---

# 14. Implementation must use sprints and micro-sub-sprints

The Codex Implementer must implement one approved Task at a time.

Within each Task:

* execute Sprint 1;
* complete and validate all Sprint 1 micro-sub-sprints;
* produce a sprint checkpoint;
* only then begin Sprint 2.

Do not partially implement Sprints 1, 2, and 3 simultaneously.

Do not scatter incomplete changes across the repository to "finish later."

The implementation sequence must prefer:

1. contracts and types;
2. validation;
3. focused unit tests;
4. generation or serialization;
5. shared components;
6. host integrations;
7. user-facing integration;
8. focused end-to-end validation;
9. documentation synchronization.

The exact sequence may change when repository architecture requires it, but the Designer must justify the order.

---

# 15. Sprint completion gate

A Sprint is complete only when:

* every planned micro-sub-sprint is complete;
* focused validations pass;
* the repository is left in a coherent state;
* no temporary diagnostic code remains;
* new findings are recorded;
* documentation affected within the Sprint is synchronized when practical;
* the Sprint checkpoint is written;
* the next Sprint's assumptions remain valid.

The Sprint checkpoint must contain:

```text
Sprint:
Objective:
Micro-sub-sprints completed:
Files changed:
Focused tests:
Results:
New findings:
Residual risks:
Deviations:
Ready for next sprint: Yes / No
```

A Sprint may be marked complete with a documented minor residual issue only when:

* it does not invalidate the Sprint objective;
* it is recorded as a later micro-sub-sprint or separate Task;
* the Orchestrator agrees it does not create hidden debt.

---

# 16. Task completion gate

A Task is complete only when:

* all its Sprints are complete;
* Task-specific acceptance criteria pass;
* focused tests pass;
* the Task's documentation is synchronized;
* the Task produces a coherent user or architectural result;
* the Orchestrator validates the Task package;
* the repository remains stable.

The completion of one Task authorizes movement to the next approved Task.

Do not wait until all Tasks are implemented before determining that an earlier Task was incomplete.

---

# 17. Recommended Task sequence for this increment

The Codex Designer must validate or refine this sequence rather than assuming it blindly.

A reasonable starting order is:

## Task 1 — Visual design system and theme foundation

Scope:

* logo-derived color system;
* semantic tokens;
* dark-mode primary palette;
* light-mode complementary palette;
* shared controls;
* contrast defects;
* theme-switching consistency.

This Task should establish tokens before later UI work consumes them.

## Task 2 — Mode 1 configuration UX

Scope:

* centered dialog;
* participant layout;
* task fields;
* providers;
* execution limits;
* save/cancel behavior;
* responsive and keyboard behavior.

## Task 3 — Participant-instance model

Scope:

* one-to-six participants;
* role versus participant separation;
* deterministic order;
* migration from the current model.

## Task 4 — Provider registry

Scope:

* capability-driven descriptors;
* existing Claude/Codex/mock migration;
* availability and unsupported states;
* no fake provider execution.

## Task 5 — Funding and API budget controls

Scope:

* subscription/local CLI versus API;
* disabled-by-default paid usage;
* monetary ceiling;
* enforcement capability;
* documentation and serialization.

This may depend on Task 4.

## Task 6 — W1 attachments

Scope:

* local browser selection;
* validation;
* ZIP inclusion;
* privacy messaging;
* lifecycle and reload behavior.

## Task 7 — Operation idempotency and duplicate prevention

Scope:

* operation state machine;
* input fingerprint;
* reentrancy protection;
* explicit legitimate rerun.

## Task 8 — Artifact verification and product feedback

Scope:

* desktop output evidence;
* web ZIP evidence;
* result clarity;
* failure and partial-completion reporting.

## Task 9 — About and product-brand cleanup

Scope:

* product-first About;
* accurate version and principles;
* removal of personal-first product presentation.

Tasks may be combined only if the Designer proves they are small, inseparable, and safer together.

Tasks may be reordered based on evidenced dependency.

---

# 18. Context preservation protocol

At the end of every micro-sub-sprint, produce a compact memory checkpoint.

It must contain only the information needed by the next micro-sub-sprint:

```text
Current Task:
Current Sprint:
Completed MSS:
Current repository state:
Files changed:
Tests run:
Decisions established:
Open issue:
Next MSS:
Do not revisit:
```

The next agent invocation or continued context must begin by reading that checkpoint.

Do not rely on informal conversational memory.

Do not copy the entire history into every checkpoint. Preserve only high-value state.

At the end of each Sprint, replace the micro checkpoint with a Sprint checkpoint.

At the end of each Task, produce a Task handoff package.

---

# 19. Task handoff package

Every completed Task must produce:

```text
Task ID and title
Objective
Approved design reference
Sprints completed
Files changed
Contracts changed
User-visible behavior
Focused automated tests
Focused manual tests
Documentation changed
Known limitations
Risks
Rollback point
Dependencies created for later Tasks
```

This package becomes the starting context for any later Task that depends on it.

---

# 20. Git and change-isolation guidance

The existing master prompt's Git restrictions remain binding.

No automatic commits or pushes are authorized.

However, work must be organized so that each Sprint could be reviewed or committed independently by the owner if desired.

Therefore:

* avoid unrelated formatting;
* avoid sweeping renames unless approved;
* keep diffs small;
* record changed files per micro-sub-sprint;
* avoid editing future-Task files prematurely;
* do not combine theme migration, schema migration, provider work, and attachments in one diff;
* preserve a clean conceptual rollback boundary.

The Orchestrator may recommend owner-controlled checkpoint commits after stable Sprints, but must not create them unless explicitly authorized by the current operating contract.

---

# 21. Focused testing inside micro-sub-sprints

Focused testing is mandatory throughout implementation.

Examples:

* after changing validation, run validation tests;
* after changing YAML generation, run YAML generation tests;
* after changing a dialog component, run its component tests;
* after changing theme tokens, inspect affected controls in both themes;
* after changing ZIP assembly, inspect a generated ZIP;
* after changing the provider registry, test capability eligibility;
* after changing participant serialization, test legacy migration.

Do not postpone all tests until the entire Task is complete.

The purpose of final testing is not to discover basic defects that focused tests should already have caught.

---

# 22. Final Test Engineer scope

The Claude Test Engineer may operate more globally than the Designer and Implementer.

After the principal implementation Tasks are complete, the Test Engineer must evaluate the integrated increment across:

* desktop;
* web;
* dark mode;
* light mode;
* responsive layouts;
* keyboard flows;
* Mode 1;
* participant configurations;
* provider eligibility;
* funding controls;
* attachments;
* duplicate prevention;
* actual outputs;
* documentation claims.

The Test Engineer does not need to reproduce the implementation's entire micro-sub-sprint structure.

However, any defect discovered must be converted into a bounded corrective unit:

```text
CORRECTION TASK
├── Corrective Sprint
    ├── Reproduce
    ├── Correct
    ├── Retest
```

A small defect may use one Sprint with several micro-sub-sprints.

A systemic defect may require a new full Task.

---

# 23. Final Independent Audit scope

The Claude Independent Auditor may audit the completed increment globally.

The audit should examine relationships across Tasks, including:

* whether the theme system is coherent;
* whether UX decisions remain consistent;
* whether role and participant models agree;
* whether providers and funding contracts align;
* whether web and desktop make honest claims;
* whether generated artifacts match documentation;
* whether the micro-sprint approach produced fragmented or duplicated architecture;
* whether temporary compatibility layers remain;
* whether Task boundaries introduced avoidable inconsistencies.

The Auditor must not repeat every focused unit test.

The Auditor must evaluate the integrity of the final system and the credibility of the evidence.

---

# 24. Regression-testing strategy

Regression testing for the main corrective increment should initially remain high-level and risk-based.

The main Task must include:

* existing mandated automated checks;
* focused tests for changed behavior;
* high-level smoke testing of unaffected critical workflows;
* a limited regression matrix covering the most important established capabilities.

Do not expand the principal Task indefinitely into a complete retest of every historical capability unless evidence requires it.

High-level regression coverage should include, at minimum:

* desktop application startup;
* web application startup;
* project-definition validation;
* dry-run;
* one desktop generation path;
* one web ZIP export path;
* existing settings persistence;
* existing history behavior where applicable;
* Mode 0 default;
* Mode 1 generation;
* theme switching;
* locale switching;
* Project Map integrity;
* existing build and type checks.

---

# 25. Escalation to full regression Task

If high-level regression testing reveals a serious or systemic problem, do not hide it inside the main Task or patch it casually.

Examples of escalation triggers:

* widespread state corruption;
* broken generation across several project actions;
* incompatible schema migration;
* desktop/web template divergence;
* failures in unrelated workflows;
* security-boundary regression;
* persistent duplicate execution;
* history/settings corruption;
* broken backward compatibility;
* major accessibility regression;
* provider registry affecting existing execution;
* API funding controls failing to stop execution;
* Project Map no longer matching runtime architecture.

When one of these occurs:

1. finish the current principal Task as far as safely possible;
2. report the regression clearly;
3. mark the principal Task's readiness accurately;
4. create a separate AEKR Task named similarly to:

```text
TASK-REGRESSION-REMEDIATION
```

5. operate that new Task through:

   * Design Sprints;
   * Implementation Sprints;
   * Micro-sub-sprints;
   * focused verification;
   * final regression testing;
   * independent audit if material.

Do not allow a serious regression-remediation effort to become an unstructured tail of the original Task.

---

# 26. Distinguishing focused, integrated, and regression tests

Use these definitions consistently.

## Focused test

Validates the direct behavior changed by one micro-sub-sprint or Sprint.

Examples:

* funding validation;
* dialog save behavior;
* provider capability filtering;
* ZIP attachment inclusion.

## Integrated Task test

Validates the complete result of one Task.

Examples:

* complete Mode 1 configuration workflow;
* full browser attachment-to-ZIP workflow;
* participant registry through YAML generation.

## High-level regression test

Checks that critical established behavior still works without retesting every edge case.

## Full regression test

A broad revalidation of existing capabilities, justified only by significant risk or discovered systemic defects.

These must not be conflated in reports.

---

# 27. Design review at Sprint boundaries

At the end of each Design Sprint, the Claude Orchestrator must review:

* consistency with the master prompt;
* consistency with previous Design Sprints;
* consistency with the product boundary;
* scope growth;
* assumptions unsupported by code;
* terminology;
* AEKR compatibility;
* UX implications;
* security implications;
* dependencies introduced for later Sprints.

The Orchestrator may:

* approve continuation;
* request a bounded revision;
* merge duplicative micro-sub-sprints;
* split an oversized Sprint;
* escalate a decision to the human design gate.

The Orchestrator must not allow the Designer to accumulate all unresolved decisions until the end.

---

# 28. Implementation review at Sprint boundaries

At each Implementation Sprint checkpoint, the Orchestrator must determine:

* whether the approved design was followed;
* whether the current repository state is coherent;
* whether focused tests passed;
* whether changes remain within scope;
* whether new architectural debt appeared;
* whether the next Sprint remains valid;
* whether documentation or migration work is falling behind;
* whether a human decision is required.

A Sprint cannot be considered complete solely because the Implementer says it is done.

Evidence is required.

---

# 29. Handling newly discovered work

A newly discovered issue must be classified as:

```text
A. Required for the current micro-sub-sprint
B. Required for the current Sprint
C. Required for the current Task
D. Separate future Task
E. Existing unrelated defect
F. Not a defect
```

Do not immediately fix every discovered issue.

For categories D and E:

* document the evidence;
* assess severity;
* avoid changing it during the current micro-sub-sprint;
* add it to the appropriate backlog or risk record.

For category A, B, or C:

* revise the relevant plan;
* keep the corrective work bounded;
* preserve the sprint hierarchy.

---

# 30. Visual acceptance criteria

The new design is acceptable only when:

1. Dark mode clearly reflects the logo's soft-purple spiral-nebula identity.
2. The result remains professional and operational rather than decorative.
3. Light mode is intentionally designed, not mechanically inverted.
4. Controls remain visible in all states.
5. Text contrast meets accessibility expectations.
6. Focus states are unmistakable.
7. Selected and disabled states cannot be confused.
8. Purple is not used as the sole differentiator for semantic status.
9. Forms remain comfortable during long sessions.
10. The Mode 1 dialog remains readable with six participants.
11. No working surface uses distracting galactic imagery.
12. Desktop and web feel like the same product.
13. The logo, palette, typography, controls, dialogs, and status language form one coherent system.
14. The design holds at supported viewport sizes and 200% zoom.
15. Reduced-motion preferences are respected.
16. The Designer records the rationale and token mapping.

---

# 31. UX acceptance criteria

The affected experience is acceptable only when:

1. The user understands what each major action will do.
2. Desktop and web differences are explained before execution.
3. Mode 1 configuration can be completed without hidden fields or nested-scroll frustration.
4. Numeric limits are editable and understandable.
5. Provider availability is honest.
6. Paid usage cannot be enabled accidentally.
7. The user understands the maximum configured budget.
8. Six participants do not create an unreadable interface.
9. Long tasks remain readable.
10. Saving provides clear confirmation.
11. Cancelling does not destroy prior saved configuration.
12. Validation preserves the user's work.
13. Duplicate actions are prevented without blocking legitimate reruns.
14. Attachments show clear status and limits.
15. Successful output is evidenced by a real destination or ZIP.
16. Failure states explain what completed and what did not.
17. Keyboard navigation supports the full workflow.
18. Responsive layouts preserve all critical functions.
19. The application does not expose unnecessary internal implementation terminology.
20. No feature is presented as available when it is only planned or unsupported.

---

# 32. Orchestrator reporting format during execution

The Claude Orchestrator must maintain a compact progress register:

```text
Task:
Task status:

Current Sprint:
Sprint status:

Completed micro-sub-sprints:
Current micro-sub-sprint:
Focused validation:
Blocking issue:
Newly discovered work:
Next action:
Human gate required: Yes / No
```

Do not produce a large narrative after every micro-sub-sprint.

Use compact operational updates and preserve detailed evidence in the relevant design, test, or change artifacts.

---

# 33. Final delivery structure

The final report from the Claude Orchestrator must preserve the Task/Sprint hierarchy.

For each Task, report:

```text
Task ID:
Objective:
Status:

Sprint 1:
- Micro-sub-sprints completed
- Evidence
- Result

Sprint 2:
- Micro-sub-sprints completed
- Evidence
- Result

Task acceptance:
Residual issues:
Regression impact:
```

Then provide:

* integrated Test Engineer results;
* high-level regression results;
* any escalated regression-remediation Task;
* Independent Auditor findings;
* unresolved risks;
* deferred work;
* rollback references;
* final readiness verdict.

Avoid presenting a simple flat list of modified files as evidence of completion.

---

# 34. Final execution instruction

Begin by incorporating this supplemental mandate into the existing master execution plan.

The first participant action must be performed by the Claude Orchestrator.

The Orchestrator must:

1. confirm the primary prompt remains authoritative;
2. establish the Task hierarchy;
3. propose the initial Sprint and micro-sub-sprint structure;
4. preserve the human design gate;
5. instruct the Codex Solution Designer to begin only the first approved Design Task;
6. prevent implementation from starting prematurely;
7. enforce compact context checkpoints at every micro-sub-sprint;
8. validate each completed Sprint before authorizing the next;
9. use high-level regression testing for the main increment;
10. create a separate full AEKR regression Task if serious systemic defects emerge.

Do not design or implement the entire increment in one uninterrupted pass.

Work must advance through:

```text
Task 1
  Sprint 1
    Micro-sub-sprint 1.1
    Micro-sub-sprint 1.2
    Micro-sub-sprint 1.3
  Sprint 2
    Micro-sub-sprint 2.1
    Micro-sub-sprint 2.2
  Task validation

Task 2
  Sprint 1
    Micro-sub-sprint 1.1
    Micro-sub-sprint 1.2
  Sprint 2
    Micro-sub-sprint 2.1
    Micro-sub-sprint 2.2
  Task validation
```

Continue with the same hierarchy until the approved increment is complete.

Precision, retained context, stable intermediate states, testable progress, and user experience take precedence over speed or the volume of code produced.
