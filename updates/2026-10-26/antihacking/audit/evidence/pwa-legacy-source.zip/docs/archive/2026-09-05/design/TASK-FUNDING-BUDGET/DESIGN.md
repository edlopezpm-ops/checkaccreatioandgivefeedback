# TASK-FUNDING-BUDGET — Explicit zero-cost and paid-API funding policy

Status: design complete; no production implementation performed. Authority: `docs/archive/2026-09-05/design/TASK_BACKLOG.md` entry `TASK-FUNDING-BUDGET`. This record owns EXT-02 and consumes the approved participant-instance and provider-registry designs. It does not redesign the Mode 1 dialog or authorize an AEKR change.

## Task contract and decisive conclusion

Objective: make funding explicit while retaining `subscription_cli` as the zero-mandatory-direct-cost default and allowing `api` only after an evidenced, owner-defined cumulative monetary hard stop exists.

In scope: funding domain/schema, validation, migration, provider/model-profile capabilities, consent, currency/max-cost semantics, relationship to provider-invocation limits, honest UI states, deterministic serialization, security, tests, and documentation. Non-goals: enabling paid usage now or by default, credentials, automatic fallback, speculative providers/models, price lookup, billing reconciliation, real provider calls in tests, dialog-shell design, or weakening dry-run/local-first behavior.

Binding dependencies:

- `OrchestrationParticipantConfig` remains keyed by stable `participantId`; provider assignment is `providerId`, never canonical role. Funding validation joins participant assignments by `participantId` and never creates a second role-keyed map.
- `PROVIDER_REGISTRY` is compiled and currently contains only Claude Code and Codex subscription-CLI capabilities. Funding extends its capability/profile contract centrally; it does not add another provider switch.
- The consumed AEKR shape is role-keyed and cannot represent repeated roles or five/six distinct participant adapters. The participant compatibility guard still blocks those Mode 1 configurations. Funding cannot cure or bypass that gap.

Decisive enforcement finding: the repository proves only Claude adapter `max_budget_usd: 1.0` (an adapter/per-call allowance) and a commented `budget.ceiling: 10.0` (not enabled, tested, or proven cumulative). It does not prove an API adapter/model profile, authoritative usage metering, currency-aware cumulative accounting, or an atomic stop before aggregate spend crosses an owner ceiling. Therefore API enforcement is **estimated/unsupported, not exact**, and no current production provider/profile is API-eligible. The UI may explain API mode, but it must render it unavailable and must reject persisted/executable `api` state. Exact API enablement is a future evidence-gated provider/AEKR change, not part of this implementation.

## Sprint 1 — Existing-state discovery

Objective: establish actual funding behavior and upstream limits. Entry: mandate, backlog, reproduction report, dependencies, and repository available. Included artifacts: discovery decisions in this record. Excluded: production edits and live provider calls.

### MSS 1.1 — Current domain, validation, and defaults

1. **Reconfirm objective:** locate every current funding assumption. 2. **Inspect current state:** `shared/domain.ts` defines no funding type; `defaultOrchestration()` supplies `maxProviderInvocations: 4`; orchestration validation bounds it to 1–100. 3. **Intended artifact:** current-state inventory here. 4. **Bounded design work:** classify `maxProviderInvocations` as an aggregate call-count safety limit, not money, authorization, retries, or a price guarantee. Existing definitions have no paid consent or currency. 5. **Focused validation:** compared master §§7–8, backlog EXT-02, and current type/validator. 6. **Result:** explicit funding must be new state; invocation limit stays one canonical execution-limit field. 7. **Deviation/new finding:** none. 8. **Status:** complete.

### MSS 1.2 — Current YAML and provider eligibility

1. **Reconfirm objective:** determine what generated fields actually support. 2. **Inspect current state:** `renderOrchestrationConfig()` emits `max_budget_usd: 1.0` for every Claude adapter, no monetary field for Codex, and a commented `budget.ceiling: 10.0`; Electron accepts Claude `claude.ai` and Codex ChatGPT subscription login while rejecting Codex API-key login. 3. **Intended artifact:** enforcement finding. 4. **Bounded design work:** treat both money values as implicit, unauthorized policy: the first is provider-specific/per-call, the second inert and unverified. Neither is evidence of an aggregate hard stop or parity. 5. **Focused validation:** repository-wide funding search and provider-registry detection/serializer review. 6. **Result:** current execution is subscription CLI only despite misleading monetary YAML. 7. **Deviation/new finding:** upstream AEKR implementation/schema is not present, so comments cannot establish enforcement. 8. **Status:** complete.

### MSS 1.3 — Dependency identity and AEKR gap

1. **Reconfirm objective:** prevent reintroduction of role-keyed funding. 2. **Inspect current state:** dependency designs define stable `participantId`, `providerId`, compiled descriptors, and fail-closed legacy AEKR compatibility. 3. **Intended artifact:** funding join rule. 4. **Bounded design work:** funding is execution-wide, while eligibility is checked against every ordered participant assignment by `participantId`; error paths identify the participant ID and provider. No budget/allocation object is keyed by role. 5. **Focused validation:** repeated-role and 5/6-participant collision finding checked against both upstream designs. 6. **Result:** identity remains unambiguous even though current AEKR execution remains blocked for unrepresentable topologies. 7. **Deviation/new finding:** API support needs both participant-aware binding where applicable and cost enforcement; solving only one is insufficient. 8. **Status:** complete.

### MSS 1.4 — Discovery consolidation

1. **Reconfirm objective:** stabilize evidence before designing types. 2. **Inspect current state:** findings from MSS 1.1–1.3. 3. **Intended artifact:** Sprint consolidation. 4. **Bounded design work:** conclude that legacy data means subscription CLI; invocation count and money are distinct; current money fields must disappear from subscription output; API must fail closed. 5. **Focused validation:** checked against zero-cost/no-fallback/no-secret boundaries. 6. **Result:** discovery assumptions are coherent. 7. **Deviation/new finding:** this is a Category C upstream capability gap, not authority to implement AEKR. 8. **Status:** complete.

Sprint 1 consolidation/checkpoint: Objective met; four MSS complete. Files changed in this design Sprint: this record only. Focused validation: mandate/backlog/dependency/schema trace. New finding: no exact cumulative monetary enforcement exists in evidence. Residual risk: AEKR behavior may differ from its accreatio comment, so only versioned schema/runtime tests can change the conclusion. Deviations: none. Ready for Sprint 2: Yes.

## Sprint 2 — Funding domain and provider capability design

Objective: define one implementation-ready funding contract. Entry: Sprint 1 enforcement conclusion stable. Included: pure shared types/invariants. Excluded: UI shell and credentials.

### MSS 2.1 — Canonical funding policy

1. **Reconfirm objective:** represent free and paid modes without ambiguous optional fields. 2. **Inspect current state:** `OrchestrationConfig` and suggested master YAML. 3. **Intended implementation:** `shared/domain.ts` types/defaults; re-export in `src/types.ts`. 4. **Bounded design work:** adopt a discriminated union:

```ts
export type CurrencyCode = "USD"; // closed until another currency has end-to-end evidence

export interface SubscriptionCliFunding {
  mode: "subscription_cli";
  currency: "USD";
  maxCost: "0";
  hardStop: true;
}

export interface ApiFunding {
  mode: "api";
  providerId: ProviderId;
  modelProfileId: string;
  currency: CurrencyCode;
  maxCost: string; // canonical base-10 decimal, never binary float
  hardStopAcknowledged: true;
}

export type FundingPolicy = SubscriptionCliFunding | ApiFunding;
```

`OrchestrationConfig.funding` is required in the new in-memory schema. `defaultFunding()` returns the exact subscription object. `maxCost` is normalized at save/migration to `/^(0|[1-9]\d*)(\.\d{1,2})?$/`, no exponent/sign/group separators; API requires value `> 0`. Parsing uses integer minor units through a pure helper, never `Number` arithmetic. Currency is initially USD because the only observed AEKR money key is USD; the closed union prevents false multi-currency capability. `hardStop` in subscription means paid API use is prohibited, not that accreatio controls an external subscription fee. API acknowledgment is explicit consent, not proof of enforcement. 5. **Focused validation:** impossible mixed-mode states and decimal examples reviewed against master §8. 6. **Result:** mode-specific requirements are structurally explicit. 7. **Deviation/new finding:** field names use TypeScript camelCase and serialize to canonical snake_case. 8. **Status:** complete.

### MSS 2.2 — Invocation ceiling relationship

1. **Reconfirm objective:** require call-count protection without duplicate sources. 2. **Inspect current state:** `OrchestrationConfig.maxProviderInvocations` already serializes to AEKR `budget.max_provider_invocations`. 3. **Intended implementation:** validator/help/serializer tests, not a duplicate field. 4. **Bounded design work:** retain `orchestration.maxProviderInvocations` as the single canonical aggregate execution limit (1–100). API validation requires it to be valid and the Funding group displays a linked summary: “Also stops at no more than N provider invocations; edit in Execution limits.” Neither control derives the other, and reaching either enforceable limit must stop. Invocation count does not estimate or guarantee money. 5. **Focused validation:** master §§7–8 and current AEKR field alignment. 6. **Result:** API has the required invocation ceiling without drift. 7. **Deviation/new finding:** no `maxProviderInvocations` duplicate is added inside `FundingPolicy`. 8. **Status:** complete.

### MSS 2.3 — Provider/model profile enforcement capability

1. **Reconfirm objective:** make API eligibility evidence-driven. 2. **Inspect current state:** provider descriptors currently claim only subscription CLI, detection, and adapter serialization. 3. **Intended implementation:** extend `shared/providerRegistry.ts`; pure test fixtures under tests only. 4. **Bounded design work:** add capability literals `api_funding` and `exact_cumulative_cost_hard_stop`, plus optional compiled `apiModelProfiles`:

```ts
interface ApiModelProfileDescriptor {
  readonly id: string;                 // safe stable ID
  readonly displayName: string;
  readonly currency: CurrencyCode;
  readonly enforcement: "exact" | "estimated" | "none";
  readonly enforcementScope: "cumulative_execution" | "per_invocation" | "none";
  readonly aekrContractVersion: string;
  readonly adapterProfileId: string;
}
```

Production eligibility requires: known compiled provider; both capabilities; known profile owned by that provider; exact+cumulative scope; matching currency; evidenced versioned AEKR serializer/runtime; and every ordered participant configuration’s `providerId` equal to the selected API `providerId`. This last invariant avoids implying that one monetary ceiling governs mixed providers. Profiles are compiled reviewed records, never user/plugin manifests. Current Claude/Codex descriptors have no API capabilities or profiles. Estimated/per-invocation profiles may be displayed as unsupported diagnostics but are never selectable/executable. 5. **Focused validation:** capability matrix including exact, estimated, per-call-only, unknown profile, mixed-provider participants, repeated IDs. 6. **Result:** descriptor presence never implies paid capability. 7. **Deviation/new finding:** current API mode has zero eligible profiles by design. 8. **Status:** complete.

### MSS 2.4 — Exact-enforcement gate and stop semantics

1. **Reconfirm objective:** define what would be required to claim a hard stop. 2. **Inspect current state:** no cumulative contract evidence. 3. **Intended implementation:** pure `evaluateFundingEligibility()` and execution-preflight use; typed reason codes. 4. **Bounded design work:** API is executable only if the consumed AEKR contract atomically accounts authoritative provider charges in the selected currency across the whole execution and refuses the next invocation before its worst-case charge could exceed `maxCost`, while also enforcing `maxProviderInvocations`. Post-hoc estimates, token-price tables, delayed billing, or `max_budget_usd` per call do not qualify. Preflight re-evaluates profile/contract compatibility immediately before execution; failure blocks with `api_exact_hard_stop_unavailable`. No fallback to subscription or another profile occurs. 5. **Focused validation:** claim tested against known fields and backlog acceptance. 6. **Result:** the product cannot overpromise cost safety. 7. **Deviation/new finding:** an exact ceiling may conservatively stop below the maximum; it must never permit known overshoot. 8. **Status:** complete.

### MSS 2.5 — Domain consolidation

1. **Reconfirm objective:** freeze the contract. 2. **Inspect current state:** MSS 2.1–2.4. 3. **Intended artifact:** Sprint checkpoint. 4. **Bounded design work:** confirm execution-wide policy, participant-ID validation, one provider/profile in API mode, decimal minor units, and independent invocation count. 5. **Focused validation:** schema contradiction review. 6. **Result:** no undocumented implementer choice remains in domain semantics. 7. **Deviation/new finding:** mixed subscription/API participants are deliberately unsupported; adding allocation-level funding would require a later Task and upstream evidence. 8. **Status:** complete.

Sprint 2 consolidation/checkpoint: Objective met; five MSS complete. Intended files: `shared/domain.ts`, `src/types.ts`, `shared/providerRegistry.ts`, focused tests. Validation: type-state, decimal, capability, identity, and stop-semantics review. Residual risk: future billing contracts may not support pre-invocation worst-case reservation. Deviation: USD-only is intentionally honest. Ready for Sprint 3: Yes.

## Sprint 3 — Validation and migration design

Objective: default all existing data safely and reject unsupported paid states. Entry: domain contract stable. Included: draft/project migration and errors. Excluded: silent coercion of explicit invalid API data.

### MSS 3.1 — Validation matrix

1. **Reconfirm objective:** specify deterministic validation. 2. **Inspect current state:** monolithic `validationErrors()` and dependency validators. 3. **Intended implementation:** create pure `shared/funding.ts` for funding types, decimal helpers, validation, and eligibility; `shared/domain.ts` composes those helpers into project validation; add focused tests. 4. **Bounded design work:** subscription is valid only for the exact zero object and subscription-capable provider assignments; API requires all union fields, canonical positive decimal, valid invocation limit, acknowledgment `true`, known provider/profile, exact cumulative capability/version/currency, all participant IDs/provider assignments valid and matching, representable AEKR topology, and API execution support. Unknown extra runtime capability never makes a persisted definition valid. Return stable reason codes, including `funding_invalid`, `api_not_supported`, `api_profile_required`, `api_exact_hard_stop_unavailable`, `api_acknowledgment_required`, `api_provider_mismatch`, and `api_currency_mismatch`. Save/export/desktop execution fail before writes. 5. **Focused validation:** positive subscription plus every required negative API fixture. 6. **Result:** unavailable paid state is fail-closed and input-preserving. 7. **Deviation/new finding:** with current production registry there is no positive API fixture except an injected pure test registry/AEKR capability fixture. 8. **Status:** complete.

### MSS 3.2 — Legacy/current migration

1. **Reconfirm objective:** preserve behavior without authorizing spend. 2. **Inspect current state:** funding absent from current project/draft data; participant design proposes W1 envelope v3 and provider design composes with it. 3. **Intended implementation:** version-aware migration in `shared/domain.ts`/`src/draftStore.ts`; migration tests. 4. **Bounded design work:** absence of `funding` in every valid legacy/current schema becomes the exact subscription default. The existing Claude `max_budget_usd: 1.0` and commented ceiling are generated output, not user authorization, and are never imported as `maxCost`. Do not infer API consent from provider ID, login state, old YAML, or API-key presence. Compose the funding field into the participant/provider migration’s next schema version rather than independently stacking an avoidable envelope bump; if those Tasks have already shipped v3, bump once to v4 and document it. Unknown future versions fail closed. An explicitly stored malformed/unknown funding object is preserved for diagnostics and blocks save/export; it is not silently rewritten to subscription. 5. **Focused validation:** literal no-funding v1/v2/current fixtures, valid new subscription, malformed/explicit API, future version, save/reload stability. 6. **Result:** all genuine legacy data remains zero-paid-use. 7. **Deviation/new finding:** final numeric schema version is implementation-order-dependent; migration semantics are not. 8. **Status:** complete.

### MSS 3.3 — Failure recovery and security validation

1. **Reconfirm objective:** preserve work and secrets boundary. 2. **Inspect current state:** project state is renderer-owned; no funding credentials exist. 3. **Intended implementation:** validation UI mapping and security tests/docs. 4. **Bounded design work:** validation never resets mode/amount/selection; Cancel restores the prior saved policy; Save keeps the dialog open and focuses/summarizes errors. No credential field, token, environment value, provider billing response, raw CLI output, or secret-bearing diagnostic enters `ProjectDefinition`, drafts, history, ZIP, YAML, logs, IPC, or telemetry. Accreatio neither obtains credentials nor offers login/purchase flows. Fixed compiled descriptors/profile IDs only; user text never reaches shell/argv. 5. **Focused validation:** persisted-output/source search and malformed input/threat cases. 6. **Result:** paid authorization metadata contains no authentication material. 7. **Deviation/new finding:** actual external credential provisioning remains outside accreatio and cannot be presented as completed setup. 8. **Status:** complete.

### MSS 3.4 — Migration consolidation

1. **Reconfirm objective:** stabilize save/restore behavior. 2. **Inspect current state:** MSS 3.1–3.3. 3. **Intended artifact:** checkpoint. 4. **Bounded design work:** consolidate absence-defaulting, explicit-invalid preservation, reason codes, and pre-write blocking. 5. **Focused validation:** backlog migration/security criteria. 6. **Result:** migration cannot create paid authorization. 7. **Deviation/new finding:** none. 8. **Status:** complete.

Sprint 3 consolidation/checkpoint: Objective met; four MSS complete. Intended files: domain/funding helper, draft store, validation/migration tests, UI error mapping. Focused validation: legacy, malformed, future-version, no-secret, and pre-write scenarios. Residual risk: shallow existing restore logic must be replaced by version-aware parsing, not patched with defaults after cast. Ready for Sprint 4: Yes.

## Sprint 4 — Funding UX and visual contract

Objective: define the funding group consumed by `TASK-UX-MODE1`. Entry: policy/validation stable. Included: controls, copy, states, accessibility, visual constraints. Excluded: dialog shell, dimensions, footer mechanics, and general layout, which belong to `TASK-UX-MODE1`.

### MSS 4.1 — UX decision A: choose and understand funding mode

1. **Reconfirm objective:** make the zero-cost default and paid unavailability unmistakable. 2. **Inspect current state:** no funding UI; downstream dialog requires a Funding group. 3. **Intended implementation:** Funding group consumed by Mode 1 dialog in `src/App.tsx` or its approved extracted component; component tests. 4. **Bounded design work and supplemental §6 answers:** (1) Goal: choose how provider execution is funded and understand the safety boundary. (2) Required: mode; subscription uses fixed USD/0/hard-stop display; API requires provider, profile, currency, max cost, acknowledgment, and the shared max-invocations limit. (3) Optional: concise help disclosure; no credentials. (4) Happy path now: keep default “Subscription/local CLI — no paid API use,” review summary, save. Future API path: select an eligible provider/profile, enter ceiling, acknowledge, save. (5) Failures: no eligible profile, mixed assigned providers, missing/invalid amount or acknowledgment, unsupported currency/AEKR contract, stale capability. (6) Errors name the failed requirement and corrective action; current primary message is “Paid API mode is unavailable because no supported provider/profile can enforce an exact cumulative cost ceiling.” (7) All entered values and participant/provider choices remain; switch/cancel does not mutate saved state. (8) Saved summary states “Subscription/local CLI; paid API disabled; maximum provider invocations N.” Future API confirmation states provider/profile, currency+ceiling, invocation limit, and exact claim. (9) subscription is preselected; API is a disabled radio/card now; no default affirmative acknowledgment; Save and execution revalidate; no automatic fallback. (10) Narrow screens stack mode cards and fields in source order within the dialog’s one scroll container. (11) A labeled fieldset/radios, native controls, help, error summary, and acknowledgment have logical keyboard order and visible focus. (12) Disabled API includes adjacent text reason; unavailable, disabled, unsupported, and invalid remain distinct. (13) UI avoids registry/schema/adapter-map terminology; a diagnostic may name the required runtime contract. (14) terms match artifacts: Funding mode, Subscription/local CLI, Paid API, Maximum cost, Maximum provider invocations, hard stop. (15) Desktop and W1 share saved/exported semantics; W1 says it can prepare only supported configuration and cannot inspect/run local providers. 5. **Focused validation:** all 15 answers checked against §§5, 6, 8, and 31. 6. **Result:** API cannot be enabled accidentally or falsely. 7. **Deviation/new finding:** “zero mandatory direct cost” does not claim the user has no external subscription cost. 8. **Status:** complete.

### MSS 4.2 — UX decision B: API ceiling and acknowledgment (future enabled state)

1. **Reconfirm objective:** fully specify the controlled future state without representing it as current capability. 2. **Inspect current state:** numeric editing requirements and exact-enforcement gate. 3. **Intended implementation:** same Funding group and tests, activated only by an eligible compiled profile. 4. **Bounded design work and supplemental §6 answers:** (1) Goal: authorize a bounded paid run. (2) Required: selected provider/profile, fixed supported currency, positive canonical maximum cost, explicit unchecked acknowledgment, and valid invocation maximum. (3) Optional: profile/enforcement details disclosure. (4) Happy path: choose eligible API mode/profile, type amount using intermediate string state, review exact-stop statement, check acknowledgment, save. (5) Failures: empty/partial/negative/too-precise amount, profile/currency mismatch, eligibility loss, mixed providers, or unrepresentable participants. (6) Inline error plus summary explains whether input or capability failed; no amount is silently rounded. (7) Draft values persist through validation; Cancel preserves prior saved funding; reopening restores saved values. (8) confirmation and compact summary show the exact authorized currency amount and invocation maximum. (9) acknowledgment resets to unchecked whenever provider, profile, currency, amount, or enforcement claim changes; execution requires fresh eligibility, while idempotency remains `TASK-EXEC-IDEMPOTENCY`. (10) labels/help/errors wrap; amount and currency stack without horizontal overflow. (11) keyboard users can type empty/intermediate states, tab to help/checkbox, and return from error summary to the field. (12) ineligible profiles are not selectable; reason text distinguishes estimated/per-call from exact cumulative. (13) no token-price/billing API internals appear unless needed in diagnostic help. (14) generated terms use `funding.mode`, `currency`, `max_cost`, `hard_stop`; UI uses plain equivalents. (15) desktop/W1 validation and serialization are identical; only runtime availability differs. 5. **Focused validation:** scenario and keyboard review against §§6, 7, 8, and 31. 6. **Result:** future paid consent is informed, specific, and revocable before execution. 7. **Deviation/new finding:** acknowledgment is configuration consent, not a substitute for the Human Design Gate or provider terms. 8. **Status:** complete.

### MSS 4.3 — Visual decision and §§30–31 acceptance

1. **Reconfirm objective:** integrate safety status into the working UI without taking theme/dialog ownership. 2. **Inspect current state:** theme and upstream visual contracts plus supplemental §§30–31. 3. **Intended implementation:** Funding group styles consume `TASK-DESIGN-THEME` semantic tokens; `TASK-UX-MODE1` supplies dialog layout. 4. **Bounded design work:** use neutral working surfaces; a restrained accent marks selection, never cost safety. Every state combines icon/text and semantic color: subscription selected, API unavailable/disabled, warning acknowledgment, validation danger, future exact-enforcement information/success only after eligibility. Default/hover/focus/selected/disabled are visibly distinct in both intentional dark/light themes; focus is unmistakable; text/controls meet contrast expectations. No purple-only status, glow, galaxy background, new animation, or nested Funding scroll area. The group fits the dialog’s single scroll container, wraps at supported widths/200% zoom, remains readable with six participant summaries, and uses no motion; reduced-motion is therefore respected. Desktop/W1 share tokens, typography, control, and status language. This directly satisfies §30 items 2 and 4–15; items 1, 3, and 16 consume the theme record rather than redefine its palette/token rationale. It satisfies §31 items 1–7, 10–12, and 17–20 for funding; participant readability, duplicate actions, attachments, and output proof remain with their Tasks. 5. **Focused validation:** manual matrix: both hosts/themes, default/hover/focus/selected/disabled/error, narrow/mobile/supported desktop, 200% zoom, keyboard/screen reader, reduced motion. 6. **Result:** safety is communicated structurally and semantically. 7. **Deviation/new finding:** static design is not visual evidence; Test Engineer captures are required. 8. **Status:** complete.

### MSS 4.4 — UX consolidation and downstream handoff

1. **Reconfirm objective:** give `TASK-UX-MODE1` a stable consumer contract. 2. **Inspect current state:** two UX decisions and visual constraints. 3. **Intended artifact:** Funding-group handoff. 4. **Bounded design work:** downstream dialog must render Funding after Execution limits, use the shared invocation value, preserve draft/saved separation, include status reason, and show compact saved summary; it must not redefine funding fields or enablement. 5. **Focused validation:** master §6 group order and dialog responsibilities. 6. **Result:** funding is designed with the architecture, not layered afterward. 7. **Deviation/new finding:** dialog shell acceptance remains downstream. 8. **Status:** complete.

Sprint 4 consolidation/checkpoint: Objective met; four MSS complete. Intended files: downstream-approved Mode 1 component/App integration, shared styles/tokens, component tests. Focused validation: two complete 15-question UX reviews plus §§30–31 matrix. Residual risk: disabled controls without adjacent reasons would hide capability; tests must assert accessible reason association. Ready for Sprint 5: Yes.

## Sprint 5 — Serialization and AEKR boundary design

Objective: emit deterministic honest configuration and remove misleading money fields. Entry: contract/UX stable. Included: shared generator and provider serializer policy. Excluded: invented upstream keys.

### MSS 5.1 — Canonical accreatio serialization

1. **Reconfirm objective:** make funding explicit in persisted/generated accreatio-owned data. 2. **Inspect current state:** master suggested YAML and shared desktop/W1 generation. 3. **Intended implementation:** `shared/domain.ts` rendering, draft/provenance schema as applicable, golden tests. 4. **Bounded design work:** for subscription emit the explicit accreatio-owned canonical block:

```yaml
funding:
  mode: subscription_cli
  currency: USD
  max_cost: 0
  hard_stop: true
```

This block belongs only where the consumed AEKR schema version has explicitly accepted it. Until then, serialize it as `fundingPolicy` in the participant design's versioned project-signature/provenance JSON; do not create a second manifest and do not put it into runnable AEKR YAML. AEKR YAML receives only schema-proven keys. Desktop and W1 use the same pure serializer and field order. API serialization is unreachable with current production descriptors. Future eligible API serialization adds `provider`, `model_profile`, currency/max cost, `hard_stop: true`, and uses the existing `budget.max_provider_invocations`; exact key placement requires versioned AEKR evidence and golden/schema/runtime tests. 5. **Focused validation:** deterministic round-trip and schema-boundary review. 6. **Result:** explicit policy exists without corrupting or overstating AEKR support. 7. **Deviation/new finding:** the master shape is canonical intent, not proof that current AEKR accepts `funding`. 8. **Status:** complete.

### MSS 5.2 — Reconcile fixed/commented ceilings

1. **Reconfirm objective:** remove unauthorized and unequal spend implications. 2. **Inspect current state:** descriptor-owned serializer handoff from provider design. 3. **Intended implementation:** `shared/providerRegistry.ts` adapter serializer context and `shared/domain.ts`; exact YAML fixtures. 4. **Bounded design work:** change `serializeAekrAdapter(descriptor, context)` to accept validated `FundingPolicy` plus any proven contract capability. In `subscription_cli`, Claude emits only `kind: claude_code`; remove `max_budget_usd: 1.0`. Remove the commented `budget.ceiling: 10.0` for every provider. Codex sandbox behavior is unchanged. Never translate an execution-wide `maxCost` into per-adapter `max_budget_usd`, particularly once multiple participants exist: doing so multiplies or changes the authorized amount and remains role-collision-prone. A future API serializer may emit a per-call field only as a separate technical sublimit derived by an evidenced exact reservation algorithm; it can never stand in for the cumulative ceiling. 5. **Focused validation:** golden subscription YAML for Claude/Codex/mixed unique roles; negative searches for both legacy strings; repeated/5/6 compatibility guard. 6. **Result:** generated subscription configuration no longer implies paid authorization or parity. 7. **Deviation/new finding:** removing the legacy field is an intentional byte change, required by EXT-02 rather than provider-registry preservation. 8. **Status:** complete.

### MSS 5.3 — Serialization failure atomicity and security

1. **Reconfirm objective:** ensure invalid funding cannot produce partial artifacts. 2. **Inspect current state:** shared generator feeds desktop writes and W1 ZIP. 3. **Intended implementation:** typed generation errors and pre-generation validation tests; no bridge expansion unless capability evidence later requires it. 4. **Bounded design work:** validate funding, participant topology, provider/profile, and schema version before constructing/writing any artifact. Unknown fields/IDs fail closed; labels/profile display names are never used as YAML keys; trusted safe IDs only. Money serializes from normalized minor units. No network, pricing fetch, credential, provider invocation, shell input, or fallback occurs during validation/generation. 5. **Focused validation:** desktop/W1 no-partial-output fixtures, YAML-special text, unknown profile/version, deterministic repeat generation. 6. **Result:** serialization is pure and cost-free. 7. **Deviation/new finding:** existing broader write atomicity remains outside this Task except the pre-write funding gate. 8. **Status:** complete.

### MSS 5.4 — Serialization consolidation

1. **Reconfirm objective:** freeze artifact policy. 2. **Inspect current state:** MSS 5.1–5.3. 3. **Intended artifact:** checkpoint. 4. **Bounded design work:** consolidate sidecar-vs-AEKR ownership, legacy-field removal, serializer context, and atomic failure. 5. **Focused validation:** current schema and upstream dependency cross-check. 6. **Result:** no unsupported AEKR field is emitted. 7. **Deviation/new finding:** a versioned AEKR funding contract is required before runnable API output. 8. **Status:** complete.

Sprint 5 consolidation/checkpoint: Objective met; four MSS complete. Intended files: shared domain/provider serializers, generation/migration fixtures, accreatio-owned policy/provenance artifact, docs. Focused validation: exact golden YAML, forbidden legacy strings, deterministic parity, no-partial-output, current AEKR schema boundary. Residual risk: the destination/name of the accreatio-owned manifest must follow the approved participant/provenance implementation; do not invent a duplicate if provenance already owns it. Ready for Sprint 6: Yes.

## Sprint 6 — Implementation order, verification, and design gate

Objective: provide file-level execution order, evidence, risks, and owner questions. Entry: all design decisions consolidated. Included: implementation/test/doc plan. Excluded: implementation in this pass.

### MSS 6.1 — Exact file-level implementation sequence

1. **Reconfirm objective:** remove undocumented implementer decisions. 2. **Inspect current state:** architecture, dependency implementation plans, and supplemental §14. 3. **Intended artifact:** ordered plan below. 4. **Bounded design work:** implement in this order:

1. Create `shared/funding.ts`: add the discriminated funding union/default, minor-unit parser/normalizer, pure validation/reason codes, and funding eligibility logic; no Node, Electron, network, or credential concerns.
2. After participant/provider Tasks land, update `shared/providerRegistry.ts`: add funding capability/profile types, current descriptors with no API profiles, and validated funding-aware serializer context.
3. Update `shared/domain.ts`: compose funding validation, add `OrchestrationConfig.funding`, invocation-limit cross-validation, and `fundingPolicy` to versioned project-signature/provenance output. Remove the fixed/commented money emission; retain participant compatibility guard.
4. Update `src/types.ts`: re-export funding/capability types only; do not add credentials or provider billing payloads.
5. Update `tests/orchestration.test.ts` and the existing `tests/webExport.test.ts`: exact subscription default/YAML, legacy-field absence, current participant compatibility, deterministic desktop/W1 policy serialization, no-partial-artifact errors. Create `tests/funding.test.ts` for pure decimal, union, eligibility/capability, API negative, and injected exact-profile fixtures rather than overloading unrelated tests.
6. Update `src/draftStore.ts`: compose the version-aware absence-to-subscription migration and explicit-invalid/future failure behavior with participant/provider migration; update `tests/draftStore.test.ts` literal fixtures.
7. Update funding state/controls in `src/App.tsx` or the component boundary approved by `TASK-UX-MODE1`: render the downstream Funding group and summary; current API unavailable reason; draft/saved behavior; accessible validation. Do not redesign the dialog shell here. Add focused component tests in the repository’s approved UI test location.
8. Update `electron/main.ts` only to enforce a fresh funding/provider/profile/AEKR preflight before Mode 1 execution and to preserve no-fallback behavior. Do not accept credentials or arbitrary IPC. `electron/preload.ts` and bridges change only if a future evidenced AEKR capability status must cross IPC; current unavailable design needs no new privileged method.
9. Update documentation after behavior: funding/security/provider policy document, AEKR compatibility note, schema/migration record, `docs/FAQ.md`, `DECISIONS.md`, `RISKS.md`, and `CHANGE_CONTROL.md`; update the Project Map for new `shared/funding.ts` and for a UI component only if that component is actually introduced by the approved Mode 1 design.
10. A future API-enablement increment may add a profile only after owner approval and versioned AEKR schema/runtime evidence. It must update descriptor, serializer, preflight, tests, support matrix, and UX together; no configuration flag can bypass this review.

5. **Focused validation:** sequence checked against contracts → validation/tests → migration → UI/host → docs and dependency ordering. 6. **Result:** each step has an atomic review boundary. 7. **Deviation/new finding:** tightly coupled type/call-site edits may be one implementation MSS to keep compilation, but must be declared before editing. 8. **Status:** complete.

### MSS 6.2 — Focused, integrated, regression, and security verification

1. **Reconfirm objective:** define cost-free acceptance evidence. 2. **Inspect current state:** backlog evidence and package scripts. 3. **Intended artifacts:** implementation and independent Test Engineer evidence. 4. **Bounded design work:** require:

- Focused domain tests: exact subscription default; union exclusivity; USD/decimal/minor-unit boundaries; API missing fields/acknowledgment/zero/negative/precision; valid/invalid invocation limits; provider/profile/currency/version/mixed-assignment failures; injected exact-cumulative profile success; estimated/per-call rejection.
- Migration tests: literal legacy/current data with no funding becomes subscription; legacy generated money is never imported; valid new subscription round-trip; explicit malformed/API/future schemas fail visibly; participant IDs/order/providers/tasks remain byte-preserved.
- Serialization tests: subscription Claude has no `max_budget_usd`; no commented `ceiling`; Codex sandbox unchanged; explicit accreatio funding policy; current AEKR gets no unrecognized key; deterministic desktop/W1 parity; repeated/5/6 remain blocked; invalid funding produces no file/ZIP entry.
- UX/manual tests: default subscription, disabled API with associated reason, all §6 flows, input preservation, saved summary, narrow/mobile, keyboard/screen reader, both themes/hosts, 200% zoom, reduced motion, visible states, six-participant summary.
- Execution/security tests: fresh fail-closed preflight; no fallback; no credentials/secret fields/logs/IPC; no shell/user text; no network/provider calls. Test processes use pure injected descriptors and mocked local boundaries; block network and replace any provider runner with a throwing sentinel so accidental invocation fails the test.
- Integrated Task test: migrate, configure subscription, save/reopen, generate desktop/W1 artifacts, inspect policy and AEKR YAML, and confirm no paid capability/action appears.
- High-level regression: Mode 0, dry-run, project validation, one desktop generation, one W1 ZIP, settings/history, theme/locale, participant/provider behavior, typecheck/build/Project Map.
- Allowed implementation commands: focused `node --test` targets, `npm test`, `npm run typecheck`, `npm run format:check`, and `npm run build`. The prohibited `package:win`, `lighthouse`, `test:electron`, and `test:web` are not part of this design pass.

5. **Focused validation:** mapped to every backlog acceptance criterion and supplemental §§21–26, 30–31. 6. **Result:** no test can incur a paid call. 7. **Deviation/new finding:** a positive API test is contract simulation only and must be named as such, never product-support evidence. 8. **Status:** complete.

### MSS 6.3 — Risks, rollback, dependencies, and gate readiness

1. **Reconfirm objective:** close the design honestly. 2. **Inspect current state:** all Sprint consolidations and backlog risks. 3. **Intended artifact:** gate handoff. 4. **Bounded design work:** primary risks are false exactness, stale price/billing behavior, per-call/cumulative conflation, role-key collisions, migration accidentally authorizing spend, UI enablement without capability, and tests escaping mocks. Mitigations are zero default, exact capability/version gate, no price estimation, participant-ID joins, absence-only migration, disabled UI, serializer/schema tests, preflight, and network/provider sentinels. Rollback is the complete funding implementation checkpoint: restore the prior code only with a migration that preserves newer explicit funding data for recovery; never downgrade an API-shaped saved definition into implicit subscription or restore misleading fixed/commented ceilings. `TASK-UX-MODE1` consumes this contract; it may not redefine enablement. No specialist is justified because no API execution is enabled. 5. **Focused validation:** master/supplemental/backlog/dependency/security cross-check. 6. **Result:** design is ready for Orchestrator consistency review/Human Design Gate as a zero-cost explicit policy; current paid API capability remains blocked. 7. **Deviation/new finding:** full backlog acceptance for an executable API path cannot be claimed without the upstream/provider evidence described below. 8. **Status:** complete.

Sprint 6 consolidation/checkpoint: Objective met; three MSS complete. Intended implementation files and order, focused/integrated/regression/security evidence, documentation, rollback, dependencies, and residual limitation are explicit. No production file was changed. Ready for design-gate packaging: Yes, with API enablement explicitly unavailable and owner/upstream questions retained.

## Acceptance, security, migration, and test impact summary

- **UX:** Funding is a first-class group consumed by `TASK-UX-MODE1`, defaulting visibly to subscription/local CLI. API is present only as an unavailable explained mode until exact eligibility exists. Two UX decisions answer all 15 questions; visual/§§30–31 constraints are explicit.
- **Domain/schema:** required discriminated `FundingPolicy`; USD-only canonical decimal; one existing invocation-limit source; provider/profile exact-cumulative capability; participant assignments joined by `participantId`; no role-keyed funding.
- **Migration:** missing legacy funding becomes the exact subscription default. Explicit malformed/new paid data is never silently coerced. Existing generated money comments/fields do not become authorization.
- **Serialization:** remove Claude `max_budget_usd: 1.0` and commented `budget.ceiling: 10.0` in subscription mode. Record explicit funding in an accreatio-owned contract until AEKR accepts a versioned funding block. Never map a cumulative ceiling onto each adapter.
- **Security/cost:** no credentials, purchase/login, network pricing, telemetry, shell interpolation, automatic fallback, or paid test. Validation and preflight fail before writes/execution.
- **Tests:** pure fixtures/mocks/sentinels only; positive API is simulated capability-contract coverage, not a live provider call or support claim. Focused, integrated, manual, high-level regression, and independent evidence are distinct.

## Design-gate decisions and open questions

Recommended approvals:

- Approve the discriminated funding policy, subscription default, USD minor-unit semantics, existing invocation-limit linkage, participant-ID eligibility, and current API-unavailable state.
- Approve removal of both misleading legacy money emissions from subscription AEKR YAML.
- Approve the rule that only exact cumulative pre-invocation enforcement can enable API; estimated or per-call ceilings are insufficient.

Orchestrator/owner disposition required:

1. Confirm that shipping an explicit zero-cost funding selector with API visibly unavailable satisfies this Task until a separate, approved AEKR/provider API-enablement increment exists.
2. Authorize a separate AEKR contract investigation/change request, if paid API remains desired, covering a versioned participant-aware adapter binding, provider/model profile, cumulative currency-denominated ceiling, authoritative metering/reservation, atomic hard stop, invocation ceiling, runtime evidence, and schema validation.
3. Confirm the approved serialization decision: extend the participant Task’s provenance/signature artifact with `fundingPolicy`; do not create a duplicate funding manifest. A later versioned AEKR contract may additionally accept the canonical `funding` block.

## Task handoff summary

Task: `TASK-FUNDING-BUDGET`. Objective: explicit zero-cost/default and evidence-gated paid API policy. Sprints designed/completed: six; all design MSS complete. Contracts affected after approval: provider capability/profile descriptors, `OrchestrationConfig.funding`, draft/provenance schema, funding-aware validation/serializer/preflight, and Mode 1 Funding consumer UI. User-visible behavior: subscription/local CLI selected by default, paid API disabled with a precise reason, linked invocation ceiling, explicit saved summary. Known limitation: current AEKR/provider evidence supports neither participant-aware expanded adapters nor an exact cumulative monetary hard stop, so API is not executable. Rollback, documentation, and cost-free evidence are specified in Sprint 6.
