# ACCREATIO — MASTER AEKR CORRECTIVE AND EXTENSIBILITY INCREMENT

## Mandate

Act as the **Claude Orchestrator** for a bounded corrective and product-design
increment in `accreatio`.

You coordinate the work. You do not implement production changes yourself.

This session must use the existing AEKR human-gated operating model. Preserve
human approval at material transitions. Do not silently collapse participants,
skip independent contexts, auto-approve gates, or represent self-review as
independent audit.

The objective is to correct the defects exposed by the owner's desktop/PWA test,
strengthen W1 as a private local-browser repository exporter, and design a
professional provider/participant extensibility model without introducing fake
capabilities or uncontrolled API spending.

---

## 1. Required source-of-truth order

Before planning or modifying anything, every participant must follow:

1. Applicable `AGENTS.md`.
2. Current repository code and tests.
3. Current AEKR runtime schema and implementation.
4. `package.json`, `CHANGE_CONTROL.md`, `DECISIONS.md`, `RISKS.md`.
5. Current product and architecture documentation.
6. Historical planning documents only as context.

Inspect Git status first. Preserve all unrelated work. Never discard, overwrite,
reset, amend, or reformat unrelated changes.

Do not assume the supplied observations identify root causes. Reproduce each
issue against the current code.

---

## 2. Current product boundaries that remain binding

Preserve:

- local-first behavior;
- deterministic generation;
- no mandatory AI dependency;
- no telemetry;
- no silent upload;
- no secret storage by accreatio;
- no generic shell runner;
- no automatic commit or push;
- GitHub opt-in and private by default;
- W1 as an export-first PWA;
- AEKR as an independent upstream runtime;
- no SaaS implementation;
- no W2 loopback companion;
- no public W1 deployment;
- no Mode 2 autonomous persistent loop;
- no remote assets or runtime dependencies in the Project Map.

API-funded execution may be designed and implemented only as an explicit,
disabled-by-default opt-in with a hard owner-defined ceiling and no automatic
fallback to paid usage.

The default product path must remain zero-direct-cost.

---

## 3. Participants and enforced separation

Create the following AEKR work participants with distinct contexts.

### Participant A — Claude Orchestrator

Responsibilities:

- coordinate the sequence;
- enforce scope and gates;
- reconcile findings;
- maintain the decision log;
- prevent cross-role contamination;
- request owner approval at the design gate;
- issue the final integrated report.

Restrictions:

- do not implement production code;
- do not perform the independent audit;
- do not claim independent test evidence without the Test Engineer.

### Participant B — Codex Solution Designer

Use a fresh context.

Responsibilities:

- reproduce and analyze the reported defects;
- inspect relevant code and contracts;
- design the complete corrective increment;
- explore provider extensibility professionally;
- define participant topology up to six execution slots;
- specify UX, domain, schema, migration, security, and test impact;
- produce an implementation-ready design record.

Restrictions:

- no production implementation;
- no speculative provider support;
- no dependency addition without evidence;
- no change to AEKR unless a downstream requirement cannot be supported and the
  exact upstream contract change is separately justified.

### Participant C — Codex Implementer

Use a separate fresh context after design approval.

Responsibilities:

- implement only the approved design;
- add/update proportional automated tests;
- update all affected documentation and machine-readable contracts;
- preserve backward compatibility or provide an explicit migration;
- produce a precise change report.

Restrictions:

- cannot approve its own design;
- cannot audit its own work;
- cannot widen scope because a future capability appears convenient.

### Participant D — Claude Test Engineer

Use a fresh context after implementation.

Responsibilities:

- derive a test matrix from acceptance criteria;
- test desktop and web independently;
- verify actual generated artifacts, not only UI success messages;
- perform functional, responsive, keyboard, theme, duplicate-action, and
  regression tests;
- record evidence and defects;
- never modify production files.

The Test Engineer may create disposable test data and evidence files only.

### Participant E — Claude Independent Auditor

Use a fresh context after all required tests pass.

Responsibilities:

- inspect approved design, final diff, contracts, tests, evidence, security,
  accessibility, and documentation;
- identify findings by severity;
- verify no unsupported capability is represented as available;
- verify tests are independent and sufficient;
- never modify files.

### Participant F — Optional Specialist

Disabled by default.

The Designer may recommend activating one specialist only when evidence shows a
specific need, such as accessibility, provider-adapter security, or migration
compatibility.

The Orchestrator must obtain explicit approval before activating this slot.

---

## 4. Mandatory execution order

Use this sequence:

1. Repository and contract discovery.
2. Reproduction report.
3. Codex Solution Design.
4. Claude Orchestrator consistency review.
5. HUMAN DESIGN GATE.
6. Codex implementation.
7. Claude Test Engineer verification.
8. If tests fail:
   - return defects to the Implementer;
   - remediate only those defects;
   - rerun affected tests and the regression minimum.
9. Claude Independent Audit.
10. If audit reports High or Critical findings:
    - return to implementation;
    - retest;
    - reaudit affected scope.
11. HUMAN FINAL ACCEPTANCE GATE.
12. Final report.

Do not start implementation before the design gate is approved.

---

## 5. Issues that must be independently reproduced

### UX-01 — Mode 1 configuration layout

Current inline configuration presents narrow task fields with internal scrollbars,
clipped text, poor readability, and excessive vertical compression.

Reproduce in desktop and web at relevant viewport sizes.

### UX-02 — Session duration and retry/failure limits

The owner could not edit maximum session duration or maximum retries.

Determine the actual root cause. Clarify the semantic meaning of every limit.

### UX-03 — Light-theme control contrast

Theme/language controls remain visually dark or lose contrast in light mode.

Inspect all states: default, hover, selected, focus, disabled.

### UX-04 — About branding

The product About page presents personal authorship where the primary product
identity should be `accreatio`.

### WEB-01 — Browser attachments

W1 currently cannot attach discovery sources. This was previously intentional,
but the new approved target is to support local-only attachments without upload.

### WEB-02 — Mode 1 overflow in web

The same configuration layout defect occurs in W1.

### EXEC-01 — Artifact creation confidence

The owner reported that desktop and web did not create/save anything.

Do not accept or reject this claim without verification.

For desktop, test tracking, repository, and both actions separately.
For web, verify the downloaded ZIP and its contents.

### EXEC-02 — Duplicate review/export execution

Repeated clicking can potentially trigger duplicate review/export/execution.

Reproduce rapid double-click, repeated confirmation, and concurrent invocation
behavior.

### EXT-01 — Provider extensibility

The product currently exposes a bounded provider set.

Design a capability-driven provider registry and an honest extension mechanism.

### EXT-02 — API-funded execution

Design an explicit funding model for subscription/local CLI versus paid API
usage, including a maximum monetary ceiling and hard-stop semantics.

### EXT-03 — Participant topology

Current product definition is limited to four unique agents.

Design support for up to six execution participants without forcing six agents
into every project or confusing participant instances with canonical roles.

---

## 6. Required UX target: Mode 1 configuration dialog

Replace the inline expanded Mode 1 editor with an accessible centered dialog,
unless the Designer proves a superior pattern.

Expected behavior:

- opened by `Prepare Mode 1 configuration`;
- centered and viewport-safe;
- desktop/tablet width approximately:
  `min(920px, calc(100vw - 32px))`;
- responsive full-height/full-width treatment on narrow mobile;
- exactly one intentional scroll container;
- no permanent scrollbar inside task text fields;
- task controls auto-grow to a bounded height;
- clear grouping:
  1. Participants
  2. Providers
  3. Execution limits
  4. Funding, when enabled
- sticky or otherwise continuously accessible footer;
- `Cancel` and `Save configuration`;
- save validates and persists;
- successful save closes the dialog;
- main form shows a compact saved summary;
- configuration can be reopened and edited;
- Escape cancellation;
- focus trap;
- initial focus;
- focus restoration;
- visible focus;
- keyboard-complete operation;
- no background interaction while open;
- no body horizontal overflow;
- no nested scrolling trap.

Do not implement a free-floating draggable window unless accessibility and
responsive behavior are demonstrably superior.

---

## 7. Execution-limit semantics

The design must name and model each concept accurately:

- maximum session duration;
- maximum iterations per entity;
- maximum provider invocations;
- maximum consecutive failures;
- provider-specific technical retry behavior, only if actually configurable.

Do not label `maximum consecutive failures` as generic `retries`.

Inputs must:

- allow keyboard editing;
- support valid intermediate editing states;
- validate on blur/save without destructive resets;
- expose min/max/help text;
- persist after reopening;
- serialize correctly;
- migrate existing configurations safely.

Use the actual current AEKR schema as the authority.

---

## 8. Funding and API budget model

Design an explicit execution funding selector.

Minimum modes:

- `subscription_cli`
- `api`

Default:

- `subscription_cli`
- paid API disabled
- zero mandatory direct cost

For API mode require:

- selected provider;
- provider/model profile;
- currency;
- maximum allowed monetary cost;
- hard-stop acknowledgment;
- maximum provider invocations;
- clear statement of whether cost enforcement is exact or estimated.

Suggested canonical contract:

```yaml
funding:
  mode: subscription_cli
  currency: USD
  max_cost: 0
  hard_stop: true
```
