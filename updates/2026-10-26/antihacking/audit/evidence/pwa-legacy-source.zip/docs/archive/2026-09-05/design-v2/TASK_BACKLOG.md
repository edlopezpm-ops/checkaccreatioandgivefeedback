# UI/UX Rebuild — Task Backlog (Sprints 3–8)

Implementation brief for every task: `UX_AUDIT.md`, `DESIGN_RESEARCH.md`, and `VISUAL_DIRECTION.md`. Every relocation or redesign below must retain behavioral equivalence with Master Prompt §18; no current capability may be removed.

## TASK-V2-01 — Quiet-formation app shell and responsive IA

- **Goal:** Replace the dashboard-like frame with the accessible `AppFrame`, product navigation, scoped status, responsive layout, reconciled tokens, and unboxed brand treatment.
- **Files:** `src/App.tsx`; `src/styles.css`; `src/responsive.css`; `src/extras.css`; `src/components/AppFrame.tsx`; `src/components/FormationMark.tsx`; `src/components/StatusNotice.tsx`; `tests/theme.test.ts`; `tests/appShell.test.ts`.
- **Dependencies:** None.
- **Acceptance:** Dark/light tokens match `VISUAL_DIRECTION.md`; header exposes every currently available host-specific destination; language/theme actions remain functional; system state is textually scoped rather than always “Ready”; layouts have no horizontal scroll at 320px and switch at the specified 768/1200px boundaries; semantic landmark, keyboard, focus, and contrast tests pass.
- **Residual risk:** Static DOM/style tests cannot prove visual balance or 200% zoom behavior without a browser-capable host.

## TASK-V2-02 — Skippable local-first onboarding

- **Goal:** Add the two-screen first-run welcome/continue experience without gating returning users or changing web/desktop execution boundaries.
- **Files:** `src/App.tsx`; `src/components/Onboarding.tsx`; `src/draftStore.ts`; `src/styles.css`; `src/responsive.css`; `tests/onboarding.test.ts`; `tests/draftStore.test.ts`.
- **Dependencies:** TASK-V2-01.
- **Acceptance:** First run shows “What you will make” and “What stays local,” duration and output expectations; Skip and Finish both enter creation; completion persists locally per host and can be revisited; existing drafts restore unchanged; no account/cloud execution is implied; keyboard and mobile flows are complete.
- **Residual risk:** Browser storage may be unavailable or cleared, so onboarding can reappear with a truthful recovery message.

## TASK-V2-03 — Guided creation framework and Foundation/Context stages

- **Goal:** Introduce reversible five-stage navigation and move project identity, phase, attachments, context, constraints, and route into outcome-led Foundation and Context stages.
- **Files:** `src/App.tsx`; `src/components/creation/CreationWorkspace.tsx`; `src/components/creation/StageNavigation.tsx`; `src/components/creation/FoundationStage.tsx`; `src/components/creation/ContextStage.tsx`; `src/components/creation/AdvancedDisclosure.tsx`; `src/components/creation/LocalityNote.tsx`; `src/styles.css`; `src/responsive.css`; `tests/creationStages.test.ts`; `tests/webAttachmentsUi.test.ts`.
- **Dependencies:** TASK-V2-01.
- **Acceptance:** Rail/strip/selector exposes Foundation, Context, Team, Delivery, Review with current/complete/attention text and icon states; stage exit and final validation focus/link to the first invalid field; all existing phase, attachment, context, restriction, and route values round-trip unchanged; web file-byte limitations and draft location appear at point of use; revisiting stages loses no data.
- **Residual risk:** Refactoring state out of the monolith may expose hidden coupling between validation, attachments, and generated prompt updates.

## TASK-V2-04 — Team and Delivery stages with full operational equivalence

- **Goal:** Relocate participants, optional Mode 1, output/action, destination, dry-run, Git, GitHub, IDE, and tracking choices into progressively disclosed Team and Delivery stages.
- **Files:** `src/App.tsx`; `src/components/creation/TeamStage.tsx`; `src/components/creation/DeliveryStage.tsx`; `src/components/mode1/Mode1ConfigurationDialog.tsx`; `src/extras.css`; `src/responsive.css`; `tests/creationDelivery.test.ts`; `tests/mode1Dialog.test.ts`; `tests/funding.test.ts`; `tests/providerRegistry.test.ts`.
- **Dependencies:** TASK-V2-03.
- **Acceptance:** Ordered/repeated participant behavior and responsibilities remain equivalent; Mode 1 retains native dialog, provider/task/limit/funding validation, save/cancel, and host restrictions; repository/tracking/both, destination, dry-run default, Git/GitHub/IDE options produce the same core inputs as baseline; unavailable choices explain why; advanced summaries state configured values.
- **Residual risk:** Plain-language labels could obscure auditable technical terms unless secondary labels are consistently retained.

## TASK-V2-05 — Review manifest and non-competing prompt preview

- **Goal:** Move the full read-only prompt and plan into Review, with artifact/destination/limitation summaries, section navigation, copy/download actions, and an invoked contextual summary elsewhere.
- **Files:** `src/App.tsx`; `src/components/creation/SummaryDrawer.tsx`; `src/components/creation/ReviewStage.tsx`; `src/components/creation/ReviewManifest.tsx`; `src/styles.css`; `src/responsive.css`; `tests/reviewManifest.test.ts`; `tests/core.test.ts`.
- **Dependencies:** TASK-V2-04.
- **Acceptance:** Prompt content and deterministic plan equal baseline output for identical input; Review lists artifacts, destination, limitations, attachment manifest, and links to incomplete/invalid stages; prompt is read-only with working copy/download and anchors; earlier stages have no permanent competing preview column; confirmation still states exact dry/live/export consequences.
- **Residual risk:** Clipboard/download APIs require host-level smoke coverage beyond unit tests.

## TASK-V2-06 — Creation outcome, evidence, and recovery

- **Goal:** Replace the right-rail result with a dedicated outcome state that communicates creating, completed, partial, failed, and download-requested results plus safe next actions.
- **Files:** `src/App.tsx`; `src/components/creation/OutcomePanel.tsx`; `src/operationGuard.ts`; `src/styles.css`; `src/responsive.css`; `tests/executionEvidenceUi.test.ts`; `tests/operationGuard.test.ts`; `tests/webExport.test.ts`.
- **Dependencies:** TASK-V2-05.
- **Acceptance:** Desktop filesystem creation and web ZIP export invoke existing guarded paths unchanged; results expose created/versioned/skipped/failed evidence and recovery without color-only meaning; existing-file versioning, no automatic push, and dry-run behavior remain explicit; success offers relevant open/copy/download/orchestration actions; retry cannot duplicate a guarded operation.
- **Residual risk:** Native dialogs, IDE opening, filesystem results, and actual ZIP download still need packaged desktop/web smoke tests.

## TASK-V2-07 — Disabled-by-default future account and consent boundary

- **Goal:** Add typed auth/account/consent contracts, local mock states, and UI boundaries without enabling remote identity, trackers, ads, billing, or password storage.
- **Files:** `src/types.ts`; `src/account/contracts.ts`; `src/account/mockProvider.ts`; `src/account/consent.ts`; `src/components/account/AuthFlow.tsx`; `src/components/account/AccountShell.tsx`; `src/components/account/PrivacyControls.tsx`; `src/App.tsx`; `src/styles.css`; `tests/accountContracts.test.ts`; `tests/consent.test.ts`.
- **Dependencies:** TASK-V2-01.
- **Acceptance:** Environment/config defaults keep account and optional-consent UI inactive; mock covers logged-out, code/link sent, verified, expired/error, account, logout, export request, and deletion request states without passwords; necessary and optional consent are separate and optional refusal never blocks local creation; analytics/ads adapters are no-ops and no network request occurs; existing no-account flow remains the default.
- **Residual risk:** Mock contracts require future server-side threat modeling, retention policy, rate limiting, and legal review before real authentication or tracking.

## TASK-V2-08 — About and future public continuity

- **Goal:** Redesign About as an editorial product/trust surface reusable by a future landing while retaining every current document and administrative fact.
- **Files:** `src/App.tsx`; `src/components/AboutExperience.tsx`; `src/components/PublicContent.tsx`; `src/styles.css`; `src/responsive.css`; `tests/about.test.ts`.
- **Dependencies:** TASK-V2-01, TASK-V2-07.
- **Acceptance:** About explains describe → organize → take your project, local-first operation, security/privacy limits, orchestration, FAQ structure, and a next action; version, license, copyright, creator attribution, existing legal links, and document access remain present; legal text is labeled draft where applicable and makes no unverified compliance claim; shared brand/content components work in web and desktop.
- **Residual risk:** Final public copy and legal language need owner/legal review before external publication.

## TASK-V2-09 — Cross-flow hardening and equivalence regression suite

- **Goal:** Harden the rebuilt experience across accessibility, responsive/offline states, performance, error boundaries, empty states, and end-to-end capability equivalence.
- **Files:** `src/main.tsx`; `src/App.tsx`; `src/components/WebExperience.tsx`; `src/styles.css`; `src/responsive.css`; `src/extras.css`; `src/polish.css`; `tests/accessibility.test.ts`; `tests/responsive.test.ts`; `tests/projectMap.test.ts`; `tests/bridge.test.ts`; `tests/files.test.ts`; `tests/webExport.test.ts`.
- **Dependencies:** TASK-V2-02, TASK-V2-03, TASK-V2-04, TASK-V2-05, TASK-V2-06, TASK-V2-07, TASK-V2-08.
- **Acceptance:** Automated tests prove §18 equivalence for creation, phases, context, restrictions, routes, participants, optional orchestration, preview, structure generation, ZIP, dry-run, Git/GitHub/IDE guides, local storage, About/documents, themes, and status; all empty/error/offline states explain cause and next action; keyboard, screen-reader semantics, reduced motion, 44px targets, 320px/200% layout, typecheck, test, build, packaged smoke, and functional UI checks pass or host blockers are explicitly evidenced.
- **Residual risk:** Electron/Chromium cannot launch in the current container, so visual, packaged, and assistive-technology validation must be completed on a capable host before release.
