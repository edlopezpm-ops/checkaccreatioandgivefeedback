# Interactive Nebula, Orbital Identity & AEKR Signature

Owner authorization: Ed Lopez, 2026-08-05. Baseline: `f37f91f` on `main`.

## Outcome

accreatio now has one persistent, locally bundled Vanta `FOG`/Three atmosphere. Broad shader motion creates the autonomous gel-like field; accreatio adds a slower counter-moving CSS plane and bounded inverse mouse parallax for depth. A directional mask keeps the nebula strongest on the right and lets it dissolve toward the left. View-specific density/speed/reading anchors preserve usable negative space across onboarding, creation, review, export, About, and quiet views.

The product mark is now a transparent orbital lowercase `a` drawn as a 256×256 SVG with no image/rectangle background. It blends directly into the shell and onboarding, while a violet contour keeps the luminous glyph recognizable on the new cool ice/lavender light theme. One local script regenerates the actual referenced 192/512 PWA icons and social preview; the 512 render is the configured Windows package source.

A small original vector “Built with AEKR” signature sits unobtrusively at the lower safe-area edge. It is non-interactive, uses no panel/border, and collapses to the icon on narrow mobile. It acknowledges the owner-requested governed-build relationship without copying AEKR handbook content or claiming certification.

No ESA/Webb image is bundled. The supplied gallery/reference informed direction only; every shipped atmosphere/logo pixel comes from local procedural rendering, local SVG, CSS, or the deterministic brand render script.

## Runtime and fallback behavior

- `vanta@0.5.24` and `three@0.185.1` are exact runtime pins and dynamic local imports; no CDN or external runtime host is used.
- Vanta input tracking is disabled. A passive accreatio listener writes visual-only CSS properties and never exceeds 16 px horizontal parallax.
- One effect/canvas persists through ordinary view and theme changes; theme/view values update through `setOptions`.
- Reduced motion, save-data, slow-update, missing WebGL, initialization failure, hidden documents, and context loss select/recover through a static CSS fallback. Coarse pointers receive no cursor-local response.
- Hidden tabs release the renderer because Vanta has no supported pause API. Cleanup removes listeners, cancels the local frame, and destroys the effect.
- The renderer is `aria-hidden`, cannot receive pointer events, receives no project data, and has no bridge/IPC/filesystem/Git/credential/orchestration capability.

## Validation evidence

Final `npm run verify` result: **pass**.

- Unit/general suite: 176/176 passing.
- Project Map: 17 nodes, 30 edges, 9 flows; generated HTML parity and four-viewport `file://` smoke passing with zero external requests.
- Application/Electron TypeScript and Prettier: passing.
- Production PWA build: passing.
  - main application JS: 348.04 kB / 108.81 kB gzip;
  - CSS: 66.36 kB / 12.70 kB gzip;
  - Vanta lazy chunk: 12.37 kB / 4.35 kB gzip;
  - Three lazy chunk: 724.20 kB / 184.68 kB gzip;
  - service-worker precache: 17 entries / 1,661.92 KiB.
- Electron privileged execution smoke: passing.
- W1 functional smoke: passing, including autonomous frame change, one canvas across theme/navigation, ≤16 px pointer bound, no pointer interception, no external resource host, IndexedDB restore/new draft, Mode 1 preparation, duplicate-safe ZIP export/rerun, legal links, context-loss fallback, reduced-motion no-canvas mode, and missing-WebGL no-canvas mode.
- Lighthouse: performance 92 on the implementation run and 91 on the clean post-audit rerun; accessibility 100, best practices 100, and SEO 100 on both. Both performance results exceed the 80 gate.
- `npm audit --audit-level=high`: zero vulnerabilities.
- Brand generation: 192×192 and 512×512 RGBA icons plus 1200×630 social image; runtime/PWA/package references point to the generated current assets.

Rendered inspection covered:

- `/tmp/accreatio-visual-v4/01-onboarding-dark.png`
- `/tmp/accreatio-visual-v4/02-creation-dark.png`
- `/tmp/accreatio-visual-v4/03-creation-light.png`
- `/tmp/accreatio-visual-v4/04-mobile-light.png`
- `/tmp/accreatio-visual-v4/05-ultrawide-dark.png`
- `/tmp/accreatio-visual-v4/06-header-logo-light.png`

The inspection confirmed right-biased atmospheric depth, readable dark/light instruments, no rectangular logo asset boundary, a legible light-mode mark, and a visually subordinate AEKR signature. Mobile preserves 16 px content gutters and reduces the signature to its icon.

## Known limits and honest failures

- Three remains a 724.20 kB minified lazy chunk and triggers the build's standard >500 kB warning. The warning was not suppressed. Lighthouse still passes at 92, but load/precache/GPU cost remains open in `RISKS.md`.
- Vanta is older and documents a much earlier Three generation. The exact current pair passed real-browser validation but is not represented as an upstream-supported compatibility guarantee.
- `npm run package:win` reached electron-builder but failed in this Linux dev container because the `/tmp`-backed `dist-electron` symlink was omitted from the ASAR. The icon configuration/source has automated coverage, but no successful new portable artifact is claimed. A Windows or non-symlink release-host package/process smoke remains mandatory and is recorded as an open risk.
- Visual motion perception varies by display/GPU. Reduced-motion/static fallback is the supported accessibility and resilience path, not a claim of identical animation everywhere.

## Data, cost, deployment, and rollback

No project/draft schema, attachment data, bridge/IPC, privileged action, AEKR runtime contract, credential, telemetry, hosted service, or public deployment changed. Runtime assets are local and cost no service money. Public release remains on hold under DEC-009.

Rollback is the pre-phase source baseline `f37f91f`; no data migration is required. Existing browser drafts remain compatible. A service-worker user may need to accept the normal update prompt to receive a rollback build.

## Independent audit handoff

This implementation was authored and internally validated by Codex; that validation is not represented as independent. After commit `7da2707` was pushed and verified equal to `origin/main`, Claude independently reviewed the complete repository, the implementation range, rendered evidence, and applicable AEKR guidance in a fresh read-only session. Claude changed nothing and returned **PASS WITH NON-BLOCKING IMPROVEMENTS** with no Critical or High code findings.

The Low findings were: Claude could not independently rerun quantitative commands in its restricted audit context; removal of redundant PWA `includeAssets` needed explicit precache confirmation; hidden-document lifecycle lacked an automated browser scenario; and Windows packaging remains an open release gate. Codex then restored the exact lockfile with `npm ci`, confirmed zero vulnerabilities, reran `npm run verify` successfully, and confirmed `dist/sw.js` precaches all three generated PNGs. The post-audit Lighthouse performance sample was 91 rather than the initial 92; all other scores remained 100. Hidden-tab automation and Windows packaging remain open in `RISKS.md`; no audited implementation code was changed. See `CLAUDE_AUDIT_REPORT.md` for the complete report and evidence attribution.
