# Project Discovery — Prompt to Start

## Executive summary

Prompt to Start eliminates the fragile copy/paste and memory burden between having a software idea and creating its first governed artifacts. Its primary user is an experienced technical builder starting multiple unrelated projects from the AI Engineering Knowledge Repo toolkit.

The product is deliberately not an AI agent or “project operating system.” It captures a definition, produces the canonical toolkit prompt, previews deterministic actions, supports dry-run, and performs a safe first filesystem/Git step.

## Problem and outcome

Today the canonical `START.md` contract is correct but manual. The user must remember field meanings, paths, phase rules, and safe setup steps. The desired outcome is a repeatable local workflow where the user can inspect both the generated prompt and exact action plan before execution.

## Primary journey

1. Configure local toolkit and project paths once.
2. Enter project identity, phase, context, restrictions, operating route, requested AI role, and expected action.
3. Inspect the canonical prompt and deterministic action plan.
4. Run a no-write dry-run or confirm execution.
5. Receive success/error evidence and logs.
6. Optionally open the created local repo in VS Code.

## Product decisions

- Product name: Prompt to Start; repository slug `prompt-to-start`.
- Zero-cost, desktop-first, Windows-first, local-only MVP.
- React + TypeScript + Electron for immediate delivery because Node is installed and Rust is not. Tauri remains a later packaging alternative.
- No embedded AI. Generated prompts are outputs for whichever assistant the user chooses later.
- Remote Git hosting is excluded from MVP. Local Git is optional and creates no commit automatically.
- Tracking-only, dedicated-repo, and both flows are supported.
- Existing target paths cause a hard stop; merging/overwrite is not offered.

## Architecture

```text
React UI (web reusable)
  → pure prompt/validation/action planner
  → narrow typed preload API
  → Electron application service
      ├─ filesystem adapter
      ├─ Git process adapter
      ├─ local settings
      ├─ folder dialog
      └─ optional IDE launcher
```

The browser-facing layer never receives Node access. The executor uses filesystem APIs for content and invokes Git with a fixed executable plus typed argument array. The MVP intentionally avoids a generic shell runner.

## MVP scope

Included: local settings, guided form, live prompt preview, action preview, validation, dry-run, exclusive file/folder creation, initial governance documents, optional local Git init, logs, result state, optional IDE opening, dark/light themes.

Excluded: AI, authentication, cloud sync, remote execution, GitHub repo creation, plugins, collaboration, embedded terminal/editor, history/resume, auto-update, multiple profiles, web deployment, packaged installer and code signing.

## Definition of done

- Core domain behavior has automated tests.
- Typecheck and production build pass.
- UI is visually and functionally inspected at desktop size.
- A dry-run and one isolated real execution complete without overwrite.
- Documentation names risks and deferred questions.
