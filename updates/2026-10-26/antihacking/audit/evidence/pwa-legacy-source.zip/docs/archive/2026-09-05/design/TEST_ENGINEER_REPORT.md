# Participant D — Test Engineer Report

Date: 2026-08-05  
Role: Codex Test Engineer in a fresh context, per Ed Lopez's explicit substitution  
Scope: integrated increment verification and high-level risk-based regression for all nine corrective Tasks; no production remediation

## Executive verdict

**Needs correction first.** Five deterministic baseline gates passed. The three real-host gates could not run in this managed devcontainer because it prohibits Chromium/Electron startup and localhost listeners. Independent contract-level testing did verify a real mixed text/binary ZIP, but it also reproduced one Medium product defect in W1 partial-failure reporting. The reserved smoke harnesses do not cover the complete acceptance matrix they were said to cover, and the required live Mode 1, desktop artifact, download, persistence, theme, keyboard, responsive, and zoom evidence therefore remains incomplete.

This is not a systemic regression finding: the completed deterministic checks are healthy, and the reproduced defect is bounded to W1 outcome reporting when ZIP creation succeeds but requesting the browser download throws. It still requires a bounded correction and a rerun in a host that permits Chromium/Electron before Independent Audit.

## 1. Full verification baseline

Commands were run in the requested order. `package:win` was not run.

| # | Command | Result | Evidence |
|---:|---|---|---|
| 1 | `npm test` | **PASS** | Exit 0; 16 test files, 127 tests, 127 passed, 0 failed. |
| 2 | `npm run typecheck` | **PASS** | Exit 0; application and Electron TypeScript checks clean. |
| 3 | `npm run format:check` | **PASS** | Exit 0; all matched files conform to Prettier. |
| 4 | `npm run build` | **PASS** | Exit 0; 1,808 modules transformed; web/PWA and Electron TypeScript builds completed. |
| 5 | `npm run project-map:check` | **PASS** | Exit 0; 17 nodes, 30 edges, 9 flows verified. |
| 6 | `npm run test:electron` | **FAIL — environment blocked** | Electron exited by `SIGTRAP` before application readiness: `FATAL:content/browser/sandbox_host_linux.cc:41 ... Operation not permitted (1)`; no smoke result file was created. A standalone Playwright Chromium launch reproduced the same fatal host restriction. |
| 7 | `npm run test:web` | **FAIL — environment blocked** | The preview server could not start. Direct reproduction with its exact Vite command returned `listen EPERM: operation not permitted 127.0.0.1:4175`. |
| 8 | `npm run lighthouse` | **FAIL — environment blocked** | The preview endpoint was unreachable and `fetch` failed with `AggregateError [EPERM]`. The script could not reach browser launch or scoring. |

The last three results are failures of the required commands and are reported as such. Their signatures demonstrate a container execution restriction rather than an accreatio runtime assertion failure; they do not count as product defects below. No permission escalation was available or attempted.

## 2. Findings by severity

### Critical

None.

### High

None.

### Medium

#### M-01 — W1 download-request failure contradicts its own completed-step evidence

Acceptance affected: `TASK-EXEC-EVIDENCE` partial-completion reporting and Supplemental §24 web execution reliability.

Reproduction:

1. Instantiate `createWebExecutionBridge` with a successful archive dependency (`new Blob(["zip"])`) and a download dependency that throws `Error("download blocked")`.
2. Execute a valid, non-dry repository request.
3. Observe the returned result:

```json
{
  "ok": false,
  "outcome": "failure",
  "completed": [],
  "steps": [
    { "id": "zip-build", "status": "completed", "summary": "ZIP built in memory" },
    { "id": "download-request", "status": "failed", "summary": "Browser download request failed" }
  ]
}
```

File/line evidence:

- `src/bridge/web.ts:105-118` defines the failure helper with unconditional `completed: []` and `outcome: "failure"`.
- `src/bridge/web.ts:171-190` explicitly records ZIP build as completed before routing a thrown download request through that helper.
- `tests/bridge.test.ts:247-274` codifies the contradictory state by expecting top-level `failure` while also expecting step statuses `completed, failed`; it does not assert `completed`.

Verified impact: the UI/result contract cannot accurately distinguish “ZIP was built, delivery request failed” from “nothing completed.” This can give incorrect recovery guidance and violates the approved requirement to list completed versus incomplete work honestly. The archive exists only in memory and no persistence can be claimed, but the completed build step must still be represented consistently. This is bounded, not systemic.

#### M-02 — Reserved functional smoke tooling does not cover the promised integrated acceptance matrix

Acceptance affected: live evidence for `TASK-UX-MODE1`, `TASK-EXEC-IDEMPOTENCY`, `TASK-WEB-ATTACHMENTS`, `TASK-EXEC-EVIDENCE`, and the high-level regression minimum.

Reproduction/evidence:

- `electron/main.ts:534-595` hard-codes only `action: "repository"`, `dryRun: false`, no attachments, and no injected mid-operation partial failure. It does not execute tracking, both, or desktop dry-run.
- `scripts/electron-execute-smoke.mjs:130-176` checks concurrent repository execution, versioned files, recovery, and history, but not tracking/both output trees, dry-run no-write, attachments, or a partial result after a durable step.
- `scripts/web-functional-smoke.mjs:54-138` exercises draft persistence and a repository ZIP download count, but selects no attachments, does not save/unzip the download, does not compare manifest order/bytes, does not test dry-run no-download, and does not test reload reselection.
- `scripts/web-functional-smoke.mjs:58-71` opens Mode 1 only to inspect/add/remove participant task rows. It does not test heading focus, Tab/Shift+Tab trap, Escape/restoration, backdrop behavior, Save/Cancel mutation, numeric blur/save validation, themes, computed breakpoints, scrolling, overflow, or zoom.

Verified impact: even on a permissive host, passing these two reserved commands would not establish multiple explicitly required acceptance criteria. In this container the harnesses were also unable to start, so no supplemental live evidence closed the gap. This is a test-evidence/tooling deficiency rather than proof that each underlying product behavior is defective.

### Low

#### L-01 — Desktop SOP implies dialog Save itself writes orchestration YAML

Acceptance affected: documentation/implementation consistency and Save semantics.

Reproduction/evidence:

- `docs/SOP_DESKTOP.md:86` says, “Saving writes a `.ai-engineering/orchestration.yaml` into the generated project.”
- `src/App.tsx:1263-1279` shows dialog Save only updates project state through `setP`; closing/canceling only controls dialog state/focus.
- `electron/main.ts:319-345` writes the YAML later, during a non-dry repository/both execution when orchestration is enabled.

Verified impact: a user can reasonably expect a filesystem artifact immediately after pressing Save, even though Save only mutates the project definition. This is documentation divergence, not data loss.

### None / observations not promoted to defects

- The previously disclosed `100dvh`-without-`100vh` fallback and resize-listener-without-`ResizeObserver` items could not be impact-tested because Chromium could not launch. Current target Chromium support makes neither a reproduced defect in this pass.
- Baseline host failures were environmental and are not included in severity counts.

## 3. Explicit clean confirmations and bounded evidence

### Mode 1 dialog

Source and automated-test inspection confirms the intended mechanisms exist:

- native modal `showModal()`, initial heading focus, body scroll lock, and trigger-focus restoration (`src/components/mode1/Mode1ConfigurationDialog.tsx:176-183`, `src/App.tsx:1275-1279`);
- no backdrop click-close handler; Cancel/close/Escape route through dialog close without calling Save;
- Save normalizes/validates before `onSave` (`Mode1ConfigurationDialog.tsx:204-212`);
- invalid numeric strings remain in controlled text inputs, and errors appear after blur or attempted Save (`src/components/mode1/NumericDraftField.tsx:14-52`);
- desktop width and responsive CSS are present: `min(920px, calc(100vw - 32px))`, one declared body scroller, 720px stacking, and ≤600px viewport treatment (`src/extras.css:539-557,618-626`; `src/responsive.css:231-271`);
- semantic focus ring styling exists for both theme token sets.

These are structural confirmations only. Actual focus containment, computed dimensions, scroll-container count, overflow, dark/light readability, responsive boundaries, and 200% zoom are **not passed** because no rendered browser/Electron target could run.

### Real artifacts and idempotency

Passed independently at contract level:

- A real ZIP was created with `client-zip`, then inspected with `unzip`.
- Claimed and actual order matched exactly: `PROJECT_PROMPT.md`, discovery, `AGENTS.md`, project provenance, `SETUP.md`, text attachment, binary attachment.
- Text attachment bytes matched `61 6c 70 68 61 0a 62 65 74 61 0a`; binary bytes matched `89 50 4e 47 00 01 02 ff` under `artifact-evidence/docs/product/sources/`.
- The temporary evidence directory was removed after inspection.
- Unit/integration tests passed for dry-run no-download, W1 concurrent coalescing, deliberate rerun, archive/download failures, Electron guard behavior, and versioned writes.

Not passed live:

- real desktop tracking, repository, and both actions and their resulting trees/history;
- desktop and W1 dry-run absence of all real mutations/downloads;
- direct concurrent Electron IPC and live rapid UI confirmation;
- actual W1 attachment selection/download/reload flow;
- desktop partial failure after a durable step.

The Electron harness source is consistent with one repository idempotency path: three concurrent same-logical requests coalesce, deliberate subsequent requests create `(1)` and `(2)` versions, invalid concurrent calls coalesce, recovery succeeds, and history is expected to contain three entries. It could not execute here, so those are not claimed as live passes.

### Participant, provider, funding, attachment spot-checks

Passed through the green integrated suite plus source/contract inspection:

- one through six ordered participant instances and repeated canonical roles validate; generated prompt/governance/provenance preserve participant IDs/order;
- enabled Mode 1 rejects repeated roles or more than four participants with exact `orchestrationContractUnsupported` (`shared/domain.ts:250-276`), which is the expected current AEKR limitation;
- provider options render from `PROVIDER_REGISTRY`; W1 returns `unsupported_host`/`host_cannot_detect` for every registered provider (`shared/providerRegistry.ts:345-350`) while deterministic configuration export remains available;
- funding defaults to `subscription_cli`, USD zero, hard stop true (`shared/funding.ts:56-61`); API is rendered disabled with the stated exact-hard-stop reason and no enabled UI path;
- draft schema is v5, persists no attachment metadata/bytes, and keeps only a bounded count marker (`src/draftStore.ts:7,27-39,71-81`);
- the independently inspected ZIP contained mixed text/binary attachments byte-for-byte under the required source directory.

The live six-participant dialog density and actual reload warning presentation remain unverified due to the host restriction.

## 4. High-level regression result

Passed cleanly:

- project-definition validation and Mode 0 default through the 127-test suite;
- build and type integrity;
- theme/locale/About static render assertions, including both locales and owner-approved “copyright holder and licensor” / Spanish equivalent;
- settings/history domain and bridge behavior covered by the green suite;
- Project Map integrity;
- deterministic web export contents and attachment lifecycle contracts.

Not established live:

- desktop startup;
- web startup;
- rendered theme and locale switching;
- rendered settings persistence and history behavior;
- host-specific About appearance/keyboard order;
- live real-generation paths.

No evidence from the completed high-level checks indicates a systemic regression. The unexecuted live matrix is a release-evidence gap, not a pass.

## 5. Documentation-claim spot check

| Document | Concrete claim checked | Result |
|---|---|---|
| `docs/SOP_DESKTOP.md` | Mode 0 default; Mode 1 provider/task/limit configuration and generated YAML | **Partial:** Mode 0, controls, and generation path match; the Save timing statement is inaccurate (L-01). |
| `docs/SOP_WEB.md` | attachments are transient/reselected; real ZIP contains byte-identical sources; dry-run does not download; provider detection unavailable | **Matches contract and inspected ZIP.** Reload UI itself was not live-rendered. |
| `docs/PRIVACY_POLICY.md` | draft uses IndexedDB while attachment names/metadata/bytes are omitted; export is local and no persistence is claimed | **Matches source and tests.** No live network observation was possible. |
| `docs/FAQ.md` | subscription/local CLI is default; paid API unavailable; 1–6 participants with Mode 1 fail-closed topology; attachment limits/lifecycle | **Matches source and green tests.** |

## 6. Test tooling and repository hygiene

New test-tooling files added: **none**. A new Playwright script was not added because the environment cannot launch Chromium or bind a preview server; an unexecutable script would not constitute evidence. The existing harness coverage gap is reported as M-02 for a future bounded correction.

Only this report file was added. No production file was modified. Temporary ZIP fixtures were created only under `/tmp` and cleaned up.

## 7. Scope disclaimer and required next action

This was the high-level, risk-based regression tier defined by Supplemental §24 and §26. It did not attempt full historical regression of every pre-existing capability. No completed check revealed the systemic triggers in §25, so a full `TASK-REGRESSION-REMEDIATION` escalation is not indicated.

Before Independent Audit:

1. correct M-01 in a bounded correction cycle and add an assertion that top-level outcome/completed evidence agrees with step evidence;
2. extend the functional tooling or run an equivalent documented manual/Playwright matrix that actually covers M-02;
3. rerun all eight baseline commands in an environment that permits Electron, Chromium, and localhost listeners;
4. complete the live Mode 1, desktop artifact, W1 downloaded-ZIP/reload, accessibility, responsive, theme, and zoom checks listed above.

## Final counts

Findings: Critical=0, High=0, Medium=2, Low=1.  
Systemic/escalation-worthy regression found: No.  
Verdict: **Needs correction first**.
