# Validated Task Backlog

Status: validation only. This backlog refines the sequence in `SUPPLEMENTAL_PROMPT.md` §17 from the confirmed and partially confirmed findings in `REPRODUCTION_REPORT.md` and the current accreatio codebase. It defines Task boundaries and order; it does not select detailed solutions, Sprint structures, or implementation mechanics.

The nine proposed product objectives remain distinct Tasks. The validated order moves the three Mode 1 contract Tasks ahead of the Mode 1 dialog, because the dialog must consume rather than anticipate the participant, provider, and funding models. It also places duplicate prevention before artifact feedback, so completion evidence is tied to one logical operation. The default path remains local-first, dry-run-on, and zero-direct-cost. No Task authorizes SaaS, W2, public deployment, telemetry, secret storage, automatic commit/push, a generic shell runner, or Mode 2.

## TASK-DESIGN-THEME — Semantic theme and control foundation

**Objective:** Establish a restrained, logo-derived semantic visual system for desktop and W1 and correct the confirmed light-theme control-state defect before other affected UI is rebuilt.

**Explicit scope:** Dark and light semantic tokens; shared surface, text, border, accent, focus, status, and control states; theme/language header controls and corresponding Settings controls; desktop/web consistency; supported responsive sizes, 200% zoom, reduced motion, and contrast verification. Includes UX-03.

**Non-goals:** Mode 1 information architecture; participant/provider/funding contracts; decorative galaxy backgrounds; unrelated page redesigns; remote fonts/assets; About copy or legal ownership decisions.

**Dependencies:** None. This is the UI foundation consumed by later Tasks.

**Acceptance criteria:**

- Both themes use documented semantic tokens derived from the actual logo, with intentional—not inverted—light-mode choices.
- Theme/language controls have distinguishable default, hover, selected/current, focus, and applicable disabled states in both hosts and themes.
- Text and interactive-state contrast meet the project’s accessibility expectations; focus is unmistakable without color being the only status signal.
- Existing critical forms remain readable and operational at supported widths and 200% zoom, and reduced-motion preferences are respected.
- Desktop and W1 render the same semantic component language without remote runtime assets.

**Relevant files/subsystems:** Logo/static assets; `src/styles.css`; `src/extras.css`; `src/responsive.css`; theme/language controls and Settings UI in `src/App.tsx`; shared UI tests or new focused style/component tests; Project Map if component/file boundaries change.

**Assigned participants:** B designs tokens and visual acceptance; A reviews scope and consistency; C implements after the Human Design Gate; D performs independent visual, keyboard, zoom, responsive, and contrast verification; E audits accessibility, brand restraint, and evidence. F is not activated; A may seek owner approval for an accessibility specialist only if measurement or remediation proves beyond the normal test scope.

**Risks:** Palette choices can reduce contrast or over-brand working surfaces; broad CSS changes can regress unaffected pages; native controls vary by OS/browser; snapshots alone can miss computed-state defects.

**Required evidence:** Token mapping and rationale; before/after computed styles; contrast results for text and interactive states; keyboard/focus captures; dark/light desktop and W1 captures at representative widths and 200% zoom; focused tests plus build/typecheck and critical-flow smoke evidence.

**Expected documentation impact:** Visual/design-system record; accessibility and UI test notes; user-facing theme guidance if behavior changes; `CHANGE_CONTROL.md`; Project Map documentation only if architecture changes.

## TASK-PARTICIPANT-INSTANCES — One-to-six participant instance contract

**Objective:** Separate participant identity from canonical role and support a deterministic topology of one to six participant instances without implying that every project needs six or that self-review is independent audit.

**Explicit scope:** Participant-instance domain vocabulary and stable identity; one-to-six bounds; repeated role assignments; deterministic order; planned-topology validation; Mode 1 association; generated prompt, governance, provenance, and orchestration representation; migration of current one-to-four unique-role drafts/configurations; planned-agent availability mismatch behavior. Includes EXT-03.

**Non-goals:** Adding new canonical role semantics without evidence; provider discovery; funding; provider execution; forcing six participants; weakening the human decision required before topology reduction; modifying upstream AEKR without a separately evidenced contract gap.

**Dependencies:** None at the domain level. Theme tokens may be consumed by later UI, but this Task must not redesign the Mode 1 dialog.

**Acceptance criteria:**

- Valid projects can express one through six stable participant instances, including repeated canonical roles, in deterministic order.
- Existing one-to-four unique-role definitions migrate without loss or silent reinterpretation, with explicit compatibility tests.
- Validation distinguishes participant identity, role assignment, and independent-audit requirements and rejects ambiguous/duplicate identities.
- Generated prompt, governance, provenance, and Mode 1 configuration preserve participant order and identity honestly.
- Bootstrap/runtime mismatch still warns and requires a user decision before reducing topology; the product never labels self-review as independent audit.
- Accreatio’s consumed AEKR contract is proven sufficient, or the exact unavoidable upstream contract change is isolated and escalated before implementation claims completion.

**Relevant files/subsystems:** `shared/domain.ts`; `src/types.ts`; `src/core.ts`; draft initialization/restoration in `src/App.tsx` and `src/draftStore.ts`; prompt/governance/signature/YAML generation; `tests/core.test.ts`; `tests/draftStore.test.ts`; `tests/orchestration.test.ts`; relevant FAQ, architecture, and migration records.

**Assigned participants:** B designs domain/migration and identifies any exact AEKR boundary; A reviews topology integrity and escalates upstream scope if necessary; C implements approved accreatio changes; D tests legacy migration, one/six/repeated-role cases, serialization, and mismatch gates; E independently audits identity, migration, and review separation. F is not activated; a migration-compatibility specialist requires owner approval if evidence warrants it.

**Risks:** The current YAML is keyed by role and may not represent repeated roles; draft migration can corrupt identity/order; role terminology can leak into participant identity; six participants can amplify later UX density; upstream assumptions cannot be verified from this repository alone.

**Required evidence:** Current-to-new migration fixtures; validation boundary tests; generated prompt/governance/provenance/YAML fixtures for one, four legacy, and six participants with repeated roles; deterministic repeat-generation comparison; explicit AEKR compatibility finding; mismatch/independent-audit test evidence.

**Expected documentation impact:** Domain/schema and migration documentation; FAQ participant limits; governance/AEKR contract notes; `DECISIONS.md` if a durable model decision is approved; `CHANGE_CONTROL.md`; Project Map if boundaries change.

## TASK-PROVIDER-REGISTRY — Capability-driven provider registry

**Objective:** Replace the closed Claude Code/Codex switches with an honest descriptor and capability model while preserving only providers that accreatio can actually validate and serialize.

**Explicit scope:** Provider identifiers and descriptors; capabilities and host availability states; installed/authenticated/unsupported/unavailable distinctions; current Claude Code and Codex migration; any existing test-only mock kept test-only; desktop detection and W1 inability to inspect local CLIs; selection validation; adapter serialization boundaries; documented extension mechanism. Includes EXT-01.

**Non-goals:** Claiming support for unverified providers/models/auth modes; downloading providers; storing credentials; arbitrary commands or generic shell execution; implementing paid API authorization; changing AEKR merely to advertise speculative adapters.

**Dependencies:** `TASK-PARTICIPANT-INSTANCES`, because assignments attach to participant instances rather than unique roles.

**Acceptance criteria:**

- Registry descriptors, validation, availability reporting, UI consumption, and serialization share one provider identity/capability source rather than parallel closed switches.
- Existing eligible Claude Code and Codex subscription-CLI paths retain behavior through explicit migration tests.
- W1 and desktop distinguish available, unavailable, disabled, and unsupported states and prevent unsupported execution without presenting planned support as usable.
- Adding a provider requires an explicit descriptor plus evidenced detection/auth/serialization capability, not scattered union/switch edits.
- No provider-supplied or user-authored text becomes a shell command, and no credentials are stored by accreatio.
- Generated adapter configuration contains only fields supported by the consumed AEKR contract.

**Relevant files/subsystems:** `shared/domain.ts`; `src/types.ts`; provider UI/state in `src/App.tsx`; `electron/main.ts` detection; `electron/preload.ts`; `src/bridge/electron.ts`; `src/bridge/web.ts`; YAML generation; provider/core/orchestration/bridge tests; security and provider documentation.

**Assigned participants:** B designs registry/capability boundaries; A reviews honesty and scope; C implements approved descriptors and migrations; D tests status matrices, host differences, legacy behavior, and serialization; E audits capability claims and command/auth security. F is not activated; a provider-adapter security specialist requires owner approval if a concrete risk emerges.

**Risks:** Descriptor extensibility can masquerade as executable support; auth output and CLI behavior may change; W1 cannot detect local installations; registry abstraction can over-generalize two proven providers; adapter capability may diverge from upstream AEKR.

**Required evidence:** Registry and migration unit tests; provider status matrix for desktop/W1; installed/authenticated/unavailable/unsupported cases; command-construction security review; generated adapter fixtures; negative evidence that unregistered or incapable providers cannot be selected/executed.

**Expected documentation impact:** Provider extension contract; supported-provider/auth matrix; security documentation; FAQ/operator guidance; `CHANGE_CONTROL.md`; Project Map if a registry module is introduced.

## TASK-FUNDING-BUDGET — Explicit zero-cost and paid-API funding policy

**Objective:** Make execution funding explicit, keep `subscription_cli` as the zero-direct-cost default, and permit `api` only as disabled-by-default opt-in where a hard owner-defined ceiling can actually be enforced.

**Explicit scope:** Funding-mode domain contract; currency and maximum-cost semantics; hard-stop acknowledgment; relationship to maximum provider invocations; provider/model-profile capability requirements; removal or reconciliation of the implicit fixed Claude USD allowance and commented ceiling; validation, migration, serialization, and honest unavailable/disabled states. Includes EXT-02.

**Non-goals:** Enabling paid usage by default; storing API keys/secrets; automatic fallback from subscription to API; cost estimation represented as exact enforcement; speculative provider/model support; purchasing or invoking services during tests; weakening the zero-cost default.

**Dependencies:** `TASK-PROVIDER-REGISTRY` and `TASK-PARTICIPANT-INSTANCES`, because funding eligibility/enforcement is provider-capability-aware and may apply across participant assignments.

**Acceptance criteria:**

- Legacy/current configurations migrate to `subscription_cli`, zero mandatory direct cost, and no paid fallback.
- Funding mode, currency, maximum allowed cost, hard-stop semantics, and provider-invocation ceiling have unambiguous validation and serialization tests.
- `api` cannot be enabled or represented as executable unless the selected provider/profile has evidenced hard-ceiling enforcement compatible with the consumed AEKR contract; otherwise it is honestly unavailable and blocks save/execution.
- Paid mode requires explicit informed acknowledgment and a positive owner-defined ceiling, and never stores credentials.
- The existing fixed Claude `max_budget_usd` and commented cumulative ceiling are reconciled so generated configuration does not imply unauthorized spend or enforcement parity.
- Tests incur no service cost and use pure fixtures/mocks only.

**Relevant files/subsystems:** Funding/provider/orchestration types and generation in `shared/domain.ts`; `src/types.ts`; provider eligibility in `electron/main.ts`; Mode 1 state in `src/App.tsx`; bridge contracts if capability status expands; validation/YAML/draft tests; AEKR compatibility notes; FAQ/security/cost documentation.

**Assigned participants:** B designs policy and enforcement-capability contract; A confirms owner authorization boundaries and escalates any incompatible AEKR requirement; C implements only the approved, enforceable surface; D verifies default-zero, acknowledgment, ceiling, unavailable, migration, and serialization cases without live spend; E audits cost safety and truthfulness. F is not activated; owner approval is required before any provider-security specialist is used.

**Risks:** Accreatio may be unable to guarantee an upstream monetary hard stop; price-based estimates can drift; per-call and cumulative budgets can be conflated; a UI toggle can imply paid capability that does not exist; tests could accidentally invoke a paid provider if isolation fails.

**Required evidence:** Funding migration/validation fixtures; zero-cost default and no-fallback tests; hard-stop capability matrix; generated YAML fixtures; negative tests for missing acknowledgment, zero/invalid ceilings, unsupported provider/profile, and absent enforcement; documented upstream compatibility conclusion; proof tests use no network/provider invocation.

**Expected documentation impact:** Funding/security/provider policy; FAQ and operator guidance; schema/migration record; `DECISIONS.md` for approved funding semantics; `RISKS.md`; `CHANGE_CONTROL.md`; AEKR contract note if escalation is required.

## TASK-UX-MODE1 — Accessible Mode 1 configuration workflow

**Objective:** Replace the compressed inline Mode 1 editor with a comprehensible, responsive, keyboard-complete configuration workflow that exposes all actual execution limits and consumes the approved participant, provider, and funding contracts.

**Explicit scope:** `Prepare Mode 1 configuration` entry point; centered viewport-safe dialog; one intentional scroll container; participant/task/provider/execution-limit/funding groups; bounded auto-growing task controls; editable intermediate numeric states; accurate labels and help; save/cancel/reopen/persistence; compact saved summary; focus trap/restoration, Escape, background inertness; narrow-screen behavior; desktop/W1 parity and honest host limitations. Includes UX-01, UX-02, and WEB-02.

**Non-goals:** Redefining participant, provider, or funding domain contracts; provider execution; general application form redesign; draggable windows; Mode 2; treating unobserved native rendering differences as already verified.

**Dependencies:** `TASK-DESIGN-THEME`, `TASK-PARTICIPANT-INSTANCES`, `TASK-PROVIDER-REGISTRY`, and `TASK-FUNDING-BUDGET`.

**Acceptance criteria:**

- The dialog meets the master target: approximately `min(920px, calc(100vw - 32px))` on desktop/tablet, full viewport treatment on narrow mobile, one scroll container, accessible footer, no background interaction, and no body horizontal overflow.
- One through six participants remain readable; long tasks do not have permanent internal scrollbars and auto-grow to a documented bound.
- Maximum session duration, iterations per entity, provider invocations, and consecutive failures are all visible, accurately named, explained, persisted, and serialized; technical retries appear only if truly configurable.
- Numeric fields permit empty/intermediate keyboard editing and validate on blur/save without destructive resets or loss of other input.
- Save validates, confirms, persists, closes, and produces a compact summary; Cancel/Escape preserve the prior saved configuration; reopening restores it.
- Keyboard-only focus order, initial focus, trap, visible focus, Escape, and trigger-focus restoration work in both hosts.
- Live checks pass at desktop 1080/1250/1480 px, W1 approximately 1024/1280/1440 px, breakpoint boundaries, common zoom levels through 200%, and narrow mobile.

**Relevant files/subsystems:** Mode 1 state and markup in `src/App.tsx`; prospective shared dialog/control components; `src/styles.css`; `src/extras.css`; `src/responsive.css`; `shared/domain.ts` validation/serialization consumers; `src/draftStore.ts`; focused component/accessibility tests; `tests/core.test.ts`; `tests/draftStore.test.ts`; `tests/orchestration.test.ts`.

**Assigned participants:** B designs the complete UX contract after upstream Task handoffs; A checks contract consistency and UX scope; C implements; D performs desktop/W1 visual, keyboard, responsive, numeric-edit, persistence, and serialization testing; E audits accessibility and consistency. F remains disabled unless A obtains owner approval for a demonstrated accessibility-specialist need.

**Risks:** Six-participant density can reintroduce nested scrolling; local draft state can diverge from saved state; dialog accessibility can regress through custom implementation; number inputs vary by Chromium/platform; upstream model changes can leak implementation terms into UI.

**Required evidence:** Component/focus tests; limit validation and serialization fixtures; save/cancel/reopen persistence tests; desktop/W1 viewport and zoom captures; keyboard-only recording/checklist; overflow measurements; screen-reader semantics check; regression evidence for Mode 0 and locale/theme switching.

**Expected documentation impact:** Mode 1 user/operator guidance; execution-limit glossary; accessibility/UX design record; screenshots only if maintained by current docs; `CHANGE_CONTROL.md`; Project Map if components are split.

## TASK-WEB-ATTACHMENTS — Local-only W1 discovery attachments

**Objective:** Allow W1 users to select validated local discovery files and include their bytes in the exported ZIP without upload or misleading persistence claims.

**Explicit scope:** Browser file selection; web-specific binary attachment representation and lifecycle; shared extension/count/per-file/total-size validation; visible file status/removal/error recovery; deterministic collision-safe ZIP inclusion; provenance/source-file consistency; draft/reload behavior stated and implemented honestly; privacy messaging reconciliation. Includes WEB-01 and the reproduction report’s category-B privacy inconsistency.

**Non-goals:** Upload, cloud storage/sync, server-side validation, W2/local companion, filesystem paths in the browser, parsing/executing attachment contents, public deployment, or silently promising persistence that the chosen browser storage model does not provide.

**Dependencies:** `TASK-DESIGN-THEME` for shared control states. It is otherwise independent of Mode 1 contract Tasks.

**Acceptance criteria:**

- W1 selects allowed local files, shows name/size/status, supports removal, and preserves form input when validation fails.
- The existing limits (20 files, 20 MB each, 100 MB total, allowlisted extensions) are enforced before export and clearly explained.
- A non-dry repository/both export includes byte-identical attachments at deterministic, collision-safe ZIP paths and records their final names in provenance and generated text.
- Attachments remain browser-local and are never uploaded, parsed, executed, logged by content, or sent to a remote dependency.
- Dry-run clearly states that no ZIP was downloaded; reload/draft behavior matches implementation and documentation without stale Blob references or false IndexedDB claims.
- Desktop attachment behavior and text-only ZIP generation remain regression-safe.

**Relevant files/subsystems:** `shared/domain.ts` attachment metadata/validation; `src/types.ts` `WebAttachment`; attachment UI/state in `src/App.tsx`; `src/bridge/web.ts`; `src/webExport.ts`; `src/draftStore.ts`; `tests/core.test.ts`; `tests/bridge.test.ts`; `tests/draftStore.test.ts`; `tests/webExport.test.ts`; `docs/SOP_WEB.md`; `docs/PRIVACY_POLICY.md`; `docs/WEB_ARCHITECTURE.md`; security/risk records.

**Assigned participants:** B designs lifecycle/privacy/ZIP contracts; A reviews boundary compliance; C implements; D inspects actual ZIP bytes, limits, collisions, reload behavior, privacy/network behavior, and desktop regression; E audits local-only and documentation claims. F is not activated.

**Risks:** Blob memory pressure; duplicate filenames/path traversal; archive inflation; draft serialization cannot safely retain `Blob` objects; metadata can diverge from final archive names; privacy text is currently internally inconsistent.

**Required evidence:** Pure validation tests; ZIP inspection with binary fixtures and duplicate names; size/count/extension/path negative tests; dry-run/non-dry browser evidence; reload/draft lifecycle test; network observation showing no content egress; desktop attachment regression; synchronized privacy/SOP text.

**Expected documentation impact:** `docs/SOP_WEB.md`; `docs/PRIVACY_POLICY.md`; `docs/WEB_ARCHITECTURE.md`; security and risk documentation; FAQ capability matrix; `CHANGE_CONTROL.md`.

## TASK-EXEC-IDEMPOTENCY — Duplicate-safe logical operations

**Objective:** Prevent rapid, repeated, and concurrent review/export/execute activations from producing duplicate artifacts or history while preserving an explicit legitimate rerun path.

**Explicit scope:** One logical operation identity across UI, bridge, Electron IPC, and W1 download; in-flight/reentrancy protection; confirmation-control disabled/busy behavior; duplicate detection semantics; explicit rerun after completion; desktop versioned-write/history behavior under concurrency; W1 duplicate-download behavior; failure recovery. Includes EXEC-02.

**Non-goals:** Removing deterministic versioned copies for intentional later runs; generic distributed idempotency; automatic retries; automatic commit/push; redesigning final artifact messages beyond the state/result contract required by the next Task.

**Dependencies:** None for core protection; `TASK-DESIGN-THEME` supplies busy/disabled/focus styling. It precedes artifact feedback so a result corresponds to one operation.

**Acceptance criteria:**

- Rapid double-click, repeated confirmation, and concurrent direct bridge/IPC invocation for the same logical request cause at most one mutation/download/history entry.
- The guard is synchronous at the initiating UI boundary and independently enforced at the privileged/host operation boundary; React unmount timing is not the protection.
- Busy/disabled state is visible, keyboard-safe, and recoverable after success or failure.
- A completed operation can be intentionally rerun through an explicit user action and then uses normal deterministic versioning rather than being permanently suppressed.
- Distinct projects/requests are not incorrectly coalesced, and no user-authored text is executed by a shell to implement fingerprinting or locking.

**Relevant files/subsystems:** Execution/confirmation state in `src/App.tsx`; `src/types.ts` bridge/result contracts; `src/bridge/web.ts`; `src/bridge/electron.ts`; `electron/preload.ts`; `electron/main.ts`; `electron/files.ts`; history subsystem; bridge/files/execution tests and Electron smoke-test harness.

**Assigned participants:** B designs operation semantics and boundary ownership; A reviews failure/rerun behavior; C implements; D stress-tests rapid UI activation, repeated confirmation, concurrent IPC, downloads, history, and intentional reruns; E audits race resistance and evidence. F is not activated.

**Risks:** UI-only locks remain race-prone; stale locks can block recovery; fingerprints can collapse legitimate operations or expose sensitive input in logs; process restart semantics can be over-scoped; Git/GitHub side effects increase partial-operation risk.

**Required evidence:** Deterministic concurrency unit/integration tests; rapid keyboard/mouse activation evidence; direct concurrent IPC/bridge test; one-download/one-history/one-artifact assertions; failure unlock and explicit-rerun tests; regression evidence for versioned writes and dry-run.

**Expected documentation impact:** Execution semantics and troubleshooting guidance; security/concurrency note; `CHANGE_CONTROL.md`; Project Map/bridge contract docs if operation identity crosses boundaries.

## TASK-EXEC-EVIDENCE — Artifact verification and outcome feedback

**Objective:** Make dry-run, successful output, failure, and partial completion unmistakable and back every success claim with an actual desktop destination or inspected W1 ZIP.

**Explicit scope:** Pre-execution distinction between review/dry-run and mutation/export; result contract and status language; desktop tracking, repository, and both outcomes; W1 repository/both ZIP outcome and browser-download limitations; completed versus failed step reporting; destination/filename evidence; recovery guidance; actual artifact verification. Includes EXEC-01.

**Non-goals:** Treating the owner report as proof that write paths are absent; changing the default dry-run-on safety policy; browser filesystem access; W1 tracking implementation; idempotency mechanics already owned by `TASK-EXEC-IDEMPOTENCY`; auto-opening or uploading output.

**Dependencies:** `TASK-EXEC-IDEMPOTENCY`, so each displayed result maps to one logical operation. `TASK-WEB-ATTACHMENTS` should complete first so final ZIP evidence covers the approved W1 artifact set.

**Acceptance criteria:**

- Before confirmation, the UI plainly states whether the action is dry-run and exactly whether it will create desktop tracking files, a repository, both, or a W1 ZIP.
- Dry-run success never implies that a file or download was created and provides a clear next action for a real run.
- Successful desktop tracking, repository, and both runs report the actual destination(s) and are verified by inspecting expected versioned contents.
- Successful W1 repository/both export reports the expected ZIP filename/content set and distinguishes app generation from browser download blocking/cancellation; no success claim is based only on calling an anchor click.
- Failures and partial completion identify what completed, what did not, and safe recovery without losing the form definition.
- W1 tracking-only remains honestly unsupported unless separately authorized; default dry-run remains enabled.

**Relevant files/subsystems:** Review/result UI in `src/App.tsx`; `src/types.ts` `ExecutionResult`; `src/core.ts` action plan; `electron/main.ts`; `electron/files.ts`; history; `src/bridge/web.ts`; `src/webExport.ts`; bridge/core/files/webExport tests; Electron execution smoke harness; desktop/web SOP and troubleshooting docs.

**Assigned participants:** B designs outcome and evidence contract; A reviews truthfulness and boundary compliance; C implements; D independently executes desktop tracking/repository/both and W1 repository/both, opens outputs, tests blocked download/failure/partial states, and records evidence; E audits claims against artifacts. F is not activated.

**Risks:** Browser APIs may not confirm final disk persistence; completed-step reporting can overstate atomicity; destination paths may expose local information in screenshots/logs; Git/GitHub partial failures complicate recovery; test environments may not match the owner’s browser policy.

**Required evidence:** Actual directory trees and content hashes/fixtures for each desktop action; inspected W1 ZIP manifest/content; dry-run no-artifact proof; browser blocked-download behavior; partial-failure fixture; result-contract tests; preserved 41-test/typecheck baseline plus proportionate new tests and required packaged functional evidence at the later Test Engineer stage.

**Expected documentation impact:** `docs/SOP_DESKTOP.md`; `docs/SOP_WEB.md`; troubleshooting/FAQ output semantics; test evidence record; `CHANGE_CONTROL.md`; privacy wording if result logs expose paths.

## TASK-BRAND-ABOUT — Product-first About and legal clarity

**Objective:** Ensure the About experience closes on accreatio’s product identity and principles while retaining legally accurate authorship/licensing language.

**Explicit scope:** About hierarchy, product naming, version/source-of-truth display, product principles, copyright/licensor wording, localization, and verification in desktop/W1 and both themes. Includes UX-04.

**Non-goals:** Changing copyright ownership or license terms without owner/legal direction; hiding legitimate authorship; broad navigation redesign; packaging metadata changes unless factual inconsistency is proven; using personal authorship as the primary product brand.

**Dependencies:** `TASK-DESIGN-THEME` for final presentation. No architectural dependency on the other Tasks, so it remains last as a small, isolated cleanup after functional work.

**Acceptance criteria:**

- `accreatio` remains the primary identity and the page’s closing hierarchy reinforces the product rather than ending on personal authorship alone.
- Authorship, copyright holder, licensor, license, and product identity are not conflated; any ownership wording change has explicit owner approval.
- Displayed version and principles are accurate from maintained sources and consistent across desktop/W1 and locales.
- About remains keyboard-readable and visually coherent in both themes without remote assets.

**Relevant files/subsystems:** `About` and localization text in `src/App.tsx`; `package.json` version/author as reference; About/theme styles; `DECISIONS.md`; license/terms/FAQ documentation; focused render/content tests if introduced.

**Assigned participants:** B designs content hierarchy and flags the ownership decision; A obtains owner clarification where legal wording would change; C implements approved copy/presentation; D verifies content, localization, keyboard order, themes, hosts, and version; E audits legal/product claim consistency. F is not activated.

**Risks:** Product-first language can accidentally alter legal meaning; package author and copyright holder may legitimately remain personal; hard-coded version text can drift; localization can change emphasis.

**Required evidence:** Approved copy decision; desktop/W1 dark/light captures; locale comparison; version-source test/check; audit against package/license/terms records; keyboard reading-order check.

**Expected documentation impact:** About/legal copy sources; FAQ or terms only if approved wording requires synchronization; `DECISIONS.md` if ownership/brand language is resolved; `CHANGE_CONTROL.md`.

## Deviations from the proposed sequence

- **Reordered proposed Task 3 ahead of Mode 1 UX:** participant instances are the identity and ordering contract the dialog must edit; designing the dialog against the current unique-role model would create rework and ambiguous migration.
- **Reordered proposed Task 4 ahead of Mode 1 UX:** the current hard-coded provider selector is one root cause of EXT-01; the dialog must consume an approved registry/status vocabulary rather than embed another closed switch.
- **Reordered proposed Task 5 ahead of Mode 1 UX:** funding is a required Mode 1 group and depends on provider capabilities; its zero-cost, unavailable, and hard-stop states must exist before the dialog contract is finalized.
- **Moved proposed Task 2 after Tasks 3–5 and renamed it accessible Mode 1 workflow:** this keeps UX-01, UX-02, and WEB-02 together because they share one markup/state/validation workflow across both hosts, while preventing that Task from redefining its architectural inputs.
- **Kept W1 attachments separate but moved it before final artifact evidence:** WEB-01 has a distinct binary/privacy lifecycle, and the final W1 ZIP verification should cover the approved attachment set.
- **Placed idempotency before artifact feedback:** EXEC-02 must establish one logical operation before EXEC-01 feedback can truthfully associate a success, failure, history entry, or artifact with that operation.
- **Retained About as a separate final Task:** UX-04 is small but not inseparable from theme work; it contains an owner/legal wording decision and should not broaden the foundational CSS Task.
- **No merge, split, add, or drop:** all nine proposed objectives are coherent rollback/review boundaries. The two category-D documentation findings from the reproduction report remain separate future backlog work, not hidden additions to this increment.

## Issue-to-Task map

Each confirmed or partially confirmed owner issue has exactly one owning Task. Later Tasks may depend on that Task, but do not share issue ownership.

| Issue ID | Owning Task ID | Rationale |
|---|---|---|
| UX-01 | `TASK-UX-MODE1` | The structural desktop defect is the shared inline Mode 1 layout/task-editor workflow; exact pixels remain a required live acceptance check. |
| UX-02 | `TASK-UX-MODE1` | The actual defects are intermediate number editing, inaccurate consecutive-failure labeling, and two hidden schema limits, all within the Mode 1 execution-limit UX. |
| UX-03 | `TASK-DESIGN-THEME` | Dark literals and absent shared interaction states are semantic theme/control-system defects. |
| UX-04 | `TASK-BRAND-ABOUT` | The heading is already product-first, but the closing identity/legal hierarchy needs bounded About work and owner-approved wording. |
| WEB-01 | `TASK-WEB-ATTACHMENTS` | W1 lacks selection, browser binary state, ZIP inclusion, and accurate lifecycle/privacy behavior. |
| WEB-02 | `TASK-UX-MODE1` | W1 shares the same Mode 1 markup/CSS cause at relevant widths, with breakpoint-specific live verification required. |
| EXEC-01 | `TASK-EXEC-EVIDENCE` | Write/export paths exist; the remaining issue is dry-run/result clarity plus independent verification of real desktop outputs and W1 ZIPs. |
| EXEC-02 | `TASK-EXEC-IDEMPOTENCY` | There is no synchronous UI guard or host-level logical-operation idempotency across desktop and W1. |
| EXT-01 | `TASK-PROVIDER-REGISTRY` | Provider types, detection, UI, availability, and YAML emission are parallel closed switches. |
| EXT-02 | `TASK-FUNDING-BUDGET` | Current subscription-only eligibility and fixed/commented USD fields do not form explicit, authorized, enforceable funding semantics. |
| EXT-03 | `TASK-PARTICIPANT-INSTANCES` | Participant identity is collapsed into four unique canonical roles throughout validation and generation. |

### Explicitly triaged reproduction findings

- The contradictory W1 attachment/IndexedDB privacy statement is classification **B** and is included in `TASK-WEB-ATTACHMENTS` documentation acceptance.
- Stale W2 direction in `DECISIONS.md`/`docs/FAQ.md` is classification **D**, a separate governance-documentation backlog item. It is not authority to implement W2 and is not added to this corrective increment.
- Stale desktop/AEKR operator guidance in `docs/SOP_DESKTOP.md`/`docs/FAQ.md` is classification **D**, a separate documentation backlog item. Only statements directly changed by an approved Task are synchronized here; broad historical cleanup is not added.
