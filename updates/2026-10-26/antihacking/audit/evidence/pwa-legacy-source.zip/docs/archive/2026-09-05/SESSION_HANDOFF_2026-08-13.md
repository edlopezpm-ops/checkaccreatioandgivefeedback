# Session handoff — 2026-08-13

**Branch:** `chore/frontend-reconciliation-and-map-rename`, four commits ahead of
`main` at `076e4ab`.
**Gate state:** `npm run verify` exits 0 — 215/215 tests, Lighthouse
90/100/100/66, accessibility 100.
**Deployed state:** unchanged. Nothing was deployed, no Cloudflare or Access
configuration was touched, no protected value was read or written.

## Where the work landed

| Commit | What |
| --- | --- |
| `0d80371` | Typography determined with host-resident stacks; corrections from the first Codex audit |
| `c9eb796` | Export rewritten: 6 files → 16, zero executables, AEKR governance vendored |
| `3f24d23` | Progress bar; copy budget put under a guard that actually measures |
| `9b4ad18` | Dry-run moved to Review; archive-never-delete policy recorded |

Design of record: `docs/design-v10/DESIGN.md`. Audit trail:
`docs/archive/2026-09-05/CODEX_AUDIT_2026-08-13.md`, `docs/archive/2026-09-05/FRONTEND_RECONCILIATION.md`.

## Owner verdict at close

**Export: accepted.** **UI/UX: rejected — still bad.** The HOE will produce
drawings of the intended flow and hand them over; the screen-level redesign
waits for those. Nothing in this session should be read as UI/UX being done.

## Open, in priority order

1. **UI/UX redesign, blocked on the HOE's drawings.** The intent is a
   TurboTax-style flow: one decision per screen, modular advance, progress
   bar, free movement backwards. E1.3 in this session was surgical — a control
   moved, a bar added, sentences cut — not the structural redesign. When the
   drawings arrive, that is a real v2 and the archive-never-delete policy
   applies: the current flow moves to a buildable legacy path and stays
   compiling until the new one passes hosted acceptance.
2. **`App.tsx` has no copy budget.** It carries roughly 4151 words of authored
   strings — the largest concentration of text in the product, covering the
   shell, About, onboarding, and the Orchestration Center.
   `tests/copyBudget.test.ts` covers only the four creation screens. The guard
   is real but partial, and this is where the remaining bloat is.
3. **R0.1 — activate the Blog publisher.** `docs/HOE_R0_CHECKLIST.md`, ~15
   minutes, HOE only. Both allowlists are deliberately empty and fail closed,
   which is why the Blog does not publish. This is the single change that
   fixes it.
4. **R0.2 — authenticated portal acceptance.** Same checklist, ~30 minutes,
   after R0.1.
5. **Deployment.** Deliberately deferred: the HOE will deploy once localhost is
   right, not before. Needs `npx wrangler` and the HOE's Cloudflare login.
6. **Independent audit of this candidate did not complete.** A Codex run over
   `0d80371..9b4ad18` was launched and had produced no output when the session
   closed. The prompt is reproducible; rerun it before deployment. Do not
   record this work as independently audited until it returns a verdict — the
   previous Codex audit returned FAIL and was correct on all five findings.

## Constraints a future session must not "fix"

Each of these looks like a defect and is a decision. All were nearly broken
during this session.

- **The export ships no executable file.** Not `.ps1`, not `.py`. A
  browser-downloaded ZIP carries Mark-of-the-Web and would be blocked;
  `orchestrator/BUILD_ORCHESTRATOR.md` describes the orchestrator for the
  user's own AI to build locally. Enforced by `tests/exportManifest.test.ts`.
- **`.ai-engineering/orchestration.yaml` is a path contract.**
  `electron/orchestration.ts` refuses any AEKR config outside that directory.
  Moving it breaks the desktop Mode 1 handoff silently.
- **That config is omitted when orchestration is disabled.** Shipping config
  for a switched-off capability is noise; the schema lives in the spec instead.
- **`DECISIONS.md:29`** fixes display serif, sans UI, mono code, and *"do not
  add or download a font."*
- **Empty publisher allowlists are the design**, not a bug.
- **Zero direct service cost** (`AGENTS.md`) until the HOE lifts it.

## Known environment traps

Both blocked all local verification and will hit any new contributor on a fresh
checkout of this workspace:

- `node_modules` held a Linux esbuild binary. Fix: `npm ci` on Windows.
- Zero-byte *files* named `dist` and `dist-electron` occupied the paths the
  build needs as directories, failing `vite-plugin-pwa` with `EACCES`. Removed.
  Note `core.*` crash artifacts are **not** covered by `.gitignore`.

## Unresolved control gap

GitHub's Free plan cannot enforce branch protection on a private repository —
the API answers `403 Upgrade to GitHub Pro`. CI reports on `main` but cannot
block a direct push to it, and `jolopezm` holds write access. Merges should go
through a pull request by convention, because nothing enforces it technically.

## Local testing

`npm run dev:web` serves the web edition at `http://localhost:5173/`. The Blog
does not work locally by design: it needs Cloudflare Access, Pages Functions,
and D1. Everything else, including the real ZIP export, runs locally.
