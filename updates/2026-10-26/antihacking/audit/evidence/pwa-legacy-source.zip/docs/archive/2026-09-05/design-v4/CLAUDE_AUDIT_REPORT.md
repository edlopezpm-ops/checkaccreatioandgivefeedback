# Independent Claude Audit Report — design v4

- Auditor: Claude Code 2.1.222, fresh read-only CLI session
- Audit date: 2026-08-05
- Baseline: `f37f91f`
- Controlling commit: `7da270739c0748dfbff7a795984a43fdb8248fe6`
- Verdict: **PASS WITH NON-BLOCKING IMPROVEMENTS**

Claude was restricted to read-only repository, Git, file-search, dependency-metadata, AEKR, and rendered-evidence access. It could not edit, write, commit, push, or browse. Codex did not author this verdict.

## Controlling-state verification

- `HEAD`, local `main`, and `origin/main` were identical at `7da270739c0748dfbff7a795984a43fdb8248fe6`.
- The only dirty item was unrelated untracked `core.798609`; Claude ignored it as directed.
- `f37f91f..HEAD` contained one commit, 37 files changed (`+1163/-295`), consistent with the declared implementation surface and governance material.
- Claude reported that its restricted audit context could not execute the installed dependency tree, so it did not independently rerun tests, build, npm audit, or Lighthouse. Quantitative results were checked for internal/code consistency but remain Codex-produced evidence. This is an audit-scope limitation, not a product defect or an independent reproduction claim.

## Code findings

### Low — exact dependency pins verified; install not independently reproduced

`package.json` pins `three@0.185.1` and `vanta@0.5.24` exactly. `package-lock.json` resolves those same versions with integrity hashes, and `THIRD_PARTY_NOTICES.md` classifies both as MIT. Claude could not independently confirm the installed tree or installed license files in its restricted session.

### Low — redundant PWA `includeAssets` removal lacked an explanatory note

`vite.config.mts` removed `includeAssets: ["icons/*.png"]`. The remaining `globPatterns: ["**/*.{js,css,html,png,webmanifest}"]` should include the generated `dist/icons/*.png`, so Claude assessed this as likely redundant cleanup rather than a regression. It recommended explicitly confirming that all three generated PNGs remain in the built precache manifest.

### Low — hidden-document lifecycle is code-reviewed, not browser-smoke tested

`Atmosphere.tsx` correctly connects `visibilitychange` to effect destruction/recreation through paused state, and cleanup remains cancellation-guarded. The browser smoke does not simulate `document.hidden`, so this behavior has code-review evidence but no automated browser evidence. The final report did not falsely list hidden-tab behavior among its smoke assertions.

### Verified — one effect/canvas and cleanup

Claude traced StrictMode double invocation, async initialization cancellation, cleanup, theme/view `setOptions`, and persistent `AppFrame` placement. It found no effect/canvas/listener/context leak across StrictMode, ordinary navigation, or theme changes. The browser smoke independently asserts one preserved canvas across theme and stage navigation.

### Verified — accessibility, fallback, isolation, and CSP

Reduced motion, save-data, slow-update, hidden state, missing/failed WebGL, and context loss route to the static fallback. Vanta mouse/touch/gyro controls are disabled; accreatio-owned pointer movement is capped at 16 px. The atmosphere is decorative and cannot intercept input. CSP remains self-only, and the renderer has no project-data or privileged-process path.

### Verified — current boxless identity and generated assets

Both current SVG marks contain no raster image or rectangle. The orbital mark geometry and four-loop AEKR mark match the design. The render script derives the 192 px, 512 px, and social PNGs from the current SVG; Windows packaging references the generated 512 px asset.

### Verified — right-to-left density direction

Claude verified the CSS mask math: its opaque end is at the right edge and fades to transparent at the left. The static screenshots alone cannot prove non-deterministic fog density, but the implementation direction is unambiguous.

No Critical or High code finding was identified.

## Documentation-only findings

### Low — quantitative evidence was not independently executable in Claude's session

The reported 176 tests, bundle sizes, Lighthouse 92/100/100/100, zero-vulnerability npm audit, and 17-entry precache were internally consistent with code and configuration but were not independently rerun by Claude. They must remain labeled as Codex-produced validation evidence.

### Low — Windows packaging remains an open release gate

The final report, change control, and risk register consistently disclose the dev-container symlink/ASAR failure and do not claim a successful new portable artifact. A supported Windows or non-symlink packaging and process smoke remains required before distribution.

### Verified — governance chain is honest

DEC-014, design, and final-report material distinguish Codex implementation/self-validation from this independent Claude audit. The AEKR signature is described as an acknowledgment, not certification, and no private handbook content is copied.

### Verified — current documentation is mutually consistent

Claude reviewed README, desktop/web SOPs, security, troubleshooting, test-note resolution, web architecture/readiness, risks, change control, decisions, and design-v4 material. It found no stale v3 CSS-only or cream-palette claim in the current v4 state and no contradiction in legal/security/runtime-egress language.

## Visual evidence review

Claude reviewed all six dark, light, mobile, ultrawide, and logo PNGs in `/tmp/accreatio-visual-v4/`. It found readable opaque instruments over a soft nebula, a legible light-mode logo without a rectangular boundary, preserved mobile gutters, an appropriately subordinate mobile AEKR icon, and no ultrawide overflow. It found no intrusive atmosphere or raster logo box.

## Codex documentation reconciliation

No code was changed in response to this report, as required by the owner.

- The built `dist/sw.js` was inspected after the audit and explicitly contains `icons/accreatio-192.png`, `icons/accreatio-512.png`, and `icons/accreatio-social.png`; the removed `includeAssets` entry was redundant. This confirmation is Codex evidence, not a retroactive independent Claude run.
- Codex restored the exact lockfile with `npm ci` (zero vulnerabilities) and reran `npm run verify`: 176/176 tests, Project Map, type, format, build, Electron/map/web smokes, and Lighthouse all passed. Lighthouse was 91/100/100/100 on this post-audit sample versus 92/100/100/100 initially. This remains Codex evidence, not independent reproduction by Claude.
- The absence of an automated hidden-tab lifecycle scenario is recorded as an open Low/Medium coverage risk. The implementation remains supported by code inspection and manual fallback behavior, without overstating browser-smoke coverage.
- Quantitative validation remains attributed to Codex. Claude's independent contribution is the repository/AEKR/code/documentation/visual review and verdict.
- The Windows packaging gate remains open and unchanged.

## Verdict

**PASS WITH NON-BLOCKING IMPROVEMENTS**
