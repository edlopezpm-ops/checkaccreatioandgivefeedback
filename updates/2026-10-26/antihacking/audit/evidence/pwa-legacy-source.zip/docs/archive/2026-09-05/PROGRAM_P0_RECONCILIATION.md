# Program P0 — Reconciliation and Roadmap

> **Historical planning baseline.** Later decisions and implementation supersede its web-status assertions: DEC-016 adds a bounded web-only Pages Functions/D1 editorial channel, and DEC-017 hard-separates that channel from Electron. This record does not authorize tenant accounts, hosted project data, billing, or W3.

**Status:** Planning record. Nothing in this document is implemented by virtue of being written here — see Change Control for what has actually shipped.

**Scope:** Reconcile `accreatio`'s current baseline against the AI Engineering Knowledge Repo's (AEKR) orchestrator runtime, and lay out the bounded increment sequence (P1–P8) for adding optional AEKR-governed automation to accreatio, per owner authorization 2026-08-03.

## 1. Current product baseline (accreatio)

- v0.5.0, branch `main`, `88185cf`, working tree clean at time of writing.
- Architecture unchanged from `AGENTS.md`: `src/core.ts` (pure domain), `src/App.tsx` (React UI), `electron/main.ts` (privileged fs/Git/GitHub/settings), `electron/preload.ts` (8-method `contextBridge`).
- `src/App.tsx` calls `window.accreatio?.*` directly at 8 call sites. **No `Bridge` interface, `electronBridge`, or `webBridge` exists in code today** — `docs/WEB_STRATEGY.md`'s "Phase W0 — started" label is aspirational, not actual. `docs/WEB_ARCHITECTURE.md` (2026-08-02) already specifies the target `Bridge` shape in detail; P1 implements that existing design rather than redesigning it.
- Baseline at the time of reconciliation: 14/14 tests and no automated coverage for `electron/main.ts`'s privileged `execute()` path. Current status: 0.6.0 adds an isolated real-Electron IPC smoke that executes the filesystem path and verifies generated artifacts; further extraction remains a prerequisite for W2, not for W1.
- Zero AI dependency, zero telemetry, zero cost — `AGENTS.md`'s mandatory constraint, unchanged and still binding on every phase below.

## 2. Current AEKR integration baseline

- AEKR found at sibling `AI Engineering Knowledge Repo` (GitHub slug `ai-engineering-toolkit`), branch `main`, `4ad03fd`, clean.
- **A real Mode 1 runtime already ships** at `toolkit/orchestrator/`: `runtime/cli.py` (entry point via `orchestrator.ps1`), `runtime/state.py`, `runtime/gates.py`, `runtime/budget.py`, `runtime/events.py`, `runtime/adapters/{base,mock,claude_code,codex}.py`. 176/176 tests passed locally this session (`python -m pytest -v` in `toolkit/orchestrator`).
- Mode 2 is confirmed boundary-only in the shipped code (`runtime/orchestrator_client.py`: `RuntimeClient.propose_action()`, read-only, no persistent runner) — matches this program's Section 3 restriction with no gap to close.
- Local tool check: Python 3.13.4, Node v24.18.0, and both `claude` and `codex` CLIs resolve on PATH (`%APPDATA%\npm\`). Authentication/health has not yet been exercised against a real invocation — that is the first thing P1's Mode 1 run must prove, not assume.
- `meta/ACCREATIO_RELATIONSHIP.md` is unambiguous: AEKR is upstream and independent; accreatio consumes/emulates, never governs back. No modification to AEKR is authorized absent a reproducible downstream defect — none found during this reconciliation.

## 3. Document-authority reconciliation

| Conflict found | Resolution |
|---|---|
| This program's example Mode 1 YAML (Section 7) uses fields (`roles.architect/implementer/auditor.write_access`, `auditor.enabled: risk_based`) that don't exist in AEKR's actual schema | AEKR's real schema wins (program Section 7 explicitly defers to "the actual validated AEKR schema"). Real shape: `session{owner,max_duration_seconds}`, one consolidated `budget{max_iterations_per_entity,max_provider_invocations,max_consecutive_failures,ceiling}`, and an ordered `role_sequence` of `{role,task,action_kind,adapter}`. No separate `limits` block exists. |
| This program's Section 4 lists `PROJECT_MAP.md`/`project-map.json` as accreatio files to read | Neither exists in accreatio today; both exist in AEKR. Resolution: create a minimal `PROJECT_MAP.md` for accreatio as part of this P0 increment (§6 below), scoped to accreatio's own boundary — not a copy of AEKR's. |
| `docs/WEB_STRATEGY.md` marks W0 "(started)"; `docs/WEB_ARCHITECTURE.md` marks it "In progress" | Both are stale relative to current code (§1). Corrected status: **W0 not started in code; fully designed in `docs/WEB_ARCHITECTURE.md`.** P1 implements that existing design. |
| AEKR's Mode 2 demo (`toolkit/orchestrator/demos/MODE2_REAL_RUN_RESULTS.md`) could be misread as proof of a working autonomous Mode 2 loop | AEKR's own README explicitly disclaims this ("historical provider-to-gate evidence... not proof of the current API or an end-to-end run"). accreatio must not represent Mode 2 as a complete capability anywhere in UI or docs, per program Section 3. |

No other material contradictions found between accreatio's product docs, AEKR's methodology docs, and current repository state.

## 4. Target product boundary (this program, non-SaaS)

- Mode 0 (manual, current baseline) remains the default and requires no runtime.
- Mode 1 (human-gated) becomes available by invoking AEKR's existing `runtime.cli` — accreatio does not reimplement gating, budget tracking, or adapters; it configures and displays them (Phase P5).
- Mode 2 stays a bounded, non-persistent library surface, never presented as autonomous.
- Web boundary follows `docs/WEB_ARCHITECTURE.md`'s W0→W3 phasing unchanged; W3/SaaS stays a sketch, not implementation, per DEC-007/`WEB_STRATEGY.md`.

## 5. Incremental roadmap

```
P0 (this doc)                     — DONE, doc-only
  ↓
P1 — W0 Bridge abstraction        — DONE, first real Mode 1 pilot (AEKR runtime invoked codex/claude_code)
  ↓
P2 — W1 export-first PWA          — DONE (P2.1-P2.4: drafts, ZIP export, offline shell, accessibility)
  ↓
P3 — Productized orchestration config UI   — DONE (2026-08-03): Mode 0/1 toggle, role→provider mapping,
  ↓                                            provider detection, session/budget limits
P4 — Versioned AEKR integration package     — DONE, bounded interpretation (2026-08-03): execute() generates a
  ↓                                            starting .ai-engineering/orchestration.yaml, real-schema-validated
  ↓                                            against AEKR's own load_config/validate_config. The fuller "sanitized
  ↓                                            release bundle / pip package / submodule" mechanism question (this
  ↓                                            program's Section on Phase P4) remains open — deferred, not decided.
P5 — Orchestration Center (desktop UI over AEKR runtime)   — DONE (2026-08-04): desktop-only, human-gated adapter
  ↓                                                           over AEKR schema-v2 durable state; fixed argv, no shell,
  ↓                                                           no stdout parsing, no autoapproval, no automatic retries,
  ↓                                                           and no automatic commits or pushes.
P6 — Generated-project automation  — Substantially satisfied by P3+P4 as built: new projects default to Mode 0,
  ↓                                   provider availability is checked before anything is claimed available, the
  ↓                                   Auditor is always fresh-context (AEKR's own adapter guarantee, not
  ↓                                   accreatio's to configure). No separate `.ai-engineering/` scaffold beyond
  ↓                                   orchestration.yaml was invented, since no canonical downstream structure
  ↓                                   beyond that is evidenced anywhere in AEKR today (anti-slop: zero
  ↓                                   recommendations beyond evidenced need is a valid outcome here).
P7 — W2 local companion            — DEFERRED. Depends on P2 (done) + the electron/main.ts execute() extraction
  ↓                                   (COR-1 was about duplicated validation/types, already remediated 2026-08-02;
  ↓                                   the execute()-as-shared-module extraction W2 actually needs is still open).
  ↓                                   Security-sensitive (new loopback network listener) — deliberately not
  ↓                                   attempted without its own dedicated, unhurried session.
P8 — Pre-SaaS architecture sketch  — DONE (`docs/SAAS_ARCHITECTURE_SKETCH.md`, 2026-08-03), doc-only.
```

Risk-adjusted ordering rationale: P1 was small, reversible, and already fully designed (`docs/WEB_ARCHITECTURE.md`) — lowest risk, highest evidence value as the first real Mode 1 pilot. P5 and P7 are deliberately left for a dedicated future session rather than completed in the same pass as everything else: P5 means driving AEKR's real stateful CLI protocol from Electron's privileged process (a meaningfully different, larger integration than anything else in this program), and P7 is the one phase that changes accreatio's trust boundary at all (a local network listener) — both deserve unhurried, individually-verified attention rather than being squeezed in.

### Proposed platform Phase 3 — desktop runtime review

Electron remains the pragmatic current host because it reuses the React/Vite UI and already provides the narrow preload/IPC boundary for local filesystem and Git operations. In a post-v1 platform phase, compare Electron with Tauri (and, if still credible then, Wails) using measured installer size, idle RAM, startup time, Windows support, security model, accessibility, updater/signing path, zero-cost compatibility, and migration effort. This is an evaluation gate, not authorization to migrate; any replacement must preserve the `Bridge` contract, local-first behavior, deterministic outputs, and the existing Electron path until parity is proven.

## 6. Explicit non-goals (this program)

Everything listed in this program's Section 14 (Anti-Slop): no microservices, Kubernetes, distributed queues, multi-host orchestration, remote telemetry, SaaS infrastructure, plugin marketplace, additional providers beyond `claude_code`/`codex`/`mock`, dashboards beyond what P5 specifies, generic command execution, or automatic downstream template sync. No persistent Mode 2 runner. No accounts, billing, or hosted execution (P8 stays sketch-only).

## 7. Verification strategy

Per phase: `npm test`, `npm run typecheck`, `npm run build` (accreatio side) and `python -m pytest -v` (AEKR side, unchanged by this program). P1 additionally exercises one real pause/resume of an AEKR Work Session, per this program's P1 Definition of Done.

## 8. Versioning strategy

accreatio's existing `CHANGE_CONTROL.md` per-release convention continues unchanged — each phase that ships gets its own dated entry with scope, verification evidence, and rollback commit. AEKR integration artifacts (Phase P4) additionally carry an explicit AEKR version/commit reference, never an implicit path dependency.

## 9. Rollback strategy

Standard for this repo: every phase's `CHANGE_CONTROL.md` entry names the prior verified commit as the rollback target (see existing 0.4.1/0.5.0 entries for the pattern). No phase in this program performs an irreversible migration; Mode 1 runs themselves are never auto-committed or auto-pushed (`git.automatic_commit/push: false` equivalent — actual AEKR config has no such literal keys, but no phase here authorizes automatic commit/push regardless).

## 10. SaaS hold boundary

Unchanged from `docs/WEB_STRATEGY.md` Phase W3 and this program's Section 8/Phase P8: no accounts, orgs, billing, hosted orchestration, or multi-tenant storage. P8 produces documentation only, revisitable without unblocking implementation.

**A separate, narrower W1 boundary, not to be conflated with W3/SaaS:** DEC-009 authorized and now records a zero-cost Cloudflare Pages beta at `https://accreatio.pages.dev`, behind separate exact-production and wildcard-preview Access applications for owner-approved identities. Anonymous access, broad promotion, and a custom domain remain on hold. Deployment evidence and remaining owner-authenticated acceptance gates are canonical in `CHANGE_CONTROL.md` and `docs/W1_RELEASE_READINESS.md`.

## Next action

**Phases P0, P1, P2 (P2.1-P2.4), P3, P4 (bounded), and P8 are complete** as of 2026-08-03. In sequence:

- **P1** (`5655b5e`): W0 Bridge abstraction, accreatio's first real AEKR Mode 1 pilot — Implementador (`codex`) → Auditor (`claude_code`). Found and fixed 3 real AEKR codex-adapter defects along the way. Full evidence: `docs/PHASE_P1_PILOT_EVIDENCE.md`.
- **P2** (`c57d24e`, `7203a73`, `66759f7`, `e71f136`): W1 export-first PWA — IndexedDB drafts, real ZIP export + SETUP.md (plus a real desktop/web template-parity fix), PWA offline shell, accessibility hygiene (including a real keyboard-focus-visibility bug found and fixed). Each sub-increment verified in a real browser, not just unit tests.
- **P3+P4** (`621d977`): orchestration config UI (Mode 0/1, role→provider mapping, provider detection) plus a generated starting `.ai-engineering/orchestration.yaml`, verified end-to-end through a real browser export and validated against AEKR's own `load_config`/`validate_config`.
- **P8** (`docs/SAAS_ARCHITECTURE_SKETCH.md`): pre-SaaS sketch, doc-only, no implementation.

**Still deliberately deferred:** P7 (W2 local companion), because its loopback listener changes the trust boundary. P5 is now complete as a narrow adapter over AEKR's existing durable state and human gates.

**Separately deployed with authenticated acceptance pending:** the access-restricted W1 beta (see Section 10 / DEC-009). Anonymous public access, custom domain, and W3/SaaS remain deliberately deferred.
