# Standard Operating Procedure — accreatio Web Edition

**Audience:** anyone using accreatio's browser edition. This is a user guide, not a developer or support document — for internal troubleshooting, see `docs/TROUBLESHOOTING_WHITEPAPER.md`.

**A note on naming:** accreatio is an authenticated, local-first, ephemeral-session web application for creating and exporting projects. Cloudflare Access supplies the protected portal identity; accreatio does not operate an internal password/account system. Project creation and ZIP export run locally in the browser. The web-only Blog uses Pages Functions and D1 for persistent editorial posts, a separate data class that never receives project files, attachments, ZIPs, local paths, or optional integration credentials. See `docs/WEB_STRATEGY.md` and DEC-016/DEC-017 in `DECISIONS.md` for the architectural boundary.

## 1. Where to find it — read this first

**The hosted edition is the protected beta at [accreatio.pages.dev](https://accreatio.pages.dev).** Authorized review previews are identified in `CHANGE_CONTROL.md` and the corresponding design result; the v12 testing handoff is in [Design v12 results](design-v12/RESULT.md). Cloudflare Access requires an approved identity before the application loads. DEC-009 does not permit anonymous access or a custom domain; if the origin ever loads the application without Access, stop using it and report the configuration drift. `CHANGE_CONTROL.md` identifies the version actually deployed: do not assume the `0.8.0` Blog/publisher is live until its deployment and acceptance entry exists.

For local development or an offline repository checkout, run:

```powershell
npm install
npm run build:web
npm run preview   # serves the production build at http://localhost:4173
```

Open the printed `localhost` URL in a browser to exercise the project workflow. A plain Vite preview does not supply Pages Functions, Access JWTs, or D1, so the Blog may show its intentional unavailable state. Full local API testing uses the repository's Wrangler configuration and local D1 simulation after the migration is applied; it does not bypass production Access policy.

On first use, the two-step welcome uses **Continue** and **Finish and create**. The header logo returns home. Project creation then asks one main question at a time: name, starting point, optional discovery files, idea, boundaries, working approach, team, delivery and review. Type an answer and choose **Continue**; selecting a starting point or working approach advances directly. **Back** preserves your answers, even when the current answer is incomplete. Optional questions offer **Skip for now**. Review lets you edit each part before confirming. Team and advanced delivery controls remain available when needed.

The web UI always opens in English and uses night mode. The language button enables Spanish for the current session. **Go back** returns to the welcome without clearing your draft. Project names accept up to 50 characters, and the team supports one to four distinct roles. A selected role is unavailable in other role lists. Older drafts that exceed these limits remain intact until you correct them. The project summary progressively shows attached-file and participant counts, starting point, working approach and delivery choices.

The Instagram and **Built with AEKR** footer links open separate tabs. X and LinkedIn remain visible placeholders until their profiles are configured.

The local atmosphere combines autonomous depth stars with a faster procedural nebula. Moving the mouse has no effect. A left click on exposed visible gas produces a brief smoke bubble; controls and empty sky do not. Reduced motion, save-data, slow updates and hidden windows pause or omit the moving nebula. Failed WebGL retains the local fallback. The effect receives viewport, time, theme, preferences and eligible click coordinates only; it has no access to project data, storage, IPC, network or credentials.

## 2. Installing it as an app (optional)

Once you have the page open in a Chromium-based browser (Chrome, Edge), you'll typically see an install icon in the address bar, or a prompt offering to "Install accreatio." Installing it:

- adds it to your Start Menu/Applications like a native app,
- makes it open in its own window without browser chrome,
- does **not** change what it can do — it's the same web app either way.

This step is entirely optional; the page works the same in an ordinary browser tab.

## 3. Using it offline

After your first visit, a service worker caches the project-creation app shell. You can close your browser, go offline, and reopen the page (or the installed app) to use cached project creation/export behavior. Blog posts are online portal content backed by Access, Functions, and D1; offline Blog reading or publishing is not promised and the UI may show unavailable.

If an update is available on a later visit, you'll see a browser confirmation dialog ("A new version is available. Reload now?") — accept it when convenient. It will never swap code under you silently while you're mid-form.

## 4. Filling out the form

The web form shares the domain model and visual language with desktop, but presents a deliberately smaller export workflow:

| Capability                                     | Desktop                           | Web                                                                                                                            |
| ---------------------------------------------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| Folder destination                             | Native picker                     | Not shown — output is a named ZIP download                                                                                     |
| Discovery attachments                          | Supported                         | Supported locally in the active tab; selected bytes are included only in a real ZIP export and must be reselected after reload |
| Settings, GitHub connection, execution history | Supported                         | Hidden because those desktop capabilities do not exist in W1                                                                   |
| "Check providers" (orchestration)              | Real check against installed CLIs | Always reports unavailable — a browser cannot see your local machine's installed software                                      |
| Your in-progress draft                         | Not persisted between sessions    | **Auto-saved locally** in your browser (IndexedDB) and restored next time you open the page — see §6                           |
| Blog and editorial publisher                   | Not included                       | Blog reads from D1; verified administrators receive the append-only composer                                                    |

W1 exposes one honest action: **Export project**. Tracking-only and the separate `future_projects` write remain desktop-only.

## 5. Running it — what "Execute" actually does here

In **Confirm export**, choose **Review without downloading** or **Create and download ZIP**. The final button changes between **Run dry review** and **Prepare ZIP** in that same dialog. Choosing a mode does not start it: press the final button to confirm, or Cancel to return. You can switch back to dry review before confirming.

The **FAQ** and **ToS** controls stay below every project step, final review and result. They open the relevant About section while retaining your draft and selected files in this tab. Use **New project** in the header to return to your current work. Full legal documents open a separate tab.

There is no real filesystem or Git access from a browser, by design. The review dialog displays the exact ZIP filename and ordered entry manifest. Repository and Both both mean one repository ZIP in W1; Both does not create desktop tracking. Tracking-only is unsupported and directs you to Repository or Both. When you confirm:

- With **dry-run on** (the default): you get a short summary of what _would_ be exported, nothing downloads.
- After a successful dry review, choose **Download ZIP** to open a fresh confirmation immediately. **Prepare ZIP** performs the export; cancelling returns to the dry-review result with your selected files intact.
- With **dry-run off**: accreatio builds `<project-slug>.zip` locally and requests that your browser download it. The result says **ZIP prepared; download requested** and repeats the exact manifest. This does not prove that the browser saved the file; it can block, cancel, rename, or relocate it. Check Downloads and open the ZIP to verify it contains:
  - `PROJECT_PROMPT.md`, `docs/product/discovery.md`, `AGENTS.md`, `.accreatio/project.json` — identical content to what the desktop app would write for the same inputs,
  - `SETUP.md` — literal, copy-pasteable shell commands (`git init`, `gh repo create`, `code --new-window .`, as applicable) for the steps only a real machine can perform,
  - `.ai-engineering/orchestration.yaml` — only if you enabled orchestration (see the desktop SOP §7; it works identically here, minus provider detection).
  - `docs/product/sources/` — selected discovery attachments as opaque, byte-identical files. Unsafe path characters are removed and case-insensitive collisions receive deterministic ` (2)`, ` (3)` suffixes; the prompt and provenance use those exact final basenames.

Use **Add local files** to select MD, TXT, PDF, DOCX, JSON, YAML/YML, CSV, PNG, or JPEG files. Limits are 20 files, 20 MB each, and 100 MB total. Each accepted row says Ready; rejected rows explain the specific limit or type failure and can be removed without changing other form fields. Dry-run never builds or requests a ZIP download.

Unzip the file wherever you want the project to actually live, then follow `SETUP.md` from that folder.

## 6. Your draft is saved automatically

As you type, your in-progress project form is saved to your browser's local storage roughly every half-second. Attachment bytes, names, sizes, and other attachment metadata are deliberately excluded. Close the tab, come back later, and ordinary form data reappears, but local files must be selected again; a count-only notice explains the loss. Project draft data is not sent to the Blog API. Published editorial posts are intentionally separate persistent D1 data.

Use **New draft** to discard the current draft after a confirmation. The UI reports loading, saving, saved, and unavailable-storage states. Clearing this site's data also removes the draft. Drafts are schema-versioned and legacy drafts are normalized against current defaults before use.

## 7. Reading and publishing the Blog

Choose **Blog** in the web navigation. Published posts load from the authenticated same-origin API. If Access, Functions, configuration, or D1 is unavailable, the page reports that the Blog is temporarily unavailable and does not substitute bundled stale content.

The composer appears only after the admin-capability endpoint confirms a verified publisher. Ed Lopez uses the web form; an allowlisted AEKR service identity uses the same HTTPS publish endpoint with its own revocable Access service token. A hidden composer does not prove authorization—the Function verifies every publish again. Agent publishing remains pending until the real Service Auth policy/token path is exercised in the hosted environment.

To publish through the web form:

1. Enter title, summary, body, language, display author, author role, and signature. Separate body paragraphs with a blank line. HTML and Markdown are displayed as plain text.
2. Review the complete text and confirm deliberately.
3. Wait for the success response. The new post is inserted at the top without a reload. On error, the draft stays in page memory so you can correct or retry it.

This release is append-only. It cannot edit, delete, schedule, upload media, or backdate a post. An unpublished composer draft is lost on reload. Access or service credentials must never be pasted into the form.

## 8. If something goes wrong

- **A capability is labeled desktop-only** — use the desktop app for that operation; W1 does not call unsupported desktop APIs during startup.
- **The ZIP won't download / nothing happens after “download requested”** — check the browser Downloads UI, download-permission prompt, blocked-download setting, and alternate save location. A request is not a persistence guarantee; after correcting the browser setting, return through Review for a deliberate new request.
- **The page won't load at all** — see §1: confirm you're pointed at a real running instance (local `preview` server or, once authorized, the real deployment), not a stale bookmark.
- **The project form works but Blog says unavailable** — a plain Vite preview has no Functions/D1; on the hosted portal, report the exact API error without sharing cookies, JWTs, email identity, or service-token values.
- **The composer is absent** — the verified Access identity is not in the server publisher allowlist, or the admin capability is unavailable. Do not try to expose the form with browser tools; that would not grant server authorization.
- **Publishing failed** — keep the tab open so the in-memory draft remains available. Retry only after checking the message; the UUID idempotency key prevents a same-actor retry from creating a duplicate.

For anything else, report the exact on-screen message to support — see `docs/TROUBLESHOOTING_WHITEPAPER.md`.

---

## Resumen en español

La edición web usa Cloudflare Access, sin una cuenta/contraseña interna de accreatio. El proyecto y los adjuntos permanecen locales: máximo 20 archivos, 20 MB cada uno y 100 MB total; una exportación ZIP real los incluye como bytes opacos y el borrador IndexedDB no conserva los adjuntos. El Blog es una frontera separada: Functions y D1 guardan posts editoriales, y solo Ed Lopez o identidades AEKR de servicio verificadas/permitidas pueden publicar. El Blog no forma parte de Electron y no se promete offline.
