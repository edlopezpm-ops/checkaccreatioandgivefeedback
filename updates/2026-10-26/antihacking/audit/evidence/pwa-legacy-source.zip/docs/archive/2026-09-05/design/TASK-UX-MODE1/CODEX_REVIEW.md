# Codex review — TASK-UX-MODE1

Reviewer: Participant E-adjacent — Codex Reviewer  
Date: 2026-08-05  
Scope: targeted independent implementation review; not the later Test Engineer pass or Independent Audit

## Verdict

**Needs bounded correction first.** The implementation is generally well scoped and closely follows the approved dialog structure, responsive width, group ordering, numeric bounds, atomic local draft model, AEKR topology guard, and host-specific provider wording. However, one funding-state path violates the design's fail-closed contract and can save a policy different from the one the dialog represents. That defect should be corrected and covered before proceeding. The numeric-input behavior should be corrected in the same bounded pass.

## Critical

None.

## High

### H1 — The dialog can represent subscription funding while saving an unchanged unsupported API policy

Evidence:

- `src/components/mode1/mode1Draft.ts:83` copies `orchestration.funding` into the draft without restricting or flagging unsupported funding.
- `src/components/mode1/mode1Draft.ts:125-149` validates participants, topology, and numeric limits but never validates funding.
- `src/components/mode1/mode1Draft.ts:168-197` therefore treats such a draft as valid and returns `draft.funding` unchanged.
- `src/components/mode1/Mode1ConfigurationDialog.tsx:490-519` always renders `subscription_cli` checked and the API radio disabled, independent of `draft.funding`.
- `src/App.tsx:978` accepts that normalized object as the saved orchestration configuration, while `src/App.tsx:896-900` unconditionally summarizes it as subscription/local CLI.
- `shared/domain.ts:224-229` catches unsupported funding only in whole-project validation after it has been saved; it does not make the dialog's Save fail closed or make the displayed funding state truthful.

Failure scenario: a restored/migrated draft contains a malformed or unsupported `api` funding policy. Opening Mode 1 shows subscription selected and paid API unavailable. Pressing **Save configuration** succeeds, enables Mode 1, and retains the hidden API object. The main summary then says **Funding: Subscription/local CLI** while project validation separately marks the project as needing review. This contradicts the approved requirement that malformed/unsupported paid data block visibly and never be coerced or misrepresented.

Bounded correction: validate the incoming funding discriminant in the dialog draft and block Save with a visible, linked error unless it is the currently supported canonical `subscription_cli` policy; alternatively, make the displayed and normalized draft explicitly use the approved canonical subscription policy only where the governing migration contract authorizes that conversion. Add a regression test starting from an API/malformed funding object.

## Medium

### M1 — Invalid numeric paste/input is silently discarded instead of preserved and reported

Evidence:

- `src/components/mode1/NumericDraftField.tsx:38-41` calls `onChange` only for an empty string or an all-digit string; any other browser input is ignored.
- `src/components/mode1/NumericDraftField.tsx:15-53` has no touched/blur state or `onBlur` path.
- `src/components/mode1/Mode1ConfigurationDialog.tsx:181-183` computes invalidity on every render and passes it directly to every numeric field at lines 426-480, rather than revealing errors after blur or attempted Save.

Failure scenario: a user pastes `12x` over `1800`. React immediately restores `1800`; the pasted text is neither retained nor reported, so the user cannot see or correct what was entered. Conversely, deleting a valid value shows an error immediately while typing rather than on blur/Save. Both behaviors contradict the approved non-destructive string-editing contract.

Bounded correction: retain the raw string in draft state, validate complete base-10 digits on blur/Save, and gate visible field errors on touched or attempted-Save state. Do not filter or restore invalid text.

## Low

### L1 — Task growth does not implement the specified resize observation

Evidence:

- `src/components/mode1/AutoGrowTaskField.tsx:36-44` recalculates on value changes and the global `window.resize` event only; it does not use a `ResizeObserver` on the textarea/dialog as required by the approved design.

Failure scenario: a layout/font/container-size change that changes wrapping without firing `window.resize` leaves the textarea at a stale height or overflow mode until the value changes or the window is resized.

### L2 — The required `100vh` fallback is absent from the dialog viewport rules

Evidence:

- `src/extras.css:482-500` uses only `100dvh` for maximum height.
- `src/responsive.css:233-249` uses only `100dvh` for the narrow full-viewport dialog and shell.

Failure scenario: a target browser/WebView without dynamic viewport unit support drops these declarations, so the dialog no longer has the designed viewport cap/full-height behavior. This is low risk for the current Chromium targets but is a direct design omission.

### L3 — Pure numeric tests do not cover the approved per-field boundary matrix

Evidence:

- `tests/mode1Draft.test.ts:84-93` tests boundary and ±1 cases only for the 60–7200 parser call, plus a few generic invalid formats.
- `tests/mode1Draft.test.ts:111-124` checks one low duration and one empty invocation value, but does not exercise min/max/±1 for all four named limits.
- The production table is correct at `src/components/mode1/mode1Draft.ts:39-47`, but the approved test plan required all four exact mappings and boundaries.

Failure scenario: a future off-by-one or key-to-range swap in iterations, invocations, or consecutive failures could pass the focused Mode 1 draft suite.

## None / confirmed sound

- Design fidelity: `src/extras.css:482-500` implements the exact `min(920px, calc(100vw - 32px))` width and a bounded grid shell; `src/extras.css:561-569` makes the dialog body the single intentional general scroll container. The capped task textarea is the explicitly permitted exceptional control scroll.
- Information architecture: `src/components/mode1/Mode1ConfigurationDialog.tsx:303-524` renders Participants, Providers, Execution limits, and Funding in the required order.
- Limits: labels and bounds match the approved 60–7200, 1–10, 1–100, and 1–10 contracts (`mode1Draft.ts:39-47`; `Mode1ConfigurationDialog.tsx:125-140,426-480`). No retry mislabel remains.
- Draft isolation and dismissal: the dialog initializes an independent snapshot/clone (`Mode1ConfigurationDialog.tsx:164-170`), calls the parent save only after successful normalization (`200-208`), and Close/Cancel/native Escape reach `onClose` without writing project state (`253-259,270-275,527-538`). Initial heading focus and trigger restoration are present (`172-179`; `src/App.tsx:979-982`). Backdrop clicks have no dismissal handler.
- Compatibility: repeated roles and more than four participants fail closed (`mode1Draft.ts:49-58,145-160`), and the dialog exposes the warning (`Mode1ConfigurationDialog.tsx:344-348`). The empty-topology edge is rejected by the surrounding project domain's 1–6 participant invariant.
- Responsive structure: provider/limit rows stack at 720px and the dialog becomes a safe-area-aware full-viewport surface at 600px (`src/responsive.css:220-260`).
- Scope and security: no reviewed Task code redefines participant/provider/funding domains, adds attachment/idempotency/evidence behavior, invokes a shell/eval, stores secrets, or injects user HTML. User strings are rendered through ordinary React text/value properties.
- Test honesty: `tests/mode1Dialog.test.ts:9-14` explicitly states that server rendering verifies structure/ARIA only and defers interactive focus, keyboard, and responsive behavior to real-host Test Engineer work. Given the repository has no jsdom/testing-library setup, this is a reasonable bounded structural test and does not pretend to be interactive evidence.
- Funding-test adaptation: `tests/funding.test.ts:131-152` still checks the moved fieldset for the selected subscription value, disabled API value with associated reason, shared invocation value, and absence of credential/payment UI. Moving the source target from `App.tsx` to the new dialog component is legitimate and did not weaken the assertion's substance, although source-regex tests remain structural rather than behavioral.
- Reconciliation: `docs/archive/2026-09-05/design/RECONCILIATION-01.md` concerns the future unified `execute()` request and attachment draft-schema composition. TASK-UX-MODE1 neither needed nor implemented either concern.

## Independent command results

- `npm test` — PASS (12 test files, 12 passed, 0 failed)
- `npm run typecheck` — PASS
- `npm run format:check` — PASS
- `npm run build` — PASS
- `npm run project-map:check` — PASS (17 nodes, 30 edges, 9 flows)

No prohibited package, Lighthouse, Electron, or web functional command was run. No production or existing documentation file was modified by this review.

## Follow-up corrective review — 2026-08-05

**Verdict: Proceed.** H1 and M1 are confirmed fixed. No new issue was found, so this pass made no production or test change.

### H1 verification

- `src/components/mode1/mode1Draft.ts:128-141` applies the same `evaluateFundingEligibility` gate used by project-level validation to the carried-over funding policy and current participant/provider assignments.
- `src/components/mode1/mode1Draft.ts:164-189` records an invalid funding result, includes it in overall draft validity, and makes normalization return `null` before constructing a saveable configuration. There is no alternate save path in the dialog: `src/components/mode1/Mode1ConfigurationDialog.tsx:204-212` calls normalization and returns without invoking `onSave` when it fails.
- `src/components/mode1/Mode1ConfigurationDialog.tsx:499-508` renders the funding warning whenever funding is invalid, independently of attempted-Save state. It has `role="alert"`, clear blocking language, and no dismiss control. The attempted-Save summary also links funding through the funding heading.
- The eligibility call intentionally supplies no supported AEKR API contract versions, matching `shared/domain.ts`; consequently API policies cannot become accidentally eligible in this zero-cost Mode 1 surface. Malformed subscription policies and unsupported participant/provider assignments also fail the shared eligibility gate.
- `tests/mode1Draft.test.ts:188` verifies `errors.funding`, `isMode1DraftValid === false`, and `normalizeMode1Draft === null` for an unsupported API policy. `tests/mode1Dialog.test.ts:117` verifies the persistent blocking warning structure.

### M1 verification

- `src/components/mode1/NumericDraftField.tsx:29-45` keeps local touched state, forwards `event.target.value` without filtering any string, and reveals invalidity only when `touched || showErrors`.
- `src/components/mode1/Mode1ConfigurationDialog.tsx:436-495` passes `showErrors={attemptedSave}` to all four fields: session duration, iterations per entity, provider invocations, and consecutive failures. Each raw string is stored directly in its corresponding draft property.
- `tests/mode1Draft.test.ts:126-139` covers the exact minimum, maximum, one-below-minimum, and one-above-maximum cases for every limit. Invalid complete strings remain rejected by normalization without any input-path coercion.

### Independent command results

- `npm test` — PASS (12 test files, 12 passed, 0 failed)
- `npm run typecheck` — PASS
- `npm run format:check` — PASS
- `npm run build` — PASS
- `npm run project-map:check` — PASS (17 nodes, 30 edges, 9 flows)

No prohibited package, Lighthouse, Electron, or web functional command was run. The only file changed by this follow-up pass is this required review record.
