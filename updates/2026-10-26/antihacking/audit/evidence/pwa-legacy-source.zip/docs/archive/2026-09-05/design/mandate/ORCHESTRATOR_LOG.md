# Orchestrator decision log — AEKR corrective increment

Owner authorization: Ed Lopez, signed 2026-08-04. Orchestrator: Claude (this session's continuity
lives in this log + `docs/design/`, not in any single chat context).

Read `MASTER_PROMPT.md` and `SUPPLEMENTAL_PROMPT.md` in this directory first. This file is the
running decision log / context-preservation checkpoint required by supplemental §18-19. Every fresh
participant context should read this file before starting.

## Resolved structural decisions

1. **Codex participant realization.** No Codex CLI was preinstalled in the devcontainer. Installed
   `@openai/codex` globally (not a project dependency). `codex login status` confirms it is already
   authenticated via a ChatGPT subscription login (not an API key) — satisfies the master prompt's
   `subscription_cli` zero-direct-cost default. Participant B (Solution Designer) and Participant C
   (Implementer) run as `codex exec` fresh-context invocations, sandboxed `read-only` for pure
   analysis or `workspace-write` when producing design docs, scoped by explicit prompt instruction
   to touch only the named output path(s). Orchestrator verifies via `git status`/`git diff` after
   every run that no out-of-scope file changed.
2. **Gate cadence.** One Human Design Gate for the complete Solution Design package (covering all
   approved Tasks), then Task-by-Task implementation with Orchestrator-only Sprint checkpoints
   (supplemental §27-28), escalating to the owner only for genuine ambiguity, scope growth, or a
   High/Critical audit finding. One Human Final Acceptance Gate at the end. (Owner-selected option,
   2026-08-04/05.)
3. **AEKR is not present in this environment.** Confirmed independent upstream repo per
   `docs/prompts/ACCREATIO_SUPER_PROMPT_v1.0.0.md` and `AGENTS.md`. This increment only touches
   accreatio's side of the AEKR contract (`shared/domain.ts`, `.ai-engineering/orchestration.yaml`
   generation). No AEKR-repo changes are in scope unless a downstream requirement proves impossible
   without one — master prompt §3 (Participant B restrictions) requires that to be separately
   justified, not assumed.
4. **Reporting style.** Owner wants terse, single-line/robot-style updates for intermediate work.
   Full prose/structured summary is reserved for the final report only (owner instruction,
   2026-08-05).

## Environment baseline (2026-08-05)

- `node_modules` symlink target (`/tmp/accreatio-deps/node_modules`) was empty on container start —
  environment gap, not an app defect. Fixed with `npm install`.
- Baseline after install: `npm test` = 41/41 passing, `npm run typecheck` = clean. This is the
  regression baseline the Test Engineer compares against later.
- `npm install` incidentally rewrote `package-lock.json` (dropped `libc` optional-dependency metadata
  fields — npm-client-version noise, not a real dependency change). Reverted with `git checkout --
  package-lock.json` to keep the diff clean.

## Sequence status

- [x] Repository/contract discovery
- [x] Reproduction report — `docs/archive/2026-09-05/design/REPRODUCTION_REPORT.md`. 6/11 issues fully confirmed, 5/11
      partially confirmed/inaccurate as originally worded, 6 need a live Test Engineer pass to fully
      close, 3 incidental findings classified (1 in-scope-later, 2 separate backlog).
- [x] Task backlog validation — `docs/archive/2026-09-05/design/TASK_BACKLOG.md`. 9 Tasks retained, reordered by
      evidenced dependency, all 11 issues mapped exactly once.
- [x] Full Task/Sprint/MSS Solution Design package — `docs/design/TASK-*/DESIGN.md` (9 files, ~2900
      lines). Every run verified zero-production-file-touched via `git status` immediately after.
- [x] Orchestrator consistency review — found 2 cross-task conflicts (parallel design rounds don't
      read siblings): draft-schema-version collision (Participant-Instances vs Web-Attachments both
      claimed v3) and `execute()` signature collision (single-object vs 3-positional-arg). Resolved
      by `docs/archive/2026-09-05/design/RECONCILIATION-01.md`, an authoritative override layered on the two affected
      DESIGN.md files. No other conflicts found; terminology, dependency joins (`participantId`,
      `providerId`, `operationId`), and product boundaries are consistent across all 9 docs.
- [x] HUMAN DESIGN GATE — **approved by Ed Lopez, 2026-08-05.**
      1. Design package (9 Tasks + RECONCILIATION-01) approved as-is.
      2. AEKR-incompatible-topology fallback accepted: ship 1-6/repeated-role participant model for
         planning; Mode 1 execution stays capped at AEKR-compatible topologies (1-4 unique roles)
         until a separate future increment investigates an upstream AEKR contract change (out of
         scope here — AEKR is an independent repo not present in this environment).
         **Owner note for that future AEKR-side investigation (Ed, 2026-08-05):** AEKR should
         eventually become portable and support including more agents/participants on demand. This
         belongs in AEKR's own "future improvements" record in its own ("ai engineering knowledge
         repo") repository, not in accreatio — recorded here only as a pointer because accreatio has
         no access to that repository from this environment. Whoever picks up the upstream contract
         investigation (participant-keyed adapters, 1-6 participants, repeated roles — see the
         illustrative target shape in `TASK-PARTICIPANT-INSTANCES/DESIGN.md` MSS 4.2) should carry
         this portability/on-demand-agent-count requirement into that work.
      3. **About wording decision (overrides TASK-BRAND-ABOUT/DESIGN.md's default recommendation):**
         Ed chose to ADD the "copyright holder and licensor" / "titular de los derechos de autor y
         licenciante" label. Per that design's own gating rule (§2, "Legal wording boundary and
         approval branches"), implementing this requires: confirm `LICENSE`'s current text remains
         controlling (or synchronize it first), then update all UI/legal summaries in the same
         implementation Sprint. The Implementer must treat this as explicit owner approval to take
         that branch, not the baseline path.
      4. Theme's native-select-popup-variance acceptance: resolved by Orchestrator directly (design
         doc explicitly delegated this to the Orchestrator, not the owner) — accepted as a documented
         platform constraint.
- [x] Implementation order (Orchestrator decision): backlog's validated order is followed except
      TASK-EXEC-IDEMPOTENCY is moved before TASK-WEB-ATTACHMENTS (both implement RECONCILIATION-01's
      unified `ExecutionRequest` envelope; Idempotency owns the UI-boundary `operationId` origination
      that Attachments' `webAttachments` field threads through, so building it first avoids Attachments
      retrofitting that plumbing). Final order: THEME → PARTICIPANT-INSTANCES → PROVIDER-REGISTRY →
      FUNDING-BUDGET → UX-MODE1 → EXEC-IDEMPOTENCY → WEB-ATTACHMENTS → EXEC-EVIDENCE → BRAND-ABOUT.
## Implementation-time correction: draft schema version (supersedes part of RECONCILIATION-01)

`RECONCILIATION-01` assigned `DRAFT_SCHEMA_VERSION = 4` to `TASK-WEB-ATTACHMENTS`. During actual
implementation, `TASK-FUNDING-BUDGET` (implemented before Web-Attachments, per the Orchestrator's
chosen sequence) correctly followed its own design's collision rule ("if participant/provider Tasks
already shipped v3, bump once to v4") and claimed **v4 for its own migration**. The tree now has
`DRAFT_SCHEMA_VERSION = 4` owned by Funding-Budget. **`TASK-WEB-ATTACHMENTS` must therefore target
v5, not v4**, composing its `attachments: []`-stripping behavior into the v4→v5 step. This is an
Orchestrator-level sequencing correction (caught via the per-Task diff review, not by the Designer or
Implementer), consistent with the same escalating-version pattern both `RECONCILIATION-01` and
`TASK-FUNDING-BUDGET`'s own design anticipated. No other part of any design is affected.

## Implementation status

- [x] TASK-DESIGN-THEME — verified: 47/47 tests, typecheck/format clean, diff scope matches plan.
- [x] TASK-PARTICIPANT-INSTANCES — verified: 55/55 tests, typecheck/format clean, AEKR fail-closed
      guard genuinely implemented/tested. Minor disclosed deviation: field kept as `provider`, not
      renamed to `providerId` (cosmetic, no behavior change).
- [x] TASK-PROVIDER-REGISTRY — verified: 69/69 tests, typecheck/format/project-map clean, no shell
      interpolation, no production mock provider.
- [x] TASK-FUNDING-BUDGET — verified: 77/77 tests, typecheck/format/project-map clean, no leftover
      misleading budget fields, no credential fields, `DRAFT_SCHEMA_VERSION` now 4 (see correction
      above).
- [x] TASK-UX-MODE1 — implemented directly by the Orchestrator (Claude, this session), per the
      owner's mid-implementation instruction below. Verified: 94/94 tests, typecheck/format/build/
      project-map clean. New: `src/components/mode1/{mode1Draft.ts, NumericDraftField.tsx,
      AutoGrowTaskField.tsx, Mode1ConfigurationDialog.tsx}`, `tests/mode1Draft.test.ts`,
      `tests/mode1Dialog.test.ts` (structural, via `react-dom/server`, no new dependency). Removed
      obsolete inline-editor CSS/markup. One incidental fix: `tests/funding.test.ts` source-grepped
      the old inline `<fieldset className="funding-policy">` in `App.tsx`; updated to grep the new
      dialog file/class name since that markup legitimately moved. Docs: `CHANGE_CONTROL.md`,
      `docs/SOP_DESKTOP.md` §7 (execution-limit terminology). **Flagged for Codex review below** —
      this was implemented without the normal fresh-context separation from Orchestrator review.
- [x] TASK-EXEC-IDEMPOTENCY — Codex, verified: 105/105 tests, typecheck/format/build/project-map
      clean. `ExecutionRequest` matches RECONCILIATION-01's four-field unified contract exactly
      (`operationId`, `definition`, `settings`, optional `webAttachments`). Guards at UI/Electron
      main-process/W1 module boundaries; fingerprint uses metadata-only attachment identity, never
      Blob content. `electron/files.ts` untouched as instructed.
- [x] TASK-WEB-ATTACHMENTS — Codex, verified: 117/117 tests, typecheck/format/build/project-map
      clean. `DRAFT_SCHEMA_VERSION` correctly at 5 (composed on top of Funding-Budget's v4, per the
      correction above). `webAttachments` threaded through the existing single-argument
      `ExecutionRequest`, no parallel call path. Actual ZIP byte-equality verified for text/binary/
      NUL/PNG-like/duplicate-name fixtures. `docs/PRIVACY_POLICY.md`'s IndexedDB-storage contradiction
      (flagged by the Reproduction Report) reconciled: attachments now correctly documented as
      transient-only, never persisted, never uploaded. No `fetch`/`XMLHttpRequest`/upload path exists.
- [x] TASK-EXEC-EVIDENCE — Codex, verified: 122/122 tests, typecheck/format/build/project-map clean.
      `ExecutionOutcome = "dry-run" | "success" | "partial" | "failure"`; W1 delivery evidence hard-
      codes `browserPersistenceVerified: false` (never claims disk-save certainty it can't back).
      Reused Web-Attachments' existing resolved manifest builder for preview/evidence rather than a
      second naming algorithm; corrected the pre-existing tracking-only preview mismatch the
      Reproduction Report found.
- [x] TASK-BRAND-ABOUT — Codex, verified: 127/127 tests, typecheck/format/build/project-map clean.
      Owner-approved label "copyright holder and licensor" / "titular de los derechos de autor y
      licenciante" added to the About legal paragraph in both locales; `LICENSE` itself untouched
      (git status confirms no change); the unapproved second branch (changing grant/restriction/
      holder/year/"all rights reserved" language) was correctly NOT implemented.

**All 9 Tasks complete.** Final counts: 127 test files pass cumulatively at each checkpoint (each
Task's own count reflects tests existing at that point in the sequence); typecheck/format/build/
project-map clean after every single Task, independently reproduced by the Orchestrator each time,
not just trusted from Implementer self-reports.

## Codex reinstated as Implementer (Ed Lopez, 2026-08-05)

The Codex usage-limit block lifted (owner renewed/added quota; `codex login status` confirms
ChatGPT-subscription auth is still in effect, not an API key — zero-direct-cost default intact).
**Owner instruction:** resume Codex as Participant C (Implementer) for the remaining 4 Tasks, and
additionally have Codex independently review `TASK-UX-MODE1` (the one the Orchestrator implemented
directly, without the normal role/context separation) once the Orchestrator's current work is done.
This review is in addition to, not a substitute for, the later Claude Test Engineer and Independent
Auditor phases — it specifically targets the Orchestrator/Implementer role collapse for that one
Task, using a different vendor for a genuinely independent look before those phases begin.

## Codex review of TASK-UX-MODE1: result and correction

Findings: `docs/archive/2026-09-05/design/TASK-UX-MODE1/CODEX_REVIEW.md` — Critical 0, High 1, Medium 1, Low 3.
Independent commands (test/typecheck/format/build/project-map) all reproduced as passing.

**Owner instruction:** since the Orchestrator had already started the correction when this landed,
the Orchestrator finished it directly rather than handing it to Codex; any *further* issue Codex
finds on re-review is Codex's to fix, not the Orchestrator's.

- **H1 (fixed):** the dialog draft never validated `funding`, so a malformed/unsupported carried-over
  funding policy (e.g. from a corrupted/tampered draft) could be silently re-saved while the UI only
  ever displayed "subscription selected." Fixed in `mode1Draft.ts` by validating the draft's funding
  via the existing `evaluateFundingEligibility` (same check the project-level domain validator uses)
  and blocking Save with a visible, non-dismissable warning explaining the dialog cannot repair it.
  Regression tests added in `tests/mode1Draft.test.ts` and `tests/mode1Dialog.test.ts`.
- **M1 (fixed):** `NumericDraftField` silently dropped non-digit keystrokes/paste instead of keeping
  them visible for the user to correct, and showed validation errors on every render instead of only
  after blur/attempted-Save. Fixed: the field now accepts any string, added local `touched` state,
  and errors only display once the field is touched or a Save was attempted.
- **L3 (fixed, cheap):** added the requested exact min/max/one-past-boundary matrix for all four
  execution limits.
- **L1, L2 (deferred, owner-visible, not blocking):** `AutoGrowTaskField` uses `window.resize` only,
  not a `ResizeObserver` (misses non-window layout changes); dialog viewport CSS uses `100dvh` only,
  no `100vh` fallback for browsers without dynamic-viewport-unit support. Both are real per Codex's
  own severity call (Low), current Chromium/Electron/W1 targets are unaffected. Recorded here rather
  than silently dropped; revisit if the Test Engineer's live pass on the actual target browsers
  surfaces either as a real problem.

Verified after the fix: 98/98 tests, typecheck/format/build/project-map clean.

## Test Engineer and Independent Audit reassigned to Codex (Ed Lopez, 2026-08-05)

**Owner instruction:** run the Claude Test Engineer and Claude Independent Auditor phases as Codex
instead, each as its own separate dedicated fresh context/agent (not shared with each other, not
shared with any Implementer run), structured using AEKR's own role-separation vocabulary
(`EXECUTE_ROLE_STEP`-style verification for the Test Engineer, `EXECUTE_INDEPENDENT_AUDIT` semantics
for the Auditor — the same distinction `shared/domain.ts`'s YAML generation already encodes for real
AEKR sessions). The Orchestrator reviews each briefly when it finishes.

**Disclosed tradeoff:** the master prompt assigns these two roles to Claude specifically so a
different vendor than the Codex Implementer checks the work — 8 of the 9 Tasks were Codex-implemented
(1 was Orchestrator-implemented then Codex-reviewed). Running Test Engineer and Independent Audit on
Codex too means the same vendor that wrote most of the code is also the one checking it; this is a
real reduction in cross-vendor independence, not merely a fresh-context question. What remains intact
per this instruction: genuinely separate fresh contexts for Test Engineer vs. Auditor vs. every
Implementer run (no shared session, no self-review within the same context), which is the structural
safeguard AEKR itself actually enforces (fresh-context Auditor, Implementer-only write access). This
is recorded as an explicit, knowing owner decision, not a silent substitution.

## Mid-implementation participant substitution (Ed Lopez, 2026-08-05)

Codex CLI returned a hard usage-limit error mid-`TASK-UX-MODE1` ("try again at Aug 10th, 2026"),
before any file was modified — tree verified clean at exactly the post-`TASK-FUNDING-BUDGET` state
(77/77 tests, typecheck clean) before proceeding. This was reported to the owner rather than silently
routed around, per the master prompt's "do not silently collapse participants" instruction.

**Owner decision:** switch Participant C (Implementer) for the 5 remaining Tasks (UX-Mode1,
Exec-Idempotency, Web-Attachments, Exec-Evidence, Brand-About) from Codex to fresh Claude subagents
(via the Agent tool), rather than pausing until Aug 10 or purchasing more Codex credits.

**Refined owner decision (same turn):** rather than spawning fresh Claude subagents for Participant
C, the owner instructed the Orchestrator (this session) to implement the remaining 5 Tasks directly.

**Disclosed consequence — this is a larger collapse than the vendor-independence one above:** the
Orchestrator (Participant A) is now also acting as Implementer (Participant C) for these 5 Tasks, in
the same context, with no fresh-context boundary between design-review and implementation. Master
prompt §3 explicitly restricts Participant A from implementing production code; this is a knowing,
explicit owner override of that restriction, not a silent one — recorded here per "do not silently
choose one interpretation." Consequence: the Orchestrator's own "Sprint boundary" review of this
implementation work is no longer independent review, it is self-checking (tests/typecheck/diff-scope
verification remain real and are still performed, but do not substitute for a separate reviewer).
This makes the Claude Test Engineer and Claude Independent Auditor phases the FIRST genuinely
independent, fresh-context checks on this implementation work — those two phases remain unchanged:
separate fresh Agent-tool contexts, never self-review, per the master prompt. They are not weakened
by this decision and must not be skipped or lightened because of it.

## Test Engineer result and correction (2026-08-05)

`docs/archive/2026-09-05/design/TEST_ENGINEER_REPORT.md` — Critical 0, High 0, Medium 2, Low 1. Key environment finding:
**this devcontainer cannot launch Electron or Chromium** (`SIGTRAP`/sandbox `Operation not permitted`
for Electron; `EPERM` binding a localhost port for the Vite preview server used by web smoke tests).
`npm run test:electron`, `npm run test:web`, and `npm run lighthouse` are blocked by this container's
own restrictions, not by an accreatio defect — confirmed by reproducing the same fatal error with a
standalone Playwright Chromium launch. No permission escalation was available or attempted.

Real findings, both fixed by a fresh Codex correction cycle (a NEW context, not the Test Engineer's
own, per owner instruction): **M-01** (W1's failure-result helper hard-coded `completed: []` even
when the ZIP-build step had actually completed before a later download-request failure — violated
TASK-EXEC-EVIDENCE's own "completed must mirror actual step evidence, outcome is partial not failure
when something completed" contract) and **L-01** (`docs/SOP_DESKTOP.md` overstated that dialog Save
itself writes the orchestration YAML; corrected to say Save persists the definition, execution writes
the file). **M-02** (the reserved smoke-test scripts cover less of the acceptance matrix than earlier
Task reports implied) was deliberately left open — expanding untestable-in-this-environment scripts
has low verification value here; see the open question below.

Verified after correction: 127/127 tests, typecheck/format/build/project-map clean.

**Open question for the owner:** live Mode 1 interactive (focus trap/keyboard/responsive/zoom), real
desktop artifact, real W1 download/reload, and theme rendering evidence cannot be produced in this
container at all, regardless of code quality — this is an infrastructure ceiling, not a pending fix.

- [x] Test Engineer (deterministic tier complete; live-host tier blocked by environment — see above)

**Owner decision on the environment gap (2026-08-05):** proceed to Independent Audit and the Final
Acceptance Gate now on everything this container can verify; the final report will flag live-host
Electron/Chromium/Lighthouse evidence as an explicit open item for the owner to close on a capable
machine (Windows dev box, or the existing GitHub Actions Windows CI referenced elsewhere in this
repo) before treating the increment as fully production-verified. Not a silent gap — disclosed here
and will be disclosed again in the final report.

- [x] Independent Audit — `docs/archive/2026-09-05/design/INDEPENDENT_AUDIT_REPORT.md`, 2 Low findings (L-A, L-B), both
      fixed by a separate fresh Codex correction cycle and independently reverified (127/127 tests,
      typecheck/format/build/project-map clean). All 3 principal checks passed.
- [x] Final report — `docs/archive/2026-09-05/design/FINAL_REPORT.md`.
- [x] **HUMAN FINAL ACCEPTANCE GATE — accepted by Ed Lopez, 2026-08-05.** Increment complete. Live-host
      verification (Electron/Chromium) remains a tracked follow-up per the owner's earlier decision,
      not a blocker to acceptance. Nothing was committed or pushed at any point in this session.
