# Frontend audit reconciliation — 2026-08-13

**Author:** Claude (AEKR mode), orchestrating.
**Method:** every finding in the root `docs/archive/2026-09-05/CURSOR_UX_AUDIT.md` re-checked against the
working tree at `076e4ab`, by reading the exact selector, component, or token it
names. No finding is recorded as closed on the strength of the audit text alone.
**Verdict:** of 14 findings, **1** was a live defect and is now fixed under an
explicit owner decision, **9** were already implemented or already mitigated,
and **4** were never code defects. Two of the nine (6 and 9) are partial: their
residue is recorded below rather than waved through.

**Independent audit:** Codex reviewed the first version of this document at
commit `b808928` and returned FAIL, correctly catching a miscount, two
inaccurate evidence citations, and an unsupported claim about the display
voice. All five findings were verified against the tree and accepted; this
revision is the correction. See "Audit corrections applied" at the end.

## Why this document exists

`docs/archive/2026-09-05/CURSOR_UX_AUDIT.md` is dated 2026-08-06 and is untracked, so it carries no
commit that would place it against a known tree. It was read here as a
*hypothesis list*, not a work order. Treating it as a backlog would have meant
re-implementing behaviour the product already has, and the audit itself is
explicit that it never rendered a browser: *"No hay navegador ni pantalla
renderizada en esta auditoría… Tratar ratios como estimaciones de riesgo, no
como certificación WCAG."*

That limitation is honoured here in both directions. This reconciliation is
also static: it proves what the code declares, not what a browser paints.
Findings 6, 12, and 13 concern rendered output over an animated WebGL nebula and
cannot be settled by either document. They are deferred to the authenticated
browser pass (SOP H-03), which is the first step in this project that actually
looks at pixels.

## Finding-by-finding

| # | Finding | State | Evidence |
|---|---|---|---|
| 1 | Brand fonts declared but never loaded | **Was open — fixed under owner decision** | Condition confirmed; remedy applied after Ed Lopez (HOE) explicitly superseded two prior entries on 2026-08-13. See below. |
| 2 | Two concurrent `<h1>` in the creation flow | Already closed | `App.tsx:943` renders `<p className="section-head__title">`, not `<h1>`. Each stage keeps the single `<h1 id="…-title">`. |
| 3 | `lang` does not follow the UI locale | Already closed | `App.tsx:423` — `document.documentElement.lang = s.locale`, in the effect keyed on `[s.locale, s.theme]`. |
| 4 | Export modal traps keyboard without inerting the shell | Already closed | `App.tsx:1169` is a native `<dialog>`; `App.tsx:847` calls `dialog.showModal()`, which inerts the rest of the document natively. |
| 5 | Mobile stage gate rejects without explaining | Already closed | `CreationWorkspace.tsx:35` — `<p className="stage-navigation__feedback" role="alert">`. |
| 6 | Contrast weakened by atmosphere and opacity | Already mitigated; **pixel check deferred** | `.aekr-signature` (`styles.css:483`) uses `--text-secondary` at `opacity: 0.84` over a `color-mix(… 78%)` scrim plus `text-shadow` and `backdrop-filter` — not the `--text-muted` at `0.52` the audit describes. Real ratio over live WebGL is H-03's call. |
| 7 | Brand hierarchy inconsistent across web surfaces | Not a defect — deliberate | Marketing surfaces (About, Blog, onboarding) lead with the brand; tool UI carries it in the header mark only. That is the rule the audit proposes, already in force. Changing it is a brand decision, not a correctness fix. |
| 8 | Duplicated draft-state channels | Not a defect — the premise is wrong | The two channels do not overlap. `WebExperience.tsx:30-36` renders its `draft-state` paragraph **only** when `draftState === "error"`, and its standing copy (`:24-28`) describes the web model — Cloudflare protection, browser-resident project, ZIP export, separate editorial store — not save status. Routine "saved" state appears once, in the header. |
| 9 | Legacy 11px error microtype | Closed **for error text**; residue noted | The finding as written is closed: `.control em` (`styles.css:879`) and `.field-error` (`styles.css:2294`) both use `var(--text-sm)`, so the two error systems no longer disagree. `11px` does survive elsewhere — mostly circular counter badges (`.agent-list > div > b`, `.plan li`), but also `.result details`, which is body copy inside a disclosure, not a counter. That one is a genuine leftover; it is outside the finding's stated scope and is left for a typography-scale pass rather than fixed opportunistically here. |
| 10 | Blog chrome/content language mismatch | Already closed | `BlogExperience.tsx:477` renders a per-post language badge; `:513` sets `lang={post.language}` on the article. |
| 11 | Sticky header without skip link | Already closed | `AppFrame.tsx:52` renders `.skip-link` → `#app-content`; styled at `styles.css:233`. `scroll-margin-top` present at `styles.css:2085`, `styles.css:2282`, `responsive.css:237`. |
| 12 | Purple-nebula aesthetic risks indistinction | Not actionable | Long-term brand differentiation, explicitly not a blocker. |
| 13 | Residual atmosphere cost when WebGL runs | Not actionable | The audit's own verdict is that the degradation path is correct and to "afinar, no reinventar." No change made. |
| 14 | `theme-color` pinned to dark | Already closed | `App.tsx:424-426` rewrites the `theme-color` meta on every theme change. |

## Finding 1 — condition confirmed, remedy applied by owner decision

**The condition is real.** `--font-brand` and `--font-heading` name
`"Posterama"`, `--font-body` and `--font-ui` name `"Inter"`, and `--font-code`
names `"JetBrains Mono"`, across four token blocks (`src/styles.css` dark and
light, `public/legal/legal.css`, `scripts/project-map.template.html`). None is
delivered: there is no font file anywhere in the repository, no `@font-face`
rule, and the Project Map template enforces `font-src 'none'`.

**What that does and does not mean.** A machine that happens to have Posterama
or Inter installed renders them — `docs/archive/2026-09-05/design-v6/DESIGN.md:45` says so
explicitly, and the tokens were written on that basis. The defect is not that
the product looks wrong; it is that appearance is decided by what each visitor
happens to have installed, which no one controls and no one can test. The
author's machine and a visitor's can disagree with nothing in the repository
able to say which is correct.

**The display role was never inverted.** `DECISIONS.md:29` fixes the intended
roles: *"display serif for editorial headings, sans for UI/body/control text,
and mono only for technical counters/code… do not add or download a font."*
Posterama resolving to a generic `serif` therefore lands on the intended role,
not against it. An earlier revision of this document claimed the voice
inverted; that was wrong and the independent audit caught it.

**The remedy was not this session's to apply on its own.** Two recorded
decisions covered it:

- `CHANGE_CONTROL.md:22` (design v6) — *"Applied the exact owner-supplied
  typography tokens and roles… Posterama for mark/H1/H2, Inter 400/500/600…
  No font binary or remote font request was introduced; **missing licensed
  families resolve through the documented generic fallbacks**."* The tokens are
  owner-supplied and the fallback behaviour was accepted, not overlooked.
- `CHANGE_CONTROL.md:9` (design v8) — *"**unlicensed font substitution** and a
  global palette/motion redesign **were intentionally not adopted**."* A prior
  pass considered exactly the substitution the audit recommends and rejected it.

A working fix was implemented, then reverted on discovering those entries and
put to the owner as three options — keep as-is, adopt host-resident stacks, or
fund a real face. Under the AEKR authority order a recorded owner decision
outranks an agent proposal, so the conflict was surfaced rather than resolved
by silently reinterpreting it. (`DECISIONS.md:29` also rules out the third
option on its own terms: *"do not add or download a font."*)

### Decision

**Ed Lopez (HOE), 2026-08-13: adopt host-resident stacks.** This explicitly
supersedes the two entries above for the typography tokens only; nothing else
in either entry is reopened. The reverted patch was re-applied verbatim.

Applied to all four surfaces carrying the token block — `src/styles.css` (dark
and light), `public/legal/legal.css`, and
`scripts/project-map.template.html`:

- `--font-brand` / `--font-heading`: `Georgia, "Times New Roman", "Nimbus Roman", serif`
- `--font-body` / `--font-ui`: `system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif`
- `--font-code`: `ui-monospace, "Cascadia Mono", "Segoe UI Mono", "Roboto Mono", Menlo, Consolas, monospace`

These stacks keep the roles `DECISIONS.md:29` fixes — display serif for
editorial headings, sans for UI/body/control text, mono for code — so the role
contract is unchanged and the tests asserting it still pass unmodified. What
changes is that the outcome is now the same on every machine instead of
depending on what each visitor has installed. On a machine without Posterama or
Inter the rendering is materially the same as before; on one that had them
installed, headings move from Posterama to Georgia and UI text from Inter to
the platform UI face — the same roles, a determined result. No font binary,
`@font-face` rule, or remote request was added, so the zero-cost constraint,
`DECISIONS.md:29`'s "do not add or download a font", and the Project Map's
`font-src 'none'` boundary are all untouched.

**Regression guard.** `tests/typography.test.ts` previously asserted the phantom
names as literal expected tokens — it was pinning the defect in place. It now
matches declared family lists (tolerating Prettier's line wrapping) and adds
`no surface declares a font family the build never delivers`, which fails on any
`@font-face`, on `Posterama`/`"Inter"`/`JetBrains Mono`, and on any webfont CDN
import. CSS comments are stripped before that check so prose explaining the
decision stays legal.

### Still open, and deliberately not decided here

Host-resident stacks make the outcome determined; they do not give accreatio a
distinct typographic identity. That still requires shipping a face, which
`DECISIONS.md:29` currently forbids outright and `AGENTS.md` constrains by cost.
Reopening it means a licensed webfont (recurring cost) or an SIL OFL face
self-hosted from the repository (no licence cost, but a binary asset, an
`@font-face` rule, `THIRD_PARTY_NOTICES.md` attribution, and relaxing
`font-src 'none'`). Neither is assumed, and both need the HOE to lift the
existing prohibition first.

## Audit corrections applied

Codex audited `b808928` in a fresh read-only context and returned **FAIL**.
Each finding was re-verified against the tree before being accepted; none was
taken on the auditor's word. All five were correct.

| # | Finding | Correction |
|---|---|---|
| 1 | The 10/3/1 split did not match this document's own table, which classified 9 as closed/mitigated and 4 as non-defects | Counts corrected to 1/9/4 |
| 1 | Finding 8's evidence misdescribed `WebExperience.tsx` — it neither says "no account" nor duplicates routine save status | Row 8 rewritten against `WebExperience.tsx:24-36`; the premise is wrong, not merely deliberate |
| 1 | Finding 9's claim that all remaining `11px` rules are counters is refuted by `.result details` | Row 9 rewritten; the residue is now recorded instead of waved through |
| 2 | "Display voice inverts" and "every surface falls through" are unsupported — `DECISIONS.md:29` defines display serif as intended, and `design-v6/DESIGN.md:45` says installed families render first | Both claims removed and replaced with the actual defect: appearance is undetermined, not inverted |
| 4 | "Every commit reaching main is still fully gated" is unsupported — no branch protection exists in the tree | Corrected in `CHANGE_CONTROL.md`; the account plan cannot enforce it (see below) |
| 5 | The "preserved patch" was not an artifact in the tree, and the `core.*` files were **not** gitignored | Both corrected in `CHANGE_CONTROL.md`; the patch has since been applied, so the claim is retired rather than relocated |

One finding is **not** accepted as stated. Codex reads `CHANGE_CONTROL.md`'s
verification and deployment lines as unsupported because they cannot be derived
from the tree. That is true of every entry in this file by design — it records
operator-run evidence (CI run IDs, deployment IDs, Lighthouse scores) that a
repository cannot contain. The convention is unchanged here; the specific
claims added by this session were re-run and are accurate.


## What this session did change

Neither item is a finding from the audit; both were found while verifying it.

- **CI double-billing.** `.github/workflows/ci.yml` triggered on both `push`
  and `pull_request`, so a branch push with an open PR ran the full Windows
  gate twice at the 2x runner rate. `push` is now scoped to `main`; pull
  requests and manual dispatch are unchanged, and every commit reaching `main`
  is still gated.
- **Project Map viewer renamed** to `accreatio-project-map.html` at the HOE's
  direction, so a downloaded copy stays identifiable beside other AEKR project
  maps. `project-map.json` deliberately keeps the standard name: the AEKR
  `project-map-standard.md` declares it canonical and agents read it by that
  name. Generator, parity check, functional smoke, test fixture, `PROJECT_MAP.md`,
  `README.md`, and `W1_RELEASE_READINESS.md` follow. Historical audit reports
  keep their original references as the evidence they are.

## Environment defects found and cleared

Neither is a source defect; both blocked all local verification on Windows and
would have blocked any new contributor on the same checkout.

- `node_modules` held a Linux esbuild binary (`@esbuild/linux-x64` present,
  `@esbuild/win32-x64` required), so every test, typecheck, build, and Wrangler
  invocation failed on this host. Cleared by `npm ci`.
- Zero-byte **files** named `dist` and `dist-electron` occupied the paths the
  build needs as directories, failing `vite-plugin-pwa` with
  `EACCES: permission denied, mkdir 'dist'`. Removed, along with four zero-byte
  `core.*` crash artifacts. All six were untracked and gitignored.
