# TASK-PROVIDER-REGISTRY — Capability-driven provider registry

Status: design complete; no production implementation performed. Authority: `docs/archive/2026-09-05/design/TASK_BACKLOG.md` entry `TASK-PROVIDER-REGISTRY`. This record owns EXT-01 and consumes the approved design of `TASK-PARTICIPANT-INSTANCES`; it does not redefine participant identity, funding, the Mode 1 dialog, or AEKR.

## Task contract

Objective: replace parallel Claude Code/Codex switches with one honest, capability-driven provider source while retaining only the two provider/auth/adapter paths evidenced by current code.

In scope: provider identity/descriptors, capabilities, availability vocabulary, desktop CLI/auth detection, W1 detection limitation, participant-instance assignment, selection eligibility, current adapter emission, legacy migration, UI consumption, bridges, tests, security, and extension documentation. Non-goals: new providers or auth modes, downloads, credentials, arbitrary commands, paid API behavior, generic execution, or speculative AEKR changes.

Binding dependency: each future `OrchestrationParticipantConfig` has `participantId`, `providerId`, and task. Provider assignment follows the stable participant ID through role change/reorder. The current AEKR YAML remains role-keyed and therefore supports only the dependency Task's compatible unique-role 1–4 subset; repeated roles/5–6 fail closed. A registry does not cure that upstream limitation.

## Sprint 1 — Existing-model discovery

Objective: establish the actual closed paths and behavior to preserve. Entry: mandate, supplemental prompt, reproduction report, backlog, Orchestrator log, and participant design read. Included artifacts: current provider domain, host detection, bridges, UI, generation, and tests. Excluded: changes to code or contracts.

### MSS 1.1 — Domain and assignment inspection

1. Reconfirm objective: locate provider identity and its join key. 2. Inspect: `shared/domain.ts`, `src/types.ts`, and participant-instance design. 3. Intended artifact: this discovery record only. 4. Work: current `OrchestrationProvider` is the closed union `claude_code | codex`; `ProviderAvailability` requires two named keys; `OrchestrationRoleConfig` joins provider to unique role. The dependency replaces the last join with `participantId`. 5. Validation: compared types with validation/default/reconciliation call sites. 6. Result: identity, availability, and assignment are closed independently. 7. Deviation/finding: participant implementation is not present yet; this Task must implement after that approved change and use its final names. 8. Status: complete.

### MSS 1.2 — Desktop and bridge inspection

1. Reconfirm objective: record evidenced detection without generalizing it. 2. Inspect: `electron/main.ts`, `electron/preload.ts`, `src/bridge/electron.ts`, `src/bridge/web.ts`. 3. Intended artifact: detection matrix. 4. Work: Electron runs fixed `claude --version`, then `claude auth status`, accepting JSON `loggedIn: true` plus `authMethod: "claude.ai"`; it runs fixed `codex --version`, then `codex login status`, accepts text containing ChatGPT, and rejects API-key text. W1 cannot spawn or inspect local CLIs and currently returns two false booleans with a desktop-required reason. IPC transports the fixed object without runtime validation. 5. Validation: checked every command/argv and output branch against DEC-002. 6. Result: both supported paths are subscription CLI only. 7. Finding: CLI output is an unstable external interface; unparseable auth output must remain unauthenticated, never optimistic. 8. Status: complete.

### MSS 1.3 — UI and serialization inspection

1. Reconfirm objective: find every consumer-side switch. 2. Inspect: provider state/defaulting/status/options in `src/App.tsx`; YAML in `shared/domain.ts`; relevant fixtures. 3. Intended artifact: behavior-preservation inventory. 4. Work: UI defaults assignments to Claude Code, maps a literal two-item tuple, derives names with a conditional, and merely decorates unauthenticated options with a warning. YAML emits `kind`; Codex alone emits role-derived `sandbox`, Claude alone emits fixed `max_budget_usd: 1.0`. Existing web-export tests cover both adapter branches but no detection matrix. 5. Validation: traced definition to desktop write and W1 ZIP generation. 6. Result: current selection is not availability-gated; adapter-specific fields are another closed branch. 7. Finding: fixed/commented money fields belong to `TASK-FUNDING-BUDGET`; this Task preserves them exactly pending that Task. 8. Status: complete.

### MSS 1.4 — Sprint consolidation

1. Reconfirm objective: stabilize facts before design. 2. Inspect: findings 1.1–1.3 against backlog acceptance and non-goals. 3. Intended artifact: consolidation. 4. Work: six closures require one source: type identity, labels/order/default, host detection metadata/classification, availability shape, selection eligibility, and adapter emission. Privileged spawning must remain host-side. 5. Validation: master boundaries, supplemental §§5/31, current schema. 6. Result: exactly two production descriptors are justified. 7. Deviation: no test-only provider was found in current repository searches; design still specifies a test-only injection seam. 8. Status: complete.

Sprint 1 checkpoint: objective met; all four MSS complete; files changed in Sprint: this design only; focused validation: static trace of all named files; new findings: no current mock descriptor and current unavailable selection is not blocked; residual risk: dependency implementation names may differ; deviations: none material; ready for Sprint 2: yes.

## Sprint 2 — Descriptor and type design

Objective: define one bounded registry and its invariants. Entry: current closures consolidated. Included: pure shared types/registry/helpers. Excluded: provider plug-in loading, runtime discovery, paid API, secrets, and generic command execution.

### MSS 2.1 — Provider descriptor

1. Reconfirm objective: make identity and capability claims explicit. 2. Inspect: current provider union, detector behavior, YAML fields. 3. Intended implementation: new `shared/providerRegistry.ts`; re-exports/call sites in `shared/domain.ts` and `src/types.ts`. 4. Decision:

```ts
export const PROVIDER_IDS = ["claude_code", "codex"] as const;
export type ProviderId = (typeof PROVIDER_IDS)[number];
export type ProviderCapability =
  | "subscription_cli"
  | "desktop_cli_detection"
  | "aekr_adapter_serialization";

export interface ProviderDescriptor {
  readonly id: ProviderId;
  readonly displayName: string;
  readonly capabilities: readonly ProviderCapability[];
  readonly desktopDetection: DesktopCliDetection;
  readonly adapter: AekrAdapterDescriptor;
}
```

`PROVIDER_REGISTRY` is an ordered readonly tuple, Claude Code then Codex; `DEFAULT_PROVIDER_ID` is `claude_code`; a construction-time assertion rejects duplicate IDs. Export `getProviderDescriptor`, `isProviderId`, `listProviderDescriptors`, `providerHasCapability`, and `isSerializableProvider`. `ProviderId` is derived from the literal descriptor IDs rather than maintained separately. Labels are product names, not localized schema identities. Capabilities describe only presently evidenced behavior; no `api`, model, cost-enforcement, generic execution, web detection, or credential capability exists.

The two descriptors are:

- `claude_code`: subscription CLI, desktop CLI detection, AEKR adapter serialization; fixed version/auth probes; adapter kind `claude_code`; current legacy adapter field policy.
- `codex`: the same three capabilities; fixed version/login probes; adapter kind `codex`; current role-derived sandbox policy.

5. Validation: every capability maps to current executable evidence and every current provider behavior maps to one descriptor. 6. Result: extending production support requires one reviewed descriptor plus detector classifier and serializer evidence. 7. Deviation: descriptors are compiled, not user/config/plugin supplied. 8. Status: complete.

### MSS 2.2 — Availability and eligibility types

1. Reconfirm objective: distinguish facts from UI/control policy. 2. Inspect: boolean status and host behavior. 3. Intended implementation: `shared/providerRegistry.ts`, `src/types.ts`. 4. Decision:

```ts
export type ProviderAvailabilityState =
  | "installed_authenticated"
  | "installed_unauthenticated"
  | "not_installed"
  | "unsupported_host";

export interface ProviderAvailabilityResult {
  providerId: ProviderId;
  state: ProviderAvailabilityState;
  reasonCode: ProviderAvailabilityReason;
  detail?: string;
}
export type ProviderAvailability = readonly ProviderAvailabilityResult[];
```

Reasons are stable non-secret codes (`ready`, `cli_not_found`, `not_logged_in`, `unsupported_auth_mode`, `auth_status_unreadable`, `host_cannot_detect`) translated by UI; optional detail is sanitized diagnostic text and never a command suggestion supplied by a provider. `availabilityById(results)` validates known IDs, no duplicates, and exactly one result for every production descriptor; malformed IPC data fails closed.

Availability is a host observation, not persisted project state. Before a check, UI state is `null`/“Not checked”; it is deliberately not a fifth detection result. Selection eligibility is separate: `serializable`, `availability`, and requested action yield `{enabled, status: "available" | "unavailable" | "unsupported" | "disabled", reasonCode}`. “Disabled” means a known descriptor is inapplicable to the requested capability/policy; it is not another installation state. Both production descriptors are serializable. Desktop execution requires `installed_authenticated`; W1 export may serialize either registered provider but labels local detection `unsupported_host` and cannot execute Mode 1. No transient status enters YAML or drafts.

5. Validation: matrix covers every state, null pre-check, malformed/unknown results, export versus execute eligibility. 6. Result: installed, authenticated, unavailable, unsupported, and disabled are not conflated. 7. Finding: execution eligibility must be checked immediately before execution as stale detection can change. 8. Status: complete.

### MSS 2.3 — Test-only injection boundary

1. Reconfirm objective: permit isolated tests without shipping fake support. 2. Inspect: repository search found no mock provider. 3. Intended implementation: tests may build a local registry through an exported pure `validateProviderRegistry(descriptors)` helper or test factory under `tests/helpers/`; production exports only `PROVIDER_REGISTRY`. 4. Decision: no production `mock` ID, descriptor, label, option, bridge result, or serializer branch. Tests needing an artificial incapable descriptor define it inside the test module and pass it only to pure helpers accepting an explicit registry. Production helpers default to the closed compiled registry and no environment/build flag can enable the fixture. 5. Validation: planned bundle/source search asserts mock identity absent outside tests; production registry exact-ID test. 6. Result: negative capability cases are testable without a reachable fake provider. 7. Deviation: none. 8. Status: complete.

### MSS 2.4 — Sprint consolidation

The registry is intentionally compiled and small. Provider identity is derived from the descriptor tuple; capabilities are evidence claims; availability is runtime host evidence; eligibility is action policy; assignment stores only `providerId`. This avoids treating descriptor presence as executable support.

Sprint 2 checkpoint: objective met; four MSS complete; intended implementation files: `shared/providerRegistry.ts`, `shared/domain.ts`, `src/types.ts`, tests; validation: type/invariant and state-matrix design review; new findings: pre-check is UI absence, not an availability enum; residual risk: over-generalization controlled by compiled descriptors; deviations: none; ready for Sprint 3: yes.

## Sprint 3 — Detection and availability per host

Objective: centralize fixed detection specifications/classification while preserving the privileged boundary and DEC-002. Entry: descriptor/state model stable. Included: Electron/W1 check behavior and IPC validation. Excluded: running provider work, login flows, installation, credentials, shell strings.

### MSS 3.1 — Desktop fixed-probe design

1. Reconfirm objective: migrate detection without behavior change. 2. Inspect: `runCapture`, `checkClaudeCode`, `checkCodex`, IPC. 3. Intended implementation: pure specs/classifiers in `shared/providerRegistry.ts`; process execution in `electron/main.ts`; focused detector tests. 4. Decision: `DesktopCliDetection` contains readonly `versionProbe` and `authProbe`, each `{ executable, argv }`, plus a classifier ID/function owned in shared code. Values are compile-time literals only:

- Claude: `claude ["--version"]`; `claude ["auth", "status"]`; parse combined auth output as JSON; ready only for `loggedIn === true && authMethod === "claude.ai"`.
- Codex: `codex ["--version"]`; `codex ["login", "status"]`; auth command must exit zero; reject normalized `api key`/`apikey`; ready only when text contains `chatgpt`.

Electron iterates `PROVIDER_REGISTRY`, executes each descriptor's probes concurrently through a renamed diagnostic-only fixed-argv helper, and calls its pure classifier. The runner accepts only a `ProviderDescriptor` from the compiled registry, never an arbitrary command/argv IPC argument. `cwd` remains `app.getPath("home")`; no shell option is enabled; user/provider output is data only. A probe spawn error/nonzero version is `not_installed`; installed plus failed/unparseable/disallowed auth is `installed_unauthenticated`. Detection never throws the whole check.

5. Validation: exact argv assertions, output fixtures for all current branches, shell metacharacter fixture treated as output, unknown provider rejected before spawn. 6. Result: behavior retained through data-driven iteration. 7. Finding: classifier matching remains necessarily vendor-output-specific and must be regression tested when CLIs change. 8. Status: complete.

### MSS 3.2 — W1 design

1. Reconfirm objective: state inherent browser limits without making providers fake/unselectable for artifact preparation. 2. Inspect: W1 bridge and export behavior. 3. Intended implementation: `src/bridge/web.ts`, shared helper/tests. 4. Decision: W1 maps every compiled descriptor to `unsupported_host`/`host_cannot_detect`. Copy: “This browser cannot check local CLI installation or sign-in. Export is still available; verify the provider in the desktop app before running Mode 1.” It does not report “not installed” or “unauthenticated,” because neither fact is observable. W1 can select registered, serializable providers for deterministic YAML export; W1 cannot launch Mode 1, and no “available” execution claim is shown. 5. Validation: exact registry coverage and negative assertions against installed/authenticated claims. 6. Result: host inability and provider availability are honestly separated. 7. Deviation: current button is disabled in W1; later UI consumes immediate registry-generated unsupported results rather than asking users to click it. 8. Status: complete.

### MSS 3.3 — IPC boundary and freshness

1. Reconfirm objective: keep bridge narrow and results trustworthy. 2. Inspect: preload/electron/web bridge types. 3. Intended implementation: `electron/preload.ts` API name unchanged; `src/bridge/electron.ts` forwarding unchanged; result types updated in `src/types.ts`; main/UI validation added. 4. Decision: retain `checkProviders()` and `providers:check`; change only payload shape to the validated result array. Preload exposes no command inputs. Electron always returns a complete ordered result. Renderer validates IDs/completeness and replaces the prior snapshot atomically; on malformed/rejected results show a provider-check error and retain no optimistic availability. Do not persist results. On configuration open they are “Not checked”; check again before any desktop Mode 1 start, since installation/auth can change. 5. Validation: bridge contract tests for exact complete result, malformed/duplicate/unknown/missing IDs, and rejected IPC. 6. Result: no new privileged surface. 7. Deviation: actual execution-preflight integration may touch the Orchestration Center and must remain a capability check, not provider execution redesign. 8. Status: complete.

### MSS 3.4 — Sprint consolidation

Desktop detection is registry-iterated but not generic: executable and argv are compiled, immutable, and unreachable from user/IPC input. W1 yields `unsupported_host`, not false local facts. IPC remains inputless and availability is ephemeral/freshness-sensitive.

Sprint 3 checkpoint: objective met; four MSS complete; intended files: shared registry, Electron main, bridge types/web bridge and detector/bridge tests; focused validation: command matrix and trust-boundary review; new findings: execution needs a fresh recheck; residual risks: vendor output drift and TOCTOU after check; deviations: no provider execution changes; ready for Sprint 4: yes.

## Sprint 4 — UI consumption design

Objective: make provider selection/status honest and registry-driven while staying within the existing UI pending `TASK-UX-MODE1`. Entry: registry and host status settled. Included: selection, status, errors, accessibility, and visual constraints. Excluded: dialog layout redesign or new theme tokens.

### MSS 4.1 — UX decision A: choose a provider per participant

1. Reconfirm objective: attach a proven provider descriptor to each stable participant instance. 2. Inspect: current select/status/default/reconciliation and dependency design. 3. Intended implementation: provider area in `src/App.tsx`, pure eligibility helpers, component tests. 4. Decision and supplemental §6 answers: (1) User goal: choose the local CLI adapter intended for each participant. (2) Required: participant identity and one registered provider. (3) Optional: none in this Task; auth details are status, not configuration. (4) Happy path: review descriptor options, choose, check desktop availability, save/export. (5) Failures: unknown legacy ID, missing descriptor, unavailable auth/install, unsupported host detection, stale/failed check, or incapable serializer. (6) Errors name provider and actionable stable reason; they never claim a browser checked the machine. (7) All selections/tasks remain intact after check or validation failure. (8) Selected value and per-provider status summary confirm configuration; desktop execution gets a fresh successful preflight. (9) one participant row has one select; save does not reassign/default over an existing valid choice. (10) Narrow layouts stack label, select, and status with no horizontal clipping/nested scroll. (11) Native labeled select is keyboard operable; status updates use a polite live region without moving focus. (12) Text plus icon distinguishes Available, Not installed, Sign-in required/unsupported auth, Not checked, Unsupported in browser, and Disabled for this action. (13) Primary UI says provider/local CLI, not registry, classifier, adapter-map, or IPC. (14) `participant`, `provider`, and `Mode 1` match artifacts; provider product names remain Claude Code/Codex. (15) Desktop/W1 share options and serialization; only detection/execution copy differs.

Render options by `listProviderDescriptors().filter(isSerializableProvider)`, never a literal provider tuple. Default only newly created assignment to `DEFAULT_PROVIDER_ID`. Look up/update by `participantId`, never role. Unknown stored provider IDs are not silently coerced: preserve the raw draft through migration diagnostics, block save/export, and ask the user to choose a supported provider. Configuration options stay selectable before detection and in W1 because this surface prepares an artifact; an actually incapable/nonserializable descriptor would render disabled only in diagnostics, never as a selectable production option. Desktop start is blocked unless every assigned provider currently reports `installed_authenticated`; W1 has no start action.

5. Validation: 1/6 participants, repeated roles with distinct choices, role edit/reorder stability, status/error recovery, keyboard, narrow/200% zoom. 6. Result: selection is honest without making installation detection a prerequisite for offline drafting. 7. Deviation: full dialog save/cancel mechanics belong to `TASK-UX-MODE1`. 8. Status: complete.

### MSS 4.2 — UX decision B: check and understand availability

1. Reconfirm objective: expose system status and recovery. 2. Inspect: current check button/list and host branch. 3. Intended implementation: `src/App.tsx` status list and copy. 4. Decision and §6 answers: (1) Goal: know whether assigned local CLIs can run. (2) Required: host, provider name, result state/reason, check time for this UI session. (3) Optional: sanitized diagnostic detail behind disclosure. (4) Happy path: desktop Check providers returns one row per descriptor and assigned providers are Available. (5) Failures: not installed, unauthenticated/disallowed auth, unreadable status, IPC failure, or browser inability. (6) Each row explains fact and recovery: install outside accreatio, use the provider's subscription login command, retry check, or verify in desktop. No accreatio login/install button. (7) Check failure preserves project input and previous assignment; stale result is removed/marked failed. (8) “Checked just now” plus explicit rows confirms completion; only ready state uses success semantics. (9) button disables while checking; repeated later checks remain legitimate. (10) Rows wrap/stack and details do not force width. (11) Button/status/disclosure are keyboard reachable; `aria-busy`, polite live update, and text labels accompany icons. (12) Unsupported host, unavailable provider, disabled action, and not-yet-checked are separate. (13) Commands may be offered as documentation text but no schema/classifier internals appear. (14) vocabulary matches provider support documentation. (15) W1 immediately explains browser inability and does not show a nonfunctional check action; desktop shows the action.

5. Validation: state/host matrix, screen-reader text, retry and failure preservation. 6. Result: status is actionable and non-deceptive. 7. Deviation: localized copy must be added in both current inline locale branches or the approved localization mechanism; no English-only fallback for status semantics. 8. Status: complete.

### MSS 4.3 — Visual and complete UX acceptance

1. Reconfirm objective: ensure registry status does not become a visual afterthought. 2. Inspect: supplemental §§30–31 and dependency/theme ownership. 3. Intended implementation: consume approved semantic theme/control/status tokens; no new palette. 4. Decision: provider rows use neutral working surfaces; selected controls use the theme system; status always combines icon, short text, and optional detail, never purple/color alone. Success/warning/danger/information tokens retain semantic differentiation. Default/hover/focus/selected/disabled states must be visible in both themes; focus ring is unmistakable. Six participant assignments use the dialog/page's single scroll container, wrap at narrow widths/200% zoom, and introduce no nested provider/status scrollbar. No galactic imagery, glow, or motion is added; reduced-motion therefore has no new animation. Desktop/W1 use identical component styling and ordered descriptors. This directly meets §30 items 2, 4–15; brand palettes/token mapping (1, 3, 16) are consumed from `TASK-DESIGN-THEME`. It meets §31 items 1–5, 8–12, 17–20 for this scope. Funding, attachment, idempotency, output-evidence, and full dialog criteria remain owned by their Tasks. 5. Validation: manual matrix desktop/W1, dark/light, default/hover/focus/selected/disabled, 1/6 participants, narrow supported widths, 200% zoom, keyboard/screen reader, reduced motion. 6. Result: visual semantics reinforce availability distinctions. 7. Deviation: no pixel/token values redefined here. 8. Status: complete.

### MSS 4.4 — Sprint consolidation

Provider configuration is per participant ID and registry-rendered. Offline/W1 artifact preparation remains possible; desktop execution requires fresh ready results. Unknown or incapable providers fail visibly without destroying input. Both UX decisions answer all 15 questions, and visual/UX acceptance is allocated without stealing dependent Task scope.

Sprint 4 checkpoint: objective met; four MSS complete; intended files: App/provider components/tests; focused validation: §§5/6/30/31 cross-check and scenario matrix; new findings: current UI needs separate configuration versus execution eligibility; residual risk: later dialog integration; deviations: dialog structure deferred; ready for Sprint 5: yes.

## Sprint 5 — Serialization and YAML design

Objective: use the same descriptor source for validation and exact current adapter output. Entry: assignment/eligibility stable. Included: migration, validation, adapter serialization, AEKR boundary. Excluded: funding redesign and invented upstream fields.

### MSS 5.1 — Assignment migration and validation

1. Reconfirm objective: preserve Claude/Codex choices through participant migration. 2. Inspect: current drafts/defaults, participant Task migration, validation. 3. Intended implementation: `shared/domain.ts`, `src/draftStore.ts`, focused migration tests. 4. Decision: the participant Task's role-to-participant migration copies each legacy `provider` byte-for-byte into `providerId` on the matched participant configuration; missing provider defaults to `DEFAULT_PROVIDER_ID` exactly as current initialization does. Valid `claude_code` and `codex` require no semantic version migration beyond the field rename. New/current validation requires `isProviderId`, descriptor capability `aekr_adapter_serialization`, one config per participant ID, and the dependency Task's AEKR compatibility guard. Unknown/removed IDs produce a visible migration warning and block Mode 1 save/export; they are never mapped to Claude silently. Availability is not persisted and does not make a deterministic definition structurally invalid; execution preflight handles runtime readiness. 5. Validation: literal legacy fixtures for each provider and mixed participants, missing/unknown IDs, reload stability, role change/reorder. 6. Result: existing valid choices are lossless. 7. Deviation: final draft schema version/order follows the participant implementation; this Task must not independently bump it again unless its approved migration requires a distinct envelope change. 8. Status: complete.

### MSS 5.2 — Descriptor-owned adapter serialization

1. Reconfirm objective: remove provider switches while preserving byte behavior. 2. Inspect: current `renderOrchestrationConfig`. 3. Intended implementation: serializer helpers in `shared/providerRegistry.ts`; orchestration loop in `shared/domain.ts`; exact fixtures. 4. Decision: `serializeAekrAdapter(descriptor, context)` returns ordered YAML data lines for one adapter after shared code writes the participant/role mapping key. It accepts only trusted domain context (`canonicalRole`, later funding policy), not arbitrary YAML keys or commands. Current policies are exact:

- Claude Code: `kind: claude_code`, then `max_budget_usd: 1.0` until `TASK-FUNDING-BUDGET` reconciles it.
- Codex: `kind: codex`, then `sandbox: workspace-write` only for Implementer; otherwise `sandbox: read-only`.

The registry validates that every production descriptor with serialization capability has a serializer and that emitted `kind` equals its evidenced AEKR adapter kind. Shared generation retrieves the descriptor by `providerId`; lookup/capability failure throws a typed generation error before any desktop write or W1 ZIP assembly. It does not accept extension fields or spread descriptor data into YAML. Provider labels/detection/capabilities are never serialized. Only current AEKR-supported fields appear.

The participant dependency's compatibility behavior remains: unique-role 1–4 emits current role-keyed mappings (plus any approved identity comments); repeated-role/5–6 fails before serialization. A future participant-keyed AEKR schema requires separate upstream approval/evidence, not a registry toggle.

5. Validation: exact golden YAML for Claude, Codex Implementer/non-Implementer, mixed legacy set; negative unknown/incapable descriptor; YAML contains no status/detection/label/spec data. 6. Result: serializer selection is descriptor-driven and output-compatible. 7. Finding: funding Task will deliberately revise Claude money fields later; its design must change the descriptor serializer contract rather than add a new switch. 8. Status: complete.

### MSS 5.3 — Extension contract and security

1. Reconfirm objective: define what “extensible” honestly requires. 2. Inspect: backlog evidence/security criteria and DEC-002. 3. Intended documentation: new provider support matrix/extension contract under `docs/`, security/FAQ/change-control updates during implementation. 4. Decision: adding production provider support requires all of: stable safe ID; product label; explicit evidenced capabilities; compiled fixed executable/argv; deterministic fail-closed auth classifier for an allowed auth mode; evidenced AEKR adapter kind/fields against the consumed schema; serializer golden fixtures; desktop/W1 state matrix; UI copy/accessibility; threat review proving no user/provider text reaches spawn; migration decision; and Orchestrator/owner approval. Absence of any element means no production descriptor/option. No dynamic manifests, PATH downloads, provider-contributed JS, credential fields, secret persistence, API calls, telemetry, shell, command interpolation, or automatic fallback. CLI output is untrusted data: bound captured output length in the detector implementation, do not log raw auth output by default, and expose only stable reason plus sanitized bounded detail. 5. Validation: security checklist and negative source/bundle search. 6. Result: extension is a controlled code change, not an unsafe plugin system. 7. Deviation: output-length bound is a security hardening that should preserve normal behavior; if current helper is shared with unrelated commands, scope the bound to provider diagnostics. 8. Status: complete.

### MSS 5.4 — Sprint consolidation

Legacy assignments migrate losslessly onto participant IDs. Structural validation uses registry identity/capabilities; ephemeral availability gates execution, not saved artifacts. Descriptor-owned serializers reproduce only current AEKR fields. The existing upstream participant-key gap remains explicit.

Sprint 5 checkpoint: objective met; four MSS complete; intended files: shared registry/domain, draft store, YAML/migration tests, docs; focused validation: migration and golden-output design plus security review; new findings: funding must later revise serializer policy centrally; residual risk: upstream schema drift; deviations: bounded diagnostic output proposed as proportional hardening; ready for Sprint 6: yes.

## Sprint 6 — Verification and delivery plan

Objective: provide an implementation order and evidence package with no undocumented choices. Entry: all prior consolidations stable. Included: exact file plan, tests, documentation, risks, rollback. Excluded: implementation in this pass.

### MSS 6.1 — Exact file-level implementation order

1. Reconfirm objective: give Participant C reviewable atomic changes. 2. Inspect: architecture and supplemental §14 order. 3. Intended artifact: this sequence. 4. Decision:

1. Create `shared/providerRegistry.ts`: types, exact two descriptors, invariant helpers, pure auth classifiers, state/eligibility helpers, adapter serializers. No Node/Electron import.
2. Update `shared/domain.ts`: import/re-export `ProviderId`; rename assignment field per participant design; validate through registry; default through `DEFAULT_PROVIDER_ID`; replace YAML provider switch with serializer lookup. Preserve participant compatibility guard and existing YAML bytes.
3. Update `src/types.ts`: re-export new descriptor/status types and update bridge return types; remove old boolean status exports after all callers migrate.
4. Add focused tests, preferably `tests/providerRegistry.test.ts`: registry invariants, exact production IDs/order/default/capabilities, classifiers/state matrix, eligibility, fixed specs, serializers, unknown/incapable/test-only cases, and no mock in production registry.
5. Update `src/draftStore.ts` only as needed to compose with the participant migration and preserve/diagnose provider IDs; extend `tests/draftStore.test.ts` with both-provider/mixed/unknown fixtures.
6. Update `electron/main.ts`: replace provider-specific functions with descriptor iteration and fixed-probe runner; bound/sanitize diagnostics; validate complete results. Do not change generic orchestration execution. If testability requires extraction of privileged orchestration-free code, create `electron/providerDetection.ts` and record the Project Map boundary.
7. Keep `electron/preload.ts` method/input unchanged; update type inference/declarations only. Keep `src/bridge/electron.ts` forwarding unchanged. Update `src/bridge/web.ts` to registry-map `unsupported_host` results. Extend `tests/bridge.test.ts` for host contract.
8. Update provider UI/state in `src/App.tsx`: render descriptors, join by `participantId`, translate reason codes, separate configuration/export from execution eligibility, preserve input, accessible status. Do not perform the later Mode 1 layout redesign. Add/extract a provider component only if the approved Mode 1 design already establishes that boundary; otherwise keep bounded changes in App.
9. Update `tests/core.test.ts`/`tests/webExport.test.ts`: validation, legacy Claude/Codex byte compatibility, mixed adapters, participant-key behavior, dependency fail-closed cases, negative unknown provider, desktop/W1 shared serialization.
10. Update provider extension/support documentation, security docs, `docs/FAQ.md`, `CHANGE_CONTROL.md`, and `DECISIONS.md` for a durable compiled-registry decision. Update Project Map only if `shared/providerRegistry.ts` or an Electron detector module changes documented boundaries. Do not clean unrelated stale guidance.

5. Validation: sequence follows contracts → validation/tests → migration → host → UI → integration → docs and keeps atomic type changes tightly coupled where compilation requires. 6. Result: no implementer policy choice remains. 7. Deviation: participant Task must land first; adapt names, not semantics, if its approved implementation differs. 8. Status: complete.

### MSS 6.2 — Focused/integrated/regression verification

1. Reconfirm objective: define acceptance evidence. 2. Inspect: backlog evidence, package scripts, current tests. 3. Intended artifacts: implementation/Test Engineer evidence. 4. Plan:

- Registry: exact two production descriptors; unique safe IDs; derived type; default; every claimed capability has implementation; artificial test descriptor never appears in production registry/bundle/UI.
- Detection: exact executable/argv; Claude ready/wrong auth/logged out/bad JSON/not found; Codex ChatGPT/API key/unknown/nonzero/not found; spawn error isolation; bounded hostile output; no shell; no user text in command/cwd/argv.
- Availability: all four result states; null Not checked; complete/duplicate/missing/unknown IPC; desktop versus W1; unavailable/unsupported/disabled language and action eligibility.
- Assignment/migration: Claude, Codex, mixed; stable per participant across repeated roles, role change/reorder; missing/unknown; no silent fallback; participant Task compatible and incompatible AEKR topologies.
- Serialization: byte/golden fixtures for both current adapters, Codex sandbox by canonical role, Claude current budget field, only supported AEKR fields, deterministic desktop/W1 parity, fail before partial artifact on unknown/incapable provider.
- UX/manual: desktop/W1, dark/light, 1/6 and repeated roles, check/retry/errors, input preservation, keyboard/screen reader, narrow widths, 200% zoom, status states and fresh execution preflight; no fake W1 detection/execution.
- Integrated Task: configure each existing provider, desktop status check, save/reopen, generate compatible YAML, inspect actual adapter fields; verify W1 exports same YAML while saying detection unsupported.
- High-level regression: Mode 0, dry-run, one desktop generation, one W1 ZIP, theme/locale, settings/history, validation, participant migration, Project Map integrity.
- Commands during implementation: focused Node test targets after each MSS; then `npm test`, `npm run typecheck`, `npm run format:check`, `npm run build`. Packaged smoke and prohibited functional commands belong only to the authorized Test Engineer phase.

5. Design validation: cross-checked with backlog required evidence and supplemental §§21–26. 6. Result: focused, integrated, manual, security, and regression evidence are distinct. 7. Deviation: no commands run in this design pass; Orchestrator baseline remains 41/41 and clean typecheck. 8. Status: complete.

### MSS 6.3 — Risks, rollback, dependencies, and gate

1. Reconfirm objective: close the implementation contract honestly. 2. Inspect: task risks and dependent designs. 3. Intended artifact: final handoff. 4. Decision: risks are CLI output drift, stale availability, abstraction implying unsupported providers, malformed IPC, migration fallback, AEKR field drift, and provider output leakage. Mitigations are fail-closed classifiers, fresh execution check, compiled exact registry, result validation, lossless/error-visible migration, golden fixtures, bounded/sanitized diagnostics, and no shell/credentials. Rollback is the complete provider-registry Task checkpoint; do not partially revert descriptor consumers to parallel switches or downgrade drafts silently. Downstream `TASK-FUNDING-BUDGET` extends capability/serializer policy centrally; `TASK-UX-MODE1` consumes provider components/status vocabulary. No specialist activation is justified. 5. Validation: master/supplemental/backlog/dependency cross-check. 6. Result: design is ready for Orchestrator consistency review and design-gate packaging, subject to the already-open upstream participant contract disposition. 7. Deviation: none. 8. Status: complete.

Sprint 6 checkpoint: objective met; three MSS complete; files changed in this design pass: only this new record; focused validation: complete mandate/schema/security/test cross-check; new findings: none beyond documented upstream dependency; residual risks: vendor CLI and AEKR drift; deviations: none; ready for design-gate packaging: yes.

## Implementation contract summary

Domain/schema impact: compiled `ProviderId`/descriptor registry; four-state ephemeral availability results; participant configs store `providerId`; status is not serialized; unknown IDs fail visibly. Migration impact: current Claude/Codex assignments copy losslessly onto participant IDs; missing legacy values retain Claude default; unknown values never silently coerce. Security impact: fixed compiled executable/argv only, no shell or IPC command input, bounded untrusted output, no raw auth logging, credential storage, downloads, network/API, or provider code loading. UX impact: registry-rendered options/status, exact host distinctions, preserved input, accessible keyboard/responsive semantics, and fresh desktop execution readiness. Serialization impact: descriptor-owned exact current adapter fields only; current compatible AEKR YAML preserved; expanded participant topology remains blocked. Test impact: invariant, classifier, state, bridge, migration, serialization, UX, security, integrated, and regression evidence specified above.

## AEKR upstream gap and open questions

AEKR upstream gap found: yes, inherited and reconfirmed from `TASK-PARTICIPANT-INSTANCES`. The current consumed role-keyed `adapters` map cannot bind different providers to repeated-role participant instances or represent 5–6 participants safely. This Task must not invent aliases or a participant-keyed schema. No additional provider-registry-specific upstream change is required for the two existing providers in compatible unique-role 1–4 configurations.

Open questions for Orchestrator/owner:

1. Resolve the participant Task's existing upstream decision: authorize a separate AEKR participant-keyed contract investigation/change, or approve the documented fail-closed expanded-Mode-1 limitation.
2. Confirm that provider availability is required to gate desktop Mode 1 start, while offline desktop/W1 configuration and deterministic YAML export remain allowed with explicit unverified/unsupported-host status. This is the recommended separation because W1 cannot truthfully detect local CLIs.

## Design-gate handoff

Task: `TASK-PROVIDER-REGISTRY`. Sprints designed/completed: six. Production providers represented: Claude Code subscription CLI and Codex ChatGPT subscription CLI only. User-visible result after implementation: provider assignment per participant, registry-driven names/options/status, honest desktop/W1 differences, and no unsupported execution. Contracts affected: provider identity, availability bridge payload, participant orchestration assignment, adapter serializer dispatch. Known limitation: current AEKR participant/adapter keying. Documentation and verification impacts are explicit above. No production file was modified.
