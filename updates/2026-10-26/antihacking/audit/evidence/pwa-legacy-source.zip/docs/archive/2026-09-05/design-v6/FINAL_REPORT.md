# Semantic Typography, Expanded Motion, and Protected W1 Beta

Owner authorization: Ed Lopez, 2026-08-06. Baseline: `c28036f0e8a6e208a4047c068798ff70a1677726` on `main`.

Implementation commit: `cc377af0525fc58abac1c6c04e0f94d706203fb2`.
Audited release-preparation commit: `cedd0230857a4d9abb295cf417e2777de2ba309c`.
Applicable AEKR commit: `d872514719520735f19fa107d87f7ba3e18f4b9d`.

## Outcome

The application, legal pages, and self-contained Project Map now share the owner-supplied semantic typography contract: Posterama for the mark/H1/H2, Inter at explicit 400/500/600 roles for body and UI, and JetBrains Mono for technical content. The named font binaries are not present or licensed for embedding, so the build makes no remote request and uses the declared generic fallbacks when those local families are unavailable. It does not claim pixel-identical Posterama rendering.

Motion changed exactly from design v5:

- star autonomous drift and pointer parallax trajectory: `×1.35`;
- nebula pointer trajectory: `×1.25`;
- star and nebula autonomous speed: `×1.15`.

Reduced-motion, save-data, slow-update, hidden-page, missing/lost-WebGL, coarse-pointer, 30 fps, DPR, density, and no-pointer-interception contracts remain intact. The light-theme instrument-token CI regression was also corrected.

Release preparation now describes a zero-cost private beta rather than an anonymous public launch. Cloudflare Access must protect the empty `accreatio` Pages project and fail closed before any asset is uploaded. `noindex` is applied as defense in depth, legal/privacy copy discloses Cloudflare Pages/Access accurately, and no custom domain, backend, analytics, upload, telemetry, paid service, or public-use license is inferred.

The three official GitHub workflow actions moved from `v4` to their current `v7` Node 24 runtimes, removing the Node 20 deprecation warning that appeared in earlier CI emails.

## Verification

- Full local gate: 183/183 tests plus Project Map parity, typecheck, Prettier, production build, Electron execution smoke, Project Map file smoke, W1 browser smoke, and Lighthouse.
- Lighthouse: 92 performance, 100 accessibility, 100 best practices, and 66 SEO. The only weighted SEO failure is the intentional private-beta `is-crawlable` result; all other weighted SEO audits remain gated.
- Dependency audit: zero vulnerabilities.
- Build evidence: application CSS 68.14 kB; main application JS 351.78 kB; Vanta chunk 12.37 kB; Three chunk 724.20 kB. The existing >500 kB Three warning remains visible and tracked.
- Visual/computed-style inspection covered dark/light Home, creation, About wide/narrow, Project Map, reduced motion, pointer movement, and representative 760 px split layout. No horizontal overflow or unexpected egress was observed.
- GitHub Actions run `31067618206` passed on Windows for `cedd023` using `actions/*@v7`, without the previous Node 20 runtime warning.
- A later documentation-only CI run exposed a nondeterministic PNG screenshot hash for the static reduced-motion star canvas. Codex replaced that compositor-dependent evidence with a SHA-256 fingerprint of the canvas pixel buffer; the smoke then passed three consecutive local runs. No application code changed.

## Independent audit

Claude Code 2.1.222 reviewed the full pushed repository at `cedd023` and applicable AEKR guidance at `d872514` from a fresh read-only context. Verdict: **PASS_WITH_NON_BLOCKING_OBSERVATIONS**, with no Blocker or Major.

Its sole Minor was the missing design-v6 change-control entry; Codex added that documentation after the audit without changing code. The only Observation was that `npm audit` remains a manual release gate. See [CLAUDE_AUDIT_REPORT.md](CLAUDE_AUDIT_REPORT.md).

## Data, security, cost, and limits

No schema, draft, attachment, business-flow, IPC, filesystem/Git execution, credential, provider, Mode 1, or desktop-packaging behavior changed. Runtime monetary cost remains USD zero. App content stays local; only Cloudflare's external access/request metadata exists for the protected origin.

Open limits remain explicit: the actual Posterama/Inter/JetBrains binaries are not bundled, Three remains a large lazy chunk, formal legal/trademark review and a deliberate public-use license remain required before anonymous access, and the Cloudflare Access/deploy checks are external gates rather than completed repository evidence.

## Rollback and deployment state

Source rollback returns to `c28036f0e8a6e208a4047c068798ff70a1677726`; no data migration is needed. For the first hosted beta, rollback is to disable the Pages project. Later deployments may restore the last known-good release.

At the time of the independent audit, repository gates were green and the protected Cloudflare deployment remained pending. Live URL, deployment ID, authenticated/fail-closed evidence, and post-deploy results must be appended only after they exist.

## Post-audit deployment addendum — 2026-08-06

After the independent audit and the documented post-audit test stabilization, commit `39ea088175e69430fa9f2539681ea978b264675d` passed GitHub Actions run `31068902888`. Cloudflare Pages production deployment `5e1ab5c8-67ca-4c4f-a574-990ad34fa973` then completed successfully by Direct Upload at `https://accreatio.pages.dev` with immutable origin `https://5e1ab5c8.accreatio.pages.dev`.

Cloudflare Access now uses separate exact-production and wildcard-preview applications. Each has one precedence-1 Allow policy for only `edlopezpm@gmail.com`; anonymous probes of both deployed origins returned HTTP `302` to Access. No new asset was uploaded until the exact production gate had propagated and returned `302`. No Git integration, custom domain, DNS change, Worker, Function, KV, analytics, backend, telemetry, paid capability, deploy token, or committed secret was introduced.

This addendum records external deployment facts and does not alter the historical audit verdict. Owner-authenticated hosted UX, response-header, offline, network-egress, and Lighthouse acceptance remains pending in `docs/W1_RELEASE_READINESS.md`.
