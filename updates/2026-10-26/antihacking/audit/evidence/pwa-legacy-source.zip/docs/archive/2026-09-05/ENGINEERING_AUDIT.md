# Engineering Audit

*Authored by Claude (AI assistant), under authorization from Ed Lopez.*

## Audit — 2026-08-02 (v0.4.1, commit `03af351`)

**Status:** Findings recorded 2026-08-02 against commit `03af351`. Verdict: `PASS_WITH_OBSERVATIONS`. A same-day remediation pass (v0.5.0, uncommitted at time of writing) addressed most findings — see the per-finding **Status (v0.5.0)** lines below and `docs/archive/2026-09-05/AUDIT_REMEDIATION_2026-08-02.md` for the full remediation log. Those per-finding statuses reflect the remediation doc's own claims, cross-checked here only by re-running `npm test` (14/14 passing) and `npm run typecheck` (clean) — not a full independent re-audit of each fix.

### Scope and methodology

Static, read-only review of the full repository at commit `03af351` (main, clean working tree): all source (`electron/`, `src/`, `tests/`), build/config (`package.json`, `tsconfig*.json`, `vite.config.ts`), and every governance document (`AGENTS.md`, `DECISIONS.md`, `RISKS.md`, `CHANGE_CONTROL.md`, `docs/archive/2026-09-05/PROJECT_DISCOVERY.md`, `THIRD_PARTY_NOTICES.md`, `docs/*.md`). No files were modified during the audit itself. Verification commands run: `git log`, `git status`, `npm audit --json` (live, against the committed lockfile), and a direct read of resolved dependency versions out of `package-lock.json`.

Severity vocabulary and verdict format (`BLOCKER`/`MAJOR`/`MINOR`/`OBSERVATION`, `PASS`/`PASS_WITH_OBSERVATIONS`/`FAIL`) are taken from the sibling AI Engineering Knowledge Repo's `toolkit/project-scaffolds/docs-governance/audit-checklist-template.md`.

**Not in scope:** public/web/SaaS release readiness (already gated separately by `docs/WEB_STRATEGY.md` Phase W3), trademark/legal clearance (DEC-008), accessibility/threat-model/SBOM audits (already named as deferred gates), dynamic/runtime penetration testing.

### Independence note

This project's own governance reference (`toolkit/governance-templates/PLANNED_AGENT_CHECK.md` in the AI Engineering Knowledge Repo) is explicit: "never describe the design author's self-review as an independent Audit." The codebase, its documentation style, and its own governance files indicate accreatio was built in close collaboration with an AI assistant across all five releases. This audit is an AI-assisted review of substantially AI-authored work, run at full rigor — not the fresh-session/subagent/human-reviewer independent pass the project's own audit-checklist template calls for. Treat it as a strong first pass, not a substitute for that second, genuinely independent read. The same caveat applies, doubly, to the same-day remediation this document now annotates — see PROC-2.

### Executive summary

No blocking defects for accreatio's current, explicitly scoped role: a private, local-first, single/small-authorized-user desktop MVP. Four findings were worth fixing before the next release; none compromised the app's actual users at the time.

**0 Blocker · 4 Major · 6 Minor · 9 Observation** (19 total).

**Post-remediation disposition (v0.5.0, same day):** 13 Remediated · 3 Accepted · 2 Deferred · 1 not applicable (a positive observation, never a defect). Detail per finding below.

accreatio is a small, unusually well-governed Electron app: a five-release-old project with a real decision log, a real risk register, and Electron's hardening trio (context isolation, sandbox, no Node integration) correctly wired and verified in code, not merely claimed in docs. The gaps found were concentrated where small, fast-moving solo projects tend to accumulate them: one safety invariant enforced in one code path but not its sibling, domain logic copy-pasted across a process boundary instead of shared, an execution path with real side effects that only manual testing ever touched, and a dependency manifest that said `"latest"` everywhere instead of committing to versions.

### System overview

Windows-first Electron + React + TypeScript desktop app: turns a structured project definition into a canonical prompt, a deterministic action preview, and a safe first filesystem/Git(+optional GitHub) step — the bootstrap companion to the AI Engineering Knowledge Repo toolkit.

```text
src/App.tsx             React UI — web-reusable, no Node access
  ↓ imports
src/core.ts              Pure domain logic — validation, prompt generation, action planning (fully unit-tested)
  ↓ narrow typed IPC (8 methods)
electron/preload.ts       contextBridge — the only crossing point of the trust boundary
  ↓
electron/main.ts          Privileged process — filesystem, Git, GitHub CLI, settings, dialogs, history
  ↓
Local filesystem · git · gh CLI · OS credential store   (no network egress except explicit, user-triggered GitHub CLI calls)
```

| Component | Resolved version | Role |
|---|---|---|
| Electron | 43.2.0 | Desktop shell / privileged process |
| React | 19.2.8 | Renderer UI |
| Vite | 8.2.0 | Renderer build/dev server |
| TypeScript | 7.0.2 | Type checking, both processes |
| electron-builder | 26.15.3 | Portable Windows packaging |

Versions confirmed directly from the committed `package-lock.json` at the time of the audit, not from `package.json`'s `"latest"` tags (see DEP-1 below — since remediated).

### Findings

#### Security & trust boundary

**SEC-1 — Major.** Attachment copies bypass the exclusive-write guarantee the rest of the app enforces.
*Where:* `electron/main.ts:24` (contrast with the correct pattern at `electron/main.ts:14`).
Every generated text file goes through `writeVersioned()`, which opens the target with Node's `wx` flag — an atomic, kernel-enforced "fail if it already exists" guarantee. The attachment-copy loop instead calls `fs.copyFile(a.path, target)` with no `COPYFILE_EXCL` flag, after a separate, non-atomic `existsSync` scan in `versionedPath()` picked the name.
*Why it matters:* README.md states "existing targets are augmented with versioned filenames; never overwritten," and DEC-003/DEC-006 assert the same as a hard design decision. That guarantee was true for every generated document but not for copied discovery attachments. The race window is narrow, so this was not an easily-triggered bug — but it was a real, checkable gap between a documented absolute guarantee and what the code enforced.
*Recommendation:* pass `fs.constants.COPYFILE_EXCL` as `copyFile`'s third argument, and on `EEXIST` retry against the next versioned candidate — mirroring the retry-safe pattern `writeVersioned` already used correctly.
*Status (v0.5.0):* Remediated — attachment copies now use atomic exclusive creation with collision retry, per the recommendation above. Confirmed by a new test, "versioned writes and attachment copies never overwrite existing files."

**SEC-2 — Observation.** Electron hardening covers the core trio but not the secondary checklist layer.
*Where:* `electron/main.ts:33`, `index.html`.
`contextIsolation:true`, `nodeIntegration:false`, and `sandbox:true` were all correctly set — verified in code. Absent: a `setWindowOpenHandler`/navigation restriction, a `session.setPermissionRequestHandler`, and a CSP meta tag in `index.html`.
*Status (v0.5.0):* Remediated — deny-by-default window opening, navigation, and permission handlers added, plus a restrictive CSP.

**SEC-3 — Observation.** `code` CLI launch touches a historically sensitive Windows spawn pattern.
*Where:* `electron/main.ts:31`.
On Windows, `code` on PATH is typically a `.cmd` shim; Node's non-shell `child_process.spawn` has had Windows-specific batch-file argument-escaping CVEs in exactly this call shape historically. The argument in question (`projectPath`) comes from a native OS folder-picker plus a regex-slugified name, not attacker-controlled text — no demonstrated exploitation path.
*Status (v0.5.0):* Accepted — no demonstrated exploit path; dependency pinning (DEP-1) and deliberate update hygiene are the stated ongoing mitigation, not a code change.

#### Correctness & domain integrity

**COR-1 — Major.** Domain constants and validation are hand-duplicated across the IPC boundary.
*Where:* `src/core.ts:2-3` vs. `electron/main.ts:3-6,19-20`.
`MAX_AGENTS`, `MAX_FILES`, `MAX_FILE_BYTES`, `MAX_TOTAL_BYTES`, `ACCEPTED_EXTENSIONS`, and the `Settings`/`Attachment`/`Definition` shapes all existed twice — once in `src/types.ts`/`core.ts`, once hand-retyped in `electron/main.ts`.
*Why it matters:* `AGENTS.md`'s own operating rule is to separate configuration, validation, prompt generation, planning, and execution — the separation existed, but the values and rules inside each side were copy-pasted, not shared.
*Recommendation:* point both `tsconfig.app.json` and `electron/tsconfig.json`'s `include` at one shared module for constants and the validation predicate.
*Status (v0.5.0):* Remediated — shared types, limits, slugging, and validation now cross the renderer/main boundary from one module (`shared/domain.ts`).

**COR-2 — Minor.** The Git/GitHub/IDE dependency rule is implemented twice; only one copy is tested.
*Where:* `src/App.tsx:15` (`setFlag`) vs. `src/core.ts:10-11` (`validateProject`, covered by `tests/core.test.ts:7`).
*Status (v0.5.0):* Remediated — the UI's Git/GitHub/IDE cascade now uses a shared pure domain transition, with direct tests.

**COR-3 — Minor.** `Settings.preferredIde` is an unconstrained string.
*Where:* `src/types.ts:14`.
*Status (v0.5.0):* Remediated — `preferredIde` is now a literal union type.

**COR-4 — Minor.** Locale dictionaries have no compile-time key parity.
*Where:* `src/App.tsx:6` (`tr = {es:{…}, en:{…}}`).
*Status (v0.5.0):* Remediated — translation dictionaries now have compile-time key parity.

**COR-5 — Observation.** No error boundary around the React tree.
*Where:* `src/main.tsx:8`.
*Status (v0.5.0):* Remediated — React now has a minimal bilingual recovery boundary.

#### Testing & verification

**TST-1 — Major.** The privileged execution path has zero automated test coverage.
*Where:* `electron/main.ts:18-32` (`execute`) vs. `tests/core.test.ts` (12/12 tests, all against `src/core.ts`'s pure functions).
The only code that actually touched the filesystem, ran `git`, or created a GitHub repository was `execute()`. CHANGE_CONTROL.md's release notes relied on a manual "packaged smoke test" and "functional UI pass" for this path, release after release.
*Recommendation:* inject the filesystem/process calls behind a seam and run the real logic against a temp directory, per RISKS.md's own "integration tests with temp folders" mitigation for the adjacent Windows-path-edge-cases risk.
*Status (v0.5.0):* Remediated in part — the highest-risk filesystem mutation seams (`electron/files.ts`) now have temp-directory integration coverage, including non-overwrite behavior (`tests/files.test.ts`). Full orchestration coverage for the Git/GitHub/IDE calls remains a follow-up, since those external tools still need injectable adapters — a residual gap, not fully closed.

**TST-2 — Observation.** No component-level tests for `src/App.tsx`.
*Status (v0.5.0):* Deferred — the shared UI domain transitions this finding touched now have direct coverage; full component-level React testing remains proportional to future UI growth, not urgent yet.

#### Dependency & supply chain

**DEP-1 — Major.** Every dependency in `package.json` is pinned to `"latest"`.
*Where:* `package.json:24-39` — all 13 devDependencies, including `electron`, `vite`, `typescript`, `react`.
`package-lock.json` was committed and did pin resolved versions, so `npm ci` was reproducible — but `package.json` itself committed to nothing, so any `npm install` after a deleted or regenerated lockfile would re-resolve everything to whatever was newest, with no diff to review.
*Status (v0.5.0):* Remediated — all direct dependencies are now pinned to the versions verified by this release.

**DEP-2 — Observation (positive).** `npm audit` was clean at audit time: 0 vulnerabilities across 424 resolved packages, verified live.
*Status (v0.5.0):* Not applicable — this was a positive, point-in-time observation, not a defect. Re-run `npm audit` before each future release regardless.

**DEP-3 — Minor.** Unsigned Windows portable executable.
*Where:* `package.json:17-23` — `win.target: ["portable"]`, no certificate.
*Status (v0.5.0):* Accepted — Authenticode signing requires a trusted certificate and recurring cost. Remains a public-distribution gate, not a zero-cost private-MVP change.

#### Documentation consistency

**DOC-1 — Minor.** `docs/SECURITY.md` stated a per-file limit that contradicted the code and every other doc.
*Where:* `docs/SECURITY.md:20` ("25 MB per-file") vs. `README.md:19`, `docs/FAQ.md:17`, `src/core.ts:2`, `electron/main.ts:6` (all: 20 MB / `20*1024*1024`).
*Status (v0.5.0):* Remediated — the documented limit now agrees with the code and every other document (20 MB).

**DOC-2 — Observation.** Legacy product-name migration (`electron/main.ts:10`, `legacyDataFiles`) is a growing, permanent carry-cost. Three product names appear across the repo's history (Prompt to Start → Periastron → Inflaton → accreatio), each intentional and documented (DEC-008).
*Status (v0.5.0):* Remediated — the legacy migration now has an explicit sunset recorded at v1.0.0.

#### Process & delivery maturity

**PROC-1 — Minor.** No CI pipeline. No `.github/workflows` or equivalent was found; every release's verification recorded in CHANGE_CONTROL.md was self-attested locally, not independently enforced.
*Status (v0.5.0):* Remediated — a Windows CI workflow (`.github/workflows/ci.yml`) independently runs install, tests, typecheck, and build.

**PROC-2 — Observation.** See the Independence note above.
*Status (v0.5.0):* Acknowledged, not resolved — by its own nature, an AI-authored remediation cannot manufacture the independent human (or fresh-session) audit this finding calls for. This remains an open governance caveat, correctly recorded as such in `docs/archive/2026-09-05/AUDIT_REMEDIATION_2026-08-02.md` rather than marked fixed.

#### Code quality & maintainability

**QUAL-1 — Observation.** Source was written in a dense, hand-compacted style throughout (e.g. `electron/main.ts` packed 34 lines into ~10.5 KB).
*Status (v0.5.0):* Remediated — source formatting is now enforced through Prettier.

**QUAL-2 — Observation.** Four CSS files (`styles.css`, `extras.css`, `responsive.css`, `polish.css`) were loaded unconditionally, apparently accreted release-by-release.
*Status (v0.5.0):* Deferred — organizational debt with no behavioral or security impact; deferred to a dedicated visual-regression-safe pass.

### What's genuinely well done

- A real decision log (`DECISIONS.md`) with rationale and consequences, not just choices — genuine ADR discipline, rare even in much larger codebases.
- Electron's hardening trio — `contextIsolation`, `sandbox`, `nodeIntegration:false` — was actually set (`electron/main.ts:33`), matching what `docs/SECURITY.md` and the About page claimed. Checked, not assumed.
- Zero generic shell executor anywhere: every external process call used `spawn` with an argument array, never a concatenated shell string. DEC-002 was a decision that was actually kept, five releases later.
- The non-overwrite guarantee was correctly, atomically implemented for every generated document (`writeVersioned`'s `wx` flag) — SEC-1's finding was that one sibling code path missed this pattern, not that the pattern itself was wrong.
- `npm audit` was clean, and the codebase had no leftover `TODO`/`FIXME` markers or hardcoded secrets anywhere in `src/` or `electron/` — checked directly.
- Release notes were honest about their own gaps — CHANGE_CONTROL.md records, in multiple releases, that "automated visual browser inspection remained unavailable" rather than silently omitting it.
- Scope discipline held: every MVP exclusion listed in `docs/archive/2026-09-05/PROJECT_DISCOVERY.md` (no AI dependency, no auth, no cloud sync, no plugins) was still true in the shipped code five releases and three renames later.

### Full findings reference

| ID | Severity | Finding | Location | Status (v0.5.0) |
|---|---|---|---|---|
| SEC-1 | Major | Attachment copy bypasses exclusive-write guarantee | `electron/main.ts:24` | Remediated |
| COR-1 | Major | Domain constants/types duplicated across IPC boundary | `electron/main.ts:3-6` | Remediated |
| TST-1 | Major | Zero automated tests on the privileged execution path | `electron/main.ts:18-32` | Remediated (partial) |
| DEP-1 | Major | All dependencies pinned to "latest" | `package.json:24-39` | Remediated |
| COR-2 | Minor | Git/GitHub/IDE cascade duplicated, only one copy tested | `src/App.tsx:15` | Remediated |
| COR-3 | Minor | `preferredIde` is an unconstrained string | `src/types.ts:14` | Remediated |
| COR-4 | Minor | Locale dictionaries have no key-parity type check | `src/App.tsx:6` | Remediated |
| DEP-3 | Minor | Unsigned Windows portable executable | `package.json:17-23` | Accepted |
| DOC-1 | Minor | SECURITY.md states 25MB vs. 20MB everywhere else | `docs/SECURITY.md:20` | Remediated |
| PROC-1 | Minor | No CI pipeline | — | Remediated |
| SEC-2 | Observation | Secondary Electron hardening layer not present | `electron/main.ts:33` | Remediated |
| SEC-3 | Observation | `code` CLI Windows spawn pattern | `electron/main.ts:31` | Accepted |
| COR-5 | Observation | No React error boundary | `src/main.tsx:8` | Remediated |
| TST-2 | Observation | No component-level tests for App.tsx | `src/App.tsx` | Deferred |
| DEP-2 | Observation | npm audit clean (positive, point-in-time) | — | N/A |
| DOC-2 | Observation | Legacy product-name migration carry-cost | `electron/main.ts:10` | Remediated |
| PROC-2 | Observation | Self-review / independence caveat | — | Accepted (standing) |
| QUAL-1 | Observation | Dense, hand-compacted source formatting | `electron/`, `src/` | Remediated |
| QUAL-2 | Observation | Four accreted CSS files | `src/*.css` | Deferred |

### Verdict

**PASS_WITH_OBSERVATIONS** — 2026-08-02, auditor: Claude (Sonnet 5), single AI-assisted pass (see Independence note).

A PASS verdict was not authorization to skip the four Major items before the next release — it was evidence the app was sound for what it was, with a specific, bounded punch list.

**This verdict covers:** the private, local-first desktop MVP as shipped (v0.4.1), its stated single/small authorized-user audience, and the security/correctness/testing/dependency/process posture of the code as committed at `03af351`.

**This verdict does not cover:** public/web/SaaS release readiness (already gated by `docs/WEB_STRATEGY.md` Phase W3), trademark/legal clearance (DEC-008), accessibility/threat-model/SBOM audits, or dynamic/runtime penetration testing.

**Update, same day:** a remediation pass landed in the working tree as v0.5.0 (uncommitted at time of writing), addressing 13 of the 19 findings and explicitly dispositioning the rest — see the per-finding Status lines above and `docs/archive/2026-09-05/AUDIT_REMEDIATION_2026-08-02.md`. This verdict itself is not revised: it describes the code as it stood at `03af351`, exactly as CHANGE_CONTROL.md's own dated entries are never rewritten after the fact.
