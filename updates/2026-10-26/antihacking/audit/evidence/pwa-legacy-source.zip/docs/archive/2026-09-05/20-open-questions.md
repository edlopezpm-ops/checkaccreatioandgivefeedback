# Open Questions — Non-blocking questionnaire

These choices do not block the MVP and have conservative defaults.

1. Should the packaged application remain Electron, or prioritize a Tauri migration after Rust is installed? Default: keep Electron through MVP feedback. ***Respuesta Ed: haz y aplica/ejecuta el mejor approach incluyendo si necesitas instalar algo local para poder ejecutarlo. Tienes mi autorización.
2. Should “both” retain full tracking content or only a pointer once a dedicated repo exists? Default: lightweight pointer/status to avoid drift. ***Respuesta Ed: lo explico en el último prompt que pasé, en varios puntos.
3. Which governance documents from the toolkit must be copied verbatim versus generated minimally? Default: minimal safe seed now; versioned toolkit profiles in V1. ***Respuesta Ed: lo explico en el último prompt que pasé, en varios puntos.
4. Should remote GitHub creation enter V1? Default: no; export instructions instead. ***Respuesta Ed: lo explico en el último prompt que pasé, en varios puntos.
5. Should successful projects appear in local history? Default: no MVP history; add an opt-in metadata index in V1. ***Respuesta Ed: me gusta esta idea, procede pero suave, que no sobrecargue la app. Trazabilidad es importante, ¿quizás también una firma particular de proyecto creado por esta app, en el repo nuevo creado y visible en VS Code? Tienes full decision making rights para idear la mejor opción aquí.
6. Should the final packaged installer support portable mode? Default: standard per-user install first. ***Respuesta Ed: ok, pero consideremos que, la versión "mía" original primera versión ejecutable es local; no obstante preparemos el camino para que esto sea un full saas-free, so no installer para la versión futura
7. Preferred language of generated project docs: Spanish, English, or follow UI/context? Default: prompt in Spanish, technical scaffold minimal English. ***Respuesta Ed: di una idea inicial en el último prompt, pero tienes full decision making rights para definir el mejor y más eficiente approach aquí
