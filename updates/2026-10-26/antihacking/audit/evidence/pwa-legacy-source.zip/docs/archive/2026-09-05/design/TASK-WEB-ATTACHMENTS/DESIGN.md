# TASK-WEB-ATTACHMENTS — Local-only W1 discovery attachments

Status: design complete; production implementation is gated.  
Owner: Participant B — Codex Solution Designer  
Authority: `docs/archive/2026-09-05/design/TASK_BACKLOG.md` entry `TASK-WEB-ATTACHMENTS`; master prompt; supplemental §§5–6, 12–13, 30–31.  
Scope boundary: this record owns WEB-01 and the classification-B privacy inconsistency only. It does not implement code, upload files, add a backend/W2, parse attachment content, alter AEKR, or redesign desktop attachment behavior.

## 1. Outcome

W1 will let a user select up to 20 allowlisted local discovery files, keep their bytes only in transient page memory, show per-file acceptance or rejection, and place accepted bytes under `docs/product/sources/` in a non-dry repository/both ZIP. One pure resolver will assign safe collision-free archive names before generating the prompt or provenance, so every textual claim uses the exact ZIP basename. Draft autosave will persist ordinary form data but deliberately omit attachment metadata and bytes; after a reload, a count-only marker will explain that local files must be selected again.

No dependency addition is required: the existing browser `File`/`Blob` APIs and `client-zip` support this design. No AEKR contract change is required.

## 2. Sprint 1 — Existing-state discovery

### MSS 1.1 — Reconfirm scope and authority

1. **Objective:** establish the authoritative boundaries and success conditions.
2. **Current state inspected:** `AGENTS.md`, both mandate prompts, `ORCHESTRATOR_LOG.md`, `REPRODUCTION_REPORT.md`, and the Task backlog entry.
3. **Artifacts:** this design record only.
4. **Design work:** retained the existing allowlist (`.md .txt .pdf .docx .json .yaml .yml .csv .png .jpg .jpeg`) and limits (20 files, 20 MiB each, 100 MiB total); classified upload, parsing, paths, cloud persistence, W2, and public deployment as non-goals.
5. **Focused validation:** checked the outcome against every backlog acceptance criterion and master local-first/no-upload boundaries.
6. **Result:** complete.
7. **Deviations/findings:** none; the privacy contradiction is explicitly in scope.
8. **Status:** complete and stable.

### MSS 1.2 — Inspect domain, bridge, export, and desktop boundaries

1. **Objective:** locate actual contracts that must change without guessing at root cause.
2. **Current state inspected:** `shared/domain.ts`, `src/types.ts`, `src/core.ts`, `src/bridge/web.ts`, `src/webExport.ts`, `electron/main.ts`, and `electron/files.ts`.
3. **Artifacts:** evidence and file-level contract in this record.
4. **Design work:** confirmed that `ProjectDefinition.attachments` currently requires desktop `path`; `WebAttachment` exists but is unused; the web bridge rejects selection; `buildProjectFiles` is string-only; prompt and signature use attachment `name`; desktop copies with exclusive versioned writes.
5. **Focused validation:** traced selection through validation, prompt, signature, execution, and desktop copy sites.
6. **Result:** WEB-01 is a missing capability, not a broken browser picker.
7. **Deviations/findings:** the earlier architecture sketch anticipates Blob ZIP inputs but is not the implemented contract.
8. **Status:** complete and stable.

### MSS 1.3 — Inspect UI, draft, docs, and tests

1. **Objective:** capture current user and persistence behavior.
2. **Current state inspected:** attachment/draft/confirmation/result code in `src/App.tsx`; `src/draftStore.ts`; current tests; `docs/SOP_WEB.md`, `docs/PRIVACY_POLICY.md`, and `docs/WEB_ARCHITECTURE.md`.
3. **Artifacts:** UX, migration, documentation, and verification decisions below.
4. **Design work:** confirmed W1 strips attachments on restore and shows a desktop-only note; autosave currently writes the whole project; dry-run returns before ZIP creation; privacy §2 says attachments are in IndexedDB while privacy §4 and SOP say W1 does not support them.
5. **Focused validation:** compared statements against actual code and the current schema-version-2 draft envelope.
6. **Result:** durable attachment restoration cannot be promised by the current draft design.
7. **Deviations/findings:** privacy wording is internally inconsistent, classification B, and must ship with this Task.
8. **Status:** complete and stable.

### Sprint 1 consolidation

The feature needs two deliberately separate representations: persistable attachment metadata used by shared domain/rendering, and transient W1 bytes used only by the live page/export. Archive naming must precede generated-text construction. Desktop paths remain a privileged host concern. Draft persistence must explicitly strip browser attachment data and retain at most a count-only reselection notice.

Sprint checkpoint: Sprint 1  
Objective: establish verified current state and boundaries.  
Micro-sub-sprints completed: 1.1–1.3.  
Files changed: design record only.  
Focused tests: static call-site/schema/doc trace; no production tests needed.  
Results: root cause and affected contracts confirmed.  
New findings: current privacy §2 contradicts §4 and implementation.  
Residual risks: live browser memory/download behavior remains for implementation testing.  
Deviations: none.  
Ready for next sprint: Yes.

## 3. Sprint 2 — Attachment domain and validation design

### MSS 2.1 — Define representations and invariants

1. **Objective:** make shared metadata usable without pretending a browser has filesystem paths.
2. **Current state inspected:** `Attachment`, `ProjectDefinition`, `WebAttachment`, bridge signatures, and Electron copy call sites.
3. **Intended files:** `shared/domain.ts`, `src/types.ts`, `src/App.tsx`, `electron/main.ts`, and relevant tests.
4. **Bounded design:**
   - Add shared `AttachmentMetadata = { name: string; size: number; extension: string }`.
   - Keep exported desktop `Attachment = AttachmentMetadata & { path: string }` for Electron picker/preload compatibility.
   - Change `ProjectDefinition.attachments` to `AttachmentMetadata[]`; this is the serializable, renderer-safe definition and never contains bytes or a fake path.
   - Change `WebAttachment` to `AttachmentMetadata & { id: string; blob: Blob }`. `id` is a per-selection UI identity generated locally; it is neither persisted nor written to provenance.
   - Hold `webAttachments: WebAttachment[]` and rejected selection rows in W1 component state outside `ProjectDefinition`. Keep `p.attachments` as a projection of accepted `webAttachments` metadata in the same order. Electron continues to receive real `Attachment[]`; `electron/main.ts` must narrow/assert `path` before copying and return an invalid-definition error rather than dereference absent paths.
   - Do not encode Blob, File, object URL, absolute path, MIME type, or file contents in shared domain, draft, logs, or project signature.
5. **Focused validation:** the shared validator and text generators need only metadata; privileged copy is the sole path consumer; browser ZIP is the sole Blob consumer.
6. **Result:** one honest cross-host metadata contract with host-specific source handles.
7. **Deviations/findings:** this intentionally tightens the Electron boundary rather than making `path` optional.
8. **Status:** complete.

### MSS 2.2 — Define reusable validation and selection admission

1. **Objective:** enforce the desktop-equivalent rules before export and explain each failure.
2. **Current state inspected:** the single aggregate `errors.attachments = "invalid"` check and UI error translation.
3. **Intended files:** `shared/domain.ts`, `src/core.ts` re-export if needed, `src/App.tsx`, `tests/core.test.ts`.
4. **Bounded design:** introduce a pure `validateAttachmentSet(metadata[])` returning structured issues with codes `unsupportedExtension`, `fileTooLarge`, `tooManyFiles`, and `totalTooLarge`, plus file identity/index where applicable and totals. Extension is derived from the last suffix of `name`, lower-cased, and compared to `ACCEPTED_EXTENSIONS`; the supplied `extension` must equal that derived value. Reject empty/control-only names, negative/non-finite sizes, files strictly greater than 20 MiB, count greater than 20, and total strictly greater than 100 MiB. Zero-byte allowlisted files remain valid. `validationErrors` delegates to this function and preserves the existing top-level `attachments` key for form compatibility.
   
   On each picker result, evaluate candidates in browser selection order against already accepted rows. Accept every individually valid candidate while cumulative count/size remain within limits. Keep each rejected candidate as a metadata-only error row (do not retain its Blob) with its precise reason. Valid duplicate names are accepted; collision resolution is an export concern. A subsequent selection clears only superseded picker-level summary text, not unrelated form errors or accepted files. Removal immediately recomputes totals and project validity. A rejected row can be dismissed; retry means selecting the corrected file again.
5. **Focused validation:** boundary tables at 20/21 files, exactly/over 20 MiB, exactly/over 100 MiB, case-insensitive extensions, multi-dot names, no extension, mismatched declared extension, invalid sizes, mixed valid/invalid batches, and existing-plus-new totals.
6. **Result:** deterministic partial admission preserves valid selections and all other form input.
7. **Deviations/findings:** rejected bytes are discarded promptly to limit memory; automatic promotion after another removal is therefore intentionally unavailable and the row says “Remove this entry or choose the file again.”
8. **Status:** complete.

### MSS 2.3 — Security invariants

1. **Objective:** prevent attachment input from becoming execution, disclosure, or archive-path risk.
2. **Current state inspected:** local-only governance, current allowlist, ZIP library boundary, versioned desktop copy.
3. **Intended files:** `shared/domain.ts`, `src/webExport.ts`, `src/bridge/web.ts`, security/risk docs listed in §9.
4. **Bounded design:** files are opaque bytes: never read as text, parse, preview, execute, interpolate into a shell command, upload, fetch, send to workers/services, or log by content. Only `name`, `size`, derived extension, status, and total are displayed. The picker uses `multiple` and an `accept` hint, but validation is authoritative because browser filters are bypassable. Archive paths are generated, never accepted from `File.name`; strip directory components, Unicode control/bidi characters, `/` and `\`, dot-segments, trailing dots/spaces, and Windows-reserved basenames. No object URL is needed for attachment content. Release references on removal, New draft, phase reset, successful export, and component unload. Export revalidates metadata and `blob.size` equality immediately before ZIP construction. No content hash is required because hashing 100 MiB adds cost and is not needed for deterministic naming or byte identity.
5. **Focused validation:** malicious names (`../`, slashes, controls, `.`, `..`, reserved names), forged extension/size metadata, and network inspection requirements.
6. **Result:** bounded local opaque handling with defense in depth at export.
7. **Deviations/findings:** client-side ZIP compression can still consume substantial memory; this remains an explicit residual risk under the existing 100 MiB cap.
8. **Status:** complete.

### Sprint 2 consolidation

Shared state carries metadata only; W1 bytes remain in a live-page sidecar. Structured validation becomes reusable and precise while the existing form-level error key stays compatible. Selection is partial-success, ordered, and recoverable. Export distrusts renderer metadata and revalidates Blob size and safe names.

Sprint checkpoint: Sprint 2  
Objective: define domain, validation, and security contracts.  
Micro-sub-sprints completed: 2.1–2.3.  
Files changed: design record only.  
Focused tests: designed boundary, mixed-batch, and hostile-name matrices.  
Results: implementation-ready contracts established.  
New findings: no new dependency or AEKR change is needed.  
Residual risks: peak Blob/ZIP memory.  
Deviations: rejected blobs are not retained for automatic retry.  
Ready for next sprint: Yes.

## 4. Sprint 3 — UI selection, status, and recovery design

### MSS 3.1 — Selection and list interaction

1. **Objective:** make local attachment selection discoverable, legible, and recoverable in W1.
2. **Current state inspected:** current `Field`, desktop attachment chips, web capability note, translations, responsive styles, and theme control-state contract.
3. **Intended files:** `src/App.tsx`, `src/styles.css`/`src/extras.css`/`src/responsive.css` as appropriate, `src/bridge/web.ts`, UI tests.
4. **Bounded design:** replace the web-only unsupported note with “Add local files” and visible helper copy: accepted extensions; “20 files · 20 MB each · 100 MB total”; “Files stay in this tab and are included only in a real ZIP export.” The web bridge picker creates a fresh `<input type=file multiple>` for each invocation, applies the allowlist to `accept`, resolves `File[]` on change/cancel, removes the element, and maps each File to `WebAttachment`; it must only be called from the user-activated button. The list is a semantic `<ul>` with one row per selection: filename, human-readable size, and text+icon status (`Ready` or exact error). Each row has a 44px-target remove button with an attachment-specific accessible name. A summary above the list says “N of 20 files · X of 100 MB.” Rejected rows do not count toward totals.
   
   Keep the add control enabled at the count limit so a user activation can receive the explicit count error; alternatively the button may be disabled only if adjacent text says “20-file limit reached” and removal remains available. The implementation must choose the latter consistent behavior across mouse/keyboard tests: disabled at exactly 20 accepted files with the adjacent reason. When fewer than 20 files but total is exhausted, leave it enabled so candidate-specific errors can be shown. New selection or removal does not modify name, context, restrictions, agents, action, flags, or orchestration.
5. **Focused validation:** accessible-name, status announcement, partial-batch, removal, repeated picker, cancel, and form-preservation component tests.
6. **Result:** selection has clear limits, state, and recovery.
7. **Deviations/findings:** browser picker `accept` is only guidance; UI never calls it “validated” until domain admission succeeds.
8. **Status:** complete.

### MSS 3.2 — Status, destructive transitions, and export messaging

1. **Objective:** distinguish transient selection, dry-run review, real export, and reset behavior.
2. **Current state inspected:** phase transition currently clears attachments silently; confirmation modal and `ExecutionResult` messages.
3. **Intended files:** `src/App.tsx`, localized strings, component tests.
4. **Bounded design:**
   - Changing phase to Idea with selected W1 files opens a confirmation: “Changing to Idea removes N files held in this tab.” Confirm clears byte sidecar, metadata, and rejected rows; Cancel preserves phase and files. Desktop behavior is not changed by this Task.
   - New draft confirmation mentions selected local files and clears them only after confirmation.
   - The export confirmation lists the accepted count and final archive basenames and states either: dry-run, “Review only: no ZIP will be built or downloaded; selected files remain in this tab,” or real export, “Build `<slug>.zip` locally with N attachments.” Rejected rows block neither export nor validation because they are not part of the project, but an adjacent warning states they will not be included.
   - Dry-run result must say “Dry run complete. No ZIP was created or downloaded. Turn off Dry run to export.” It must not say merely “Would export.” Real success says the app built and requested download of `<slug>.zip`, includes N attachments, and cautions that browser download policy may still block/cancel saving; final artifact-evidence semantics remain owned by `TASK-EXEC-EVIDENCE`.
   - After a real export request succeeds, retain selections so the user can intentionally retry if the browser blocked the download; idempotency controls are owned by `TASK-EXEC-IDEMPOTENCY`. Do not clear bytes based only on anchor activation.
5. **Focused validation:** phase cancel/confirm, New draft cancel/confirm, dry-run no ZIP call, real-export wording, rejected-row warning, and preservation after requested download.
6. **Result:** no mutation/download claim is ambiguous.
7. **Deviations/findings:** attachment status cannot claim the browser persisted the final download; wording is intentionally bounded.
8. **Status:** complete.

### MSS 3.3 — Required 15-question UX decision record

This answers supplemental §6 for the unified W1 attachment selection/export/reload feature.

1. **Goal:** add trusted local discovery sources to a W1 project ZIP.
2. **Required information:** a local file with allowlisted extension within count/size limits.
3. **Optional information:** none beyond the existing project form; attachments themselves are optional.
4. **Happy path:** choose files → see Ready rows/totals → review exact final names → run real export → receive a ZIP download request containing those bytes.
5. **Failure modes:** unsupported/oversize/too many/total too large, hostile/colliding name, picker cancel, lost transient bytes on reload, memory/ZIP failure, or browser-blocked download.
6. **Explanation:** per-row plain-language reason plus a summary/action; export errors identify that no ZIP was requested.
7. **Recovery:** remove/reselect a file, reduce totals, retry export, or reload and reselect; all non-attachment form input remains.
8. **Success confirmation:** Ready status before export; after export, exact ZIP name and included attachment count, bounded to “download requested.”
9. **Accidental repetition:** running/confirmation controls must consume the later idempotency contract; this Task keeps selection after export and never auto-repeats.
10. **Narrow screens:** rows stack name/status above size/remove; no horizontal scroll; controls remain full-width or 44px minimum.
11. **Keyboard:** labeled button opens native picker; list/remove controls follow DOM order; focus returns to Add after picker and to the next row/Add after removal; live summary/errors are announced without stealing focus.
12. **Unavailable capabilities:** no upload/path/cloud wording; reload notice explicitly says files must be reselected.
13. **Implementation concepts:** UI says “kept in this tab,” not Blob, sidecar, structured clone, or IndexedDB schema.
14. **Terminology:** “discovery sources,” “attachments,” “dry run,” and final archive names match prompt/provenance/ZIP artifacts.
15. **Desktop/web consistency:** same allowlist/limits/metadata and source directory; desktop uses native paths and durable source files, W1 uses transient browser selection and ZIP bytes, with that difference stated before export.

Status: all questions answered; complete.

### MSS 3.4 — Visual and UX acceptance mapping

1. **Objective:** satisfy supplemental §§30–31 without inventing a separate visual system.
2. **Current state inspected:** `TASK-DESIGN-THEME/DESIGN.md` token and component-state contract.
3. **Intended files:** attachment component selectors in existing CSS files; no new visual dependency or imagery.
4. **Bounded design:** attachment working surfaces use `--surface-primary`/`--surface-muted`, `--border-default`, `--text-primary`/`--text-secondary`; Add/remove controls use the shared control tokens (`--control-background`, hover/selected/border/text/disabled families); focus uses `--focus-ring`; Ready uses `--success` plus icon/text, errors use `--danger`/`--danger-muted` plus icon/text, and reload warning uses `--warning`/`--warning-muted`. Purple is not a status signal. Default, hover, active, focus-visible, disabled, error, and busy states follow the dependency design in both themes. No gradients, glow, galaxy imagery, attachment preview, or motion is added. At 200% zoom and narrow viewports rows wrap vertically; filenames use overflow-wrap and may visually truncate only when the full name remains available to assistive technology and via title/expand behavior. Reduced motion has no feature-specific animation.
5. **Focused validation:** WCAG AA token contrast inherited from theme evidence; both themes; state matrix; 320px/narrow layout, supported desktop widths, 200% zoom, keyboard-only and screen-reader checks.
6. **Result:** all relevant §30 criteria (professional shared identity, complete states, contrast, focus, semantic non-purple status, long-session neutrality, cross-host coherence, responsive/zoom/reduced motion, recorded tokens) and §31 criteria (clear action/differences, preserved validation work, attachment limits/status, honest output/failure, keyboard/responsive behavior, no false capability) are explicit. Unrelated Mode 1/provider/funding/six-participant criteria remain owned by their Tasks.
7. **Deviations/findings:** none.
8. **Status:** complete.

### Sprint 3 consolidation

The W1 field becomes a real, accessible local picker with structured rows and totals. All destructive transitions involving transient bytes are confirmed. Dry-run and real-export language are unambiguous. Styling consumes only the approved semantic control/status tokens and works in both themes and responsive modes.

Sprint checkpoint: Sprint 3  
Objective: define complete attachment UX and visual behavior.  
Micro-sub-sprints completed: 3.1–3.4.  
Files changed: design record only.  
Focused tests: designed component, keyboard, state, theme, viewport, zoom, and wording checks.  
Results: §6, §30, and §31 requirements mapped.  
New findings: phase change currently silently destroys attachments and needs W1-only confirmation.  
Residual risks: native picker cancellation events vary by browser and require live coverage.  
Deviations: none.  
Ready for next sprint: Yes.

## 5. Sprint 4 — Deterministic ZIP inclusion design

### MSS 4.1 — Resolve safe final names once

1. **Objective:** ensure bytes, prompt, provenance, confirmation, and logs name the same files.
2. **Current state inspected:** prompt and `projectSignature` map `attachments[].name`; `buildProjectFiles` renders text before ZIP creation; desktop `copyVersioned` resolves names during copying.
3. **Intended files:** `src/webExport.ts`, `src/bridge/web.ts`, `src/App.tsx`, `tests/webExport.test.ts`.
4. **Bounded design:** add pure `resolveWebAttachments(webAttachments)` returning ordered `{ source, archiveName, archivePath, metadata }`. Preserve selection order. Sanitize each basename per §3.3; preserve a validated lower-case extension; use `attachment<extension>` if the stem empties. Allocate case-insensitively against prior resolved paths with suffix ` (2)`, ` (3)`, etc. before the extension, including collisions created by sanitization. Final path is exactly `<slug>/docs/product/sources/<archiveName>`. Unicode filenames that survive safety normalization are preserved; comparison uses Unicode normalization plus lower-casing for collision purposes. The same input order/metadata produces the same names and ZIP entry order.
5. **Focused validation:** exact duplicates, case-only duplicates, sanitized collisions, multiple dots, Unicode normalization collisions, reserved/dot/path names, and stable repeated resolution.
6. **Result:** collision-safe deterministic basenames without filesystem paths.
7. **Deviations/findings:** archive naming is intentionally independent from desktop’s race-safe versioned copy naming; each host is deterministic within its execution environment, and W1 textual consistency is guaranteed.
8. **Status:** complete.

### MSS 4.2 — Build mixed text/binary export from the resolved projection

1. **Objective:** include actual byte-identical attachments without breaking current text exports.
2. **Current state inspected:** `ExportFile { path, content: string }` and `client-zip` mapping.
3. **Intended files:** `src/webExport.ts`, `src/bridge/web.ts`, `tests/webExport.test.ts`, `tests/bridge.test.ts`.
4. **Bounded design:** replace `ExportFile` with `ExportEntry = { path: string; input: string | Blob; kind: "generated" | "attachment" }`. Replace `buildProjectFiles` with `buildWebExport(p, settings, webAttachments, opts)`. That function verifies a one-to-one/order/size match between `p.attachments` and transient sources, resolves names, creates an export-only `ProjectDefinition` projection whose attachment names are the final archive basenames, then calls existing shared `generatePrompt`, `projectSignature`, and other generators. Append binary entries after the fixed generated-file order, in resolved selection order. Pass `{ name: path, input }` directly to `client-zip`; never convert Blob through text or base64. `discovery.md` remains current context/constraints content; the prompt and `.accreatio/project.json.sourceFiles` are the authoritative generated-text/provenance attachment lists and contain final basenames. Confirmation consumes the same resolver output, not a second algorithm.
   
   Immediately before building, re-run shared validation, ensure transient count equals metadata count, names/extensions/sizes match, and each `blob.size` equals declared size. Any mismatch returns a localized failure and calls neither `downloadZip` nor `triggerDownload`. Dry-run may resolve/describe names but must not call `downloadZip` and must not read Blob contents. Real export supports repository and both because W1 maps both to its repository ZIP; tracking-only remains unsupported.
5. **Focused validation:** unzip binary fixtures (including NUL/non-UTF-8 bytes) and compare bytes; manifest order/path snapshots; prompt/signature/final-path equality; generated text-only baseline; optional orchestration; dry-run zero ZIP invocation; missing/stale/size-mismatched sidecar; repository/both and tracking rejection.
6. **Result:** one deterministic manifest carries mixed inputs and truthful provenance.
7. **Deviations/findings:** ZIP container bytes themselves need not be globally byte-for-byte reproducible if `client-zip` timestamps/metadata vary; required determinism is entry order/path/content and collision resolution. Attachment payload bytes must be byte-identical.
8. **Status:** complete.

### MSS 4.3 — Result and cleanup failure semantics

1. **Objective:** avoid success claims or leaks across partial failures.
2. **Current state inspected:** current bridge catches only build errors; dynamic ZIP errors can reject; download trigger cannot prove persistence.
3. **Intended files:** `src/bridge/web.ts`, `src/types.ts` only if result fields are added by the later evidence Task, bridge tests.
4. **Bounded design:** catch resolver, ZIP-generation, and DOM-download-request failures and return `ok:false`, `completed:[]`, with no “Included” success logs. On successful Blob construction and anchor activation, return current-compatible `ExecutionResult` with attachment paths in logs and bounded download-request wording in UI. Do not claim disk save. Revoke only the ZIP object URL; attachment Blobs use no URLs. Keep selected bytes for retry until explicit removal/reset/navigation. Avoid widening `ExecutionResult` now if `TASK-EXEC-EVIDENCE` owns its richer evidence fields.
5. **Focused validation:** injected resolver/ZIP/DOM failures and no-success-log assertions; successful URL revoke; selections retained.
6. **Result:** failure and ownership boundaries remain honest.
7. **Deviations/findings:** browser save completion is unknowable through the current anchor API and is deferred to the evidence Task’s approved semantics.
8. **Status:** complete.

### Sprint 4 consolidation

One resolver owns archive names. A mixed string/Blob manifest feeds the existing ZIP dependency, generated text uses a resolved export projection, and export-time validation prevents stale sidecars. Determinism covers entry path/order/content; only browser save completion remains intentionally unclaimed.

Sprint checkpoint: Sprint 4  
Objective: define safe, deterministic, byte-preserving ZIP inclusion.  
Micro-sub-sprints completed: 4.1–4.3.  
Files changed: design record only.  
Focused tests: designed collision, binary equality, manifest, parity, dry-run, and injected-failure tests.  
Results: ZIP/provenance consistency contract complete.  
New findings: container-level reproducibility is not guaranteed by current library and is not needed for acceptance.  
Residual risks: browser memory and download policy.  
Deviations: richer artifact evidence remains in its owning Task.  
Ready for next sprint: Yes.

## 6. Sprint 5 — Draft/reload lifecycle design

### MSS 5.1 — Define schema version 3 persistence boundary

1. **Objective:** autosave form data without stale or falsely durable attachment references.
2. **Current state inspected:** IndexedDB draft schema version 2 stores `project` wholesale; load already forces `attachments: []` in `App`.
3. **Intended files:** `src/draftStore.ts`, `src/App.tsx`, `tests/draftStore.test.ts`.
4. **Bounded design:** bump envelope schema to 3 and define `StoredDraftV3 = { schemaVersion: 3; project: PersistedProjectDefinition; transientAttachments?: { count: number } }`, where `PersistedProjectDefinition` is `Omit<ProjectDefinition,"attachments"> & { attachments: [] }`. `saveDraft` (or a pure serializer it calls) always writes `attachments: []`, never accepts/stores `WebAttachment`, and records only accepted transient count when greater than zero. Do not persist names, extensions, sizes, IDs, Blobs, Files, paths, error rows, or final archive names. `normalizeDraft` returns project plus the count notice through an explicit load-result type rather than smuggling it into `ProjectDefinition`.
5. **Focused validation:** inspect the exact object sent to IndexedDB; assert no Blob/name/ID survives; schema-3 round trip; count marker only.
6. **Result:** attachment durability is explicitly excluded at the storage boundary.
7. **Deviations/findings:** structured clone may support Blob in some browsers, but this design does not rely on it because lifecycle/browser quota behavior is not a safe product promise.
8. **Status:** complete.

### MSS 5.2 — Migration and reload/user behavior

1. **Objective:** preserve old draft form input while making attachment loss visible and truthful.
2. **Current state inspected:** v1 raw-project migration, v2 envelope normalization, restore-time attachment clearing, New draft.
3. **Intended files:** `src/draftStore.ts`, `src/App.tsx`, tests and docs.
4. **Bounded design:**
   - V1 direct projects and v2 envelopes continue to normalize all existing ordinary fields. Regardless of any legacy `attachments` content (including malformed objects or cloneable Blobs), discard it and return a reselection count equal to the length of the legacy attachment array, capped for display; never try to revive paths/bytes.
   - V3 reload restores ordinary form fields with `attachments: []`. If the marker count is positive, show a persistent warning in the attachment section and draft status area: “Your draft was restored. N local attachment(s) were not saved; select them again before export.” Clear the warning when the user dismisses it, starts a New draft, or selects new files; selecting fewer files may clear the old marker because it is not a reconstruction checklist.
   - Same-tab autosave never clears live `webAttachments`; it serializes a stripped snapshot. A full reload/tab close/navigation loses the bytes by browser lifecycle. Back/forward cache restoration may preserve memory, but the product promises only the conservative rule: after a reload, verify the Ready list; if absent, reselect.
   - After reload, prompt/signature preview immediately says no attachments until reselection. Export cannot use the count marker as evidence and cannot proceed with phantom sources.
5. **Focused validation:** v1/v2/v3 fixtures, malformed/Blob legacy attachments, reload restoration, marker visibility/dismissal, no phantom prompt/sourceFiles, same-tab autosave preserving live selection, New draft cleanup.
6. **Result:** form continuity without false binary continuity.
7. **Deviations/findings:** only a count is retained to minimize filename disclosure while still explaining lost transient state.
8. **Status:** complete.

### Sprint 5 consolidation

Draft schema v3 creates a hard serialization boundary: ordinary form data persists, attachment bytes and identifying metadata do not. A count-only marker drives honest reselection guidance. All legacy attachment-like data is discarded safely, and generated artifacts cannot reference absent files.

Sprint checkpoint: Sprint 5  
Objective: define honest autosave/reload behavior and migration.  
Micro-sub-sprints completed: 5.1–5.2.  
Files changed: design record only.  
Focused tests: designed serializer inspection, version fixtures, reload, marker, and phantom-source tests.  
Results: persistence/migration contract complete.  
New findings: structured-clone capability does not justify a durable product guarantee.  
Residual risks: browser eviction can also remove the ordinary draft; existing unavailable-storage status covers it.  
Deviations: count-only marker intentionally omits filenames.  
Ready for next sprint: Yes.

## 7. Sprint 6 — Privacy and documentation reconciliation

### MSS 6.1 — Define exact truthful user documentation

1. **Objective:** make capability, local handling, export, and reload claims agree.
2. **Current state inspected:** current SOP capability matrix/export/draft sections and contradictory privacy §§2/4/Spanish summary.
3. **Intended files:** `docs/SOP_WEB.md`, `docs/PRIVACY_POLICY.md`, `docs/WEB_ARCHITECTURE.md`, `docs/FAQ.md`, `CHANGE_CONTROL.md`, and Project Map/security/risk documentation if their maintained scopes mention W1 attachments.
4. **Bounded design:**
   - `SOP_WEB.md`: mark discovery attachments supported locally; document allowlist/limits, Ready/error/removal, `docs/product/sources/`, collision renaming, exact dry-run behavior, real-download limitation, and mandatory reselection after reload.
   - `PRIVACY_POLICY.md` §2: replace “Project text, attachments, and the current draft live ... in IndexedDB” with the accurate distinction: ordinary draft form data is stored in IndexedDB; selected attachment bytes are held transiently in the active page and omitted from draft storage; real export writes them into the local ZIP; none is uploaded. Retention must say attachment bytes are released on removal/reset/page lifecycle and must be reselected after reload. §4 must state the shipped capability, limits, opaque handling, local validation, and ZIP inclusion—not “not yet supported.” Update the Spanish summary to make the same distinction. Preserve the legal-review/public-deployment caveat.
   - `WEB_ARCHITECTURE.md`: supersede its generic “attachments Blob” and draft statements with the metadata/sidecar/v3/reselection and resolved-manifest design; do not revive W2 direction.
   - FAQ/capability matrix and change control: record W1 support and transient lifecycle. Security/risk records: record memory pressure, hostile-name normalization, no-content-egress verification, and discarded draft bytes.
5. **Focused validation:** terminology search for “not yet supported,” “attachments ... IndexedDB,” and contrary persistence claims; English/Spanish parity; compare every statement to tests and code.
6. **Result:** documentation impact is exact and bounded.
7. **Deviations/findings:** this Task does not clean unrelated stale W2 or desktop/AEKR documentation findings classified D.
8. **Status:** complete.

### MSS 6.2 — Documentation/privacy UX questions and acceptance

1. **Objective:** ensure disclosure appears at the decision point, not only in policy text.
2. **Current state inspected:** attachment helper, footer “Local browser draft,” confirmation/result, SOP/privacy language.
3. **Intended files:** `src/App.tsx` and docs above.
4. **Bounded design:** attachment helper and reload warning carry the essential privacy/lifecycle facts before selection/export. The generic footer remains true for ordinary form data but must not imply attachment persistence; revise to “Form draft saved locally” if space allows. Policy/SOP give detail. The UI never says “IndexedDB,” “structured clone,” or “Blob.” This decision uses the same §6 answers in MSS 3.3; specifically, information is understandable before action, errors preserve work, unavailable persistence is explicit, terminology matches artifacts, and desktop/W1 differences are stated.
5. **Focused validation:** user-language review at default, dry-run, selected, rejected, restored, and real-export states.
6. **Result:** privacy is part of the workflow, not post-hoc architecture copy.
7. **Deviations/findings:** none.
8. **Status:** complete.

### Sprint 6 consolidation

Docs and in-product disclosure will distinguish IndexedDB form persistence from transient attachment bytes everywhere, including Spanish. W1 attachment support is described as shipped only when implementation lands. Unrelated category-D cleanup remains out of scope.

Sprint checkpoint: Sprint 6  
Objective: reconcile privacy and operator documentation.  
Micro-sub-sprints completed: 6.1–6.2.  
Files changed: design record only.  
Focused tests: designed contradictory-phrase search and EN/ES/code consistency review.  
Results: documentation plan complete.  
New findings: generic footer wording may imply broader draft persistence and is included for correction.  
Residual risks: policy still requires formal legal review as already stated.  
Deviations: unrelated documentation debt excluded.  
Ready for next sprint: Yes.

## 8. Sprint 7 — Verification and delivery plan

### MSS 7.1 — Automated verification matrix

1. **Objective:** define proportional proof for every contract.
2. **Current state inspected:** `tests/core.test.ts`, `tests/bridge.test.ts`, `tests/draftStore.test.ts`, `tests/webExport.test.ts`, package scripts, and backlog evidence requirements.
3. **Intended files:** those four tests plus focused UI/component tests in the repository’s established test location; no new test dependency without evidence.
4. **Bounded design:**
   - Core: structured issue codes and all boundaries/hostile metadata described in MSS 2.2.
   - Bridge/picker: cancel, accept hint, `File` mapping, unsupported-method list updated to remove `chooseAttachments`, dry-run never imports/calls ZIP, export-time sidecar mismatch, and failure results.
   - Web export: safe/colliding deterministic paths; fixed entry order; actual unzip and byte equality for text, binary/NUL, PNG-like, and duplicate-name fixtures; final names equal prompt and signature; text-only baseline unchanged; orchestration unchanged; repository/both accepted and tracking rejected.
   - Draft: stripped serialized object (not only normalized output); v1/v2/v3 migration; Blob/path/name discarded; count-only marker; corrupt input; reload/no phantom sources.
   - UI: mixed selection status/totals, exact errors, removal/focus, picker cancel, phase/New draft confirmations, preserved unrelated fields, count-limit disabled explanation, restored warning, dry/real confirmation and results, EN/ES strings.
   - Regression: desktop `Attachment` retains required path; desktop picker/copy/versioned collision tests pass; attachment-free W1 ZIP manifest and generated text remain unchanged except intentionally revised messaging/types.
5. **Focused validation:** map each backlog acceptance criterion to at least one automated assertion and later live evidence.
6. **Result:** complete automated matrix.
7. **Deviations/findings:** Node tests alone cannot prove native picker, browser download, memory, accessibility, or network behavior.
8. **Status:** complete.

### MSS 7.2 — Required implementation verification and independent evidence

1. **Objective:** prescribe execution order and later human-functional evidence.
2. **Current state inspected:** governance verification commands and prohibited commands for this design-only pass.
3. **Intended artifacts:** Implementer test output; Test Engineer screenshots/checklists/ZIP inspection/network evidence; no artifacts created during design.
4. **Bounded design:** Implementer runs focused tests after each bounded MSS, then full `npm test`, `npm run typecheck`, and `npm run build`. Packaged smoke and functional UI pass occur at the later authorized stage, not this design step. Test Engineer must independently:
   - select valid/invalid/mixed/duplicate/large files in W1;
   - inspect an actual non-dry repository and both ZIP, list exact paths, and byte-compare fixtures;
   - prove dry-run creates no ZIP/download request;
   - reload an autosaved draft and show ordinary fields restored, files absent, warning present, and successful reselection;
   - observe DevTools Network while selecting/removing/exporting and confirm no project content request; test offline;
   - exercise picker cancel, removal, keyboard-only flow, screen reader status, both themes, 320px/narrow and supported widths, 200% zoom, long/unicode names, and blocked download;
   - run desktop selection/copy/versioned-name regression and attachment-free W1 regression.
5. **Focused validation:** evidence matrix covers all backlog “Required evidence” items and supplemental §§30–31.
6. **Result:** complete verification plan.
7. **Deviations/findings:** do not represent Implementer self-tests as the independent functional audit.
8. **Status:** complete.

### MSS 7.3 — Implementation order and rollback units

1. **Objective:** remove undocumented choices from the Implementer handoff.
2. **Current state inspected:** architecture boundaries and supplemental implementation ordering.
3. **Intended files/artifacts:** exact ordered list in §9.
4. **Bounded design:** implement contracts/tests first, then export, persistence, UI, and synchronized docs. Each Sprint below is a coherent rollback/checkpoint unit; do not scatter CSS/docs before contracts stabilize.
5. **Focused validation:** order respects pure domain before host integration and prevents generated text from preceding archive-name resolution.
6. **Result:** ready for design gate.
7. **Deviations/findings:** none.
8. **Status:** complete.

### Sprint 7 consolidation

Automated and independent evidence together cover validation, byte identity, collisions, persistence loss, privacy/network behavior, desktop regression, accessibility, responsive behavior, dry-run, and real export. Implementation sequence is contract-first and checkpointed.

Sprint checkpoint: Sprint 7  
Objective: complete verification and delivery design.  
Micro-sub-sprints completed: 7.1–7.3.  
Files changed: design record only.  
Focused tests: acceptance-to-evidence mapping and implementation-order review.  
Results: design package complete.  
New findings: none.  
Residual risks: live browser differences and peak memory require Test Engineer evidence.  
Deviations: none.  
Ready for next sprint: Yes; Task ready for design-gate review.

## 9. Exact file-level implementation plan

Implement in this order; changes outside this list require Orchestrator classification before work.

1. `shared/domain.ts` — add `AttachmentMetadata`; retain path-bearing `Attachment`; change project attachment metadata type; add structured pure attachment-set validation and make `validationErrors` delegate to it; retain constants/allowlist and existing top-level error compatibility.
2. `src/types.ts` — export metadata type; define transient `WebAttachment` with `id` and Blob; keep Electron API return type path-bearing; update shared bridge/project types without optional/fake paths.
3. `tests/core.test.ts` — add boundary, extension-integrity, invalid-size, mixed-set, and total/count tests before integration.
4. `src/webExport.ts` — implement safe deterministic resolver, export projection with final names, and mixed text/Blob manifest; validate one-to-one sidecar; preserve fixed generated ordering and current attachment-free output.
5. `tests/webExport.test.ts` — add collision/path/order/provenance/prompt and unzip byte-equality fixtures; preserve current text/orchestration/tracking tests.
6. `src/types.ts` and both bridge implementations — extend the shared method to `execute(d: ProjectDefinition, s: Settings, transient?: { webAttachments: readonly WebAttachment[] }): Promise<ExecutionResult>`. `App` supplies the third argument only for W1. The Electron wrapper rejects a supplied transient argument as invalid host data and otherwise forwards the existing two arguments unchanged. This keeps Blob outside `ProjectDefinition` and avoids module-global hidden state.
7. `src/bridge/web.ts` — replace attachment rejection with user-gesture picker mapping; consume the explicit `transient.webAttachments` argument, revalidate, build mixed ZIP, preserve dry-run no-ZIP, catch ZIP/download-request failures, and keep bounded results.
8. `tests/bridge.test.ts` — remove picker from unsupported list; test mapping/cancel and dry-run/sidecar/error behavior with injectable/minimal DOM seams.
9. `src/draftStore.ts` — add schema-v3 stored type and pure stripping serializer; migrate v1/v2/v3; return count-only reselection notice; never write attachment metadata/bytes.
10. `tests/draftStore.test.ts` — inspect serialized payload and add migration/reload/phantom-source cases.
11. `src/App.tsx` — own live web sidecar/rejected rows; project accepted metadata; pass the explicit transient execute argument; implement picker admission/removal, phase/New draft cleanup confirmation, restored warning, exact final-name confirmation, dry-run/real messaging, focus/live-region semantics, and EN/ES copy. Keep desktop attach path behavior unchanged through host narrowing.
12. Existing component/UI test files (or one new focused attachment component test file if the current harness requires it) — add interaction, preservation, focus, warning, status, and localization tests. The Implementer must name any new test file in its Sprint checkpoint before creating it.
13. `src/styles.css`, `src/extras.css`, `src/responsive.css` — style only selectors actually needed by the attachment list using the `TASK-DESIGN-THEME` semantic tokens; include all states, wrap/narrow/zoom behavior, and reduced-motion compatibility. Do not add raw feature colors.
14. `electron/main.ts` — add/retain an explicit path-bearing attachment guard at the privileged copy boundary necessitated by the shared metadata split; do not alter desktop limits, picker, versioned naming, or copy semantics.
15. Existing desktop/file tests — assert path requirement and preserve byte/collision behavior.
16. `docs/SOP_WEB.md` — update capability, export contents, limits, local-only behavior, collisions, dry-run, and reload/reselection.
17. `docs/PRIVACY_POLICY.md` — implement the precise §7 distinction in English and Spanish; remove both contradictory/currently-future claims while preserving legal caveats.
18. `docs/WEB_ARCHITECTURE.md` — record transient sidecar, metadata projection, schema v3, resolver, and ZIP pipeline as implemented architecture.
19. `docs/FAQ.md`, `CHANGE_CONTROL.md`, and maintained Project Map/security/risk records — synchronize only statements directly affected by shipped W1 attachments and risks; do not edit category-D W2/desktop guidance as part of this Task.
20. Run focused tests throughout, then `npm test`, `npm run typecheck`, `npm run build`; hand off for the independent functional matrix in MSS 7.2.

## 10. Schema, migration, security, and regression summary

**Domain/schema impact:** `ProjectDefinition.attachments` becomes portable metadata; desktop attachment handles remain path-bearing; W1 Blob handles remain transient and outside the project/draft contract. Draft envelope moves from version 2 to 3 with stripped attachments and an optional count-only notice. Provenance schema version can remain 1 because `sourceFiles` stays `string[]`; its values become collision-resolved final basenames in W1.

**Migration:** v1 and v2 drafts retain all ordinary supported form fields, discard all attachment-shaped data, and optionally derive only a reselection count. No IndexedDB database/object-store version bump is needed because the stored envelope is value-versioned and the same key/store remains usable. Desktop has no persisted draft migration. Existing project signature consumers remain compatible.

**Security/privacy:** opaque bytes, local transient memory only, no upload/content logging/parsing/execution, authoritative extension/size/count validation, export-time Blob/metadata match, generated safe paths, no fake browser paths, no attachment identifiers/names in IndexedDB, and honest download/reload claims. Memory exhaustion remains bounded but not eliminated by 20/20 MiB/100 MiB limits.

**Test impact:** pure domain validation, resolver and binary ZIP tests; bridge/picker/error tests; serializer/migration tests; UI/accessibility/responsive/localization tests; full existing suite/typecheck/build; independent ZIP byte inspection, network observation, reload, offline, blocked download, and desktop regression.

## 11. Acceptance traceability and residual risks

| Backlog acceptance criterion | Design/evidence |
|---|---|
| Select, show name/size/status, remove, preserve form on error | MSS 2.2, 3.1; UI tests/live keyboard pass |
| Enforce 20 files/20 MiB/100 MiB/allowlist and explain | MSS 2.2; core boundaries and mixed-batch evidence |
| Non-dry repository/both includes byte-identical, deterministic collision-safe attachments and consistent text | MSS 4.1–4.2; unzip byte comparison and manifest/text/provenance assertions |
| Local-only; no upload/parse/execute/content log/remote dependency | MSS 2.3; offline and DevTools Network evidence |
| Honest dry-run and reload/draft behavior | MSS 3.2, 5.1–5.2; zero-ZIP and schema/reload evidence |
| Desktop and text-only ZIP regression safety | MSS 7.1–7.2; existing plus explicit regression tests |

Residual risks:

- `client-zip` plus browser Blob construction may temporarily exceed the nominal 100 MiB payload size. Mitigate with early caps, prompt reference release, busy feedback, and real-browser large-boundary testing; do not raise limits in this Task.
- Native file-picker cancel/focus events vary by browser. Use a fresh input and live Chrome/Edge plus one additional supported browser check; failure must leave state unchanged.
- User filenames can disclose information on screen and inside the intentionally exported ZIP. Do not persist or transmit them; the user explicitly selects and exports them.
- Browser download completion cannot be proven by anchor activation. Use bounded wording now and integrate with `TASK-EXEC-EVIDENCE` later.
- ZIP consumers can differ in Unicode/case handling. Collision comparison is normalized/case-insensitive and hostile path characters are removed; verify on Windows extraction as part of packaged functional evidence.

## 12. Open questions and design-gate verdict

No owner decision is required for implementation. The following are recorded for Orchestrator awareness, not blockers:

- Confirm the later `TASK-EXEC-EVIDENCE` design retains the bounded “download requested” wording rather than treating anchor activation as disk-save proof.
- Formal legal review of `docs/PRIVACY_POLICY.md` remains pending under its existing caveat; it does not block making the technical statements accurate.

Ready for design-gate packaging: **Yes**.
