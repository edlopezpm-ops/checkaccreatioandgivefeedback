# Faster Nebula, Layered Star Depth, and Responsive Glass

Owner authorization: Ed Lopez, 2026-08-05. Baseline: `7876673` on `main`.

## Governance and exact increment

This is a Full/high-risk governed increment because the complete product retains filesystem/Git preparation and optional human-gated AEKR orchestration. The change itself is presentation-only. The owner supplied explicit GO, required multi-agent orchestration, reserved Claude for the final independent audit, retained the zero-direct-cost rule, and limited testing for this increment to visual evidence.

In scope:

- double the autonomous Vanta fog speed in every product view;
- replace the synchronized star texture with a denser right-weighted three-depth procedural field;
- give every star a distinct smooth bounded path plus depth-scaled pointer parallax;
- make About narrower and fluid in fullscreen/split-screen;
- let the atmosphere show subtly through About and Home instruments;
- preserve the established typography families and hierarchy without introducing a font.

Out of scope: project/draft data, business flow, accessibility semantics, bridge/IPC, filesystem/Git/GitHub, Mode 1, dependencies, remote assets, telemetry, hosting, deployment, and paid services.

## Owner-requested AEKR provenance extension

Before the final audit, the owner extended presentation scope to the repository surfaces. The supplied full AEKR banner is stored once at `assets/aekr-banner.png` with `assets/AEKR-BANNER-LICENSE.txt`, rendered at the end of the root README for GitHub, and shown responsively beside the canonical-source note in the Project Map. The generator embeds the exact PNG bytes as a `data:image/png;base64` URI; the map therefore keeps its single-file `file://`, no-fetch, `img-src data:` contract. The banner is accessible non-interactive provenance, not a claim of certification and not an AEKR runtime dependency. The owner separately promoted this convention into AEKR's upstream project scaffold at commit `d872514719520735f19fa107d87f7ba3e18f4b9d`.

## Atmospheric motion

Vanta `FOG` remains the locally bundled nebula renderer. Its view speeds change by an exact factor of two:

| View | v4 | v5 |
| --- | ---: | ---: |
| Home | 0.28 | 0.56 |
| Creation | 0.22 | 0.44 |
| Review | 0.14 | 0.28 |
| Export | 0.24 | 0.48 |
| About | 0.22 | 0.44 |
| Quiet | 0.10 | 0.20 |

No other Vanta option, dependency, or input control changes. Reduced-motion/save-data/slow-update/hidden/missing-WebGL behavior remains fail-safe.

## Starfield architecture

One local 2D canvas renders stars before the translucent CSS/Vanta nebula planes, so stars read as spatially behind or within fog rather than pasted over the interface. This intentionally changes the invariant from “one atmosphere canvas” to “one bounded 2D star canvas plus one Vanta WebGL canvas.”

The star pool is produced by a fixed seeded pseudo-random generator. Resizing selects a stable prefix of the pool instead of reshuffling the sky. Normalized x positions use a power distribution below 1 and alpha grows toward the right; both mechanisms create a continuous right-to-left density falloff without a remote image.

Three planes establish depth:

| Plane | Relative amount | Radius | Organic box | Period range | Pointer maximum |
| --- | ---: | ---: | ---: | ---: | ---: |
| Far / small | Highest | ~0.4–0.8 CSS px | 2 mm | ~54–86 s | 1.5 px |
| Mid / medium | Medium | ~0.8–1.35 CSS px | 3 mm | ~38–62 s | 3.1 px |
| Near / large | Sparse | ~1.5–2.4 CSS px | 5 mm | ~26–44 s | 5.5 px |

Web CSS defines 1 mm as `96/25.4` CSS px; this is a reference unit, not a claim that every display renders a physically identical millimetre. The 2/3/5 mm values describe the total autonomous box centered on an anchor, so per-axis amplitudes are half those values. Parallax is a separate depth offset.

Each axis is a weighted sum of three sine/cosine waves with different frequencies and phases. Absolute weights sum to one, keeping motion inside its box while producing a smooth looping/gel-like path rather than a synchronized straight translation. Each star receives its own period and phases. Near stars move faster and farther than mid stars; mid stars move faster and farther than far stars.

The renderer:

- draws at no more than 30 fps;
- caps backing DPR at 1.5;
- scales visible population by viewport area within bounded limits;
- interpolates fine-mouse parallax and returns gently to neutral on blur/exit;
- stops its RAF while hidden;
- draws a static seeded frame for reduced motion, save-data, or slow-update;
- remains `aria-hidden`, `pointer-events: none`, and presentation-only.

## Responsive glass and typography

About uses `width: 100%` with a fluid maximum around 62rem and ordinary gutters. Its ultrawide 100rem exception is removed. Hero height and vertical gaps become content-led/fluid, and the three explanation steps use auto-fit so the card adapts to fullscreen, half-screen, narrow split, and mobile based on available space.

About and the Home/onboarding/creation instruments share a slightly more transparent local glass token backed by blur and the existing content-aware atmosphere scrim. The About hero and footer use the current `--brand-atmosphere` token; obsolete undefined theme-token names and stale legacy About overrides are removed.

The existing visual typography is preserved, not flattened:

- `--font-display`: editorial/product headings;
- `--font-sans`: body, navigation, controls, labels, and actions;
- `--font-mono`: technical counters and generated/code surfaces only.

No font is fetched or bundled. Stray literal overrides in the affected Home/About/header surface are replaced with existing scale tokens.

## Visual-only acceptance plan

Build is performed only to produce the inspectable artifact. No unit, integration, smoke, Lighthouse, or audit command from v4 is counted as v5 evidence by owner instruction.

Rendered inspection must cover:

1. Home 1920×1080, dark and light, at t0/t5/t10/t15 plus mouse corners;
2. Creation 1440×900, dark and light;
3. About 1920×1080, dark and light;
4. About ultrawide 2560×1440;
5. About split 960×1080 and narrow split 720×900;
6. mobile 390×844 and minimum 320×568;
7. 200% zoom representative desktop;
8. reduced motion, confirming a static star/fog composition.
9. Project Map at 1440×900 and 390×844, confirming the AEKR banner remains legible, subordinate, responsive, and adjacent to the canonical-source/footer information.

Acceptance is visual: approximately doubled but calm fog; greater star density on the right; three recognizable depths; larger/near stars moving farther/faster; distinct curved motion without visible synchronized lines; subtle background through readable instruments; no About overflow; preserved typography roles; no pointer interception; and a subordinate, collision-free AEKR signature.

## Security, cost, rollback, and audit

The new canvas receives viewport, time, theme, media-preference, and fine-pointer coordinates only. It has no project text, storage, bridge, filesystem, network, Git, credential, provider, or AEKR runtime access. No dependency or service is added; monetary cost is zero.

Rollback is source-only to `7876673`; no migration is required. Public release remains on hold. After implementation, rendered evidence, and documentation are committed and pushed, Claude must audit the complete pushed repository and applicable AEKR guidance from a fresh read-only context. It reports gaps without fixing them; Codex may then update documentation only as required.
