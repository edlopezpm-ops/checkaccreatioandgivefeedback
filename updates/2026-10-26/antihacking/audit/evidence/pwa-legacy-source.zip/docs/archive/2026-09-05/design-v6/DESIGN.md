# Typography Roles, Expanded Atmosphere Motion, and W1 Beta Release

Owner authorization: Ed Lopez, 2026-08-06. Existing project, Ruta A local-first, AEKR Full profile. The owner's “Modo AEKR. Full commit/deploy” is the sponsor GO for this bounded increment and for a zero-cost Cloudflare Pages beta release. No custom domain, paid service, analytics, backend, account, upload, hosted AI, or telemetry is authorized.

## Scope

This increment changes three bounded surfaces:

1. the typography role system across the application, static legal pages, and interactive Project Map;
2. the existing local two-canvas atmosphere's trajectory and speed;
3. the W1 static PWA's first zero-cost, access-restricted Cloudflare Pages beta deployment.

Project/draft schemas, business flow, IPC, filesystem/Git execution, credentials, Mode 1 semantics, attachment handling, and desktop packaging are unchanged.

## Typography contract

The exact owner-supplied tokens are:

```css
--font-brand: "Posterama", serif;
--font-heading: "Posterama", serif;
--font-body: "Inter", sans-serif;
--font-ui: "Inter", sans-serif;
--font-code: "JetBrains Mono", monospace;

--fw-regular: 400;
--fw-medium: 500;
--fw-semibold: 600;
--fw-bold: 700;
```

Role assignment:

| Role                                                                     | Family               | Weight |
| ------------------------------------------------------------------------ | -------------------- | -----: |
| Product mark/name, H1, H2                                                | Posterama stack      |    700 |
| H3, H4                                                                   | Inter UI stack       |    600 |
| Body, secondary text, forms, placeholders, footer, tooltips, table cells | Inter body stack     |    400 |
| Buttons and table headers                                                | Inter UI stack       |    600 |
| Top navigation, labels, badges, and chips                                | Inter UI stack       |    500 |
| Code, terminal, logs, and JSON/YAML/Markdown previews                    | JetBrains Mono stack |    400 |

Semantic HTML selectors own the default. Narrow component selectors override navigation buttons to 500 and product-name text to the brand family. Existing font sizes, hierarchy, line height, contrast, and responsive layout remain unchanged.

No Posterama, Inter, or JetBrains Mono binary is present in the repository or host. Posterama embedding rights have not been supplied. This increment therefore implements the exact authorized stacks without a remote font request or unlicensed asset. Browsers use the named local family when installed and the explicit generic fallback otherwise. The release must not claim pixel-identical Posterama rendering; a future self-hosted font increment requires owner-supplied webfont files and redistribution/embedding evidence.

The Project Map remains a restrictive-CSP, self-contained, zero-request artifact. It receives the same family and weight tokens but does not embed font bytes or relax `font-src 'none'`.

## Motion contract

All percentages are applied exactly to the current design-v5 values:

- Star autonomous drift radius and fine-pointer parallax: `×1.35`. Effective total CSS-mm reference boxes become 2.70 mm far, 4.05 mm mid, and 6.75 mm near.
- Nebula wrapper parallax by product variant: `×1.25`, with no integer rounding: Home 20 px, Creation 13.75 px, Review 8.75 px, Export 12.5 px, About 12.5 px, and Quiet 0 px.
- Star autonomous speed: `×1.15`, implemented by dividing seeded period duration by 1.15.
- Vanta autonomous speed: `×1.15`. Effective values are Home 0.644, Creation 0.506, Review 0.322, Export 0.552, About 0.506, and Quiet 0.230.

Reduced-motion, save-data, slow-update, hidden-page, missing/failed/lost-WebGL, coarse-pointer, frame-rate, DPR, area, density, security, and no-pointer-interception contracts remain unchanged.

## Validation

Before implementation, source-contract tests must fail on the new typography and motion expectations. After implementation:

- run unit/source-contract tests, Project Map parity, typecheck, format check, production build, Electron smoke, Project Map smoke, W1 browser smoke, Lighthouse, and dependency audit;
- inspect computed family/weight roles and representative dark/light Home, creation, About, legal, Project Map, mobile, reduced-motion, and pointer-extreme frames;
- keep Posterama fallback status explicit in evidence;
- require a concise fresh independent Claude review after the implementation/evidence commit is pushed.

The pre-existing CI regression where the light theme omitted the two new instrument-surface tokens is a release blocker and is corrected in this increment without changing their values.

The first green implementation run also exposed GitHub's Node 20 deprecation warning from the three official `actions/*@v4` workflow steps. Before freezing the audited release SHA, those steps move to their current official `v7` majors, which declare the supported Node 24 action runtime. Application dependencies and runtime behavior remain unchanged.

## Deployment

The owner's explicit 2026-08-06 release authorization amends DEC-009 only for a zero-cost W1 private beta on a Cloudflare Access-protected `*.pages.dev` origin. Custom domain, anonymous access, and broad promotion remain unauthorized. Deployment is allowed only after:

1. local full verification and independent review;
2. the exact release commit is pushed and GitHub CI is green;
3. the owner completes Cloudflare authentication, creates the empty `accreatio` Pages project, and configures Cloudflare Access for an owner-approved identity before any asset upload;
4. an unauthenticated request is verified to fail closed before the generated `dist` is uploaded;
5. the generated `dist` for that exact commit is deployed with no Functions, Workers, KV, analytics, upload, or server-side code;
6. authenticated and unauthenticated access, response headers, commit identity, first visit, local draft, ZIP export, legal links, offline reload, network egress, two-canvas/fallback behavior, Lighthouse, cost, and rollback are checked on the protected origin.

Direct Upload through an authenticated Wrangler session is acceptable for this beta because it keeps credentials outside the repository and does not require an unprotected release branch or committed deploy token. No asset may be uploaded until the Access policy is active and fail-closed behavior has been verified. The inferred project name is `accreatio`; if unavailable, deployment pauses rather than silently choosing a different identity.

The repository license permits use only by explicitly authorized persons and does not authorize anonymous publication. The Access-restricted audience therefore starts with the owner-approved identity only. Formal legal/trademark review remains an open risk before anonymous access or broad promotion. The beta legal pages must accurately disclose the actual static host and restricted status. First-release rollback is to disable the Pages project; later releases may restore a known-good deployment.

## Rollback

Source rollback returns to `c28036f0e8a6e208a4047c068798ff70a1677726`. No user-data migration is required. Deployment rollback disables the first beta or restores the last known-good Pages deployment. Browser drafts remain origin-bound and must be exported before any future origin change.
