# R0 checklist for the HOE — activate the Blog publisher and accept the portal

**For:** Ed Lopez (HOE). **Prepared by:** Claude, 2026-08-13.
**Governed by:** `docs/design-v9/HOE_SOPS.md` H-01 and H-03, and
`docs/design-v9/BLOCKER_RESOLUTION_DESIGN.md` D1.1. Those documents remain
authoritative; this is the operator-facing short form, not a replacement.

Nothing in this file can be delegated to an agent. Every step needs your
authenticated browser session, and the values you handle must never reach a
chat, a screenshot, a log, or a commit.

---

## Before you start

- [ ] The candidate commit is green (see `CHANGE_CONTROL.md` for the run ID).
- [ ] You can sign in to `https://accreatio.pages.dev`.
- [ ] A private/incognito window is available for the anonymous probe.
- [ ] Confirm the Cloudflare account is still on the free plan. **Stop at any
      upgrade or charge prompt** — that is a hard stop condition, not a
      judgement call.

---

## R0.1 — Human publisher (SOP H-01) · ~15 minutes

This is the single change that makes the Blog publishable. Both allowlists are
currently `{}`, so the server answers `canPublish: false` to everyone —
correctly, by design.

### Step 1 — obtain your Access user ID

1. [ ] Sign in to `https://accreatio.pages.dev` normally.
2. [ ] Open DevTools on that authenticated tab and request the documented
       identity endpoint on your team domain
       (`https://accreatio-pages.cloudflareaccess.com/cdn-cgi/access/get-identity`),
       using the session the browser already holds.
3. [ ] Read **only** `user_uuid`. Not `identity_nonce` — that is the most common
       failure in this SOP.
4. [ ] Close the response view.

> The `CF_Authorization` cookie that makes this call work must never be copied
> anywhere. Do not paste the full identity response into anything, including
> back to me.

### Step 2 — build the map locally

Construct this one-line JSON in a local editor. Shape only — substitute your
real values:

```json
{"your-email@example.com":{"sub":"YOUR-USER-UUID","label":"ed"}}
```

- [ ] Email lowercased, no leading or trailing whitespace.
- [ ] `sub` copied exactly — it is case-sensitive.
- [ ] `label` is `ed`; lowercase ASCII, 1–40 chars.
- [ ] Exactly these two properties. Any extra field fails the parser closed.

### Step 3 — set it

1. [ ] Cloudflare dashboard → Pages project `accreatio` → Settings → Variables
       and Secrets, **production** environment. Setting preview instead of
       production is the second most common failure here.
2. [ ] Change **only** `BLOG_HUMAN_ADMINS`. Do not touch
       `BLOG_ACCESS_ISSUER`, `BLOG_ACCESS_AUDIENCES`, `BLOG_AGENT_ADMINS`, the
       D1 binding, Access policies, branch controls, or deployment.
3. [ ] Save.

### Step 4 — verify without publishing

1. [ ] Reload the portal.
2. [ ] Inspect the session endpoint response only. Expect `canPublish: true`,
       actor kind `human`, label `ed`.
3. [ ] In a private window, without signing in, request the portal root.
       Expect HTTP `302` to Cloudflare Access.
4. [ ] **Do not publish anything.** First publication must be a real intended
       post, never a throwaway test.

### Send me back only this

```
production human-admin configured; label=ed; canPublish=true; anonymous=302; no publish attempted
```

### If it goes wrong

Set `BLOG_HUMAN_ADMINS` back to `{}`, reload, confirm `canPublish: false` and
that anonymous access is still denied. Preserve D1 — never delete rows as a
credential rollback. Stop and tell me if: a paid prompt appears, the identity
response has no `user_uuid`, the session response leaks raw identity, anonymous
access succeeds, or a policy/deployment changed that you did not change.

---

## R0.2 — Authenticated portal acceptance (SOP H-03) · ~30 minutes

Run this after R0.1. Use a clean browser profile with extensions disabled —
an extension will pollute the egress check and invalidate the gate.

### Functional

- [ ] Access login completes; Home renders.
- [ ] Blog shows **exactly three** founding posts; titles and order correct.
- [ ] `/api/blog/posts` returns authenticated JSON.
- [ ] Session endpoint returns the expected `canPublish` and safe actor data
      only — no raw identity.
- [ ] Dark/light toggle works on both Home and Blog.
- [ ] Wide and narrow viewports: no horizontal overflow, keyboard order sane,
      focus visible, announcements fire.
- [ ] Create a minimal project (non-sensitive sample text, no attachments, no
      GitHub/IDE/AI) and request the ZIP download.
- [ ] Blog and API traffic carries no project payload.
- [ ] Sign out via the documented Access logout route; confirm re-entry
      requires authentication.

### Headers

API JSON must carry `Cache-Control: no-store` and
`X-Content-Type-Options: nosniff`. Static responses must carry all of:

- [ ] `Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'`
- [ ] `Referrer-Policy: no-referrer`
- [ ] `X-Content-Type-Options: nosniff`
- [ ] `X-Frame-Options: DENY`
- [ ] `Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=()`
- [ ] `Cross-Origin-Opener-Policy: same-origin`
- [ ] `X-Robots-Tag: noindex, nofollow, noarchive`

### Egress

- [ ] Application, API, and service-worker requests go **only** to
      `https://accreatio.pages.dev`.
- [ ] Authentication traffic goes **only** to
      `https://accreatio-pages.cloudflareaccess.com`.
- [ ] Any other host fails the gate. Ignore browser-internal requests.

### Send me back only this

Booleans and counts per line above, sanitized header values, viewport/theme
labels, and request host/path/method. **Never** a HAR export, cookies,
authorization headers, JWTs, the identity payload, an OTP, your email, an IP,
post bodies, project content, or the ZIP.

---

## Deliberately not in this checklist

- **R0.3 Service Auth** (`H-02`) — needs two decisions from you first: which
  agents get a token (Codex only, Claude only, both as separate tokens, or
  defer), and the token duration (90 days proposed). Say the word and I will
  prepare the client contract; the secret stays with you and never reaches me.
- **Deployment.** Wrangler needs your Cloudflare login. Note `wrangler` is not
  on PATH on this machine — the repo-local `npx wrangler` is what the release
  runbook uses.
- **Anything that makes the portal public.** `docs/design-v9/ROADMAP.md` lists
  anonymous access and custom domains under the deferred/blocked horizon, and
  `README.md` records that `PRIVACY_POLICY.md` and `TERMS_OF_SERVICE.md` still
  need formal legal review before anonymous access or broad promotion. That is
  a separate product decision, not a step in R0.
