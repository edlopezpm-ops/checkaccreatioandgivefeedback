# Public Blog reading and explicit project sign-in

**Historical Access-login evidence:** [Own email OTP](OWN_EMAIL_OTP_2026-09-05.md) supersedes the product authentication, session bootstrap and account-route protection described below. Current sign-in verifies the email code inside accreatio. Public Blog reading, separate administrator permissions and local-draft preservation continue. Historical deployment and test results are retained as originally recorded.

Owner clarification, 2026-09-05: About and published Blog posts can be read without signing in. Only the administrator can create posts. This supersedes the earlier administrator-only reading interpretation in [SIGNIN_FLOW_2026-09-05.md](SIGNIN_FLOW_2026-09-05.md).

## Behavior

The sequence is `What you will make -> What stays local -> Sign in to start your project -> What is your project called?`. A verified existing application session opens the creator directly. An existing Access identity can create one application session when the creator gate becomes active. Otherwise the central button navigates to `/api/account/login`, where Cloudflare Access requests the email code. A verified human identity returns through a fixed `303 /?account=continue#new`; GET never creates an application session. The client consumes the return marker and uses a same-origin POST to establish its session. Missing identity does not trigger automatic navigation or reload loops.

The creator remains locked when authentication cannot be verified. Before leaving for login, pending draft persistence is flushed; a save failure keeps the page open for retry. Project draft fields stay in browser storage. Attachments remain transient and need reselection after navigation/reload. No email, token or project content is placed in the callback URL. The PWA navigation fallback excludes `/api/*` and `/cdn-cgi/*`, including login and logout, so a controlling service worker cannot replace them with the app shell.

The update prompt now activates the waiting worker before reloading. A previously installed client may still contain the old reload-only prompt handler: close all accreatio tabs and reopen once to activate the new worker. Do not clear site storage. Activation/reload is not forced on open drafts.

Blog posts load independently of the optional administrator capability request. A rejected or delayed admin request does not hide posts. Publishing still requires a cryptographically verified Access identity, the separate administrator allowlist and the existing mutation protections.

New project, Blog and About use compact navigation at the upper right, with 44px touch targets. The neutral Welcome badge is removed. Section changes settle over 440ms without remounting content; question/About scrolling is smooth. Reduced-motion preferences disable these transitions.

## Hosting scope and recovery

Only `archive-email-auth-preview.accreatio.pages.dev` has a public shell exception. Its `/api/account` and `/api/admin` paths are protected by the more-specific Access application `adf8c767-4d6e-46f3-84c4-74e829683e27`, using the existing approved preview member policy and OTP provider. Its cookie covers both API families. The exact-host public application is `999c8935-c0d9-4e5b-8709-4e1975297c78`. Historical immutable previews retain their wildcard Access protection. Account JWT validation accepts the scoped application audience and the existing wildcard preview audience.

Production deployment and credentials are unchanged. Restoring preview confidentiality means removing the exact-host public exception after confirming wildcard protection is present; preserve the protected child routes. Do not restore the broken sign-in client while retaining the public shell.

Sources checked: [Access path precedence](https://developers.cloudflare.com/cloudflare-one/access-controls/policies/app-paths/), [authorization cookie scope](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/), and [Workbox navigation fallback](https://developer.chrome.com/docs/workbox/modules/workbox-build/).

## Verification and delivery

API tests cover public published-only reads, administrator-only mutations, fixed verified callback, no GET issuance, and the account/quota protections. Browser tests cover the welcome order, explicit authenticator navigation, session continuation, public Blog with denied or pending administration, responsive navigation and reduced motion. Provider verification in local integration tests is simulated and distinguished from hosted acceptance.

An independent Chromium upgrade rehearsal built the actual prior app at `c0793dca9620e14d31a0685ac93b57a1ddb7287a` and this candidate. It reproduced the legacy reload-only prompt retaining a waiting worker and intercepting login, then verified that closing all origin tabs and reopening activates the candidate, preserves the saved IndexedDB draft, and sends login navigation to the network. Receipt and screenshots: `.local/logs/sw-upgrade-11rJ2N/`. This proves the documented one-time recovery, not automatic migration of already-open legacy tabs.

Real Chromium navigation to the hosted preview reaches the Cloudflare email-code form. Completing delivery and verification of a real email code still requires the owner's participation; no simulated identity is presented as a live OTP acceptance.

The requested kommiBo runtime cannot process this feature PR: its automatic lifecycle is not operational and its allowed mutation/repository scope excludes this patch. Delivery uses the documented two-identity pattern directly: PR author `edlopezpm-ops`, exact-head approval and merge by `edfortheblind`. This is not a kommiBo execution.

## Verified preview candidate

Source `80362c391888a1bafc18c06077c2ca1996bbeecc` deployed successfully as `a6446cfd-1356-49a2-9ffd-7e4e80295e6c` at [the preview alias](https://archive-email-auth-preview.accreatio.pages.dev). The outgoing deployment remains available under its immutable URL. Production remains `11235c8c-108f-46f3-8cce-fb88a144330b`.

- Full verification exit 0: `.local/logs/2026-09-05T21-03-11-887Z-verify-e62ba4c5-668e-4e2a-8a80-ac920b8aff21.log`. 245 tests, types, formatting, both builds, Functions build, branding, Electron/surface/project-map smoke, web/account Chromium and Lighthouse pass. Lighthouse performance/accessibility/best-practices: 96/100/100. SEO remains intentionally noindex. The optional upstream vendor-source comparison retains its known missing-local-checkout skip; pinned branding checks pass.
- Account browser/SQLite receipt: `.local/logs/account-ui-1788642301673/receipt.json`, including the active worker, callback, existing sessions, last-edit persistence, storage failure, five ZIPs and retry.
- Hosted Chromium receipt and screenshots: `.local/logs/live-signin-1788642427477/`. Anonymous shell 200, three public posts, no composer, zero page errors; account/session, account/authorize and admin/publish anonymous probes return 401. A second visit controlled by the worker still opens the actual Cloudflare email-code form.
- `npm audit --audit-level=high`: zero vulnerabilities. Separate review of the authentication and public Blog changes reports no remaining required fixes; legacy PWA recovery remains explicit above.

## CI footer exception authorized by the owner

Two CI runs timed out while observing an isolated footer tab through the original page's popup event. Local functional checks pass, and the second CI diagnostic confirms the expected destination was intercepted. The focused test now observes creation of the new browser-context page directly, retaining the exact URL, local receipt, null opener and unchanged parent checks. Both links pass locally. This changes the test only.

On 2026-09-05, Ed explicitly authorized a simple patch or ignoring this non-product-blocking failure. Approval and merge may therefore proceed without waiting for another CI cycle; this exception applies to the footer popup check and does not represent a green CI result. Production and the verified preview runtime are unchanged.
