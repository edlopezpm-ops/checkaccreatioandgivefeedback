# Historical prototype notes — accreatio Desktop

**Retired on 2026-10-22 by owner instruction.** The desktop prototype is obsolete, was never released, and will never be released. accreatio is web-only. There is no supported desktop download, build, execution or packaging workflow. See [the web guide](SOP_WEB.md) and [the web-only delivery record](WEB_ONLY_DELIVERY_2026-10-22.md).

The notes below preserve the earlier prototype's intended behavior and packaging instructions. They are historical evidence, not a current user guide or a claim that a desktop release occurred. Existing source, test receipts and archived packages remain in custody without deletion or reclassification as released products.

<details>
<summary>Preserved operating notes for the unreleased prototype</summary>

**Audience:** anyone using the accreatio desktop application to start or augment a governed project. This is a user guide, not a developer or support document — for internal troubleshooting, see `docs/TROUBLESHOOTING_WHITEPAPER.md`.

**Scope:** the Electron desktop application (Windows). For the browser/PWA edition, see `docs/SOP_WEB.md` — the two are the same product, different hosts, and behave differently in a few places noted below. The Blog, editorial publisher, Pages Functions/D1 client, and PWA registration are web-only and do not appear in this application.

## 1. What this application does

accreatio turns a project idea into:

- a canonical prompt you can hand to an AI assistant,
- a deterministic, previewed action plan,
- governance files (`AGENTS.md`, `PROJECT_PROMPT.md`, discovery notes, a local provenance signature),
- and, optionally, a local Git repository and/or a GitHub remote.

It does not use AI itself, does not send your project data anywhere, and does not require an internet connection except for the optional GitHub steps you explicitly enable. It does not read or publish Blog posts and never connects to the web editorial API or D1.

## 2. Getting the application

You will normally receive a portable Windows executable named `accreatio-<version>-portable.exe` (for example `accreatio-0.8.0-portable.exe`). It requires no installer:

1. Place the `.exe` anywhere you have write access (e.g., `Desktop` or a `Tools` folder).
2. Double-click it to launch. Windows SmartScreen may warn about an unrecognized publisher on first run — this is expected for an unsigned build; click "More info" → "Run anyway" if you trust the source you received it from.
3. No installation, registry changes, or admin rights are required.

## 3. First launch — one-time setup

Before creating your first project, open the **Configuración** (Settings) tab and set:

| Field                                      | What it's for                                                                                                  |
| ------------------------------------------ | -------------------------------------------------------------------------------------------------------------- |
| **Carpeta de proyectos** (Projects folder) | Default destination suggested for new dedicated-repo projects.                                                 |
| **Toolkit**                                | Path to your local copy of the governance/toolkit templates this project references.                           |
| **future_projects**                        | Path used for tracking-only entries (see §5, Action). Required if you ever select "Crear tracking" or "Ambos." |
| **Rama inicial** (Initial branch)          | Default Git branch name used when accreatio initializes a repository (e.g., `main`).                           |
| **IDE**                                    | VS Code or File Explorer — what "Abrir proyecto" opens at the end of a run.                                    |
| **Idioma / Language**                      | Spanish or English UI.                                                                                         |
| **Tema / Theme**                           | Dark or light.                                                                                                 |

Click **Guardar cambios** (Save changes) after editing. Settings persist across restarts in your Windows per-user app-data folder — no account or sign-in involved.

**GitHub (optional):** further down the Settings page, accreatio shows whether GitHub CLI (`gh`) is installed and authenticated. If it's installed but not connected, a **Conectar GitHub** button starts `gh`'s own device-code sign-in flow in your browser. accreatio never sees or stores your GitHub password or token — the GitHub CLI and your OS credential store manage that entirely.

## 4. Creating a new project, step by step

Go to the **Nuevo proyecto** (New project) tab.

On first use, a two-step welcome explains the output and local-data boundary. It has one guided path: **Continue**, then **Finish and create**; there is no Skip action. The header logo/name always returns to this home/welcome surface. The creation experience is organized into five reversible stages—Foundation, Context, Team, Delivery, and Review—rather than a permanent one-page form. The fields below retain the same meaning and appear in the corresponding stage. Dark and cool ice/lavender light themes share the same behavior. The local atmosphere normally combines one deterministic Canvas2D star field with one first-party procedural WebGL nebula canvas. Three right-weighted star depths move at subtly different rates and respond gently to a fine pointer. Reduced motion, save-data/slow-update settings, or a hidden window retain one static star canvas and omit WebGL. Missing, failed, or lost WebGL also omits that canvas while the bounded stars can continue moving unless another constrained state applies. None of these states affects a project operation. The renderer receives only viewport, time, theme, media-preference, and fine-pointer state—never project data, storage, IPC, network, Git, or credential input.

1. **Nombre del proyecto** (Project name) — required. This becomes the folder/repo slug (lowercased, hyphenated).
2. **Fase actual** (Current phase) — Idea, Discovery in progress, or Discovery complete.
3. **Fuentes de discovery** (Discovery sources) — only shown once phase is not "Idea." Attach up to 20 files (Markdown, TXT, PDF, DOCX, JSON, YAML, CSV, PNG, JPEG; 20 MB each, 100 MB total). Files are copied opaquely — never parsed, executed, or modified.
4. **Contexto conocido** (Known context) — required. What, for whom, and why.
5. **Restricciones** (Constraints) — optional free text.
6. **Ruta** (Route) — A (local-first), B (vendor-managed), or Mixed. This is recorded in the generated prompt/governance, not enforced by the app.
7. **Agentes planificados** (Planned agents) — 1 to 4 roles (Generalist, Architect, Implementer, Auditor), each usable once. This is what a human or AI assistant reads later to know who's meant to do what — it does not itself invoke any AI.
8. **Orquestación AI (opcional)** — leave this off unless you specifically want to prepare AEKR Mode 1 orchestration for this project. See §7 below; the safe default is off (Mode 0 — you coordinate manually).
9. **Acción esperada** (Expected action):
   - **Crear tracking** — writes only a status note under your configured `future_projects` path. No dedicated folder/repo.
   - **Crear/usar repo** — creates (or augments) a dedicated project folder at Destination.
   - **Ambos** — does both.
10. **Carpeta destino** (Destination folder) — required for Repo/Both. Type a path directly or click **Elegir** (Browse) to pick one via a native folder dialog.
11. **Toggles**: Dry-run (on by default — recommended for your first run in a new destination), Inicializar Git, Crear en GitHub, Abrir IDE. GitHub/IDE require Git to be enabled and require Route ≠ tracking-only.

During the first four stages, **Project summary** provides a compact contextual view. The complete generated prompt, deterministic plan, paths, and confirmation appear together in **Review**. Nothing is written to disk until you confirm.

## 5. Reviewing and running

1. Click **REVISAR Y EJECUTAR** (or **START**) — disabled until all required fields validate (red text shows exactly what's missing).
2. The confirmation modal identifies **Dry run** or real creation and lists the planned destinations and items. Tracking shows its configured `future_projects/<slug>` directory and version-protected `PROJECT_STATUS.md`; Repository shows the dedicated project root and generated/source set; Both shows both destinations.
3. Use **Run dry review**, **Create tracking**, **Create repository**, or **Create both**, as shown, or cancel to adjust the definition. Dry run creates no directory, file, history entry, remote, or IDE launch.
4. The result panel names the outcome and exact paths returned by each versioned write/copy. “Produced items” is app-reported local evidence; inspect those files for final verification. Absolute paths may contain your username, so redact them before sharing screenshots or diagnostics.

While execution is in progress, the confirmation controls remain visible but disabled. Repeated mouse or keyboard confirmation is treated as the same logical operation and cannot create another artifact/history entry. After completion or failure, returning to Review and confirming again is an intentional new run and may create normal `(1)` versioned files.

**If the destination already contains files**, accreatio never overwrites them — it writes a versioned copy instead (e.g., `AGENTS (1).md`). A hard failure on an existing _root_ target is intentional, not a bug — see the Troubleshooting Whitepaper if this surprises you.

If a later step fails after files, tracking, Git, or a GitHub remote were created, the result says **Some work completed**, separates Completed from Not completed, and retains every known destination. accreatio does not delete or roll back completed work. Inspect it before deliberately returning through Review; a fresh run does not resume and may create another versioned copy.

## 6. After running: History and provenance

The **Historial** (History) tab lists your last 50 executed projects (name, path, timestamp) — purely local, no cloud sync. Every dedicated-repo project also gets a `.accreatio/project.json` file recording what was planned and when, for your own reference later. The web portal's persistent Blog is not imported, cached, or shown in desktop history.

## 7. Optional: AI orchestration (Mode 0 vs. Mode 1)

By default, every project is **Mode 0**: you coordinate any AI assistants yourself, manually, using the generated prompt. Nothing about this requires the toggle in §4.8.

If you open **Prepare Mode 1 configuration**, a dialog lets you assign each planned participant a local provider (`claude_code` or `codex`) and an editable task, and set four separately named execution limits: maximum session duration, maximum iterations per entity, maximum provider invocations, and maximum consecutive failures (not an automatic-retry count). Saving persists the configuration in the project definition; `.ai-engineering/orchestration.yaml` is written into the generated project later, when you execute a real Repository or Both action. Two things to know:

- **"Check providers"** only works in the desktop app (this is the one meaningful behavior difference from the web edition) — it verifies whether the `claude`/`codex` CLIs are actually installed and authenticated on this machine before you rely on them. A provider marked with a warning icon (⚠) is not currently usable.
- The generated `orchestration.yaml` is **ready to review, not authorization to run**. accreatio supplies deterministic role-specific tasks without AI; review or edit every task before invoking AEKR. Running the file requires a separate local AEKR checkout; P5 is deferred, so accreatio itself does not launch or manage the orchestration run.

If you don't recognize any of the above, leave orchestration off — it changes nothing else about how the tool works.

## 8. Quick reference — status bar

The footer always shows: readiness, your configured projects folder, Git/GitHub connection state, and a reminder that no AI or cloud dependency is active for the desktop app itself.

## 9. If something goes wrong

Common, expected situations (not bugs):

- **"Corrige las validaciones"** on the main button — a required field is empty or invalid; check the red text under each field.
- **Destination exists** and the run stops — expected safety behavior, not a crash.
- **GitHub button does nothing after clicking Connect** — the device-code flow opens in your default browser; check for a window/tab that may have opened behind others.

For anything else, or to report a real problem, contact support with the exact error message shown in the result panel's log — see `docs/TROUBLESHOOTING_WHITEPAPER.md` (support-facing) for the full diagnostic process.

---

## Resumen en español

accreatio desktop convierte una idea de proyecto en un prompt, un plan de acciones, archivos de gobernanza y, opcionalmente, un repositorio Git/GitHub local. Es un ejecutable portable sin instalador. Antes del primer proyecto, configura carpetas y GitHub en "Configuración". Para crear un proyecto: completa el formulario en "Nuevo proyecto" (nombre, fase, contexto, agentes, acción, destino), revisa la vista previa, confirma y ejecuta. accreatio nunca sobrescribe archivos existentes — crea copias versionadas. La orquestación AI es opcional y queda apagada (Mode 0) por defecto; si la activas, "Verificar proveedores" solo funciona en desktop. El historial es 100% local. El Blog y la administración editorial existen únicamente en la web y no forman parte del paquete Electron. Ante un problema, revisa el mensaje exacto en el panel de resultado antes de contactar soporte.

</details>
