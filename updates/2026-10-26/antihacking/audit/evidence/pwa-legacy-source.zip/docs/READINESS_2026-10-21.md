# accreatio — implementación y readiness · 2026-10-21

## Aviso de vigencia — entrega final 0.9.1

La entrega vigente es **0.9.1**, desplegada en
[accreatio.com](https://accreatio.com/) desde la fuente
`a16c53dba5c29c5da15ff31e9f41d5a7610ad7d1`. El
[recibo de entrega final](FINAL_PRODUCT_RELEASE_2026-10-21.md) registra el
despliegue, readback y alcance actual. La autoridad vigente es la instrucción
del propietario de entregar el producto final mediante IA, sin un gate de
release o UAT humano adicional.

Verificación integral: **387/387 PASS**, builds y smokes aprobados;
Lighthouse **97/100/100/69**. El recorrido UI combinado registró doce casos
PASS y después un timeout en WebKit; la reproducción dirigida sobre el mismo
asset pasó. La causa del timeout no está demostrada. No se convierte esta
evidencia en OAuth personal, controles/exportación de producción con una sesión
personal de proveedor ni Safari en un iPhone físico. Son límites de evidencia,
no condiciones pendientes para esta entrega final.

El cuerpo que sigue conserva el **checkpoint histórico 0.9.0 y su matriz
R01–R12**. Sus estados, bloqueos, acciones humanas y criterios de aceptación
corresponden a aquella etapa; no describen ni gobiernan la entrega final actual.
Los hechos y recibos históricos se mantienen sin reescribirlos como pruebas
posteriores.

## Inicio del registro histórico 0.9.0

Estado global: **0. NO COMPLETADO — EN CURSO O BLOQUEADO**.

## Versión vigente: botones corregidos

La petición posterior de Ed sobre botones pegados/desalineados quedó aplicada:
Google y GitHub comparten ancho y altura, separados 12 px; en móvil se apilan.
Los detalles y las instrucciones quedan separados 20 px. Se conserva el logo,
fuente y espaciado de Google, sin cambiar la autenticación.

Código vigente: `97f0b485c14374ebb9711015b8f2914578f83cb9`.
Deployment `434eef0b-6693-46c1-a789-d356d4b37e25`, completado el
2026-10-21 a las 16:07:42 UTC en [accreatio.com](https://accreatio.com/).
Bundle `index-BO-vhWup.js`, 488442 bytes, SHA-256
`7fd03978c22af76fe65b3ad9020e82292899794019113f571160876e8e0e5470`:
readback de producción idéntico al build final. La diferencia de árbol no
versionada al desplegar era exclusivamente documental; el producto estaba limpio.
Google/GitHub disponibles, OTP deshabilitado, métodos no-store y rutas/avisos 200.
Sin nuevas migraciones ni cambios de datos tras 0006.

La suite completa volvió a terminar con exit 0: 355/355, builds, smokes y
Lighthouse 96/100/100/69 (noindex). Recibo
`.local/logs/2026-10-21T16-04-47-541Z-verify-5b7242e8-d5b5-4111-aa44-1717ed014ec4.log`.
Diagnóstico visual ES/EN: 1280 px, dos botones de aproximadamente 250×44 px;
390 px, 262×44; 320 px, 246×44; gap 12 y cero recortes/desbordamiento.
El navegador integrado confirmó la disposición en producción. Evidencia:
`provider-buttons-smoke.json`, `production-buttons-aligned.png` y
`production-hosted-readback.json`.

El check de muestras también se hizo reproducible tras nuevos commits: usa la
revisión registrada para comprobar y HEAD al generar, validando los hashes
actuales de fuentes. Las muestras regeneradas solo cambian el campo
`sourceRevision` de `.accreatio/project.json` a `357d297`; instrucciones,
adjuntos y demás entradas son byte-idénticos, al igual que las propuestas R11.
ZIP básico actual: 19635 bytes, SHA
`bbf72008cecfdf648718ba85c86f1e234e14877f2c5c2d33b56f21b2d9225b57`;
producción lo sirve idéntico. Véase `examples-stable-diff.json`.

Los recibos siguientes conservan los hitos previos. El estado global y las
pruebas personales pendientes no cambian por una corrección visual.

## Primer despliegue de producción por autorización directa

Ed indicó: «deployea en el link .com y ya, no es un banco virtual so we should
be good». Se publicó el mismo código probado en [accreatio.com](https://accreatio.com/),
deployment `3027a9b5-f62e-4f68-99eb-45731f06a630`, completado el
2026-10-21 a las 15:53:03 UTC. No se retiró Cloudflare Access de previews.
La autorización de despliegue está concedida; no queda pendiente solicitarla.

Código: `0dec26d9fc299e8612b32fd8b93f090361cc25cc`. Bundle servido
`index-CbFRb9nV.js`, 488184 bytes, SHA-256
`b3007c5b6cc7f106cda2b1bdf8df51d17b6f86ca074750351e4d82413456c5b7`,
idéntico al build final probado localmente. El management readback confirma
el SHA y el D1 de producción correcto. `/api/auth/v1/methods` responde 200,
`no-store`: Google y GitHub disponibles, OTP deshabilitado. About ES, Blog EN,
avisos legales y manifiesto de ejemplos responden 200; versiones legales 10-21
presentes. ZIP público básico idéntico a los 19635 bytes validados, SHA
`abb8a7bea2be1ee3630d6485e9e95003027870819c6f8e03f93d52e5a763a733`.

El navegador integrado mostró la bienvenida nueva, el ejemplo expandido y ambos
botones de proveedor. La navegación inicial sirvió el shell antiguo de caché;
la siguiente recarga activó el nuevo sin borrar datos del navegador. No se usa
el shell antiguo como prueba del candidato. Evidencia: `production-hosted-readback.json`,
`production-google-github.png` y `production-welcome-example.png`.

Se conservó el D1 de producción existente y se aplicó únicamente `0006`.
Backup protegido restaurado en SQLite aislado, integridad ok/cero errores FK;
comparación antes/después de todas las columnas/filas originales aprobada:
dos cuentas/dos identidades, un recibo de autorización y uno de cuota, cero
sesiones/transacciones. No se fabricó aceptación ni se descifraron datos.
El mantenimiento de producción existente se conserva; no se bifurca el ledger.
Evidencia: `production-preservation-before.json`, `production-preservation-after.json`.

**Último hito actual: producción publicada y smoke público aprobado.** Quedan
sin ejecutar OAuth real, enlaces/controles reales, exportación autenticada desde
la UI de producción y Safari/iPhone físico. No se aceptaron Términos ni se
otorgaron permisos personales por el usuario. El ZIP público no sustituye la
exportación autenticada requerida. Por eso R04/R05/R07/R09/R10/R12 y el estado
global no se convierten en PASS/estado 3. La matriz detalla sus subpruebas.

## Recibo del candidato y preview

Código probado y versionado: `0dec26d9fc299e8612b32fd8b93f090361cc25cc`.
Preview desplegada el 2026-10-21 15:45 UTC, ID
`176390b5-2148-4010-8bac-de88f2b592c9`, estado del proveedor `success`:
[alias controlado](https://google-oidc-preview.accreatio.pages.dev/).
El readback de API confirma ese SHA y el binding D1 aislado nuevo. El indicador
`commit_dirty=true` corresponde exclusivamente a documentación pendiente de
commit; no existen cambios de código fuera del candidato desplegado.

GitHub se habilitó inicialmente solo en **preview**; posteriormente se activó
en producción mediante la autorización y el recibo anteriores. La inspección HTTP y el navegador
integrado encontraron Cloudflare Access solicitando acceso del propietario.
La UI antigua vista inicialmente provenía de caché: no se usa como prueba del
candidato nuevo. No se retiró Access ni se copiaron cookies/tokens para sortearlo.
Hasta completar ese acceso, el deployment exitoso no prueba el smoke hosted,
las capacidades efectivas ni OAuth real. Recibo: `preview-hosted-readback.json`.

El recibo anterior identifica el último hito y sus límites. Las pruebas locales y el despliegue público no sustituyen los recorridos autenticados pendientes.

## Baseline, alcance y autorización

Repositorio privado real `edlopezpm-ops/accreatio`, rama inicial `main`, HEAD
`70612512e2115036fa71a08075a596a04bbff942`, versión 0.8.0. Rama de entrega:
`codex/readiness-2026-10-21`. El árbol inicial solo tenía `PRIVACY.md` y los
informes/dossier no versionados de 2026-10-20; se preservan fuera del commit.
El dossier público es documentación separada, no el código de la aplicación.

Encargo: prompt maestro del propietario 2026-10-21, secciones 1–12, C01–C64 y
R01–R12. Arquitectura conservada: React/TypeScript/Vite; Pages Functions; D1
separados para cuenta y Blog; ZIP en navegador. Electron sigue congelado.
Commits/pushes autorizados por AGENTS.md. Ed autorizó configurar las Apps GitHub
y aprobó los textos/versiones propuestos. Completó personalmente la verificación
de acceso GitHub. Eso no acepta la release ni presta consentimiento OAuth o
a Términos en nombre de una cuenta de prueba.

| Observación inicial                                      | Revalidación y disposición                                                        |
| -------------------------------------------------------- | --------------------------------------------------------------------------------- |
| START imponía orquestador y faltaba contexto de proyecto | Reproducida en generador; corregida con modo básico autónomo y contexto explícito |
| Referencias normativas ausentes                          | Reproducida; contratos y referencias básico/avanzado probados con ZIP reales      |
| Guardado diferido y posición sin persistencia            | Reproducida en fuente; corregida; edición/recarga a 103 ms y fallos I/O probados  |
| Revisión truncada y decisiones repetidas                 | Reproducida; texto completo, cinco preguntas y una elección de acción             |
| FAQ OTP, escritorio activo y Blog móvil                  | Reproducida; ES/EN reconciliados e historia fechada preservada                    |
| GitHub y conexión explícita                              | Ausente; implementado con GitHub App, PKCE y prueba por acción                    |
| Google/producción actuales                               | Recibos históricos identificados; no acreditan este candidato                     |

## Matriz única R01–R12

PASS exige evidencia del entorno requerido. Un PASS local no cierra un gate
que requiere proveedores o producción reales. Evidencia operativa bajo
`.local/logs/readiness-2026-10-21/`; nunca se publica el respaldo privado.

| ID  | Criterio                                                          | Versión / entorno                                             | Método y evidencia ejecutada                                                                                                      | Resultado | Acción pendiente                                                                                             |
| --- | ----------------------------------------------------------------- | ------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------------------------------------------------------ |
| R01 | Base, alcance, instrucciones, candidato y entornos                | 97f0b48 / repositorio y destino real                          | Baseline, Git, runbooks; deployment 434eef0b; producción sirve bytes del build probado                                            | PASS      | Ninguna en identificación del candidato                                                                      |
| R02 | Referencias, contexto, fase, decisiones y adjuntos fieles         | 97f0b48 / local y muestra pública de producción               | ZIP de 21/27 entradas; bytes/contratos, integrated-functional.json y export-load.json; sample prod idéntico                       | BLOCKED   | Falta ZIP básico generado desde UI autenticada de producción                                                 |
| R03 | Básico sin runtime; avanzado autocontenido                        | 0.9.0 / ZIP locales reales                                    | Básico ES y avanzado EN; licencia/procedencia, configuración única y dependencias explícitas                                      | PASS      | Ninguna en contrato local                                                                                    |
| R04 | Identidad estable, PKCE/state, proveedores reales y conexión      | 97f0b48 / SQLite, workerd/D1, UI sintética y capacidades prod | 107 regresiones específicas, enlaces ambos sentidos/fallos; Apps configuradas; métodos Google/GitHub true en .com                 | BLOCKED   | OAuth real, enlaces y controles no ejecutados; consentimiento personal pendiente; preview Access bloqueada   |
| R05 | Conservación Google, cuota común, controles, borrado y migración  | 97f0b48 / local y D1 remoto preview/producción                | Concurrencia/retry/datos/borrado locales; migraciones preview 5/6 y prod 6; preservación exacta y cero backfill                   | BLOCKED   | Migración PASS; falta verificar cuenta/cuota/controles con proveedores reales                                |
| R06 | Último cambio/posición, adjuntos, multitab y guardado honesto     | 0.9.0 / Edge, Firefox, WebKit locales                         | integrated-functional.json; 6 regresiones de storage, schema futuro y borrado obsoleto                                            | PASS      | No constituye backup entre dispositivos                                                                      |
| R07 | Revisión, acción única, comprobación, continuación y retry exacto | 97f0b48 / UI local y entrada pública prod                     | ES/EN, ZIP real, instrucción compartida, mismo blob/operation ID; dry-run sin cuota/ZIP; acceso publicado                         | BLOCKED   | Local PASS; completar recorrido autenticado en .com                                                          |
| R08 | C01–C64, ejemplo real y documentos coherentes                     | 97f0b48 / fuentes, build y producción pública                 | Copy ES/EN, sample prod idéntico, avisos aprobados 10-21 publicados, smoke legal/público                                          | PASS      | Aprobación/publicación no equivale a revisión jurídica formal                                                |
| R09 | Matriz declarada, foco/teclado/zoom/contraste y compatibilidad    | 0.9.0 / navegadores reales y emulación identificada           | Edge155.0.4283.62, Firefox153.0, WebKit26.5; 320/390/720/1280; 200%, reflow, movimiento reducido; contraste4.665:1                | BLOCKED   | Falta recorrido Safari en iPhone físico anunciado; Ed debe ejecutarlo                                        |
| R10 | Rutas, recarga, idioma, callbacks, caché y migración              | 97f0b48 / local y producción; preview Access                  | Local query URLs/Back/Forward/Blog/retorno sin lang/SW PASS; .com rutas 200 y frontend actualizado tras recarga                   | BLOCKED   | Falta callback real y recorrido de cuenta autenticada; preview no se declara verificada                      |
| R11 | Handoff aislado produce primera acción útil                       | 97f0b48 / paquetes reales básico/avanzado                     | Agente sin contexto produjo problem-proposal de 3323/4482 bytes; 18/33 referencias locales resueltas; sample básico prod idéntico | PASS      | R02/R12 conservan exigencia de exportación autenticada prod                                                  |
| R12 | Candidato aceptado, release, rollback y ZIP prod                  | 97f0b48 / .com, deployment 434eef0b                           | Deploy autorizado/success, bundle final idéntico, migración/backup/restore aislado PASS; fallback compatible preparado            | BLOCKED   | Despliegue ya autorizado/ejecutado; faltan ZIP autenticado, controles reales y aceptación final de criterios |

Matriz declarada antes de probar: Chromium/Edge Windows real; Firefox/WebKit
Playwright; móvil390×844 y reflow320CSSpx; zoom200%, movimiento reducido, ES/EN.
Se conserva el soporte móvil anunciado. WebKit/emulación no acredita iPhone
físico: no se reduce el criterio para obtener PASS.

## Verificación y límites

`npm.cmd run log -- verify`: **exit0**, 355/355 pruebas, mailer, branding
(cuatro pins), Blog seed, ejemplos, mapa, tipos Cloudflare, typecheck, formato,
Functions build, web/desktop build, fronteras, smoke Electron, mapa, web,
cuentas, identidad y Lighthouse. Recibo canónico:
`.local/logs/2026-10-21T15-38-11-245Z-verify-9bd10e53-848c-40c0-a41a-da53563e82af.log`.
El check del origen AEKR externo se omitió por checkout no disponible, según su
script existente; payloads vendorizados, licencia y ZIP sí se comprobaron.

Lighthouse local: rendimiento96, accesibilidad100, prácticas100, SEO69.
El gate existente permite el noindex de beta privada; no es SEO90 ni
certificación WCAG. `npm audit --audit-level=high`: exit0; 0high/critical,
8moderate en dependencias dev de empaquetado Electron congelado sin cambios.
No se aplica el downgrade forzado ni se afirma ausencia de vulnerabilidades.

`readiness-functional-smoke.mjs` usa UI real, APIs de fixture y ZIP real.
No suplanta consentimiento/login real. `readiness-export-load-smoke.mjs`:
100MiB (20×5MiB), generación372.9ms, máximo intervalo timer17ms; 20MiB,
76.8ms y25.3ms. Los21adjuntos coinciden byte/SHA-256; teclado/render respondieron.
Sin benchmark previo ni generalización a otros dispositivos.

Las cifras de carga y la recarga medida a 103 ms pertenecen a las ejecuciones
locales anteriores identificadas en sus JSON (bundle de carga `index-CfNKP_Lr.js`).
No se presentan como nuevos tiempos medidos del bundle final `index-BO-vhWup.js`.
El generador de proyecto y las instrucciones permanecen idénticos; la suite
completa final sí volvió a ejecutarse sobre el candidato vigente.

[Revisión independiente](READINESS_DIFF_REVIEW_2026-10-21.md):
1P1 y6P2 cerrados/revalidados; ningún otro hallazgo accionable observado en
ese alcance. No es aceptación humana ni auditoría universal.

## Configuración y custodia ejecutadas

GitHub App preview `accreatio-preview-identity` (5412791, owner-only) y producción
`accreatio-web-identity` (5412799, pública). Solo emails:read; sin webhook,
comodines, permisos de repositorio/organización ni instalación. Callbacks exactos
y cuatro bindings por entorno configurados; valores fuera de fuente/logs.
[Runbook de identidad](GITHUB_IDENTITY_ACTIVATION.md).

Se inventariaron runtimes antiguos. El origen OAuth fijo no impide que un
writer antiguo con el mismo D1 desconozca la prueba por acción. Se creó
`accreatio-accounts-readiness-preview`, restaurando el snapshot protegido1–4
del preview previo y aplicando5/6. Se preservan todos los campos/filas originales:
dos cuentas/dos identidades, cero sesiones/transacciones/recibos de cuota;
cero policy receipts fabricados, integridad ok y cero errores FK. No se muestran
ni descifran payloads. D1 anterior intacto; solo nuevos despliegues compatibles
reciben binding nuevo.

Mantenimiento preview apunta al nuevo D1, versión
`36970b73-ea3b-4267-8266-028f9e38aa36`, cron horario existente. Producción,
Blog, claves de privacidad y Google preservados. Backup restaurado también
en SQLite local aislado; ninguna restauración de producción.

## Release, fallback y acciones humanas

[Runbook y textos aprobados](READINESS_RELEASE_2026-10-21.md).
Versiones `2026-10-21-privacy` / `2026-10-21-beta`, finalidad `account-core-v1`.
C39 refleja que dry-run no construye ZIP; C45 aclara que tampoco se guardan
nombres. Retry usa recibo servidor y blob en esta pestaña; sin prometer guardado
físico ni almacenamiento48h. Licencia privada app conservada; MIT literal de
plantillas incluida con procedencia y sin conceder marcas/material de terceros.

Fallback preparado: desactivar GitHub conservando0006 y backend compatible;
sin DROP/RESET, rotación de claves o borrado de identidades. Nunca revertir al
writer anterior sobre cuentas enlazadas. No se ejecutó fallback/restore prod.

Pendientes: consentimiento/pruebas reales de proveedores, Safari/iPhone físico,
aceptación final y comprobación autenticada de producción. La promoción ya fue
autorizada y ejecutada. No faltan Client ID/secret
GitHub ni autorización de textos. Tras cerrar gates, observar5–8usuarios con
consentimiento y sin telemetría nueva es aprendizaje recomendado, no obtenido.
