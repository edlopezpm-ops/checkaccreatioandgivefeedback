import type {
  ExecutionHost,
  ExecutionPreview,
  PlannedAction,
  PlannedArtifact,
  ProjectDefinition,
  Settings,
} from "./types";
export {
  ACCEPTED_EXTENSIONS,
  MAX_PARTICIPANTS,
  MIN_PARTICIPANTS,
  allocateParticipantId,
  MAX_FILE_BYTES,
  MAX_FILES,
  MAX_TOTAL_BYTES,
  validateAttachmentSet,
  discoveryMd,
  defaultRoleTask,
  generatePrompt,
  governance,
  projectSignature,
  renderOrchestrationConfig,
  slugify,
} from "../shared/domain";
import { slugify, validationErrors } from "../shared/domain";
import { exportManifestPaths } from "../shared/exportManifest";
export { buildExportManifest } from "../shared/exportManifest";
export const validateProject = validationErrors;
// The export is the product, so its file list lives in one shared manifest
// rather than being restated per host. SETUP.md is the single browser-only
// addition: it renders the git/GitHub/IDE steps a page cannot perform.
export const generatedArtifactPaths = (
  p: ProjectDefinition,
  host: ExecutionHost,
  s?: Settings,
): string[] => [
  ...exportManifestPaths(p, s ?? previewSettings),
  ...(host === "web" ? ["SETUP.md"] : []),
];

// Only the locale reaches the manifest's text, and the preview surface renders
// paths rather than content, so a neutral stand-in is sufficient here.
const previewSettings: Settings = {
  baseFolder: "",
  toolkitPath: "",
  futureProjectsPath: "",
  defaultBranch: "main",
  preferredIde: "VS Code",
  theme: "dark",
  locale: "en",
  confirmBeforeRun: true,
};

export function buildExecutionPreview(
  p: ProjectDefinition,
  s: Settings,
  host: ExecutionHost,
  resolvedWebManifest: readonly string[] = [],
): ExecutionPreview {
  const slug = slugify(p.name) || "new-project";
  if (host === "web" && p.action === "tracking")
    throw new Error(
      "Tracking-only export isn't supported in the browser edition yet — choose Repository or Both.",
    );
  const artifacts: PlannedArtifact[] = [];
  const planned = (
    kind: PlannedArtifact["kind"],
    displayName: string,
    destination: string,
  ) => artifacts.push({ kind, displayName, destination, certainty: "planned" });
  if (host === "web") {
    const filename = `${slug}.zip`;
    planned("zip", filename, filename);
    for (const entry of resolvedWebManifest)
      planned("zip-entry", entry.split("/").at(-1) || entry, entry);
    return {
      host,
      dryRun: p.dryRun,
      action: p.action,
      headline: p.dryRun ? "Review only" : "Prepare a repository ZIP",
      artifacts,
      limitations: [
        "Both creates the same repository ZIP; browser tracking is not available.",
        p.dryRun
          ? "No ZIP will be built and no download will be requested."
          : "The browser may block, rename, relocate, or cancel the download.",
      ],
    };
  }
  const repository = `${p.destination}\\${slug}`;
  if (p.action !== "tracking") {
    planned("repository", slug, repository);
    for (const relative of generatedArtifactPaths(p, host))
      planned("generated-file", relative, `${repository}\\${relative}`);
    for (const attachment of p.attachments)
      planned(
        "attachment",
        attachment.name,
        `${repository}\\docs\\product\\sources\\${attachment.name}`,
      );
  }
  if (p.action !== "repository")
    planned(
      "tracking",
      "PROJECT_STATUS.md (or the next versioned copy)",
      `${s.futureProjectsPath}\\${slug}`,
    );
  return {
    host,
    dryRun: p.dryRun,
    action: p.action,
    headline: p.dryRun
      ? "Review only"
      : p.action === "both"
        ? "Create repository and tracking"
        : `Create ${p.action}`,
    artifacts,
    limitations: [
      p.dryRun
        ? "No file, directory, remote, IDE launch, or history entry will be created."
        : "Existing filenames use the next available versioned copy.",
      ...(p.createRemote && p.action !== "tracking"
        ? ["GitHub creates a remote; no push is performed."]
        : []),
    ],
  };
}
export function planActions(
  p: ProjectDefinition,
  s: Settings,
): PlannedAction[] {
  const slug = slugify(p.name) || "new-project",
    a: PlannedAction[] = [],
    es = s.locale === "es";
  if (p.action !== "tracking")
    a.push({
      id: "folder",
      label: es ? "Crear carpeta dedicada" : "Create dedicated folder",
      detail: `${p.destination}\\${slug}`,
      description: es
        ? "Prepara el directorio raíz del proyecto sin reemplazar archivos existentes."
        : "Prepares the project root without replacing existing files.",
      kind: "filesystem",
      mutates: true,
    });
  if (p.action !== "repository")
    a.push({
      id: "tracking",
      label: es
        ? "Crear o versionar tracking del proyecto"
        : "Create or version project tracking",
      detail: `${s.futureProjectsPath}\\${slug}`,
      description: es
        ? "Registra la fase y el contexto en future_projects usando una copia versionada si ya existe."
        : "Records phase and context in future_projects, using a versioned copy when needed.",
      kind: "filesystem",
      mutates: true,
    });
  if (p.action !== "tracking" && p.attachments.length)
    a.push({
      id: "attachments",
      label: es ? "Copiar fuentes de discovery" : "Copy discovery sources",
      detail: es
        ? `${p.attachments.length} archivo(s) validado(s)`
        : `${p.attachments.length} validated file(s)`,
      description: es
        ? "Copia fuentes permitidas al área de discovery; los originales permanecen intactos."
        : "Copies allowed sources into discovery; originals remain untouched.",
      kind: "filesystem",
      mutates: true,
    });
  if (p.action !== "tracking")
    a.push({
      id: "docs",
      label: es
        ? "Preparar gobernanza y firma del proyecto"
        : "Seed governance and project signature",
      detail: `AGENTS.md, prompt, discovery, .accreatio/project.json`,
      description: es
        ? "Genera el prompt, la gobernanza y una firma local de procedencia para continuar en el IDE."
        : "Generates the prompt, governance, and local provenance signature for IDE continuation.",
      kind: "template",
      mutates: true,
    });
  if (p.initializeGit && p.action !== "tracking")
    a.push({
      id: "git",
      label: es ? "Inicializar o detectar Git" : "Initialize or detect Git",
      detail: `${es ? "Rama" : "Branch"} ${s.defaultBranch || "main"}`,
      description: es
        ? "Conserva un repositorio existente o inicializa uno local sin commit ni push automático."
        : "Keeps an existing repository or initializes a local one without automatic commit or push.",
      kind: "git",
      mutates: true,
    });
  if (p.createRemote && p.action !== "tracking")
    a.push({
      id: "github",
      label: es ? "Crear repositorio en GitHub" : "Create GitHub repository",
      detail: p.remotePrivate
        ? es
          ? "Privado"
          : "Private"
        : es
          ? "Público"
          : "Public",
      description: es
        ? "Crea el remoto mediante GitHub CLI usando la sesión local; no sube contenido automáticamente."
        : "Creates the remote through GitHub CLI using the local session; no content is pushed automatically.",
      kind: "github",
      mutates: true,
    });
  if (p.openIde && p.action !== "tracking")
    a.push({
      id: "ide",
      label: es ? "Abrir proyecto" : "Open project",
      detail: s.preferredIde,
      description: es
        ? "Abre el directorio terminado en la herramienta seleccionada."
        : "Opens the completed directory in the selected tool.",
      kind: "ide",
      mutates: false,
    });
  return a;
}
// Renders the git/github/ide actions a browser can't perform itself into
// literal copy-paste shell commands. Filesystem/template actions need no
// entry here: unzipping the export already satisfies them.
export function renderSetupMd(
  actions: PlannedAction[],
  p: ProjectDefinition,
  s: Settings,
): string {
  const slug = slugify(p.name) || "new-project";
  const commands = [`cd ${slug}`];
  for (const action of actions) {
    if (action.kind === "git") {
      const branch = s.defaultBranch || "main";
      // SETUP is copyable shell text: never embed an arbitrary settings value.
      if (
        !/^[A-Za-z0-9][A-Za-z0-9._/-]*$/.test(branch) ||
        branch.includes("..") ||
        branch.includes("//") ||
        branch.endsWith("/") ||
        branch.endsWith(".") ||
        branch
          .split("/")
          .some((part) => part.startsWith(".") || part.endsWith(".lock"))
      )
        throw new Error("Invalid branch name for setup instructions.");
      commands.push(`git init -b ${branch}`);
    } else if (action.kind === "github")
      commands.push(
        `gh repo create ${slug} ${p.remotePrivate ? "--private" : "--public"} --source . --remote origin`,
      );
    else if (action.kind === "ide")
      commands.push(
        s.preferredIde === "VS Code" ? "code --new-window ." : "explorer .",
      );
  }
  return `# Setup\n\nThe browser can't run these steps for you. From the folder where you extracted this ZIP:\n\n\`\`\`\n${commands.join("\n")}\n\`\`\`\n`;
}
