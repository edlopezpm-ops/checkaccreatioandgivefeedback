import { inflateSync, unzlibSync, zipSync } from "fflate";
import { XMLParser, XMLValidator } from "fast-xml-parser";
import {
  PDFArray,
  PDFDict,
  PDFDocument,
  PDFHexString,
  PDFName,
  PDFNumber,
  PDFObject,
  PDFObjectParser,
  PDFPageLeaf,
  PDFPageTree,
  PDFParser,
  PDFRawStream,
  PDFRef,
  PDFStream,
  PDFString,
  PDFWriter,
} from "pdf-lib";
import {
  ATTACHMENT_INPUT_LIMIT,
  AttachmentSecurityError,
  attachmentExtension,
  rejectAttachment as reject,
} from "./attachmentSecurityTypes";
export { AttachmentSecurityError } from "./attachmentSecurityTypes";

const EXPANSION_LIMIT = 32 * 1024 * 1024;
const XML_LIMIT = 4 * 1024 * 1024;
const IMAGE_PIXELS = 16_000_000;
const IMAGE_DIMENSION = 8192;
const text = new TextDecoder("utf-8", { fatal: true });
const bytesOf = (bytes: Uint8Array) => bytes.slice().buffer as ArrayBuffer;

function assertImageDimensions(width: number, height: number) {
  if (
    !Number.isInteger(width) ||
    !Number.isInteger(height) ||
    width < 1 ||
    height < 1 ||
    width > IMAGE_DIMENSION ||
    height > IMAGE_DIMENSION ||
    width * height > IMAGE_PIXELS
  )
    reject("tooLarge");
}
function imageMime(bytes: Uint8Array, extension: string) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (extension === ".png") {
    if (
      bytes.length < 33 ||
      view.getUint32(0) !== 0x89504e47 ||
      view.getUint32(4) !== 0x0d0a1a0a ||
      view.getUint32(8) !== 13 ||
      view.getUint32(12) !== 0x49484452
    )
      reject("malformed");
    assertImageDimensions(view.getUint32(16), view.getUint32(20));
    return "image/png";
  }
  if (bytes.length < 4 || view.getUint16(0) !== 0xffd8)
    return reject("malformed");
  let offset = 2;
  while (offset + 4 <= bytes.length) {
    if (bytes[offset++] !== 0xff) return reject("malformed");
    while (bytes[offset] === 0xff) offset += 1;
    const marker = bytes[offset++];
    if (marker === 0xd9 || marker === 0xda) break;
    if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
    if (offset + 2 > bytes.length) return reject("malformed");
    const length = view.getUint16(offset);
    if (length < 2 || offset + length > bytes.length)
      return reject("malformed");
    if (
      marker >= 0xc0 &&
      marker <= 0xcf &&
      ![0xc4, 0xc8, 0xcc].includes(marker)
    ) {
      if (length < 8) return reject("malformed");
      assertImageDimensions(
        view.getUint16(offset + 5),
        view.getUint16(offset + 3),
      );
      return "image/jpeg";
    }
    offset += length;
  }
  return reject("malformed");
}

async function reconstructImage(bytes: Uint8Array, extension: string) {
  const mime = imageMime(bytes, extension);
  if (
    typeof createImageBitmap !== "function" ||
    typeof OffscreenCanvas !== "function"
  )
    return reject("unavailable");
  const image = await createImageBitmap(
    new Blob([bytesOf(bytes)], { type: mime }),
  );
  try {
    assertImageDimensions(image.width, image.height);
    const canvas = new OffscreenCanvas(image.width, image.height);
    const context = canvas.getContext("2d");
    if (!context) return reject("unavailable");
    context.drawImage(image, 0, 0);
    const clean = await canvas.convertToBlob({ type: mime, quality: 0.92 });
    if (clean.type !== mime || clean.size > ATTACHMENT_INPUT_LIMIT)
      return reject("tooLarge");
    return new Uint8Array(await clean.arrayBuffer());
  } finally {
    image.close();
  }
}

const crcTable = Array.from({ length: 256 }, (_, index) => {
  let crc = index;
  for (let bit = 0; bit < 8; bit += 1)
    crc = (crc & 1) !== 0 ? 0xedb88320 ^ (crc >>> 1) : crc >>> 1;
  return crc >>> 0;
});
function crc32(bytes: Uint8Array) {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
function checkExtra(bytes: Uint8Array, start: number, length: number) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const end = start + length;
  while (start < end) {
    if (start + 4 > end) reject("malformed");
    const id = view.getUint16(start, true);
    const size = view.getUint16(start + 2, true);
    if ([1, 0x9901, 0x7075, 0x6375].includes(id)) reject("unsupported");
    start += 4 + size;
    if (start > end) reject("malformed");
  }
}
/** Deliberately narrow OOXML container reader. All lengths are checked before
 * inflate; output uses a fixed allocation and is CRC checked before parsing.
 * Repacking removes comments, unused compressed tails and original ZIP metadata. */
function readDocx(bytes: Uint8Array) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const eocd = bytes.length - 22;
  if (
    eocd < 0 ||
    view.getUint32(eocd, true) !== 0x06054b50 ||
    view.getUint16(eocd + 4, true) !== 0 ||
    view.getUint16(eocd + 6, true) !== 0 ||
    view.getUint16(eocd + 20, true) !== 0
  )
    return reject("malformed");
  const count = view.getUint16(eocd + 10, true);
  const centralSize = view.getUint32(eocd + 12, true);
  const centralStart = view.getUint32(eocd + 16, true);
  if (
    count < 3 ||
    count > 512 ||
    count !== view.getUint16(eocd + 8, true) ||
    centralStart + centralSize !== eocd
  )
    return reject("malformed");
  const files = new Map<string, Uint8Array>();
  const names = new Set<string>();
  const ranges: [number, number][] = [];
  let expanded = 0;
  let offset = centralStart;
  for (let index = 0; index < count; index += 1) {
    if (offset + 46 > eocd || view.getUint32(offset, true) !== 0x02014b50)
      return reject("malformed");
    const flags = view.getUint16(offset + 8, true);
    const method = view.getUint16(offset + 10, true);
    const crc = view.getUint32(offset + 16, true);
    const compressed = view.getUint32(offset + 20, true);
    const size = view.getUint32(offset + 24, true);
    const nameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const local = view.getUint32(offset + 42, true);
    const end = offset + 46 + nameLength + extraLength + commentLength;
    if (
      end > eocd ||
      flags & ~0x0808 ||
      ![0, 8].includes(method) ||
      view.getUint16(offset + 34, true) !== 0 ||
      ((view.getUint32(offset + 38, true) >>> 16) & 0xf000) === 0xa000
    )
      return reject("unsupported");
    const name = text.decode(
      bytes.subarray(offset + 46, offset + 46 + nameLength),
    );
    if (
      !/^[A-Za-z0-9_\[\]./-]+$/.test(name) ||
      name.startsWith("/") ||
      name
        .split("/")
        .some(
          (part, partIndex, parts) =>
            part === "." ||
            part === ".." ||
            (!part && partIndex !== parts.length - 1),
        ) ||
      names.has(name.toLowerCase())
    )
      return reject("malformed");
    names.add(name.toLowerCase());
    checkExtra(bytes, offset + 46 + nameLength, extraLength);
    if (local + 30 > centralStart || view.getUint32(local, true) !== 0x04034b50)
      return reject("malformed");
    const localName = view.getUint16(local + 26, true);
    const localExtra = view.getUint16(local + 28, true);
    const dataStart = local + 30 + localName + localExtra;
    let dataEnd = dataStart + compressed;
    if (
      dataEnd > centralStart ||
      view.getUint16(local + 6, true) !== flags ||
      view.getUint16(local + 8, true) !== method ||
      localName !== nameLength ||
      text.decode(bytes.subarray(local + 30, local + 30 + localName)) !== name
    )
      return reject("malformed");
    checkExtra(bytes, local + 30 + localName, localExtra);
    if (flags & 8) {
      let descriptor = dataEnd;
      if (
        descriptor + 4 <= centralStart &&
        view.getUint32(descriptor, true) === 0x08074b50
      )
        descriptor += 4;
      if (
        descriptor + 12 > centralStart ||
        view.getUint32(descriptor, true) !== crc ||
        view.getUint32(descriptor + 4, true) !== compressed ||
        view.getUint32(descriptor + 8, true) !== size
      )
        return reject("malformed");
      dataEnd = descriptor + 12;
    } else if (
      view.getUint32(local + 14, true) !== crc ||
      view.getUint32(local + 18, true) !== compressed ||
      view.getUint32(local + 22, true) !== size
    )
      return reject("malformed");
    ranges.push([local, dataEnd]);
    expanded += size;
    if (size > ATTACHMENT_INPUT_LIMIT || expanded > EXPANSION_LIMIT)
      return reject("tooLarge");
    if (name.endsWith("/")) {
      if (size || compressed) return reject("malformed");
    } else {
      const input = bytes.subarray(dataStart, dataStart + compressed);
      const output =
        method === 0
          ? input.slice()
          : inflateSync(input, { out: new Uint8Array(size) });
      if (output.length !== size || crc32(output) !== crc)
        return reject("malformed");
      files.set(name, output);
    }
    offset = end;
  }
  if (offset !== eocd) return reject("malformed");
  ranges.sort((a, b) => a[0] - b[0]);
  let cursor = 0;
  for (const [start, end] of ranges) {
    if (start !== cursor) return reject("malformed");
    cursor = end;
  }
  if (cursor !== centralStart) return reject("malformed");
  return files;
}

type XmlNode = Record<string, unknown>;
const localName = (name: string) => name.replace(/^@_/, "").split(":").at(-1)!;
const forbiddenWordElements = new Set([
  "object",
  "oleObject",
  "control",
  "altChunk",
  "fldSimple",
  "fldChar",
  "instrText",
  "attachedTemplate",
  "subDoc",
  "dataBinding",
  "script",
]);
function parseXml(bytes: Uint8Array) {
  if (bytes.length > XML_LIMIT) return reject("tooLarge");
  const xml = text.decode(bytes);
  if (/<!\s*(?:DOCTYPE|ENTITY)/i.test(xml)) return reject("activeContent");
  let depth = 0;
  let nodes = 0;
  for (const token of xml.matchAll(
    /<!--[\s\S]*?-->|<\?[\s\S]*?\?>|<!\[CDATA\[[\s\S]*?\]\]>|<[^>]+>/g,
  )) {
    const tag = token[0];
    if (tag.startsWith("<!") || tag.startsWith("<?")) continue;
    nodes += 1;
    if (nodes > 50_000) return reject("tooLarge");
    if (tag.startsWith("</")) depth -= 1;
    else if (!tag.endsWith("/>")) depth += 1;
    if (depth < 0 || depth > 64) return reject("malformed");
  }
  if (depth !== 0 || XMLValidator.validate(xml) !== true)
    return reject("malformed");
  const result: XmlNode[] = new XMLParser({
    preserveOrder: true,
    ignoreAttributes: false,
    processEntities: false,
    parseTagValue: false,
    parseAttributeValue: false,
    trimValues: false,
  }).parse(xml);
  return result;
}
function inspectXml(
  nodes: XmlNode[],
  visit: (name: string, attrs: Record<string, unknown>) => void,
) {
  const pending: XmlNode[] = [...nodes];
  while (pending.length) {
    const node = pending.pop()!;
    const attrs = (node[":@"] ?? {}) as Record<string, unknown>;
    for (const [name, children] of Object.entries(node)) {
      if (name === ":@" || name.startsWith("#") || name.startsWith("?"))
        continue;
      visit(localName(name), attrs);
      if (Array.isArray(children)) pending.push(...children);
    }
  }
}
const attr = (attrs: Record<string, unknown>, name: string) => {
  const value = attrs[`@_${name}`];
  return typeof value === "string" ? value : "";
};
const wordNamespace =
  "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
async function reconstructDocx(bytes: Uint8Array) {
  const files = readDocx(bytes);
  if (
    !["[Content_Types].xml", "_rels/.rels", "word/document.xml"].every((name) =>
      files.has(name),
    )
  )
    return reject("malformed");
  let mainType = false;
  let mainRelation = false;
  let mainDocument = false;
  const clean: Record<string, Uint8Array> = Object.create(null);
  for (const [name, content] of files) {
    if (/^word\/media\/[A-Za-z0-9_.-]+\.(png|jpe?g)$/i.test(name)) {
      clean[name] = await reconstructImage(content, attachmentExtension(name));
      continue;
    }
    if (
      name !== "[Content_Types].xml" &&
      name !== "_rels/.rels" &&
      !/^(?:word|docProps)\/[A-Za-z0-9_./-]+\.(xml|rels)$/.test(name)
    )
      return reject("activeContent");
    const nodes = parseXml(content);
    if (name === "word/document.xml") {
      const roots = nodes.filter((node) =>
        Object.keys(node).some((key) => key !== ":@" && !key.startsWith("?")),
      );
      const root = roots[0];
      const rootName = root && Object.keys(root).find((key) => key !== ":@");
      const prefix = rootName?.includes(":") ? rootName.split(":")[0] : "";
      const namespace =
        root &&
        (root[":@"] as Record<string, unknown> | undefined)?.[
          prefix ? `@_xmlns:${prefix}` : "@_xmlns"
        ];
      mainDocument =
        roots.length === 1 &&
        !!rootName &&
        localName(rootName) === "document" &&
        namespace === wordNamespace;
    }
    inspectXml(nodes, (element, attrs) => {
      if (forbiddenWordElements.has(element)) reject("activeContent");
      for (const [key, value] of Object.entries(attrs)) {
        if (
          /^on[a-z]+$/i.test(localName(key)) ||
          (typeof value === "string" &&
            /(?:macroenabled|vbaproject|activex|oleobject|javascript:)/i.test(
              value,
            ))
        )
          reject("activeContent");
      }
      if (
        name === "[Content_Types].xml" &&
        ["Default", "Override"].includes(element)
      ) {
        const type = attr(attrs, "ContentType");
        if (
          !/^(?:application\/(?:vnd\.openxmlformats-[a-z0-9.+-]+|xml)|image\/(?:png|jpeg))$/.test(
            type,
          )
        )
          reject("activeContent");
        if (
          attr(attrs, "PartName") === "/word/document.xml" &&
          type ===
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"
        )
          mainType = true;
      }
      if (element === "Relationship") {
        const target = attr(attrs, "Target");
        const type = attr(attrs, "Type");
        if (
          !["", "Internal"].includes(attr(attrs, "TargetMode")) ||
          !/^[A-Za-z0-9_./-]+$/.test(target) ||
          target.startsWith("/") ||
          target.split("/").some((part) => part === ".." || part === ".") ||
          !/^http:\/\/schemas\.openxmlformats\.org\/(?:officeDocument|package)\/2006\/relationships\/(?:officeDocument|metadata\/core-properties|extended-properties|custom-properties|styles|stylesWithEffects|numbering|settings|webSettings|fontTable|theme|image|header|footer|footnotes|endnotes|comments)$/.test(
            type,
          )
        )
          reject("activeContent");
        if (
          name === "_rels/.rels" &&
          type.endsWith("/officeDocument") &&
          target === "word/document.xml"
        )
          mainRelation = true;
      }
    });
    clean[name] = content;
  }
  if (!mainType || !mainRelation || !mainDocument) return reject("malformed");
  const output = zipSync(clean, { level: 6, mtime: new Date(1980, 0, 1) });
  if (output.length > ATTACHMENT_INPUT_LIMIT) return reject("tooLarge");
  return output;
}

const forbiddenPdfKeys = new Set([
  "JS",
  "JavaScript",
  "AA",
  "OpenAction",
  "EmbeddedFiles",
  "EF",
  "AF",
  "RichMediaContent",
  "RichMediaSettings",
  "XFA",
  "AcroForm",
  "Collection",
  "PresSteps",
  "Requirements",
  "AlternatePresentations",
  "SpiderInfo",
]);
const forbiddenPdfNames = new Set([
  "JavaScript",
  "Launch",
  "SubmitForm",
  "ImportData",
  "Rendition",
  "GoToR",
  "GoToE",
  "Movie",
  "Sound",
  "Thread",
  "SetOCGState",
  "Hide",
  "ResetForm",
  "EmbeddedFile",
  "Filespec",
  "RichMedia",
  "Screen",
  "3D",
  "FileAttachment",
]);

/** Public parser hook sees actual stream dictionaries before pdf-lib's ObjStm
 * and XRef helpers inflate them. Decode into a fixed output allocation here,
 * remove compression, then let those helpers inspect only bounded bytes. */
class BoundedPdfParser extends PDFParser {
  private nesting = 0;
  private parsed = 0;
  private expanded = 0;
  private rejection?: AttachmentSecurityError;
  readonly boundedStreams = new WeakSet<PDFRawStream>();

  private checkObjectStream(stream: PDFRawStream) {
    const count = stream.dict.get(PDFName.of("N"));
    const first = stream.dict.get(PDFName.of("First"));
    if (
      !(count instanceof PDFNumber && first instanceof PDFNumber) ||
      !Number.isInteger(first.asNumber()) ||
      first.asNumber() < 1 ||
      first.asNumber() >= stream.contents.length
    )
      return reject("malformed");
    const boundedObjectParser = (bytes: Uint8Array) => {
      const parser = PDFObjectParser.forBytes(bytes, stream.dict.context, true);
      const parse = parser.parseObject.bind(parser);
      let depth = 0;
      parser.parseObject = () => {
        depth += 1;
        this.parsed += 1;
        try {
          if (depth > 64 || this.parsed > 100_000) return reject("tooLarge");
          const value = parse();
          if (value instanceof PDFStream) return reject("malformed");
          return value;
        } finally {
          depth -= 1;
        }
      };
      return parser;
    };
    const header = boundedObjectParser(
      stream.contents.subarray(0, first.asNumber()),
    );
    const offsets: number[] = [];
    const ids = new Set<number>();
    for (let index = 0; index < count.asNumber(); index += 1) {
      const id = header.parseObject();
      const offset = header.parseObject();
      if (
        !(id instanceof PDFNumber && offset instanceof PDFNumber) ||
        !Number.isSafeInteger(id.asNumber()) ||
        id.asNumber() < 1 ||
        ids.has(id.asNumber()) ||
        !Number.isSafeInteger(offset.asNumber()) ||
        offset.asNumber() < 0 ||
        first.asNumber() + offset.asNumber() >= stream.contents.length ||
        (index > 0 && offset.asNumber() <= offsets[index - 1])
      )
        return reject("malformed");
      ids.add(id.asNumber());
      offsets.push(offset.asNumber());
    }
    for (let index = 0; index < offsets.length; index += 1) {
      const start = first.asNumber() + offsets[index];
      const end =
        index + 1 < offsets.length
          ? first.asNumber() + offsets[index + 1]
          : stream.contents.length;
      boundedObjectParser(stream.contents.subarray(start, end)).parseObject();
    }
  }

  override async parseDocument() {
    try {
      return await super.parseDocument();
    } catch (error) {
      throw this.rejection ?? error;
    }
  }

  override parseObject(): PDFObject {
    this.nesting += 1;
    this.parsed += 1;
    try {
      if (this.nesting > 64 || this.parsed > 100_000) reject("tooLarge");
      const value = super.parseObject();
      if (!(value instanceof PDFRawStream)) return value;
      for (const key of value.dict.keys()) {
        if (
          ["F", "FFilter", "FDecodeParms", "Ref", "OPI"].includes(
            key.decodeText(),
          )
        )
          return reject("activeContent");
      }
      const kind = value.dict.get(PDFName.of("Type"));
      if (kind instanceof PDFRef) return reject("unsupported");
      const count = value.dict.get(PDFName.of("N"));
      if (
        kind instanceof PDFName &&
        kind.decodeText() === "ObjStm" &&
        (!(count instanceof PDFNumber) ||
          !Number.isInteger(count.asNumber()) ||
          count.asNumber() < 1 ||
          count.asNumber() > 20_000)
      )
        return reject("tooLarge");
      let filter = value.dict.get(PDFName.of("Filter"));
      if (filter instanceof PDFArray) {
        if (filter.size() !== 1) return reject("unsupported");
        filter = filter.get(0);
      }
      if (filter && !(filter instanceof PDFName)) return reject("unsupported");
      const encoding = filter instanceof PDFName ? filter.decodeText() : "";
      const params = value.dict.get(PDFName.of("DecodeParms"));
      if (params) {
        if (!(params instanceof PDFDict)) return reject("unsupported");
        const predictor = params.get(PDFName.of("Predictor"));
        if (
          predictor &&
          (!(predictor instanceof PDFNumber) || predictor.asNumber() !== 1)
        )
          return reject("unsupported");
      }
      let contents = value.contents;
      if (encoding === "FlateDecode") {
        const limit = 8 * 1024 * 1024;
        contents = unzlibSync(contents, { out: new Uint8Array(limit + 1) });
        if (contents.length > limit) return reject("tooLarge");
      } else if (encoding === "DCTDecode") {
        imageMime(contents, ".jpg");
      } else if (encoding !== "") return reject("unsupported");
      this.expanded += contents.length;
      if (this.expanded > EXPANSION_LIMIT) return reject("tooLarge");
      const subtype = value.dict.get(PDFName.of("Subtype"));
      if (subtype instanceof PDFName && subtype.decodeText() === "Image") {
        const width = value.dict.get(PDFName.of("Width"));
        const height = value.dict.get(PDFName.of("Height"));
        if (!(width instanceof PDFNumber && height instanceof PDFNumber))
          return reject("unsupported");
        assertImageDimensions(width.asNumber(), height.asNumber());
      }
      if (encoding !== "FlateDecode") {
        if (kind instanceof PDFName && kind.decodeText() === "ObjStm")
          this.checkObjectStream(value);
        this.boundedStreams.add(value);
        return value;
      }
      const dict = value.dict.clone();
      dict.delete(PDFName.of("Filter"));
      dict.delete(PDFName.of("DecodeParms"));
      dict.set(PDFName.of("Length"), PDFNumber.of(contents.length));
      const bounded = PDFRawStream.of(dict, contents);
      if (kind instanceof PDFName && kind.decodeText() === "ObjStm")
        this.checkObjectStream(bounded);
      this.boundedStreams.add(bounded);
      return bounded;
    } catch (error) {
      if (error instanceof AttachmentSecurityError) this.rejection = error;
      throw error;
    } finally {
      this.nesting -= 1;
    }
  }
}

/** pdf-lib enumerates pages with a recursive traversal that assumes a tree.
 * Validate those assumptions iteratively before any high-level page accessor
 * or save path can expand a shared-child DAG or follow a cycle. */
function validatePdfPageTree(document: PDFDocument) {
  const context = document.context;
  const rootRef = document.catalog.get(PDFName.of("Pages"));
  if (!(rootRef instanceof PDFRef)) return reject("malformed");
  const root = context.lookup(rootRef);
  if (!(root instanceof PDFPageTree) || root.has(PDFName.of("Parent")))
    return reject("malformed");
  const claimed = new Set<PDFDict>([root]);
  const totals = new Map<PDFDict, number>();
  const pending: {
    node: PDFPageTree | PDFPageLeaf;
    depth: number;
    children?: (PDFPageTree | PDFPageLeaf)[];
    expected?: number;
  }[] = [{ node: root, depth: 0 }];
  let pages = 0;
  while (pending.length) {
    const { node, depth, children, expected } = pending.pop()!;
    if (children) {
      let total = 0;
      for (const child of children) {
        const childTotal = totals.get(child);
        if (childTotal === undefined) return reject("malformed");
        total += childTotal;
      }
      if (total !== expected) return reject("malformed");
      totals.set(node, total);
      continue;
    }
    if (depth > 64 || claimed.size > 20_000) return reject("tooLarge");
    if (node instanceof PDFPageLeaf) {
      if (node.has(PDFName.of("Kids")) || node.has(PDFName.of("Count")))
        return reject("malformed");
      pages += 1;
      if (pages > 2000) return reject("tooLarge");
      totals.set(node, 1);
      continue;
    }
    const kids = context.lookup(node.get(PDFName.of("Kids")));
    const count = context.lookup(node.get(PDFName.of("Count")));
    if (
      !(kids instanceof PDFArray && count instanceof PDFNumber) ||
      !Number.isSafeInteger(count.asNumber()) ||
      count.asNumber() < 0
    )
      return reject("malformed");
    if (count.asNumber() > 2000 || kids.size() > 2000)
      return reject("tooLarge");
    const resolved: (PDFPageTree | PDFPageLeaf)[] = [];
    for (const kidRef of kids.asArray()) {
      if (!(kidRef instanceof PDFRef)) return reject("malformed");
      const kid = context.lookup(kidRef);
      if (!(kid instanceof PDFPageTree || kid instanceof PDFPageLeaf))
        return reject("malformed");
      if (claimed.has(kid)) return reject("malformed");
      const parentRef = kid.get(PDFName.of("Parent"));
      if (!(parentRef instanceof PDFRef) || context.lookup(parentRef) !== node)
        return reject("malformed");
      claimed.add(kid);
      resolved.push(kid);
    }
    pending.push({
      node,
      depth,
      children: resolved,
      expected: count.asNumber(),
    });
    for (const kid of resolved) pending.push({ node: kid, depth: depth + 1 });
  }
  if (pages < 1 || totals.get(root) !== pages) return reject("unsupported");
  return pages;
}

async function reconstructPdf(bytes: Uint8Array) {
  if (
    bytes.length < 8 ||
    !/^%PDF-1\.[0-7]/.test(new TextDecoder().decode(bytes.subarray(0, 8)))
  )
    return reject("malformed");
  const parser = new BoundedPdfParser(bytes, 100, true, true);
  const context = await parser.parseDocument();
  if (context.trailerInfo.Encrypt) return reject("unsupported");
  // A compressed object stream is forbidden by PDF from containing another
  // stream. Fail closed if the permissive upstream parser nevertheless emits
  // one; it did not pass this instance's bounded stream hook.
  const pendingStreams = context
    .enumerateIndirectObjects()
    .map(([, value]) => value);
  const checked = new Set<PDFObject>();
  while (pendingStreams.length) {
    const value = pendingStreams.pop()!;
    if (checked.has(value)) continue;
    checked.add(value);
    if (checked.size > 100_000) return reject("tooLarge");
    if (value instanceof PDFRawStream) {
      if (!parser.boundedStreams.has(value)) return reject("malformed");
      const type = value.dict.get(PDFName.of("Type"));
      if (
        type instanceof PDFName &&
        ["ObjStm", "XRef"].includes(type.decodeText())
      )
        return reject("malformed");
      pendingStreams.push(value.dict);
    } else if (value instanceof PDFDict) {
      pendingStreams.push(...value.values());
    } else if (value instanceof PDFArray) {
      pendingStreams.push(...value.asArray());
    }
  }
  const bounded = await PDFWriter.forContext(context, 100).serializeToBuffer();
  if (bounded.length > EXPANSION_LIMIT) return reject("tooLarge");
  const document = await PDFDocument.load(bounded, {
    updateMetadata: false,
    throwOnInvalidObject: true,
  });
  if (document.isEncrypted) return reject("unsupported");
  validatePdfPageTree(document);
  const objects = document.context.enumerateIndirectObjects();
  if (objects.length > 20_000) return reject("tooLarge");
  const visited = new Set<PDFObject>();
  const pending: { value: PDFObject; depth: number }[] = objects.map(
    ([, value]) => ({ value, depth: 0 }),
  );
  pending.push({ value: document.catalog, depth: 0 });
  let count = 0;
  while (pending.length) {
    let { value, depth } = pending.pop()!;
    // References are resolved through the parser, including objects held in
    // compressed object streams. PDFName.decodeText resolves #XX name escapes.
    if (value instanceof PDFRef) {
      const resolved = document.context.lookup(value);
      if (!resolved) return reject("malformed");
      value = resolved;
    }
    if (visited.has(value)) continue;
    visited.add(value);
    count += 1;
    if (count > 100_000 || depth > 64) return reject("tooLarge");
    if (value instanceof PDFStream) value = value.dict;
    if (value instanceof PDFName && forbiddenPdfNames.has(value.decodeText()))
      return reject("activeContent");
    if (value instanceof PDFDict) {
      const declaredType = value.lookup(PDFName.of("Type"));
      if (
        declaredType instanceof PDFName &&
        declaredType.decodeText() === "Action"
      ) {
        const kind = value.lookup(PDFName.of("S"));
        if (
          !(kind instanceof PDFName) ||
          !["GoTo", "URI"].includes(kind.decodeText())
        )
          return reject("activeContent");
      }
      for (const [key, child] of value.entries()) {
        const name = key.decodeText();
        if (forbiddenPdfKeys.has(name)) return reject("activeContent");
        if (name === "URI") {
          const uri = document.context.lookup(child);
          if (!(uri instanceof PDFString || uri instanceof PDFHexString))
            return reject("activeContent");
          const url = new URL(uri.decodeText());
          if (url.protocol !== "https:" || url.username || url.password)
            return reject("activeContent");
        }
        if (name === "A") {
          const action = document.context.lookup(child);
          if (!(action instanceof PDFDict)) return reject("activeContent");
          const kind = action.lookup(PDFName.of("S"));
          if (
            !(kind instanceof PDFName) ||
            !["GoTo", "URI"].includes(kind.decodeText())
          )
            return reject("activeContent");
        }
        pending.push({ value: child, depth: depth + 1 });
      }
    } else if (value instanceof PDFArray) {
      for (const child of value.asArray())
        pending.push({ value: child, depth: depth + 1 });
    }
  }
  const clean = await document.save({
    useObjectStreams: false,
    updateFieldAppearances: false,
  });
  if (clean.length > ATTACHMENT_INPUT_LIMIT) return reject("tooLarge");
  return clean;
}

/** Internal worker entry point; only the public wrapper can issue a proof. */
export async function prepareAttachmentBytes(
  blob: Blob,
  filename: string,
): Promise<Blob> {
  const extension = attachmentExtension(filename);
  if (blob.size < 1 || blob.size > ATTACHMENT_INPUT_LIMIT)
    return reject("tooLarge");
  try {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    const clean =
      extension === ".docx"
        ? await reconstructDocx(bytes)
        : extension === ".pdf"
          ? await reconstructPdf(bytes)
          : await reconstructImage(bytes, extension);
    return new Blob([bytesOf(clean)], {
      type:
        extension === ".docx"
          ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          : extension === ".pdf"
            ? "application/pdf"
            : extension === ".png"
              ? "image/png"
              : "image/jpeg",
    });
  } catch (error) {
    if (error instanceof AttachmentSecurityError) throw error;
    return reject("malformed");
  }
}
