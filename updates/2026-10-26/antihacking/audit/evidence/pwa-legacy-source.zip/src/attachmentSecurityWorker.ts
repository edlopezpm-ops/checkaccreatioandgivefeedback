import {
  AttachmentSecurityError,
  prepareAttachmentBytes,
} from "./attachmentSecurityCore";

self.onmessage = async (
  event: MessageEvent<{ blob: Blob; filename: string }>,
) => {
  try {
    const blob = await prepareAttachmentBytes(
      event.data.blob,
      event.data.filename,
    );
    self.postMessage({ blob });
  } catch (error) {
    self.postMessage({
      code: error instanceof AttachmentSecurityError ? error.code : "malformed",
    });
  }
};
