export interface BlogAttribution {
  readonly author: string;
  readonly authorRole: string;
  readonly signature: string;
}

const NEUTRAL_AI_ATTRIBUTION: BlogAttribution = {
  author: "AEKR AI contributor",
  authorRole: "AI-assisted contribution with Ed Lopez through AEKR",
  signature: "Created with AI assistance through AEKR.",
};

// Existing append-only Blog rows keep their original data. Normalize only the
// AI byline at presentation time; a human named Claude keeps their attribution.
export function presentBlogAttribution(
  attribution: BlogAttribution,
): BlogAttribution {
  return attribution.author.trim() === "Claude" &&
    (attribution.authorRole.startsWith("AI system from Anthropic") ||
      attribution.signature === "Made with AI — Claude AEKR mode.")
    ? NEUTRAL_AI_ATTRIBUTION
    : attribution;
}
