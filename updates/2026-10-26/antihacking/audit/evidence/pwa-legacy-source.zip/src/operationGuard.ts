import type { ExecutionRequest } from "./types";
import {
  assertProjectShape,
  assertSettingsShape,
  isPlainRecord,
  validText,
} from "../shared/inputValidation";

const UUID_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (value === null || typeof value !== "object") return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

export function validateExecutionRequest(value: unknown): ExecutionRequest {
  if (!isPlainRecord(value)) throw new Error("Invalid execution request");
  if (
    typeof value.operationId !== "string" ||
    !UUID_PATTERN.test(value.operationId)
  )
    throw new Error("Invalid execution operation ID");
  if (!isPlainObject(value.definition) || !isPlainObject(value.settings))
    throw new Error("Invalid execution request snapshots");
  if (
    Object.keys(value).some(
      (key) =>
        !["operationId", "definition", "settings", "webAttachments"].includes(
          key,
        ),
    )
  )
    throw new Error("Invalid execution request fields");
  assertProjectShape(value.definition);
  assertSettingsShape(value.settings);
  if (
    value.webAttachments !== undefined &&
    !Array.isArray(value.webAttachments)
  )
    throw new Error("Invalid web attachments sidecar");
  if (
    Array.isArray(value.webAttachments) &&
    (value.webAttachments.length > 20 ||
      value.webAttachments.some(
        (file) =>
          !isPlainRecord(file) ||
          Object.keys(file).some(
            (key) => !["id", "name", "size", "extension", "blob"].includes(key),
          ) ||
          !validText(file.id, 128, true) ||
          !validText(file.name, 240, true) ||
          !validText(file.extension, 10, true) ||
          typeof file.size !== "number" ||
          !Number.isSafeInteger(file.size) ||
          file.size < 0 ||
          file.size > 20 * 1024 * 1024 ||
          !(file.blob instanceof Blob) ||
          file.blob.size !== file.size,
      ))
  )
    throw new Error("Invalid web attachments sidecar");
  return value as unknown as ExecutionRequest;
}

export function executionFingerprintValue(request: ExecutionRequest): unknown {
  const value: Record<string, unknown> = {
    definition: request.definition,
    settings: request.settings,
  };
  if (request.webAttachments !== undefined)
    value.webAttachments = request.webAttachments.map(
      ({ name, size, extension }) => ({
        name,
        size,
        extension,
      }),
    );
  return value;
}

export function canonicalJson(value: unknown): string {
  const active = new Set<object>();
  const encode = (input: unknown): string => {
    if (input === null) return "null";
    if (typeof input === "string" || typeof input === "boolean")
      return JSON.stringify(input);
    if (typeof input === "number") {
      if (!Number.isFinite(input))
        throw new Error("Unsupported canonical value");
      return JSON.stringify(input);
    }
    if (typeof input !== "object")
      throw new Error("Unsupported canonical value");
    if (typeof Blob !== "undefined" && input instanceof Blob)
      throw new Error("Blob values cannot be canonicalized");
    if (active.has(input)) throw new Error("Cyclic canonical value");
    active.add(input);
    try {
      if (Array.isArray(input)) return `[${input.map(encode).join(",")}]`;
      if (!isPlainObject(input))
        throw new Error("Unsupported canonical object");
      return `{${Object.keys(input)
        .sort()
        .map((key) => `${JSON.stringify(key)}:${encode(input[key])}`)
        .join(",")}}`;
    } finally {
      active.delete(input);
    }
  };
  return encode(value);
}

export async function browserExecutionFingerprint(
  request: ExecutionRequest,
): Promise<string> {
  const bytes = new TextEncoder().encode(
    canonicalJson(executionFingerprintValue(request)),
  );
  const digest = await globalThis.crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (byte) =>
    byte.toString(16).padStart(2, "0"),
  ).join("");
}

type Entry<T> = {
  fingerprint: Promise<string>;
  result: Promise<T>;
  settled: boolean;
};

export class LogicalOperationGuard<R extends { operationId: string }, T> {
  readonly #byId = new Map<string, Entry<T>>();
  readonly #inFlightByFingerprint = new Map<string, Promise<T>>();

  constructor(
    private readonly fingerprint: (request: R) => Promise<string>,
    private readonly worker: (request: R) => Promise<T>,
    private readonly capacity = 128,
  ) {}

  run(request: R): Promise<T> {
    const existing = this.#byId.get(request.operationId);
    const fingerprint = Promise.resolve().then(() => this.fingerprint(request));
    if (existing) {
      return Promise.all([existing.fingerprint, fingerprint]).then(
        ([first, repeated]) => {
          if (first !== repeated)
            throw new Error(
              "Execution operation ID reused with different payload",
            );
          return existing.result;
        },
      );
    }

    let resolveResult!: (value: T | PromiseLike<T>) => void;
    let rejectResult!: (reason?: unknown) => void;
    const result = new Promise<T>((resolve, reject) => {
      resolveResult = resolve;
      rejectResult = reject;
    });
    const entry = { fingerprint, result, settled: false };
    this.#byId.set(request.operationId, entry);

    void fingerprint.then((key) => {
      const shared = this.#inFlightByFingerprint.get(key);
      if (shared) {
        shared.then(resolveResult, rejectResult);
        return;
      }
      const execution = Promise.resolve().then(() => this.worker(request));
      this.#inFlightByFingerprint.set(key, execution);
      const release = () => {
        if (this.#inFlightByFingerprint.get(key) === execution)
          this.#inFlightByFingerprint.delete(key);
      };
      execution.then(
        (value) => {
          resolveResult(value);
          release();
        },
        (error) => {
          rejectResult(error);
          release();
        },
      );
    }, rejectResult);
    void result.then(
      () => {
        entry.settled = true;
        this.#evictSettled();
      },
      () => {
        entry.settled = true;
        this.#evictSettled();
      },
    );
    return result;
  }

  #evictSettled() {
    while (this.#byId.size > this.capacity) {
      const oldest = [...this.#byId].find(([, entry]) => entry.settled)?.[0];
      if (oldest === undefined) break;
      this.#byId.delete(oldest);
    }
  }
}
