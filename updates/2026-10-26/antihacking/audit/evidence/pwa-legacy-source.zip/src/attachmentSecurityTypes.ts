export const ATTACHMENT_INPUT_LIMIT = 20 * 1024 * 1024;
export type AttachmentRejectionCode =
  | "unsupported"
  | "tooLarge"
  | "malformed"
  | "activeContent"
  | "unavailable"
  | "timeout"
  | "unprepared";

export class AttachmentSecurityError extends Error {
  constructor(public readonly code: AttachmentRejectionCode) {
    super(`Attachment rejected: ${code}.`);
    this.name = "AttachmentSecurityError";
  }
}
export const rejectAttachment = (code: AttachmentRejectionCode): never => {
  throw new AttachmentSecurityError(code);
};
export const attachmentExtension = (name: string) => {
  if (typeof name !== "string" || !name || name.length > 240)
    return rejectAttachment("unsupported");
  const match = /\.(docx|pdf|png|jpe?g)$/i.exec(name);
  return match ? match[0].toLowerCase() : rejectAttachment("unsupported");
};
