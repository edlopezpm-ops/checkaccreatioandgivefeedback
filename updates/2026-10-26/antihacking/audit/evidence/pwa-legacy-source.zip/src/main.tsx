import React from "react";
import ReactDOM from "react-dom/client";
import { App, type AppProps } from "./App";
import { App as LegacyApp } from "./legacy/LegacyApp";
import "./components/creation/guidedCreation.css";

// Keep the previous creator buildable until hosted acceptance. This switch is
// build-time only and does not change stored drafts or the execution contract.
const CreationApp =
  import.meta.env.VITE_CREATION_FLOW === "legacy" ? LegacyApp : App;

class ErrorBoundary extends React.Component<
  React.PropsWithChildren,
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <main className="fatal-error">
        <h1>accreatio could not continue</h1>
        <p>
          An unexpected interface error stopped this view. Reload to start from
          the last locally saved state.
        </p>
        <button type="button" onClick={() => window.location.reload()}>
          Reload
        </button>
      </main>
    );
  }
}

export function mountApp(props: AppProps = {}) {
  ReactDOM.createRoot(document.getElementById("root")!).render(
    <React.StrictMode>
      <ErrorBoundary>
        <CreationApp {...props} />
      </ErrorBoundary>
    </React.StrictMode>,
  );
}
