import aekrMark from "../assets/aekr-mark.svg";
import type { Locale } from "../types";

export function AekrSignature({
  webLinks = false,
  locale = "en",
}: { webLinks?: boolean; locale?: Locale } = {}) {
  if (webLinks) {
    const newTab =
      locale === "es" ? "abre en una pestaña nueva" : "opens in a new tab";
    const pending = locale === "es" ? "perfil pendiente" : "profile pending";
    return (
      <div className="web-footer">
        <a
          className="web-footer__social"
          href="https://www.instagram.com/__aekr/"
          target="_blank"
          rel="noopener noreferrer"
          aria-label={`Instagram (${newTab})`}
        >
          <span className="aekr-signature">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
              aria-hidden="true"
            >
              <rect x="3.5" y="3.5" width="17" height="17" rx="5" />
              <circle cx="12" cy="12" r="4" />
              <circle
                cx="17.4"
                cy="6.7"
                r=".8"
                fill="currentColor"
                stroke="none"
              />
            </svg>
          </span>
        </a>
        <span
          className="web-footer__social web-footer__social--pending"
          role="img"
          aria-disabled="true"
          aria-label={`X (${pending})`}
          title={`X · ${pending}`}
        >
          <span className="aekr-signature">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="M4 3.5h4.5L20 20.5h-4.5L4 3.5Z" />
              <path d="m19.5 3.5-6.6 7.7M4.5 20.5l6.6-7.7" />
            </svg>
          </span>
        </span>
        <span
          className="web-footer__social web-footer__social--pending"
          role="img"
          aria-disabled="true"
          aria-label={`LinkedIn (${pending})`}
          title={`LinkedIn · ${pending}`}
        >
          <span className="aekr-signature">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <rect x="3.5" y="3.5" width="17" height="17" rx="2.5" />
              <path d="M7.5 10.5v6M11.5 16.5v-6M11.5 13a2.5 2.5 0 0 1 5 0v3.5" />
              <circle
                cx="7.5"
                cy="7.6"
                r=".7"
                fill="currentColor"
                stroke="none"
              />
            </svg>
          </span>
        </span>
        <a
          className="web-footer__brand"
          href="https://aekr.io"
          target="_blank"
          rel="noopener noreferrer"
          aria-label={`Built with AEKR (${newTab})`}
        >
          <span className="aekr-signature">
            <img src={aekrMark} alt="" />
            <span>
              Built with <strong>AEKR</strong>
            </span>
          </span>
        </a>
      </div>
    );
  }
  return (
    <div className="aekr-signature">
      <img src={aekrMark} alt="" />
      <span>
        Built with <strong>AEKR</strong>
      </span>
    </div>
  );
}
