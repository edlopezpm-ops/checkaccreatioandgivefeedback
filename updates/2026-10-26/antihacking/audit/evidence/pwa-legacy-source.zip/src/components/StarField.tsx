import { useEffect, useRef } from "react";
import type { Settings } from "../types";

interface StarFieldProps {
  paused: boolean;
  reducedMotion: boolean;
  saveData: boolean;
  slowUpdate: boolean;
  theme: Settings["theme"];
}

type StarDepth = "far" | "mid" | "near";

interface DepthSpec {
  alpha: readonly [number, number];
  densityPerMegapixel: number;
  depth: StarDepth;
  driftRadiusMm: number;
  periodSeconds: readonly [number, number];
  radiusPx: readonly [number, number];
  xExponent: number;
}

interface Star {
  alpha: number;
  colorIndex: number;
  periodMs: number;
  phases: readonly [number, number, number, number, number, number];
  radiusPx: number;
  x: number;
  y: number;
}

const TWO_PI = Math.PI * 2;
const CSS_PIXELS_PER_MM = 96 / 25.4;
const MAX_AREA_MEGAPIXELS = 2.4;
const MIN_AREA_MEGAPIXELS = 0.65;
const FRAME_INTERVAL_MS = 1000 / 30;
const STAR_TRAJECTORY_MULTIPLIER = 1.35;
const STAR_SPEED_MULTIPLIER = 1.15;

const DEPTH_SPECS: readonly DepthSpec[] = [
  {
    alpha: [0.34, 0.66],
    densityPerMegapixel: 82,
    depth: "far",
    driftRadiusMm: 1,
    periodSeconds: [54, 86],
    radiusPx: [0.4, 0.8],
    xExponent: 0.62,
  },
  {
    alpha: [0.46, 0.78],
    densityPerMegapixel: 32,
    depth: "mid",
    driftRadiusMm: 1.5,
    periodSeconds: [38, 62],
    radiusPx: [0.8, 1.35],
    xExponent: 0.54,
  },
  {
    alpha: [0.58, 0.9],
    densityPerMegapixel: 11,
    depth: "near",
    driftRadiusMm: 2.5,
    periodSeconds: [26, 44],
    radiusPx: [1.5, 2.4],
    xExponent: 0.46,
  },
] as const;

const STAR_COLORS = {
  dark: ["#e5e6df", "#bbc0b9", "#a3aaa4", "#d3d5cc"],
  light: ["#89918b", "#9fa69e", "#b4b9b1", "#c7cbc2"],
} as const;

/** Rasterize each color/depth once. In particular, a near star's glow must not
 * run a blur filter against the fullscreen canvas on every animation frame. */
function createStarSprites(theme: Settings["theme"]) {
  return DEPTH_SPECS.map((spec) =>
    STAR_COLORS[theme].map((color) => {
      const sprite = document.createElement("canvas");
      sprite.width = 64;
      sprite.height = 64;
      const context = sprite.getContext("2d", { alpha: true });
      if (!context) return null;
      const near = spec.depth === "near";
      const radius = near ? 8 : 28;
      if (near) {
        const halo = context.createRadialGradient(32, 32, 0, 32, 32, 32);
        halo.addColorStop(0, `${color}80`);
        halo.addColorStop(0.25, `${color}50`);
        halo.addColorStop(0.6, `${color}18`);
        halo.addColorStop(1, `${color}00`);
        context.fillStyle = halo;
        context.fillRect(0, 0, 64, 64);
      }
      context.fillStyle = color;
      context.beginPath();
      context.arc(32, 32, radius, 0, TWO_PI);
      context.fill();
      return { canvas: sprite, extent: 32 / radius };
    }),
  );
}

function createSeededRandom(seed: number) {
  let state = seed >>> 0;
  return () => {
    state += 0x6d2b79f5;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

function between(
  random: () => number,
  [minimum, maximum]: readonly [number, number],
) {
  return minimum + (maximum - minimum) * random();
}

function createStarPool(spec: DepthSpec, seed: number): readonly Star[] {
  const random = createSeededRandom(seed);
  const count = Math.ceil(spec.densityPerMegapixel * MAX_AREA_MEGAPIXELS);

  return Array.from({ length: count }, () => {
    const x = Math.pow(random(), spec.xExponent);
    const rightWeightedAlpha = 0.24 + 0.76 * Math.pow(x, 1.35);
    return {
      alpha: between(random, spec.alpha) * rightWeightedAlpha,
      colorIndex: Math.floor(random() * STAR_COLORS.dark.length),
      periodMs:
        (between(random, spec.periodSeconds) * 1000) / STAR_SPEED_MULTIPLIER,
      phases: [
        random() * TWO_PI,
        random() * TWO_PI,
        random() * TWO_PI,
        random() * TWO_PI,
        random() * TWO_PI,
        random() * TWO_PI,
      ],
      radiusPx: between(random, spec.radiusPx),
      x,
      y: random(),
    };
  });
}

const STAR_POOLS = DEPTH_SPECS.map((spec, index) =>
  createStarPool(spec, 0xaccea710 + index * 0x9e3779b9),
);

function clamp(value: number, minimum: number, maximum: number) {
  return Math.min(maximum, Math.max(minimum, value));
}

/** Local, deterministic 2D depth plane. It receives only viewport, theme,
 * preference, and time; never pointer or project data. */
export function StarField({
  paused,
  reducedMotion,
  saveData,
  slowUpdate,
  theme,
}: StarFieldProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext("2d", { alpha: true });
    if (!context) return;

    const motionEnabled = !paused && !reducedMotion && !saveData && !slowUpdate;
    const sprites = createStarSprites(theme);
    const viewport = { height: 1, width: 1 };
    let areaMegapixels = MIN_AREA_MEGAPIXELS;
    let animationFrame = 0;
    let lastFrame = 0;

    const draw = (now: number) => {
      context.clearRect(0, 0, viewport.width, viewport.height);
      DEPTH_SPECS.forEach((spec, depthIndex) => {
        const visibleCount = Math.min(
          STAR_POOLS[depthIndex].length,
          Math.ceil(spec.densityPerMegapixel * areaMegapixels),
        );
        const driftRadius =
          spec.driftRadiusMm * CSS_PIXELS_PER_MM * STAR_TRAJECTORY_MULTIPLIER;

        for (let index = 0; index < visibleCount; index += 1) {
          const star = STAR_POOLS[depthIndex][index];
          const phase = (now / star.periodMs) * TWO_PI;
          const driftX =
            driftRadius *
            (0.57 * Math.sin(phase + star.phases[0]) +
              0.28 * Math.sin(phase * 0.63 + star.phases[1]) +
              0.15 * Math.cos(phase * 1.37 + star.phases[2]));
          const driftY =
            driftRadius *
            (0.52 * Math.cos(phase * 0.83 + star.phases[3]) +
              0.31 * Math.sin(phase * 0.47 + star.phases[4]) +
              0.17 * Math.sin(phase * 1.51 + star.phases[5]));
          const x = star.x * viewport.width + driftX;
          const y = star.y * viewport.height + driftY;
          const shimmer = motionEnabled
            ? 0.94 + 0.06 * Math.sin(phase * 0.41 + star.phases[2])
            : 1;

          const sprite = sprites[depthIndex][star.colorIndex];
          if (!sprite) continue;
          const extent = star.radiusPx * shimmer * sprite.extent;
          context.globalAlpha = star.alpha * shimmer;
          context.drawImage(
            sprite.canvas,
            x - extent,
            y - extent,
            extent * 2,
            extent * 2,
          );
        }
      });

      context.globalAlpha = 1;
    };

    const resize = () => {
      const bounds = canvas.getBoundingClientRect();
      viewport.width = Math.max(1, bounds.width);
      viewport.height = Math.max(1, bounds.height);
      areaMegapixels = clamp(
        (viewport.width * viewport.height) / 1_000_000,
        MIN_AREA_MEGAPIXELS,
        MAX_AREA_MEGAPIXELS,
      );
      const pixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.max(1, Math.round(viewport.width * pixelRatio));
      canvas.height = Math.max(1, Math.round(viewport.height * pixelRatio));
      context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
      draw(motionEnabled ? performance.now() : 0);
    };

    const tick = (now: number) => {
      animationFrame = window.requestAnimationFrame(tick);
      if (now - lastFrame < FRAME_INTERVAL_MS) return;
      lastFrame = now;
      draw(now);
    };

    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(canvas);
    resize();

    if (motionEnabled) {
      animationFrame = window.requestAnimationFrame(tick);
    }

    return () => {
      window.cancelAnimationFrame(animationFrame);
      resizeObserver.disconnect();
    };
  }, [paused, reducedMotion, saveData, slowUpdate, theme]);

  return (
    <canvas
      ref={canvasRef}
      className="atmosphere__starfield"
      data-motion={
        paused || reducedMotion || saveData || slowUpdate ? "static" : "active"
      }
    />
  );
}
