import { Plus, Terminal, Trash2, Users } from "lucide-react";
import * as React from "react";
import { PROVIDER_REGISTRY } from "../../../shared/providerRegistry";
import type {
  CanonicalRole,
  Locale,
  OrchestrationConfig,
  ProjectDefinition,
} from "../../types";
import { AdvancedDisclosure } from "./AdvancedDisclosure";

interface FocusRoot {
  getElementById(id: string): { focus(): void } | null;
}

export const focusCreationTarget = (id: string, root: FocusRoot = document) =>
  root.getElementById(id)?.focus();

export const creationFocusTarget = (
  stage: "foundation" | "context" | "team" | "delivery",
  errors: Record<string, string>,
) =>
  stage === "foundation"
    ? errors.name
      ? "project-name"
      : "project-attachments"
    : stage === "context"
      ? errors.restrictions && !errors.context
        ? "project-restrictions"
        : "project-context"
      : stage === "team"
        ? errors.participants
          ? "project-participants"
          : "project-mode1-configuration"
        : errors.destination
          ? "project-destination"
          : errors.tracking
            ? "project-tracking"
            : "project-repository-options";

interface TeamStageProps {
  errors: Record<string, string>;
  errorText: (code?: string) => string | undefined;
  isWeb: boolean;
  locale: Locale;
  onAddParticipant: () => void;
  onChange: (project: ProjectDefinition) => void;
  onConfigureMode1: () => void;
  mode1TriggerRef: React.RefObject<HTMLButtonElement | null>;
  project: ProjectDefinition;
  responsibilities: Record<CanonicalRole, { es: string; en: string }>;
}

const roleLabels: Record<Locale, Record<CanonicalRole, string>> = {
  es: {
    generalist: "Generalista",
    architect: "Arquitecto",
    implementer: "Implementador",
    auditor: "Auditor",
  },
  en: {
    generalist: "Generalist",
    architect: "Architect",
    implementer: "Implementer",
    auditor: "Auditor",
  },
};

const roles: CanonicalRole[] = [
  "generalist",
  "architect",
  "implementer",
  "auditor",
];

export function TeamStage({
  errors,
  errorText,
  isWeb,
  locale,
  onAddParticipant,
  onChange,
  onConfigureMode1,
  mode1TriggerRef,
  project,
  responsibilities,
}: TeamStageProps) {
  const es = locale === "es";
  const participantLimit = isWeb ? roles.length : 6;
  const participantLimitReached =
    project.participants.length >= participantLimit;
  const mode1Error = errors.orchestration || errors.funding;
  const providers = Array.from(
    new Set(
      project.orchestration.participants.map(
        (entry) =>
          PROVIDER_REGISTRY.find(({ id }) => id === entry.provider)
            ?.displayName ?? entry.provider,
      ),
    ),
  ).join(", ");
  const updateOrchestration = (orchestration: OrchestrationConfig) =>
    onChange({ ...project, orchestration });
  const Heading = isWeb ? "h2" : "h1";

  React.useEffect(() => {
    if (mode1Error) {
      mode1TriggerRef.current?.closest("details")?.setAttribute("open", "");
    }
  }, [mode1Error, mode1TriggerRef]);

  return (
    <div className="creation-stage" aria-labelledby="team-title">
      <header className="creation-stage__header">
        {!isWeb && <p>{es ? "Etapa 3 de 5" : "Stage 3 of 5"}</p>}
        <Heading id="team-title">
          {es
            ? "Organiza quién hará el trabajo"
            : "Organize who will do the work"}
        </Heading>
        <span>
          {isWeb
            ? es
              ? "El orden define el traspaso. Elige hasta cuatro roles distintos."
              : "Order defines the handoff. Choose up to four distinct roles."
            : es
              ? "El orden define el traspaso. Los roles pueden repetirse."
              : "Order defines the handoff. Roles may repeat."}
        </span>
      </header>

      <fieldset
        id="project-participants"
        className={`question-group team-participants ${errors.participants ? "invalid" : ""}`}
        tabIndex={-1}
        aria-describedby={
          errors.participants ? "project-participants-error" : undefined
        }
      >
        <legend>
          <Users aria-hidden="true" />
          <span>
            <strong>
              {es ? "Participantes planificados" : "Planned participants"}
            </strong>
            <small>
              {isWeb
                ? es
                  ? "De 1 a 4 · un participante por rol"
                  : "1 to 4 · one participant per role"
                : es
                  ? "De 1 a 6 · el orden se conserva"
                  : "1 to 6 · order is preserved"}
            </small>
          </span>
        </legend>
        <ol className="team-list">
          {project.participants.map((participant, index) => (
            <li key={participant.id}>
              <span className="team-list__order">{index + 1}</span>
              <div>
                <label htmlFor={`participant-role-${participant.id}`}>
                  <strong>{participant.id}</strong>
                  <small>{es ? "Rol canónico" : "Canonical role"}</small>
                </label>
                <select
                  id={`participant-role-${participant.id}`}
                  value={participant.role}
                  onChange={(event) => {
                    const role = event.target.value as CanonicalRole;
                    if (
                      isWeb &&
                      role !== participant.role &&
                      project.participants.some((item) => item.role === role)
                    )
                      return;
                    onChange({
                      ...project,
                      participants: project.participants.map((item) =>
                        item.id === participant.id
                          ? {
                              ...item,
                              role,
                              label: responsibilities[role][locale],
                            }
                          : item,
                      ),
                    });
                  }}
                >
                  {roles.map((role) => (
                    <option
                      key={role}
                      value={role}
                      disabled={
                        isWeb &&
                        role !== participant.role &&
                        project.participants.some((item) => item.role === role)
                      }
                    >
                      {roleLabels[locale][role]}
                    </option>
                  ))}
                </select>
                <span className="team-list__responsibility">
                  {responsibilities[participant.role][locale]}
                </span>
              </div>
              <button
                type="button"
                aria-label={
                  es ? `Quitar ${participant.id}` : `Remove ${participant.id}`
                }
                disabled={project.participants.length === 1}
                onClick={() =>
                  onChange({
                    ...project,
                    participants: project.participants.filter(
                      ({ id }) => id !== participant.id,
                    ),
                    orchestration: {
                      ...project.orchestration,
                      participants: project.orchestration.participants.filter(
                        ({ participantId }) => participantId !== participant.id,
                      ),
                    },
                  })
                }
              >
                <Trash2 aria-hidden="true" />
              </button>
            </li>
          ))}
        </ol>
        {errors.participants && (
          <p id="project-participants-error" className="field-error">
            {errorText(errors.participants)}
          </p>
        )}
        <button
          type="button"
          className="secondary"
          disabled={participantLimitReached}
          aria-describedby={
            isWeb && participantLimitReached
              ? "project-participant-limit"
              : undefined
          }
          onClick={onAddParticipant}
        >
          <Plus aria-hidden="true" />{" "}
          {es ? "Agregar participante" : "Add participant"}
        </button>
        {isWeb && (
          <p
            id="project-participant-limit"
            className="team-participants__limit"
            role="status"
          >
            {participantLimitReached
              ? project.participants.length > participantLimit
                ? es
                  ? "Este borrador tiene más de 4 participantes. Quita participantes para continuar."
                  : "This draft has more than 4 participants. Remove participants to continue."
                : es
                  ? "Máximo de 4 participantes alcanzado. Quita un participante para cambiar el equipo."
                  : "Maximum of 4 participants reached. Remove a participant to change the team."
              : es
                ? "Cada rol puede seleccionarse una sola vez."
                : "Each role can be selected once."}
          </p>
        )}
      </fieldset>

      <AdvancedDisclosure
        summary={
          project.orchestration.enabled
            ? es
              ? `Mode 1 configurado · ${project.participants.length} participante(s) · ${providers || "—"}`
              : `Mode 1 configured · ${project.participants.length} participant(s) · ${providers || "—"}`
            : es
              ? "Orquestación Mode 1 · modo manual"
              : "Mode 1 orchestration · manual mode"
        }
      >
        <section className="mode1-stage" aria-labelledby="mode1-stage-title">
          <h2 id="mode1-stage-title">
            <Terminal aria-hidden="true" />{" "}
            {es
              ? "Incluir instrucciones de orquestación"
              : "Include orchestration instructions"}
          </h2>
          <p>
            {es
              ? "Añade la preparación de herramientas para una ejecución coordinada. Configura las herramientas en tu equipo y comprueba el plan antes de ejecutarlo."
              : "Add tool preparation for coordinated execution. Configure the tools on your machine and check the plan before running it."}
          </p>
          {project.orchestration.enabled && (
            <ul className="configured-summary">
              <li>
                {es ? "Proveedores" : "Providers"}: {providers || "—"}
              </li>
              <li>
                {es ? "Duración" : "Duration"}:{" "}
                {Math.round(
                  project.orchestration.sessionMaxDurationSeconds / 60,
                )}{" "}
                min
              </li>
              <li>
                {es ? "Iteraciones/entidad" : "Iterations/entity"}:{" "}
                {project.orchestration.maxIterationsPerEntity}
              </li>
              <li>
                {es ? "Invocaciones" : "Invocations"}:{" "}
                {project.orchestration.maxProviderInvocations}
              </li>
              <li>
                {es ? "Financiación" : "Funding"}:{" "}
                {es ? "Suscripción/CLI local" : "Subscription/local CLI"}
              </li>
            </ul>
          )}
          {isWeb && (
            <p className="capability-note">
              {es
                ? "El ZIP incluye la configuración y las guías. Revisa los requisitos y el código generado antes de ejecutar herramientas locales. accreatio es solo web; el prototipo de escritorio está retirado y nunca se publicará."
                : "The ZIP includes configuration and guides. Review the requirements and generated code before running local tools. accreatio is web-only; the desktop prototype is retired and will never be released."}
            </p>
          )}
          {mode1Error && (
            <p id="project-mode1-error" className="field-error">
              {errorText(mode1Error)}
            </p>
          )}
          <div className="mode1-stage__actions">
            <button
              id="project-mode1-configuration"
              type="button"
              className={`secondary ${mode1Error ? "invalid" : ""}`}
              aria-describedby={mode1Error ? "project-mode1-error" : undefined}
              aria-invalid={Boolean(mode1Error)}
              ref={mode1TriggerRef}
              onClick={onConfigureMode1}
            >
              <Terminal aria-hidden="true" />
              {project.orchestration.enabled
                ? es
                  ? "Editar configuración"
                  : "Edit configuration"
                : es
                  ? "Preparar configuración Mode 1"
                  : "Prepare Mode 1 configuration"}
            </button>
            {project.orchestration.enabled && (
              <button
                type="button"
                className="secondary"
                onClick={() =>
                  updateOrchestration({
                    ...project.orchestration,
                    enabled: false,
                  })
                }
              >
                {es ? "Desactivar Mode 1" : "Disable Mode 1"}
              </button>
            )}
          </div>
        </section>
      </AdvancedDisclosure>
    </div>
  );
}
