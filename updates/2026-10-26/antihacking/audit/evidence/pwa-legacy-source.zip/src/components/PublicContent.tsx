import type { ReactNode } from "react";

export interface PublicContentSection {
  readonly id: string;
  readonly title: string;
  readonly content: ReactNode;
}

export function PublicContent({
  sections,
}: {
  sections: readonly PublicContentSection[];
}) {
  return (
    <div className="public-content">
      {sections.map((section) => (
        <section key={section.id} aria-labelledby={`${section.id}-title`}>
          <h2 id={`${section.id}-title`}>{section.title}</h2>
          {section.content}
        </section>
      ))}
    </div>
  );
}
