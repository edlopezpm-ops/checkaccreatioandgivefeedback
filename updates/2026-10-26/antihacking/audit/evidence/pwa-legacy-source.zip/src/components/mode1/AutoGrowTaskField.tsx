import React, { useEffect, useRef } from "react";
import { PROJECT_TEXT_LIMITS } from "../../../shared/inputValidation";

interface AutoGrowTaskFieldProps {
  id: string;
  label: string;
  value: string;
  invalid: boolean;
  errorText: string;
  onChange: (value: string) => void;
}

/** A textarea that grows with its content up to a CSS-defined `max-height`
 * (120-240px desktop, 112-200px narrow mobile per the approved design) and
 * only becomes internally scrollable once content actually exceeds that
 * bound -- never a permanent scrollbar for ordinary task text. */
export function AutoGrowTaskField({
  id,
  label,
  value,
  invalid,
  errorText,
  onChange,
}: AutoGrowTaskFieldProps) {
  const ref = useRef<HTMLTextAreaElement>(null);

  const grow = () => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto";
    const bound = parseFloat(getComputedStyle(el).maxHeight);
    const cap = Number.isFinite(bound) ? bound : Infinity;
    el.style.height = `${Math.min(el.scrollHeight, cap)}px`;
    el.style.overflowY = el.scrollHeight > cap ? "auto" : "hidden";
  };

  useEffect(() => {
    grow();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  useEffect(() => {
    window.addEventListener("resize", grow);
    return () => window.removeEventListener("resize", grow);
  }, []);

  const errorId = `${id}-error`;
  return (
    <label className="mode1-task-field" htmlFor={id}>
      <span className="mode1-task-field__label">{label}</span>
      <textarea
        id={id}
        ref={ref}
        value={value}
        maxLength={PROJECT_TEXT_LIMITS.task}
        aria-invalid={invalid || undefined}
        aria-describedby={invalid ? errorId : undefined}
        onChange={(event) => onChange(event.target.value)}
      />
      <small>
        {value.length}/{PROJECT_TEXT_LIMITS.task}
      </small>
      {invalid && (
        <small id={errorId} className="mode1-task-field__error" role="alert">
          {errorText}
        </small>
      )}
    </label>
  );
}
