import React, { useEffect, useId, useRef, useState } from "react";
import { CircleCheck, TriangleAlert, X } from "lucide-react";
import {
  PROVIDER_REGISTRY,
  isProviderId,
} from "../../../shared/providerRegistry";
import type {
  CanonicalRole,
  Locale,
  OrchestrationConfig,
  ParticipantInstance,
  ProviderAvailability,
  ProviderAvailabilityReason,
  ProviderId,
} from "../../types";
import {
  cloneMode1Draft,
  isMode1DraftDirty,
  isMode1DraftValid,
  normalizeMode1Draft,
  openMode1Draft,
  validateMode1Draft,
  type Mode1DialogDraft,
} from "./mode1Draft";
import { NumericDraftField } from "./NumericDraftField";
import { AutoGrowTaskField } from "./AutoGrowTaskField";

interface Mode1ConfigurationDialogProps {
  locale: Locale;
  projectName: string;
  participants: ParticipantInstance[];
  orchestration: OrchestrationConfig;
  providers: ProviderAvailability | null;
  checkingProviders: boolean;
  hostKind: "electron" | "web";
  onCheckProviders: () => void;
  providerReasonText: (reasonCode: ProviderAvailabilityReason) => string;
  responsibilityLabel: (role: CanonicalRole) => string;
  onSave: (config: OrchestrationConfig) => void;
  onClose: () => void;
}

const copy = {
  es: {
    title: "Configurar Mode 1",
    consequence:
      "Esta configuración se guarda solo cuando confirmas. Cerrar o cancelar descarta los cambios sin tocar la configuración guardada.",
    close: "Cerrar y descartar cambios",
    participantsHeading: "Participantes",
    participantsHelp: "Tarea para cada participante planificado, en orden.",
    providersHeading: "Proveedores",
    providersHelp: "Proveedor local para cada participante.",
    checkProviders: "Verificar proveedores",
    checkingProviders: "Verificando…",
    recheckProviders: "Volver a verificar proveedores",
    webProviderNote:
      "Este navegador no puede verificar la instalación ni el inicio de sesión de CLI locales. Puedes preparar y exportar esta configuración. Verifica por tu cuenta las herramientas locales antes de ejecutarlas; accreatio es solo web y su prototipo de escritorio está retirado.",
    notChecked: "No verificado",
    limitsHeading: "Límites de ejecución",
    limitsHelp: "Los cuatro límites que aplica AEKR durante la sesión.",
    fundingHeading: "Financiación",
    subscriptionTitle: "Suscripción/CLI local",
    subscriptionDetail: "Sin uso de API de pago · USD 0 · parada obligatoria",
    apiTitle: "API de pago",
    apiUnavailable:
      "No disponible: ningún proveedor/perfil compatible puede imponer un límite de coste acumulado exacto.",
    fundingSummary: (invocations: string) =>
      `También se detiene tras un máximo de ${invocations} invocaciones de proveedor; edítalo en Límites de ejecución.`,
    compatibilityBlocked:
      "Este plan de participantes se puede guardar para planificación, pero el contrato AEKR actual no puede vincular proveedores a estas instancias. Usa de 1 a 4 participantes con roles únicos para Mode 1.",
    fundingBlocked:
      "La política de financiación guardada en este proyecto no es válida ni compatible (por ejemplo, un estado de API sin resolver) y esta pantalla no puede repararla. Guardar queda bloqueado hasta que se resuelva; el resto de esta configuración de Mode 1 permanece intacto.",
    errorSummaryHeading: "Revisa los siguientes campos antes de guardar:",
    taskError: "La tarea es obligatoria.",
    providerError: "Elige un proveedor compatible.",
    dirtyNotice: "Los cambios sin guardar se descartarán.",
    cancel: "Cancelar",
    save: "Guardar configuración",
    sessionLabel: "Duración máxima de sesión (segundos)",
    sessionHelp: "Detiene la sesión Mode 1 tras esta duración (1–120 minutos).",
    sessionError: "Usa un entero entre 60 y 7200.",
    iterationsLabel: "Iteraciones máximas por entidad",
    iterationsHelp: "Límite de iteraciones para una entidad o tarea gobernada.",
    iterationsError: "Usa un entero entre 1 y 10.",
    invocationsLabel: "Invocaciones máximas de proveedor",
    invocationsHelp:
      "Límite de llamadas agregadas al proveedor. No es una estimación monetaria.",
    invocationsError: "Usa un entero entre 1 y 100.",
    failuresLabel: "Fallos consecutivos máximos",
    failuresHelp:
      "Detiene el progreso tras esta cantidad de fallos seguidos del proveedor. No es un número de reintentos automáticos.",
    failuresError: "Usa un entero entre 1 y 10.",
  },
  en: {
    title: "Configure Mode 1",
    consequence:
      "This configuration only saves when you confirm. Closing or cancelling discards changes without touching the saved configuration.",
    close: "Close and discard changes",
    participantsHeading: "Participants",
    participantsHelp: "Task for each planned participant, in order.",
    providersHeading: "Providers",
    providersHelp: "Local provider for each participant.",
    checkProviders: "Check provider availability",
    checkingProviders: "Checking…",
    recheckProviders: "Check providers again",
    webProviderNote:
      "This browser cannot check local CLI installation or sign-in. You can prepare and export this configuration. Verify local tools yourself before running them; accreatio is web-only and its desktop prototype is retired.",
    notChecked: "Not checked",
    limitsHeading: "Execution limits",
    limitsHelp: "The four limits AEKR applies during the session.",
    fundingHeading: "Funding",
    subscriptionTitle: "Subscription/local CLI",
    subscriptionDetail: "No paid API use · USD 0 · hard stop",
    apiTitle: "Paid API",
    apiUnavailable:
      "Unavailable: no supported provider/profile can enforce an exact cumulative cost ceiling.",
    fundingSummary: (invocations: string) =>
      `Also stops at no more than ${invocations} provider invocations; edit in Execution limits.`,
    compatibilityBlocked:
      "This participant plan can be saved for project planning, but the current AEKR Mode 1 format cannot bind providers to these participant instances. Use one to four participants with unique roles for Mode 1.",
    fundingBlocked:
      "This project's saved funding policy is invalid or unsupported (for example, an unresolved API state) and this screen cannot repair it. Save is blocked until it is resolved; the rest of this Mode 1 configuration is untouched.",
    errorSummaryHeading: "Review the following fields before saving:",
    taskError: "Task is required.",
    providerError: "Choose a supported provider.",
    dirtyNotice: "Unsaved changes will be discarded.",
    cancel: "Cancel",
    save: "Save configuration",
    sessionLabel: "Maximum session duration (seconds)",
    sessionHelp:
      "Stops the Mode 1 session after this duration (1-120 minutes).",
    sessionError: "Use a whole number between 60 and 7200.",
    iterationsLabel: "Maximum iterations per entity",
    iterationsHelp:
      "Limits how many governed iterations one entity may receive.",
    iterationsError: "Use a whole number between 1 and 10.",
    invocationsLabel: "Maximum provider invocations",
    invocationsHelp:
      "Limits aggregate provider calls for the execution. This is a call-count limit, not a monetary estimate.",
    invocationsError: "Use a whole number between 1 and 100.",
    failuresLabel: "Maximum consecutive failures",
    failuresHelp:
      "Stops or blocks progress after this many provider failures in a row. This is not an automatic retry count.",
    failuresError: "Use a whole number between 1 and 10.",
  },
} as const;

export function Mode1ConfigurationDialog({
  locale,
  projectName,
  participants,
  orchestration,
  providers,
  checkingProviders,
  hostKind,
  onCheckProviders,
  providerReasonText,
  responsibilityLabel,
  onSave,
  onClose,
}: Mode1ConfigurationDialogProps) {
  const c = copy[locale];
  const dialogRef = useRef<HTMLDialogElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const errorSummaryRef = useRef<HTMLDivElement>(null);
  const headingId = useId();
  const descId = useId();
  const [openSnapshot] = useState<Mode1DialogDraft>(() =>
    openMode1Draft(participants, orchestration, projectName),
  );
  const [draft, setDraft] = useState<Mode1DialogDraft>(() =>
    cloneMode1Draft(openSnapshot),
  );
  const [attemptedSave, setAttemptedSave] = useState(false);

  useEffect(() => {
    dialogRef.current?.showModal();
    headingRef.current?.focus();
    document.body.classList.add("mode1-dialog-open");
    return () => {
      document.body.classList.remove("mode1-dialog-open");
    };
  }, []);

  const errors = validateMode1Draft(draft);
  const hasErrors = !isMode1DraftValid(draft);
  const dirty = isMode1DraftDirty(draft, openSnapshot);

  useEffect(() => {
    if (attemptedSave && hasErrors) errorSummaryRef.current?.focus();
  }, [attemptedSave, hasErrors]);

  const updateParticipant = (
    participantId: string,
    patch: Partial<Mode1DialogDraft["participants"][number]>,
  ) =>
    setDraft((current) => ({
      ...current,
      participants: current.participants.map((row) =>
        row.participantId === participantId ? { ...row, ...patch } : row,
      ),
    }));

  const handleSave = () => {
    const normalized = normalizeMode1Draft(draft);
    if (!normalized) {
      setAttemptedSave(true);
      return;
    }
    onSave(normalized);
    dialogRef.current?.close();
  };

  const focusField = (id: string) => document.getElementById(id)?.focus();

  const errorItems: { id: string; label: string; fieldId: string }[] = [];
  for (const row of draft.participants) {
    if (errors.participants[row.participantId] === "task")
      errorItems.push({
        id: `${row.participantId}-task-error`,
        label: `${row.participantId}: ${c.taskError}`,
        fieldId: `mode1-task-${row.participantId}`,
      });
    if (errors.participants[row.participantId] === "provider")
      errorItems.push({
        id: `${row.participantId}-provider-error`,
        label: `${row.participantId}: ${c.providerError}`,
        fieldId: `mode1-provider-${row.participantId}`,
      });
  }
  if (errors.sessionMaxDurationSeconds)
    errorItems.push({
      id: "session-error",
      label: c.sessionError,
      fieldId: "mode1-session-duration",
    });
  if (errors.maxIterationsPerEntity)
    errorItems.push({
      id: "iterations-error",
      label: c.iterationsError,
      fieldId: "mode1-iterations",
    });
  if (errors.maxProviderInvocations)
    errorItems.push({
      id: "invocations-error",
      label: c.invocationsError,
      fieldId: "mode1-invocations",
    });
  if (errors.maxConsecutiveFailures)
    errorItems.push({
      id: "failures-error",
      label: c.failuresError,
      fieldId: "mode1-failures",
    });
  if (errors.funding)
    errorItems.push({
      id: "funding-error",
      label: c.fundingBlocked,
      fieldId: `${headingId}-funding`,
    });

  return (
    <dialog
      ref={dialogRef}
      className="mode1-dialog"
      aria-labelledby={headingId}
      aria-describedby={descId}
      onClose={onClose}
    >
      <div className="mode1-dialog__shell">
        <header className="mode1-dialog__header">
          <div>
            <h2 id={headingId} ref={headingRef} tabIndex={-1}>
              {c.title}
            </h2>
            <p id={descId} className="mode1-dialog__consequence">
              {c.consequence}
            </p>
          </div>
          <button
            type="button"
            className="mode1-dialog__close"
            aria-label={c.close}
            onClick={() => dialogRef.current?.close()}
          >
            <X />
          </button>
        </header>

        {attemptedSave && hasErrors && (
          <div
            ref={errorSummaryRef}
            className="mode1-dialog__error-summary"
            role="alert"
            tabIndex={-1}
          >
            <p>{c.errorSummaryHeading}</p>
            <ul>
              {errorItems.map((item) => (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => focusField(item.fieldId)}
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="mode1-dialog__body">
          <section
            className="mode1-dialog__group"
            aria-labelledby={`${headingId}-participants`}
          >
            <h3 id={`${headingId}-participants`}>{c.participantsHeading}</h3>
            <p className="mode1-dialog__group-help">{c.participantsHelp}</p>
            {draft.participants.map((row, index) => (
              <div key={row.participantId} className="mode1-participant-row">
                <div className="mode1-participant-row__header">
                  <strong>
                    {locale === "es" ? "Participante" : "Participant"}{" "}
                    {index + 1} · {row.participantId}
                  </strong>
                  <span>{responsibilityLabel(row.role)}</span>
                </div>
                <AutoGrowTaskField
                  id={`mode1-task-${row.participantId}`}
                  label={
                    locale === "es"
                      ? `Tarea para participante ${index + 1} (${responsibilityLabel(row.role)})`
                      : `Task for participant ${index + 1} (${responsibilityLabel(row.role)})`
                  }
                  value={row.task}
                  invalid={errors.participants[row.participantId] === "task"}
                  errorText={c.taskError}
                  onChange={(value) =>
                    updateParticipant(row.participantId, { task: value })
                  }
                />
              </div>
            ))}
          </section>

          <section
            className="mode1-dialog__group"
            aria-labelledby={`${headingId}-providers`}
          >
            <h3 id={`${headingId}-providers`}>{c.providersHeading}</h3>
            <p className="mode1-dialog__group-help">{c.providersHelp}</p>

            {draft.compatibilityBlocked && (
              <p className="mode1-dialog__compatibility-warning" role="alert">
                {c.compatibilityBlocked}
              </p>
            )}

            {hostKind === "electron" ? (
              <button
                type="button"
                className="secondary"
                onClick={onCheckProviders}
                disabled={checkingProviders}
                aria-busy={checkingProviders}
              >
                {checkingProviders
                  ? c.checkingProviders
                  : providers
                    ? c.recheckProviders
                    : c.checkProviders}
              </button>
            ) : (
              <p className="mode1-dialog__provider-note">{c.webProviderNote}</p>
            )}

            {draft.participants.map((row, index) => {
              const status = providers?.find(
                ({ providerId }) => providerId === row.provider,
              );
              return (
                <div key={row.participantId} className="mode1-provider-row">
                  <label htmlFor={`mode1-provider-${row.participantId}`}>
                    {locale === "es" ? "Proveedor para" : "Provider for"} #
                    {index + 1} {row.participantId}
                  </label>
                  <select
                    id={`mode1-provider-${row.participantId}`}
                    value={row.provider}
                    aria-invalid={
                      errors.participants[row.participantId] === "provider" ||
                      undefined
                    }
                    onChange={(event) =>
                      updateParticipant(row.participantId, {
                        provider: event.target.value as ProviderId,
                      })
                    }
                  >
                    {!isProviderId(row.provider) && (
                      <option value={row.provider} disabled>
                        {locale === "es"
                          ? `Proveedor no compatible: ${row.provider}`
                          : `Unsupported provider: ${row.provider}`}
                      </option>
                    )}
                    {PROVIDER_REGISTRY.map((descriptor) => (
                      <option key={descriptor.id} value={descriptor.id}>
                        {descriptor.displayName}
                      </option>
                    ))}
                  </select>
                  <span
                    className="mode1-provider-row__status"
                    aria-live="polite"
                  >
                    {status?.state === "installed_authenticated" ? (
                      <CircleCheck size={14} />
                    ) : (
                      <TriangleAlert size={14} />
                    )}
                    {status
                      ? providerReasonText(status.reasonCode)
                      : c.notChecked}
                  </span>
                </div>
              );
            })}
          </section>

          <section
            className="mode1-dialog__group"
            aria-labelledby={`${headingId}-limits`}
          >
            <h3 id={`${headingId}-limits`}>{c.limitsHeading}</h3>
            <p className="mode1-dialog__group-help">{c.limitsHelp}</p>
            <div className="mode1-dialog__limits-grid">
              <NumericDraftField
                id="mode1-session-duration"
                label={c.sessionLabel}
                help={c.sessionHelp}
                errorText={c.sessionError}
                value={draft.sessionMaxDurationSeconds}
                invalid={errors.sessionMaxDurationSeconds}
                showErrors={attemptedSave}
                onChange={(value) =>
                  setDraft((current) => ({
                    ...current,
                    sessionMaxDurationSeconds: value,
                  }))
                }
              />
              <NumericDraftField
                id="mode1-iterations"
                label={c.iterationsLabel}
                help={c.iterationsHelp}
                errorText={c.iterationsError}
                value={draft.maxIterationsPerEntity}
                invalid={errors.maxIterationsPerEntity}
                showErrors={attemptedSave}
                onChange={(value) =>
                  setDraft((current) => ({
                    ...current,
                    maxIterationsPerEntity: value,
                  }))
                }
              />
              <NumericDraftField
                id="mode1-invocations"
                label={c.invocationsLabel}
                help={c.invocationsHelp}
                errorText={c.invocationsError}
                value={draft.maxProviderInvocations}
                invalid={errors.maxProviderInvocations}
                showErrors={attemptedSave}
                onChange={(value) =>
                  setDraft((current) => ({
                    ...current,
                    maxProviderInvocations: value,
                  }))
                }
              />
              <NumericDraftField
                id="mode1-failures"
                label={c.failuresLabel}
                help={c.failuresHelp}
                errorText={c.failuresError}
                value={draft.maxConsecutiveFailures}
                invalid={errors.maxConsecutiveFailures}
                showErrors={attemptedSave}
                onChange={(value) =>
                  setDraft((current) => ({
                    ...current,
                    maxConsecutiveFailures: value,
                  }))
                }
              />
            </div>
          </section>

          <section
            className="mode1-dialog__group"
            aria-labelledby={`${headingId}-funding`}
          >
            <h3 id={`${headingId}-funding`}>{c.fundingHeading}</h3>
            {errors.funding && (
              <p className="mode1-dialog__compatibility-warning" role="alert">
                {c.fundingBlocked}
              </p>
            )}
            <fieldset className="mode1-funding-fieldset">
              <legend>{c.fundingHeading}</legend>
              <label className="funding-option selected">
                <input
                  type="radio"
                  name="mode1-funding-mode"
                  value="subscription_cli"
                  checked
                  readOnly
                />
                <span>
                  <strong>{c.subscriptionTitle}</strong>
                  <small>{c.subscriptionDetail}</small>
                </span>
              </label>
              <label className="funding-option unavailable">
                <input
                  type="radio"
                  name="mode1-funding-mode"
                  value="api"
                  disabled
                  aria-describedby="mode1-api-funding-unavailable"
                />
                <span>
                  <strong>{c.apiTitle}</strong>
                  <small id="mode1-api-funding-unavailable">
                    {c.apiUnavailable}
                  </small>
                </span>
              </label>
              <p className="funding-summary">
                {c.fundingSummary(draft.maxProviderInvocations)}
              </p>
            </fieldset>
          </section>
        </div>

        <footer className="mode1-dialog__footer">
          <span className="mode1-dialog__dirty-notice">
            {dirty ? c.dirtyNotice : ""}
          </span>
          <div className="mode1-dialog__footer-actions">
            <button type="button" onClick={() => dialogRef.current?.close()}>
              {c.cancel}
            </button>
            <button type="button" className="confirm" onClick={handleSave}>
              {c.save}
            </button>
          </div>
        </footer>
      </div>
    </dialog>
  );
}
