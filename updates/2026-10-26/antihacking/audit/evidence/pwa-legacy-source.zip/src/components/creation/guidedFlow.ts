import type { Phase } from "../../types";
import type { CreationStage } from "./StageNavigation";

export const GUIDED_QUESTIONS = [
  "name",
  "phase",
  "attachments",
  "context",
  "restrictions",
  "route",
  "team",
  "delivery",
  "review",
] as const;

export type GuidedQuestion = (typeof GUIDED_QUESTIONS)[number];

export const guidedQuestions = (
  phase: Phase,
  isWeb = false,
  current?: GuidedQuestion,
): GuidedQuestion[] =>
  GUIDED_QUESTIONS.filter(
    (question) =>
      (question !== "attachments" || phase !== "idea") &&
      (!isWeb ||
        !["route", "team", "delivery"].includes(question) ||
        question === current),
  );

export const questionStage = (question: GuidedQuestion): CreationStage =>
  question === "name" || question === "phase" || question === "attachments"
    ? "foundation"
    : question === "context" ||
        question === "restrictions" ||
        question === "route"
      ? "context"
      : question;

export const stageQuestion = (stage: CreationStage): GuidedQuestion =>
  stage === "foundation" ? "name" : stage;

const questionFields: Record<GuidedQuestion, readonly string[]> = {
  name: ["name"],
  phase: [],
  attachments: ["attachments"],
  context: ["context"],
  restrictions: ["restrictions"],
  route: [],
  team: ["participants", "orchestration", "funding"],
  delivery: ["destination", "tracking", "openIde", "createRemote"],
  review: [],
};

export const questionInvalid = (
  question: GuidedQuestion,
  errors: Record<string, string>,
) => questionFields[question].some((field) => Boolean(errors[field]));

export const canMoveToQuestion = (
  current: GuidedQuestion,
  next: GuidedQuestion,
  errors: Record<string, string>,
) =>
  GUIDED_QUESTIONS.indexOf(next) < GUIDED_QUESTIONS.indexOf(current) ||
  !questionInvalid(current, errors);
