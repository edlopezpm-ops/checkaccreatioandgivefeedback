import React, { useEffect, useRef, type ReactNode } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronRight,
  ShieldCheck,
  Users,
} from "lucide-react";
import type { Locale, ProjectDefinition } from "../../types";
import { PROJECT_TEXT_LIMITS } from "../../../shared/inputValidation";
import { guidedQuestions, type GuidedQuestion } from "./guidedFlow";
import { ProjectHelp, type ProjectHelpSection } from "./ProjectHelp";

interface GuidedCreationProps {
  isWeb?: boolean;
  children: ReactNode;
  current: GuidedQuestion;
  feedback: string | null;
  hasReviewed: boolean;
  locale: Locale;
  onMove: (question: GuidedQuestion) => void;
  onHelp?: (section: ProjectHelpSection) => void;
  project: ProjectDefinition;
  toolbar: ReactNode;
}

const labels: Record<Locale, Record<GuidedQuestion, string>> = {
  es: {
    name: "Tu proyecto",
    phase: "Punto de partida",
    attachments: "Tus archivos",
    context: "Tu idea",
    restrictions: "Tus límites",
    route: "Forma de trabajo",
    team: "Tu equipo",
    delivery: "La entrega",
    review: "Revisión final",
  },
  en: {
    name: "Your project",
    phase: "Starting point",
    attachments: "Your files",
    context: "Your idea",
    restrictions: "Your boundaries",
    route: "Working approach",
    team: "Your team",
    delivery: "Your delivery",
    review: "Final review",
  },
};

export function GuidedCreation({
  isWeb = false,
  children,
  current,
  feedback,
  hasReviewed,
  locale,
  onMove,
  onHelp,
  project,
  toolbar,
}: GuidedCreationProps) {
  const es = locale === "es";
  const questions = guidedQuestions(project.phase, isWeb, current);
  const index = questions.indexOf(current);
  const surface = useRef<HTMLElement>(null);
  const previous = questions[index - 1];
  const next = questions[index + 1];
  const optional =
    (current === "restrictions" && !project.restrictions.trim()) ||
    (current === "attachments" && !project.attachments.length);

  useEffect(() => {
    const title = surface.current?.querySelector<HTMLElement>("h1");
    if (title) {
      title.tabIndex = -1;
      title.focus({ preventScroll: true });
      // A short viewport can retain scroll beneath the sticky, wrapping header.
      // Measure that header; a fixed rem offset cannot cover every breakpoint.
      const headerBottom = Math.max(
        0,
        document.querySelector(".app-header")?.getBoundingClientRect().bottom ??
          0,
      );
      const bounds = title.getBoundingClientRect();
      const clearance = headerBottom + 24;
      if (bounds.top < clearance || bounds.bottom > window.innerHeight) {
        const smooth =
          surface.current?.closest(".app-shell--web") &&
          !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        window.scrollBy({
          top: bounds.top - clearance,
          behavior: smooth ? "smooth" : "instant",
        });
      }
    }
  }, [current]);

  return (
    <main
      className={`guided-creation${current === "review" ? " guided-creation--review" : ""}`}
    >
      <div className="guided-creation__toolbar">{toolbar}</div>
      {hasReviewed && current !== "review" && (
        <button
          type="button"
          className="guided-creation__return secondary"
          onClick={() => onMove("review")}
        >
          {es ? "Volver a revisión" : "Back to review"}
          <ArrowRight aria-hidden="true" />
        </button>
      )}
      <div className="guided-creation__progress">
        <div
          className="guided-creation__position"
          aria-live="polite"
          aria-atomic="true"
        >
          <span>
            {es
              ? `Paso ${index + 1} de ${questions.length}`
              : `Step ${index + 1} of ${questions.length}`}
          </span>
          <strong>{labels[locale][current]}</strong>
        </div>
        <div
          className="guided-creation__track"
          role="progressbar"
          aria-label={es ? "Progreso del proyecto" : "Project progress"}
          aria-valuemin={1}
          aria-valuemax={questions.length}
          aria-valuenow={index + 1}
          aria-valuetext={labels[locale][current]}
        >
          <span
            style={{ width: `${((index + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>
      <section className="guided-creation__surface panel" ref={surface}>
        <div
          className="guided-creation__question"
          key={current}
          data-question={current}
        >
          {children}
        </div>
        {feedback && (
          <p className="guided-creation__feedback field-error" role="alert">
            {feedback}
          </p>
        )}
        <div className="guided-creation__actions">
          {previous ? (
            <button
              type="button"
              className="secondary"
              onClick={() => onMove(previous)}
            >
              <ArrowLeft aria-hidden="true" />
              {es ? "Pregunta anterior" : "Previous question"}
            </button>
          ) : (
            <span />
          )}
          {next && (
            <button
              type="button"
              className="primary guided-creation__continue"
              onClick={() => onMove(next)}
            >
              {next === "review"
                ? es
                  ? "Revisar mi proyecto"
                  : "Review my project"
                : optional
                  ? es
                    ? "Omitir por ahora"
                    : "Skip for now"
                  : es
                    ? "Continuar"
                    : "Continue"}
              <ArrowRight aria-hidden="true" />
            </button>
          )}
        </div>
      </section>
      {onHelp ? (
        <ProjectHelp locale={locale} onOpen={onHelp} reassure />
      ) : (
        <p className="guided-creation__reassurance">
          <ShieldCheck aria-hidden="true" />
          {es
            ? "Puedes volver y cambiar tus respuestas. Tú confirmas al final."
            : "You can go back and change your answers. You confirm at the end."}
        </p>
      )}
    </main>
  );
}

interface GuidedBasicsProps {
  current: "name" | "phase" | "context" | "restrictions" | "route";
  errorText: (code?: string) => string | undefined;
  errors: Record<string, string>;
  isWeb?: boolean;
  locale: Locale;
  onChange: (project: ProjectDefinition) => void;
  onMove: (question: GuidedQuestion) => void;
  onPhaseChange: (phase: ProjectDefinition["phase"]) => boolean;
  project: ProjectDefinition;
}

export function GuidedBasics({
  current,
  errorText,
  errors,
  isWeb = false,
  locale,
  onChange,
  onMove,
  onPhaseChange,
  project,
}: GuidedBasicsProps) {
  const es = locale === "es";
  const nameLimit = isWeb ? 50 : 80;
  const title = {
    name: es ? "¿Cómo se llama tu proyecto?" : "What is your project called?",
    phase: es ? "¿En qué punto estás?" : "Where are you starting?",
    context: es ? "¿Qué quieres crear?" : "What would you like to create?",
    restrictions: es
      ? "¿Hay algún límite que debamos respetar?"
      : "Any boundaries we should respect?",
    route: es
      ? "¿Cómo prefieres construirlo?"
      : "How would you like to build it?",
  }[current];
  const hint = {
    name: es
      ? "Un nombre corto es suficiente. Puedes cambiarlo después."
      : "A short name is enough. You can change it later.",
    phase: es
      ? "Así adaptamos el siguiente paso a lo que ya tienes."
      : "We'll adapt the next step to what you already have.",
    context: es
      ? "Cuéntanos qué hará, para quién y qué problema resolverá. Unas frases bastan."
      : "Tell us what it will do, who it is for, and the problem it solves. A few sentences are enough.",
    restrictions: es
      ? "Opcional. Por ejemplo: sin servicios de pago, solo Windows o datos siempre locales."
      : "Optional. For example: no paid services, Windows only, or data always stays local.",
    route: es
      ? "Esto orienta el plan. Puedes cambiar tu preferencia después."
      : "This guides the plan. You can change your preference later.",
  }[current];
  const textQuestion =
    current === "name" || current === "context" || current === "restrictions";
  const fieldId = `project-${current}`;
  const advanceText = () =>
    onMove(
      current === "name"
        ? "phase"
        : current === "context"
          ? "restrictions"
          : isWeb
            ? "review"
            : "route",
    );

  return (
    <div
      className="creation-stage guided-basics"
      aria-labelledby="guided-question-title"
    >
      <header className="creation-stage__header">
        <h1 id="guided-question-title">{title}</h1>
        <span id="guided-question-hint">{hint}</span>
      </header>
      {textQuestion ? (
        <div className={`question-group${errors[current] ? " invalid" : ""}`}>
          <label htmlFor={fieldId}>
            {current === "name"
              ? es
                ? "Nombre del proyecto"
                : "Project name"
              : current === "context"
                ? es
                  ? "Tu idea"
                  : "Your idea"
                : es
                  ? "Tus límites (opcional)"
                  : "Your boundaries (optional)"}
          </label>
          {current === "name" ? (
            <input
              id={fieldId}
              autoComplete="off"
              maxLength={nameLimit}
              value={project.name}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={`guided-question-hint${errors.name ? " project-name-error" : ""}`}
              onChange={(event) =>
                onChange({ ...project, name: event.target.value })
              }
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.nativeEvent.isComposing) {
                  event.preventDefault();
                  advanceText();
                }
              }}
              placeholder={
                es ? "Ej.: Mi huerto urbano" : "E.g. My urban garden"
              }
            />
          ) : (
            <textarea
              id={fieldId}
              maxLength={PROJECT_TEXT_LIMITS[current]}
              value={project[current]}
              aria-invalid={Boolean(errors[current])}
              aria-describedby={`guided-question-hint${errors[current] ? ` ${fieldId}-error` : ""}`}
              onChange={(event) =>
                onChange({ ...project, [current]: event.target.value })
              }
              placeholder={
                current === "context"
                  ? es
                    ? "Quiero crear una app para…"
                    : "I'd like to create an app that…"
                  : es
                    ? "Escribe lo que importa para tu proyecto…"
                    : "Add what matters for your project…"
              }
            />
          )}
          {current === "name" && (
            <small className="guided-basics__count">
              {project.name.length}/{nameLimit}
            </small>
          )}
          {(current === "context" || current === "restrictions") && (
            <small className="guided-basics__count">
              {project[current].length}/{PROJECT_TEXT_LIMITS[current]}
            </small>
          )}
          {errors[current] && (
            <p id={`${fieldId}-error`} className="field-error">
              {errorText(errors[current])}
            </p>
          )}
        </div>
      ) : (
        <div
          className="guided-choice-group"
          role="group"
          aria-labelledby="guided-question-title"
          aria-describedby="guided-choice-hint"
        >
          <p id="guided-choice-hint" className="guided-choice-hint">
            {es
              ? "Elige una opción para continuar."
              : "Choose an option to continue."}
          </p>
          {current === "phase"
            ? (
                [
                  [
                    "idea",
                    es
                      ? "Estoy empezando con una idea"
                      : "I'm starting with an idea",
                    es
                      ? "Todavía no tengo investigación ni documentos."
                      : "I don't have research or documents yet.",
                  ],
                  [
                    "discovery-active",
                    es ? "Estoy investigando" : "I'm exploring the idea",
                    es
                      ? "Tengo notas o material que aún estoy reuniendo."
                      : "I have notes or material I'm still gathering.",
                  ],
                  [
                    "discovery-complete",
                    es ? "Ya tengo la idea definida" : "I've defined the idea",
                    es
                      ? "Tengo investigación o requisitos listos para usar."
                      : "I have research or requirements ready to use.",
                  ],
                ] as const
              ).map(([value, label, description]) => (
                <button
                  type="button"
                  className="guided-choice"
                  key={value}
                  aria-pressed={project.phase === value}
                  onClick={() => {
                    if (onPhaseChange(value))
                      onMove(value === "idea" ? "context" : "attachments");
                  }}
                >
                  <span className="guided-choice__indicator">
                    {project.phase === value && <Check aria-hidden="true" />}
                  </span>
                  <span>
                    <strong>{label}</strong>
                    <small>{description}</small>
                  </span>
                  <ChevronRight aria-hidden="true" />
                </button>
              ))
            : (
                [
                  [
                    "local",
                    es ? "Con herramientas locales" : "With local tools",
                    es
                      ? "Priorizar mi equipo y mantener el control de mis datos."
                      : "Prioritize my computer and keep control of my data.",
                  ],
                  [
                    "vendor",
                    es
                      ? "Con una plataforma gestionada"
                      : "With a managed platform",
                    es
                      ? "Usar un servicio que se encargue de la infraestructura."
                      : "Use a service that manages the infrastructure.",
                  ],
                  [
                    "mixed",
                    es ? "Combinando ambas" : "A combination of both",
                    es
                      ? "Elegir herramientas locales y servicios según lo que necesite."
                      : "Choose local tools and services as needed.",
                  ],
                ] as const
              ).map(([value, label, description]) => (
                <button
                  type="button"
                  className="guided-choice"
                  key={value}
                  aria-pressed={project.route === value}
                  onClick={() => {
                    onChange({ ...project, route: value });
                    onMove("team");
                  }}
                >
                  <span className="guided-choice__indicator">
                    {project.route === value && <Check aria-hidden="true" />}
                  </span>
                  <span>
                    <strong>{label}</strong>
                    <small>{description}</small>
                  </span>
                  <ChevronRight aria-hidden="true" />
                </button>
              ))}
        </div>
      )}
    </div>
  );
}

export function GuidedTeam({
  children,
  isWeb = false,
  locale,
  project,
  invalid,
}: {
  children: ReactNode;
  isWeb?: boolean;
  locale: Locale;
  project: ProjectDefinition;
  invalid: boolean;
}) {
  const es = locale === "es";
  const details = useRef<HTMLDetailsElement>(null);
  useEffect(() => {
    if (invalid && details.current) details.current.open = true;
  }, [invalid]);
  const roleLabels = es
    ? {
        generalist: "generalista",
        architect: "arquitecto",
        implementer: "implementador",
        auditor: "auditor",
      }
    : {
        generalist: "generalist",
        architect: "architect",
        implementer: "implementer",
        auditor: "auditor",
      };
  return (
    <div className="creation-stage guided-team">
      <header className="creation-stage__header">
        <h1>
          {es
            ? "¿Quién trabajará en tu proyecto?"
            : "Who will work on your project?"}
        </h1>
        <span>
          {es
            ? "Un generalista es un buen punto de partida. Puedes definir más roles si los necesitas."
            : "A generalist is a good starting point. You can define more roles if you need them."}
        </span>
      </header>
      <div className="guided-team__summary">
        <span className="guided-team__icon">
          <Check aria-hidden="true" />
        </span>
        <div>
          <strong>
            {es
              ? `${project.participants.length} participante(s) en tu plan`
              : `${project.participants.length} participant(s) in your plan`}
          </strong>
          <p>
            {project.participants
              .map((participant) => roleLabels[participant.role])
              .join(" · ")}
          </p>
          <small>
            {es
              ? "Definir roles prepara instrucciones; no contrata ni ejecuta agentes."
              : "Defining roles prepares instructions; it doesn't hire or run agents."}
          </small>
        </div>
      </div>
      <details
        className="guided-team__customization advanced-disclosure"
        ref={details}
      >
        <summary>
          {isWeb ? (
            <>
              <Users aria-hidden="true" />
              <span>
                <strong>
                  {es ? "Opciones avanzadas" : "Advanced options"}
                </strong>
                <small>
                  {es
                    ? "Elige hasta 4 roles distintos y cómo trabajarán juntos."
                    : "Choose up to 4 unique roles and how they work together."}
                </small>
              </span>
              <ChevronRight aria-hidden="true" />
            </>
          ) : es ? (
            "Personalizar equipo y orquestación"
          ) : (
            "Customize team and orchestration"
          )}
        </summary>
        <div>{children}</div>
      </details>
    </div>
  );
}
