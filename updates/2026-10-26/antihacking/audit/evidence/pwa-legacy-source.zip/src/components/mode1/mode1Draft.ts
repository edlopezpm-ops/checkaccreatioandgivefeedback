import { defaultRoleTask } from "../../../shared/domain";
import {
  PROJECT_TEXT_LIMITS,
  validText,
} from "../../../shared/inputValidation";
import { evaluateFundingEligibility } from "../../../shared/funding";
import {
  DEFAULT_PROVIDER_ID,
  PROVIDER_REGISTRY,
  isProviderId,
  isSerializableProvider,
} from "../../../shared/providerRegistry";
import type {
  CanonicalRole,
  FundingPolicy,
  OrchestrationConfig,
  ParticipantInstance,
  ProviderId,
} from "../../types";

export interface Mode1ParticipantDraftRow {
  participantId: string;
  role: CanonicalRole;
  label: string;
  provider: string;
  task: string;
}

export interface Mode1DialogDraft {
  participants: Mode1ParticipantDraftRow[];
  sessionMaxDurationSeconds: string;
  maxIterationsPerEntity: string;
  maxProviderInvocations: string;
  maxConsecutiveFailures: string;
  funding: FundingPolicy;
  compatibilityBlocked: boolean;
}

export type NumericLimitKey =
  | "sessionMaxDurationSeconds"
  | "maxIterationsPerEntity"
  | "maxProviderInvocations"
  | "maxConsecutiveFailures";

export const NUMERIC_LIMIT_TABLE: Record<
  NumericLimitKey,
  { min: number; max: number }
> = {
  sessionMaxDurationSeconds: { min: 60, max: 7200 },
  maxIterationsPerEntity: { min: 1, max: 10 },
  maxProviderInvocations: { min: 1, max: 100 },
  maxConsecutiveFailures: { min: 1, max: 10 },
};

/** Compatible only when the current AEKR-consumed contract can serialize this
 * topology: 1-4 participants with unique canonical roles. See
 * shared/domain.ts's own `orchestrationContractUnsupported` guard, which
 * this mirrors so the dialog can fail closed before Save. */
export function isAekrCompatibleTopology(
  participants: readonly Pick<ParticipantInstance, "role">[],
): boolean {
  const roles = participants.map(({ role }) => role);
  return participants.length <= 4 && new Set(roles).size === roles.length;
}

export function openMode1Draft(
  participants: readonly ParticipantInstance[],
  orchestration: OrchestrationConfig,
  projectName: string,
): Mode1DialogDraft {
  const rows: Mode1ParticipantDraftRow[] = participants.map((participant) => {
    const existing = orchestration.participants.find(
      (entry) => entry.participantId === participant.id,
    );
    return {
      participantId: participant.id,
      role: participant.role,
      label: participant.label,
      provider: existing?.provider ?? DEFAULT_PROVIDER_ID,
      task: existing?.task ?? defaultRoleTask(participant.role, projectName),
    };
  });
  return {
    participants: rows,
    sessionMaxDurationSeconds: String(orchestration.sessionMaxDurationSeconds),
    maxIterationsPerEntity: String(orchestration.maxIterationsPerEntity),
    maxProviderInvocations: String(orchestration.maxProviderInvocations),
    maxConsecutiveFailures: String(orchestration.maxConsecutiveFailures),
    funding: orchestration.funding,
    compatibilityBlocked: !isAekrCompatibleTopology(participants),
  };
}

export function cloneMode1Draft(draft: Mode1DialogDraft): Mode1DialogDraft {
  return {
    ...draft,
    participants: draft.participants.map((row) => ({ ...row })),
    funding: { ...draft.funding },
  };
}

export function isMode1DraftDirty(
  draft: Mode1DialogDraft,
  openSnapshot: Mode1DialogDraft,
): boolean {
  return JSON.stringify(draft) !== JSON.stringify(openSnapshot);
}

export function parseIntegerInRange(
  value: string,
  min: number,
  max: number,
): number | null {
  const trimmed = value.trim();
  if (!/^\d+$/.test(trimmed)) return null;
  const parsed = Number(trimmed);
  if (!Number.isSafeInteger(parsed) || parsed < min || parsed > max)
    return null;
  return parsed;
}

export interface Mode1DraftErrors {
  participants: Record<string, "task" | "provider">;
  sessionMaxDurationSeconds: boolean;
  maxIterationsPerEntity: boolean;
  maxProviderInvocations: boolean;
  maxConsecutiveFailures: boolean;
  compatibility: boolean;
  funding: boolean;
}

/** Mirrors the project-level funding gate (shared/domain.ts) inside the
 * dialog draft so an already-invalid/unsupported funding policy (e.g. a
 * malformed or API object surviving migration) cannot be silently re-saved
 * while the dialog displays the unrelated, always-selected subscription
 * option. See TASK-UX-MODE1/CODEX_REVIEW.md finding H1. */
function isDraftFundingValid(draft: Mode1DialogDraft): boolean {
  return evaluateFundingEligibility(
    draft.funding,
    draft.participants.map(({ participantId, provider }) => ({
      participantId,
      provider,
    })),
    PROVIDER_REGISTRY,
  ).valid;
}

export function validateMode1Draft(draft: Mode1DialogDraft): Mode1DraftErrors {
  const participantErrors: Record<string, "task" | "provider"> = {};
  for (const row of draft.participants) {
    if (!row.task.trim() || !validText(row.task, PROJECT_TEXT_LIMITS.task))
      participantErrors[row.participantId] = "task";
    else if (
      !isProviderId(row.provider) ||
      !isSerializableProvider(row.provider)
    )
      participantErrors[row.participantId] = "provider";
  }
  const numeric: Record<NumericLimitKey, boolean> = {
    sessionMaxDurationSeconds: false,
    maxIterationsPerEntity: false,
    maxProviderInvocations: false,
    maxConsecutiveFailures: false,
  };
  for (const key of Object.keys(NUMERIC_LIMIT_TABLE) as NumericLimitKey[]) {
    const { min, max } = NUMERIC_LIMIT_TABLE[key];
    numeric[key] = parseIntegerInRange(draft[key], min, max) === null;
  }
  return {
    participants: participantErrors,
    compatibility: draft.compatibilityBlocked,
    funding: !isDraftFundingValid(draft),
    ...numeric,
  };
}

export function isMode1DraftValid(draft: Mode1DialogDraft): boolean {
  const errors = validateMode1Draft(draft);
  return (
    !errors.compatibility &&
    !errors.funding &&
    Object.keys(errors.participants).length === 0 &&
    !errors.sessionMaxDurationSeconds &&
    !errors.maxIterationsPerEntity &&
    !errors.maxProviderInvocations &&
    !errors.maxConsecutiveFailures
  );
}

/** Returns null when the draft is invalid; the caller must not save. */
export function normalizeMode1Draft(
  draft: Mode1DialogDraft,
): OrchestrationConfig | null {
  if (!isMode1DraftValid(draft)) return null;
  return {
    enabled: true,
    participants: draft.participants.map((row) => ({
      participantId: row.participantId,
      provider: row.provider as ProviderId,
      task: row.task.trim(),
    })),
    sessionMaxDurationSeconds: parseIntegerInRange(
      draft.sessionMaxDurationSeconds,
      60,
      7200,
    )!,
    maxIterationsPerEntity: parseIntegerInRange(
      draft.maxIterationsPerEntity,
      1,
      10,
    )!,
    maxProviderInvocations: parseIntegerInRange(
      draft.maxProviderInvocations,
      1,
      100,
    )!,
    maxConsecutiveFailures: parseIntegerInRange(
      draft.maxConsecutiveFailures,
      1,
      10,
    )!,
    funding: draft.funding,
  };
}
