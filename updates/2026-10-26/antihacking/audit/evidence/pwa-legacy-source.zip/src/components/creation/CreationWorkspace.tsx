import type { ReactNode } from "react";
import type { Locale } from "../../types";
import {
  CREATION_STAGES,
  StageNavigation,
  type CreationStage,
  type StageState,
} from "./StageNavigation";

interface CreationWorkspaceProps {
  children: ReactNode;
  current: CreationStage;
  feedback?: string | null;
  locale: Locale;
  onStageChange: (stage: CreationStage) => void;
  states: Record<CreationStage, StageState>;
}

export function CreationWorkspace({
  children,
  current,
  feedback,
  locale,
  onStageChange,
  states,
}: CreationWorkspaceProps) {
  // Position, not completion: the bar answers "how far along am I" at a
  // glance, which is the question the stage rail makes the user assemble from
  // five separate icons.
  const step = CREATION_STAGES.indexOf(current) + 1;
  const total = CREATION_STAGES.length;
  const es = locale === "es";

  return (
    <main className="creation-workspace">
      <div className="creation-progress">
        <div
          className="creation-progress__track"
          role="progressbar"
          aria-valuemin={1}
          aria-valuemax={total}
          aria-valuenow={step}
          aria-valuetext={
            es ? `Paso ${step} de ${total}` : `Step ${step} of ${total}`
          }
        >
          <span style={{ inlineSize: `${(step / total) * 100}%` }} />
        </div>
        <p className="creation-progress__label">
          {es ? `Paso ${step} de ${total}` : `Step ${step} of ${total}`}
        </p>
      </div>
      <StageNavigation
        current={current}
        locale={locale}
        onSelect={onStageChange}
        states={states}
      />
      {feedback ? (
        <p className="stage-navigation__feedback" role="alert">
          {feedback}
        </p>
      ) : null}
      <section className="creation-workspace__stage">{children}</section>
    </main>
  );
}
