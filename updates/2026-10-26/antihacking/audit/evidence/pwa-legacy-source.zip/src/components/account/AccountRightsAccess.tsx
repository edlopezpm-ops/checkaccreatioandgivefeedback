import { useEffect, useRef, useState, useId } from "react";
import type { Locale } from "../../types";
import type {
  GoogleAuthTransaction,
  WebAuthMethods,
  WebIdentityProvider,
} from "../../account/contracts";
import {
  AccountError,
  cancelGoogleSignIn,
  deleteWebRightsAccount,
  loadGoogleSignInStatus,
  loadWebRightsData,
  startProviderSignIn,
} from "../../account/webClient";

type RightsAction = "data" | "delete";
type PendingRights = GoogleAuthTransaction & { action: RightsAction };

function rightsMessage(failure: unknown, es: boolean) {
  const code = failure instanceof AccountError ? failure.code : "";
  if (code === "popup_blocked")
    return es
      ? "Permite la ventana de verificación y vuelve a intentarlo. Esta pestaña permanece abierta."
      : "Allow the verification window and try again. Keep this tab open.";
  if (
    [
      "request_rate_limited",
      "rights_rate_limited",
      "sign_in_rate_limited",
    ].includes(code)
  )
    return es
      ? "Hay demasiadas solicitudes. Espera antes de verificar tu cuenta otra vez."
      : "Too many requests. Wait before verifying your account again.";
  if (code === "account_suspended")
    return es
      ? "El acceso al servicio está suspendido temporalmente. Usa esta verificación independiente para tus datos o eliminación, o escribe a aekr@aekr.io."
      : "Service access is temporarily suspended. Use this separate verification for your data or deletion, or contact aekr@aekr.io.";
  if (code === "provider_cancelled")
    return es
      ? "La autorización se canceló. Puedes iniciar otra verificación."
      : "Authorization was cancelled. You can start another verification.";
  if (
    [
      "oidc_expired",
      "provider_authorization_invalid",
      "reauthentication_required",
      "rights_context_changed",
      "rights_context_mismatch",
    ].includes(code)
  )
    return es
      ? "La verificación venció. Verifica otra vez para realizar esta acción."
      : "Verification expired. Verify again to perform this action.";
  if (code === "unreachable")
    return es
      ? "No se pudo conectar. Comprueba tu conexión; esta pestaña y sus archivos se conservan."
      : "Could not connect. Check your connection; this tab and its files are preserved.";
  return es
    ? "No se pudo verificar una cuenta existente con ese método. Usa un proveedor ya conectado a tu cuenta o escribe a aekr@aekr.io."
    : "An existing account could not be verified with that method. Use a provider already connected to your account or contact aekr@aekr.io.";
}

export function AccountRightsAccess({
  locale,
  methods,
  disabled,
  onBusyChange,
}: {
  locale: Locale;
  methods: WebAuthMethods | null;
  disabled: boolean;
  onBusyChange: (busy: boolean) => void;
}) {
  const es = locale === "es";
  const actionId = useId();
  const [action, setAction] = useState<RightsAction>("data");
  const [pending, setPending] = useState<PendingRights | null>(null);
  const [busy, setBusy] = useState(false);
  const [verifiedDelete, setVerifiedDelete] = useState(false);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [retryAt, setRetryAt] = useState(0);
  const [now, setNow] = useState(Date.now);
  const popup = useRef<Window | null>(null);
  const sequence = useRef(0);
  const busyRef = useRef(false);
  const mounted = useRef(true);
  const verifiedTransaction = useRef<string | null>(null);

  function changeBusy(value: boolean) {
    busyRef.current = value;
    setBusy(value);
    onBusyChange(value);
  }
  function fail(failure: unknown) {
    setError(rightsMessage(failure, es));
    if (failure instanceof AccountError && failure.retryAfter)
      setRetryAt(Date.now() + failure.retryAfter * 1000);
  }
  function closePopup() {
    try {
      popup.current?.close();
    } catch {
      /* Provider COOP may isolate the window. */
    }
    popup.current = null;
  }
  async function downloadData(ticket: number, transactionId: string) {
    const value = await loadWebRightsData(transactionId);
    if (!mounted.current || ticket !== sequence.current) return;
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(value, null, 2)], { type: "application/json" }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = "accreatio-account-data.json";
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      sequence.current++;
      try {
        popup.current?.close();
      } catch {
        /* Already isolated. */
      }
      if (busyRef.current) onBusyChange(false);
    };
  }, [onBusyChange]);
  useEffect(() => {
    if (retryAt <= Date.now()) return;
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [retryAt]);
  useEffect(() => {
    if (!pending) return;
    let stopped = false;
    let timer: ReturnType<typeof setTimeout>;
    let delay = 2000;
    const ticket = sequence.current;
    const deadline = Math.min(
      Date.parse(pending.expiresAt),
      Date.now() + 600000,
    );
    const finish = () => {
      if (stopped || ticket !== sequence.current) return;
      setPending(null);
      closePopup();
      changeBusy(false);
    };
    const poll = async () => {
      if (stopped || ticket !== sequence.current) return;
      try {
        if (Date.now() >= deadline) throw new AccountError("oidc_expired", "");
        const result = await loadGoogleSignInStatus(pending.transactionId);
        if (stopped || ticket !== sequence.current) return;
        if (result === "completed") {
          if (pending.action === "data") {
            await downloadData(ticket, pending.transactionId);
            if (stopped || ticket !== sequence.current) return;
            setStatus(
              es
                ? "Descarga de tus datos solicitada. Comprueba los archivos descargados del navegador."
                : "Your data download was requested. Check your browser's downloaded files.",
            );
          } else {
            verifiedTransaction.current = pending.transactionId;
            setVerifiedDelete(true);
            setStatus(
              es
                ? "Cuenta verificada para eliminación. Confirma la eliminación a continuación."
                : "Account verified for deletion. Confirm deletion below.",
            );
          }
          finish();
          return;
        }
        if (result !== "pending")
          throw new AccountError(
            result === "expired" ? "oidc_expired" : "oidc_failed",
            "",
          );
        timer = setTimeout(() => void poll(), delay);
      } catch (failure) {
        if (stopped || ticket !== sequence.current) return;
        if (
          failure instanceof AccountError &&
          failure.code === "unreachable" &&
          Date.now() < deadline
        ) {
          setStatus(
            es
              ? "Reconectando para comprobar la verificación…"
              : "Reconnecting to check verification…",
          );
          delay = Math.min(delay * 2, 15000);
          timer = setTimeout(() => void poll(), delay);
          return;
        }
        fail(failure);
        finish();
      }
    };
    timer = setTimeout(() => void poll(), 500);
    return () => {
      stopped = true;
      clearTimeout(timer);
    };
    // Each transaction captures its action/locale. This flow never adopts a product session.
  }, [pending, es]);

  async function verify(provider: WebIdentityProvider) {
    if (
      disabled ||
      busyRef.current ||
      Date.now() < retryAt ||
      !methods?.methods[provider].available
    )
      return;
    changeBusy(true);
    setError("");
    setStatus("");
    setVerifiedDelete(false);
    verifiedTransaction.current = null;
    const ticket = ++sequence.current;
    try {
      // Open synchronously under the click activation; never navigate the draft tab.
      const opened = window.open(
        "about:blank",
        "_blank",
        "popup,width=520,height=720",
      );
      if (!opened) throw new AccountError("popup_blocked", "");
      opened.opener = null;
      opened.document.title = "accreatio";
      opened.document.body.textContent = es
        ? "Preparando la verificación de cuenta. Mantén abierta la pestaña original."
        : "Preparing account verification. Keep the original tab open.";
      popup.current = opened;
      const transaction = await startProviderSignIn(provider, "popup", {
        purpose: "account_access",
        verificationAction: action,
        rightsOnly: true,
      });
      if (!mounted.current || ticket !== sequence.current) {
        closePopup();
        return;
      }
      opened.location.replace(transaction.authorizationUrl);
      setPending({ ...transaction, action });
    } catch (failure) {
      if (mounted.current && ticket === sequence.current) {
        closePopup();
        fail(failure);
        changeBusy(false);
      }
    }
  }
  async function cancel() {
    const transaction = pending;
    sequence.current++;
    setPending(null);
    closePopup();
    try {
      if (transaction) await cancelGoogleSignIn(transaction.transactionId);
    } catch {
      /* A completed proof still expires without authorizing an action. */
    }
    if (!mounted.current) return;
    setStatus(
      es
        ? "Verificación cerrada. No se solicitó eliminar la cuenta."
        : "Verification closed. Account deletion was not requested.",
    );
    changeBusy(false);
  }
  async function remove() {
    const transactionId = verifiedTransaction.current;
    if (disabled || busyRef.current || !verifiedDelete || !transactionId)
      return;
    changeBusy(true);
    setError("");
    try {
      await deleteWebRightsAccount(transactionId);
      if (!mounted.current) return;
      setVerifiedDelete(false);
      verifiedTransaction.current = null;
      setStatus(
        es
          ? "La cuenta verificada se eliminó. Los archivos locales siguen bajo tu control."
          : "The verified account was deleted. Local files remain under your control.",
      );
    } catch (failure) {
      if (mounted.current) {
        setVerifiedDelete(false);
        verifiedTransaction.current = null;
        fail(failure);
      }
    } finally {
      if (mounted.current) changeBusy(false);
    }
  }
  const retrySeconds = Math.max(0, Math.ceil((retryAt - now) / 1000));
  const providers = (["google", "github"] as const).filter(
    (provider) => methods?.methods[provider].available,
  );
  return (
    <details className="web-signin__rights">
      <summary>
        {es ? "Mis datos y eliminación de cuenta" : "Account data and deletion"}
      </summary>
      <div className="web-signin__form">
        <p>
          {es
            ? "Gestiona una cuenta existente con un proveedor que ya tenga conectado. No necesitas iniciar acceso al proyecto ni aceptar términos nuevos. Esta verificación no crea cuentas ni cambia tus borradores."
            : "Manage an existing account with a provider already connected to it. You do not need project access or new terms acceptance. This verification creates no account and does not change your drafts."}
        </p>
        <label htmlFor={actionId}>{es ? "Acción" : "Action"}</label>
        <select
          id={actionId}
          value={action}
          disabled={disabled || busy || verifiedDelete}
          onChange={(event) => {
            setAction(event.target.value as RightsAction);
            setError("");
            setStatus("");
          }}
        >
          <option value="data">
            {es ? "Descargar mis datos" : "Download my data"}
          </option>
          <option value="delete">
            {es ? "Eliminar mi cuenta" : "Delete my account"}
          </option>
        </select>
        {!pending && !verifiedDelete && (
          <div className="web-signin__providers">
            {providers.map((provider) => (
              <button
                key={provider}
                type="button"
                className="secondary"
                disabled={disabled || busy || retrySeconds > 0}
                onClick={() => void verify(provider)}
              >
                {es ? "Verificar con" : "Verify with"}{" "}
                {provider === "github" ? "GitHub" : "Google"}
              </button>
            ))}
          </div>
        )}
        {pending && (
          <>
            <p role="status">
              {es
                ? "Completa la verificación en la otra ventana. Esta pestaña permanece abierta."
                : "Complete verification in the other window. Keep this tab open."}
            </p>
            <button
              type="button"
              className="secondary"
              onClick={() => void cancel()}
            >
              {es ? "Cancelar verificación" : "Cancel verification"}
            </button>
          </>
        )}
        {verifiedDelete && (
          <>
            <p>
              {es
                ? "La eliminación retira el perfil, métodos y sesiones de la cuenta que acabas de verificar. Esta acción requiere tu confirmación."
                : "Deletion removes the profile, methods and sessions of the account you just verified. This action requires your confirmation."}
            </p>
            <div className="web-signin__recovery">
              <button
                type="button"
                className="secondary danger"
                disabled={disabled || busy}
                onClick={() => void remove()}
              >
                {es
                  ? "Eliminar la cuenta verificada"
                  : "Delete the verified account"}
              </button>
              <button
                type="button"
                className="secondary"
                disabled={busy}
                onClick={() => {
                  setVerifiedDelete(false);
                  verifiedTransaction.current = null;
                  setStatus("");
                }}
              >
                {es ? "Cancelar" : "Cancel"}
              </button>
            </div>
          </>
        )}
        {status && <p role="status">{status}</p>}
        {error && (
          <p className="web-signin__error" role="alert">
            {error}
          </p>
        )}
        {retrySeconds > 0 && (
          <p role="status">
            {es
              ? `Puedes volver a verificar en ${retrySeconds} s.`
              : `You can verify again in ${retrySeconds} s.`}
          </p>
        )}
        <p>
          {es
            ? "Si no puedes verificar tu método habitual, contacta a "
            : "If you cannot verify your usual method, contact "}
          <a href="mailto:aekr@aekr.io">aekr@aekr.io</a>.
        </p>
      </div>
    </details>
  );
}
