import { CircleCheck, CircleEllipsis, TriangleAlert } from "lucide-react";

export type StatusTone = "neutral" | "success" | "warning";

interface StatusNoticeProps {
  detail?: string;
  label: string;
  tone?: StatusTone;
}

export function StatusNotice({
  detail,
  label,
  tone = "neutral",
}: StatusNoticeProps) {
  const Icon =
    tone === "success"
      ? CircleCheck
      : tone === "warning"
        ? TriangleAlert
        : CircleEllipsis;

  return (
    <div className={`status-notice status-notice--${tone}`} role="status">
      <Icon aria-hidden="true" />
      <span>
        <strong>{label}</strong>
        {detail && <small>{detail}</small>}
      </span>
    </div>
  );
}
