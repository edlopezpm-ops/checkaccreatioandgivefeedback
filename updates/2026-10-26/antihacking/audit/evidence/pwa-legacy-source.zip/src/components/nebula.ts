/** Local procedural nebula. One fullscreen WebGL pass renders domain-warped
 * fractal gas with dust absorption, emission cores, and micro star grains.
 * No remote service, no third-party runtime; the module is lazy-imported and
 * owns nothing outside the canvas it is given. */

export interface NebulaOptions {
  theme: "dark" | "light";
  speed: number;
}

export interface NebulaEffect {
  destroy(): void;
  setOptions(options: NebulaOptions): void;
  burstAt(clientX: number, clientY: number): boolean;
}

const VERTEX_SOURCE = `
attribute vec2 a_position;
varying vec2 v_uv;
void main() {
  v_uv = a_position * 0.5 + 0.5;
  gl_Position = vec4(a_position, 0.0, 1.0);
}`;

/** Value-noise fbm with two-level domain warping (the classic warp-of-a-warp
 * construction) plus absorption and emission shaping. Written for WebGL1. */
const FRAGMENT_SOURCE = `
precision highp float;
varying vec2 v_uv;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_theme;
uniform float u_cssHeight;
uniform vec4 u_bursts[4];
uniform float u_picking;
uniform vec2 u_pickUv;

float hash(vec2 p) {
  p = fract(p * vec2(234.34, 435.345));
  p += dot(p, p + 34.23);
  return fract(p.x * p.y);
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  float a = hash(i);
  float b = hash(i + vec2(1.0, 0.0));
  float c = hash(i + vec2(0.0, 1.0));
  float d = hash(i + vec2(1.0, 1.0));
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

const mat2 ROT = mat2(0.8, 0.6, -0.6, 0.8);

float fbm(vec2 p) {
  float value = 0.0;
  float amplitude = 0.5;
  for (int i = 0; i < 5; i++) {
    value += amplitude * noise(p);
    p = ROT * p * 2.02;
    amplitude *= 0.5;
  }
  return value;
}

void main() {
  vec2 sampleUv = mix(v_uv, u_pickUv, u_picking);
  vec2 aspect = vec2(u_resolution.x / u_resolution.y, 1.0);
  vec2 uv = sampleUv * aspect;
  float t = u_time;

  // Autonomous currents: travel and curl remain independent of the pointer.
  vec2 p = uv * 2.1 + vec2(t * 0.026, -t * 0.017);
  p += vec2(sin(t * 0.13 + uv.y * 2.0), cos(t * 0.11 + uv.x)) * 0.13;

  // A local pressure wave pushes gas aside, curls its rim, then dissipates.
  // Distances are CSS pixels, so each bubble has the same size on every screen.
  float shell = 0.0;
  float hollow = 0.0;
  for (int i = 0; i < 4; i++) {
    vec4 burst = u_bursts[i];
    if (burst.w < 0.5) continue;
    vec2 offset = (sampleUv - burst.xy) * aspect;
    float distancePx = length(offset) * u_cssHeight;
    vec2 direction = offset / max(length(offset), 0.0001);
    float progress = clamp(burst.z / 1.6, 0.0, 1.0);
    float life = (1.0 - smoothstep(0.2, 1.0, progress)) * burst.w;
    float radius = 8.0 + 105.0 * (1.0 - pow(1.0 - progress, 2.0));
    float angle = atan(offset.y, offset.x + 0.00001);
    float ruffle = sin(angle * 6.0 + progress * 8.0) * 4.0
                 + sin(angle * 11.0 - progress * 5.0) * 2.5;
    float ring = exp(-pow((distancePx - radius - ruffle) / (11.0 + progress * 15.0), 2.0)) * life;
    p += direction * ring * 0.16;
    p += vec2(-direction.y, direction.x) * ring * 0.055 * sin(angle * 4.0);
    shell += ring;
    hollow += (1.0 - smoothstep(radius * 0.35, radius, distancePx)) * life;
  }

  vec2 q = vec2(fbm(p), fbm(p + vec2(5.2, 1.3)));
  vec2 r = vec2(
    fbm(p + 2.6 * q + vec2(1.7, 9.2) + 0.06 * t),
    fbm(p + 2.6 * q + vec2(8.3, 2.8) + 0.045 * t)
  );
  float f = fbm(p + 2.4 * r);

  // Broader gas coverage keeps filaments visible against matte pearl, while
  // the left reading column stays airy and the shared mask protects picking.
  float column = smoothstep(0.05, 0.72, sampleUv.x);
  float density = smoothstep(0.26, 0.82, f) * mix(0.35, 1.0, column);

  // Mineral strata retain the same field in charcoal, sage gray and pearl.
  vec3 deep = vec3(0.090, 0.100, 0.095);
  vec3 graphite = vec3(0.290, 0.310, 0.295);
  vec3 sage = vec3(0.400, 0.430, 0.405);
  vec3 silver = vec3(0.490, 0.510, 0.485);
  vec3 pearl = vec3(0.640, 0.660, 0.630);

  vec3 color = mix(deep, graphite, clamp(f * f * 2.4, 0.0, 1.0));
  color = mix(color, sage, clamp(dot(q, q) * 0.85, 0.0, 1.0));
  color = mix(color, silver, clamp(r.y * r.y * 0.9, 0.0, 1.0) * 0.55);

  // Both emission cores drift with the gas currents.
  vec2 core = (vec2(0.72, 0.46) + vec2(sin(t * 0.08), cos(t * 0.07)) * 0.07) * aspect;
  float coreGlow = exp(-dot(uv - core, uv - core) * 5.5);
  vec2 lamp = (vec2(0.57, 0.58) + vec2(cos(t * 0.1), sin(t * 0.06)) * 0.09) * aspect;
  float lampGlow = exp(-dot(uv - lamp, uv - lamp) * 7.0);
  float emission = (coreGlow * 0.85 + lampGlow * 0.5) * (0.45 + 0.55 * f);
  color += pearl * emission * 0.55;
  color += graphite * lampGlow * 0.35;

  // Dust lanes: cold foreground absorption carves filaments into the glow.
  float dust = fbm(p * 2.3 + r * 1.4);
  float absorption = smoothstep(0.28, 0.72, dust);
  color *= mix(0.42, 1.06, absorption);

  // Micro star grains, dimmed where the dust is thickest.
  vec2 grid = uv * 210.0;
  float cell = hash(floor(grid));
  float grain = smoothstep(0.9975, 1.0, cell);
  float twinkle = 0.7 + 0.3 * sin(t * 1.4 + cell * 40.0);
  color += vec3(0.85, 0.87, 0.83) * grain * twinkle * absorption * 0.8;

  float alpha = clamp(density * 1.15 + emission * 0.5, 0.0, 1.0);
  float clearing = 1.0 - min(hollow, 1.0) * 0.84;
  alpha = clamp(alpha * clearing + shell * 0.42, 0.0, 1.0);
  color += (graphite * 0.6 + sage * 0.35 + pearl * 0.25) * shell;

  // Shared rendering/picking mask. There is no second CSS mask or transform
  // that can make an invisible part of the gas respond to a click.
  float visibility = sampleUv.x < 0.18
    ? mix(0.0, 0.38, sampleUv.x / 0.18)
    : sampleUv.x < 0.42
      ? mix(0.38, 0.88, (sampleUv.x - 0.18) / 0.24)
      : mix(0.88, 1.0, clamp((sampleUv.x - 0.42) / 0.24, 0.0, 1.0));
  alpha *= visibility;

  // Light theme uses the same mineral field with stronger graphite absorption.
  // Pearl remains the page color; denser, separated wisps give the gas shape
  // instead of washing the entire backdrop into a uniform gray veil.
  vec3 paper = vec3(0.910, 0.918, 0.906);
  vec3 lightInk = mix(paper, color * 0.38 + vec3(0.34, 0.36, 0.34), 0.80);
  color = mix(color, lightInk, u_theme);
  alpha = mix(alpha, alpha * 0.78, u_theme);

  // Dither kills gradient banding on wide soft ramps.
  color += (hash(uv * 913.7 + t) - 0.5) * 0.012;

  if (u_picking > 0.5) {
    // Density excludes emission haze and star grains; holes do not count as gas.
    gl_FragColor = vec4(density * visibility * clearing, 0.0, 0.0, 1.0);
    return;
  }
  gl_FragColor = vec4(color * alpha, alpha);
}`;

const FRAME_INTERVAL_MS = 1000 / 30;
const RESOLUTION_SCALE = 0.6;
const COMPACT_RESOLUTION_SCALE = 0.4;
const MAX_PIXEL_RATIO = 1.5;
const BURST_LIFETIME_SECONDS = 1.6;
const MIN_VISIBLE_DENSITY = 0.06;

function compile(gl: WebGLRenderingContext, type: number, source: string) {
  const shader = gl.createShader(type);
  if (!shader) return null;
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}

export function createNebula(
  host: HTMLElement,
  initial: NebulaOptions,
): NebulaEffect | null {
  const canvas = document.createElement("canvas");
  canvas.className = "nebula-canvas";
  const gl = canvas.getContext("webgl", {
    alpha: true,
    antialias: false,
    depth: false,
    stencil: false,
    powerPreference: "low-power",
    premultipliedAlpha: true,
  });
  if (!gl) return null;

  const vertex = compile(gl, gl.VERTEX_SHADER, VERTEX_SOURCE);
  const fragment = compile(gl, gl.FRAGMENT_SHADER, FRAGMENT_SOURCE);
  const program = gl.createProgram();
  const releaseProgram = () => {
    if (vertex) gl.deleteShader(vertex);
    if (fragment) gl.deleteShader(fragment);
    if (program) gl.deleteProgram(program);
  };
  if (!vertex || !fragment || !program) {
    releaseProgram();
    gl.getExtension("WEBGL_lose_context")?.loseContext();
    return null;
  }
  gl.attachShader(program, vertex);
  gl.attachShader(program, fragment);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    releaseProgram();
    gl.getExtension("WEBGL_lose_context")?.loseContext();
    return null;
  }
  gl.useProgram(program);

  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(
    gl.ARRAY_BUFFER,
    new Float32Array([-1, -1, 3, -1, -1, 3]),
    gl.STATIC_DRAW,
  );
  const positionLocation = gl.getAttribLocation(program, "a_position");
  gl.enableVertexAttribArray(positionLocation);
  gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);

  const uniforms = {
    resolution: gl.getUniformLocation(program, "u_resolution"),
    time: gl.getUniformLocation(program, "u_time"),
    theme: gl.getUniformLocation(program, "u_theme"),
    cssHeight: gl.getUniformLocation(program, "u_cssHeight"),
    bursts: gl.getUniformLocation(program, "u_bursts[0]"),
    picking: gl.getUniformLocation(program, "u_picking"),
    pickUv: gl.getUniformLocation(program, "u_pickUv"),
  };

  // A one-pixel target reads the same shader without redrawing or reading back
  // the full canvas. Picking is only performed after an eligible left click.
  const pickTexture = gl.createTexture();
  const pickFramebuffer = gl.createFramebuffer();
  gl.bindTexture(gl.TEXTURE_2D, pickTexture);
  gl.texImage2D(
    gl.TEXTURE_2D,
    0,
    gl.RGBA,
    1,
    1,
    0,
    gl.RGBA,
    gl.UNSIGNED_BYTE,
    null,
  );
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.bindFramebuffer(gl.FRAMEBUFFER, pickFramebuffer);
  gl.framebufferTexture2D(
    gl.FRAMEBUFFER,
    gl.COLOR_ATTACHMENT0,
    gl.TEXTURE_2D,
    pickTexture,
    0,
  );
  const pickingSupported =
    Boolean(pickTexture && pickFramebuffer) &&
    gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  gl.bindTexture(gl.TEXTURE_2D, null);

  host.appendChild(canvas);

  let options = initial;
  let destroyed = false;
  let frame = 0;
  let lastFrame = 0;
  let simulatedTime = Math.random() * 400;
  let elapsedSeconds = 0;
  let rendered = false;
  let cssHeight = 1;
  let nextBurst = 0;
  const bursts: { x: number; y: number; started: number }[] = [];
  const burstUniforms = new Float32Array(16);
  const pickedPixel = new Uint8Array(4);

  const resize = () => {
    rendered = false;
    const bounds = host.getBoundingClientRect();
    cssHeight = Math.max(1, bounds.height);
    // Gas is low-frequency imagery. Compact screens retain the same currents
    // and 30 FPS at a smaller drawing buffer, avoiding GPU waits during commit.
    const resolutionScale =
      bounds.width <= 600 ? COMPACT_RESOLUTION_SCALE : RESOLUTION_SCALE;
    const scale =
      Math.min(window.devicePixelRatio || 1, MAX_PIXEL_RATIO) * resolutionScale;
    canvas.width = Math.max(1, Math.round(bounds.width * scale));
    canvas.height = Math.max(1, Math.round(bounds.height * scale));
    gl.viewport(0, 0, canvas.width, canvas.height);
  };
  const resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(host);
  resize();

  const render = (now: number) => {
    frame = window.requestAnimationFrame(render);
    if (now - lastFrame < FRAME_INTERVAL_MS) return;
    const step = Math.min(now - lastFrame, 100) / 1000;
    lastFrame = now;
    elapsedSeconds += step;
    simulatedTime += step * (0.55 + options.speed);
    burstUniforms.fill(0);
    bursts.forEach((burst, index) => {
      const age = elapsedSeconds - burst.started;
      if (age >= BURST_LIFETIME_SECONDS) return;
      burstUniforms.set([burst.x, burst.y, age, 1], index * 4);
    });

    gl.uniform2f(uniforms.resolution, canvas.width, canvas.height);
    gl.uniform1f(uniforms.time, simulatedTime);
    gl.uniform1f(uniforms.theme, options.theme === "light" ? 1 : 0);
    gl.uniform1f(uniforms.cssHeight, cssHeight);
    gl.uniform4fv(uniforms.bursts, burstUniforms);
    gl.uniform1f(uniforms.picking, 0);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    rendered = true;
  };
  frame = window.requestAnimationFrame(render);

  return {
    destroy() {
      if (destroyed) return;
      destroyed = true;
      window.cancelAnimationFrame(frame);
      resizeObserver.disconnect();
      gl.deleteTexture(pickTexture);
      gl.deleteFramebuffer(pickFramebuffer);
      gl.deleteBuffer(buffer);
      releaseProgram();
      gl.getExtension("WEBGL_lose_context")?.loseContext();
      canvas.remove();
    },
    setOptions(next: NebulaOptions) {
      options = next;
    },
    burstAt(clientX: number, clientY: number) {
      if (destroyed || !rendered || !pickingSupported || gl.isContextLost())
        return false;
      const bounds = canvas.getBoundingClientRect();
      if (bounds.width <= 0 || bounds.height <= 0) return false;
      const x = (clientX - bounds.left) / bounds.width;
      const y = 1 - (clientY - bounds.top) / bounds.height;
      if (
        !Number.isFinite(x) ||
        !Number.isFinite(y) ||
        x < 0 ||
        x > 1 ||
        y < 0 ||
        y > 1
      )
        return false;

      pickedPixel.fill(0);
      try {
        gl.bindFramebuffer(gl.FRAMEBUFFER, pickFramebuffer);
        gl.viewport(0, 0, 1, 1);
        gl.uniform1f(uniforms.picking, 1);
        gl.uniform2f(uniforms.pickUv, x, y);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
        gl.readPixels(0, 0, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, pickedPixel);
      } catch {
        return false;
      } finally {
        gl.uniform1f(uniforms.picking, 0);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        gl.viewport(0, 0, canvas.width, canvas.height);
      }

      const opacity = Number.parseFloat(window.getComputedStyle(host).opacity);
      if (
        !Number.isFinite(opacity) ||
        (pickedPixel[0] / 255) * opacity < MIN_VISIBLE_DENSITY
      )
        return false;
      bursts[nextBurst] = { x, y, started: elapsedSeconds };
      nextBurst = (nextBurst + 1) % 4;
      return true;
    },
  };
}
