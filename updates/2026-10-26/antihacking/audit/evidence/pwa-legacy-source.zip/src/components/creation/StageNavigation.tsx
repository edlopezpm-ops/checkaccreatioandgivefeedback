import { Circle, CircleCheck, CircleDot, TriangleAlert } from "lucide-react";
import type { Locale } from "../../types";

export const CREATION_STAGES = [
  "foundation",
  "context",
  "team",
  "delivery",
  "review",
] as const;

export type CreationStage = (typeof CREATION_STAGES)[number];
export type StageState = "current" | "complete" | "attention" | "upcoming";

interface StageNavigationProps {
  current: CreationStage;
  locale: Locale;
  onSelect: (stage: CreationStage) => void;
  states: Record<CreationStage, StageState>;
}

const labels = {
  en: {
    foundation: "Foundation",
    context: "Context",
    team: "Team",
    delivery: "Delivery",
    review: "Review",
    current: "Current",
    complete: "Complete",
    attention: "Needs attention",
    upcoming: "Not started",
    navigation: "Project creation stages",
    selector: "Current stage",
  },
  es: {
    foundation: "Fundamentos",
    context: "Contexto",
    team: "Equipo",
    delivery: "Entrega",
    review: "Revisión",
    current: "Actual",
    complete: "Completa",
    attention: "Necesita atención",
    upcoming: "Sin comenzar",
    navigation: "Etapas de creación del proyecto",
    selector: "Etapa actual",
  },
} as const;

export function StageNavigation({
  current,
  locale,
  onSelect,
  states,
}: StageNavigationProps) {
  const text = labels[locale];
  const icon = (state: StageState) => {
    const Icon =
      state === "complete"
        ? CircleCheck
        : state === "attention"
          ? TriangleAlert
          : state === "current"
            ? CircleDot
            : Circle;
    return <Icon aria-hidden="true" />;
  };

  return (
    <>
      <nav className="stage-navigation" aria-label={text.navigation}>
        <ol>
          {CREATION_STAGES.map((stage, index) => (
            <li key={stage}>
              <button
                type="button"
                className={`stage-navigation__item stage-navigation__item--${states[stage]}`}
                aria-current={stage === current ? "step" : undefined}
                onClick={() => onSelect(stage)}
              >
                {icon(states[stage])}
                <span>
                  <small>{String(index + 1).padStart(2, "0")}</small>
                  <strong>{text[stage]}</strong>
                  <em>{text[states[stage]]}</em>
                </span>
              </button>
            </li>
          ))}
        </ol>
      </nav>
      <label className="stage-selector">
        <span>{text.selector}</span>
        <select
          value={current}
          onChange={(event) => onSelect(event.target.value as CreationStage)}
        >
          {CREATION_STAGES.map((stage) => (
            <option key={stage} value={stage}>
              {text[stage]} — {text[states[stage]]}
            </option>
          ))}
        </select>
      </label>
    </>
  );
}
