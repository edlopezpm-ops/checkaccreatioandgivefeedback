import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, FolderOutput, HardDrive } from "lucide-react";
import type { Locale } from "../types";
import { getStartingInstruction } from "../../shared/exportManifest";
import { FormationMark } from "./FormationMark";
import { useSectionTransition } from "./useSectionTransition";
import "./Onboarding.css";

interface OnboardingProps {
  isWeb?: boolean;
  initialStep?: 1 | 2;
  locale: Locale;
  onComplete: () => void;
  storageAvailable: boolean;
  tagline: string;
}

export function Onboarding({
  isWeb = false,
  initialStep = 1,
  locale,
  onComplete,
  storageAvailable,
  tagline,
}: OnboardingProps) {
  const es = locale === "es";
  const [step, setStep] = useState<1 | 2>(initialStep);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const cardRef = useRef<HTMLElement>(null);
  useSectionTransition(cardRef, step, isWeb);
  useEffect(() => {
    titleRef.current?.focus({ preventScroll: true });
  }, [step]);

  return (
    <main className="onboarding" aria-labelledby="onboarding-title">
      <section className="onboarding-card" ref={cardRef}>
        <FormationMark
          homeLabel={es ? "Ir al inicio de accreatio" : "Go to accreatio home"}
          tagline={tagline}
          onActivate={isWeb ? undefined : () => setStep(1)}
        />
        <p className="onboarding-progress">
          {es
            ? `Bienvenida · Paso ${step} de ${isWeb ? 3 : 2}`
            : `Welcome · Step ${step} of ${isWeb ? 3 : 2}`}
        </p>
        {step === 1 ? (
          <div className="onboarding-content">
            <FolderOutput aria-hidden="true" />
            <h1 id="onboarding-title" ref={titleRef} tabIndex={-1}>
              {isWeb
                ? es
                  ? "Prepara el encargo de tu próximo proyecto de software."
                  : "Prepare the brief for your next software project."
                : es
                  ? "Lo que vas a crear"
                  : "What you will make"}
            </h1>
            <p>
              {isWeb
                ? es
                  ? "Ordena tu idea, sus límites y los materiales que ya tienes. Descarga un ZIP con el contexto y las instrucciones para continuar con tu asistente de programación."
                  : "Organize your idea, its constraints, and the material you already have. Download a ZIP with the context and instructions to continue with your coding assistant."
                : es
                  ? "Describe una idea y accreatio la organiza en un prompt explícito, un plan determinista y archivos de proyecto listos para continuar."
                  : "Describe an idea and accreatio organizes it into an explicit prompt, a deterministic plan, and project files ready for you to continue."}
            </p>
            {isWeb && <p>{es ? "Beta web gratuita" : "Free web beta"}</p>}
            <dl className="onboarding-facts">
              {!isWeb && (
                <div>
                  <dt>{es ? "Tiempo estimado" : "Expected time"}</dt>
                  <dd>{es ? "5–10 minutos" : "5–10 minutes"}</dd>
                </div>
              )}
              <div>
                <dt>{es ? "Resultado" : "Output"}</dt>
                <dd>
                  {isWeb
                    ? es
                      ? "Un ZIP con el encargo y los archivos iniciales"
                      : "A ZIP with your brief and starter files"
                    : es
                      ? "Una carpeta local en escritorio o un ZIP descargable en web"
                      : "A local folder on desktop or a downloadable ZIP on the web"}
                </dd>
              </div>
            </dl>
            {isWeb && (
              <>
                <p>
                  {es
                    ? "accreatio prepara el paquete inicial. La construcción del software continúa en la herramienta que tú elijas."
                    : "accreatio prepares the starter package. Software development continues in the tool you choose."}
                </p>
                <details className="onboarding-example">
                  <summary>{es ? "Ver un ejemplo" : "See an example"}</summary>
                  <h2>{es ? "Qué recibirás" : "What you will receive"}</h2>
                  <p>
                    {es
                      ? "Ejemplo ficticio de un paquete exportado. Puedes inspeccionarlo antes de iniciar sesión."
                      : "Fictional example of an exported package. You can inspect it before signing in."}
                  </p>
                  <h3>Herramientas del barrio</h3>
                  <p>
                    {es
                      ? "Biblioteca ficticia de herramientas de barrio. Registrar préstamos sin conexión; sin cuentas, pagos, sincronización ni datos personales de contacto. Consultar antes de elegir stack."
                      : "Fictional neighborhood tool library. Record loans offline; no accounts, payments, cloud sync or personal contact details. Ask before choosing a stack."}
                  </p>
                  <ul>
                    <li>START.md · {es ? "cómo comenzar" : "how to start"}</li>
                    <li>
                      PROJECT_PROMPT.md ·{" "}
                      {es ? "el encargo del proyecto" : "the project brief"}
                    </li>
                    <li>
                      docs/product/discovery.md ·{" "}
                      {es ? "contexto y decisiones" : "context and decisions"}
                    </li>
                    <li>
                      docs/master.md ·{" "}
                      {es ? "fase y próximos pasos" : "phase and next steps"}
                    </li>
                  </ul>
                  <h3>
                    {es ? "Instrucción de inicio" : "Starting instruction"}
                  </h3>
                  <pre tabIndex={0}>{getStartingInstruction(locale)}</pre>
                  <nav aria-label={es ? "Archivos de ejemplo" : "Sample files"}>
                    <a href="/examples/accreatio-basic-sample.zip" download>
                      {es ? "Descargar ZIP de ejemplo" : "Download sample ZIP"}
                    </a>
                    <a
                      href={`/examples/START.${locale}.md`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {es
                        ? "Leer la instrucción de inicio"
                        : "Read the starting instruction"}
                    </a>
                    <a
                      href="/examples/manifest.json"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {es
                        ? "Fecha, versión y procedencia"
                        : "Date, version, and provenance"}
                    </a>
                  </nav>
                </details>
              </>
            )}
          </div>
        ) : (
          <div className="onboarding-content">
            <HardDrive aria-hidden="true" />
            <h1 id="onboarding-title" ref={titleRef} tabIndex={-1}>
              {es ? "Lo que permanece local" : "What stays local"}
            </h1>
            <p>
              {isWeb
                ? es
                  ? "El contenido de tu proyecto se procesa en este navegador. El acceso y la cuota utilizan un servicio de cuenta separado."
                  : "Your project content is processed in this browser. Sign-in and allowance use a separate account service."
                : es
                  ? "Tu definición y tus documentos se procesan en este dispositivo. La edición de escritorio no requiere una cuenta, no sincroniza proyectos a la nube ni añade telemetría de producto. La web conserva las cuentas y el Blog en almacenes separados de tus proyectos."
                  : "Your definition and documents are processed on this device. The desktop edition requires no account, syncs no projects to the cloud, and adds no product telemetry. The web keeps accounts and Blog posts separate from your projects."}
            </p>
            {isWeb && (
              <p>
                {es
                  ? "Los datos de tu cuenta se gestionan en ese servicio. Si después compartes el ZIP con un asistente u otro servicio, se aplican sus propias condiciones y controles."
                  : "Your account data is managed by that service. If you later share the ZIP with an assistant or another service, its own terms and controls apply."}
              </p>
            )}
            <p className="onboarding-locality">
              {es
                ? "En web, el borrador local se vincula a la cuenta y sesión verificadas. Cerrar sesión lo borra; el siguiente acceso empieza vacío. Los archivos seleccionados sólo permanecen en la pestaña."
                : "On the web, the local draft is bound to the verified account and session. Signing out clears it; the next sign-in starts blank. Selected files remain only in the tab."}
            </p>
          </div>
        )}
        {!storageAvailable && (
          <p className="onboarding-recovery" role="status">
            {es
              ? "Este entorno no permite guardar la preferencia de bienvenida. Puedes continuar, pero podría aparecer de nuevo."
              : "This environment cannot save the welcome preference. You can continue, but it may appear again."}
          </p>
        )}
        <div className="onboarding-actions">
          {step === 2 && (
            <button
              type="button"
              className="secondary"
              onClick={() => setStep(1)}
            >
              <ArrowLeft aria-hidden="true" /> {es ? "Atrás" : "Back"}
            </button>
          )}
          {step === 1 ? (
            <button type="button" className="save" onClick={() => setStep(2)}>
              {isWeb
                ? es
                  ? "Preparar mi proyecto"
                  : "Prepare my project"
                : es
                  ? "Continuar"
                  : "Continue"}{" "}
              <ArrowRight aria-hidden="true" />
            </button>
          ) : (
            <button type="button" className="save" onClick={onComplete}>
              {isWeb
                ? es
                  ? "Continuar al acceso"
                  : "Continue to sign in"
                : es
                  ? "Terminar y crear"
                  : "Finish and create"}
            </button>
          )}
        </div>
      </section>
    </main>
  );
}
