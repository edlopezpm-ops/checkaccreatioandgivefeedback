import { Cloud, FileCode2, Folder, GitBranch, ShieldCheck } from "lucide-react";
import * as React from "react";
import { updateProjectFlag } from "../../../shared/domain";
import type { Locale, ProjectDefinition } from "../../types";
import { AdvancedDisclosure } from "./AdvancedDisclosure";
import { LocalityNote } from "./LocalityNote";

interface DeliveryStageProps {
  embedded?: boolean;
  errors: Record<string, string>;
  errorText: (code?: string) => string | undefined;
  isWeb: boolean;
  locale: Locale;
  onBrowseDestination: () => void;
  onChange: (project: ProjectDefinition) => void;
  onOpenSettings: () => void;
  project: ProjectDefinition;
}

export function DeliveryStage({
  embedded = false,
  errors,
  errorText,
  isWeb,
  locale,
  onBrowseDestination,
  onChange,
  onOpenSettings,
  project,
}: DeliveryStageProps) {
  const es = locale === "es";
  const Heading = embedded ? "h2" : "h1";
  const setFlag = (
    key: "dryRun" | "initializeGit" | "createRemote" | "openIde",
    value: boolean,
  ) => onChange(updateProjectFlag(project, key, value));
  const repositoryEnabled = project.action !== "tracking";
  const advancedCount = [
    project.initializeGit,
    project.createRemote,
    project.openIde,
  ].filter(Boolean).length;

  return (
    <div className="creation-stage" aria-labelledby="delivery-title">
      <header className="creation-stage__header">
        {!isWeb && <p>{es ? "Etapa 4 de 5" : "Stage 4 of 5"}</p>}
        <Heading id="delivery-title">
          {es
            ? "Decide cómo llevarte el proyecto"
            : "Decide how to take your project"}
        </Heading>
        <span>
          {es
            ? "Nada se escribe hasta que confirmes."
            : "Nothing is written until you confirm."}
        </span>
      </header>

      <fieldset className="question-group">
        <legend>
          <Folder aria-hidden="true" />
          <span>
            <strong>{es ? "Resultado" : "Output"}</strong>
          </span>
        </legend>
        {isWeb ? (
          <div className="web-export-contract">
            <strong>
              {es ? "Descargar un proyecto ZIP" : "Download a project ZIP"}
            </strong>
            <small>
              {es
                ? "ZIP inspeccionable. accreatio es solo web y no ejecuta tracking local."
                : "Inspectable ZIP. accreatio is web-only and does not run local tracking."}
            </small>
          </div>
        ) : (
          <div className="choice-cards">
            {(
              [
                [
                  "repository",
                  es
                    ? "Crear una carpeta de proyecto"
                    : "Create a project folder",
                ],
                [
                  "tracking",
                  es ? "Crear solo tracking" : "Create tracking only",
                ],
                [
                  "both",
                  es
                    ? "Crear proyecto y tracking"
                    : "Create project and tracking",
                ],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                type="button"
                aria-pressed={project.action === value}
                onClick={() =>
                  onChange({
                    ...project,
                    action: value,
                    ...(value === "tracking"
                      ? {
                          initializeGit: false,
                          createRemote: false,
                          openIde: false,
                        }
                      : {}),
                  })
                }
              >
                {label}
              </button>
            ))}
          </div>
        )}
      </fieldset>

      {!isWeb && (
        <div
          className={`question-group ${errors.destination ? "invalid" : ""}`}
        >
          <label htmlFor="project-destination">
            <Folder aria-hidden="true" />
            <span>
              <strong>{es ? "Carpeta destino" : "Destination folder"}</strong>
              <small>
                {es
                  ? "Los archivos existentes reciben copias versionadas"
                  : "Existing files receive versioned copies"}
              </small>
            </span>
          </label>
          <div className="path-input">
            <input
              id="project-destination"
              aria-invalid={Boolean(errors.destination)}
              value={project.destination}
              onChange={(event) =>
                onChange({ ...project, destination: event.target.value })
              }
            />
            <button type="button" onClick={onBrowseDestination}>
              {es ? "Elegir" : "Browse"}
            </button>
          </div>
          {errors.destination && (
            <p className="field-error">{errorText(errors.destination)}</p>
          )}
        </div>
      )}

      {errors.tracking && (
        <div id="project-tracking" className="config-notice" tabIndex={-1}>
          <span>
            {es
              ? "Configura future_projects para crear tracking."
              : "Configure future_projects to create tracking."}
          </span>
          <button type="button" onClick={onOpenSettings}>
            {es ? "Abrir configuración" : "Open settings"}
          </button>
        </div>
      )}

      {/* The dry-run choice moved to Review, where the button it modifies
          lives. Deciding the outcome one screen before seeing the consequence
          is what made this flow feel scattered. */}

      <AdvancedDisclosure
        summary={
          advancedCount
            ? es
              ? `${advancedCount} opción(es) de repositorio configurada(s)`
              : `${advancedCount} repository option(s) configured`
            : es
              ? "Repositorio, GitHub e IDE · sin opciones"
              : "Repository, GitHub, and IDE · no options"
        }
      >
        <fieldset className="delivery-options">
          <legend>
            {es ? "Opciones de repositorio" : "Repository options"}
          </legend>
          {(
            [
              [
                "initializeGit",
                GitBranch,
                isWeb
                  ? es
                    ? "Incluir guía Git"
                    : "Include Git guide"
                  : es
                    ? "Inicializar Git"
                    : "Initialize Git",
              ],
              [
                "createRemote",
                Cloud,
                isWeb
                  ? es
                    ? "Incluir guía GitHub"
                    : "Include GitHub guide"
                  : es
                    ? "Crear remoto privado en GitHub"
                    : "Create private GitHub remote",
              ],
              [
                "openIde",
                FileCode2,
                isWeb
                  ? es
                    ? "Incluir guía IDE"
                    : "Include IDE guide"
                  : es
                    ? "Abrir en el IDE"
                    : "Open in the IDE",
              ],
            ] as const
          ).map(([key, Icon, label]) => (
            <label
              key={key}
              className={!repositoryEnabled ? "disabled-option" : ""}
            >
              <input
                type="checkbox"
                checked={project[key]}
                disabled={!repositoryEnabled}
                onChange={(event) => setFlag(key, event.target.checked)}
              />
              <Icon aria-hidden="true" />
              <span>
                <strong>{label}</strong>
                {!repositoryEnabled && (
                  <small>
                    {es ? "Requiere repositorio." : "Needs a repository."}
                  </small>
                )}
              </span>
            </label>
          ))}
          {/* The web caveat is a truthfulness disclosure, not filler: on the
              web these toggles cannot run anything locally, and saying so is
              the difference between a limitation and a lie by omission. It is
              also why it stays full length while the desktop note is short. */}
          <p className="capability-note">
            {isWeb
              ? es
                ? "GitHub nunca hace push automáticamente. En web estas opciones añaden guías al ZIP; no ejecutan herramientas locales."
                : "GitHub never pushes automatically. On the web these options add guides to the ZIP; they do not run local tools."
              : es
                ? "GitHub nunca hace push automáticamente."
                : "GitHub never pushes automatically."}
          </p>
        </fieldset>
      </AdvancedDisclosure>

      {(errors.openIde || errors.createRemote) && (
        <p
          id="project-repository-options"
          className="field-error"
          tabIndex={-1}
        >
          {es
            ? "Git es obligatorio para GitHub y para abrir el repositorio en el IDE."
            : "Git is required for GitHub and opening the repository in the IDE."}
        </p>
      )}

      <LocalityNote
        title={
          isWeb
            ? es
              ? "Descarga local"
              : "Local download"
            : es
              ? "Escritura local"
              : "Local write"
        }
      >
        {isWeb
          ? es
            ? "El proyecto se prepara en esta pestaña y se descarga como ZIP."
            : "The project is prepared in this tab and downloaded as a ZIP."
          : es
            ? "La ejecución usa la carpeta elegida y tu sesión local de GitHub/IDE cuando corresponde."
            : "Execution uses the chosen folder and your local GitHub/IDE session when applicable."}
      </LocalityNote>
    </div>
  );
}
