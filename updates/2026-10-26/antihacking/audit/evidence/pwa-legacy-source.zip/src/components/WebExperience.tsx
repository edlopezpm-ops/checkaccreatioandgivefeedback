import { Plus } from "lucide-react";
import type { Locale } from "../types";

export type DraftState = "loading" | "saving" | "saved" | "error";

export function WebExperienceIntro({
  locale,
  draftState,
  onNewDraft,
}: {
  locale: Locale;
  draftState: DraftState;
  onNewDraft: () => void;
}) {
  const es = locale === "es";
  return (
    <div className="web-intro">
      <button type="button" className="secondary" onClick={onNewDraft}>
        <Plus /> {es ? "Nuevo borrador" : "New draft"}
      </button>
      <p className="draft-state" role="status">
        {draftState === "loading"
          ? es
            ? "Cargando borrador…"
            : "Loading draft…"
          : draftState === "saving"
            ? es
              ? "Guardando en este navegador…"
              : "Saving in this browser…"
            : draftState === "saved"
              ? es
                ? "Borrador guardado en este navegador"
                : "Draft saved in this browser"
              : ""}
      </p>
      {draftState === "error" ? (
        <p className="draft-state error" role="alert">
          {es
            ? "No pudimos guardar este cambio. Conserva una copia del trabajo visible antes de salir. Otra pestaña o una versión más reciente puede estar protegiendo el borrador. Cierra la otra pestaña y vuelve a intentarlo tras recargar y verificar la misma cuenta y sesión."
            : "We could not save this change. Keep a copy of visible work before leaving. Another tab or a newer version may be protecting the draft. Close the other tab and try again after reloading and verifying the same account and session."}
        </p>
      ) : null}
      <small>
        {es
          ? "Este borrador no es una copia de seguridad. Cerrar sesión, eliminar o cambiar la cuenta lo borra; el siguiente acceso empieza vacío. También puede perderse al borrar datos del sitio o por el navegador."
          : "This draft is not a backup. Signing out, deleting or changing the account clears it; the next sign-in starts blank. Site-data removal or browser eviction can also erase it."}
      </small>
    </div>
  );
}
