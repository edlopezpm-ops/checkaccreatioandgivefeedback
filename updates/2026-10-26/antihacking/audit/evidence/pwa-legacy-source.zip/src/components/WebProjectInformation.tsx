import type { Locale } from "../types";

export type PublicSignInProvider = "google" | "github" | "email-code";

const questions = [
  [
    "What does accreatio create?",
    "¿Qué crea accreatio?",
    "A project starting point: your definition, an explicit prompt, a deterministic plan, guidance, and selected supporting files in a ZIP. It does not build or deploy a finished application.",
    "Un punto de partida: tu definición, un prompt explícito, un plan determinista, guías y los archivos seleccionados en un ZIP. No construye ni despliega una aplicación terminada.",
  ],
  [
    "Do I need AI tools or a paid subscription?",
    "¿Necesito herramientas AI o una suscripción?",
    "Preparing a project does not call an AI provider. Planned roles describe how you want to divide the work later; they do not hire or run agents. Optional orchestration instructions require later tool configuration on your machine. Inspect them before running them. accreatio is web-only. The obsolete desktop prototype was never released and will never be released.",
    "La preparación no llama a un proveedor de IA. Los roles planificados describen cómo quieres repartir el trabajo después; no contratan ni ejecutan agentes. Las instrucciones opcionales de orquestación requieren configuración posterior en tu equipo. Inspecciónalas antes de ejecutarlas. accreatio es solo web. El prototipo obsoleto de escritorio nunca se publicó y nunca se publicará.",
  ],
  [
    "Do I need an account? Is there a daily limit?",
    "¿Necesito una cuenta? ¿Hay un límite diario?",
    "Sign in to prepare your project. The account service authorizes five new exports per account in any rolling 24 hours across sessions and devices. Editing and reviewing do not use your allowance. You can retry the same authorized export within 48 hours without using another slot, while its ZIP remains available in this tab. About, the public sample, and published Blog posts can be read without signing in. The sign-in screen shows the methods enabled in this environment.",
    "Inicia sesión para preparar tu proyecto. El servicio autoriza cinco exportaciones nuevas por cuenta en cualquier periodo móvil de 24 horas, compartido entre sesiones y dispositivos. Editar y revisar no consume cuota. Puedes reintentar la misma exportación autorizada durante 48 horas sin consumir otra, mientras su ZIP siga disponible en esta pestaña. About, el ejemplo público y las publicaciones del Blog se pueden leer sin iniciar sesión. La pantalla de acceso muestra los métodos habilitados en este entorno.",
  ],
  [
    "What should I enter, and can I change it later?",
    "¿Qué debo ingresar? ¿Puedo cambiarlo después?",
    "Start with a name of up to 50 characters. Idea/context accepts up to 20,000 UTF-16 units, constraints up to 10,000, and each participant task up to 5,000, using the JavaScript textarea count; some emoji count as two units. You can go back without losing your answers. Review the final summary before confirming.",
    "Empieza con un nombre de hasta 50 caracteres. Idea/contexto admite hasta 20.000 unidades UTF-16, restricciones hasta 10.000 y cada tarea de participante hasta 5.000, según el conteo del textarea de JavaScript; algunos emoji cuentan como dos unidades. Puedes volver sin perder respuestas. Revisa el resumen final antes de confirmar.",
  ],
  [
    "How many roles can I plan?",
    "¿Cuántos roles puedo planear?",
    "Choose one to four distinct roles: generalist, architect, implementer, and auditor. A selected role cannot be selected twice. Your later working environment must actually provide the planned capabilities.",
    "Elige de uno a cuatro roles distintos: generalista, arquitecto, implementador y auditor. No se pueden repetir. Tu entorno de trabajo posterior debe disponer de las capacidades planeadas.",
  ],
  [
    "What is the difference between dry review and ZIP?",
    "¿Cuál es la diferencia entre revisión y ZIP?",
    "Check the package without downloading validates and previews it. Create and download ZIP prepares the package and requests a browser download. Checking does not use export allowance. Review your brief, constraints, files, and options before choosing the action.",
    "Comprobar el paquete sin descargar valida y muestra la vista previa. Crear y descargar ZIP prepara el paquete y solicita la descarga al navegador. Comprobar no consume cuota de exportación. Revisa el encargo, los límites, los archivos y las opciones antes de elegir la acción.",
  ],
  [
    "Where do my project and files go?",
    "¿Dónde van mi proyecto y mis archivos?",
    "Your project content is processed in this browser and is not sent to accreatio servers. Sign-in and allowance use a separate account service. Cloudflare hosts the site; published Blog content uses a separate editorial store. If you later give the ZIP to an assistant or another service, that service's terms and controls apply.",
    "El contenido de tu proyecto se procesa en este navegador y no se envía a servidores de accreatio. El acceso y la cuota utilizan un servicio de cuenta separado. Cloudflare aloja la web; las publicaciones del Blog usan un almacén editorial independiente. Si después entregas el ZIP a un asistente u otro servicio, se aplican sus condiciones y controles.",
  ],
  [
    "What survives a reload?",
    "¿Qué se conserva al recargar?",
    "When local saving succeeds, this browser keeps one draft bound to the verified account and session: answers, project and participant names, options, position and selected-file count, without file names or bytes. Restore requires the matching verified account/session; select files again after reload. Signing out, deleting or changing the account clears the site draft, file references and prepared ZIP; the next sign-in starts blank. Downloaded files, introduction, cookie preferences and account allowance are independent. Older unowned drafts are discarded. This is not a backup or server project sync; other browsers/devices have separate storage.",
    "Cuando el guardado local funciona, este navegador conserva un borrador vinculado a la cuenta y sesión verificadas: respuestas, nombres de proyecto y participantes, opciones, posición y cantidad de adjuntos, sin nombres ni bytes de archivos. Restaurarlo requiere la misma cuenta/sesión verificada; reselecciona archivos tras recargar. Cerrar sesión, eliminar o cambiar la cuenta borra borrador, referencias y ZIP; el siguiente acceso empieza vacío. Descargas, introducción, cookies y cuota son independientes. Se descartan borradores antiguos sin propietario. No es backup ni sincronización del proyecto; otros navegadores/dispositivos tienen almacenamiento separado.",
  ],
  [
    "Which files can I include?",
    "¿Qué archivos puedo incluir?",
    "Up to 20 DOCX, PDF, PNG or JPEG files, 20 MiB each and 100 MiB total. Their structure and active features are checked locally, and accepted files are reconstructed before export. Unsupported or complex features may be rejected. They remain untrusted reference material; checks do not certify them free of malware. Device memory can prevent export before these limits.",
    "Hasta 20 archivos DOCX, PDF, PNG o JPEG, 20 MiB por archivo y 100 MiB en total. Se comprueban localmente su estructura y funciones activas, y los aceptados se reconstruyen antes de exportar. Las funciones no compatibles o complejas pueden rechazarse. Siguen siendo referencias no confiables; la comprobación no certifica ausencia de malware. La memoria disponible puede impedir exportar antes de esos límites.",
  ],
  [
    "Can I use mobile or work offline?",
    "¿Puedo usar mobile o trabajar sin conexión?",
    "The layout adapts to small screens and touch. File pickers, download handling, available memory, and installation depend on your browser and device. During temporary suspension, unavailable/offline session verification or reauthentication, the builder stays locked and clears its prepared ZIP and retry information from memory. The saved draft stays hidden and can resume only after the same owner is verified again. Explicit sign out, account deletion or an account change discards that draft. Keep important files outside the browser.",
    "La interfaz se adapta a pantallas pequeñas y uso táctil. Archivos, descargas, memoria e instalación dependen del navegador y dispositivo. Durante una suspensión temporal, verificación de sesión no disponible/sin conexión o reautenticación, el creador permanece bloqueado y borra de memoria el ZIP preparado y su reintento. El borrador guardado queda oculto y sólo puede retomarse al verificar de nuevo al mismo propietario. Cerrar sesión explícitamente, eliminar o cambiar la cuenta descarta ese borrador. Conserva los archivos importantes fuera del navegador.",
  ],
  [
    "What if a download does not appear?",
    "¿Qué hago si no aparece la descarga?",
    "Check your browser's downloads and permissions. The browser may cancel, rename, or relocate a file; a requested download does not prove it was saved. Keep the tab open with its selected files, return to review, and try again.",
    "Revisa las descargas y permisos del navegador. Puede cancelar, renombrar o mover un archivo; solicitar una descarga no prueba que se guardó. Conserva la pestaña con sus archivos, vuelve a revisión e intenta otra vez.",
  ],
  [
    "Does ZIP export connect GitHub or overwrite a repository?",
    "¿Exportar ZIP conecta GitHub o sobrescribe un repositorio?",
    "No. Export downloads an archive; it does not request repository access, push code, or write into an existing repository. Signing in with an enabled identity provider is separate from export. Review its contents and choose how to extract or integrate them yourself.",
    "No. Exportar descarga un archivo; no solicita acceso a repositorios, sube código ni escribe dentro de un repositorio existente. El acceso con un proveedor de identidad habilitado es independiente de la exportación. Revisa el contenido y decide cómo extraerlo o integrarlo.",
  ],
  [
    "Can I share the output?",
    "¿Puedo compartir el resultado?",
    "You retain the rights you already hold in your material. Included reusable AEKR templates carry the MIT notice in LICENSES/AEKR-TEMPLATES.txt, which permits use, modification, redistribution, and sale while preserving its notice. This does not license accreatio application code or third-party inputs. Review personal information, secrets, licenses, and confidentiality obligations before sharing.",
    "Conservas los derechos que ya tienes sobre tu material. Las plantillas AEKR reutilizables incluidas llevan el aviso MIT en LICENSES/AEKR-TEMPLATES.txt, que permite uso, modificación, redistribución y venta conservando su aviso. Esto no licencia el código de la aplicación accreatio ni tus entradas de terceros. Revisa datos personales, secretos, licencias y obligaciones de confidencialidad antes de compartir.",
  ],
] as const;

export function WebProjectInformation({
  locale,
  enabledSignInProviders,
}: {
  locale: Locale;
  enabledSignInProviders?: readonly PublicSignInProvider[];
}) {
  const es = locale === "es";
  const providers = enabledSignInProviders?.map((provider) =>
    provider === "google"
      ? "Google"
      : provider === "github"
        ? "GitHub"
        : es
          ? "código de correo"
          : "email code",
  );
  return (
    <>
      <section className="about-faq" aria-labelledby="about-faq-title">
        <h2 id="about-faq-title">FAQ</h2>
        {questions.map(([enQ, esQ, enA, esA]) => (
          <details key={enQ}>
            <summary>{es ? esQ : enQ}</summary>
            <p>{es ? esA : enA}</p>
            {enQ === "Do I need an account? Is there a daily limit?" &&
              !!providers?.length && (
                <p>
                  {es
                    ? "Métodos habilitados ahora: "
                    : "Currently enabled methods: "}
                  {providers.join(", ")}.
                </p>
              )}
          </details>
        ))}
        <nav
          className="legal-links"
          aria-label={es ? "Más ayuda" : "More help"}
        >
          <a href="#about-operation">{es ? "Cómo funciona" : "How it works"}</a>
          <a href="#about-security">
            {es ? "Seguridad y privacidad" : "Security and privacy"}
          </a>
          <a href={`/?view=welcome&lang=${locale}`}>
            {es ? "Ver bienvenida y ejemplo" : "View welcome and sample"}
          </a>
          <a href="/legal/faq.html" target="_blank" rel="noopener noreferrer">
            {es ? "FAQ completo · nueva pestaña" : "Full FAQ · new tab"}
          </a>
        </nav>
      </section>
      <section className="about-terms" aria-labelledby="about-terms-title">
        <h2 id="about-terms-title">
          {es ? "Términos de servicio" : "Terms of Service"}
        </h2>
        <p>
          {es
            ? "Beta web gratuita. Los Términos y la Política de privacidad enlazados son los documentos aplicables. Su fecha y versión figuran en cada documento. La revisión legal formal sigue pendiente."
            : "Free web beta. The linked Terms and Privacy Policy are the applicable documents. Each document records its date and version. Formal legal review remains pending."}
        </p>
        <h3>{es ? "Acceso y uso permitido" : "Access and permitted use"}</h3>
        <p>
          {es
            ? "Usa solamente el acceso aprobado para ti. No eludas controles de acceso, abuses de recursos ni interfieras con otros usuarios. La disponibilidad de la beta puede cambiar."
            : "Use only the access approved for you. Do not bypass access controls, abuse resources, or interfere with other users. Beta availability may change."}
        </p>
        <h3>{es ? "Tus entradas y tu resultado" : "Your inputs and output"}</h3>
        <p>
          {es
            ? "Debes tener los derechos necesarios sobre los textos y archivos que uses. Revisa el ZIP antes de ejecutarlo, compartirlo o integrarlo. La definición de roles no garantiza que las herramientas estén disponibles ni que el proyecto sea correcto o completo."
            : "You must have the necessary rights to the text and files you use. Review the ZIP before running, sharing, or integrating it. Planned roles do not guarantee available tools or a correct or complete project."}
        </p>
        <h3>
          {es ? "Datos y servicios separados" : "Data and separate services"}
        </h3>
        <p>
          {es
            ? "La creación web procesa el proyecto localmente. El borrador del navegador no es una copia de seguridad. El armador requiere una sesión iniciada y verificada. El Blog se puede leer sin iniciar sesión; sólo el administrador puede publicar y su contenido se almacena por separado. Revisa la política de privacidad para sus límites."
            : "Web creation processes your project locally. The browser draft is not a backup. The builder requires a verified signed-in session. The Blog is public to read; only administrators can publish, and editorial content is stored separately. See the privacy policy for those boundaries."}
        </p>
        <h3>
          {es ? "Licencias y responsabilidad" : "Licensing and responsibility"}
        </h3>
        <p>
          {es
            ? "El software mantiene la licencia restringida incluida en LICENSE y el copyright de Ed Lopez. AEKR es la marca asociada; esta página no transfiere la titularidad. Los archivos y componentes de terceros conservan sus licencias. Se trata de una beta sin garantía de disponibilidad o adecuación; los términos completos respetan los derechos que la ley no permita excluir."
            : "The software retains the restricted license in LICENSE and Ed Lopez's copyright. AEKR is the associated brand; this page does not transfer ownership. Third-party files and components retain their licenses. This beta does not guarantee availability or fitness; the full terms preserve rights that applicable law does not allow excluding."}
        </p>
        <nav
          className="legal-links"
          aria-label={es ? "Documentos y ayuda" : "Documents and help"}
        >
          <a href="/legal/terms.html" target="_blank" rel="noopener noreferrer">
            {es ? "Términos" : "Terms"}
          </a>
          <a
            href="/legal/privacy.html"
            target="_blank"
            rel="noopener noreferrer"
          >
            {es ? "Privacidad · nueva pestaña" : "Privacy · new tab"}
          </a>
          <a href="/legal/cookies" target="_blank" rel="noopener noreferrer">
            {es
              ? "Cookies y almacenamiento · nueva pestaña"
              : "Cookies and storage · new tab"}
          </a>
          <a href="#about-faq">FAQ</a>
          <a href="mailto:aekr@aekr.io">
            {es ? "Ayuda y contacto" : "Help and contact"}
          </a>
        </nav>
      </section>
    </>
  );
}
