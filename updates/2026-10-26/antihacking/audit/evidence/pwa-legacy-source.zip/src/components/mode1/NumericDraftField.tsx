import React, { useState } from "react";

interface NumericDraftFieldProps {
  id: string;
  label: string;
  help: string;
  value: string;
  invalid: boolean;
  errorText: string;
  showErrors: boolean;
  onChange: (value: string) => void;
}

/** A labeled numeric text field that edits a string, never a number, so
 * empty/partial keyboard input -- and invalid pasted text -- is always kept
 * visible for the user to correct rather than silently dropped or restored.
 * The error only becomes visible after this field is blurred or a Save was
 * attempted (`showErrors`), never while the user is still typing. */
export function NumericDraftField({
  id,
  label,
  help,
  value,
  invalid,
  errorText,
  showErrors,
  onChange,
}: NumericDraftFieldProps) {
  const [touched, setTouched] = useState(false);
  const helpId = `${id}-help`;
  const errorId = `${id}-error`;
  const displayError = invalid && (touched || showErrors);
  return (
    <label className="mode1-numeric-field" htmlFor={id}>
      <span className="mode1-numeric-field__label">{label}</span>
      <input
        id={id}
        type="text"
        inputMode="numeric"
        autoComplete="off"
        value={value}
        aria-describedby={displayError ? `${helpId} ${errorId}` : helpId}
        aria-invalid={displayError || undefined}
        onChange={(event) => onChange(event.target.value)}
        onBlur={() => setTouched(true)}
      />
      <small id={helpId} className="mode1-numeric-field__help">
        {help}
      </small>
      {displayError && (
        <small id={errorId} className="mode1-numeric-field__error" role="alert">
          {errorText}
        </small>
      )}
    </label>
  );
}
