import { CircleHelp, FileText, ShieldCheck } from "lucide-react";
import type { Locale } from "../../types";

export type ProjectHelpSection = "about-faq" | "about-terms";

export function ProjectHelp({
  locale,
  onOpen,
  reassure = false,
}: {
  locale: Locale;
  onOpen: (section: ProjectHelpSection) => void;
  reassure?: boolean;
}) {
  const es = locale === "es";
  return (
    <div className="project-help">
      {reassure && (
        <p className="guided-creation__reassurance">
          <ShieldCheck aria-hidden="true" />
          {es
            ? "Puedes volver y cambiar tus respuestas. Tú confirmas al final."
            : "You can go back and change your answers. You confirm at the end."}
        </p>
      )}
      <nav aria-label={es ? "Ayuda y condiciones" : "Help and terms"}>
        <button type="button" onClick={() => onOpen("about-faq")}>
          <CircleHelp aria-hidden="true" /> FAQ
        </button>
        <button
          type="button"
          onClick={() => onOpen("about-terms")}
          aria-label={es ? "Términos de servicio" : "Terms of Service"}
        >
          <FileText aria-hidden="true" /> ToS
        </button>
      </nav>
    </div>
  );
}
