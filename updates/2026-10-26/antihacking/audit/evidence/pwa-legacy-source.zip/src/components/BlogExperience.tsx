import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent, MouseEvent } from "react";
import type { Locale } from "../types";
import { presentBlogAttribution } from "../blogAttribution";
import { blogPostFromUrl, isBlogSlug } from "../../shared/blogSlug";
import "./BlogExperience.css";

export interface PublishedBlogPost {
  readonly id: string;
  readonly slug: string;
  readonly title: string;
  readonly summary: string;
  readonly paragraphs: readonly string[];
  readonly language: "en" | "es";
  readonly author: string;
  readonly authorRole: string;
  readonly signature: string;
  readonly publishedAt: string;
}

interface AdminSession {
  readonly canPublish: boolean;
  readonly actor: {
    readonly kind: "human" | "agent";
    readonly label: string;
  } | null;
}

interface BlogDraft {
  title: string;
  summary: string;
  body: string;
  language: "en" | "es";
  author: string;
  authorRole: string;
  signature: string;
}

const EMPTY_DRAFT: BlogDraft = {
  title: "",
  summary: "",
  body: "",
  language: "en",
  author: "",
  authorRole: "",
  signature: "",
};

const selectedPostFromLocation = () => blogPostFromUrl(window.location.href);

const publishedLabel = (value: string, locale: Locale) => {
  const date = new Date(value.includes("T") ? value : `${value}T00:00:00Z`);
  return Number.isNaN(date.getTime())
    ? value
    : date.toLocaleDateString(locale === "es" ? "es-US" : "en-US", {
        day: "numeric",
        month: "long",
        timeZone: "UTC",
        year: "numeric",
      });
};

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const isPublishedBlogPost = (value: unknown): value is PublishedBlogPost => {
  if (!isRecord(value)) return false;
  const strings = [
    "id",
    "slug",
    "title",
    "summary",
    "author",
    "authorRole",
    "signature",
    "publishedAt",
  ];
  return (
    strings.every((key) => typeof value[key] === "string") &&
    isBlogSlug(value.slug) &&
    (value.language === "en" || value.language === "es") &&
    Array.isArray(value.paragraphs) &&
    value.paragraphs.length > 0 &&
    value.paragraphs.every(
      (paragraph) => typeof paragraph === "string" && paragraph.length > 0,
    )
  );
};

const apiMessage = (value: unknown, fallback: string) => {
  if (!isRecord(value) || !isRecord(value.error)) return fallback;
  return typeof value.error.message === "string"
    ? value.error.message
    : fallback;
};

async function readJson(response: Response): Promise<unknown> {
  const type = response.headers.get("content-type") ?? "";
  if (!type.toLowerCase().includes("application/json")) return null;
  return response.json();
}

function normalizeParagraphs(body: string) {
  return body
    .trim()
    .split(/\n\s*\n/u)
    .map((paragraph) => paragraph.trim().replace(/\s*\n\s*/gu, " "))
    .filter(Boolean);
}

function BlogComposer({
  actorLabel,
  locale,
  onPublished,
}: {
  actorLabel: string;
  locale: Locale;
  onPublished(post: PublishedBlogPost): void;
}) {
  const es = locale === "es";
  const [draft, setDraft] = useState<BlogDraft>(EMPTY_DRAFT);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const idempotencyKey = useRef<string | null>(null);

  const update = <K extends keyof BlogDraft>(key: K, value: BlogDraft[K]) => {
    setDraft((current) => ({ ...current, [key]: value }));
    setMessage(null);
    idempotencyKey.current = null;
  };

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (submitting) return;
    const paragraphs = normalizeParagraphs(draft.body);
    if (!paragraphs.length || paragraphs.length > 64) {
      setMessage(
        es
          ? "El cuerpo debe contener entre 1 y 64 párrafos."
          : "The body must contain between 1 and 64 paragraphs.",
      );
      return;
    }
    if (paragraphs.some((paragraph) => paragraph.length > 2_400)) {
      setMessage(
        es
          ? "Cada párrafo puede contener hasta 2.400 caracteres."
          : "Each paragraph may contain up to 2,400 characters.",
      );
      return;
    }
    const payload = {
      author: draft.author.trim(),
      authorRole: draft.authorRole.trim(),
      language: draft.language,
      paragraphs,
      signature: draft.signature.trim(),
      summary: draft.summary.trim(),
      title: draft.title.trim(),
    };
    if (new TextEncoder().encode(JSON.stringify(payload)).byteLength > 32_768) {
      setMessage(
        es
          ? "El post supera el tamaño máximo de publicación."
          : "The post exceeds the maximum publish size.",
      );
      return;
    }
    const confirmed = window.confirm(
      es
        ? "¿Publicar este post ahora? Después de publicar no se puede editar ni borrar desde el portal."
        : "Publish this post now? Published posts cannot yet be edited or deleted from the portal.",
    );
    if (!confirmed) return;

    const key = idempotencyKey.current ?? crypto.randomUUID();
    idempotencyKey.current = key;
    setSubmitting(true);
    setMessage(null);
    try {
      const response = await fetch("/api/admin/blog/posts", {
        body: JSON.stringify(payload),
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "Idempotency-Key": key,
          "X-Accreatio-Publish": "blog-v1",
        },
        method: "POST",
      });
      const responsePayload = await readJson(response);
      if (!response.ok)
        throw new Error(
          apiMessage(
            responsePayload,
            es
              ? "No se pudo publicar el post."
              : "The post could not be published.",
          ),
        );
      if (
        !isRecord(responsePayload) ||
        !isPublishedBlogPost(responsePayload.post)
      )
        throw new Error(
          es
            ? "La respuesta de publicación no es válida."
            : "The publication response is invalid.",
        );
      onPublished(responsePayload.post);
      setDraft(EMPTY_DRAFT);
      idempotencyKey.current = null;
      setMessage(es ? "Post publicado." : "Post published.");
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : es
            ? "No se pudo publicar el post."
            : "The post could not be published.",
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="blog-admin" aria-labelledby="blog-admin-title">
      <header>
        <p className="blog-eyebrow">
          {es ? "Administración" : "Administration"}
        </p>
        <h2 id="blog-admin-title">
          {es ? "Publicar desde la nebulosa" : "Publish from the nebula"}
        </h2>
        <p>
          {es
            ? `Sesión autorizada como ${actorLabel}. El borrador permanece sólo en esta página hasta publicar.`
            : `Authorized as ${actorLabel}. The draft stays only in this page until you publish.`}
        </p>
      </header>
      <form onSubmit={(event) => void submit(event)}>
        <label>
          {es ? "Título" : "Title"}
          <input
            required
            maxLength={120}
            value={draft.title}
            onChange={(event) => update("title", event.target.value)}
          />
        </label>
        <label>
          {es ? "Resumen" : "Summary"}
          <textarea
            required
            maxLength={240}
            rows={3}
            value={draft.summary}
            onChange={(event) => update("summary", event.target.value)}
          />
        </label>
        <label className="blog-admin__body">
          {es
            ? "Cuerpo — separa párrafos con una línea vacía"
            : "Body — separate paragraphs with a blank line"}
          <textarea
            required
            maxLength={30_000}
            rows={12}
            value={draft.body}
            onChange={(event) => update("body", event.target.value)}
          />
        </label>
        <div className="blog-admin__row">
          <label>
            {es ? "Idioma" : "Language"}
            <select
              value={draft.language}
              onChange={(event) =>
                update("language", event.target.value === "es" ? "es" : "en")
              }
            >
              <option value="en">English</option>
              <option value="es">Español</option>
            </select>
          </label>
          <label>
            {es ? "Autor visible" : "Display author"}
            <input
              required
              maxLength={80}
              value={draft.author}
              onChange={(event) => update("author", event.target.value)}
            />
          </label>
        </div>
        <label>
          {es ? "Rol / procedencia visible" : "Display role / provenance"}
          <input
            required
            maxLength={160}
            value={draft.authorRole}
            onChange={(event) => update("authorRole", event.target.value)}
          />
        </label>
        <label>
          {es ? "Firma" : "Signature"}
          <input
            required
            maxLength={160}
            value={draft.signature}
            onChange={(event) => update("signature", event.target.value)}
          />
        </label>
        <div className="blog-admin__actions">
          <p aria-live="polite" role="status">
            {message}
          </p>
          <button type="submit" disabled={submitting}>
            {submitting
              ? es
                ? "Publicando…"
                : "Publishing…"
              : es
                ? "Revisar y publicar"
                : "Review and publish"}
          </button>
        </div>
      </form>
    </section>
  );
}

export function BlogExperience({
  locale,
  onStart,
  version,
}: {
  locale: Locale;
  onStart(): void;
  version: string;
}) {
  const es = locale === "es";
  const [posts, setPosts] = useState<readonly PublishedBlogPost[]>([]);
  const [postsState, setPostsState] = useState<"loading" | "ready" | "error">(
    "loading",
  );
  const [session, setSession] = useState<AdminSession>({
    actor: null,
    canPublish: false,
  });
  const [selectedPostSlug, setSelectedPostSlug] = useState(
    selectedPostFromLocation,
  );
  const selectedPost = posts.find((post) => post.slug === selectedPostSlug);
  const visiblePosts = selectedPostSlug
    ? selectedPost
      ? [selectedPost]
      : []
    : posts;

  useEffect(() => {
    const syncPost = () => setSelectedPostSlug(selectedPostFromLocation());
    window.addEventListener("popstate", syncPost);
    return () => window.removeEventListener("popstate", syncPost);
  }, []);

  useEffect(() => {
    if (postsState !== "ready" || !selectedPostSlug) return;
    document.getElementById(`${selectedPostSlug}-title`)?.focus();
  }, [postsState, selectedPostSlug]);

  useEffect(() => {
    const title = selectedPost
      ? `${selectedPost.title} | accreatio Blog`
      : "Blog | accreatio";
    const description =
      selectedPost?.summary ??
      (locale === "es"
        ? "Publicaciones y novedades de accreatio. Lectura pública."
        : "accreatio articles and updates. Public to read.");
    const canonical = new URL("https://accreatio.com/");
    canonical.searchParams.set("view", "blog");
    canonical.searchParams.set("lang", locale);
    if (selectedPost) canonical.searchParams.set("post", selectedPost.slug);
    document.title = "accreatio | Blog";
    document
      .querySelector('meta[name="description"]')
      ?.setAttribute("content", description);
    document
      .querySelector('meta[property="og:title"]')
      ?.setAttribute("content", title);
    document
      .querySelector('meta[property="og:description"]')
      ?.setAttribute("content", description);
    document
      .querySelector('meta[property="og:url"]')
      ?.setAttribute("content", canonical.href);
    document
      .querySelector('link[rel="canonical"]')
      ?.setAttribute("href", canonical.href);
  }, [locale, selectedPost]);

  const postUrl = (slug: string | null) => {
    const url = new URL(window.location.href);
    url.searchParams.set("view", "blog");
    url.searchParams.set("lang", locale);
    if (slug) url.searchParams.set("post", slug);
    else url.searchParams.delete("post");
    url.hash = "";
    return `${url.pathname}${url.search}`;
  };
  const openPost = (
    event: MouseEvent<HTMLAnchorElement>,
    slug: string | null,
  ) => {
    if (
      event.button !== 0 ||
      event.metaKey ||
      event.ctrlKey ||
      event.shiftKey ||
      event.altKey
    )
      return;
    event.preventDefault();
    const destination = postUrl(slug);
    if (
      `${window.location.pathname}${window.location.search}` !== destination
    ) {
      window.history.pushState(null, "", destination);
      window.dispatchEvent(new PopStateEvent("popstate"));
    }
    setSelectedPostSlug(slug);
    if (!slug) document.getElementById("blog-title")?.focus();
  };

  const loadPosts = useCallback(async (signal?: AbortSignal) => {
    setPostsState("loading");
    try {
      const response = await fetch("/api/blog/posts", {
        cache: "no-store",
        credentials: "same-origin",
        headers: { Accept: "application/json" },
        redirect: "error",
        signal,
      });
      const payload = await readJson(response);
      if (!response.ok || !isRecord(payload) || !Array.isArray(payload.posts))
        throw new Error("invalid posts response");
      const nextPosts = payload.posts.filter(isPublishedBlogPost);
      if (nextPosts.length !== payload.posts.length)
        throw new Error("invalid post record");
      if (signal?.aborted) return;
      setPosts(nextPosts);
      setPostsState("ready");
    } catch (error) {
      if (
        signal?.aborted ||
        (error instanceof DOMException && error.name === "AbortError")
      )
        return;
      setPostsState("error");
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void loadPosts(controller.signal);
    return () => controller.abort();
  }, [loadPosts]);

  useEffect(() => {
    const controller = new AbortController();
    void (async () => {
      try {
        const response = await fetch("/api/admin/blog/session", {
          cache: "no-store",
          credentials: "same-origin",
          headers: { Accept: "application/json" },
          redirect: "error",
          signal: controller.signal,
        });
        const payload = await readJson(response);
        if (
          response.ok &&
          isRecord(payload) &&
          typeof payload.canPublish === "boolean"
        ) {
          const actor: AdminSession["actor"] = isRecord(payload.actor)
            ? payload.actor.kind === "human" || payload.actor.kind === "agent"
              ? typeof payload.actor.label === "string"
                ? {
                    kind: payload.actor.kind,
                    label: payload.actor.label,
                  }
                : null
              : null
            : null;
          if (controller.signal.aborted) return;
          const verifiedSession = {
            actor,
            canPublish: payload.canPublish && actor !== null,
          };
          setSession(verifiedSession);
        }
      } catch (error) {
        if (
          !controller.signal.aborted &&
          !(error instanceof DOMException && error.name === "AbortError")
        )
          setSession({ actor: null, canPublish: false });
      }
    })();
    return () => controller.abort();
  }, []);

  return (
    <main className="blog-page" aria-labelledby="blog-title">
      <div className="blog-experience">
        <header className="blog-hero">
          <p className="blog-eyebrow">
            {es ? "Notas desde la nebulosa" : "Notes from the nebula"}
          </p>
          <h1 id="blog-title" tabIndex={-1}>
            accreatio <span>Blog</span>
          </h1>
          <p className="blog-lede">
            {es
              ? "Ensayos sobre creación, orquestación y las decisiones técnicas que dan forma a accreatio."
              : "Essays on creation, orchestration, and the technical decisions shaping accreatio."}
          </p>
          <span className="blog-edition">
            {es ? "Edición" : "Edition"} {version}
          </span>
        </header>

        {postsState === "loading" ? (
          <section className="blog-state" aria-live="polite" aria-busy="true">
            <h2>{es ? "Cargando publicaciones" : "Loading posts"}</h2>
            <p>
              {es
                ? "Consultando la biblioteca editorial…"
                : "Reading the editorial library…"}
            </p>
          </section>
        ) : postsState === "error" ? (
          <section className="blog-state blog-state--error" role="alert">
            <h2>
              {es
                ? "No se pudieron cargar las publicaciones"
                : "Posts could not be loaded"}
            </h2>
            <p>
              {es
                ? "Vuelve a cargar las publicaciones para intentarlo de nuevo."
                : "Reload the posts to try again."}
            </p>
            <button type="button" onClick={() => void loadPosts()}>
              {es ? "Recargar publicaciones" : "Reload posts"}
            </button>
          </section>
        ) : (
          <>
            {selectedPostSlug && (
              <nav
                className="blog-post-navigation"
                aria-label={es ? "Publicaciones" : "Posts"}
              >
                <a
                  href={postUrl(null)}
                  onClick={(event) => openPost(event, null)}
                >
                  {es ? "Ver todas las publicaciones" : "View all posts"}
                </a>
              </nav>
            )}
            {selectedPostSlug && !selectedPost && (
              <section className="blog-state" role="status">
                <h2>
                  {es
                    ? "No encontramos esa publicación"
                    : "That post was not found"}
                </h2>
                <p>
                  {es
                    ? "Revisa el enlace o consulta todas las publicaciones."
                    : "Check the link or view all posts."}
                </p>
              </section>
            )}
            {session.canPublish && session.actor ? (
              <BlogComposer
                actorLabel={session.actor.label}
                locale={locale}
                onPublished={(post) =>
                  setPosts((current) => [post, ...current])
                }
              />
            ) : null}

            <div className="blog-posts">
              {visiblePosts.map((post, index) => (
                <article
                  className="blog-post"
                  id={post.slug}
                  key={post.id}
                  lang={post.language}
                  aria-labelledby={`${post.slug}-title`}
                >
                  <header>
                    <p className="blog-post__number">
                      Post {String(index + 1).padStart(2, "0")} ·{" "}
                      <time dateTime={post.publishedAt}>
                        {publishedLabel(post.publishedAt, locale)}
                      </time>
                    </p>
                    <h2 id={`${post.slug}-title`} tabIndex={-1}>
                      <a
                        href={postUrl(post.slug)}
                        onClick={(event) => openPost(event, post.slug)}
                      >
                        {post.title}
                      </a>
                    </h2>
                    <p className="blog-post__summary">{post.summary}</p>
                    <p className="blog-post__byline">
                      <strong>{presentBlogAttribution(post).author}</strong>
                      <span>{presentBlogAttribution(post).authorRole}</span>
                      <span className="blog-post__language">
                        {post.language === "es" ? "Español" : "English"}
                      </span>
                    </p>
                  </header>

                  {post.slug === "nebula-made-ideas-for-accreatio" && (
                    <aside
                      className="blog-update-note"
                      lang={locale}
                      aria-label={es ? "Nota de actualización" : "Update note"}
                    >
                      <p>
                        {es
                          ? "Nota de actualización (21 de octubre de 2026): este artículo describe una arquitectura anterior. Actualmente, el Blog es de lectura pública y el creador requiere iniciar sesión con un método habilitado."
                          : "Update note (October 21, 2026): this article describes an earlier architecture. The Blog is now public to read, and the builder requires an enabled sign-in method."}
                      </p>
                    </aside>
                  )}

                  <div className="blog-post__body">
                    {post.paragraphs.map((paragraph, paragraphIndex) => (
                      <p key={`${post.id}-${paragraphIndex}`}>{paragraph}</p>
                    ))}
                  </div>

                  <footer className="blog-post__signature">
                    <p>{presentBlogAttribution(post).signature}</p>
                  </footer>
                </article>
              ))}
            </div>
          </>
        )}

        <footer className="blog-footer">
          <div className="blog-close">
            <div>
              <strong>accreatio</strong>
              <p>
                {es
                  ? "De la idea a un inicio estructurado."
                  : "From idea to a structured beginning."}
              </p>
            </div>
            <button type="button" onClick={onStart}>
              {es ? "Crear un proyecto" : "Create a project"}
            </button>
          </div>
          {postsState === "ready" ? (
            <div className="blog-provenance" aria-label="Editorial provenance">
              <strong>{es ? "Nota editorial" : "Editorial note"}</strong>
              <p>
                {es
                  ? "Los posts identificados como contribuciones de IA fueron creados con asistencia de IA y revisión humana mediante AEKR. Su contenido refleja el trabajo de sus colaboradores, no declaraciones ni respaldo de los proveedores de tecnología."
                  : "Posts identified as AI contributions were created with AI assistance and human review through AEKR. Their content reflects the work of their contributors, not statements or endorsements by technology providers."}
              </p>
            </div>
          ) : null}
        </footer>
      </div>
    </main>
  );
}
