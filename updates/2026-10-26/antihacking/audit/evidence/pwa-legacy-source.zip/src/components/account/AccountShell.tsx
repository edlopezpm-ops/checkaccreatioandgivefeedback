import type {
  AccountFeatureConfig,
  AccountProvider,
} from "../../account/contracts";
import { DEFAULT_CONSENT, setOptionalConsent } from "../../account/consent";
import { useState } from "react";
import { AuthFlow } from "./AuthFlow";
import { PrivacyControls } from "./PrivacyControls";

export function AccountShell({
  config,
  provider,
}: {
  config: AccountFeatureConfig;
  provider: AccountProvider;
}) {
  const [state, setState] = useState(provider.getState());
  const [consent, setConsent] = useState(DEFAULT_CONSENT);
  if (!config.enabled) return null;
  return (
    <aside className="account-shell" aria-label="Future account preview">
      <AuthFlow
        state={state}
        onSendChallenge={(email, method) =>
          setState(provider.sendChallenge(email, method))
        }
        onVerify={(code) => setState(provider.verify(code))}
      />
      {config.consentUiEnabled && (
        <PrivacyControls
          consent={consent}
          onChange={(purpose, granted) =>
            setConsent((current) =>
              setOptionalConsent(current, purpose, granted),
            )
          }
        />
      )}
    </aside>
  );
}
