import { FileCode2, Paperclip, Rocket, X } from "lucide-react";
import type {
  Attachment,
  Locale,
  Phase,
  ProjectDefinition,
  WebAttachment,
} from "../../types";
import { MAX_FILES } from "../../core";
import { AdvancedDisclosure } from "./AdvancedDisclosure";
import { LocalityNote } from "./LocalityNote";

export interface RejectedAttachment {
  id: string;
  name: string;
  reason: string;
}

interface FoundationStageProps {
  errorText: (code?: string) => string | undefined;
  errors: Record<string, string>;
  isWeb: boolean;
  inspectingAttachments?: boolean;
  locale: Locale;
  onAddAttachments: () => void;
  onChange: (project: ProjectDefinition) => void;
  onDismissRestoredAttachments: () => void;
  onPhaseChange: (phase: Phase) => void;
  onRemoveAttachment: (index: number) => void;
  onRemoveRejectedAttachment: (id: string) => void;
  project: ProjectDefinition;
  rejectedAttachments: RejectedAttachment[];
  restoredAttachmentCount: number;
  webAttachments: WebAttachment[];
}

export const attachmentRejectionText = (reason: string, locale: Locale) =>
  ({
    unsupportedExtension:
      locale === "es" ? "Tipo no permitido" : "Unsupported file type",
    fileTooLarge:
      locale === "es" ? "El archivo supera 20 MiB" : "File exceeds 20 MiB",
    tooManyFiles: locale === "es" ? "Límite de 20 archivos" : "20-file limit",
    totalTooLarge:
      locale === "es" ? "El total supera 100 MiB" : "Total exceeds 100 MiB",
    unsupported:
      locale === "es" ? "Formato no permitido" : "Unsupported format",
    tooLarge:
      locale === "es"
        ? "Archivo demasiado grande o complejo"
        : "File is too large or complex",
    malformed:
      locale === "es"
        ? "Contenido o formato no válido"
        : "Invalid content or format",
    activeContent:
      locale === "es"
        ? "Contenido activo no permitido"
        : "Active content is not allowed",
    unavailable:
      locale === "es"
        ? "No se pudo leer o comprobar el archivo"
        : "File could not be read or checked",
    timeout:
      locale === "es"
        ? "La comprobación excedió el límite"
        : "File inspection exceeded its limit",
    unprepared:
      locale === "es"
        ? "El archivo requiere comprobación"
        : "File requires inspection",
  })[reason] ??
  (locale === "es"
    ? "No se pudo admitir el archivo"
    : "File could not be admitted");

export function FoundationStage({
  errorText,
  errors,
  isWeb,
  inspectingAttachments = false,
  locale,
  onAddAttachments,
  onChange,
  onDismissRestoredAttachments,
  onPhaseChange,
  onRemoveAttachment,
  onRemoveRejectedAttachment,
  project,
  rejectedAttachments,
  restoredAttachmentCount,
  webAttachments,
}: FoundationStageProps) {
  const es = locale === "es";
  const attachmentSummary = `${project.attachments.length} / ${MAX_FILES} · ${(
    project.attachments.reduce((sum, file) => sum + file.size, 0) /
    1024 /
    1024
  ).toFixed(1)} / 100 MiB`;

  return (
    <div className="creation-stage" aria-labelledby="foundation-title">
      <header className="creation-stage__header">
        <p>{es ? "Etapa 1 de 5" : "Stage 1 of 5"}</p>
        <h1 id="foundation-title">
          {es
            ? "Dale una base a tu proyecto"
            : "Give your project a foundation"}
        </h1>
        <span>
          {es
            ? "Nombra la idea y dinos en qué punto se encuentra. Esto organiza el material que accreatio preparará."
            : "Name the idea and tell us where it stands. This organizes the material accreatio will prepare."}
        </span>
      </header>

      <div className={`question-group ${errors.name ? "invalid" : ""}`}>
        <label htmlFor="project-name">
          <Rocket aria-hidden="true" />
          <span>
            <strong>{es ? "Nombre del proyecto" : "Project name"}</strong>
            <small>{es ? "Hasta 80 caracteres" : "Up to 80 characters"}</small>
          </span>
        </label>
        <input
          id="project-name"
          aria-invalid={Boolean(errors.name)}
          aria-describedby={errors.name ? "project-name-error" : undefined}
          value={project.name}
          onChange={(event) =>
            onChange({ ...project, name: event.target.value })
          }
          placeholder={
            es ? "Ej.: Copiloto de inventario" : "Ex: Inventory Copilot"
          }
        />
        {errors.name && (
          <p id="project-name-error" className="field-error">
            {errorText(errors.name)}
          </p>
        )}
      </div>

      <fieldset className="question-group">
        <legend>
          <FileCode2 aria-hidden="true" />
          <span>
            <strong>
              {es ? "¿En qué punto está?" : "Where does it stand?"}
            </strong>
            <small>
              {es
                ? "La fase decide si puedes añadir fuentes de discovery."
                : "The phase determines whether you can add discovery sources."}
            </small>
          </span>
        </legend>
        <div className="choice-cards">
          {(
            [
              ["idea", es ? "Solo una idea" : "Just an idea"],
              [
                "discovery-active",
                es ? "Discovery en curso" : "Discovery in progress",
              ],
              [
                "discovery-complete",
                es ? "Discovery completo" : "Discovery complete",
              ],
            ] as const
          ).map(([value, label]) => (
            <button
              type="button"
              key={value}
              aria-pressed={project.phase === value}
              onClick={() => onPhaseChange(value)}
            >
              {label}
            </button>
          ))}
        </div>
      </fieldset>

      {project.phase !== "idea" && (
        <AdvancedDisclosure
          summary={
            project.attachments.length
              ? es
                ? `${project.attachments.length} fuente(s) de discovery añadida(s)`
                : `${project.attachments.length} discovery source(s) added`
              : es
                ? "Fuentes de discovery · ninguna añadida"
                : "Discovery sources · none added"
          }
        >
          <div
            id="project-attachments"
            className={`attachment-workspace ${errors.attachments ? "invalid" : ""}`}
            aria-busy={inspectingAttachments}
            tabIndex={errors.attachments ? -1 : undefined}
          >
            <h2>{es ? "Fuentes de discovery" : "Discovery sources"}</h2>
            <p>
              {es
                ? "DOCX, PDF, PNG o JPEG · 20 archivos · 20 MiB por archivo · 100 MiB total"
                : "DOCX, PDF, PNG, or JPEG · 20 files · 20 MiB each · 100 MiB total"}
            </p>
            {isWeb && (
              <LocalityNote
                title={es ? "Solo en esta pestaña" : "Only in this tab"}
              >
                {es
                  ? "El borrador guarda solo la cantidad de archivos en este navegador, sin sus nombres ni bytes. Vuelve a seleccionarlos después de recargar."
                  : "The draft saves only the file count in this browser, without their names or bytes. Select them again after a reload."}
              </LocalityNote>
            )}
            {restoredAttachmentCount > 0 && (
              <p className="attachment-warning" role="status">
                {es
                  ? `Se restauró el borrador. ${restoredAttachmentCount} archivo(s) local(es) no se guardaron; selecciónalos de nuevo.`
                  : `Your draft was restored. ${restoredAttachmentCount} local attachment(s) were not saved; select them again.`}{" "}
                <button
                  type="button"
                  disabled={inspectingAttachments}
                  onClick={onDismissRestoredAttachments}
                >
                  {es ? "Descartar" : "Dismiss"}
                </button>
              </p>
            )}
            <button
              type="button"
              className="secondary"
              disabled={
                inspectingAttachments || project.attachments.length >= MAX_FILES
              }
              onClick={onAddAttachments}
            >
              <Paperclip aria-hidden="true" />
              {es ? "Añadir archivos locales" : "Add local files"}
            </button>
            {inspectingAttachments && (
              <p role="status">
                {es
                  ? "Comprobando archivos localmente…"
                  : "Inspecting files locally…"}
              </p>
            )}
            <p className="attachment-summary" aria-live="polite">
              {attachmentSummary}
              {project.attachments.length >= MAX_FILES
                ? es
                  ? " · Límite de 20 archivos alcanzado"
                  : " · 20-file limit reached"
                : ""}
            </p>
            <div className="attachments">
              {project.attachments.map((attachment, index) => (
                <span
                  key={
                    isWeb
                      ? (webAttachments[index]?.id ??
                        `${attachment.name}-${index}`)
                      : String((attachment as Attachment).path)
                  }
                >
                  {attachment.name}
                  <small>
                    {(attachment.size / 1024 / 1024).toFixed(1)} MiB
                  </small>
                  {isWeb && (
                    <small className="attachment-ready">
                      ✓ {es ? "Listo" : "Ready"}
                    </small>
                  )}
                  <button
                    type="button"
                    disabled={inspectingAttachments}
                    aria-label={`${es ? "Quitar" : "Remove"} ${attachment.name}`}
                    onClick={() => onRemoveAttachment(index)}
                  >
                    <X aria-hidden="true" />
                  </button>
                </span>
              ))}
              {rejectedAttachments.map((attachment) => (
                <span className="attachment-rejected" key={attachment.id}>
                  {attachment.name}
                  <small>
                    ⚠ {attachmentRejectionText(attachment.reason, locale)}
                  </small>
                  <button
                    type="button"
                    disabled={inspectingAttachments}
                    aria-label={`${es ? "Quitar" : "Remove"} ${attachment.name}`}
                    onClick={() => onRemoveRejectedAttachment(attachment.id)}
                  >
                    <X aria-hidden="true" />
                  </button>
                </span>
              ))}
            </div>
            {errors.attachments && (
              <p className="field-error">{errorText(errors.attachments)}</p>
            )}
          </div>
        </AdvancedDisclosure>
      )}
    </div>
  );
}
