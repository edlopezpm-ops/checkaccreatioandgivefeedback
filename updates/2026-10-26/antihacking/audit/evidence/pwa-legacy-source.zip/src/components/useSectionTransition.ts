import { useLayoutEffect, useRef, type RefObject } from "react";

/** Animate a section change without replacing its DOM or interrupting focus. */
export function useSectionTransition<T extends HTMLElement>(
  ref: RefObject<T | null>,
  sectionKey: string | number | undefined,
  enabled = true,
) {
  const previousKey = useRef(sectionKey);

  useLayoutEffect(() => {
    const changed = previousKey.current !== sectionKey;
    previousKey.current = sectionKey;
    const element = ref.current;
    if (
      !enabled ||
      !changed ||
      sectionKey === undefined ||
      !element ||
      typeof element.animate !== "function"
    ) {
      return;
    }

    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (preference.matches) return;

    // Keep the new section readable throughout the short, restrained settle.
    // Only section identity triggers this: typing and validation do not replay it.
    const animation = element.animate(
      [
        { opacity: 0.72, transform: "translate3d(0, 12px, 0)" },
        { opacity: 1, transform: "translate3d(0, -1px, 0)", offset: 0.78 },
        { opacity: 1, transform: "translate3d(0, 0, 0)" },
      ],
      {
        id: "accreatio-section-enter",
        duration: 440,
        easing: "cubic-bezier(0.22, 0.74, 0.22, 1)",
      },
    );
    const cancelForReducedMotion = () => {
      if (preference.matches) animation.cancel();
    };
    preference.addEventListener("change", cancelForReducedMotion);
    return () => {
      animation.cancel();
      preference.removeEventListener("change", cancelForReducedMotion);
    };
  }, [enabled, ref, sectionKey]);
}
