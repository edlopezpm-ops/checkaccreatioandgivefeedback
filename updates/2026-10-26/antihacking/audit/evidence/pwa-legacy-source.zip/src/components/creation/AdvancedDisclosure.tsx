import type { ReactNode } from "react";

interface AdvancedDisclosureProps {
  children: ReactNode;
  summary: string;
}

export function AdvancedDisclosure({
  children,
  summary,
}: AdvancedDisclosureProps) {
  return (
    <details className="advanced-disclosure">
      <summary>{summary}</summary>
      <div>{children}</div>
    </details>
  );
}
