import React, { type ComponentProps } from "react";
import { Paperclip, X } from "lucide-react";
import type { Attachment } from "../../types";
import { MAX_FILES } from "../../core";
import {
  attachmentRejectionText,
  type FoundationStage,
} from "./FoundationStage";
import { LocalityNote } from "./LocalityNote";

export function GuidedAttachments({
  errorText,
  errors,
  isWeb,
  inspectingAttachments = false,
  locale,
  onAddAttachments,
  onDismissRestoredAttachments,
  onRemoveAttachment,
  onRemoveRejectedAttachment,
  project,
  rejectedAttachments,
  restoredAttachmentCount,
  webAttachments,
}: ComponentProps<typeof FoundationStage>) {
  const es = locale === "es";
  const attachmentSummary = `${project.attachments.length} / ${MAX_FILES} · ${(project.attachments.reduce((sum, file) => sum + file.size, 0) / 1024 / 1024).toFixed(1)} / 100 MiB`;
  return (
    <div className="creation-stage guided-attachments">
      <header className="creation-stage__header">
        <h1>
          {es
            ? "¿Quieres añadir lo que ya tienes?"
            : "Would you like to add what you have?"}
        </h1>
        <span>
          {es
            ? "Opcional. Añade notas, investigación o requisitos para incluirlos en tu proyecto."
            : "Optional. Add notes, research, or requirements to include in your project."}
        </span>
      </header>
      <div
        id="project-attachments"
        className={`attachment-workspace ${errors.attachments ? "invalid" : ""}`}
        aria-busy={inspectingAttachments}
        tabIndex={errors.attachments ? -1 : undefined}
      >
        <h2>{es ? "Archivos de apoyo" : "Supporting files"}</h2>
        <p>
          {es
            ? "DOCX, PDF, PNG o JPEG · 20 archivos · 20 MiB por archivo · 100 MiB total"
            : "DOCX, PDF, PNG, or JPEG · 20 files · 20 MiB each · 100 MiB total"}
        </p>
        <p>
          {es
            ? "La comprobación local valida la estructura y bloquea funciones activas; las imágenes se decodifican y se vuelven a codificar. No es un análisis de malware ni una verificación de licencias."
            : "Local inspection validates structure and blocks active features; images are decoded and re-encoded. This is not a malware scan or license verification."}
        </p>
        {isWeb && (
          <LocalityNote
            title={es ? "Solo en esta pestaña" : "Only in this tab"}
          >
            {es
              ? "El borrador conserva tus respuestas y la cantidad de archivos seleccionados, pero no sus nombres ni los archivos. Vuelve a seleccionarlos después de recargar."
              : "The draft keeps your answers and the number of selected files, but not their names or the files. Select them again after a reload."}
          </LocalityNote>
        )}
        {restoredAttachmentCount > 0 && (
          <p className="attachment-warning" role="status">
            {es
              ? `Se restauró el borrador. ${restoredAttachmentCount} archivo(s) local(es) no se guardaron; selecciónalos de nuevo.`
              : `Your draft was restored. ${restoredAttachmentCount} local attachment(s) were not saved; select them again.`}{" "}
            <button
              type="button"
              disabled={inspectingAttachments}
              onClick={onDismissRestoredAttachments}
            >
              {es
                ? "Continuar sin esos archivos"
                : "Continue without those files"}
            </button>
          </p>
        )}
        <button
          type="button"
          className="secondary"
          disabled={
            inspectingAttachments || project.attachments.length >= MAX_FILES
          }
          onClick={onAddAttachments}
        >
          <Paperclip aria-hidden="true" />
          {es ? "Añadir archivos locales" : "Add local files"}
        </button>
        {inspectingAttachments && (
          <p role="status">
            {es
              ? "Comprobando archivos localmente…"
              : "Inspecting files locally…"}
          </p>
        )}
        <p className="attachment-summary" aria-live="polite">
          {attachmentSummary}
          {project.attachments.length >= MAX_FILES
            ? es
              ? " · Límite de 20 archivos alcanzado"
              : " · 20-file limit reached"
            : ""}
        </p>
        <div className="attachments">
          {project.attachments.map((attachment, index) => (
            <span
              key={
                isWeb
                  ? (webAttachments[index]?.id ?? `${attachment.name}-${index}`)
                  : String((attachment as Attachment).path)
              }
            >
              {attachment.name}
              <small>{(attachment.size / 1024 / 1024).toFixed(1)} MiB</small>
              {isWeb && (
                <small className="attachment-ready">
                  ✓ {es ? "Listo para incluir" : "Ready to include"}
                </small>
              )}
              <button
                type="button"
                disabled={inspectingAttachments}
                aria-label={`${es ? "Quitar" : "Remove"} ${attachment.name}`}
                onClick={() => onRemoveAttachment(index)}
              >
                <X aria-hidden="true" />
              </button>
            </span>
          ))}
          {rejectedAttachments.map((attachment) => (
            <span className="attachment-rejected" key={attachment.id}>
              {attachment.name}
              <small>
                ⚠ {attachmentRejectionText(attachment.reason, locale)}
              </small>
              <button
                type="button"
                disabled={inspectingAttachments}
                aria-label={`${es ? "Quitar" : "Remove"} ${attachment.name}`}
                onClick={() => onRemoveRejectedAttachment(attachment.id)}
              >
                <X aria-hidden="true" />
              </button>
            </span>
          ))}
        </div>
        {errors.attachments && (
          <p className="field-error">{errorText(errors.attachments)}</p>
        )}
      </div>
    </div>
  );
}
