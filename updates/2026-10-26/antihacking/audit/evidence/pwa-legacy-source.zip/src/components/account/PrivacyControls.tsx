import type {
  ConsentState,
  OptionalConsentPurpose,
} from "../../account/consent";

export function PrivacyControls({
  consent,
  onChange,
}: {
  consent: ConsentState;
  onChange(purpose: OptionalConsentPurpose, granted: boolean): void;
}) {
  return (
    <section aria-labelledby="privacy-controls-title">
      <h2 id="privacy-controls-title">Privacy controls (future placeholder)</h2>
      <label>
        <input type="checkbox" checked disabled /> Strictly necessary local
        preferences
      </label>
      {(["analytics", "advertising"] as const).map((purpose) => (
        <label key={purpose}>
          <input
            type="checkbox"
            checked={consent[purpose]}
            onChange={(event) => onChange(purpose, event.target.checked)}
          />{" "}
          Optional {purpose}
        </label>
      ))}
      <p>
        Optional refusal never limits local project creation. No tracker is
        loaded.
      </p>
    </section>
  );
}
