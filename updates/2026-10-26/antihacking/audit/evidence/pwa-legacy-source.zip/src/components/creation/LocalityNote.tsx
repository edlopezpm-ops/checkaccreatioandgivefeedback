import { HardDrive } from "lucide-react";
import type { ReactNode } from "react";

interface LocalityNoteProps {
  children: ReactNode;
  title: string;
}

export function LocalityNote({ children, title }: LocalityNoteProps) {
  return (
    <aside className="locality-note">
      <HardDrive aria-hidden="true" />
      <div>
        <strong>{title}</strong>
        <p>{children}</p>
      </div>
    </aside>
  );
}
