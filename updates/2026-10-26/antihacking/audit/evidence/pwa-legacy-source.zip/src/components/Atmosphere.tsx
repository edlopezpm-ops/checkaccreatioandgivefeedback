import { useEffect, useRef, useState } from "react";
import type { Settings } from "../types";
import type { NebulaEffect, NebulaOptions } from "./nebula";
import { StarField } from "./StarField";

export type AtmosphereVariant =
  "home" | "creation" | "review" | "export" | "about" | "quiet";

interface AtmosphereProps {
  theme: Settings["theme"];
  variant: AtmosphereVariant;
}

type RendererState = "fallback" | "loading" | "webgl";

interface NetworkConnection {
  addEventListener?(type: "change", listener: () => void): void;
  removeEventListener?(type: "change", listener: () => void): void;
  saveData?: boolean;
}

const networkConnection = () =>
  (
    navigator as Navigator & {
      connection?: NetworkConnection;
    }
  ).connection;

const SPEED_BY_VARIANT: Record<AtmosphereVariant, number> = {
  home: 2.6,
  creation: 1.9,
  review: 1.25,
  export: 2.1,
  about: 1.9,
  quiet: 0.8,
};

const nebulaOptions = (
  theme: Settings["theme"],
  variant: AtmosphereVariant,
): NebulaOptions => ({
  theme,
  speed: SPEED_BY_VARIANT[variant],
});

function hasWebGlSupport() {
  try {
    const canvas = document.createElement("canvas");
    const context = canvas.getContext("webgl2") ?? canvas.getContext("webgl");
    context?.getExtension("WEBGL_lose_context")?.loseContext();
    return context !== null;
  } catch {
    return false;
  }
}

/** Persistent, presentation-only environment. The procedural nebula module is
 * loaded locally and only when motion, device cadence, visibility, and WebGL
 * support allow it. */
export function Atmosphere({ theme, variant }: AtmosphereProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const webglRef = useRef<HTMLDivElement>(null);
  const effectRef = useRef<NebulaEffect | null>(null);
  const [renderer, setRenderer] = useState<RendererState>("fallback");
  const [paused, setPaused] = useState(
    () => typeof document !== "undefined" && document.hidden,
  );
  const [reducedMotion, setReducedMotion] = useState(() =>
    typeof window === "undefined"
      ? true
      : window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );
  const [slowUpdate, setSlowUpdate] = useState(() =>
    typeof window === "undefined"
      ? true
      : window.matchMedia("(update: slow)").matches,
  );
  const [saveData, setSaveData] = useState(() =>
    typeof navigator === "undefined"
      ? true
      : Boolean(networkConnection()?.saveData),
  );
  const optionsRef = useRef(nebulaOptions(theme, variant));
  optionsRef.current = nebulaOptions(theme, variant);

  useEffect(() => {
    const syncVisibility = () => setPaused(document.hidden);
    document.addEventListener("visibilitychange", syncVisibility);
    return () =>
      document.removeEventListener("visibilitychange", syncVisibility);
  }, []);

  useEffect(() => {
    const connection = networkConnection();
    if (!connection) return;
    const syncSaveData = () => setSaveData(Boolean(connection.saveData));
    connection.addEventListener?.("change", syncSaveData);
    return () => connection.removeEventListener?.("change", syncSaveData);
  }, []);

  useEffect(() => {
    const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    const updateQuery = window.matchMedia("(update: slow)");
    const syncPreferences = () => {
      setReducedMotion(motionQuery.matches);
      setSlowUpdate(updateQuery.matches);
    };
    motionQuery.addEventListener("change", syncPreferences);
    updateQuery.addEventListener("change", syncPreferences);
    return () => {
      motionQuery.removeEventListener("change", syncPreferences);
      updateQuery.removeEventListener("change", syncPreferences);
    };
  }, []);

  useEffect(() => {
    if (
      renderer !== "webgl" ||
      paused ||
      reducedMotion ||
      saveData ||
      slowUpdate
    )
      return;

    // The atmosphere never owns the pointer. Observe completed, real mouse
    // clicks only on exposed layout space, excluding every foreground surface.
    const burstOnClick = (event: MouseEvent) => {
      if (
        event.button !== 0 ||
        event.detail === 0 ||
        event.defaultPrevented ||
        ("pointerType" in event && event.pointerType !== "mouse") ||
        !(event.target instanceof Element) ||
        !event.target.matches(
          "body, #root, .app-shell, .app-content, main, .creation-workspace, .creation-layout",
        ) ||
        event.target.closest(
          "button, a, input, textarea, select, label, form, header, nav, dialog, [role], [contenteditable], .panel, .modal, .onboarding-card",
        )
      )
        return;
      effectRef.current?.burstAt(event.clientX, event.clientY);
    };

    window.addEventListener("click", burstOnClick, { passive: true });
    return () => {
      window.removeEventListener("click", burstOnClick);
    };
  }, [paused, reducedMotion, renderer, saveData, slowUpdate]);

  useEffect(() => {
    effectRef.current?.setOptions(optionsRef.current);
  }, [theme, variant]);

  useEffect(() => {
    const element = webglRef.current;
    let disposed = false;

    const destroyEffect = () => {
      effectRef.current?.destroy();
      effectRef.current = null;
    };

    destroyEffect();
    if (
      !element ||
      paused ||
      reducedMotion ||
      saveData ||
      slowUpdate ||
      !hasWebGlSupport()
    ) {
      setRenderer("fallback");
      return destroyEffect;
    }

    setRenderer("loading");
    const handleContextLoss = () => {
      destroyEffect();
      setRenderer("fallback");
    };
    element.addEventListener("webglcontextlost", handleContextLoss, true);

    void import("./nebula")
      .then(({ createNebula }) => {
        if (disposed || !element.isConnected) return;
        const effect = createNebula(element, optionsRef.current);
        if (!effect) {
          setRenderer("fallback");
          return;
        }
        effectRef.current = effect;
        setRenderer("webgl");
      })
      .catch(() => {
        if (!disposed) setRenderer("fallback");
      });

    return () => {
      disposed = true;
      element.removeEventListener("webglcontextlost", handleContextLoss, true);
      destroyEffect();
    };
  }, [paused, reducedMotion, saveData, slowUpdate]);

  return (
    <div
      ref={rootRef}
      className="atmosphere"
      data-atmosphere={variant}
      data-paused={paused || undefined}
      data-renderer={renderer}
      aria-hidden="true"
    >
      <StarField
        paused={paused}
        reducedMotion={reducedMotion}
        saveData={saveData}
        slowUpdate={slowUpdate}
        theme={theme}
      />
      <div className="atmosphere__fallback" />
      <div ref={webglRef} className="atmosphere__webgl" />
      <div className="atmosphere__scrim" />
    </div>
  );
}
