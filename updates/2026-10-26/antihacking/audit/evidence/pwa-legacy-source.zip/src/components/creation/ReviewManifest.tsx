import { FileText, MapPin, Paperclip, TriangleAlert } from "lucide-react";
import type { ExecutionPreview, Locale, ProjectDefinition } from "../../types";

interface ReviewManifestProps {
  locale: Locale;
  preview: ExecutionPreview | null;
  project: ProjectDefinition;
}

export function ReviewManifest({
  locale,
  preview,
  project,
}: ReviewManifestProps) {
  const es = locale === "es";
  const localize = (value: string) =>
    es
      ? ((
          {
            "Review only": "Solo revisión",
            "Prepare a repository ZIP": "Preparar un proyecto ZIP",
            "Create repository and tracking": "Crear proyecto y seguimiento",
            "Create repository": "Crear proyecto",
            "Create tracking": "Crear seguimiento",
            "Both creates the same repository ZIP; browser tracking is not available.":
              "La opción de proyecto y seguimiento genera el mismo ZIP. El seguimiento separado no está disponible en el navegador.",
            "No ZIP will be built and no download will be requested.":
              "No se creará ningún ZIP ni se solicitará una descarga.",
            "The browser may block, rename, relocate, or cancel the download.":
              "El navegador puede bloquear, renombrar, cambiar la ubicación o cancelar la descarga.",
            "No file, directory, remote, IDE launch, or history entry will be created.":
              "No se crearán archivos, carpetas, remotos ni registros de historial; tampoco se abrirá el IDE.",
            "Existing filenames use the next available versioned copy.":
              "Los nombres de archivo existentes reciben la siguiente copia versionada disponible.",
            "GitHub creates a remote; no push is performed.":
              "GitHub crea un remoto; no se realiza ningún push.",
          } as Record<string, string>
        )[value] ?? value)
      : value;
  const destinations =
    preview?.artifacts.filter(({ kind }) =>
      ["repository", "tracking", "zip"].includes(kind),
    ) ?? [];

  return (
    <section className="review-manifest" aria-labelledby="manifest-title">
      <h2 id="manifest-title">
        {es ? "Manifiesto de entrega" : "Delivery manifest"}
      </h2>
      <div className="review-manifest__grid">
        <article>
          <h3>
            <FileText aria-hidden="true" /> {es ? "Artefactos" : "Artifacts"}
          </h3>
          <strong>
            {preview?.artifacts.length ?? 0}{" "}
            {es ? "elementos previstos" : "planned items"}
          </strong>
          <span>
            {preview
              ? localize(preview.headline)
              : es
                ? "Completa las etapas anteriores"
                : "Complete the earlier stages"}
          </span>
        </article>
        <article>
          <h3>
            <MapPin aria-hidden="true" /> {es ? "Destino" : "Destination"}
          </h3>
          {destinations.length ? (
            destinations.map((artifact) => (
              <code key={`${artifact.kind}-${artifact.destination}`}>
                {artifact.destination}
              </code>
            ))
          ) : (
            <span>—</span>
          )}
        </article>
        <article>
          <h3>
            <Paperclip aria-hidden="true" />{" "}
            {es ? "Fuentes adjuntas" : "Attached sources"}
          </h3>
          {project.attachments.length > 0 && (
            <strong>
              {project.attachments.length} {es ? "archivo(s)" : "file(s)"}
            </strong>
          )}
          {project.attachments.length ? (
            <ul>
              {project.attachments.map((attachment, index) => (
                <li key={`${attachment.name}-${index}`}>{attachment.name}</li>
              ))}
            </ul>
          ) : (
            <span>{es ? "Sin fuentes adjuntas" : "No attached sources"}</span>
          )}
        </article>
        <article>
          <h3>
            <TriangleAlert aria-hidden="true" />{" "}
            {es ? "Límites" : "Limitations"}
          </h3>
          {preview?.limitations.length ? (
            <ul>
              {preview.limitations.map((item) => (
                <li key={item}>{localize(item)}</li>
              ))}
            </ul>
          ) : (
            <span>—</span>
          )}
        </article>
      </div>
    </section>
  );
}
