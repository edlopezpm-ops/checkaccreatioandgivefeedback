import { FileCode2, Folder, ShieldCheck } from "lucide-react";
import type { Locale, ProjectDefinition, Route } from "../../types";
import { AdvancedDisclosure } from "./AdvancedDisclosure";
import { PROJECT_TEXT_LIMITS } from "../../../shared/inputValidation";

interface ContextStageProps {
  errorText: (code?: string) => string | undefined;
  errors: Record<string, string>;
  locale: Locale;
  onChange: (project: ProjectDefinition) => void;
  project: ProjectDefinition;
}

export function ContextStage({
  errorText,
  errors,
  locale,
  onChange,
  project,
}: ContextStageProps) {
  const es = locale === "es";
  return (
    <div className="creation-stage" aria-labelledby="context-title">
      <header className="creation-stage__header">
        <p>{es ? "Etapa 2 de 5" : "Stage 2 of 5"}</p>
        <h1 id="context-title">
          {es
            ? "Explica lo que debe entender"
            : "Explain what it should understand"}
        </h1>
        <span>
          {es
            ? "Describe el propósito y los límites que deben permanecer visibles en el prompt y el plan."
            : "Describe the purpose and boundaries that must remain visible in the prompt and plan."}
        </span>
      </header>

      <div className={`question-group ${errors.context ? "invalid" : ""}`}>
        <label htmlFor="project-context">
          <FileCode2 aria-hidden="true" />
          <span>
            <strong>{es ? "Contexto conocido" : "Known context"}</strong>
            <small>
              {es ? "Qué, para quién y por qué" : "What, for whom, and why"}
            </small>
          </span>
        </label>
        <textarea
          id="project-context"
          maxLength={PROJECT_TEXT_LIMITS.context}
          aria-invalid={Boolean(errors.context)}
          aria-describedby={
            errors.context ? "project-context-error" : undefined
          }
          value={project.context}
          onChange={(event) =>
            onChange({ ...project, context: event.target.value })
          }
          placeholder={
            es
              ? "Describe el resultado que buscas…"
              : "Describe the outcome you need…"
          }
        />
        {errors.context && (
          <p id="project-context-error" className="field-error">
            {errorText(errors.context)}
          </p>
        )}
      </div>

      <AdvancedDisclosure
        summary={
          project.restrictions.trim()
            ? es
              ? "Restricciones configuradas"
              : "Constraints configured"
            : es
              ? "Restricciones · ninguna añadida"
              : "Constraints · none added"
        }
      >
        <div className="question-group">
          <label htmlFor="project-restrictions">
            <ShieldCheck aria-hidden="true" />
            <span>
              <strong>{es ? "Restricciones" : "Constraints"}</strong>
              <small>
                {es
                  ? "Coste, herramientas, privacidad u otros límites"
                  : "Cost, tools, privacy, or other boundaries"}
              </small>
            </span>
          </label>
          <input
            id="project-restrictions"
            maxLength={PROJECT_TEXT_LIMITS.restrictions}
            value={project.restrictions}
            onChange={(event) =>
              onChange({ ...project, restrictions: event.target.value })
            }
          />
        </div>
      </AdvancedDisclosure>

      <fieldset className="question-group">
        <legend>
          <Folder aria-hidden="true" />
          <span>
            <strong>{es ? "Ruta de trabajo" : "Working route"}</strong>
            <small>
              {es
                ? "Conservamos el término técnico para que el traspaso sea auditable."
                : "We retain the technical term so the handoff stays auditable."}
            </small>
          </span>
        </legend>
        <div className="choice-cards">
          {(
            [
              ["local", "A — local-first"],
              ["vendor", "B — vendor-managed"],
              ["mixed", es ? "Mixta" : "Mixed"],
            ] as const
          ).map(([value, label]) => (
            <button
              type="button"
              key={value}
              aria-pressed={project.route === value}
              onClick={() => onChange({ ...project, route: value as Route })}
            >
              {label}
            </button>
          ))}
        </div>
      </fieldset>
    </div>
  );
}
