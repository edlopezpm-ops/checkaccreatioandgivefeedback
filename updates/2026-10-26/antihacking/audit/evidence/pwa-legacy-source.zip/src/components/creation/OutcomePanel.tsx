import React, { useEffect, useState } from "react";
import { getStartingInstruction } from "../../../shared/exportManifest";
import { hasWebExportRecovery, retryWebExport } from "../../bridge/web";
import {
  ArrowLeft,
  CheckCircle2,
  Clipboard,
  Download,
  ExternalLink,
  LoaderCircle,
  TriangleAlert,
} from "lucide-react";
import type { ExecutionResult, Locale } from "../../types";
import { ProjectHelp, type ProjectHelpSection } from "./ProjectHelp";

interface OutcomePanelProps {
  isWeb: boolean;
  locale: Locale;
  onBackToReview: () => void;
  onCopyPath: () => void;
  onDownloadZip?: () => void;
  onHelp?: (section: ProjectHelpSection) => void;
  downloadZipDisabled?: boolean;
  onOpenOrchestration: () => void;
  result: ExecutionResult | null;
  running: boolean;
}

const stepNames: Record<string, { en: string; es: string }> = {
  "repository-root": {
    en: "Repository destination",
    es: "Destino del repositorio",
  },
  "repository-docs": { en: "Project documents", es: "Documentos del proyecto" },
  attachments: { en: "Attachment sources", es: "Fuentes adjuntas" },
  git: { en: "Git repository", es: "Repositorio Git" },
  github: { en: "GitHub remote (no push)", es: "Remoto de GitHub (sin push)" },
  tracking: { en: "Project tracking", es: "Tracking del proyecto" },
  history: { en: "Local history", es: "Historial local" },
  ide: { en: "IDE launch", es: "Inicio del IDE" },
  "zip-build": { en: "ZIP build", es: "Construcción del ZIP" },
  "download-request": { en: "Download request", es: "Solicitud de descarga" },
};

export function OutcomePanel({
  isWeb,
  locale,
  onBackToReview,
  onCopyPath,
  onDownloadZip,
  onHelp,
  downloadZipDisabled = false,
  onOpenOrchestration,
  result,
  running,
}: OutcomePanelProps) {
  const es = locale === "es";
  const [canRetry, setCanRetry] = useState(hasWebExportRecovery);
  const [retrying, setRetrying] = useState(false);
  const [retryMessage, setRetryMessage] = useState("");
  const [startCopied, setStartCopied] = useState(false);
  useEffect(() => {
    const update = () => setCanRetry(hasWebExportRecovery());
    update();
    window.addEventListener("accreatio:export-ready", update);
    const timer = window.setInterval(update, 30_000);
    return () => {
      window.removeEventListener("accreatio:export-ready", update);
      window.clearInterval(timer);
    };
  }, []);
  const outcome = result?.outcome;
  const canDownloadZip =
    isWeb && result?.ok && outcome === "dry-run" && Boolean(onDownloadZip);
  const title = running
    ? isWeb
      ? es
        ? "Preparando exportación…"
        : "Preparing export…"
      : es
        ? "Creando tu proyecto…"
        : "Creating your project…"
    : outcome === "dry-run"
      ? es
        ? "Revisión completada. No se creó ni descargó ningún ZIP."
        : "Review completed. No ZIP was created or downloaded."
      : outcome === "partial"
        ? es
          ? "Parte del trabajo se completó"
          : "Some work completed"
        : outcome === "failure"
          ? es
            ? "No se completó nada"
            : "Nothing was completed"
          : isWeb
            ? es
              ? "ZIP preparado; descarga solicitada"
              : "ZIP prepared; download requested"
            : es
              ? "Proyecto creado"
              : "Project created";
  const statusLabel = (status: "completed" | "failed" | "skipped") =>
    status === "completed"
      ? es
        ? "Creado o versionado"
        : "Created or versioned"
      : status === "failed"
        ? es
          ? "Falló"
          : "Failed"
        : es
          ? "Omitido"
          : "Skipped";

  return (
    <main
      className={`outcome-workspace outcome-workspace--${outcome ?? "creating"}`}
    >
      <section className="outcome-panel" aria-live="polite" aria-busy={running}>
        <header className="outcome-panel__header">
          <span className="outcome-panel__mark" aria-hidden="true">
            {running ? (
              <LoaderCircle className="spinner" />
            ) : result?.ok ? (
              <CheckCircle2 />
            ) : (
              <TriangleAlert />
            )}
          </span>
          <div>
            <p>{es ? "Resultado de creación" : "Creation outcome"}</p>
            <h1>{title}</h1>
            {running && (
              <span>
                {es
                  ? "Mantén accreatio abierto mientras termina la operación protegida."
                  : "Keep accreatio open while the guarded operation finishes."}
              </span>
            )}
            {result?.error && (
              <span className="outcome-panel__error">{result.error}</span>
            )}
          </div>
        </header>

        {result && (
          <>
            <div className="outcome-panel__guidance">
              {result.webDelivery ? (
                <p>
                  {es
                    ? `Busca ${result.webDelivery.filename} en las descargas de tu navegador. accreatio no puede confirmar que el archivo se haya guardado.`
                    : `Look for ${result.webDelivery.filename} in your browser's downloads. accreatio cannot confirm that the file was saved.`}
                </p>
              ) : outcome === "dry-run" ? (
                <p>
                  {canDownloadZip
                    ? es
                      ? "Tu revisión está completa. Descarga el ZIP cuando quieras; podrás confirmar los detalles antes de la descarga."
                      : "Your review is complete. Download the ZIP when you're ready; you can confirm the details before the download."
                    : es
                      ? "Dry run permaneció activo. Desactívalo en Entrega, vuelve a revisar y confirma para crear."
                      : "Dry run remained on. Turn it off in Review, review again, and confirm to create."}
                </p>
              ) : outcome === "partial" || outcome === "failure" ? (
                <p>
                  {es
                    ? "Revisa la evidencia antes de volver a intentarlo. Una ejecución nueva usa otra operación protegida y puede crear copias versionadas."
                    : "Review the evidence before trying again. A fresh run uses a new guarded operation and may create versioned copies."}
                </p>
              ) : (
                <p>
                  {es
                    ? "Los archivos existentes no se sobrescribieron: los conflictos recibieron copias versionadas. GitHub no recibió ningún push automático."
                    : "Existing files were not overwritten: conflicts received versioned copies. Nothing was pushed to GitHub automatically."}
                </p>
              )}
            </div>

            {isWeb && result.webDelivery && (
              <section
                className="outcome-next"
                aria-labelledby="outcome-next-title"
              >
                <h2 id="outcome-next-title">
                  {es
                    ? "Continúa con tu proyecto"
                    : "Continue with your project"}
                </h2>
                <p>
                  {es
                    ? "Extrae el ZIP, abre la carpeta en tu editor y sigue START.md. Allí encontrarás la instrucción para comenzar con el contexto de tu proyecto."
                    : "Extract the ZIP, open the folder in your editor, and follow START.md. It contains the instruction for starting with your project's context."}
                </p>
                <pre tabIndex={0}>{getStartingInstruction(locale)}</pre>
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(
                        getStartingInstruction(locale),
                      );
                      setStartCopied(true);
                    } catch {
                      setRetryMessage(
                        es
                          ? "No pudimos copiar. Selecciona la instrucción y cópiala manualmente."
                          : "We could not copy. Select the instruction and copy it manually.",
                      );
                    }
                  }}
                >
                  {startCopied
                    ? es
                      ? "Copiado"
                      : "Copied"
                    : es
                      ? "Copiar instrucción de inicio"
                      : "Copy starting instruction"}
                </button>
                <p>
                  {canRetry
                    ? es
                      ? "Puedes reintentar esta exportación autorizada durante 48 horas sin consumir otra, mientras el ZIP siga disponible en esta pestaña."
                      : "You can retry this authorized export within 48 hours without using another allowance slot, while the ZIP remains available in this tab."
                    : es
                      ? "El ZIP anterior ya no está disponible para reintento en esta pestaña. Revisa tus descargas o prepara una nueva exportación."
                      : "The previous ZIP is no longer available to retry in this tab. Check your downloads or prepare a new export."}
                </p>
                {canRetry && (
                  <button
                    type="button"
                    disabled={retrying}
                    onClick={async () => {
                      setRetrying(true);
                      try {
                        await retryWebExport();
                        setRetryMessage(
                          es
                            ? "Descarga solicitada de nuevo."
                            : "Download requested again.",
                        );
                      } catch (error) {
                        setRetryMessage(
                          error instanceof Error
                            ? error.message
                            : es
                              ? "No se pudo reintentar."
                              : "Could not retry.",
                        );
                      } finally {
                        setCanRetry(hasWebExportRecovery());
                        setRetrying(false);
                      }
                    }}
                  >
                    <Download aria-hidden="true" />
                    {es
                      ? "Volver a descargar este ZIP"
                      : "Download this ZIP again"}
                  </button>
                )}
                <p role="status">{retryMessage}</p>
              </section>
            )}

            {result.steps.length > 0 && outcome !== "dry-run" && (
              <details className="outcome-diagnostics">
                <summary>
                  {es
                    ? "Ver archivos y detalles de la exportación"
                    : "View files and export details"}
                </summary>
                <section
                  className="outcome-evidence"
                  aria-labelledby="outcome-evidence-title"
                >
                  <div className="outcome-evidence__heading">
                    <h2 id="outcome-evidence-title">
                      {es ? "Evidencia de la operación" : "Operation evidence"}
                    </h2>
                    <span>
                      {
                        result.steps.filter(
                          ({ status }) => status === "completed",
                        ).length
                      }
                      /{result.steps.length}{" "}
                      {es ? "pasos completados" : "steps completed"}
                    </span>
                  </div>
                  <ol>
                    {result.steps.map((step) => (
                      <li key={step.id} data-status={step.status}>
                        <div>
                          <strong>
                            {stepNames[step.id]?.[locale] ?? step.id}
                          </strong>
                          <span className="outcome-evidence__status">
                            {statusLabel(step.status)}
                          </span>
                        </div>
                        <p>{step.error ?? step.summary}</p>
                        {step.artifacts.length > 0 && (
                          <ul
                            aria-label={
                              es
                                ? "Artefactos evidenciados"
                                : "Evidenced artifacts"
                            }
                          >
                            {step.artifacts.map((artifact, index) => (
                              <li
                                key={`${artifact.kind}-${artifact.location}-${index}`}
                              >
                                <span>{artifact.displayName}</span>
                                <code>{artifact.location}</code>
                              </li>
                            ))}
                          </ul>
                        )}
                      </li>
                    ))}
                  </ol>
                </section>
              </details>
            )}

            <div className="outcome-panel__actions">
              {canDownloadZip && (
                <button
                  type="button"
                  className="start"
                  disabled={running || downloadZipDisabled}
                  onClick={onDownloadZip}
                >
                  {running ? (
                    <LoaderCircle className="spinner" aria-hidden="true" />
                  ) : (
                    <Download aria-hidden="true" />
                  )}
                  {running
                    ? es
                      ? "Preparando ZIP…"
                      : "Preparing ZIP…"
                    : es
                      ? "Crear y descargar ZIP"
                      : "Create and download ZIP"}
                </button>
              )}
              <button
                type="button"
                className={canDownloadZip ? "secondary" : "start"}
                disabled={isWeb && running}
                onClick={onBackToReview}
              >
                {isWeb && outcome === "success" ? (
                  <Download aria-hidden="true" />
                ) : (
                  <ArrowLeft aria-hidden="true" />
                )}
                {isWeb && outcome === "success"
                  ? es
                    ? "Editar y volver a exportar"
                    : "Edit and export again"
                  : es
                    ? "Volver a revisión"
                    : "Back to review"}
              </button>
              {!isWeb && result.projectPath && (
                <button type="button" onClick={onCopyPath}>
                  <Clipboard aria-hidden="true" />
                  {es ? "Copiar ruta" : "Copy path"}
                </button>
              )}
              {!isWeb && result.ok && !result.dryRun && (
                <button type="button" onClick={onOpenOrchestration}>
                  <ExternalLink aria-hidden="true" />
                  {es ? "Abrir orquestación" : "Open orchestration"}
                </button>
              )}
            </div>

            <details className="outcome-diagnostics">
              <summary>
                {es ? "Diagnóstico técnico" : "Technical diagnostics"}
              </summary>
              <pre>
                {result.logs.length
                  ? result.logs.join("\n")
                  : es
                    ? "No se registraron mensajes."
                    : "No diagnostic messages were recorded."}
              </pre>
            </details>
          </>
        )}
      </section>
      {isWeb && onHelp && <ProjectHelp locale={locale} onOpen={onHelp} />}
    </main>
  );
}
