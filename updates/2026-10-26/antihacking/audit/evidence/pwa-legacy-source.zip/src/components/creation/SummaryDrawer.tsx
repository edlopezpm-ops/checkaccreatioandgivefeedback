import React from "react";
import { ChevronDown, ClipboardList } from "lucide-react";
import type { Locale, ProjectDefinition } from "../../types";
import type { GuidedQuestion } from "./guidedFlow";

interface SummaryDrawerProps {
  current?: GuidedQuestion;
  isWeb?: boolean;
  locale: Locale;
  project: ProjectDefinition;
}

export function SummaryDrawer({
  current = "review",
  isWeb = false,
  locale,
  project,
}: SummaryDrawerProps) {
  const es = locale === "es";
  if (isWeb) {
    const questionOrder: GuidedQuestion[] = [
      "name",
      "phase",
      "attachments",
      "context",
      "restrictions",
      "route",
      "team",
      "delivery",
      "review",
    ];
    const reached = (question: GuidedQuestion) =>
      questionOrder.indexOf(current) >= questionOrder.indexOf(question);
    const showFiles = project.attachments.length > 0 || reached("attachments");
    const showTeam = project.participants.length > 1 || reached("team");
    const fileCount = project.attachments.length;
    const participantCount = project.participants.length;
    const counts = [
      showFiles
        ? es
          ? `${fileCount} ${fileCount === 1 ? "archivo" : "archivos"}`
          : `${fileCount} ${fileCount === 1 ? "file" : "files"}`
        : "",
      showTeam
        ? es
          ? `${participantCount} ${participantCount === 1 ? "participante" : "participantes"}`
          : `${participantCount} ${participantCount === 1 ? "participant" : "participants"}`
        : "",
    ]
      .filter(Boolean)
      .join(" · ");
    const phaseLabels = es
      ? {
          idea: "Idea inicial",
          "discovery-active": "Investigación en curso",
          "discovery-complete": "Idea definida",
        }
      : {
          idea: "Starting idea",
          "discovery-active": "Research in progress",
          "discovery-complete": "Defined idea",
        };
    const routeLabels = es
      ? {
          local: "Herramientas locales",
          vendor: "Plataforma gestionada",
          mixed: "Local y gestionado",
        }
      : {
          local: "Local tools",
          vendor: "Managed platform",
          mixed: "Local and managed",
        };
    const guides = [
      project.initializeGit && "Git",
      project.createRemote && "GitHub",
      project.openIde && "IDE",
    ]
      .filter(Boolean)
      .join(" · ");
    return (
      <details className="summary-drawer summary-drawer--web">
        <summary>
          <ClipboardList aria-hidden="true" />
          <span>
            {es ? "Resumen del proyecto" : "Project summary"}
            {counts && (
              <small className="summary-drawer__preview">{counts}</small>
            )}
          </span>
          <ChevronDown className="summary-drawer__chevron" aria-hidden="true" />
        </summary>
        <dl>
          <div className="summary-drawer__project">
            <dt>{es ? "Proyecto" : "Project"}</dt>
            <dd>{project.name || "—"}</dd>
          </div>
          {reached("phase") && (
            <div>
              <dt>{es ? "Punto de partida" : "Starting point"}</dt>
              <dd>{phaseLabels[project.phase]}</dd>
            </div>
          )}
          {showFiles && (
            <div>
              <dt>{es ? "Archivos adjuntos" : "Attached files"}</dt>
              <dd>{fileCount}</dd>
            </div>
          )}
          {reached("route") && (
            <div>
              <dt>{es ? "Forma de trabajo" : "Working approach"}</dt>
              <dd>{routeLabels[project.route]}</dd>
            </div>
          )}
          {showTeam && (
            <div>
              <dt>{es ? "Participantes" : "Participants"}</dt>
              <dd>{participantCount}</dd>
            </div>
          )}
          {reached("delivery") && (
            <>
              <div>
                <dt>{es ? "Entrega" : "Delivery"}</dt>
                <dd>{es ? "Proyecto ZIP" : "Project ZIP"}</dd>
              </div>
              <div>
                <dt>{es ? "Guías incluidas" : "Included guides"}</dt>
                <dd>{guides || (es ? "Ninguna" : "None")}</dd>
              </div>
              <div>
                <dt>{es ? "Confirmación" : "Confirmation"}</dt>
                <dd>
                  {project.dryRun
                    ? es
                      ? "Revisar primero"
                      : "Review first"
                    : es
                      ? "Descargar tras confirmar"
                      : "Download after confirmation"}
                </dd>
              </div>
            </>
          )}
        </dl>
      </details>
    );
  }
  return (
    <details className="summary-drawer">
      <summary>
        <ClipboardList aria-hidden="true" />{" "}
        {es ? "Resumen del proyecto" : "Project summary"}
      </summary>
      <dl>
        <div>
          <dt>{es ? "Proyecto" : "Project"}</dt>
          <dd>{project.name || "—"}</dd>
        </div>
        <div>
          <dt>{es ? "Equipo" : "Team"}</dt>
          <dd>{project.participants.length}</dd>
        </div>
        <div>
          <dt>{es ? "Resultado" : "Output"}</dt>
          <dd>{project.action}</dd>
        </div>
        <div>
          <dt>{es ? "Destino" : "Destination"}</dt>
          <dd>{project.destination || "—"}</dd>
        </div>
      </dl>
    </details>
  );
}
