import type { AccountState, AuthMethod } from "../../account/contracts";

interface AuthFlowProps {
  state: AccountState;
  onSendChallenge(email: string, method: AuthMethod): void;
  onVerify(code: string): void;
}

export function AuthFlow({ state, onSendChallenge, onVerify }: AuthFlowProps) {
  if (state.status === "logged-out")
    return (
      <form
        onSubmit={(event) => {
          event.preventDefault();
          const data = new FormData(event.currentTarget);
          onSendChallenge(String(data.get("email") ?? ""), "email-code");
        }}
      >
        <label>
          Email{" "}
          <input name="email" type="email" autoComplete="email" required />
        </label>
        <button type="submit">Send mock code</button>
        <p>
          No password is requested or stored. This local mock sends nothing.
        </p>
      </form>
    );
  if (state.status === "challenge-sent")
    return (
      <form
        onSubmit={(event) => {
          event.preventDefault();
          onVerify(String(new FormData(event.currentTarget).get("code") ?? ""));
        }}
      >
        <p>
          Mock code prepared for {state.challenge.destinationHint}; no message
          was sent.
        </p>
        <label>
          Mock code{" "}
          <input
            name="code"
            inputMode="numeric"
            autoComplete="one-time-code"
            required
          />
        </label>
        <button type="submit">Verify locally</button>
      </form>
    );
  if (state.status === "expired" || state.status === "error")
    return (
      <p role="alert">
        {state.status === "expired"
          ? "The mock challenge expired."
          : state.message}
      </p>
    );
  return <p role="status">Mock account verified.</p>;
}
