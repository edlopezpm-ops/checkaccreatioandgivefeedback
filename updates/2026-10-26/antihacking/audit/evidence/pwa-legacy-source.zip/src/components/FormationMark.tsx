import brandMark from "../assets/accreatio-mark.svg";

interface FormationMarkProps {
  homeLabel?: string;
  tagline: string;
  onActivate?: () => void;
}

export function FormationMark({
  homeLabel,
  tagline,
  onActivate,
}: FormationMarkProps) {
  const contents = (
    <>
      <img src={brandMark} alt="" />
      <span>
        <strong>accreatio</strong>
        <small>{tagline}</small>
      </span>
    </>
  );

  return onActivate ? (
    <button
      type="button"
      className="formation-mark"
      onClick={onActivate}
      aria-label={homeLabel ?? "Go to accreatio home"}
    >
      {contents}
    </button>
  ) : (
    <div className="formation-mark" aria-label="accreatio">
      {contents}
    </div>
  );
}
