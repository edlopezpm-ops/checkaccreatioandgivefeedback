import { Check, Copy, Download, Rocket, Terminal } from "lucide-react";
import { updateProjectFlag } from "../../../shared/domain";
import type {
  ExecutionPreview,
  Locale,
  PlannedAction,
  ProjectDefinition,
} from "../../types";
import type { CreationStage, StageState } from "./StageNavigation";
import { ReviewManifest } from "./ReviewManifest";

interface ReviewStageProps {
  isWeb?: boolean;
  actions: PlannedAction[];
  copied: boolean;
  locale: Locale;
  onChange: (project: ProjectDefinition) => void;
  onConfirm: () => void;
  onCopy: () => void;
  onDownload: () => void;
  onStageChange: (stage: CreationStage) => void;
  preview: ExecutionPreview | null;
  project: ProjectDefinition;
  prompt: string;
  running: boolean;
  stageStates: Record<CreationStage, StageState>;
  valid: boolean;
}

const editableStages: CreationStage[] = [
  "foundation",
  "context",
  "team",
  "delivery",
];

export function ReviewStage({
  isWeb,
  actions,
  copied,
  locale,
  onChange,
  onConfirm,
  onCopy,
  onDownload,
  onStageChange,
  preview,
  project,
  prompt,
  running,
  stageStates,
  valid,
}: ReviewStageProps) {
  const es = locale === "es";
  const web = isWeb ?? preview?.host === "web";
  const phaseLabels = es
    ? {
        idea: "Idea inicial",
        "discovery-active": "Investigación en curso",
        "discovery-complete": "Idea definida",
      }
    : {
        idea: "Starting idea",
        "discovery-active": "Research in progress",
        "discovery-complete": "Defined idea",
      };
  const roleLabels = es
    ? {
        generalist: "Generalista",
        architect: "Arquitecto",
        implementer: "Implementador",
        auditor: "Auditor",
      }
    : {
        generalist: "Generalist",
        architect: "Architect",
        implementer: "Implementer",
        auditor: "Auditor",
      };
  const deliveryLabel = web
    ? es
      ? "Proyecto descargable en ZIP"
      : "Downloadable project ZIP"
    : project.action === "tracking"
      ? es
        ? "Seguimiento del proyecto"
        : "Project tracking"
      : project.action === "both"
        ? es
          ? "Carpeta de proyecto y seguimiento"
          : "Project folder and tracking"
        : es
          ? "Carpeta de proyecto local"
          : "Local project folder";
  const stageLabels: Record<CreationStage, string> = es
    ? {
        foundation: "Fundamentos",
        context: "Contexto",
        team: "Equipo",
        delivery: "Entrega",
        review: "Revisión",
      }
    : {
        foundation: "Foundation",
        context: "Context",
        team: "Team",
        delivery: "Delivery",
        review: "Review",
      };

  return (
    <div className="creation-stage review-stage" aria-labelledby="review-title">
      <header className="creation-stage__header">
        {!web && <p>{es ? "Etapa 5 de 5" : "Stage 5 of 5"}</p>}
        <h1 id="review-title">
          {es
            ? "Revisa el encargo de tu proyecto"
            : "Review your project brief"}
        </h1>
        <span>
          {es
            ? "Comprueba la idea, los límites, los archivos y las opciones elegidas. Puedes editar cada sección antes de crear el ZIP."
            : "Check the idea, constraints, files, and selected options. You can edit each section before creating the ZIP."}
        </span>
      </header>

      <div className="review-stage__status" role={!valid ? "alert" : undefined}>
        <strong>
          {valid
            ? es
              ? "Listo para confirmar"
              : "Ready to confirm"
            : es
              ? "Falta información"
              : "Information is missing"}
        </strong>
        <div>
          {editableStages
            .filter((stage) => !web || stage !== "delivery")
            .map((stage) => (
              <button
                type="button"
                key={stage}
                onClick={() => onStageChange(stage)}
                className={[
                  web && stage === "team" ? "review-stage__advanced" : "",
                  stageStates[stage] === "attention" ||
                  (!web && stageStates[stage] === "upcoming")
                    ? "needs-attention"
                    : "",
                ]
                  .filter(Boolean)
                  .join(" ")}
              >
                {web && stage === "team"
                  ? es
                    ? "Opciones avanzadas"
                    : "Advanced options"
                  : stageLabels[stage]}{" "}
                ·{" "}
                {stageStates[stage] === "attention" ||
                (!web && stageStates[stage] === "upcoming")
                  ? es
                    ? "revisar"
                    : "review"
                  : es
                    ? "editar"
                    : "edit"}
              </button>
            ))}
        </div>
      </div>

      <div className="review-overview">
        <div className="review-overview__project">
          <h2>
            {project.name || (es ? "Proyecto sin nombre" : "Unnamed project")}
          </h2>
          <span>{phaseLabels[project.phase]}</span>
          <h3>{es ? "Qué quieres crear" : "What you want to create"}</h3>
          <p className="review-overview__text">
            {project.context ||
              (es
                ? "Añade una descripción en Contexto."
                : "Add a description in Context.")}
          </p>
          <h3>{es ? "Límites del proyecto" : "Project constraints"}</h3>
          <p className="review-overview__text">
            {project.restrictions ||
              (es
                ? "No añadiste límites específicos."
                : "You have not added specific constraints.")}
          </p>
        </div>
        <dl>
          <div>
            <dt>{es ? "Roles planificados" : "Planned roles"}</dt>
            <dd>
              {project.participants
                .map((participant) => roleLabels[participant.role])
                .join(" · ")}
            </dd>
          </div>
          <div>
            <dt>{es ? "Ruta" : "Working approach"}</dt>
            <dd>
              {
                {
                  es: {
                    local: "Herramientas locales",
                    vendor: "Plataforma gestionada",
                    mixed: "Combinada",
                  },
                  en: {
                    local: "Local tools",
                    vendor: "Managed platform",
                    mixed: "Mixed",
                  },
                }[locale][project.route]
              }
            </dd>
          </div>
          <div>
            <dt>{es ? "Orquestación" : "Orchestration"}</dt>
            <dd>
              {project.orchestration.enabled
                ? es
                  ? "Activada; revisa la configuración antes de ejecutarla"
                  : "Enabled; check setup before running"
                : es
                  ? "Desactivada"
                  : "Disabled"}
            </dd>
          </div>
          <div>
            <dt>{es ? "Guías opcionales" : "Optional guides"}</dt>
            <dd>
              {[
                project.initializeGit && "Git",
                project.createRemote && "GitHub",
                project.openIde && "IDE",
              ]
                .filter(Boolean)
                .join(" · ") || (es ? "Ninguna" : "None")}
            </dd>
          </div>
          <div>
            <dt>{es ? "Entrega" : "Delivery"}</dt>
            <dd>{deliveryLabel}</dd>
          </div>
          <div>
            <dt>{es ? "Archivos adjuntos" : "Attached files"}</dt>
            <dd>
              {project.attachments.length
                ? es
                  ? `${project.attachments.length} archivo(s): ${project.attachments.map((file) => file.name).join(", ")}`
                  : `${project.attachments.length} file(s): ${project.attachments.map((file) => file.name).join(", ")}`
                : es
                  ? "Ninguno"
                  : "None"}
            </dd>
          </div>
        </dl>
      </div>

      <div className="review-details">
        <details id="review-manifest" className="review-details__item">
          <summary>
            {es ? "Archivos y límites de entrega" : "Files and delivery limits"}
          </summary>
          <ReviewManifest locale={locale} preview={preview} project={project} />
        </details>

        <details id="review-plan" className="review-plan review-details__item">
          <summary>
            {es
              ? "Cómo se preparará tu paquete"
              : "How your package will be prepared"}
          </summary>
          <h2 id="review-plan-title">
            {es ? "Plan determinista" : "Deterministic plan"}
          </h2>
          <ol>
            {actions.map((action) => (
              <li key={action.id}>
                <strong>{action.label}</strong>
                <code>{action.detail}</code>
                <p>{action.description}</p>
              </li>
            ))}
          </ol>
        </details>

        <details
          id="review-prompt"
          className="review-prompt review-details__item"
        >
          <summary>
            {es
              ? "Ver las instrucciones completas"
              : "View the complete instructions"}
          </summary>
          <div className="review-prompt__head">
            <h2 id="review-prompt-title">
              <Terminal aria-hidden="true" />{" "}
              {es ? "Prompt completo" : "Full prompt"}
            </h2>
            <div>
              <button type="button" onClick={onCopy}>
                {copied ? (
                  <Check aria-hidden="true" />
                ) : (
                  <Copy aria-hidden="true" />
                )}
                {copied ? (es ? "Copiado" : "Copied") : es ? "Copiar" : "Copy"}
              </button>
              <button type="button" onClick={onDownload}>
                <Download aria-hidden="true" />
                {es ? "Descargar .md" : "Download .md"}
              </button>
            </div>
          </div>
          <pre tabIndex={0}>{prompt}</pre>
        </details>
      </div>

      <div className="review-stage__confirm">
        {/* The safe-run choice belongs where its consequence lands. It used to
            live on Delivery, one screen away from the button it modifies, so
            the user decided the outcome before seeing what was at stake. */}
        <label className="review-stage__dry-run">
          <input
            type="checkbox"
            checked={project.dryRun}
            onChange={(event) =>
              onChange(
                updateProjectFlag(project, "dryRun", event.target.checked),
              )
            }
          />
          <span>
            <strong>
              {web
                ? es
                  ? "Comprobar el paquete sin descargar"
                  : "Check the package without downloading"
                : es
                  ? "Revisar sin escribir nada"
                  : "Review without writing"}
            </strong>
            <small>{es ? "Activado por defecto" : "On by default"}</small>
          </span>
        </label>
        <p>
          {project.dryRun
            ? es
              ? "Vista previa del paquete. No se creará ni descargará ningún ZIP."
              : "Package preview. No ZIP will be created or downloaded."
            : web
              ? es
                ? "Prepararemos un ZIP descargable después de tu confirmación final."
                : "We'll prepare a downloadable ZIP after your final confirmation."
              : es
                ? "Crearemos los archivos locales después de tu confirmación final."
                : "We'll create the local files after your final confirmation."}
        </p>
        <button
          type="button"
          className="start"
          disabled={!valid || running}
          onClick={onConfirm}
        >
          <Rocket aria-hidden="true" />
          {web
            ? project.dryRun
              ? es
                ? "Comprobar el paquete sin descargar"
                : "Check the package without downloading"
              : es
                ? "Crear y descargar ZIP"
                : "Create and download ZIP"
            : es
              ? "Revisar y confirmar"
              : "Review and confirm"}
          <small>
            {valid
              ? project.dryRun
                ? es
                  ? "Simulación sin crear archivos"
                  : "Preview without creating files"
                : web
                  ? es
                    ? "Revisar descarga ZIP"
                    : "Review ZIP download"
                  : es
                    ? "Revisar creación local"
                    : "Review local creation"
              : es
                ? "Corrige las etapas señaladas"
                : "Fix the indicated stages"}
          </small>
        </button>
      </div>
    </div>
  );
}
