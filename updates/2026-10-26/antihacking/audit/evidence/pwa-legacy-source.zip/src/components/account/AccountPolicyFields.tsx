import type { Locale } from "../../types";

export function AccountPolicyFields({ locale }: { locale: Locale }) {
  const es = locale === "es";
  return (
    <section
      className="web-signin__policy"
      aria-label={es ? "Tu cuenta y tus datos" : "Your account and data"}
    >
      <p id="account-policy-terms">
        {es ? "Al continuar, aceptas los " : "By continuing, you accept the "}
        <a href="/legal/terms" target="_blank" rel="noopener noreferrer">
          {es ? "Términos de AEKR" : "AEKR Terms"}
        </a>
        .
      </p>
      <p id="account-policy-data">
        {es
          ? "Al continuar, autorizas a AEKR a tratar tu identificador de acceso, correo, nombre y los datos mínimos de sesión y cuota necesarios para prestar y proteger tu cuenta, según la "
          : "By continuing, you authorize AEKR to process your sign-in identifier, email, name and minimal session and allowance records needed to provide and protect your account, as described in the "}
        <a href="/legal/privacy" target="_blank" rel="noopener noreferrer">
          {es ? "Política de privacidad" : "Privacy Policy"}
        </a>
        .
      </p>
      <p id="account-policy-scope">
        {es
          ? "Tus proyectos siguen en tu dispositivo. Puedes retirar esta autorización eliminando tu cuenta; los identificadores protegidos de cuota permanecen 48 horas. No autorizas publicidad ni analítica."
          : "Your projects stay on your device. You can withdraw this authorization by deleting your account; protected allowance identifiers remain for 48 hours. This does not authorize advertising or analytics."}
      </p>
      <a href="/legal/cookies" target="_blank" rel="noopener noreferrer">
        {es ? "Cookies y almacenamiento local" : "Cookies and local storage"}
      </a>
    </section>
  );
}
