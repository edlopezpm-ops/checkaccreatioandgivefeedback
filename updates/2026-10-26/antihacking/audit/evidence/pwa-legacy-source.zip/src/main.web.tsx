import { BlogExperience } from "./components/BlogExperience";
import { WebAccountBoundary } from "./components/account/WebAccountBoundary";
import { CookiePreferences } from "./components/account/CookiePreferences";
import type { ComponentProps } from "react";
import { mountApp } from "./main";
import type { AppExtraDestination } from "./App";
import "./styles.css";
import "./extras.css";
import "./responsive.css";
import "./polish.css";
import "./web-branding.css";

const blogDestination: AppExtraDestination = {
  id: "blog",
  labels: { es: "Blog", en: "Blog" },
  render: (context) => <BlogExperience {...context} />,
};

function WebExperienceBoundary(
  props: ComponentProps<typeof WebAccountBoundary>,
) {
  return (
    <>
      <WebAccountBoundary {...props} />
      <CookiePreferences locale={props.locale} />
    </>
  );
}

if (import.meta.env.PROD) {
  // Updates activate in the worker and appear on the next navigation. Native
  // registration adds no blocking dialog or automatic reload of an open draft.
  if ("serviceWorker" in navigator)
    window.addEventListener("load", () => {
      void navigator.serviceWorker.register("./sw.js").catch(() => {
        // The online app still works when browser policy disables installation.
      });
    });
}

mountApp({
  extraDestination: blogDestination,
  accountBoundary: WebExperienceBoundary,
});
