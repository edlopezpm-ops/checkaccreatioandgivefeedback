import { FileText, MapPin, Paperclip, TriangleAlert } from "lucide-react";
import type { ExecutionPreview, Locale, ProjectDefinition } from "../types";

interface ReviewManifestProps {
  locale: Locale;
  preview: ExecutionPreview | null;
  project: ProjectDefinition;
}

export function ReviewManifest({
  locale,
  preview,
  project,
}: ReviewManifestProps) {
  const es = locale === "es";
  const destinations =
    preview?.artifacts.filter(({ kind }) =>
      ["repository", "tracking", "zip"].includes(kind),
    ) ?? [];

  return (
    <section className="review-manifest" aria-labelledby="manifest-title">
      <h2 id="manifest-title">
        {es ? "Manifiesto de entrega" : "Delivery manifest"}
      </h2>
      <div className="review-manifest__grid">
        <article>
          <h3>
            <FileText aria-hidden="true" /> {es ? "Artefactos" : "Artifacts"}
          </h3>
          <strong>{preview?.artifacts.length ?? 0}</strong>
          <span>
            {preview?.headline ??
              (es
                ? "Completa las etapas anteriores"
                : "Complete the earlier stages")}
          </span>
        </article>
        <article>
          <h3>
            <MapPin aria-hidden="true" /> {es ? "Destino" : "Destination"}
          </h3>
          {destinations.length ? (
            destinations.map((artifact) => (
              <code key={`${artifact.kind}-${artifact.destination}`}>
                {artifact.destination}
              </code>
            ))
          ) : (
            <span>—</span>
          )}
        </article>
        <article>
          <h3>
            <Paperclip aria-hidden="true" />{" "}
            {es ? "Fuentes adjuntas" : "Attached sources"}
          </h3>
          <strong>{project.attachments.length}</strong>
          {project.attachments.length ? (
            <ul>
              {project.attachments.map((attachment, index) => (
                <li key={`${attachment.name}-${index}`}>{attachment.name}</li>
              ))}
            </ul>
          ) : (
            <span>{es ? "Sin fuentes adjuntas" : "No attached sources"}</span>
          )}
        </article>
        <article>
          <h3>
            <TriangleAlert aria-hidden="true" />{" "}
            {es ? "Límites" : "Limitations"}
          </h3>
          {preview?.limitations.length ? (
            <ul>
              {preview.limitations.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          ) : (
            <span>—</span>
          )}
        </article>
      </div>
    </section>
  );
}
