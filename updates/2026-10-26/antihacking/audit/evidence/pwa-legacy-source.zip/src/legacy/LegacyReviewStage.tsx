import { Check, Copy, Download, Rocket, Terminal } from "lucide-react";
import { updateProjectFlag } from "../../shared/domain";
import type {
  ExecutionPreview,
  Locale,
  PlannedAction,
  ProjectDefinition,
} from "../types";
import type {
  CreationStage,
  StageState,
} from "../components/creation/StageNavigation";
import { ReviewManifest } from "./LegacyReviewManifest";

interface ReviewStageProps {
  actions: PlannedAction[];
  copied: boolean;
  locale: Locale;
  onChange: (project: ProjectDefinition) => void;
  onConfirm: () => void;
  onCopy: () => void;
  onDownload: () => void;
  onStageChange: (stage: CreationStage) => void;
  preview: ExecutionPreview | null;
  project: ProjectDefinition;
  prompt: string;
  running: boolean;
  stageStates: Record<CreationStage, StageState>;
  valid: boolean;
}

const editableStages: CreationStage[] = [
  "foundation",
  "context",
  "team",
  "delivery",
];

export function ReviewStage({
  actions,
  copied,
  locale,
  onChange,
  onConfirm,
  onCopy,
  onDownload,
  onStageChange,
  preview,
  project,
  prompt,
  running,
  stageStates,
  valid,
}: ReviewStageProps) {
  const es = locale === "es";
  const stageLabels: Record<CreationStage, string> = es
    ? {
        foundation: "Fundamentos",
        context: "Contexto",
        team: "Equipo",
        delivery: "Entrega",
        review: "Revisión",
      }
    : {
        foundation: "Foundation",
        context: "Context",
        team: "Team",
        delivery: "Delivery",
        review: "Review",
      };

  return (
    <div className="creation-stage review-stage" aria-labelledby="review-title">
      <header className="creation-stage__header">
        <p>{es ? "Etapa 5 de 5" : "Stage 5 of 5"}</p>
        <h1 id="review-title">
          {es
            ? "Revisa el proyecto antes de confirmar"
            : "Review the project before confirming"}
        </h1>
        <span>
          {es
            ? "Este manifiesto es de solo lectura. Vuelve a cualquier etapa para cambiar la definición."
            : "This manifest is read-only. Return to any stage to change the definition."}
        </span>
      </header>

      <nav
        className="review-stage__sections"
        aria-label={es ? "Secciones de revisión" : "Review sections"}
      >
        <a href="#review-manifest">{es ? "Manifiesto" : "Manifest"}</a>
        <a href="#review-plan">{es ? "Plan" : "Plan"}</a>
        <a href="#review-prompt">Prompt</a>
      </nav>

      <div className="review-stage__status" role={!valid ? "alert" : undefined}>
        <strong>
          {valid
            ? es
              ? "Listo para confirmar"
              : "Ready to confirm"
            : es
              ? "Falta información"
              : "Information is missing"}
        </strong>
        <div>
          {editableStages.map((stage) => (
            <button
              type="button"
              key={stage}
              onClick={() => onStageChange(stage)}
              className={
                stageStates[stage] === "attention" ||
                stageStates[stage] === "upcoming"
                  ? "needs-attention"
                  : ""
              }
            >
              {stageLabels[stage]} ·{" "}
              {stageStates[stage] === "attention" ||
              stageStates[stage] === "upcoming"
                ? es
                  ? "revisar"
                  : "review"
                : es
                  ? "completa"
                  : "complete"}
            </button>
          ))}
        </div>
      </div>

      <div id="review-manifest">
        <ReviewManifest locale={locale} preview={preview} project={project} />
      </div>

      <section
        id="review-plan"
        className="review-plan"
        aria-labelledby="review-plan-title"
      >
        <h2 id="review-plan-title">
          {es ? "Plan determinista" : "Deterministic plan"}
        </h2>
        <ol>
          {actions.map((action) => (
            <li key={action.id}>
              <strong>{action.label}</strong>
              <code>{action.detail}</code>
              <p>{action.description}</p>
            </li>
          ))}
        </ol>
      </section>

      <section
        id="review-prompt"
        className="review-prompt"
        aria-labelledby="review-prompt-title"
      >
        <div className="review-prompt__head">
          <h2 id="review-prompt-title">
            <Terminal aria-hidden="true" />{" "}
            {es ? "Prompt completo" : "Full prompt"}
          </h2>
          <div>
            <button type="button" onClick={onCopy}>
              {copied ? (
                <Check aria-hidden="true" />
              ) : (
                <Copy aria-hidden="true" />
              )}
              {copied ? (es ? "Copiado" : "Copied") : es ? "Copiar" : "Copy"}
            </button>
            <button type="button" onClick={onDownload}>
              <Download aria-hidden="true" />
              {es ? "Descargar .md" : "Download .md"}
            </button>
          </div>
        </div>
        <pre tabIndex={0}>{prompt}</pre>
      </section>

      <div className="review-stage__confirm">
        {/* The safe-run choice belongs where its consequence lands. It used to
            live on Delivery, one screen away from the button it modifies, so
            the user decided the outcome before seeing what was at stake. */}
        <label className="review-stage__dry-run">
          <input
            type="checkbox"
            checked={project.dryRun}
            onChange={(event) =>
              onChange(
                updateProjectFlag(project, "dryRun", event.target.checked),
              )
            }
          />
          <span>
            <strong>
              {es ? "Revisar sin escribir nada" : "Review without writing"}
            </strong>
            <small>{es ? "Activado por defecto" : "On by default"}</small>
          </span>
        </label>
        <p>
          {project.dryRun
            ? es
              ? "Dry run: no se crearán archivos ni se solicitará una descarga."
              : "Dry run: no files will be created and no download will be requested."
            : preview?.headline}
        </p>
        <button
          type="button"
          className="start"
          disabled={!valid || running}
          onClick={onConfirm}
        >
          <Rocket aria-hidden="true" />
          {es ? "Confirmar consecuencias" : "Confirm consequences"}
          <small>
            {valid
              ? es
                ? "Ver confirmación exacta"
                : "View exact confirmation"
              : es
                ? "Corrige las etapas señaladas"
                : "Fix the indicated stages"}
          </small>
        </button>
      </div>
    </div>
  );
}
