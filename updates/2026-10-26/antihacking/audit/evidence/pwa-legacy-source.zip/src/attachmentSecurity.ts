import {
  ATTACHMENT_INPUT_LIMIT,
  AttachmentSecurityError,
  attachmentExtension,
  type AttachmentRejectionCode,
} from "./attachmentSecurityTypes";

export { AttachmentSecurityError } from "./attachmentSecurityTypes";
export type { AttachmentRejectionCode } from "./attachmentSecurityTypes";
const prepared = new WeakMap<Blob, string>();

/** Successful admission belongs to this immutable reconstructed Blob and exact
 * selected filename. JSON metadata, a new Blob, and caller flags cannot attest it. */
export function assertPreparedAttachment(blob: Blob, filename: string): void {
  if (prepared.get(blob) !== filename)
    throw new AttachmentSecurityError("unprepared");
}

export async function prepareAttachment(
  blob: Blob,
  filename: string,
): Promise<Blob> {
  attachmentExtension(filename);
  if (
    !(blob instanceof Blob) ||
    blob.size < 1 ||
    blob.size > ATTACHMENT_INPUT_LIMIT
  )
    throw new AttachmentSecurityError("tooLarge");
  if (prepared.get(blob) === filename) return blob;
  let clean: Blob;
  if (typeof window === "undefined") {
    // Native Node tests run the same parser. The shipped browser always uses
    // a disposable worker so slow/malformed input cannot freeze its UI thread.
    const { prepareAttachmentBytes } = await import("./attachmentSecurityCore");
    clean = await prepareAttachmentBytes(blob, filename);
  } else {
    if (typeof Worker !== "function")
      throw new AttachmentSecurityError("unavailable");
    clean = await new Promise<Blob>((resolve, reject) => {
      const worker = new Worker(
        new URL("./attachmentSecurityWorker.ts", import.meta.url),
        { type: "module" },
      );
      const finish = () => {
        clearTimeout(timer);
        worker.terminate();
      };
      const timer = setTimeout(() => {
        finish();
        reject(new AttachmentSecurityError("timeout"));
      }, 10_000);
      worker.onmessage = (
        event: MessageEvent<{ blob?: Blob; code?: AttachmentRejectionCode }>,
      ) => {
        finish();
        if (event.data.blob instanceof Blob) resolve(event.data.blob);
        else
          reject(new AttachmentSecurityError(event.data.code ?? "malformed"));
      };
      worker.onerror = () => {
        finish();
        reject(new AttachmentSecurityError("unavailable"));
      };
      worker.postMessage({ blob, filename });
    });
  }
  if (clean.size < 1 || clean.size > ATTACHMENT_INPUT_LIMIT)
    throw new AttachmentSecurityError("tooLarge");
  prepared.set(clean, filename);
  return clean;
}
