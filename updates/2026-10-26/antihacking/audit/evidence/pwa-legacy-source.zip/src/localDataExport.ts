import type { ProjectDefinition, Settings, WebAttachment } from "./types";
import { assertPreparedAttachment } from "./attachmentSecurity";
import { resolveWebAttachments, type ExportEntry } from "./webExport";
import { assertArchivePaths } from "../shared/inputValidation";

/** A rights/download output, independent of project validity, account quota,
 * optional collection, or commercial Terms. No request leaves the browser. */
export function buildLocalDataExport(
  project: ProjectDefinition | null,
  settings: Settings,
  attachments: readonly WebAttachment[],
  missingFiles = 0,
  now = new Date().toISOString(),
): ExportEntry[] {
  const root = "accreatio-local-data";
  const entries: ExportEntry[] = [];
  const limitations = [
    "This device and currently accessible browser draft only. No other account, device, downloaded ZIP history, or server account data is included.",
    "IndexedDB and its recovery journal store draft fields, not attachment bytes. A closed tab's memory-only attachments cannot be recovered.",
    "JSON is UTF-8 data; no CSV formulas or executable scripts are generated. Do not treat user-authored strings as instructions or execute them.",
  ];
  const add = (name: string, value: unknown) =>
    entries.push({
      path: `${root}/${name}`,
      input: JSON.stringify(value, null, 2),
      kind: "generated",
    });
  add("preferences.json", { locale: settings.locale, theme: settings.theme });
  if (project) {
    add("project.json", project);
    for (const item of resolveWebAttachments(attachments, root)) {
      assertPreparedAttachment(item.source.blob, item.source.name);
      entries.push({
        path: `${root}/attachments/${item.archiveName}`,
        input: item.source.blob,
        kind: "attachment",
      });
    }
  } else
    limitations.push(
      "No currently verified local project context is available; sign in with the draft owner through the normal service to restore it. No other-account storage is read.",
    );
  if (missingFiles)
    limitations.push(
      `${missingFiles} previously selected attachment(s) are unavailable in this tab; reselect the originals to include them.`,
    );
  add("manifest.json", {
    product: "accreatio",
    preparedAt: now,
    scope:
      "Local personal draft download, not a project execution or complete account access response",
    included: [...entries.map((e) => e.path), `${root}/manifest.json`],
    missingAttachmentCount: missingFiles,
    limitations,
  });
  assertArchivePaths(
    entries.map((e) => e.path),
    root,
  );
  return entries;
}
