import { mountApp } from "./main";
import "./styles.css";
import "./extras.css";
import "./responsive.css";
import "./polish.css";

mountApp();
