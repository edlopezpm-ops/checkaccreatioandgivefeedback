import type {
  Action,
  Attachment,
  AttachmentMetadata,
  Locale,
  ProjectDefinition,
  Settings,
} from "../shared/domain";
import type { ProviderAvailability } from "../shared/providerRegistry";
export type {
  Action,
  Attachment,
  AttachmentMetadata,
  CanonicalRole,
  Locale,
  OrchestrationConfig,
  FundingPolicy,
  OrchestrationProvider,
  OrchestrationParticipantConfig,
  Phase,
  PreferredIde,
  ProjectDefinition,
  ParticipantId,
  ParticipantInstance,
  Route,
  Settings,
} from "../shared/domain";
export type {
  ApiFunding,
  CurrencyCode,
  FundingReasonCode,
  SubscriptionCliFunding,
} from "../shared/funding";
export type {
  DesktopCliDetection,
  FixedCliProbe,
  ProbeResult,
  ProviderAvailability,
  ProviderAvailabilityReason,
  ProviderAvailabilityResult,
  ProviderAvailabilityState,
  ApiModelProfileDescriptor,
  ProviderCapability,
  ProviderDescriptor,
  ProviderEligibility,
  ProviderId,
} from "../shared/providerRegistry";
export { defaultOrchestration } from "../shared/domain";
export type {
  AccountFeatureConfig,
  AccountProfile,
  AccountProvider,
  AccountState,
  AuthChallenge,
  AuthErrorCode,
  AuthMethod,
  DataRequest,
} from "./account/contracts";
export interface PlannedAction {
  id: string;
  label: string;
  detail: string;
  description: string;
  kind: "filesystem" | "template" | "git" | "github" | "output" | "ide";
  mutates: boolean;
}
export type ExecutionHost = "desktop" | "web";
export interface PlannedArtifact {
  kind:
    | "repository"
    | "tracking"
    | "generated-file"
    | "attachment"
    | "zip"
    | "zip-entry";
  displayName: string;
  destination: string;
  certainty: "planned";
}
export interface ExecutionPreview {
  host: ExecutionHost;
  dryRun: boolean;
  action: Action;
  headline: string;
  artifacts: PlannedArtifact[];
  limitations: string[];
}
export type ExecutionOutcome = "dry-run" | "success" | "partial" | "failure";
export type ExecutionStepStatus = "completed" | "failed" | "skipped";
export interface ArtifactEvidence {
  kind:
    | "repository-root"
    | "tracking-file"
    | "generated-file"
    | "attachment"
    | "zip"
    | "zip-entry"
    | "git-repository"
    | "github-remote"
    | "ide-launch";
  location: string;
  displayName: string;
}
export interface ExecutionStepResult {
  id: string;
  status: ExecutionStepStatus;
  summary: string;
  artifacts: ArtifactEvidence[];
  error?: string;
}
export interface WebDeliveryEvidence {
  state: "not-requested" | "download-requested";
  filename: string;
  manifest: string[];
  browserPersistenceVerified: false;
}
export interface ExecutionResult {
  operationId: string;
  ok: boolean;
  dryRun: boolean;
  projectPath?: string;
  completed: string[];
  logs: string[];
  error?: string;
  outcome: ExecutionOutcome;
  steps: ExecutionStepResult[];
  artifacts: ArtifactEvidence[];
  webDelivery?: WebDeliveryEvidence;
}
export interface ExecutionRequest {
  operationId: string;
  definition: ProjectDefinition;
  settings: Settings;
  webAttachments?: readonly WebAttachment[];
}
export interface GithubStatus {
  installed: boolean;
  authenticated: boolean;
  login?: string;
  error?: string;
}
export interface HistoryEntry {
  id: string;
  name: string;
  path: string;
  createdAt: string;
  action: Action;
  remote?: string;
}
export type WebAttachment = AttachmentMetadata & {
  id: string;
  blob: Blob;
};
export type OrchestrationDecision =
  | "approve"
  | "reject"
  | "changes-requested"
  | "pause"
  | "escalate"
  | "terminate";
export type OrchestrationLifecycle =
  | "RUNNING"
  | "WAITING_HUMAN_APPROVAL"
  | "PAUSED"
  | "BLOCKED"
  | "TIMED_OUT"
  | "FAILED"
  | "CANCELLED"
  | "COMPLETED";
export interface OrchestrationAttemptSnapshot {
  attempt_id: string;
  step_index: number;
  phase:
    | "WAITING_EXECUTION_APPROVAL"
    | "IN_FLIGHT"
    | "WAITING_RESULT_APPROVAL"
    | "RESULT_BLOCKED";
  action_id?: string | null;
  action_digest?: string | null;
  result_status?: string | null;
  result_summary?: string | null;
}
export interface OrchestrationRunSnapshot {
  schema_version: 2;
  run_id: string;
  project_name: string;
  lifecycle: OrchestrationLifecycle;
  revision: number;
  current_step_index: number;
  active_attempt: OrchestrationAttemptSnapshot | null;
  correlation_id: string;
  work_session_id: string;
}
export interface OrchestrationLaunchRequest {
  toolkitDir: string;
  projectDir: string;
  configPath: string;
  newWorkSession?: boolean;
  retryInFlight?: boolean;
}
export interface OrchestrationPreflightResult {
  toolkitDir: string;
  projectDir: string;
  configPath: string;
  statePath: string;
  logPath: string;
}
export interface Bridge {
  chooseFolder(): Promise<string | null>;
  chooseAttachments(): Promise<WebAttachment[] | Attachment[]>;
  loadSettings(): Promise<Settings>;
  saveSettings(s: Settings): Promise<void>;
  githubStatus(): Promise<GithubStatus>;
  connectGithub(): Promise<void>;
  loadHistory(): Promise<HistoryEntry[]>;
  execute(request: ExecutionRequest): Promise<ExecutionResult>;
  checkProviders(): Promise<ProviderAvailability>;
  orchestrationPreflight(
    request: OrchestrationLaunchRequest,
  ): Promise<OrchestrationPreflightResult>;
  orchestrationStart(
    request: OrchestrationLaunchRequest,
  ): Promise<OrchestrationPreflightResult>;
  orchestrationSnapshot(): Promise<OrchestrationRunSnapshot | null>;
  orchestrationDecide(decision: OrchestrationDecision): Promise<void>;
  orchestrationCancel(): Promise<void>;
  readonly kind: "electron" | "web";
}
export interface accreatioApi {
  chooseFolder(): Promise<string | null>;
  chooseAttachments(): Promise<Attachment[]>;
  loadSettings(): Promise<Settings>;
  saveSettings(settings: Settings): Promise<void>;
  githubStatus(): Promise<GithubStatus>;
  connectGithub(): Promise<void>;
  loadHistory(): Promise<HistoryEntry[]>;
  execute(request: ExecutionRequest): Promise<ExecutionResult>;
  checkProviders(): Promise<ProviderAvailability>;
  orchestrationPreflight(
    request: OrchestrationLaunchRequest,
  ): Promise<OrchestrationPreflightResult>;
  orchestrationStart(
    request: OrchestrationLaunchRequest,
  ): Promise<OrchestrationPreflightResult>;
  orchestrationSnapshot(): Promise<OrchestrationRunSnapshot | null>;
  orchestrationDecide(decision: OrchestrationDecision): Promise<void>;
  orchestrationCancel(): Promise<void>;
}
declare global {
  interface Window {
    accreatio?: accreatioApi;
  }
}
