import {
  ACCOUNT_POLICY,
  type AccountPolicyAuthorization,
} from "../../shared/accountPolicy";
import type {
  GoogleAuthTransaction,
  WebAuthMethods,
  WebAuthTransactionStatus,
  WebIdentityProvider,
  WebVerificationAction,
} from "./contracts";

export interface AccountAvailability {
  remaining: number;
  nextAvailableAt: string | null;
}
export interface WebAccountContext {
  ownerKey: string;
  sessionKey: string;
}
export interface WebAccount extends AccountAvailability, WebAccountContext {
  email: string;
  displayName: string;
  expiresAt: string;
  policyAuthorizationRequired: boolean;
  connectedProviders?: readonly WebIdentityProvider[];
}

export function accountPolicyAuthorization(choices: {
  accountDataAuthorized: boolean;
  termsAccepted: boolean;
}): AccountPolicyAuthorization {
  return { ...ACCOUNT_POLICY, ...choices };
}
export interface EmailChallenge {
  challengeId: string;
  expiresAt: string;
  resendAt: string;
}
export class AccountError extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly availability?: AccountAvailability,
    readonly retryAfter?: number,
  ) {
    super(message);
  }
}
function availability(
  value: Record<string, unknown>,
): AccountAvailability | undefined {
  if (
    !Number.isInteger(value.remaining) ||
    (value.remaining as number) < 0 ||
    (value.remaining as number) > 5 ||
    !(
      value.nextAvailableAt === null ||
      (typeof value.nextAvailableAt === "string" &&
        Number.isFinite(Date.parse(value.nextAvailableAt)))
    )
  )
    return undefined;
  return {
    remaining: value.remaining as number,
    nextAvailableAt: value.nextAvailableAt as string | null,
  };
}
async function call(action: string, method: "GET" | "POST", body?: unknown) {
  return callApi(
    `/api/account/${action}`,
    method,
    body,
    action === "authorize",
  );
}
async function callApi(
  path: string,
  method: "GET" | "POST",
  body?: unknown,
  authorizing = false,
  rightsOnly = false,
  rightsTransactionId?: string,
) {
  const response = await fetch(path, {
    method,
    credentials: "same-origin",
    cache: "no-store",
    // Account APIs never navigate. Reject unexpected redirects at the boundary.
    redirect: "manual",
    headers: {
      "Content-Type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      ...(rightsOnly ? { "X-Accreatio-Rights": "1" } : {}),
      ...(rightsTransactionId
        ? { "X-Accreatio-Rights-Transaction": rightsTransactionId }
        : {}),
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    signal: AbortSignal.timeout(15_000),
  }).catch(() => {
    throw new AccountError(
      "unreachable",
      "Reconnect or sign in again. Your draft is still here.",
    );
  });
  if (
    response.type === "opaqueredirect" ||
    (response.status >= 300 && response.status < 400) ||
    !response.headers.get("Content-Type")?.includes("application/json")
  ) {
    if (authorizing)
      window.dispatchEvent(new Event("accreatio:session-invalid"));
    throw new AccountError(
      "sign_in_required",
      "Sign in with your email to continue.",
    );
  }
  const parsed: unknown = await response.json().catch(() => {
    throw new AccountError("unavailable", "Account service is unavailable.");
  });
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed))
    throw new AccountError("unavailable", "Account service is unavailable.");
  const value = parsed as Record<string, unknown>;
  if (!response.ok) {
    const error = value.error as
      { code?: string; message?: string; retryAfter?: number } | undefined;
    if (
      authorizing &&
      (response.status === 401 || error?.code === "account_suspended")
    )
      window.dispatchEvent(new Event("accreatio:session-invalid"));
    const header = response.headers.get("Retry-After")?.trim();
    const headerSeconds = header
      ? /^\d+$/.test(header)
        ? Number(header)
        : Math.ceil((Date.parse(header) - Date.now()) / 1000)
      : NaN;
    const retryAfter =
      typeof error?.retryAfter === "number" &&
      Number.isFinite(error.retryAfter) &&
      error.retryAfter >= 0
        ? error.retryAfter
        : headerSeconds;
    throw new AccountError(
      error?.code ?? "unavailable",
      error?.message ?? "Account service is unavailable.",
      availability(value),
      Number.isFinite(retryAfter) && retryAfter >= 0
        ? Math.min(86400, Math.ceil(retryAfter))
        : undefined,
    );
  }
  return value;
}

export async function loadWebAuthMethods(): Promise<WebAuthMethods> {
  const value = await callApi("/api/auth/v1/methods", "GET");
  const methods = value.methods as WebAuthMethods["methods"] | undefined;
  if (
    value.version !== "auth.v1" ||
    typeof methods?.google?.available !== "boolean" ||
    typeof methods?.emailOtp?.available !== "boolean"
  )
    throw new AccountError("unavailable", "Sign-in methods are unavailable.");
  return {
    version: "auth.v1",
    methods: {
      google: { available: methods.google.available },
      github: { available: methods.github?.available === true },
      emailOtp: { available: methods.emailOtp.available },
    },
  };
}

function validTransactionId(value: unknown): value is string {
  return typeof value === "string" && /^[A-Za-z0-9_-]{16,128}$/.test(value);
}

export async function startGoogleSignIn(
  mode: "popup" | "redirect",
  policyAuthorization?: AccountPolicyAuthorization,
  accountAccess = false,
): Promise<GoogleAuthTransaction> {
  return startProviderSignIn("google", mode, {
    purpose: accountAccess ? "account_access" : "sign_in",
    policyAuthorization,
    ...(accountAccess ? { verificationAction: "data" as const } : {}),
  });
}
export async function startProviderSignIn(
  provider: WebIdentityProvider,
  mode: "popup" | "redirect",
  options: {
    purpose: "sign_in" | "account_access" | "link_provider";
    policyAuthorization?: AccountPolicyAuthorization;
    verificationAction?: WebVerificationAction;
    rightsOnly?: boolean;
  },
): Promise<GoogleAuthTransaction> {
  if (provider !== "google" && provider !== "github")
    throw new AccountError(
      "unavailable",
      "Choose an available sign-in method.",
    );
  if (
    options.rightsOnly &&
    (options.purpose !== "account_access" ||
      (options.verificationAction !== "data" &&
        options.verificationAction !== "delete") ||
      options.policyAuthorization !== undefined)
  )
    throw new AccountError(
      "rights_action_required",
      "Choose account data or deletion.",
    );
  const value = await callApi(
    `/api/auth/v1/${options.rightsOnly ? "rights" : "oidc"}/${provider}/start`,
    "POST",
    {
      purpose: options.purpose,
      returnRoute: "builder",
      mode,
      ...(options.rightsOnly ? { rightsOnly: true } : {}),
      ...(options.purpose === "sign_in"
        ? { policyAuthorization: options.policyAuthorization }
        : {}),
      ...(options.verificationAction
        ? { verificationAction: options.verificationAction }
        : {}),
    },
  );
  let authorizationUrl: URL;
  try {
    authorizationUrl = new URL(String(value.authorizationUrl));
  } catch {
    throw new AccountError("unavailable", "Sign-in could not be started.");
  }
  if (
    !validTransactionId(value.transactionId) ||
    typeof value.expiresAt !== "string" ||
    !Number.isFinite(Date.parse(value.expiresAt)) ||
    authorizationUrl.origin !==
      (provider === "github"
        ? "https://github.com"
        : "https://accounts.google.com") ||
    authorizationUrl.pathname !==
      (provider === "github"
        ? "/login/oauth/authorize"
        : "/o/oauth2/v2/auth") ||
    authorizationUrl.username ||
    authorizationUrl.password ||
    authorizationUrl.hash
  )
    throw new AccountError("unavailable", "Sign-in could not be started.");
  return {
    transactionId: value.transactionId,
    authorizationUrl: authorizationUrl.href,
    expiresAt: value.expiresAt,
  };
}

export async function loadGoogleSignInStatus(
  transactionId: string,
): Promise<WebAuthTransactionStatus> {
  if (!validTransactionId(transactionId))
    throw new AccountError("unavailable", "Sign-in status is unavailable.");
  const value = await callApi(
    `/api/auth/v1/transactions/${transactionId}/status`,
    "GET",
  );
  if (
    value.status !== "pending" &&
    value.status !== "completed" &&
    value.status !== "failed" &&
    value.status !== "expired"
  )
    throw new AccountError("unavailable", "Sign-in status is unavailable.");
  if (value.status === "failed" && typeof value.errorCode === "string")
    throw new AccountError(value.errorCode, "Sign-in could not be completed.");
  return value.status;
}

export async function cancelGoogleSignIn(
  transactionId: string,
): Promise<Exclude<WebAuthTransactionStatus, "pending">> {
  if (!validTransactionId(transactionId))
    throw new AccountError(
      "unavailable",
      "Sign-in cancellation is unavailable.",
    );
  const value = await callApi(
    `/api/auth/v1/transactions/${transactionId}/cancel`,
    "POST",
    {},
  );
  if (
    value.status !== "completed" &&
    value.status !== "failed" &&
    value.status !== "expired"
  )
    throw new AccountError(
      "unavailable",
      "Sign-in cancellation is unavailable.",
    );
  return value.status;
}
function localWorkKey(value: unknown): value is string {
  return (
    typeof value === "string" &&
    value.length === 67 &&
    /^v1:[a-f0-9]{64}$/.test(value)
  );
}
function account(value: Record<string, unknown>): WebAccount {
  const quota = availability(value);
  if (
    !quota ||
    !localWorkKey(value.ownerKey) ||
    !localWorkKey(value.sessionKey) ||
    (value.connectedProviders !== undefined &&
      (!Array.isArray(value.connectedProviders) ||
        value.connectedProviders.some(
          (provider) => provider !== "google" && provider !== "github",
        ) ||
        new Set(value.connectedProviders).size !==
          value.connectedProviders.length)) ||
    typeof value.email !== "string" ||
    typeof value.expiresAt !== "string" ||
    !Number.isFinite(Date.parse(value.expiresAt)) ||
    (value.displayName !== undefined &&
      (typeof value.displayName !== "string" ||
        value.displayName.trim().length === 0 ||
        Array.from(value.displayName).length > 120 ||
        new TextEncoder().encode(value.displayName).length > 512 ||
        /[\p{Cc}\p{Cf}\p{Cs}]/u.test(value.displayName)))
  )
    throw new AccountError("unavailable", "Account service is unavailable.");
  return {
    ownerKey: value.ownerKey,
    sessionKey: value.sessionKey,
    email: value.email,
    displayName:
      typeof value.displayName === "string"
        ? value.displayName
        : value.email.split("@")[0] || "Account",
    expiresAt: value.expiresAt,
    policyAuthorizationRequired: value.policyAuthorizationRequired !== false,
    ...(Array.isArray(value.connectedProviders)
      ? {
          connectedProviders: value.connectedProviders as WebIdentityProvider[],
        }
      : {}),
    ...quota,
  };
}
export async function loadWebAccount(): Promise<WebAccount> {
  return account(await call("session", "GET"));
}
export async function requestEmailCode(
  email: string,
  policyAuthorization: AccountPolicyAuthorization,
): Promise<EmailChallenge> {
  const value = await call("otp/request", "POST", {
    email: email.trim(),
    policyAuthorization,
  });
  if (
    typeof value.challengeId !== "string" ||
    !value.challengeId ||
    typeof value.expiresAt !== "string" ||
    !Number.isFinite(Date.parse(value.expiresAt)) ||
    typeof value.resendAt !== "string" ||
    !Number.isFinite(Date.parse(value.resendAt))
  )
    throw new AccountError(
      "unavailable",
      "The email code could not be requested.",
    );
  return {
    challengeId: value.challengeId,
    expiresAt: value.expiresAt,
    resendAt: value.resendAt,
  };
}
export async function verifyEmailCode(
  challengeId: string,
  code: string,
): Promise<WebAccount> {
  return account(await call("otp/verify", "POST", { challengeId, code }));
}
export async function canUseWebBlog(): Promise<boolean> {
  try {
    const response = await fetch("/api/admin/blog/session", {
      credentials: "same-origin",
      cache: "no-store",
      redirect: "error",
      headers: {
        Accept: "application/json",
        "X-Requested-With": "XMLHttpRequest",
      },
      signal: AbortSignal.timeout(15_000),
    });
    if (!response.ok) return false;
    const value = await response.json();
    return (
      value?.canPublish === true &&
      (value.actor?.kind === "human" || value.actor?.kind === "agent") &&
      typeof value.actor?.label === "string"
    );
  } catch {
    return false;
  }
}
export async function authorizeWebExport(
  operationId: string,
  expected: WebAccountContext,
) {
  try {
    if (
      !localWorkKey(expected?.ownerKey) ||
      !localWorkKey(expected?.sessionKey)
    )
      throw new AccountError(
        "sign_in_required",
        "Sign in before exporting this ZIP.",
      );
    const value = await call("authorize", "POST", {
      operationId,
      ownerKey: expected.ownerKey,
      sessionKey: expected.sessionKey,
    });
    const quota = availability(value);
    if (!quota || value.operationId !== operationId)
      throw new AccountError(
        "invalid_receipt",
        "The export receipt could not be verified. Retry this ZIP.",
      );
    window.dispatchEvent(
      new CustomEvent("accreatio:quota", {
        detail: {
          ...quota,
          ownerKey: expected.ownerKey,
          sessionKey: expected.sessionKey,
        },
      }),
    );
    if (
      typeof value.issuedAt === "string" &&
      typeof value.retryExpiresAt === "string" &&
      Number.isFinite(Date.parse(value.issuedAt)) &&
      Date.parse(value.retryExpiresAt) ===
        Date.parse(value.issuedAt) + 172_800_000
    )
      return { issuedAt: value.issuedAt, retryExpiresAt: value.retryExpiresAt };
  } catch (error) {
    if (
      error instanceof AccountError &&
      error.code === "account_context_changed"
    )
      window.dispatchEvent(new Event("accreatio:account-recheck"));
    if (
      error instanceof AccountError &&
      error.code === "policy_authorization_required"
    )
      window.dispatchEvent(new Event("accreatio:policy-required"));
    if (error instanceof AccountError && error.availability)
      window.dispatchEvent(
        new CustomEvent("accreatio:quota", {
          detail: {
            ...error.availability,
            ownerKey: expected.ownerKey,
            sessionKey: expected.sessionKey,
          },
        }),
      );
    throw error;
  }
}
export async function closeWebAccount(remove = false) {
  await call(remove ? "delete" : "logout", "POST");
}
export async function loadWebAccountData(): Promise<Record<string, unknown>> {
  return call("data", "GET");
}

// These routes use only the separate HttpOnly rights proof. They never load,
// adopt, sign out or publish events for the ordinary product session.
function requireRightsTransaction(transactionId: string): string {
  if (
    !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(
      transactionId,
    )
  )
    throw new AccountError(
      "rights_context_changed",
      "Verify this account again before continuing.",
    );
  return transactionId;
}
export async function loadWebRightsData(
  transactionId: string,
): Promise<Record<string, unknown>> {
  return callApi(
    "/api/account/data",
    "GET",
    undefined,
    false,
    true,
    requireRightsTransaction(transactionId),
  );
}
export async function deleteWebRightsAccount(
  transactionId: string,
): Promise<void> {
  await callApi(
    "/api/account/delete",
    "POST",
    undefined,
    false,
    true,
    requireRightsTransaction(transactionId),
  );
}

export async function saveWebAccountPolicy(
  policyAuthorization: AccountPolicyAuthorization,
): Promise<WebAccount> {
  return account(await call("policy", "POST", policyAuthorization));
}
