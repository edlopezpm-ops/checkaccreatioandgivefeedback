import {
  readCookiePreference,
  type PreferenceStorage,
} from "./cookiePreferences";
import {
  COLLECTION_RETENTION_MS,
  COLLECTION_VERSION,
  parseCollectionRecord,
  type CollectionPurpose,
  type ResearchAnswers,
  type UsageRecord,
} from "../../shared/collection";
export const LOCAL_COLLECTION_KEY = "accreatio:optional-data:v1";
const key = (purpose: CollectionPurpose) =>
  `accreatio:collect-capability:${purpose}:v1`;
const revokeKey = (purpose: CollectionPurpose) =>
  `accreatio:withdrawal:${purpose}:v1`;
type Capability = { token: string; expiresAt: number; version: string };
type CapabilityEntry = Capability & {
  state: "granting" | "active" | "pending";
  boundary: string;
};
type CollectionStorage = PreferenceStorage & Pick<Storage, "length" | "key">;
const prefix = (purpose: CollectionPurpose) =>
  `accreatio:collect-capability:${purpose}:v2:`;
const entryKey = (purpose: CollectionPurpose, token: string) =>
  `${prefix(purpose)}${token}`;
const boundaryKey = (purpose: CollectionPurpose) =>
  `accreatio:collection-boundary:${purpose}:v1`;
// Never overwrite a shared singleton or forget a failed server revocation.
// Per-capability keys make fallback races lossless even without Web Locks.
const unresolved = new Map<
  string,
  { purpose: CollectionPurpose; entry: CapabilityEntry }
>();
let generation = 0;
const pending = new Set<AbortController>();
const grants = new Map<CollectionPurpose, Promise<Capability>>();
export function browserStorage(): CollectionStorage | null {
  try {
    return localStorage;
  } catch {
    return null;
  }
}
export function restrictiveSignal() {
  return (
    typeof navigator !== "undefined" &&
    (navigator as Navigator & { globalPrivacyControl?: boolean })
      .globalPrivacyControl === true
  );
}
function validCapability(value: unknown): value is Capability {
  if (!value || typeof value !== "object") return false;
  const v = value as Capability;
  return (
    typeof v.token === "string" &&
    /^[0-9a-f]{64}$/.test(v.token) &&
    typeof v.version === "string" &&
    v.version.length > 0 &&
    v.version.length <= 100 &&
    Number.isSafeInteger(v.expiresAt) &&
    v.expiresAt > Date.now()
  );
}
function boundary(purpose: CollectionPurpose) {
  return browserStorage()?.getItem(boundaryKey(purpose)) ?? "";
}
function remember(purpose: CollectionPurpose, entry: CapabilityEntry) {
  const name = entryKey(purpose, entry.token);
  // If persistence itself fails, retain the capability in this tab and report
  // withdrawal pending. No record may be sent from that failed grant.
  unresolved.set(name, { purpose, entry });
  const s = browserStorage();
  if (!s) throw Error("collection_storage");
  s.setItem(name, JSON.stringify(entry));
  if (s.getItem(name) !== JSON.stringify(entry))
    throw Error("collection_storage");
  unresolved.delete(name);
}
function entries(purpose: CollectionPurpose): CapabilityEntry[] {
  const s = browserStorage(),
    found = new Map<string, CapabilityEntry>();
  if (s) {
    // Snapshot names before cleanup; Storage.key ordering is not defined.
    const names = Array.from({ length: s.length }, (_, i) => s.key(i)).filter(
      (v): v is string => Boolean(v),
    );
    for (const name of names) {
      if (!name.startsWith(prefix(purpose))) continue;
      try {
        const value = JSON.parse(s.getItem(name) ?? "null") as CapabilityEntry;
        if (!validCapability(value)) {
          s.removeItem(name);
          continue;
        }
        if (
          !["active", "pending", "granting"].includes(value.state) ||
          typeof value.boundary !== "string" ||
          name !== entryKey(purpose, value.token)
        )
          continue;
        found.set(
          value.token,
          value.version === COLLECTION_VERSION
            ? value
            : { ...value, state: "pending" },
        );
      } catch {
        /* Malformed storage grants no permission. */
      }
    }
    // Preserve every legacy active/pending singleton during the upgrade.
    for (const [name, state] of [
      [key(purpose), "active"],
      [revokeKey(purpose), "pending"],
    ] as const) {
      try {
        const value = JSON.parse(s.getItem(name) ?? "null");
        if (value !== null && !validCapability(value)) {
          s.removeItem(name);
          continue;
        }
        if (validCapability(value) && !found.has(value.token))
          found.set(value.token, {
            ...value,
            state:
              boundary(purpose) || value.version !== COLLECTION_VERSION
                ? "pending"
                : state,
            boundary: boundary(purpose),
          });
      } catch {}
    }
  }
  for (const [name, value] of unresolved) {
    if (!validCapability(value.entry)) {
      unresolved.delete(name);
      continue;
    }
    if (value.purpose === purpose) found.set(value.entry.token, value.entry);
  }
  return [...found.values()].sort((a, b) => a.token.localeCompare(b.token));
}
function capability(purpose: CollectionPurpose) {
  try {
    return (
      entries(purpose).find(
        (v) =>
          v.state === "active" &&
          v.version === COLLECTION_VERSION &&
          v.boundary === boundary(purpose),
      ) ?? null
    );
  } catch {
    return null;
  }
}
async function call(
  action: string,
  body: unknown,
  token?: string,
  signal?: AbortSignal,
) {
  const response = await fetch(`/api/collect/${action}`, {
    method: "POST",
    credentials: "omit",
    cache: "no-store",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body),
    signal,
  });
  if (!response.ok) throw new Error("collection_not_shared");
  return response.json();
}
function permitted(purpose: CollectionPurpose) {
  const s = browserStorage();
  return Boolean(
    s &&
    !restrictiveSignal() &&
    (purpose === "research"
      ? capability(purpose)
      : readCookiePreference(s)?.analytics),
  );
}
async function createGrant(purpose: CollectionPurpose) {
  const s = browserStorage();
  if (!s || restrictiveSignal())
    throw new Error("collection_storage_or_signal");
  const existing = capability(purpose);
  if (existing) return existing;
  if (!(await retryWithdrawals())) throw Error("collection_withdrawal_pending");
  if (entries(purpose).length >= 50) throw Error("collection_local_capacity");
  const epoch = generation;
  const capturedBoundary = boundary(purpose);
  const cap: CapabilityEntry = {
    token: Array.from(crypto.getRandomValues(new Uint8Array(32)), (v) =>
      v.toString(16).padStart(2, "0"),
    ).join(""),
    expiresAt: Date.now() + COLLECTION_RETENTION_MS,
    version: COLLECTION_VERSION,
    state: "granting",
    boundary: capturedBoundary,
  };
  // Persist before requesting a grant. Even a lost response can be withdrawn.
  remember(purpose, cap);
  try {
    const result = (await call(
      "preference",
      { purpose, action: "grant", version: COLLECTION_VERSION },
      cap.token,
    )) as Capability;
    if (
      !validCapability(result) ||
      result.version !== COLLECTION_VERSION ||
      result.token !== cap.token
    ) {
      if (validCapability(result))
        remember(purpose, {
          ...result,
          state: "pending",
          boundary: capturedBoundary,
        });
      throw Error("collection_protocol");
    }
    cap.expiresAt = result.expiresAt;
    if (
      epoch !== generation ||
      boundary(purpose) !== capturedBoundary ||
      restrictiveSignal() ||
      (purpose === "analytics" && !readCookiePreference(s)?.analytics) ||
      !entries(purpose).some(
        (v) => v.token === cap.token && v.state === "granting",
      )
    )
      throw Error("collection_withdrawn");
    const shared = capability(purpose);
    if (shared) {
      remember(purpose, { ...cap, state: "pending" });
      if (!(await retryWithdrawals()))
        throw Error("collection_withdrawal_pending");
      return shared;
    }
    remember(purpose, {
      ...result,
      state: "active",
      boundary: capturedBoundary,
    });
    return { ...result, state: "active" as const, boundary: capturedBoundary };
  } catch {
    try {
      remember(purpose, { ...cap, state: "pending" });
    } catch {
      /* unresolved retains it */
    }
    await retryWithdrawals();
    throw Error("collection_not_shared");
  }
}
async function grant(purpose: CollectionPurpose) {
  const existing = grants.get(purpose);
  if (existing) return existing;
  const promise =
    typeof navigator !== "undefined" && navigator.locks?.request
      ? navigator.locks.request(
          `accreatio:collection-grant:${purpose}:v2`,
          () => createGrant(purpose),
        )
      : createGrant(purpose);
  grants.set(purpose, promise);
  try {
    return await promise;
  } finally {
    if (grants.get(purpose) === promise) grants.delete(purpose);
  }
}
export function localCollection() {
  const s = browserStorage();
  try {
    const data = JSON.parse(s?.getItem(LOCAL_COLLECTION_KEY) ?? "[]");
    if (!Array.isArray(data)) return [];
    const filtered = data.filter(
      (v) =>
        v &&
        Number.isSafeInteger(v.at) &&
        v.at <= Date.now() &&
        v.at > Date.now() - COLLECTION_RETENTION_MS &&
        parseCollectionRecord(v.payload, v.purpose),
    );
    if (filtered.length !== data.length)
      s?.setItem(LOCAL_COLLECTION_KEY, JSON.stringify(filtered));
    return filtered.slice(-200);
  } catch {
    return [];
  }
}
function saveLocal(purpose: CollectionPurpose, payload: unknown) {
  const s = browserStorage();
  if (!s) throw new Error("collection_storage");
  const values = localCollection();
  values.push({ purpose, at: Date.now(), payload });
  s.setItem(LOCAL_COLLECTION_KEY, JSON.stringify(values.slice(-200)));
}
async function send(purpose: CollectionPurpose, payload: unknown) {
  const cap = await grant(purpose);
  if (!permitted(purpose)) throw new Error("collection_withdrawn");
  const controller = new AbortController();
  pending.add(controller);
  try {
    return await call(
      "record",
      {
        purpose,
        version: COLLECTION_VERSION,
        id: crypto.randomUUID(),
        payload,
      },
      cap.token,
      controller.signal,
    );
  } finally {
    pending.delete(controller);
  }
}
export async function recordUsage(payload: UsageRecord) {
  const s = browserStorage();
  if (
    !s ||
    !readCookiePreference(s)?.analytics ||
    restrictiveSignal() ||
    !parseCollectionRecord(payload, "analytics")
  )
    return;
  try {
    saveLocal("analytics", payload);
    await send("analytics", payload);
  } catch {
    /* No retry queue or essential-service failure. */
  }
}
export async function submitResearch(answers: ResearchAnswers, share: boolean) {
  const payload = { kind: "research", answers };
  if (!parseCollectionRecord(payload, "research"))
    throw new Error("research_empty");
  saveLocal("research", payload);
  if (share) await send("research", payload);
}
export async function withdrawCollection(purpose: CollectionPurpose) {
  generation++;
  for (const controller of pending) controller.abort();
  pending.clear();
  const s = browserStorage();
  if (!s) return false;
  try {
    s.setItem(boundaryKey(purpose), crypto.randomUUID());
    for (const cap of entries(purpose))
      remember(purpose, { ...cap, state: "pending" });
    if (s.getItem(LOCAL_COLLECTION_KEY) !== null) {
      const retained = localCollection().filter((v) => v.purpose !== purpose);
      if (retained.length)
        s.setItem(LOCAL_COLLECTION_KEY, JSON.stringify(retained));
      else s.removeItem(LOCAL_COLLECTION_KEY);
    }
    return retryWithdrawals();
  } catch {
    return false;
  }
}
export async function retryWithdrawals() {
  const s = browserStorage();
  if (!s) return false;
  let complete = true;
  for (const purpose of ["analytics", "research"] as const) {
    let retained: CapabilityEntry[];
    try {
      retained = entries(purpose).filter(
        (v) => v.state !== "active" || v.boundary !== boundary(purpose),
      );
    } catch {
      complete = false;
      continue;
    }
    for (const cap of retained) {
      try {
        remember(purpose, { ...cap, state: "pending" });
        const result = await call(
          "preference",
          { purpose, action: "revoke" },
          cap.token,
        );
        if (result.revoked !== true)
          throw Error("collection_withdrawal_unconfirmed");
        s.removeItem(entryKey(purpose, cap.token));
        unresolved.delete(entryKey(purpose, cap.token));
        for (const name of [key(purpose), revokeKey(purpose)]) {
          const legacy = JSON.parse(s.getItem(name) ?? "null");
          if (legacy?.token === cap.token) s.removeItem(name);
        }
      } catch {
        complete = false;
      }
    }
  }
  return complete;
}
export function stopPendingCollection() {
  generation++;
  for (const c of pending) c.abort();
  pending.clear();
}
export async function downloadOptionalData() {
  const result: {
    manifest: unknown;
    local: unknown;
    server: unknown[];
    limitations: string[];
  } = {
    manifest: {
      product: "accreatio",
      preparedAt: new Date().toISOString(),
      scope: "Browser choices and optional contributions only",
      format: "JSON UTF-8",
    },
    local: localCollection(),
    server: [],
    limitations: [],
  };
  for (const purpose of ["analytics", "research"] as const) {
    for (const cap of entries(purpose)) {
      try {
        result.server.push(await call("data", { purpose }, cap.token));
      } catch {
        result.limitations.push(
          `${purpose}: a server contribution set is unavailable or expired; local copy included`,
        );
      }
    }
  }
  return result;
}
