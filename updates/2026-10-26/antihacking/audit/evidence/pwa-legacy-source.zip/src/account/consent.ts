export type ConsentPurpose = "necessary" | "analytics" | "advertising";
export type OptionalConsentPurpose = Exclude<ConsentPurpose, "necessary">;

export interface ConsentState {
  readonly necessary: true;
  readonly analytics: boolean;
  readonly advertising: boolean;
}

export const DEFAULT_CONSENT: ConsentState = {
  necessary: true,
  analytics: false,
  advertising: false,
};

export const setOptionalConsent = (
  state: ConsentState,
  purpose: OptionalConsentPurpose,
  granted: boolean,
): ConsentState => ({ ...state, [purpose]: granted });

export interface TrackingAdapter {
  readonly kind: "no-op";
  record(event: string, properties?: Readonly<Record<string, unknown>>): void;
}

const NO_OP_TRACKING_ADAPTER: TrackingAdapter = {
  kind: "no-op",
  record: () => undefined,
};

export const analyticsAdapter: TrackingAdapter = NO_OP_TRACKING_ADAPTER;
export const advertisingAdapter: TrackingAdapter = NO_OP_TRACKING_ADAPTER;
