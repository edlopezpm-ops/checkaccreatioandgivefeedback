export const COOKIE_PREFERENCE_KEY = "accreatio:cookie-preferences";
export const COOKIE_PREFERENCE_MAX_AGE = 180 * 24 * 60 * 60 * 1000;

export interface CookiePreference {
  readonly schemaVersion: 1 | 2;
  readonly necessary: true;
  readonly analytics: boolean;
  readonly advertising: false;
  readonly recordedAt: number;
  readonly noticeVersion?: string;
}

export type PreferenceStorage = Pick<
  Storage,
  "getItem" | "setItem" | "removeItem"
>;

// Keep a failed restriction effective in this module while storage is blocked.
// Remove only the choice: purpose capabilities must remain for withdrawal.
const invalidated = new WeakSet<PreferenceStorage>();
function invalidateOptionalChoice(storage: PreferenceStorage | null) {
  if (!storage) return;
  invalidated.add(storage);
  try {
    storage.removeItem(COOKIE_PREFERENCE_KEY);
    if (storage.getItem(COOKIE_PREFERENCE_KEY) === null)
      invalidated.delete(storage);
  } catch {
    // Keep this client off; a later read must not erase another client's choice.
  }
}

export const OPTIONAL_NOTICE_VERSION = "2026-10-22-collect-v1";
// Account sign-in never calls this module or grants collection permission.
export function readCookiePreference(
  storage: PreferenceStorage,
  now = Date.now(),
): CookiePreference | null {
  if (invalidated.has(storage)) {
    return null;
  }
  try {
    const raw = storage.getItem(COOKIE_PREFERENCE_KEY);
    if (!raw) return null;
    const value = JSON.parse(raw) as Partial<CookiePreference>;
    if (
      value === null ||
      typeof value !== "object" ||
      !(
        (value.schemaVersion === 1 &&
          value.analytics === false &&
          Object.keys(value).sort().join(",") ===
            "advertising,analytics,necessary,recordedAt,schemaVersion") ||
        (value.schemaVersion === 2 &&
          typeof value.analytics === "boolean" &&
          value.noticeVersion === OPTIONAL_NOTICE_VERSION &&
          Object.keys(value).sort().join(",") ===
            "advertising,analytics,necessary,noticeVersion,recordedAt,schemaVersion")
      ) ||
      value.necessary !== true ||
      value.advertising !== false ||
      typeof value.recordedAt !== "number" ||
      !Number.isSafeInteger(value.recordedAt) ||
      value.recordedAt > now ||
      now - value.recordedAt >= COOKIE_PREFERENCE_MAX_AGE
    ) {
      storage.removeItem(COOKIE_PREFERENCE_KEY);
      return null;
    }
    return value as CookiePreference;
  } catch {
    // Blocked or malformed storage never enables optional collection.
    return null;
  }
}

export function saveOptionalChoice(
  storage: PreferenceStorage | null,
  analytics: boolean,
  now = Date.now(),
) {
  if (!analytics) return rejectOptionalCookies(storage, now);
  const preference: CookiePreference = {
    schemaVersion: 2,
    noticeVersion: OPTIONAL_NOTICE_VERSION,
    necessary: true,
    analytics: true,
    advertising: false,
    recordedAt: now,
  };
  try {
    if (!storage) throw new Error("storage_unavailable");
    const serialized = JSON.stringify(preference);
    storage.setItem(COOKIE_PREFERENCE_KEY, serialized);
    if (storage.getItem(COOKIE_PREFERENCE_KEY) !== serialized)
      throw new Error("storage_unavailable");
    invalidated.delete(storage);
    if (!readCookiePreference(storage, now)?.analytics)
      throw new Error("storage_unavailable");
    return { preference, persisted: true };
  } catch {
    invalidateOptionalChoice(storage);
    return {
      preference: { ...preference, analytics: false },
      persisted: false,
    };
  }
}

export function rejectOptionalCookies(
  storage: PreferenceStorage | null,
  now = Date.now(),
): { preference: CookiePreference; persisted: boolean } {
  const preference: CookiePreference = {
    schemaVersion: 1,
    necessary: true,
    analytics: false,
    advertising: false,
    recordedAt: now,
  };
  try {
    if (!storage) return { preference, persisted: false };
    const serialized = JSON.stringify(preference);
    storage.setItem(COOKIE_PREFERENCE_KEY, serialized);
    if (storage.getItem(COOKIE_PREFERENCE_KEY) !== serialized)
      throw new Error("storage_unavailable");
    invalidated.delete(storage);
    return { preference, persisted: true };
  } catch {
    invalidateOptionalChoice(storage);
    return { preference, persisted: false };
  }
}
