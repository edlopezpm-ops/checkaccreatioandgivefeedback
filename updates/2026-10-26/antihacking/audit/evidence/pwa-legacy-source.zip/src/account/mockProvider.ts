import type {
  AccountProfile,
  AccountProvider,
  AccountState,
  AuthChallenge,
  AuthMethod,
  DataRequest,
} from "./contracts";

const MOCK_CODE = "000000";
const FIXED_NOW = "2000-01-01T00:00:00.000Z";
const CHALLENGE_LIFETIME_MS = 10 * 60 * 1000;

const hintEmail = (email: string) => {
  const [name = "", domain = ""] = email.trim().split("@");
  return `${name.slice(0, 1)}***@${domain || "invalid"}`;
};

/** Deterministic in-memory fixture. It performs no I/O and is never enabled by default. */
export function createMockAccountProvider(): AccountProvider {
  let state: AccountState = { status: "logged-out" };
  let pendingEmail = "";
  let requests: DataRequest[] = [];
  const profile = (): AccountProfile => ({
    id: "local-mock-account",
    email: pendingEmail,
    createdAt: FIXED_NOW,
    tier: "local",
  });
  return {
    kind: "mock",
    getState: () => state,
    sendChallenge(email: string, method: AuthMethod) {
      pendingEmail = email.trim();
      const challenge: AuthChallenge = {
        method,
        destinationHint: hintEmail(pendingEmail),
        expiresAt: new Date(Date.now() + CHALLENGE_LIFETIME_MS).toISOString(),
      };
      state = pendingEmail.includes("@")
        ? { status: "challenge-sent", challenge }
        : {
            status: "error",
            code: "provider-unavailable",
            message: "Mock email is invalid.",
          };
      return state;
    },
    verify(code: string) {
      if (state.status !== "challenge-sent")
        return (state = {
          status: "error",
          code: "challenge-expired",
          message: "No active mock challenge.",
        });
      state =
        code === MOCK_CODE
          ? { status: "verified", account: profile() }
          : {
              status: "error",
              code: "invalid-code",
              message: "Use the documented mock code.",
            };
      return state;
    },
    openAccount() {
      if (state.status !== "verified" && state.status !== "account")
        return state;
      const account = state.account;
      return (state = { status: "account", account, requests });
    },
    logout() {
      pendingEmail = "";
      requests = [];
      return (state = { status: "logged-out" });
    },
    requestData(kind: DataRequest["kind"]) {
      if (state.status !== "account") return state;
      requests = [
        ...requests,
        {
          id: `mock-${kind}-${requests.length + 1}`,
          kind,
          status: "requested",
          requestedAt: FIXED_NOW,
        },
      ];
      return (state = { ...state, requests });
    },
    expireChallenge() {
      if (state.status === "challenge-sent")
        state = { status: "expired", challenge: state.challenge };
      return state;
    },
  };
}
