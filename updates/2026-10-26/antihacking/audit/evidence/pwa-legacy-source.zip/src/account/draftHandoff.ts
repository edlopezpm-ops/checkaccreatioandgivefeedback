export const DRAFT_HANDOFF_KEY = "accreatio:draft-oauth-handoff:v1";
type Identity = { ownerKey: string; sessionKey: string };
const validKey = (value: unknown): value is string =>
  typeof value === "string" && /^v1:[a-f0-9]{64}$/.test(value);
const lifetime = 10 * 60_000;

// This one-tab marker contains no project data and grants no account access.
export function saveDraftHandoff(
  identity: Identity,
  storage?: Pick<Storage, "setItem">,
  now = Date.now(),
) {
  if (!validKey(identity.ownerKey) || !validKey(identity.sessionKey))
    throw new Error("draft_invalid_identity");
  (storage ?? sessionStorage).setItem(
    DRAFT_HANDOFF_KEY,
    JSON.stringify({ ...identity, expiresAt: now + lifetime }),
  );
}

export function clearDraftHandoff(
  storage?: Pick<Storage, "removeItem" | "getItem">,
  requireConfirmation = false,
) {
  try {
    const target = storage ?? sessionStorage;
    target.removeItem(DRAFT_HANDOFF_KEY);
    if (requireConfirmation && target.getItem(DRAFT_HANDOFF_KEY) !== null)
      throw new Error("draft_handoff_not_cleared");
  } catch {
    if (requireConfirmation) throw new Error("draft_handoff_not_cleared");
    /* A marker that cannot be consumed is never used. */
  }
}

export function takeDraftHandoff(
  verifiedOwnerKey: string,
  storage?: Pick<Storage, "getItem" | "removeItem">,
  now = Date.now(),
): Identity | null {
  try {
    const target = storage ?? sessionStorage;
    const raw = target.getItem(DRAFT_HANDOFF_KEY);
    // Consume before examining or using it; failed removal is fail-closed.
    target.removeItem(DRAFT_HANDOFF_KEY);
    if (target.getItem(DRAFT_HANDOFF_KEY) !== null) return null;
    if (!raw || raw.length > 512) return null;
    const value: unknown = JSON.parse(raw);
    if (!value || typeof value !== "object") return null;
    const marker = value as Record<string, unknown>;
    if (
      Object.keys(marker).sort().join() !== "expiresAt,ownerKey,sessionKey" ||
      !validKey(marker.ownerKey) ||
      !validKey(marker.sessionKey) ||
      marker.ownerKey !== verifiedOwnerKey ||
      typeof marker.expiresAt !== "number" ||
      !Number.isSafeInteger(marker.expiresAt) ||
      marker.expiresAt <= now ||
      marker.expiresAt > now + lifetime
    )
      return null;
    return { ownerKey: marker.ownerKey, sessionKey: marker.sessionKey };
  } catch {
    return null;
  }
}
