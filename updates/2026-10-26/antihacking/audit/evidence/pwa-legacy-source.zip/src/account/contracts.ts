export type AuthMethod = "email-code" | "magic-link";
export type AuthErrorCode =
  | "challenge-expired"
  | "invalid-code"
  | "rate-limited"
  | "provider-unavailable";

export interface AccountFeatureConfig {
  readonly enabled: boolean;
  readonly consentUiEnabled: boolean;
  readonly analyticsEnabled: boolean;
  readonly advertisingEnabled: boolean;
}

export const DEFAULT_ACCOUNT_FEATURE_CONFIG: AccountFeatureConfig = {
  enabled: false,
  consentUiEnabled: false,
  analyticsEnabled: false,
  advertisingEnabled: false,
};

export interface AuthChallenge {
  readonly method: AuthMethod;
  readonly destinationHint: string;
  readonly expiresAt: string;
}

export interface AccountProfile {
  readonly id: string;
  readonly email: string;
  readonly createdAt: string;
  readonly tier: "local";
}

export interface DataRequest {
  readonly id: string;
  readonly kind: "export" | "deletion";
  readonly status: "requested";
  readonly requestedAt: string;
}

export type AccountState =
  | { readonly status: "logged-out" }
  | { readonly status: "challenge-sent"; readonly challenge: AuthChallenge }
  | { readonly status: "verified"; readonly account: AccountProfile }
  | {
      readonly status: "account";
      readonly account: AccountProfile;
      readonly requests: readonly DataRequest[];
    }
  | { readonly status: "expired"; readonly challenge: AuthChallenge }
  | {
      readonly status: "error";
      readonly code: AuthErrorCode;
      readonly message: string;
    };

export interface AccountProvider {
  readonly kind: "mock";
  getState(): AccountState;
  sendChallenge(email: string, method: AuthMethod): AccountState;
  verify(code: string): AccountState;
  openAccount(): AccountState;
  logout(): AccountState;
  requestData(kind: DataRequest["kind"]): AccountState;
  expireChallenge(): AccountState;
}

// Browser-facing discovery contains capabilities only, never account lookups.
export interface WebAuthMethods {
  version: "auth.v1";
  methods: {
    google: { available: boolean };
    github: { available: boolean };
    emailOtp: { available: boolean };
  };
}
export type WebIdentityProvider = "google" | "github";
export type WebVerificationAction =
  "data" | "delete" | "link_google" | "link_github";

export interface GoogleAuthTransaction {
  transactionId: string;
  authorizationUrl: string;
  expiresAt: string;
}

export type WebAuthTransactionStatus =
  "pending" | "completed" | "failed" | "expired";
