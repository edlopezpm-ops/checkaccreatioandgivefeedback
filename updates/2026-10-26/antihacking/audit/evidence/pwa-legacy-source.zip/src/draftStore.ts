import type { ProjectDefinition } from "./types";
import { migrateProjectDefinition } from "../shared/domain";
import { projectShapeErrors } from "../shared/inputValidation";

const DB_NAME = "accreatio-drafts";
const STORE_NAME = "drafts";
const DRAFT_KEY = "account-current:v1";
const ONBOARDING_KEY = "accreatio:onboarding";
const JOURNAL_KEY = "accreatio:account-draft:v1";
const CONTEXT_KEY = "accreatio:draft-context:v1";
const LEGACY_JOURNAL_KEY = "accreatio:draft-journal:v5";
const LEGACY_DRAFT_KEY = "current";
export const DRAFT_SCHEMA_VERSION = 5;
export const ONBOARDING_SCHEMA_VERSION = 1;

let dbPromise: ReturnType<typeof openDatabase> | null = null;
let writerReady: Promise<boolean> | null = null;
let writerOwned = false;
let releaseWriter: (() => void) | undefined;
let knownRevision: string | null = null;
let pendingWrite: Promise<unknown> = Promise.resolve();
type AccountDraftIdentity = { ownerKey: string; sessionKey: string };
type DraftContext = AccountDraftIdentity & { generation: string };
type ContextMarker = DraftContext | { generation: string };
let boundContext: DraftContext | null = null;
let contextEpoch = 0;
const sameContext = (a: unknown, b: unknown): boolean => {
  if (!a || !b || typeof a !== "object" || typeof b !== "object") return false;
  const left = a as DraftContext,
    right = b as DraftContext;
  return (
    left.ownerKey === right.ownerKey &&
    left.sessionKey === right.sessionKey &&
    left.generation === right.generation
  );
};
const readJournal = (key: string): unknown => {
  const value = localStorage.getItem(key);
  return value ? JSON.parse(value) : null;
};
function releaseDraftWriter() {
  releaseWriter?.();
  releaseWriter = undefined;
  writerOwned = false;
  writerReady = null;
}
function invalidateExternal(marker: unknown) {
  if (!boundContext || sameContext(marker, boundContext)) return;
  contextEpoch++;
  boundContext = null;
  knownRevision = null;
  releaseDraftWriter();
  window.dispatchEvent(
    Object.assign(new Event("accreatio:draft-invalidated"), {
      sessionEnded:
        !marker || typeof marker !== "object" || !("ownerKey" in marker),
    }),
  );
}
const contextChannel =
  typeof window !== "undefined" && typeof BroadcastChannel !== "undefined"
    ? new BroadcastChannel(CONTEXT_KEY)
    : null;
contextChannel?.addEventListener("message", (event) =>
  invalidateExternal(event.data),
);
function requireContext(): { context: DraftContext; epoch: number } {
  if (!boundContext) throw new Error("draft_not_bound");
  const snapshot = { context: boundContext, epoch: contextEpoch };
  assertContext(snapshot);
  return snapshot;
}
function assertContext(snapshot: { context: DraftContext; epoch: number }) {
  if (
    snapshot.epoch !== contextEpoch ||
    !sameContext(snapshot.context, boundContext)
  )
    throw new Error("draft_context_changed");
  let marker: unknown;
  try {
    marker = readJournal(CONTEXT_KEY);
  } catch {
    return;
  } // IndexedDB checks remain mandatory when localStorage is blocked.
  if (!sameContext(marker, snapshot.context))
    throw new Error("draft_context_changed");
}
const contextError = (error: unknown) =>
  error instanceof Error &&
  ["draft_not_bound", "draft_context_changed"].includes(error.message);
function abortDraftTransaction(tx: { abort(): void; done: Promise<unknown> }) {
  // Aborting rejects idb's completion promise even when the caller throws first.
  void tx.done.catch(() => undefined);
  try {
    tx.abort();
  } catch {
    /* Already completed or aborted. */
  }
}
const writerId = globalThis.crypto?.randomUUID?.() ?? String(Math.random());
const revisionTime = (revision?: string | null) =>
  Number(revision?.split(":")[0]) || 0;
const isNewerForeignRevision = (
  actual: string | null | undefined,
  expected: string | null,
) =>
  (actual ?? null) !== expected &&
  revisionTime(actual) >= revisionTime(expected);
function assertReadableVersion(value: unknown) {
  if (
    value &&
    typeof value === "object" &&
    typeof (value as { schemaVersion?: unknown }).schemaVersion === "number" &&
    Number((value as { schemaVersion: number }).schemaVersion) >
      DRAFT_SCHEMA_VERSION
  ) {
    writerOwned = false;
    throw new Error("draft_newer_version");
  }
}
const protectedDraftError = (error: unknown) =>
  error instanceof Error &&
  [
    "draft_other_tab",
    "draft_newer_version",
    "draft_not_bound",
    "draft_context_changed",
  ].includes(error.message);

export type DraftNavigation = {
  question: string;
  hasReviewed: boolean;
  locale: "es" | "en";
};

// One tab owns durable writes. Another tab can inspect/edit/export its in-memory
// copy, but must reload after the owner closes before it may replace the draft.
// This is deliberately not project synchronization.
function claimWriter(): Promise<boolean> {
  if (writerReady) return writerReady;
  if (!globalThis.navigator?.locks) {
    writerOwned = true;
    return (writerReady = Promise.resolve(true));
  }
  writerReady = new Promise((resolve) => {
    void navigator.locks
      .request("accreatio:draft-writer", { ifAvailable: true }, (lock) => {
        writerOwned = Boolean(lock);
        resolve(writerOwned);
        if (lock)
          return new Promise<void>((release) => {
            releaseWriter = release;
          });
      })
      .catch(() => {
        writerOwned = false;
        resolve(false);
      });
  });
  return writerReady;
}

if (typeof window !== "undefined") {
  window.addEventListener("storage", (event) => {
    if (event.key !== CONTEXT_KEY && event.key !== null) return;
    try {
      invalidateExternal(event.newValue ? JSON.parse(event.newValue) : null);
    } catch {
      invalidateExternal(null);
    }
  });
  window.addEventListener("pagehide", releaseDraftWriter);
  window.addEventListener("pageshow", () => {
    try {
      if (boundContext) invalidateExternal(readJournal(CONTEXT_KEY));
    } catch {
      /* Recheck durable context on load/save. */
    }
    if (boundContext) void claimWriter();
  });
}

type OnboardingPreference = {
  completed: boolean;
  storageAvailable: boolean;
};

export function loadOnboardingPreference(
  storage?: Pick<Storage, "getItem">,
): OnboardingPreference {
  try {
    const target = storage ?? globalThis.localStorage;
    const value = target?.getItem(ONBOARDING_KEY);
    if (!value) return { completed: false, storageAvailable: Boolean(target) };
    const parsed = JSON.parse(value) as Record<string, unknown>;
    return {
      completed:
        parsed.schemaVersion === ONBOARDING_SCHEMA_VERSION &&
        parsed.completed === true,
      storageAvailable: true,
    };
  } catch {
    return { completed: false, storageAvailable: false };
  }
}

export function saveOnboardingCompletion(
  storage?: Pick<Storage, "setItem">,
): boolean {
  try {
    const target = storage ?? globalThis.localStorage;
    if (!target) return false;
    target.setItem(
      ONBOARDING_KEY,
      JSON.stringify({
        schemaVersion: ONBOARDING_SCHEMA_VERSION,
        completed: true,
      }),
    );
    return true;
  } catch {
    return false;
  }
}

async function openDatabase() {
  const { openDB } = await import("idb");
  return openDB(DB_NAME, 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    },
  });
}

function database() {
  if (!dbPromise)
    dbPromise = openDatabase().catch((error) => {
      dbPromise = null;
      throw error;
    });
  return dbPromise;
}

type StoredDraftV5 = {
  schemaVersion: 5;
  project: Omit<ProjectDefinition, "attachments"> & { attachments: [] };
  transientAttachments?: { count: number };
  navigation?: DraftNavigation;
  revision?: string;
  ownerKey?: string;
  sessionKey?: string;
  generation?: string;
};

// Binding is a privacy boundary, independent of the single-tab editing lock.
// Unknown legacy payloads are discarded, never assigned to the next account.
export async function bindAccountDraft(
  identity: AccountDraftIdentity,
  preserveSameOwner = false,
): Promise<void> {
  if (
    !/^v1:[a-f0-9]{64}$/.test(identity.ownerKey) ||
    !/^v1:[a-f0-9]{64}$/.test(identity.sessionKey)
  )
    throw new Error("draft_invalid_identity");
  const previous = boundContext;
  const epoch = ++contextEpoch;
  boundContext = null;
  knownRevision = null;
  let localMarker: unknown, localDraft: unknown;
  try {
    localMarker = readJournal(CONTEXT_KEY);
    localDraft = readJournal(JOURNAL_KEY);
  } catch {
    /* Durable fallback below. */
  }
  await pendingWrite.catch(() => undefined);
  if (epoch !== contextEpoch) throw new Error("draft_context_changed");
  let context: DraftContext | undefined;
  let retained: StoredDraftV5 | undefined;
  const select = (marker: unknown, value: unknown) => {
    const m = marker as DraftContext | undefined;
    const sameIdentity =
      m?.ownerKey === identity.ownerKey &&
      m?.sessionKey === identity.sessionKey;
    const liveSameOwner =
      preserveSameOwner &&
      previous?.ownerKey === identity.ownerKey &&
      sameContext(marker, previous);
    context =
      sameIdentity && typeof m?.generation === "string"
        ? { ...identity, generation: m.generation }
        : { ...identity, generation: crypto.randomUUID() };
    retained =
      (sameIdentity || liveSameOwner) && sameContext(value, marker)
        ? (value as StoredDraftV5)
        : undefined;
    if (retained) {
      assertReadableVersion(retained);
      retained = { ...retained, ...context };
    }
  };
  let durableSaved = false;
  try {
    const db = await database();
    if (epoch !== contextEpoch) throw new Error("draft_context_changed");
    const tx = db.transaction(STORE_NAME, "readwrite");
    try {
      const marker = await tx.store.get(CONTEXT_KEY);
      const durable = await tx.store.get(DRAFT_KEY);
      if (epoch !== contextEpoch) throw new Error("draft_context_changed");
      // Conflicting generations mean a privacy boundary was crossed. Neither
      // store may revive the other one's old answers.
      const markersAgree =
        !localMarker || !marker || sameContext(localMarker, marker);
      const chosen = marker ?? localMarker;
      const matchingJournal = sameContext(localDraft, chosen)
        ? (localDraft as StoredDraftV5)
        : undefined;
      const matchingDurable = sameContext(durable, chosen)
        ? (durable as StoredDraftV5)
        : undefined;
      const chosenContext = chosen as DraftContext | undefined;
      if (
        markersAgree &&
        ((chosenContext?.ownerKey === identity.ownerKey &&
          chosenContext?.sessionKey === identity.sessionKey) ||
          (preserveSameOwner &&
            previous?.ownerKey === identity.ownerKey &&
            sameContext(chosen, previous)))
      ) {
        assertReadableVersion(matchingJournal);
        assertReadableVersion(matchingDurable);
      }
      const latest =
        matchingDurable &&
        (!matchingJournal ||
          revisionTime(matchingDurable.revision) >
            revisionTime(matchingJournal.revision))
          ? matchingDurable
          : matchingJournal;
      select(
        markersAgree ? chosen : undefined,
        markersAgree ? latest : undefined,
      );
      await tx.store.put(context!, CONTEXT_KEY);
      if (retained) await tx.store.put(retained, DRAFT_KEY);
      else await tx.store.delete(DRAFT_KEY);
      await tx.store.delete(LEGACY_DRAFT_KEY);
      if (epoch !== contextEpoch) throw new Error("draft_context_changed");
      await tx.done;
      durableSaved = true;
    } catch (error) {
      abortDraftTransaction(tx);
      throw error;
    }
  } catch (error) {
    if (contextError(error) || protectedDraftError(error)) throw error;
    select(localMarker, localDraft);
  }
  if (epoch !== contextEpoch) throw new Error("draft_context_changed");
  let journalSaved = false;
  try {
    localStorage.removeItem(LEGACY_JOURNAL_KEY);
    if (retained) localStorage.setItem(JOURNAL_KEY, JSON.stringify(retained));
    else localStorage.removeItem(JOURNAL_KEY);
    localStorage.setItem(CONTEXT_KEY, JSON.stringify(context));
    journalSaved = true;
  } catch {
    /* One confirmed store is sufficient; mismatched envelopes stay unreadable. */
  }
  if (!journalSaved && !durableSaved)
    throw new Error("draft_storage_unavailable");
  boundContext = context!;
  knownRevision = retained?.revision ?? null;
  contextChannel?.postMessage(context);
  await claimWriter();
}

export async function purgeAccountDraft(): Promise<void> {
  const previous = boundContext;
  const epoch = ++contextEpoch; // Invalidate queued writes before the first await.
  boundContext = null;
  knownRevision = null;
  releaseDraftWriter();
  const tombstone: ContextMarker = { generation: crypto.randomUUID() };
  let currentMarker: unknown;
  try {
    currentMarker = readJournal(CONTEXT_KEY);
  } catch {
    /* Transactional check below. */
  }
  if (previous && currentMarker && !sameContext(currentMarker, previous))
    throw new Error("draft_context_changed");
  let journalPurged = false;
  try {
    localStorage.setItem(CONTEXT_KEY, JSON.stringify(tombstone));
    localStorage.removeItem(JOURNAL_KEY);
    localStorage.removeItem(LEGACY_JOURNAL_KEY);
    journalPurged = true;
  } catch {
    /* Attempt IndexedDB even when browser storage is unavailable. */
  }
  contextChannel?.postMessage(tombstone);
  await pendingWrite.catch(() => undefined);
  if (epoch !== contextEpoch) throw new Error("draft_context_changed");
  let durablePurged = false;
  try {
    const db = await database();
    const tx = db.transaction(STORE_NAME, "readwrite");
    try {
      const current = await tx.store.get(CONTEXT_KEY);
      let localCurrent: unknown;
      try {
        localCurrent = readJournal(CONTEXT_KEY);
      } catch {
        /* Use the transactional context. */
      }
      if (
        epoch !== contextEpoch ||
        (journalPurged && !sameContext(localCurrent, tombstone)) ||
        (previous &&
          current &&
          !sameContext(current, previous) &&
          !sameContext(current, tombstone))
      )
        throw new Error("draft_context_changed");
      await tx.store.put(tombstone, CONTEXT_KEY);
      await tx.store.delete(DRAFT_KEY);
      await tx.store.delete(LEGACY_DRAFT_KEY);
      if (epoch !== contextEpoch) throw new Error("draft_context_changed");
      await tx.done;
      durablePurged = true;
    } catch (error) {
      abortDraftTransaction(tx);
      throw error;
    }
  } catch (error) {
    if (contextError(error)) throw error;
  }
  if (!journalPurged && !durablePurged)
    throw new Error("draft_storage_unavailable");
}

export function serializeDraft(
  draft: ProjectDefinition,
  navigation?: DraftNavigation,
  transientAttachmentCount = draft.attachments.length,
): StoredDraftV5 {
  const count = Math.min(MAX_RESELECTION_COUNT, transientAttachmentCount);
  return {
    schemaVersion: DRAFT_SCHEMA_VERSION,
    project: { ...draft, attachments: [] },
    ...(count > 0 ? { transientAttachments: { count } } : {}),
    ...(navigation ? { navigation } : {}),
  };
}

const attachmentCount = (value: unknown) => {
  if (!value || typeof value !== "object") return 0;
  const record = value as Record<string, unknown>;
  const project =
    record.project && typeof record.project === "object"
      ? (record.project as Record<string, unknown>)
      : record;
  const legacyCount = Array.isArray(project.attachments)
    ? project.attachments.length
    : 0;
  const marker = record.transientAttachments;
  const markedCount =
    marker &&
    typeof marker === "object" &&
    Number.isInteger((marker as Record<string, unknown>).count)
      ? Number((marker as Record<string, unknown>).count)
      : 0;
  return Math.min(MAX_RESELECTION_COUNT, Math.max(legacyCount, markedCount));
};
const MAX_RESELECTION_COUNT = 20;

export function normalizeDraft(
  value: unknown,
  fallback: ProjectDefinition,
): ProjectDefinition | null {
  const migrated = normalizeDraftWithWarnings(value, fallback);
  return migrated?.project ?? null;
}

export function normalizeDraftWithWarnings(
  value: unknown,
  fallback: ProjectDefinition,
) {
  let migrated: ReturnType<typeof migrateProjectDefinition>;
  try {
    migrated = migrateProjectDefinition(value, fallback);
  } catch {
    // Stored values are untrusted. Malformed legacy structures must take the
    // same blank-draft recovery path rather than escape into the renderer.
    return null;
  }
  if (!migrated) return null;
  const project = { ...migrated.project, attachments: [] };
  // Drafts may be unfinished, but every value installed into the renderer must
  // satisfy the typed shape before string helpers or controls can consume it.
  if (Object.keys(projectShapeErrors(project)).length) return null;
  return {
    ...migrated,
    project,
    transientAttachmentCount: attachmentCount(value),
    navigation: readNavigation(value),
  };
}

function readNavigation(value: unknown): DraftNavigation | undefined {
  if (!value || typeof value !== "object") return;
  const n = (value as { navigation?: DraftNavigation }).navigation;
  if (
    n &&
    typeof n.question === "string" &&
    typeof n.hasReviewed === "boolean" &&
    (n.locale === "es" || n.locale === "en")
  )
    return n;
}

export async function loadDraft(
  fallback: ProjectDefinition,
): Promise<ProjectDefinition | null> {
  return (await loadDraftWithWarnings(fallback))?.project ?? null;
}

export async function loadDraftWithWarnings(fallback: ProjectDefinition) {
  const snapshot = requireContext();
  await claimWriter();
  assertContext(snapshot);
  let value: unknown;
  try {
    const journal = readJournal(JOURNAL_KEY);
    if (sameContext(journal, snapshot.context)) value = journal;
  } catch {
    // IndexedDB remains a valid fallback when localStorage is unavailable.
  }
  assertReadableVersion(value);
  try {
    const db = await database();
    const tx = db.transaction(STORE_NAME, "readonly");
    const marker = await tx.store.get(CONTEXT_KEY);
    const stored = await tx.store.get(DRAFT_KEY);
    await tx.done;
    assertContext(snapshot);
    if (!sameContext(marker, snapshot.context))
      throw new Error("draft_context_changed");
    const durable = (
      sameContext(marker, snapshot.context) &&
      sameContext(stored, snapshot.context)
        ? stored
        : undefined
    ) as StoredDraftV5 | undefined;
    assertReadableVersion(durable);
    // A failed journal write must never hide an acknowledged IndexedDB write.
    if (
      durable &&
      (!value ||
        revisionTime(durable.revision) >
          revisionTime((value as StoredDraftV5).revision))
    )
      value = durable;
  } catch (error) {
    if (protectedDraftError(error) || !value) throw error;
  }
  assertContext(snapshot);
  knownRevision =
    value && typeof value === "object"
      ? ((value as StoredDraftV5).revision ?? null)
      : null;
  const normalized = normalizeDraftWithWarnings(value, fallback);
  if (value !== undefined && value !== null && !normalized) {
    return {
      project: { ...fallback, attachments: [] },
      warnings: ["invalidDraftRecovered"],
      transientAttachmentCount: 0,
      navigation: undefined,
    };
  }
  return normalized;
}

// The count-only journal is committed synchronously in the input/navigation
// handler, before an immediate browser reload can discard a debounce. IndexedDB
// writes remain ordered and are acknowledged only when their transaction ends.
export function saveDraft(
  draft: ProjectDefinition,
  navigation?: DraftNavigation,
  transientAttachmentCount?: number,
): Promise<void> {
  let snapshot: ReturnType<typeof requireContext>;
  try {
    snapshot = requireContext();
  } catch (error) {
    return Promise.reject(error);
  }
  if (!writerOwned) return Promise.reject(new Error("draft_other_tab"));
  const expected = knownRevision;
  const revision = `${Math.max(Date.now(), revisionTime(expected) + 1)}:${writerId}:${crypto.randomUUID()}`;
  const value = {
    ...serializeDraft(draft, navigation, transientAttachmentCount),
    ...snapshot.context,
    revision,
  };
  let journalSaved = false;
  try {
    const current = localStorage.getItem(JOURNAL_KEY);
    const actual = current ? (JSON.parse(current) as StoredDraftV5) : null;
    assertContext(snapshot);
    if (actual && !sameContext(actual, snapshot.context))
      throw new Error("draft_context_changed");
    assertReadableVersion(actual);
    if (actual && isNewerForeignRevision(actual.revision, expected))
      return Promise.reject(new Error("draft_other_tab"));
    localStorage.setItem(JOURNAL_KEY, JSON.stringify(value));
    journalSaved = true;
  } catch (error) {
    if (protectedDraftError(error)) return Promise.reject(error);
    // Do not claim success unless at least one durable store confirms a write.
  }
  knownRevision = revision;
  const write = pendingWrite
    .catch(() => undefined)
    .then(async () => {
      try {
        assertContext(snapshot);
        const db = await database();
        assertContext(snapshot);
        const tx = db.transaction(STORE_NAME, "readwrite");
        const marker = await tx.store.get(CONTEXT_KEY);
        const previous = (await tx.store.get(DRAFT_KEY)) as
          StoredDraftV5 | undefined;
        try {
          assertContext(snapshot);
          if (
            !sameContext(marker, snapshot.context) ||
            (previous && !sameContext(previous, snapshot.context))
          )
            throw new Error("draft_context_changed");
          assertReadableVersion(previous);
        } catch (error) {
          abortDraftTransaction(tx);
          throw error;
        }
        if (
          !globalThis.navigator?.locks &&
          previous?.revision &&
          previous.revision !== expected &&
          !previous.revision.includes(`:${writerId}:`)
        ) {
          abortDraftTransaction(tx);
          throw new Error("draft_other_tab");
        }
        await tx.store.put(value, DRAFT_KEY);
        try {
          assertContext(snapshot);
        } catch (error) {
          abortDraftTransaction(tx);
          throw error;
        }
        await tx.done;
        assertContext(snapshot);
        if (!journalSaved) {
          try {
            const stale = localStorage.getItem(JOURNAL_KEY);
            if (
              stale &&
              revisionTime((JSON.parse(stale) as StoredDraftV5).revision) <
                revisionTime(revision)
            )
              localStorage.removeItem(JOURNAL_KEY);
          } catch {
            /* Loading compares both durable stores even if cleanup fails. */
          }
        }
      } catch (error) {
        if (protectedDraftError(error) || !journalSaved) throw error;
      }
    });
  pendingWrite = write;
  return write;
}

export async function clearDraft(): Promise<void> {
  const snapshot = requireContext();
  if (!writerOwned) throw new Error("draft_other_tab");
  const expected = knownRevision;
  await pendingWrite.catch(() => undefined);
  assertContext(snapshot);
  if (expected !== knownRevision) throw new Error("draft_changed_during_reset");
  const checkRevision = () => {
    assertContext(snapshot);
    const current = localStorage.getItem(JOURNAL_KEY);
    const actual = current ? (JSON.parse(current) as StoredDraftV5) : null;
    if (actual && !sameContext(actual, snapshot.context))
      throw new Error("draft_context_changed");
    assertReadableVersion(actual);
    if (actual && isNewerForeignRevision(actual.revision, expected))
      throw new Error("draft_other_tab");
  };
  try {
    checkRevision();
  } catch (error) {
    if (protectedDraftError(error)) throw error;
  }
  let removed = false;
  try {
    const db = await database();
    assertContext(snapshot);
    const tx = db.transaction(STORE_NAME, "readwrite");
    const marker = await tx.store.get(CONTEXT_KEY);
    const previous = (await tx.store.get(DRAFT_KEY)) as
      StoredDraftV5 | undefined;
    try {
      assertContext(snapshot);
      if (
        !sameContext(marker, snapshot.context) ||
        (previous && !sameContext(previous, snapshot.context))
      )
        throw new Error("draft_context_changed");
      assertReadableVersion(previous);
    } catch (error) {
      abortDraftTransaction(tx);
      throw error;
    }
    if (
      !globalThis.navigator?.locks &&
      previous?.revision &&
      previous.revision !== expected
    ) {
      abortDraftTransaction(tx);
      throw new Error("draft_other_tab");
    }
    await tx.store.delete(DRAFT_KEY);
    try {
      assertContext(snapshot);
    } catch (error) {
      abortDraftTransaction(tx);
      throw error;
    }
    await tx.done;
    assertContext(snapshot);
    removed = true;
  } catch (error) {
    if (protectedDraftError(error)) throw error;
  }
  try {
    checkRevision();
    localStorage.removeItem(JOURNAL_KEY);
    removed = true;
  } catch (error) {
    if (protectedDraftError(error) || !removed) throw error;
  }
  knownRevision = null;
}
