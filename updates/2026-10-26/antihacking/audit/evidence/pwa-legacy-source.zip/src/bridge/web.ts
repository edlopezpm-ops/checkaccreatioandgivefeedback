import type {
  Bridge,
  ExecutionRequest,
  ExecutionResult,
  ExecutionStepResult,
  WebAttachment,
} from "../types";
import type { ProviderAvailability } from "../types";
import { unsupportedHostAvailability } from "../../shared/providerRegistry";
import { slugify } from "../core";
import { ACCEPTED_EXTENSIONS } from "../core";
import { prepareAttachment } from "../attachmentSecurity";
import {
  buildWebExport,
  resolveWebAttachments,
  validateWebProject,
  type ExportEntry,
} from "../webExport";
import {
  browserExecutionFingerprint,
  LogicalOperationGuard,
  validateExecutionRequest,
} from "../operationGuard";

export const WEB_BRIDGE_UNSUPPORTED = "Not supported in this host";

const unsupported = (capability: string): Promise<never> =>
  Promise.reject(
    new Error(`${capability}: ${WEB_BRIDGE_UNSUPPORTED.toLowerCase()}`),
  );

// DOM side effect only; not unit-tested in Node for the same reason
// electron/main.ts's real fs/git effects rely on manual verification --
// see docs/PHASE_P2_PILOT_EVIDENCE.md for the browser check that covers it.
function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

type WebExecutionDependencies = {
  authorize?: (operationId: string) => Promise<void>;
  prepared?: (blob: Blob, filename: string, operationId: string) => void;
  download?: (blob: Blob, filename: string) => void;
  fingerprint?: (request: ExecutionRequest) => Promise<string>;
  createArchive?: (files: ExportEntry[]) => Promise<Blob>;
  assertCurrent?: () => void;
};

export function chooseWebAttachments(): Promise<WebAttachment[]> {
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.multiple = true;
    input.accept = ACCEPTED_EXTENSIONS.join(",");
    const finish = () => {
      const files = Array.from(input.files ?? []).map((file, index) => {
        const dot = file.name.lastIndexOf(".");
        return {
          id: globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${index}`,
          name: file.name,
          size: file.size,
          extension: dot > 0 ? file.name.slice(dot).toLowerCase() : "",
          blob: file,
        };
      });
      input.remove();
      resolve(files);
    };
    input.addEventListener("change", finish, { once: true });
    input.addEventListener("cancel", finish, { once: true });
    input.click();
  });
}

export function createWebExecutionBridge(
  dependencies: WebExecutionDependencies = {},
): (request: ExecutionRequest) => Promise<ExecutionResult> {
  const download = dependencies.download ?? triggerDownload;
  const createArchive =
    dependencies.createArchive ??
    (async (files) => {
      const { downloadZip } = await import("client-zip");
      return downloadZip(
        files.map((f) => ({ name: f.path, input: f.input })),
      ).blob();
    });
  const worker = async (
    request: ExecutionRequest,
  ): Promise<ExecutionResult> => {
    const { operationId, definition: p, settings: s } = request;
    dependencies.assertCurrent?.();
    const errors = validateWebProject(p, s);
    const skipped = (reason: string) => [
      {
        id: "zip-build",
        status: "skipped" as const,
        summary: reason,
        artifacts: [],
      },
      {
        id: "download-request",
        status: "skipped" as const,
        summary: reason,
        artifacts: [],
      },
    ];
    const failure = (
      error: unknown,
      steps: ExecutionStepResult[] = skipped("Not attempted"),
    ): ExecutionResult => {
      const completed = steps
        .filter(({ status }) => status === "completed")
        .map(({ id }) => id);
      return {
        operationId,
        ok: false,
        dryRun: p.dryRun,
        completed,
        logs: [],
        error: error instanceof Error ? error.message : String(error),
        outcome: completed.length > 0 ? "partial" : "failure",
        steps,
        artifacts: [],
      };
    };
    if (Object.keys(errors).length)
      return failure(
        `Invalid project definition: ${Object.values(errors).join(", ")}`,
      );
    const slug = slugify(p.name) || "new-project";
    if (p.dryRun) {
      try {
        if (request.webAttachments)
          resolveWebAttachments(request.webAttachments, slug);
      } catch (error) {
        return failure(error);
      }
      return {
        operationId,
        ok: true,
        dryRun: true,
        completed: [],
        logs: [
          `Dry run complete. No ZIP was created or downloaded. Would export: ${slug}.zip`,
        ],
        outcome: "dry-run",
        steps: skipped("Skipped because Dry run is on"),
        artifacts: [],
      };
    }
    let files;
    try {
      const selected = request.webAttachments ?? [];
      if (selected.length !== p.attachments.length)
        throw new Error(
          "Attachment metadata does not match the live browser selection.",
        );
      const prepared: WebAttachment[] = [];
      for (let index = 0; index < selected.length; index += 1) {
        const source = selected[index];
        const metadata = p.attachments[index];
        if (
          metadata.name !== source.name ||
          metadata.size !== source.size ||
          metadata.extension.toLowerCase() !== source.extension.toLowerCase() ||
          source.blob.size !== source.size
        )
          throw new Error(
            "Attachment metadata does not match the live browser selection.",
          );
        const blob = await prepareAttachment(source.blob, source.name);
        dependencies.assertCurrent?.();
        prepared.push({ ...source, blob, size: blob.size });
      }
      files = buildWebExport(
        {
          ...p,
          attachments: prepared.map(({ name, size, extension }) => ({
            name,
            size,
            extension,
          })),
        },
        s,
        prepared,
        {
          // __APP_VERSION__ is a Vite build-time define; it doesn't exist
          // when this module runs under the plain Node test runner.
          appVersion:
            typeof __APP_VERSION__ === "string" ? __APP_VERSION__ : "unknown",
        },
      );
    } catch (error) {
      return failure(error, [
        {
          id: "zip-build",
          status: "failed",
          summary: "ZIP build failed",
          artifacts: [],
          error: error instanceof Error ? error.message : String(error),
        },
        {
          id: "download-request",
          status: "skipped",
          summary: "ZIP was not built",
          artifacts: [],
        },
      ]);
    }
    const filename = `${slug}.zip`;
    const manifest = files.map(({ path }) => path);
    try {
      const blob = await createArchive(files);
      dependencies.assertCurrent?.();
      dependencies.prepared?.(blob, filename, operationId);
      try {
        dependencies.assertCurrent?.();
        await dependencies.authorize?.(operationId);
        dependencies.assertCurrent?.();
      } catch (error) {
        return failure(error, [
          {
            id: "zip-build",
            status: "completed",
            summary: "ZIP built in memory",
            artifacts: [],
          },
          {
            id: "download-request",
            status: "skipped",
            summary: "Export authorization required; retry this ZIP",
            artifacts: [],
            error: error instanceof Error ? error.message : String(error),
          },
        ]);
      }
      try {
        dependencies.assertCurrent?.();
        download(blob, filename);
      } catch (error) {
        return failure(error, [
          {
            id: "zip-build",
            status: "completed",
            summary: "ZIP built in memory",
            artifacts: [],
          },
          {
            id: "download-request",
            status: "failed",
            summary: "Browser download request failed",
            artifacts: [],
            error: error instanceof Error ? error.message : String(error),
          },
        ]);
      }
    } catch (error) {
      return failure(error, [
        {
          id: "zip-build",
          status: "failed",
          summary: "ZIP build failed",
          artifacts: [],
          error: error instanceof Error ? error.message : String(error),
        },
        {
          id: "download-request",
          status: "skipped",
          summary: "ZIP was not built",
          artifacts: [],
        },
      ]);
    }
    const artifacts = [
      { kind: "zip" as const, location: filename, displayName: filename },
      ...manifest.map((location) => ({
        kind: "zip-entry" as const,
        location,
        displayName: location.split("/").at(-1) || location,
      })),
    ];
    return {
      operationId,
      ok: true,
      dryRun: false,
      completed: ["zip-build", "download-request"],
      logs: files.map((f) => `Included: ${f.path}`),
      outcome: "success",
      steps: [
        {
          id: "zip-build",
          status: "completed",
          summary: "ZIP built in memory",
          artifacts,
        },
        {
          id: "download-request",
          status: "completed",
          summary: "Browser download requested",
          artifacts: [],
        },
      ],
      artifacts,
      webDelivery: {
        state: "download-requested",
        filename,
        manifest,
        browserPersistenceVerified: false,
      },
    };
  };
  const guard = new LogicalOperationGuard(
    dependencies.fingerprint ?? browserExecutionFingerprint,
    worker,
  );
  return (value: ExecutionRequest) => {
    const request = validateExecutionRequest(value);
    return guard.run(request);
  };
}

let officialAuthorizer = async (
  _operationId: string,
): Promise<void | { issuedAt: string; retryExpiresAt: string }> => {
  throw new Error(
    "Sign in to authorize a new export. Your draft remains local.",
  );
};
let lastPrepared: {
  blob: Blob;
  filename: string;
  operationId: string;
  preparedAt: number;
  authorizedAt: number | null;
  retryExpiresAt: number | null;
} | null = null;
export function setWebAuthorizer(authorize: typeof officialAuthorizer) {
  officialAuthorizer = authorize;
}
let exportGeneration = 0;
let officialExecution: ReturnType<typeof createOfficialExecution> | undefined;
export function clearWebExportRecovery() {
  exportGeneration++;
  officialExecution = undefined;
  lastPrepared = null;
  if (typeof window !== "undefined")
    window.dispatchEvent(new Event("accreatio:export-ready"));
}
export function hasWebExportRecovery() {
  return (
    lastPrepared !== null &&
    lastPrepared.authorizedAt !== null &&
    lastPrepared.retryExpiresAt !== null &&
    Date.now() < lastPrepared.retryExpiresAt
  );
}
export async function retryWebExport() {
  const prepared = lastPrepared;
  const generation = exportGeneration;
  if (!prepared || !hasWebExportRecovery())
    throw new Error("The previous ZIP is no longer in memory.");
  await officialAuthorizer(prepared.operationId);
  if (generation !== exportGeneration || prepared !== lastPrepared)
    throw new Error("The account changed. Start a new export.");
  triggerDownload(prepared.blob, prepared.filename);
}
function createOfficialExecution() {
  const generation = exportGeneration;
  return createWebExecutionBridge({
    assertCurrent: () => {
      if (generation !== exportGeneration)
        throw new Error("The account changed. Start a new export.");
    },
    authorize: async (operationId) => {
      const receipt = await officialAuthorizer(operationId);
      if (lastPrepared?.operationId === operationId && receipt) {
        lastPrepared.authorizedAt = Date.parse(receipt.issuedAt);
        lastPrepared.retryExpiresAt = Date.parse(receipt.retryExpiresAt);
      }
      if (typeof window !== "undefined")
        window.dispatchEvent(new Event("accreatio:export-ready"));
    },
    prepared: (blob, filename, operationId) => {
      lastPrepared = {
        blob,
        filename,
        operationId,
        preparedAt: Date.now(),
        authorizedAt: null,
        retryExpiresAt: null,
      };
      if (typeof window !== "undefined")
        window.dispatchEvent(new Event("accreatio:export-ready"));
    },
  });
}
export const execute = (request: ExecutionRequest) => {
  officialExecution ??= createOfficialExecution();
  return officialExecution(request);
};

// Resolves rather than rejects: the UI wants to render an honest per-
// provider status, not a generic error banner, and "can't detect this
// in a browser" is itself the accurate reason -- a browser has no way
// to run a local CLI at all.
async function checkProviders(): Promise<ProviderAvailability> {
  return unsupportedHostAvailability();
}

export const webBridge: Bridge = {
  kind: "web",
  chooseFolder: () => unsupported("Folder selection"),
  chooseAttachments: chooseWebAttachments,
  loadSettings: () => unsupported("Settings loading"),
  saveSettings: () => unsupported("Settings saving"),
  githubStatus: () => unsupported("GitHub status"),
  connectGithub: () => unsupported("GitHub connection"),
  loadHistory: () => unsupported("History loading"),
  execute,
  checkProviders,
  orchestrationPreflight: () => unsupported("Orchestration Center"),
  orchestrationStart: () => unsupported("Orchestration Center"),
  orchestrationSnapshot: () => unsupported("Orchestration Center"),
  orchestrationDecide: () => unsupported("Orchestration Center"),
  orchestrationCancel: () => unsupported("Orchestration Center"),
};
