import type { Bridge } from "../types";

const api = () => {
  if (!window.accreatio) throw new Error("Electron bridge unavailable");
  return window.accreatio;
};

export const electronBridge: Bridge = {
  kind: "electron",
  chooseFolder: () => api().chooseFolder(),
  chooseAttachments: () => api().chooseAttachments(),
  loadSettings: () => api().loadSettings(),
  saveSettings: (s) => api().saveSettings(s),
  githubStatus: () => api().githubStatus(),
  connectGithub: () => api().connectGithub(),
  loadHistory: () => api().loadHistory(),
  execute: (request) => {
    if (request.webAttachments !== undefined)
      return Promise.reject(
        new Error("Web attachments are invalid in the Electron host"),
      );
    return api().execute(request);
  },
  checkProviders: () => api().checkProviders(),
  orchestrationPreflight: (request) => api().orchestrationPreflight(request),
  orchestrationStart: (request) => api().orchestrationStart(request),
  orchestrationSnapshot: () => api().orchestrationSnapshot(),
  orchestrationDecide: (decision) => api().orchestrationDecide(decision),
  orchestrationCancel: () => api().orchestrationCancel(),
};
