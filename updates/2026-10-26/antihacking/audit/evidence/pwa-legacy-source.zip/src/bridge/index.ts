import type { Bridge } from "../types";
import { electronBridge } from "./electron";
import { webBridge } from "./web";

export const selectBridge = (hasElectronApi: boolean): Bridge =>
  hasElectronApi ? electronBridge : webBridge;

export const bridge: Bridge =
  typeof window !== "undefined" && window.accreatio
    ? electronBridge
    : webBridge;
