import { planActions, renderSetupMd, slugify, validateProject } from "./core";
import { buildExportManifest } from "../shared/exportManifest";
import { validateAttachmentSet } from "../shared/domain";
import { assertPreparedAttachment } from "./attachmentSecurity";
import type { ProjectDefinition, Settings, WebAttachment } from "./types";
import {
  assertArchivePaths,
  assertProjectShape,
  assertSettingsShape,
  PROJECT_TEXT_LIMITS,
  RESERVED_FILENAME,
} from "../shared/inputValidation";

/** Web presentation limits also guard restored drafts and direct executions.
 * The retained desktop domain keeps its existing participant/name contract. */
export function validateWebProject(
  project: ProjectDefinition,
  settings?: Settings,
) {
  const errors = validateProject(project, settings);
  if (Object.keys(errors).length) return errors;
  if (project.name.length > 50) errors.name = "webNameLength";
  const roles = project.participants.map(({ role }) => role);
  if (roles.length > 4) errors.participants = "webParticipantCount";
  else if (new Set(roles).size !== roles.length)
    errors.participants = "duplicateParticipantRole";
  return errors;
}

export interface ExportEntry {
  path: string;
  input: string | Blob;
  kind: "generated" | "attachment";
  content?: string;
}

export interface ResolvedWebAttachment {
  source: WebAttachment;
  archiveName: string;
  archivePath: string;
  metadata: ProjectDefinition["attachments"][number];
}

const RESERVED = RESERVED_FILENAME;
const safeStem = (name: string) => {
  const basename = name.replace(/^.*[\\/]/, "");
  const withoutControls = basename.replace(
    /[\u0000-\u001f\u007f-\u009f\u200e\u200f\u202a-\u202e\u2066-\u2069]/g,
    "",
  );
  return withoutControls.replace(/[<>:"|?*\\/]/g, "_").replace(/[. ]+$/g, "");
};

export function resolveWebAttachments(
  attachments: readonly WebAttachment[],
  slug = "new-project",
): ResolvedWebAttachment[] {
  const used = new Set<string>();
  return attachments.map((source) => {
    const extension = source.extension.toLowerCase();
    let sanitized = safeStem(source.name);
    let stem = sanitized.toLowerCase().endsWith(extension)
      ? sanitized.slice(0, -extension.length)
      : sanitized;
    stem = stem.replace(/^[. ]+|[. ]+$/g, "");
    if (!stem || stem === "." || stem === "..") stem = "attachment";
    if (RESERVED.test(stem)) stem = `attachment-${stem}`;
    stem = stem.slice(
      0,
      PROJECT_TEXT_LIMITS.attachmentName - extension.length - 8,
    );
    let archiveName = `${stem}${extension}`;
    let suffix = 2;
    const key = (value: string) =>
      value.normalize("NFC").toLocaleLowerCase("en-US");
    while (used.has(key(archiveName))) {
      archiveName = `${stem} (${suffix})${extension}`;
      suffix += 1;
    }
    used.add(key(archiveName));
    return {
      source,
      archiveName,
      archivePath: `${slug}/docs/product/sources/${archiveName}`,
      metadata: { name: archiveName, size: source.size, extension },
    };
  });
}

const generated = (path: string, content: string): ExportEntry => ({
  path,
  input: content,
  content,
  kind: "generated",
});

/** Pure: what the browser edition zips, given a definition. Desktop's
 * privileged execute() writes the same content to a real filesystem via
 * the same shared generatePrompt/discoveryMd/governance/projectSignature
 * functions, so the two hosts stay in content parity from one source. */
export function buildWebExport(
  p: ProjectDefinition,
  s: Settings,
  webAttachments: readonly WebAttachment[],
  opts: { appVersion: string; createdAt?: string; sourceRevision?: string },
): ExportEntry[] {
  assertProjectShape(p);
  assertSettingsShape(s);
  if (p.action === "tracking")
    throw new Error(
      "Tracking-only export isn't supported in the browser edition yet — choose Repository or Both.",
    );
  const slug = slugify(p.name) || "new-project";
  if (validateAttachmentSet(p.attachments).length)
    throw new Error("Invalid attachment selection.");
  if (p.attachments.length !== webAttachments.length)
    throw new Error(
      "Attachment metadata does not match the live browser selection.",
    );
  for (let index = 0; index < webAttachments.length; index += 1) {
    const metadata = p.attachments[index];
    const source = webAttachments[index];
    if (
      metadata.name !== source.name ||
      metadata.size !== source.size ||
      metadata.extension.toLowerCase() !== source.extension.toLowerCase() ||
      source.blob.size !== source.size
    )
      throw new Error(
        "Attachment metadata does not match the live browser selection.",
      );
    assertPreparedAttachment(source.blob, source.name);
  }
  const resolved = resolveWebAttachments(webAttachments, slug);
  const exportProject = {
    ...p,
    attachments: resolved.map((entry) => entry.metadata),
  };
  const actions = planActions(p, s);
  // One manifest builds both editions, so the browser ZIP and the desktop
  // host cannot drift into shipping different projects.
  const files: ExportEntry[] = buildExportManifest(exportProject, s, {
    createdBy: "accreatio-web",
    appVersion: opts.appVersion,
    createdAt: opts.createdAt,
    sourceRevision: opts.sourceRevision,
  }).map((file) => generated(`${slug}/${file.path}`, file.content));
  // Browser-only: the steps a page cannot perform for the user, as literal
  // commands. The desktop host performs these itself and needs no such file.
  files.push(
    generated(`${slug}/SETUP.md`, renderSetupMd(actions, exportProject, s)),
  );
  files.push(
    ...resolved.map((entry) => ({
      path: entry.archivePath,
      input: entry.source.blob,
      kind: "attachment" as const,
    })),
  );
  assertArchivePaths(
    files.map((file) => file.path),
    slug,
  );
  return files;
}

export function buildProjectFiles(
  p: ProjectDefinition,
  s: Settings,
  opts: { appVersion: string; createdAt?: string; sourceRevision?: string },
): ExportEntry[] {
  return buildWebExport(p, s, [], opts);
}
