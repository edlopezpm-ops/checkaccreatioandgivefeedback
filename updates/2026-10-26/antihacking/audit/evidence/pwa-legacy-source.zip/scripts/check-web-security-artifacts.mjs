import { readFile, readdir, lstat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const repositoryRoot = path.resolve(
  fileURLToPath(new URL("..", import.meta.url)),
);
const internalDirectories = new Set([
  ".git",
  ".local",
  ".private",
  ".wrangler",
  "node_modules",
  "electron",
  "functions",
  "workers",
  "scripts",
  "tests",
  "migrations",
  "migrations-auth",
  "src",
  "dist-electron",
  "dist-desktop",
]);
const sensitiveName =
  /^(?:\.env(?:\..*)?|\.dev\.vars(?:\..*)?|\.npmrc|\.pypirc|\.netrc|wrangler\.(?:toml|jsonc?)|vite\.config\.[^.]+|tsconfig(?:\.[^.]+)?\.json|package(?:-lock)?\.json|AGENTS\.md)$/i;
const internalExtension =
  /\.(?:[cm]?tsx?|sql|sqlite3?|db|pem|key|pfx|p12|bak|log|map)(?:\.(?:gz|br))?$/i;
const sourceMapDirective = /(?:\/\/[#@]|\/\*[#@])\s*sourceMappingURL\s*=/;
const publicArchives = new Set([
  "examples/accreatio-basic-sample.zip",
  "examples/accreatio-orchestration-sample.zip",
]);

export async function checkWebSecurityArtifacts(directory) {
  const root = path.resolve(directory);
  const details = await lstat(root).catch(() => null);
  if (!details?.isDirectory() || details.isSymbolicLink())
    throw new Error(
      "Web artifact root is missing or is not a regular directory.",
    );
  const findings = [];
  let files = 0;
  const walk = async (current) => {
    const entries = await readdir(current, { withFileTypes: true });
    for (const entry of entries) {
      const target = path.join(current, entry.name);
      const relative = path.relative(root, target).split(path.sep).join("/");
      if (entry.isSymbolicLink()) {
        findings.push(`symbolic link: ${relative}`);
      } else if (entry.isDirectory()) {
        if (internalDirectories.has(entry.name.toLowerCase()))
          findings.push(`internal directory: ${relative}`);
        else await walk(target);
      } else if (entry.isFile()) {
        files++;
        if (
          sensitiveName.test(entry.name) ||
          internalExtension.test(entry.name)
        )
          findings.push(`internal/source-map file: ${relative}`);
        if (
          /\.(?:zip|7z|tar|tgz|gz|br|rar)$/i.test(entry.name) &&
          !publicArchives.has(relative)
        )
          findings.push(`unreviewed archive: ${relative}`);
        // Inspect actual directives rather than credential-like variable names,
        // which may legitimately occur in documentation or public UI content.
        if (/\.(?:[cm]?js|css|html)$/i.test(entry.name)) {
          const content = await readFile(target, "utf8");
          if (sourceMapDirective.test(content))
            findings.push(`source-map directive: ${relative}`);
        }
      } else findings.push(`non-regular entry: ${relative}`);
    }
  };
  await walk(root);
  const index = await lstat(path.join(root, "index.html")).catch(() => null);
  if (!index?.isFile() || index.isSymbolicLink())
    findings.push("missing regular index.html");
  if (findings.length)
    throw new Error(`Web publication gate failed:\n${findings.join("\n")}`);
  return { files };
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href
) {
  try {
    const result = await checkWebSecurityArtifacts(
      path.join(repositoryRoot, "dist"),
    );
    console.log(
      `PASS web publication gate: ${result.files} files; no source maps or known internal configuration/source paths; public archives allowlisted.`,
    );
  } catch (error) {
    console.error(
      error instanceof Error ? error.message : "Web publication gate failed.",
    );
    process.exitCode = 1;
  }
}
