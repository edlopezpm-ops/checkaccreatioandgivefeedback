import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import electronPath from "electron";

const root = await fs.mkdtemp(path.join(os.tmpdir(), "accreatio-execute-"));
const userData = path.join(root, "user-data");
const resultFile = path.join(root, "smoke-result.json");
const projectRoot = path.resolve(import.meta.dirname, "..");
const electronEnv = Object.fromEntries(
  Object.entries(process.env).filter(
    ([name]) =>
      name !== "ELECTRON_RUN_AS_NODE" &&
      name !== "NODE_OPTIONS" &&
      name !== "VITE_DEV_SERVER_URL" &&
      !name.startsWith("VSCODE_"),
  ),
);
const OUTPUT_LIMIT = 64 * 1024;
const appendOutput = (current, chunk) =>
  `${current}${String(chunk)}`.slice(-OUTPUT_LIMIT);

const delay = (milliseconds) =>
  new Promise((resolve) => setTimeout(resolve, milliseconds));

async function stopProcessTree(child) {
  if (!child || child.exitCode !== null || child.signalCode !== null) return;
  if (process.platform !== "win32") {
    child.kill("SIGKILL");
    return;
  }
  await new Promise((resolve) => {
    const killer = spawn("taskkill", ["/pid", String(child.pid), "/t", "/f"], {
      shell: false,
      windowsHide: true,
      stdio: "ignore",
    });
    killer.once("error", resolve);
    killer.once("exit", resolve);
  });
}

async function removeTemporaryRoot() {
  let lastError;
  for (let attempt = 0; attempt < 12; attempt += 1) {
    try {
      await fs.rm(root, { recursive: true, force: true });
      return;
    } catch (error) {
      lastError = error;
      await delay(150 * (attempt + 1));
    }
  }
  throw lastError;
}

function waitForExit(child, timeoutMilliseconds) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      callback(value);
    };
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      void stopProcessTree(child).finally(() =>
        reject(
          new Error(
            `Electron privileged execute smoke timed out after ${timeoutMilliseconds}ms`,
          ),
        ),
      );
    }, timeoutMilliseconds);
    child.once("error", (error) => finish(reject, error));
    child.once("exit", (code, signal) => finish(resolve, { code, signal }));
  });
}

let child;
let stdout = "";
let stderr = "";
let smokeError;
try {
  child = spawn(
    electronPath,
    [
      // This flag is isolated to a hidden, fixed-payload temp-directory smoke.
      // On this Windows host the Chromium GPU subprocess otherwise exits with
      // STATUS_DLL_NOT_FOUND before app.whenReady(), producing a native dialog.
      "--no-sandbox",
      "--noerrdialogs",
      `--user-data-dir=${userData}`,
      ".",
      `--accreatio-execute-smoke=${root}`,
    ],
    {
      cwd: projectRoot,
      env: electronEnv,
      shell: false,
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
    },
  );
  child.stdout.on("data", (chunk) => (stdout = appendOutput(stdout, chunk)));
  child.stderr.on("data", (chunk) => (stderr = appendOutput(stderr, chunk)));

  const outcome = await waitForExit(child, 60_000);
  let envelope;
  try {
    envelope = JSON.parse(await fs.readFile(resultFile, "utf8"));
  } catch (error) {
    throw new Error(
      `Electron smoke produced no readable result (exit=${String(outcome.code)}, signal=${String(outcome.signal)}). ${error instanceof Error ? error.message : String(error)}\n${stderr || stdout}`,
    );
  }
  assert.equal(
    outcome.code,
    0,
    envelope.fatalError ||
      envelope.result?.error ||
      stderr ||
      `Electron exited with ${String(outcome.code)}`,
  );
  const result = envelope.result;
  assert.equal(result.concurrent.length, 3);
  assert.ok(result.concurrent.every((item) => item.ok === true));
  assert.ok(result.concurrent.every((item) => item.outcome === "success"));
  assert.deepEqual(result.concurrent[0], result.concurrent[1]);
  assert.deepEqual(result.concurrent[0], result.concurrent[2]);
  assert.deepEqual(
    result.concurrent.map((item) => item.operationId),
    Array(3).fill("00000000-0000-4000-8000-000000000001"),
  );
  assert.equal(result.rerun.ok, true, result.rerun.error);
  assert.equal(result.recovery.ok, true, result.recovery.error);
  assert.equal(result.failures.length, 2);
  assert.ok(result.failures.every((item) => item.ok === false));
  assert.deepEqual(result.failures[0], result.failures[1]);
  const project = path.join(root, "execution-smoke");
  assert.equal(path.resolve(result.concurrent[0].projectPath), project);
  assert.equal(
    result.concurrent[0].artifacts.filter(
      (artifact) => artifact.kind === "generated-file",
    ).length,
    4,
  );
  assert.ok(
    result.concurrent[0].artifacts.every(
      (artifact) => artifact.location && artifact.displayName,
    ),
  );
  assert.equal(result.failures[0].outcome, "failure");
  for (const expected of [
    "PROJECT_PROMPT.md",
    "AGENTS.md",
    path.join("docs", "product", "discovery.md"),
    path.join(".accreatio", "project.json"),
  ])
    await fs.access(path.join(project, expected));
  for (const expected of [
    "PROJECT_PROMPT (1).md",
    "PROJECT_PROMPT (2).md",
    "AGENTS (1).md",
    "AGENTS (2).md",
  ])
    await fs.access(path.join(project, expected));
  await assert.rejects(fs.access(path.join(project, "PROJECT_PROMPT (3).md")));
  const history = JSON.parse(
    await fs.readFile(path.join(userData, "history.json"), "utf8"),
  );
  assert.equal(history.entries.length, 3);
  console.log(
    "PASS Electron privileged execute smoke (guarded concurrent runner)",
  );
} catch (error) {
  smokeError = error;
} finally {
  await stopProcessTree(child);
  try {
    await removeTemporaryRoot();
  } catch (cleanupError) {
    if (!smokeError) throw cleanupError;
    console.error(
      `Electron smoke cleanup also failed: ${cleanupError instanceof Error ? cleanupError.message : String(cleanupError)}`,
    );
  }
}

if (smokeError) throw smokeError;
