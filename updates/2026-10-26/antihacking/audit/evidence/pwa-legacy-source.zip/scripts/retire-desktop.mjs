console.error(
  "accreatio desktop is retired. It was an unreleased prototype and will never be released. accreatio is web-only. Electron source and historical artifacts are preserved for custody. Use npm run dev:web, npm run build:web, or npm run verify. See docs/WEB_ONLY_DELIVERY_2026-10-22.md.",
);
process.exitCode = 1;
