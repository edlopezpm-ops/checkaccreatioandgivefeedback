// Real browser generator, deterministic fictitious inputs, actual ZIP readback.
// Run: node --import tsx scripts/generate-export-examples.mjs [--check]
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { inflateRawSync } from "node:zlib";
import { downloadZip } from "client-zip";
import { buildWebExport } from "../src/webExport.ts";
import { defaultOrchestration } from "../shared/domain.ts";
import { prepareAttachment } from "../src/attachmentSecurity.ts";
import { minimalDocx } from "./attachment-smoke-fixtures.mjs";
import {
  EXPORT_CONTRACT_VERSION,
  getStartingInstruction,
} from "../shared/exportManifest.ts";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const check = process.argv.includes("--check");
const output = path.join(root, "public/examples");
const evidence = path.join(root, ".local/logs/readiness-2026-10-21");
const createdAt = "2026-10-21T12:00:00.000Z";
const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");
const appVersion = JSON.parse(
  await readFile(path.join(root, "package.json"), "utf8"),
).version;
// A committed sample describes its recorded source snapshot. Checking it after
// another commit must reproduce that snapshot, while generation pins current HEAD.
const sourceRevision = check
  ? JSON.parse(await readFile(path.join(output, "manifest.json"), "utf8"))
      .sourceRevision
  : execFileSync("git", ["rev-parse", "HEAD"], {
      cwd: root,
      encoding: "utf8",
    }).trim();
assert.ok(
  typeof sourceRevision === "string" && /^[0-9a-f]{40}$/i.test(sourceRevision),
  "Example provenance requires a valid 40-character Git sourceRevision.",
);
const sourceFiles = [
  "src/webExport.ts",
  "src/attachmentSecurity.ts",
  "src/attachmentSecurityCore.ts",
  "src/attachmentSecurityTypes.ts",
  "src/core.ts",
  "shared/exportManifest.ts",
  "shared/projectTemplates.ts",
  "shared/domain.ts",
  "shared/aekrPayload.generated.ts",
  "shared/providerRegistry.ts",
  "shared/funding.ts",
  "scripts/generate-export-examples.mjs",
  "scripts/attachment-smoke-fixtures.mjs",
];
const sourceHashes = Object.fromEntries(
  await Promise.all(
    sourceFiles.map(async (name) => [
      name,
      sha256(await readFile(path.join(root, name))),
    ]),
  ),
);

function unzip(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const extracted = new Map();
  const end = bytes.length - 22;
  assert.equal(view.getUint32(end, true), 0x06054b50);
  let offset = view.getUint32(end + 16, true);
  const count = view.getUint16(end + 10, true);
  for (let index = 0; index < count; index += 1) {
    assert.equal(view.getUint32(offset, true), 0x02014b50);
    const method = view.getUint16(offset + 10, true);
    const size = view.getUint32(offset + 20, true);
    const nameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const local = view.getUint32(offset + 42, true);
    const name = new TextDecoder("utf-8", { fatal: true }).decode(
      bytes.subarray(offset + 46, offset + 46 + nameLength),
    );
    const start =
      local +
      30 +
      view.getUint16(local + 26, true) +
      view.getUint16(local + 28, true);
    const body = bytes.subarray(start, start + size);
    assert.ok(!extracted.has(name), `duplicate ZIP entry ${name}`);
    extracted.set(
      name,
      method === 0 ? body.slice() : new Uint8Array(inflateRawSync(body)),
    );
    offset += 46 + nameLength + extraLength + commentLength;
  }
  return extracted;
}

async function publish(name, bytes) {
  const target = path.join(output, name);
  if (check)
    assert.equal(
      sha256(await readFile(target)),
      sha256(bytes),
      `stale generated sample: ${name}`,
    );
  else {
    await mkdir(path.dirname(target), { recursive: true });
    await writeFile(target, bytes);
  }
}

const samples = [];
for (const enabled of [false, true]) {
  const locale = enabled ? "en" : "es";
  const brief = enabled
    ? "Fictional neighborhood tool library. Record loans offline; no accounts, payments, cloud sync or personal contact details. Ask before choosing a stack."
    : "Biblioteca ficticia de herramientas de barrio. Registrar préstamos sin conexión; sin cuentas, pagos, sincronización ni datos personales de contacto. Consultar antes de elegir stack.";
  const attachments = [];
  for (const [id, name, content] of [
    ["brief", "project-brief.docx", brief],
    [
      "decisions",
      "constraints.docx",
      "Fictional fixture: offline; zero paid services; architecture remains pending.",
    ],
  ]) {
    const blob = await prepareAttachment(
      new Blob([minimalDocx(content)]),
      name,
    );
    attachments.push({ id, name, extension: ".docx", size: blob.size, blob });
  }
  const participants = enabled
    ? [
        { id: "participant-01", role: "architect", label: "Design" },
        {
          id: "participant-02",
          role: "implementer",
          label: "Build after approval",
        },
        { id: "participant-03", role: "auditor", label: "Independent review" },
      ]
    : [{ id: "participant-01", role: "generalist", label: "" }];
  const definition = {
    name: enabled ? "Neighborhood tools advanced" : "Herramientas del barrio",
    phase: "idea",
    context: brief,
    restrictions: enabled
      ? "Offline only. Zero direct service cost. No personal data, payments, tracking or automatic publication. Stack and acceptance remain human decisions."
      : "Solo sin conexión. Costo directo cero. Sin datos personales, pagos, seguimiento ni publicación automática. Stack y aceptación pendientes de decisión humana.",
    route: "local",
    action: "repository",
    destination: "browser-download",
    participants,
    attachments: attachments.map(({ name, size, extension }) => ({
      name,
      size,
      extension,
    })),
    initializeGit: false,
    createRemote: false,
    remotePrivate: true,
    openIde: false,
    dryRun: true,
    orchestration: {
      ...defaultOrchestration(),
      enabled,
      participants: enabled
        ? participants.map((p) => ({
            participantId: p.id,
            provider: "codex",
            task:
              p.role === "architect"
                ? "Propose the first bounded design after reviewing the project goal."
                : p.role === "implementer"
                  ? "Implement only the human-approved scope; do not choose pending requirements."
                  : "Review independently in a separate context and report reproducible findings.",
          }))
        : [],
    },
  };
  const settings = {
    baseFolder: "",
    toolkitPath: "",
    futureProjectsPath: "",
    defaultBranch: "main",
    preferredIde: "VS Code",
    theme: "dark",
    locale,
    confirmBeforeRun: true,
  };
  const entries = buildWebExport(definition, settings, attachments, {
    appVersion,
    createdAt,
    sourceRevision,
  });
  const zipBlob = await downloadZip(
    entries.map((e) => ({
      name: e.path,
      input: e.input,
      lastModified: new Date(createdAt),
    })),
  ).blob();
  const bytes = new Uint8Array(await zipBlob.arrayBuffer());
  const extracted = unzip(bytes);
  assert.equal(extracted.size, entries.length);
  const projectRoot = entries[0].path.split("/")[0];
  const files = [];
  for (const entry of entries) {
    const original =
      typeof entry.input === "string"
        ? new TextEncoder().encode(entry.input)
        : new Uint8Array(await entry.input.arrayBuffer());
    assert.deepEqual(
      extracted.get(entry.path),
      original,
      `ZIP bytes differ: ${entry.path}`,
    );
    assert.ok(
      entry.path.startsWith(`${projectRoot}/`) &&
        !entry.path.includes("..") &&
        !entry.path.includes("\\"),
    );
    if (entry.content)
      new TextDecoder("utf-8", { fatal: true }).decode(
        extracted.get(entry.path),
      );
    files.push({
      path: entry.path,
      kind: entry.kind,
      bytes: original.length,
      sha256: sha256(original),
    });
    if (!check) {
      const target = path.join(
        evidence,
        enabled ? "zip-advanced" : "zip-basic",
        entry.path,
      );
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, extracted.get(entry.path));
    }
  }
  const contract = JSON.parse(
    new TextDecoder().decode(
      extracted.get(`${projectRoot}/.accreatio/contract.json`),
    ),
  );
  for (const name of contract.requiredPaths)
    assert.ok(extracted.has(`${projectRoot}/${name}`), name);
  for (const entry of entries.filter(
    (e) => e.kind === "generated" && e.path.endsWith(".md"),
  )) {
    // Imported project data is not normative. These sample inputs contain no links.
    for (const match of entry.content.matchAll(/\]\(([^)]+)\)/g)) {
      const target = match[1].split("#")[0];
      if (/^https?:/.test(target) || !target) continue;
      const resolved = path.posix.normalize(
        path.posix.join(path.posix.dirname(entry.path), target),
      );
      assert.ok(extracted.has(resolved), `${entry.path}: unresolved ${target}`);
    }
  }
  const filename = enabled
    ? "accreatio-orchestration-sample.zip"
    : "accreatio-basic-sample.zip";
  await publish(filename, bytes);
  await publish(
    `PROJECT_PROMPT.${locale}.md`,
    entries.find((e) => e.path.endsWith("/PROJECT_PROMPT.md")).content,
  );
  samples.push({
    filename,
    locale,
    orchestrationEnabled: enabled,
    projectRoot,
    sha256: sha256(bytes),
    bytes: bytes.length,
    files,
  });
}
for (const locale of ["es", "en"])
  await publish(
    `START.${locale}.md`,
    `# ${locale === "es" ? "Instrucción de inicio" : "Starting instruction"}\n\n${getStartingInstruction(locale)}\n`,
  );
const manifest = {
  generatedAt: createdAt,
  appVersion,
  sourceRevision,
  exportContractVersion: EXPORT_CONTRACT_VERSION,
  sourceHashes,
  provenance:
    "Generated with buildWebExport and client-zip; actual ZIP bytes extracted and compared to every generator entry. Fictitious inputs only; source hashes identify the modified generator independent of repository HEAD. No human handoff or runtime execution is established by these checks.",
  samples,
};
await publish("manifest.json", `${JSON.stringify(manifest, null, 2)}\n`);
if (!check) {
  await mkdir(evidence, { recursive: true });
  await writeFile(
    path.join(evidence, "export-examples.json"),
    `${JSON.stringify(manifest, null, 2)}\n`,
  );
}
console.log(
  `${check ? "Verified" : "Generated and read back"} ${samples.length} actual ZIPs, ${samples.map((s) => `${s.filename}: ${s.files.length} entries, ${s.bytes} bytes`).join("; ")}.`,
);
