// Real Edge/UI ZIP generation; synthetic account backend, fictitious local bytes.
// Run: node scripts/readiness-export-load-smoke.mjs
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { inflateRawSync } from "node:zlib";
import { chromium } from "playwright";

const root = process.cwd();
const evidenceDirectory = path.join(root, ".local/logs/readiness-2026-10-21");
const cacheDirectory = path.join(
  root,
  ".local/cache/readiness-2026-10-21/export-load",
);
const origin = "http://localhost:4185";
const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");
const MiB = 1024 * 1024;
await mkdir(evidenceDirectory, { recursive: true });
await mkdir(cacheDirectory, { recursive: true });
const html = await readFile(path.join(root, "dist/index.html"), "utf8");
const candidateAsset = html.match(/src="\.\/assets\/(index-[^"]+\.js)"/)?.[1];
assert.ok(candidateAsset, "A built web candidate is required");
if (process.argv[2])
  assert.equal(
    candidateAsset,
    process.argv[2],
    "Use the requested built candidate without rebuilding it",
  );
const report = {
  startedAt: new Date().toISOString(),
  status: "RUNNING",
  candidate: {
    appVersion: JSON.parse(await readFile("package.json", "utf8")).version,
    asset: candidateAsset,
    assetSha256: sha256(
      await readFile(path.join(root, "dist/assets", candidateAsset)),
    ),
  },
  environment: {
    browserChannel: "msedge",
    headless: true,
    serviceWorkers: "block",
    viewport: { width: 1440, height: 1000 },
    reducedMotion: "reduce",
    platform: os.platform(),
    release: os.release(),
    architecture: os.arch(),
    cpu: os.cpus()[0]?.model,
    logicalCpus: os.cpus().length,
    systemMemoryBytes: os.totalmem(),
  },
  backend:
    "SYNTHETIC account/methods/authorization API fixture; no real account, identity provider, quota ledger or production request.",
  methodology:
    "Select deterministic fictitious local files through the real browser file chooser. Use the built UI and production generator, request a real download, extract the actual ZIP and compare every attachment byte and SHA-256. A transparent observer around native Response.blob records only application/zip archive start/end; 10ms timer and requestAnimationFrame samples record scheduling during the unmodified archive operation. A trusted Playwright Tab key is sent when ZIP generation starts; its arrival/focus transition is observed. Idle measurements use this same candidate only, not an earlier code baseline. No performance regression comparison is claimed.",
  cases: [],
};
const saveReport = () =>
  writeFile(
    path.join(evidenceDirectory, "export-load.json"),
    JSON.stringify(report, null, 2) + "\n",
  );
const server = spawn(
  process.execPath,
  [
    "node_modules/vite/bin/vite.js",
    "preview",
    "--host",
    "localhost",
    "--port",
    "4185",
    "--strictPort",
  ],
  { cwd: root, windowsHide: true, stdio: "ignore" },
);
let browser;

function unzip(bytes) {
  const result = new Map();
  const end = bytes.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  assert.ok(end >= 0, "Complete ZIP end record");
  let offset = bytes.readUInt32LE(end + 16);
  const count = bytes.readUInt16LE(end + 10);
  for (let index = 0; index < count; index++) {
    assert.equal(bytes.readUInt32LE(offset), 0x02014b50);
    const method = bytes.readUInt16LE(offset + 10);
    const size = bytes.readUInt32LE(offset + 20);
    const nameLength = bytes.readUInt16LE(offset + 28);
    const name = bytes
      .subarray(offset + 46, offset + 46 + nameLength)
      .toString("utf8");
    const local = bytes.readUInt32LE(offset + 42);
    assert.equal(bytes.readUInt32LE(local), 0x04034b50);
    const start =
      local +
      30 +
      bytes.readUInt16LE(local + 26) +
      bytes.readUInt16LE(local + 28);
    const compressed = bytes.subarray(start, start + size);
    assert.ok(method === 0 || method === 8);
    assert.ok(
      !result.has(name) &&
        !name.startsWith("/") &&
        !name.includes("..") &&
        !name.includes("\\"),
      name,
    );
    result.set(name, method === 0 ? compressed : inflateRawSync(compressed));
    offset +=
      46 +
      nameLength +
      bytes.readUInt16LE(offset + 30) +
      bytes.readUInt16LE(offset + 32);
  }
  assert.equal(result.size, count);
  return result;
}

async function fixture(context) {
  const authorizations = [];
  const externalRequests = [];
  await context.route(
    (url) => url.origin !== origin,
    (route) => {
      externalRequests.push(route.request().url());
      return route.abort();
    },
  );
  await context.route("**/api/**", (route) => {
    const pathname = new URL(route.request().url()).pathname;
    const json = (body, status = 200) =>
      route.fulfill({
        status,
        contentType: "application/json",
        headers: { "Cache-Control": "no-store" },
        body: JSON.stringify(body),
      });
    if (pathname === "/api/auth/v1/methods")
      return json({
        version: "auth.v1",
        methods: {
          google: { available: true },
          github: { available: true },
          emailOtp: { available: false },
        },
      });
    if (pathname.startsWith("/api/account/")) {
      if (pathname.endsWith("/authorize")) {
        const { operationId } = route.request().postDataJSON();
        const issuedAt = new Date().toISOString();
        authorizations.push(operationId);
        return json({
          operationId,
          issuedAt,
          retryExpiresAt: new Date(
            Date.parse(issuedAt) + 172_800_000,
          ).toISOString(),
          remaining: 4,
          nextAvailableAt: null,
        });
      }
      return json({
        email: "export-load@example.test",
        displayName: "Fictitious load fixture",
        connectedProviders: ["google"],
        policyAuthorizationRequired: false,
        ownerKey: `v1:${"a".repeat(64)}`,
        sessionKey: `v1:${"1".repeat(64)}`,
        expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
        remaining: 5,
        nextAvailableAt: null,
      });
    }
    if (pathname === "/api/admin/blog/session")
      return json({ actor: null, canPublish: false });
    return json({ error: { code: "fixture_not_implemented" } }, 404);
  });
  return { authorizations, externalRequests };
}

async function observe(page) {
  await page.evaluate(() => {
    const metrics = {
      timerPeriodMs: 10,
      timerGaps: [],
      frames: [],
      trustedKeys: [],
      longTasks: [],
      zipStart: null,
      zipEnd: null,
      finished: false,
    };
    window.__exportLoadMetrics = metrics;
    let previous = performance.now();
    const interval = setInterval(() => {
      const now = performance.now();
      metrics.timerGaps.push({
        start: previous,
        end: now,
        gap: now - previous,
      });
      previous = now;
    }, metrics.timerPeriodMs);
    const frame = (time) => {
      metrics.frames.push(time);
      if (!metrics.finished) requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
    document.addEventListener(
      "keydown",
      (event) => {
        if (event.isTrusted)
          metrics.trustedKeys.push({
            key: event.key,
            time: performance.now(),
            wallTime: Date.now(),
            target: document.activeElement?.tagName,
          });
      },
      true,
    );
    document.addEventListener(
      "focusin",
      () => {
        metrics.lastFocus = {
          time: performance.now(),
          tag: document.activeElement?.tagName,
          label:
            document.activeElement?.getAttribute("aria-label") ??
            document.activeElement?.textContent?.trim().slice(0, 80),
        };
      },
      true,
    );
    try {
      new PerformanceObserver((list) => {
        for (const entry of list.getEntries())
          metrics.longTasks.push({
            start: entry.startTime,
            duration: entry.duration,
          });
      }).observe({ type: "longtask", buffered: false });
    } catch {
      metrics.longTaskObserverUnavailable = true;
    }
    const original = Response.prototype.blob;
    Response.prototype.blob = function (...args) {
      if (!this.headers.get("content-type")?.includes("application/zip"))
        return original.apply(this, args);
      metrics.zipStart = performance.now();
      console.debug("ACCREATIO_EXPORT_LOAD_ZIP_START");
      const result = original.apply(this, args);
      result.then(
        () => {
          metrics.zipEnd = performance.now();
        },
        () => {
          metrics.zipError = true;
        },
      );
      return result;
    };
    window.__stopExportLoadMetrics = () => {
      metrics.finished = true;
      clearInterval(interval);
      return metrics;
    };
  });
}

function summarize(metrics, start, end) {
  const gaps = metrics.timerGaps
    .filter((tick) => tick.start < end && tick.end > start)
    .map((tick) => tick.gap)
    .sort((a, b) => a - b);
  const frames = metrics.frames.filter((time) => time >= start && time <= end);
  const frameGaps = frames.slice(1).map((time, index) => time - frames[index]);
  return {
    durationMs: end - start,
    timerTicks: gaps.length,
    timerPeriodMs: metrics.timerPeriodMs,
    maxTimerGapMs: gaps.length ? Math.max(...gaps) : null,
    p95TimerGapMs: gaps.length
      ? gaps[Math.min(gaps.length - 1, Math.ceil(gaps.length * 0.95) - 1)]
      : null,
    animationFrames: frames.length,
    maxFrameGapMs: frameGaps.length ? Math.max(...frameGaps) : null,
    longTasks: metrics.longTasks.filter(
      (task) => task.start < end && task.start + task.duration > start,
    ),
  };
}

try {
  const deadline = Date.now() + 20_000;
  while (true) {
    try {
      if ((await fetch(origin)).ok) break;
    } catch {}
    if (Date.now() > deadline)
      throw new Error("Preview unavailable on port 4185");
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  browser = await chromium.launch({ channel: "msedge", headless: true });
  report.environment.browserVersion = browser.version();
  for (const spec of [
    { id: "20-files-100-mib", count: 20, perFile: 5 * MiB },
    { id: "1-file-20-mib", count: 1, perFile: 20 * MiB },
  ]) {
    const result = {
      id: spec.id,
      status: "RUNNING",
      attachmentCount: spec.count,
      attachmentBytesEach: spec.perFile,
      attachmentBytesTotal: spec.count * spec.perFile,
      attachments: [],
    };
    report.cases.push(result);
    const paths = [];
    for (let index = 0; index < spec.count; index++) {
      const name = `fictitious-load-${String(index + 1).padStart(2, "0")}.txt`;
      const bytes = Buffer.allocUnsafe(spec.perFile);
      bytes.fill(
        `FICTITIOUS ACCREATIO LOAD CASE ${spec.id} FILE ${index + 1}; NO USER DATA.\n`,
      );
      const target = path.join(cacheDirectory, spec.id, name);
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, bytes);
      result.attachments.push({
        name,
        expectedBytes: bytes.length,
        expectedSha256: sha256(bytes),
      });
      paths.push(target);
    }
    const context = await browser.newContext({
      viewport: report.environment.viewport,
      reducedMotion: "reduce",
      serviceWorkers: "block",
      acceptDownloads: true,
    });
    const backend = await fixture(context);
    const page = await context.newPage();
    const errors = [];
    page.on("pageerror", (error) => errors.push(error.message));
    await page.goto(`${origin}/?view=project&lang=en`);
    await page.locator('[data-question="name"]').waitFor();
    await page.locator("#project-name").fill(spec.id);
    await page.locator(".guided-creation__continue").click();
    await page.getByRole("button", { name: /I'm exploring the idea/ }).click();
    await page.locator('[data-question="attachments"]').waitFor();
    const chooserPromise = page.waitForEvent("filechooser");
    await page
      .getByRole("button", { name: "Add local files", exact: true })
      .click();
    const selectedAt = Date.now();
    await (await chooserPromise).setFiles(paths);
    await page
      .getByRole("button", {
        name: `Remove ${result.attachments.at(-1).name}`,
        exact: true,
      })
      .waitFor();
    result.attachmentSelectionMs = Date.now() - selectedAt;
    assert.equal(
      await page
        .locator(".attachments > span:not(.attachment-rejected)")
        .count(),
      spec.count,
    );
    assert.equal(await page.locator(".attachment-rejected").count(), 0);
    result.attachmentSummary = (
      await page.locator(".attachment-summary").textContent()
    ).trim();
    assert.ok(result.attachmentSummary.includes(`${spec.count} / 20`));
    assert.ok(
      result.attachmentSummary.includes(
        `${(spec.count * spec.perFile) / MiB}.0 / 100 MiB`,
      ),
    );
    if (spec.count === 20)
      assert.equal(
        await page
          .getByRole("button", { name: "Add local files", exact: true })
          .isDisabled(),
        true,
      );
    result.limits = {
      maxCount: 20,
      maxFileBytes: 20 * MiB,
      maxTotalBytes: 100 * MiB,
      exactCountBoundaryAccepted: spec.count === 20,
      exactFileBoundaryAccepted: spec.perFile === 20 * MiB,
      exactTotalBoundaryAccepted: spec.count * spec.perFile === 100 * MiB,
    };
    await page.locator(".guided-creation__continue").click();
    await page
      .locator("#project-context")
      .fill(
        "Fictitious offline tool library; measure real ZIP generation with reference files. No paid services, personal data or publication.",
      );
    await page.locator(".guided-creation__continue").click();
    await page.locator(".guided-creation__continue").click();
    await page.locator('[data-question="review"]').waitFor();
    await page
      .getByRole("checkbox", { name: "Check the package without downloading" })
      .uncheck();
    await page.locator(".review-stage__confirm button").click();
    await page.getByRole("dialog").waitFor();
    assert.equal(await page.getByRole("dialog").getByRole("radio").count(), 0);
    await observe(page);
    await page.waitForTimeout(300);
    await page.evaluate(() => {
      window.__exportLoadMetrics.confirmAt = performance.now();
    });
    let trustedKeyRequestedAt;
    let keyPromise;
    page.on("console", (message) => {
      if (message.text() !== "ACCREATIO_EXPORT_LOAD_ZIP_START") return;
      trustedKeyRequestedAt = Date.now();
      keyPromise = page.keyboard.press("Tab");
    });
    const downloadPromise = page.waitForEvent("download", { timeout: 60_000 });
    const confirmedAt = Date.now();
    await page.locator(".modal-actions .confirm").click();
    const download = await downloadPromise;
    await keyPromise;
    const downloadedPath = path.join(cacheDirectory, `${spec.id}.zip`);
    await download.saveAs(downloadedPath);
    assert.equal(await download.failure(), null);
    await page
      .getByRole("heading", {
        name: "ZIP prepared; download requested",
        exact: true,
      })
      .waitFor();
    result.confirmationToDownloadedAndSuccessMs = Date.now() - confirmedAt;
    const metrics = await page.evaluate(() => window.__stopExportLoadMetrics());
    assert.ok(metrics.zipStart !== null && metrics.zipEnd > metrics.zipStart);
    result.idle = summarize(
      metrics,
      metrics.timerGaps[0].start,
      metrics.confirmAt,
    );
    result.archiveGeneration = summarize(
      metrics,
      metrics.zipStart,
      metrics.zipEnd,
    );
    result.confirmationThroughArchive = summarize(
      metrics,
      metrics.confirmAt,
      metrics.zipEnd,
    );
    result.trustedKeysDuringArchive = metrics.trustedKeys.filter(
      (key) => key.time >= metrics.zipStart && key.time <= metrics.zipEnd,
    );
    result.trustedKeyRequestToArrivalMs = result.trustedKeysDuringArchive.length
      ? result.trustedKeysDuringArchive[0].wallTime - trustedKeyRequestedAt
      : null;
    result.lastFocus = metrics.lastFocus;
    assert.ok(
      result.archiveGeneration.timerTicks > 0,
      "Timer must progress during actual archive generation",
    );
    assert.ok(
      result.archiveGeneration.animationFrames > 0,
      "Rendering must progress during actual archive generation",
    );
    assert.ok(
      result.trustedKeysDuringArchive.some((key) => key.key === "Tab"),
      "Actual browser key must be handled during archive generation",
    );
    const zipBytes = await readFile(downloadedPath);
    const entries = unzip(zipBytes);
    result.zip = {
      cachePath: path.relative(root, downloadedPath),
      bytes: zipBytes.length,
      sha256: sha256(zipBytes),
      entries: entries.size,
    };
    const attachmentEntries = [...entries].filter(([name]) =>
      name.includes("/docs/product/sources/"),
    );
    assert.equal(attachmentEntries.length, spec.count);
    for (const attachment of result.attachments) {
      const pair = attachmentEntries.find(([name]) =>
        name.endsWith(`/${attachment.name}`),
      );
      assert.ok(pair, attachment.name);
      const original = await readFile(
        paths[result.attachments.indexOf(attachment)],
      );
      assert.equal(pair[1].length, attachment.expectedBytes);
      assert.ok(pair[1].equals(original), `Byte mismatch: ${attachment.name}`);
      attachment.actualSha256 = sha256(pair[1]);
      assert.equal(attachment.actualSha256, attachment.expectedSha256);
      attachment.byteComparison = "PASS";
    }
    const signature = JSON.parse(
      [...entries]
        .find(([name]) => name.endsWith("/.accreatio/project.json"))[1]
        .toString("utf8"),
    );
    assert.equal(signature.appVersion, report.candidate.appVersion);
    assert.deepEqual(
      signature.sourceFiles,
      result.attachments.map((attachment) => attachment.name),
    );
    assert.equal(backend.authorizations.length, 1);
    assert.deepEqual(backend.externalRequests, []);
    assert.deepEqual(errors, []);
    result.authorization =
      "One synthetic fixture authorization; no real quota claim.";
    result.status = "PASS";
    result.completedAt = new Date().toISOString();
    console.log(
      `PASS ${spec.id}: ${result.zip.bytes} ZIP bytes, archive ${result.archiveGeneration.durationMs.toFixed(1)} ms, max timer gap ${result.archiveGeneration.maxTimerGapMs.toFixed(1)} ms, trusted Tab ${result.trustedKeyRequestToArrivalMs} ms; all ${spec.count} attachments byte/hash equal.`,
    );
    await saveReport();
    await context.close();
  }
  report.status = "PASS";
  report.completedAt = new Date().toISOString();
  report.interpretation =
    "Both requested boundary exports completed and retained every attachment byte. Timers, frames and a trusted key progressed during actual archive generation. Measurements describe this machine, built candidate and fixture run only. No earlier-code baseline, universal performance guarantee, real-backend/production load, physical-device result or paid service was used.";
} catch (error) {
  report.status = "FAIL";
  report.error = error instanceof Error ? error.message : String(error);
  report.completedAt = new Date().toISOString();
  throw error;
} finally {
  await saveReport();
  await browser?.close().catch(() => {});
  server.kill();
}
