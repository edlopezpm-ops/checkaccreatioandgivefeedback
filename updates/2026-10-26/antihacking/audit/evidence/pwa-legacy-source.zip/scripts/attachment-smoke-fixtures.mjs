import assert from "node:assert/strict";
import { strToU8, unzipSync, zipSync } from "fflate";

const escapeXml = (value) =>
  value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");

export function minimalDocx(content) {
  const files = {
    "[Content_Types].xml": `<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>`,
    "_rels/.rels": `<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`,
    "word/document.xml": `<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>${escapeXml(content)}</w:t></w:r></w:p></w:body></w:document>`,
  };
  return Buffer.from(
    zipSync(
      Object.fromEntries(
        Object.entries(files).map(([name, text]) => [name, strToU8(text)]),
      ),
      { mtime: new Date(1980, 0, 1) },
    ),
  );
}

export function assertSameDocxParts(actual, expected) {
  assert.ok(
    actual,
    "The reconstructed DOCX must be present in the exported ZIP.",
  );
  const actualParts = unzipSync(actual);
  const expectedParts = unzipSync(expected);
  assert.deepEqual(
    Object.keys(actualParts).sort(),
    Object.keys(expectedParts).sort(),
  );
  for (const name of Object.keys(expectedParts))
    assert.deepEqual(actualParts[name], expectedParts[name], name);
}
