// Lighthouse quality gate against the real production build (dist/).
//
// Why not `@lhci/cli`: its `collect` command launches Chrome through
// chrome-launcher, whose Windows temp-profile cleanup (`Launcher.kill` ->
// `destroyTmp`) reproducibly fails with EPERM in this environment even
// against a normal system-installed Edge, before it ever writes a report --
// a known class of chrome-launcher/Windows flakiness, not something this
// script's config can route around. Playwright manages the browser
// lifecycle reliably (already proven throughout this project's manual
// verification work), so this script drives Lighthouse's own programmatic
// API against a Playwright-launched, already-running Chromium instead of
// letting chrome-launcher own the process.
//
// Also note: Lighthouse no longer scores a "pwa" category (removed
// upstream; installability/service-worker are manual DevTools checks now).
// This gate covers performance/accessibility/best-practices/seo only --
// offline/installable behavior is verified separately, by hand, with
// Playwright (see docs/PHASE_P2_PILOT_EVIDENCE.md and PROGRAM_P0's P2.3
// notes for that evidence).

import { chromium } from "playwright";
import lighthouse from "lighthouse";
import { spawn } from "node:child_process";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const PORT = 4174;
const URL = `http://localhost:${PORT}/index.html`;
const REPORT_DIR = path.join(ROOT, ".local", "logs", "lighthouse");

const THRESHOLDS = {
  performance: 0.8,
  accessibility: 0.9,
  "best-practices": 0.9,
  seo: 0.9,
};

// The W1 beta is intentionally private and non-indexable. Lighthouse treats
// that release control as an SEO failure, so exempt only this exact audit while
// keeping every other weighted SEO audit subject to the normal threshold.
const INTENTIONAL_SEO_EXEMPTIONS = new Set(["is-crawlable"]);

function waitForServer(url, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  return new Promise((resolve, reject) => {
    const attempt = () => {
      fetch(url)
        .then(() => resolve())
        .catch((err) => {
          if (Date.now() > deadline) reject(err);
          else setTimeout(attempt, 500);
        });
    };
    attempt();
  });
}

async function main() {
  const preview = spawn(
    process.execPath,
    [
      path.join(ROOT, "node_modules", "vite", "bin", "vite.js"),
      "preview",
      "--host",
      "127.0.0.1",
      "--port",
      String(PORT),
      "--strictPort",
    ],
    { cwd: ROOT, stdio: "ignore" },
  );
  let browser;
  try {
    await waitForServer(`http://localhost:${PORT}`, 30_000);

    browser = await chromium.launch({
      args: [`--remote-debugging-port=9222`],
    });

    const runnerResult = await lighthouse(
      URL,
      { port: 9222, output: "json", logLevel: "error" },
      undefined,
    );
    if (!runnerResult) throw new Error("Lighthouse produced no result");

    const { categories } = runnerResult.lhr;
    await mkdir(REPORT_DIR, { recursive: true });
    await writeFile(
      path.join(REPORT_DIR, "lhr.json"),
      runnerResult.report,
      "utf8",
    );

    let failed = false;
    for (const [key, minScore] of Object.entries(THRESHOLDS)) {
      const score = categories[key]?.score;
      const pct =
        score === null || score === undefined ? "n/a" : Math.round(score * 100);
      const weightedFailures =
        key === "seo"
          ? (categories.seo?.auditRefs ?? []).filter((auditRef) => {
              const audit = runnerResult.lhr.audits[auditRef.id];
              return auditRef.weight > 0 && audit?.score !== 1;
            })
          : [];
      const intentionalPrivateBetaResult =
        key === "seo" &&
        weightedFailures.length > 0 &&
        weightedFailures.every((auditRef) =>
          INTENTIONAL_SEO_EXEMPTIONS.has(auditRef.id),
        );
      const ok =
        (typeof score === "number" && score >= minScore) ||
        intentionalPrivateBetaResult;
      if (!ok) failed = true;
      console.log(
        `${ok ? "PASS" : "FAIL"} ${key}: ${pct}${pct === "n/a" ? "" : "/100"} (min ${Math.round(minScore * 100)}${intentionalPrivateBetaResult ? "; intentional private-beta noindex" : ""})`,
      );
    }
    if (failed) {
      console.error(
        "\nLighthouse gate failed. Full report: .local/logs/lighthouse/lhr.json",
      );
      process.exitCode = 1;
    } else {
      console.log("\nLighthouse gate passed.");
    }
  } finally {
    if (browser) await browser.close().catch(() => {});
    preview.kill();
  }
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
