import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("..", import.meta.url));
const manifest = JSON.parse(
  await readFile(path.join(root, "assets/aekr-branding.json"), "utf8"),
);
const digest = (bytes, text) =>
  createHash("sha256")
    .update(text ? bytes.toString("utf8").replaceAll("\r\n", "\n") : bytes)
    .digest("hex");

// Local validation is offline. AEKR_PATH additionally checks the actual upstream
// copies; it never downloads, renders, rewrites, or accepts replacement artwork.
for (const asset of manifest.assets) {
  const local = await readFile(path.join(root, asset.local));
  assert.equal(
    digest(local, asset.text),
    asset.sha256,
    `${asset.local}: AEKR artwork/source changed; restore the pinned original.`,
  );
  if (process.env.AEKR_PATH) {
    const upstream = await readFile(
      path.join(process.env.AEKR_PATH, asset.source),
    );
    assert.equal(
      digest(upstream, asset.text),
      asset.sha256,
      `${asset.source}: upstream differs from this reviewed asset version.`,
    );
  }
}
console.log(
  `PASS AEKR branding integrity (${manifest.assets.length} pinned files${process.env.AEKR_PATH ? ", upstream checked" : ", local offline check"})`,
);
