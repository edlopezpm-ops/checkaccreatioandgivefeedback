import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { createServer } from "node:http";
import { cp, mkdir, mkdtemp, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { parseArgs } from "node:util";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

// Use real, separately built bundles; do not replace the legacy app with a
// synthetic updater. Candidate defaults to the normal web build in dist/.
const { values } = parseArgs({
  options: {
    "legacy-dir": { type: "string" },
    "waiting-dir": { type: "string" },
    "candidate-dir": { type: "string", default: "dist" },
  },
});
assert.ok(
  values["legacy-dir"] && values["waiting-dir"],
  "Usage: node scripts/pwa-upgrade-smoke.mjs --legacy-dir <old build> --waiting-dir <prompt-update build> [--candidate-dir dist]",
);
const root = fileURLToPath(new URL("../", import.meta.url));
await mkdir(path.join(root, ".local/cache"), { recursive: true });
const scratch = await mkdtemp(path.join(root, ".local/cache/pwa-regression-"));
const evidence = path.join(root, ".local/logs", path.basename(scratch));
await mkdir(evidence, { recursive: true });
const bundles = {};
for (const name of ["legacy", "waiting", "candidate"]) {
  const source = path.resolve(root, values[`${name}-dir`]);
  const destination = path.join(scratch, name);
  await cp(source, destination, { recursive: true, errorOnExist: true });
  const html = await readFile(path.join(destination, "index.html"), "utf8");
  const worker = await readFile(path.join(destination, "sw.js"), "utf8");
  const entry = html.match(/<script\b[^>]*type="module"[^>]*src="([^"]+)"/);
  assert.ok(entry, `${name} must contain the actual built application entry`);
  bundles[name] = {
    source,
    destination,
    entry: entry[1].replace(/^\.\//, ""),
    workerHash: createHash("sha256").update(worker).digest("hex"),
  };
}
assert.notEqual(bundles.legacy.entry, bundles.waiting.entry);
assert.notEqual(bundles.waiting.entry, bundles.candidate.entry);

let stage = "legacy";
let otpRequests = 0;
let accountVerified = true;
const account = {
  email: "pwa-fixture@example.test",
  policyAuthorizationRequired: false,
  ownerKey: `v1:${"a".repeat(64)}`,
  sessionKey: `v1:${"1".repeat(64)}`,
  expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
  remaining: 5,
  nextAvailableAt: null,
};
const server = createServer(async (request, response) => {
  const url = new URL(request.url, "http://localhost");
  const json = (value, status = 200) => {
    response.writeHead(status, {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
    });
    response.end(JSON.stringify(value));
  };
  // This suite isolates worker lifecycle; the account suite exercises real OTP.
  if (url.pathname === "/api/auth/v1/methods")
    return json({
      version: "auth.v1",
      methods: { google: { available: false }, emailOtp: { available: true } },
    });
  if (url.pathname === "/api/account/otp/request") {
    otpRequests++;
    return json({
      challengeId: "pwa-fixture-challenge",
      expiresAt: new Date(Date.now() + 600_000).toISOString(),
      resendAt: new Date(Date.now() + 60_000).toISOString(),
    });
  }
  if (url.pathname === "/api/account/otp/verify") {
    accountVerified = true;
    return json(account);
  }
  if (url.pathname === "/api/account/session")
    return accountVerified
      ? json(account)
      : json({ error: { code: "sign_in_required" } }, 401);
  if (url.pathname === "/api/admin/blog/session")
    return json({ error: { code: "sign_in_required" } }, 401);
  if (url.pathname === "/api/blog/posts") return json({ posts: [] });

  const bundle = bundles[stage.startsWith("candidate") ? "candidate" : stage];
  const relative = url.pathname === "/" ? "index.html" : url.pathname.slice(1);
  const target = path.resolve(bundle.destination, relative);
  if (!target.startsWith(bundle.destination + path.sep)) {
    response.writeHead(403);
    response.end();
    return;
  }
  try {
    let bytes = await readFile(target);
    if (url.pathname === "/sw.js") {
      // Observes installation/activation without changing lifecycle behavior.
      // A second candidate stamp exercises another update with identical app code.
      bytes = Buffer.concat([
        bytes,
        Buffer.from(
          `\nself.__pwaProbeStage=${JSON.stringify(stage)};self.__pwaProbeActivated=false;self.addEventListener('activate',()=>{self.__pwaProbeActivated=true;});\n`,
        ),
      ]);
    }
    const type =
      {
        ".html": "text/html",
        ".js": "application/javascript",
        ".css": "text/css",
        ".json": "application/json",
        ".svg": "image/svg+xml",
        ".png": "image/png",
        ".webmanifest": "application/manifest+json",
      }[path.extname(target)] ?? "application/octet-stream";
    response.writeHead(200, {
      "Content-Type": type,
      "Cache-Control": "no-store",
    });
    response.end(bytes);
  } catch {
    response.writeHead(404);
    response.end();
  }
});
await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
const browser = await chromium.launch({ headless: true });
const dialogs = [];
const errors = [];
const navigations = [];
const receipt = {
  bundles,
  origin,
  authentication:
    "local fixture; this test verifies worker navigation, not OTP",
  dialogs,
  navigations,
  errors,
};
let page;

async function until(predicate, message, timeout = 10_000) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    try {
      if (await predicate()) return;
    } catch {
      // Navigation may replace the evaluation context during the legacy loop.
    }
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  assert.fail(message);
}
async function newContext() {
  const context = await browser.newContext({
    viewport: { width: 1280, height: 800 },
  });
  context.setDefaultTimeout(10_000);
  await context.addInitScript(() => {
    window.__pwaDocumentId = `${Date.now()}-${Math.random()}`;
  });
  context.on("page", (opened) => {
    opened.on("pageerror", (error) => errors.push(error.message));
    opened.on("framenavigated", (frame) => {
      if (frame === opened.mainFrame())
        navigations.push({ stage, url: frame.url() });
    });
    opened.on("dialog", async (dialog) => {
      const accept = stage === "waiting" && dialogs.length < 2;
      dialogs.push({ stage, message: dialog.message(), accepted: accept });
      if (accept) await dialog.accept();
      else await dialog.dismiss();
    });
  });
  return context;
}
const documentEntry = (target) =>
  target.evaluate(
    () => document.querySelector('script[type="module"][src]')?.src,
  );
const documentId = (target) => target.evaluate(() => window.__pwaDocumentId);
const savedName = (target) =>
  target.evaluate(
    () =>
      new Promise((resolve, reject) => {
        const request = indexedDB.open("accreatio-drafts");
        request.onerror = () => reject(request.error);
        request.onsuccess = () => {
          const db = request.result;
          const read = db
            .transaction("drafts")
            .objectStore("drafts")
            .get(
              localStorage.getItem("accreatio:draft-context:v1")
                ? "account-current:v1"
                : "current",
            );
          read.onerror = () => {
            db.close();
            reject(read.error);
          };
          read.onsuccess = () => {
            resolve(read.result?.project?.name ?? null);
            db.close();
          };
        };
      }),
  );
async function activated(context, expectedStage) {
  for (const worker of context.serviceWorkers()) {
    try {
      if (
        await worker.evaluate(
          (expected) =>
            self.__pwaProbeStage === expected && self.__pwaProbeActivated,
          expectedStage,
        )
      )
        return true;
    } catch {}
  }
  return false;
}
async function requestUpdate(target) {
  await target
    .evaluate(() =>
      navigator.serviceWorker
        .getRegistration()
        .then((registration) => registration.update()),
    )
    .catch(() => {});
}

try {
  const legacyContext = await newContext();
  page = await legacyContext.newPage();
  await page.goto(origin);
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.reload();
  await until(
    () =>
      documentEntry(page).then((entry) =>
        entry?.endsWith(bundles.legacy.entry),
      ),
    "Actual legacy bundle must be loaded",
  );
  await page.getByRole("button", { name: "New project", exact: true }).click();
  const legacyDraft = "Legacy draft survives same-tab recovery";
  await page.locator("#project-name").fill(legacyDraft);
  await until(
    () => savedName(page).then((name) => name === legacyDraft),
    "Legacy draft must be persisted before the update",
  );

  stage = "waiting";
  await requestUpdate(page);
  await until(
    () => dialogs.length >= 3,
    "Legacy updater must reproduce two accepted reloads and a repeated prompt",
  );
  await page.locator(".app-shell").waitFor();
  assert.ok((await documentEntry(page)).endsWith(bundles.legacy.entry));
  assert.ok(
    await page.evaluate(async () =>
      Boolean((await navigator.serviceWorker.getRegistration())?.waiting),
    ),
  );
  assert.equal(await savedName(page), legacyDraft);
  receipt.baseline = {
    repeatedPrompts: dialogs.length,
    waiting: true,
    legacyBundleRetained: true,
  };
  await page.screenshot({ path: path.join(evidence, "legacy-loop.png") });

  stage = "candidate-1";
  const legacyDocument = await documentId(page);
  const promptCount = dialogs.length;
  // A normal navigation must discover the deployed repair. Do not use a
  // DevTools-style registration.update() call to recover the legacy client.
  await page.reload();
  await until(
    () => activated(legacyContext, stage),
    "Candidate must activate without closing any tabs",
  );
  await new Promise((resolve) => setTimeout(resolve, 800));
  receipt.legacyActivationReloaded =
    (await documentId(page)) !== legacyDocument;
  if (!(await documentEntry(page))?.endsWith(bundles.candidate.entry))
    await page.reload();
  await until(
    () =>
      documentEntry(page).then((entry) =>
        entry?.endsWith(bundles.candidate.entry),
      ),
    "Same-tab deliberate navigation must reach candidate bundle",
  );
  await page.getByRole("button", { name: "New project", exact: true }).click();
  await until(
    () =>
      page
        .locator("#project-name")
        .inputValue()
        .then((value) => value === ""),
    "Upgrade must discard a legacy draft without account/session ownership",
  );
  assert.ok(
    dialogs.length <= promptCount + 1,
    "Only the legacy waiting prompt may recur once during normal navigation",
  );
  const ownedDraft = "Verified session draft after upgrade";
  await page.locator("#project-name").fill(ownedDraft);
  const recoveredPromptCount = dialogs.length;
  assert.equal(
    legacyContext.pages().length,
    1,
    "Recovery keeps the original tab open",
  );
  await page.screenshot({
    path: path.join(evidence, "candidate-same-tab.png"),
  });

  const freshContext = await newContext();
  const fresh = await freshContext.newPage();
  await fresh.goto(origin);
  await fresh.evaluate(() => navigator.serviceWorker.ready);
  await until(
    () => activated(freshContext, stage),
    "Fresh candidate worker must activate",
  );
  await fresh.getByRole("button", { name: "New project", exact: true }).click();
  await fresh
    .locator("#project-name")
    .fill("Fresh candidate keeps its current draft");
  const stableDocuments = [await documentId(page), await documentId(fresh)];
  stage = "candidate-2";
  await Promise.all([requestUpdate(page), requestUpdate(fresh)]);
  await until(
    async () =>
      (await activated(legacyContext, stage)) &&
      (await activated(freshContext, stage)),
    "Subsequent candidate workers must activate",
  );
  await new Promise((resolve) => setTimeout(resolve, 800));
  assert.deepEqual(
    [await documentId(page), await documentId(fresh)],
    stableDocuments,
    "Candidate updates must never reload either open document",
  );
  assert.equal(
    dialogs.length,
    recoveredPromptCount,
    "Fresh and subsequent candidate updates have no dialogs",
  );
  assert.equal(
    await fresh.locator("#project-name").inputValue(),
    "Fresh candidate keeps its current draft",
  );
  await until(
    () =>
      savedName(fresh).then(
        (name) => name === "Fresh candidate keeps its current draft",
      ),
    "Background update preserves draft persistence",
  );

  const authenticationDocument = await documentId(page);
  accountVerified = false;
  await page.evaluate(() =>
    window.dispatchEvent(new Event("accreatio:session-invalid")),
  );
  await page.locator("#web-email").fill(account.email);
  const policyNotice = page.locator(".web-signin__policy");
  await policyNotice.waitFor();
  assert.match(
    await policyNotice.innerText(),
    /By continuing, you accept the AEKR Terms/,
  );
  assert.match(
    await policyNotice.innerText(),
    /By continuing, you authorize AEKR/,
  );
  assert.equal(await policyNotice.getByRole("checkbox").count(), 0);
  const sendCode = page.getByRole("button", { name: "Send code", exact: true });
  assert.equal(await sendCode.isEnabled(), true);
  assert.equal(otpRequests, 0);
  await sendCode.click();
  await page.locator("#web-otp").fill("123456");
  await page
    .getByRole("button", { name: "Verify and continue", exact: true })
    .click();
  await page.locator("#project-name").waitFor();
  await until(
    () =>
      page
        .locator("#project-name")
        .inputValue()
        .then((name) => name === ownedDraft),
    "Inline OTP preserves the verified owner draft",
  );
  assert.equal(
    otpRequests,
    1,
    "Controlling worker must send the OTP request to the network",
  );
  assert.equal(
    await documentId(page),
    authenticationDocument,
    "OTP reauthentication must preserve the open document",
  );
  assert.deepEqual(
    errors,
    [],
    "No application errors are allowed during the transition",
  );
  receipt.result = "PASS";
  receipt.recovery = {
    tabsClosed: 0,
    publicPreferencesCleared: false,
    unownedLegacyDraftDiscarded: true,
    verifiedSessionDraftRetained: true,
    otpRequests,
  };
  receipt.nextUpdate = { automaticReloads: 0, dialogs: 0, draftRetained: true };
  await writeFile(
    path.join(evidence, "receipt.json"),
    JSON.stringify(receipt, null, 2),
  );
  process.stdout.write(
    `PASS PWA upgrade: legacy repeated-confirm regression, same-tab recovery, legacy ownership purge, verified-session drafts, no candidate update reloads, inline OTP. Evidence: ${evidence}\n`,
  );
} catch (error) {
  receipt.result = "FAIL";
  receipt.failure = String(error);
  await writeFile(
    path.join(evidence, "receipt.json"),
    JSON.stringify(receipt, null, 2),
  );
  if (page && !page.isClosed())
    await page
      .screenshot({ path: path.join(evidence, "failure.png") })
      .catch(() => {});
  throw error;
} finally {
  await browser.close();
  await new Promise((resolve) => server.close(resolve));
}
