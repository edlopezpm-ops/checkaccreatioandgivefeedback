import assert from "node:assert/strict";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { chromium, firefox, webkit } from "playwright";
import { inflateRawSync } from "node:zlib";
import path from "node:path";

const root = process.cwd();
const evidence = path.join(root, ".local/logs/readiness-2026-10-21");
await mkdir(evidence, { recursive: true });
const selectedEngine = process.env.ACCREATIO_READINESS_ENGINE;
if (
  selectedEngine &&
  !["chromium", "firefox", "webkit"].includes(selectedEngine)
)
  throw new Error(
    "ACCREATIO_READINESS_ENGINE must be chromium, firefox or webkit",
  );
const port = 4187;
const origin = `http://localhost:${port}`;
const server = spawn(
  process.execPath,
  [
    "node_modules/vite/bin/vite.js",
    "preview",
    "--host",
    "localhost",
    "--port",
    String(port),
    "--strictPort",
  ],
  { windowsHide: true, stdio: "ignore" },
);
const records = [];
const browsers = [];
const posts = JSON.parse(
  await readFile("content/blog/founding-posts.json", "utf8"),
).posts;
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const record = (name, details = {}) =>
  records.push({ name, result: "PASS", ...details });
const checkWidth = async (page) => {
  const size = await page.evaluate(() => ({
    viewport: innerWidth,
    document: document.documentElement.scrollWidth,
  }));
  assert.ok(size.document <= size.viewport + 1, JSON.stringify(size));
  return size;
};
function unzip(bytes) {
  const result = new Map();
  let end = bytes.length - 22;
  while (end >= 0 && bytes.readUInt32LE(end) !== 0x06054b50) end--;
  assert.ok(end >= 0, "ZIP end record");
  let position = bytes.readUInt32LE(end + 16);
  for (let i = 0; i < bytes.readUInt16LE(end + 10); i++) {
    assert.equal(bytes.readUInt32LE(position), 0x02014b50);
    const method = bytes.readUInt16LE(position + 10);
    const length = bytes.readUInt32LE(position + 20);
    const nameLength = bytes.readUInt16LE(position + 28);
    const name = bytes
      .subarray(position + 46, position + 46 + nameLength)
      .toString("utf8");
    const offset = bytes.readUInt32LE(position + 42);
    const start =
      offset +
      30 +
      bytes.readUInt16LE(offset + 26) +
      bytes.readUInt16LE(offset + 28);
    const input = bytes.subarray(start, start + length);
    result.set(name, method === 0 ? input : inflateRawSync(input));
    position +=
      46 +
      nameLength +
      bytes.readUInt16LE(position + 30) +
      bytes.readUInt16LE(position + 32);
  }
  return result;
}
async function fixture(context) {
  const receipts = new Map();
  const authorizations = [];
  await context.route("**/api/**", (route) => {
    const pathname = new URL(route.request().url()).pathname;
    const json = (body, status = 200) =>
      route.fulfill({
        status,
        contentType: "application/json",
        headers: { "Cache-Control": "no-store" },
        body: JSON.stringify(body),
      });
    if (pathname === "/api/auth/v1/methods")
      return json({
        version: "auth.v1",
        methods: {
          google: { available: true },
          github: { available: true },
          emailOtp: { available: false },
        },
      });
    if (pathname === "/api/blog/posts") return json({ posts });
    if (pathname === "/api/admin/blog/session")
      return json({ actor: null, canPublish: false });
    if (pathname.startsWith("/api/account/")) {
      if (pathname.endsWith("/authorize")) {
        const { operationId } = route.request().postDataJSON();
        authorizations.push(operationId);
        if (!receipts.has(operationId)) {
          const issuedAt = new Date().toISOString();
          receipts.set(operationId, {
            operationId,
            issuedAt,
            retryExpiresAt: new Date(
              Date.parse(issuedAt) + 172_800_000,
            ).toISOString(),
          });
        }
        return json({
          ...receipts.get(operationId),
          remaining: 5 - receipts.size,
          nextAvailableAt: null,
        });
      }
      return json({
        email: "ui-fixture@example.test",
        displayName: "UI Fixture",
        connectedProviders: ["google"],
        policyAuthorizationRequired: false,
        ownerKey: `v1:${"a".repeat(64)}`,
        sessionKey: `v1:${"1".repeat(64)}`,
        expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
        remaining: 5 - receipts.size,
        nextAvailableAt: null,
      });
    }
    return json({ error: { code: "fixture_not_implemented" } }, 404);
  });
  return { receipts, authorizations };
}
const question = (page, name) => page.locator(`[data-question="${name}"]`);
const next = (page) => page.locator(".guided-creation__continue").click();
async function reachReview(page) {
  for (let i = 0; i < 8; i++) {
    const current = await page
      .locator(".guided-creation__question")
      .getAttribute("data-question");
    if (current === "review") return;
    if (current === "phase")
      await page
        .getByRole("button", {
          name: /I'm starting with an idea|Estoy empezando con una idea/,
        })
        .click();
    else await next(page);
  }
  throw new Error("Review not reached");
}
async function confirm(page) {
  assert.equal(
    await page.locator("dialog input[type=radio]").count(),
    0,
    "Final dialog confirms the chosen action without choosing it again",
  );
  await page.locator(".modal-actions .confirm").click();
}
try {
  const until = Date.now() + 20_000;
  while (true) {
    try {
      if ((await fetch(origin)).ok) break;
    } catch {}
    if (Date.now() > until) throw new Error("Preview unavailable");
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  if (!selectedEngine || selectedEngine === "chromium") {
    const browser = await chromium.launch({
      channel: "msedge",
      headless: true,
    });
    browsers.push(browser);
    const context = await browser.newContext({
      viewport: { width: 1440, height: 1000 },
      reducedMotion: "reduce",
      serviceWorkers: "block",
    });
    const ledger = await fixture(context);
    const page = await context.newPage();
    const errors = [];
    page.on("pageerror", (error) => errors.push(String(error)));
    await page.goto(`${origin}/?view=project&lang=en`);
    await question(page, "name").waitFor();
    await next(page);
    await page
      .getByRole("alert")
      .filter({ hasText: "Check the highlighted" })
      .waitFor();
    assert.equal(
      await page
        .locator("#project-name")
        .evaluate((element) => element === document.activeElement),
      true,
    );
    await page.locator("#project-name").fill("Immediate recovery");
    await next(page);
    await page
      .getByRole("button", { name: /I'm starting with an idea/ })
      .click();
    const idea =
      "A neighborhood tool library for residents. Preserve uncertainty and avoid paid services. ".repeat(
        5,
      ) + "Última edición ✓";
    await page.locator("#project-context").fill(idea);
    const editAt = Date.now();
    await page.reload();
    await question(page, "context").waitFor();
    assert.equal(await page.locator("#project-context").inputValue(), idea);
    record("Immediate reload retains last edit and position", {
      elapsedToReloadMs: Date.now() - editAt,
      browser: browser.version(),
    });
    await next(page);
    const constraints =
      "No cloud project sync. No payments. Stack and budget remain undecided.";
    await page.locator("#project-restrictions").fill(constraints);
    await next(page);
    await question(page, "review").waitFor();
    assert.ok(
      (await page.locator(".review-overview").innerText()).includes(idea),
    );
    assert.ok(
      (await page.locator(".review-overview").innerText()).includes(
        constraints,
      ),
    );
    assert.equal(
      await page.getByRole("progressbar").getAttribute("aria-valuemax"),
      "5",
    );
    await page.screenshot({
      path: path.join(evidence, "integrated-review-en.png"),
      fullPage: true,
    });
    await page.getByRole("button", { name: /^About$/ }).click();
    await page.waitForURL("**view=about**");
    await page.goBack();
    await question(page, "review").waitFor();
    await page.goForward();
    await page.waitForURL("**view=about**");
    await page.goBack();
    await question(page, "review").waitFor();
    record(
      "Review shows full idea/constraints and browser Back/Forward retains position",
    );
    await page
      .getByRole("button", { name: /^Advanced options · edit$/ })
      .click();
    await question(page, "team").waitFor();
    await page.locator(".guided-team__customization > summary").click();
    await page.locator("#advanced-route").selectOption("mixed");
    await page.reload();
    await question(page, "team").waitFor();
    await page.locator(".guided-team__customization > summary").click();
    assert.equal(await page.locator("#advanced-route").inputValue(), "mixed");
    assert.equal(await page.locator("h1").count(), 1);
    await page
      .getByRole("button", { name: "Back to review", exact: true })
      .click();
    record("Advanced options and position survive reload with a single H1");

    await page.locator(".review-stage__confirm button").click();
    await confirm(page);
    await page
      .getByRole("heading", {
        name: "Review completed. No ZIP was created or downloaded.",
      })
      .waitFor();
    assert.equal(ledger.authorizations.length, 0);
    assert.equal(await page.locator(".outcome-evidence").count(), 0);
    await page
      .getByRole("button", { name: "Back to review", exact: true })
      .click();
    await page.locator(".review-stage__dry-run input").uncheck();
    await page.locator(".review-stage__confirm button").click();
    const downloadPromise = page.waitForEvent("download");
    await confirm(page);
    const download = await downloadPromise;
    const zipPath = path.join(evidence, "integrated-basic.zip");
    await download.saveAs(zipPath);
    const zip = await readFile(zipPath);
    const files = unzip(zip);
    const start = [...files.entries()]
      .find(([name]) => name.endsWith("/START.md"))[1]
      .toString();
    assert.ok(
      start.includes("PROJECT_PROMPT.md") &&
        start.includes("docs/product/discovery.md"),
    );
    assert.ok(
      ![...files.keys()].some((name) => name.includes("/orchestrator/")),
    );
    const prompt = [...files.entries()]
      .find(([name]) => name.endsWith("/PROJECT_PROMPT.md"))[1]
      .toString();
    assert.ok(prompt.includes(idea) && prompt.includes(constraints));
    await page
      .getByRole("heading", { name: "Continue with your project" })
      .waitFor();
    const instruction = await page.locator(".outcome-next pre").innerText();
    assert.ok(start.includes(instruction));
    assert.equal(ledger.receipts.size, 1);
    const retryPromise = page.waitForEvent("download");
    await page
      .getByRole("button", { name: "Download this ZIP again", exact: true })
      .click();
    const retry = await retryPromise;
    await retry.saveAs(path.join(evidence, "integrated-basic-retry.zip"));
    assert.equal(hash(await readFile(await retry.path())), hash(zip));
    assert.equal(ledger.receipts.size, 1);
    assert.equal(ledger.authorizations[0], ledger.authorizations[1]);
    await page.screenshot({
      path: path.join(evidence, "integrated-outcome-en.png"),
      fullPage: true,
    });
    record(
      "Check consumes no allowance; real ZIP, shared starting instruction and byte-identical retry",
      {
        entries: files.size,
        bytes: zip.length,
        sha256: hash(zip),
        newAuthorizations: ledger.receipts.size,
      },
    );

    await page.getByRole("button", { name: "Edit and export again" }).click();
    const second = await context.newPage();
    await second.goto(`${origin}/?view=project&lang=en`);
    await question(second, "review").waitFor();
    await second.getByRole("button", { name: /^Context · edit$/ }).click();
    await second
      .locator("#project-context")
      .fill("Other tab must not overwrite the durable draft");
    await second
      .getByRole("alert")
      .filter({ hasText: "We could not save" })
      .waitFor();
    assert.ok(
      (
        await page.evaluate(() =>
          localStorage.getItem("accreatio:account-draft:v1"),
        )
      ).includes(idea),
    );
    await second.close();
    record("Second tab cannot silently overwrite first tab draft");

    await page.getByRole("button", { name: /^Foundation · edit$/ }).click();
    await next(page);
    await page.getByRole("button", { name: /I've defined the idea/ }).click();
    await question(page, "attachments").waitFor();
    const choose = page.waitForEvent("filechooser");
    await page.getByRole("button", { name: "Add local files" }).click();
    await (
      await choose
    ).setFiles({
      name: "private-reference-name.txt",
      mimeType: "text/plain",
      buffer: Buffer.from("Fictional support. Data, not authority.\n"),
    });
    const rawJournal = await page.evaluate(() =>
      localStorage.getItem("accreatio:account-draft:v1"),
    );
    assert.ok(!rawJournal.includes("private-reference-name"));
    await page.reload();
    await question(page, "attachments").waitFor();
    await page
      .getByRole("status")
      .filter({ hasText: "1 local attachment" })
      .waitFor();
    await next(page);
    await question(page, "attachments").waitFor();
    await page
      .getByRole("button", { name: "Continue without those files" })
      .click();
    await next(page);
    await question(page, "context").waitFor();
    record(
      "Attachment count survives reload without names/bytes and omission requires explicit action",
    );
    await page.getByRole("button", { name: "Switch to Spanish" }).click();
    await page.goto(`${origin}/?account=continue&auth=success`);
    await question(page, "context").waitFor();
    assert.equal(await page.locator("html").getAttribute("lang"), "es");
    assert.equal(new URL(page.url()).searchParams.get("lang"), "es");
    assert.equal(await page.locator("#project-context").inputValue(), idea);
    await page.getByRole("button", { name: "Cambiar a inglés" }).click();
    record(
      "OAuth-style return without lang restores saved Spanish, position and content",
      { realProvider: false },
    );
    await page.getByRole("button", { name: "Blog", exact: true }).click();
    await page.locator(".blog-post h2 a").first().click();
    assert.ok((await page.title()).endsWith("| accreatio Blog"));
    await page.getByRole("link", { name: /View all posts/ }).click();
    await page.waitForFunction(() => document.title === "Blog | accreatio");
    assert.ok(
      !(
        await page.locator('link[rel="canonical"]').getAttribute("href")
      ).includes("post="),
    );
    await page.goBack();
    await page.waitForFunction(() =>
      document.title.endsWith("| accreatio Blog"),
    );
    await page
      .getByRole("button", { name: "New project", exact: true })
      .click();
    await question(page, "context").waitFor();
    record(
      "Article/list canonical and title reset on navigation and browser Back",
    );

    const field = page.locator("#project-context");
    const contrast = await field.evaluate((element) => {
      const rgb = (value) =>
        value
          .match(/[\d.]+/g)
          .slice(0, 3)
          .map(Number);
      const luminance = (color) =>
        rgb(color)
          .map((value) => {
            const n = value / 255;
            return n <= 0.04045 ? n / 12.92 : ((n + 0.055) / 1.055) ** 2.4;
          })
          .reduce(
            (sum, value, i) => sum + value * [0.2126, 0.7152, 0.0722][i],
            0,
          );
      const css = getComputedStyle(element);
      const foreground = luminance(css.borderColor),
        background = luminance(css.backgroundColor);
      return {
        border: css.borderColor,
        background: css.backgroundColor,
        ratio:
          (Math.max(foreground, background) + 0.05) /
          (Math.min(foreground, background) + 0.05),
      };
    });
    assert.ok(contrast.ratio >= 3, JSON.stringify(contrast));
    await field.focus();
    const focus = await field.evaluate((element) => ({
      outline: getComputedStyle(element).outlineStyle,
      width: getComputedStyle(element).outlineWidth,
    }));
    assert.notEqual(focus.outline, "none");
    for (const viewport of [
      { width: 320, height: 844 },
      { width: 390, height: 844 },
      { width: 720, height: 500 },
    ]) {
      await page.setViewportSize(viewport);
      await checkWidth(page);
    }
    await page.screenshot({
      path: path.join(evidence, "integrated-field-mobile.png"),
      fullPage: true,
    });
    assert.equal(errors.length, 0, errors.join("\n"));
    record("Field boundary contrast, focus, reduced motion and narrow reflow", {
      contrast,
      focus,
      viewports: [320, 390, 720],
      pageErrors: errors,
    });
    await context.close();

    const blocked = await browser.newContext({
      reducedMotion: "reduce",
      serviceWorkers: "block",
    });
    await fixture(blocked);
    await blocked.addInitScript(() => {
      Storage.prototype.setItem = function () {
        throw new DOMException("quota fixture", "QuotaExceededError");
      };
      indexedDB.open = function () {
        throw new DOMException("blocked fixture", "SecurityError");
      };
    });
    const blockedPage = await blocked.newPage();
    await blockedPage.goto(`${origin}/?view=project&lang=en`);
    await question(blockedPage, "name").waitFor();
    await blockedPage.locator("#project-name").fill("Still editable in memory");
    await blockedPage
      .getByRole("alert")
      .filter({ hasText: "We could not save this change" })
      .waitFor();
    assert.equal(
      await blockedPage.locator("#project-name").inputValue(),
      "Still editable in memory",
    );
    assert.ok(
      !(await blockedPage.locator(".web-intro").innerText()).includes(
        "Draft saved in this browser",
      ),
    );
    record(
      "Unavailable IndexedDB and exhausted storage do not freeze fields or claim saved",
    );
    await blocked.close();
    const future = await browser.newContext({ serviceWorkers: "block" });
    await fixture(future);
    await future.addInitScript(() => {
      const ownership = {
        ownerKey: `v1:${"a".repeat(64)}`,
        sessionKey: `v1:${"1".repeat(64)}`,
        generation: "owned-future-fixture",
      };
      localStorage.setItem(
        "accreatio:draft-context:v1",
        JSON.stringify(ownership),
      );
      localStorage.setItem(
        "accreatio:account-draft:v1",
        JSON.stringify({
          ...ownership,
          schemaVersion: 6,
          project: { name: "Future retained" },
        }),
      );
    });
    const futurePage = await future.newPage();
    await futurePage.goto(`${origin}/?view=project&lang=en`);
    await question(futurePage, "name").waitFor();
    await futurePage
      .locator("#project-name")
      .fill("Editable without overwriting future schema");
    await futurePage
      .getByRole("alert")
      .filter({ hasText: "We could not save" })
      .waitFor();
    assert.equal(
      JSON.parse(
        await futurePage.evaluate(() =>
          localStorage.getItem("accreatio:account-draft:v1"),
        ),
      ).schemaVersion,
      6,
    );
    record("Future draft schema is preserved without freezing the form");
    await future.close();
  }

  for (const [name, engine] of [
    ["firefox", firefox],
    ["webkit", webkit],
  ]) {
    if (selectedEngine && selectedEngine !== name) continue;
    let launched = false;
    let enginePage;
    const engineErrors = [];
    const steps = [];
    try {
      const other = await engine.launch({ headless: true });
      launched = true;
      browsers.push(other);
      const c = await other.newContext({
        viewport: { width: 390, height: 844 },
        reducedMotion: "reduce",
        serviceWorkers: "block",
      });
      await fixture(c);
      const p = await c.newPage();
      enginePage = p;
      p.on("pageerror", (error) => engineErrors.push(String(error)));
      await p.goto(`${origin}/?view=project&lang=es`);
      await question(p, "name").waitFor();
      steps.push({ stage: "name-visible", at: Date.now() });
      await p.locator("#project-name").fill("Prueba de motor");
      steps.push({
        stage: "name-filled",
        at: Date.now(),
        value: await p.locator("#project-name").inputValue(),
      });
      await next(p);
      steps.push({
        stage: "next-clicked",
        at: Date.now(),
        question: await p
          .locator(".guided-creation__question")
          .getAttribute("data-question"),
      });
      await p
        .getByRole("button", { name: /Estoy empezando con una idea/ })
        .click();
      await p
        .locator("#project-context")
        .fill("Contexto conservado sin construir el software.");
      await p.reload();
      await question(p, "context").waitFor();
      assert.equal(
        await p.locator("#project-context").inputValue(),
        "Contexto conservado sin construir el software.",
      );
      await reachReview(p);
      await checkWidth(p);
      await p.locator(".review-stage__confirm button").click();
      await confirm(p);
      await p
        .getByRole("heading", {
          name: "Revisión completada. No se creó ni descargó ningún ZIP.",
        })
        .waitFor();
      await p
        .getByRole("button", { name: /^(Back to review|Volver a revisión)$/ })
        .click();
      await p.locator(".review-stage__dry-run input").uncheck();
      await p.locator(".review-stage__confirm button").click();
      const actualDownload = p.waitForEvent("download");
      await confirm(p);
      const artifact = await actualDownload;
      await artifact.saveAs(path.join(evidence, `integrated-${name}.zip`));
      const content = unzip(await readFile(await artifact.path()));
      assert.ok(
        [...content.keys()].some((entry) => entry.endsWith("/START.md")),
      );
      record(`${name} ES mobile viewport main journey`, {
        browser: other.version(),
        physicalMobile: false,
        pageErrors: engineErrors,
      });
      await c.close();
    } catch (error) {
      const stem = `integrated-${name}-failure-${Date.now()}`;
      const diagnostic = {
        error: String(error),
        stack: error.stack,
        steps,
        pageErrors: engineErrors,
      };
      if (enginePage && !enginePage.isClosed()) {
        try {
          diagnostic.state = await enginePage.evaluate(() => ({
            url: location.href,
            visibility: document.visibilityState,
            question: document
              .querySelector(".guided-creation__question")
              ?.getAttribute("data-question"),
            body: document.body.innerText,
            inputs: [...document.querySelectorAll("input, textarea")].map(
              (input) => ({
                id: input.id,
                value: input.value,
                disabled: input.disabled,
              }),
            ),
            draftContext: localStorage.getItem("accreatio:draft-context:v1"),
            draft: localStorage.getItem("accreatio:account-draft:v1"),
          }));
        } catch (captureError) {
          diagnostic.captureError = String(captureError);
        }
        try {
          await enginePage.screenshot({
            path: path.join(evidence, `${stem}.png`),
            fullPage: true,
          });
        } catch (captureError) {
          diagnostic.screenshotError = String(captureError);
        }
      }
      await writeFile(
        path.join(evidence, `${stem}.json`),
        JSON.stringify(diagnostic, null, 2) + "\n",
      );
      records.push({
        name: `${name} desktop engine`,
        result: launched ? "FAIL" : "BLOCKED",
        reason: String(error).slice(0, 700),
        diagnostic: `${stem}.json`,
      });
      if (launched) process.exitCode = 1;
    }
  }
} catch (error) {
  records.push({
    name: "Integrated functional smoke",
    result: "FAIL",
    reason: String(error),
    stack: error.stack,
  });
  process.exitCode = 1;
} finally {
  for (const browser of browsers) await browser.close();
  server.kill();
  const result = {
    testedAt: new Date().toISOString(),
    version: JSON.parse(await readFile("package.json", "utf8")).version,
    source: "working candidate; tie to manifest before release",
    selectedEngine: selectedEngine ?? "all",
    environment:
      "Local production bundle; account/provider/Blog API fixtures; real browser ZIP generation and download",
    records,
  };
  await writeFile(
    path.join(
      evidence,
      selectedEngine
        ? `integrated-functional-${selectedEngine}.json`
        : "integrated-functional.json",
    ),
    JSON.stringify(result, null, 2) + "\n",
  );
  console.log(JSON.stringify(result, null, 2));
}
