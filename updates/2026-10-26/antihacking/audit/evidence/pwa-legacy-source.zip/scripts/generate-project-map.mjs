import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dataPath = path.join(root, "project-map.json");
const templatePath = path.join(root, "scripts", "project-map.template.html");
const aekrBannerPath = path.join(root, "assets", "aekr-banner.png");
// The viewer carries the project name so a downloaded copy stays identifiable
// beside other AEKR project maps. The canonical JSON keeps the standard name
// that agents and the AEKR project-map contract read by.
const outputName = "accreatio-project-map.html";
const outputPath = path.join(root, outputName);
const DATA_PLACEHOLDER = "__PROJECT_MAP_DATA__";
const AEKR_BANNER_PLACEHOLDER = "__AEKR_BANNER_DATA_URI__";
const ALLOWED_STATUSES = new Set(["current", "upstream", "planned", "hold"]);

const isRecord = (value) =>
  value !== null && typeof value === "object" && !Array.isArray(value);

export function validateProjectMap(map) {
  const errors = [];
  if (!isRecord(map)) return ["Project map must be a JSON object."];

  const expectedKeys = ["edges", "flows", "nodes"];
  const actualKeys = Object.keys(map).sort();
  if (JSON.stringify(actualKeys) !== JSON.stringify(expectedKeys))
    errors.push("Top-level keys must be exactly: nodes, edges, flows.");

  for (const key of expectedKeys)
    if (!Array.isArray(map[key])) errors.push(`${key} must be an array.`);
  if (errors.length) return errors;

  const validateIds = (items, collection) => {
    const seen = new Set();
    for (const [index, item] of items.entries()) {
      if (!isRecord(item) || typeof item.id !== "string" || !item.id.trim()) {
        errors.push(`${collection}[${index}] must have a non-empty string id.`);
        continue;
      }
      if (seen.has(item.id))
        errors.push(`Duplicate ${collection} id: ${item.id}.`);
      seen.add(item.id);
    }
    return seen;
  };

  const nodeIds = validateIds(map.nodes, "node");
  const edgeIds = validateIds(map.edges, "edge");
  const flowIds = validateIds(map.flows, "flow");
  const totalIds = nodeIds.size + edgeIds.size + flowIds.size;
  if (new Set([...nodeIds, ...edgeIds, ...flowIds]).size !== totalIds)
    errors.push("Node, edge, and flow IDs must also be globally unique.");

  for (const node of map.nodes) {
    if (!isRecord(node) || typeof node.id !== "string") continue;
    if (!ALLOWED_STATUSES.has(node.status))
      errors.push(`Node ${node.id} has an invalid status.`);
    if (
      !isRecord(node.position) ||
      !Number.isFinite(node.position.x) ||
      !Number.isFinite(node.position.y)
    )
      errors.push(
        `Node ${node.id} must have finite position.x and position.y.`,
      );
    if (!Array.isArray(node.paths) || !Array.isArray(node.responsibilities))
      errors.push(
        `Node ${node.id} must expose paths and responsibilities arrays.`,
      );
  }

  const edgesById = new Map();
  for (const edge of map.edges) {
    if (!isRecord(edge) || typeof edge.id !== "string") continue;
    edgesById.set(edge.id, edge);
    if (!nodeIds.has(edge.source))
      errors.push(`Edge ${edge.id} has unknown source ${String(edge.source)}.`);
    if (!nodeIds.has(edge.target))
      errors.push(`Edge ${edge.id} has unknown target ${String(edge.target)}.`);
    if (!ALLOWED_STATUSES.has(edge.status))
      errors.push(`Edge ${edge.id} has an invalid status.`);
  }

  for (const flow of map.flows) {
    if (!isRecord(flow) || typeof flow.id !== "string") continue;
    if (!ALLOWED_STATUSES.has(flow.status))
      errors.push(`Flow ${flow.id} has an invalid status.`);
    if (!Array.isArray(flow.steps) || flow.steps.length < 2) {
      errors.push(`Flow ${flow.id} must have at least two steps.`);
      continue;
    }
    for (let index = 0; index < flow.steps.length; index += 1) {
      const step = flow.steps[index];
      const location = `Flow ${flow.id} step ${index + 1}`;
      if (!isRecord(step) || !nodeIds.has(step.nodeId)) {
        errors.push(`${location} has unknown node ${String(step?.nodeId)}.`);
        continue;
      }
      if (typeof step.action !== "string" || !step.action.trim())
        errors.push(`${location} must describe its action.`);
      const next = flow.steps[index + 1];
      if (!next) {
        if ("edgeId" in step)
          errors.push(`${location} is final and must not declare edgeId.`);
        continue;
      }
      if (typeof step.edgeId !== "string" || !edgeIds.has(step.edgeId)) {
        errors.push(`${location} must reference a known edgeId.`);
        continue;
      }
      const edge = edgesById.get(step.edgeId);
      if (edge.source !== step.nodeId || edge.target !== next.nodeId)
        errors.push(
          `${location} edge ${step.edgeId} must connect ${step.nodeId} to ${next.nodeId}.`,
        );
    }
  }

  return errors;
}

export function assertValidProjectMap(map) {
  const errors = validateProjectMap(map);
  if (errors.length)
    throw new Error(`Invalid project-map.json:\n- ${errors.join("\n- ")}`);
}

export function serializeForInlineScript(map) {
  return JSON.stringify(map, null, 2)
    .replaceAll("&", "\\u0026")
    .replaceAll("<", "\\u003c")
    .replaceAll(">", "\\u003e")
    .replaceAll("\u2028", "\\u2028")
    .replaceAll("\u2029", "\\u2029");
}

export function renderProjectMapHtml(map, template, aekrBannerDataUri) {
  assertValidProjectMap(map);
  if (typeof template !== "string" || !template.includes(DATA_PLACEHOLDER))
    throw new Error(`HTML template must contain ${DATA_PLACEHOLDER}.`);
  if (
    template.indexOf(DATA_PLACEHOLDER) !==
    template.lastIndexOf(DATA_PLACEHOLDER)
  )
    throw new Error(
      `HTML template must contain ${DATA_PLACEHOLDER} exactly once.`,
    );
  if (
    template.indexOf(AEKR_BANNER_PLACEHOLDER) < 0 ||
    template.indexOf(AEKR_BANNER_PLACEHOLDER) !==
      template.lastIndexOf(AEKR_BANNER_PLACEHOLDER)
  )
    throw new Error(
      `HTML template must contain ${AEKR_BANNER_PLACEHOLDER} exactly once.`,
    );
  if (
    typeof aekrBannerDataUri !== "string" ||
    !/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(aekrBannerDataUri)
  )
    throw new Error("AEKR banner must be supplied as a PNG data URI.");
  return template
    .replace(AEKR_BANNER_PLACEHOLDER, aekrBannerDataUri)
    .replace(DATA_PLACEHOLDER, serializeForInlineScript(map));
}

export async function buildProjectMap({ check = false } = {}) {
  const [source, template, aekrBanner] = await Promise.all([
    fs.readFile(dataPath, "utf8"),
    fs.readFile(templatePath, "utf8"),
    fs.readFile(aekrBannerPath),
  ]);
  const map = JSON.parse(source);
  const aekrBannerDataUri = `data:image/png;base64,${aekrBanner.toString("base64")}`;
  const rendered = renderProjectMapHtml(map, template, aekrBannerDataUri);
  if (check) {
    let committed = "";
    try {
      committed = await fs.readFile(outputPath, "utf8");
    } catch {
      throw new Error(
        `${outputName} is missing; run npm run project-map:build.`,
      );
    }
    if (committed !== rendered)
      throw new Error(
        `${outputName} is out of sync with project-map.json; run npm run project-map:build.`,
      );
    return { map, outputPath, changed: false };
  }
  let existing = "";
  try {
    existing = await fs.readFile(outputPath, "utf8");
  } catch {
    // The first generation intentionally creates the derived artifact.
  }
  if (existing !== rendered) await fs.writeFile(outputPath, rendered, "utf8");
  return { map, outputPath, changed: existing !== rendered };
}

const invokedDirectly =
  process.argv[1] &&
  pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;

if (invokedDirectly) {
  buildProjectMap({ check: process.argv.includes("--check") })
    .then((result) => {
      const verb = process.argv.includes("--check")
        ? "verified"
        : result.changed
          ? "generated"
          : "already current";
      console.log(
        `${outputName} ${verb} (${result.map.nodes.length} nodes, ${result.map.edges.length} edges, ${result.map.flows.length} flows).`,
      );
    })
    .catch((error) => {
      console.error(error instanceof Error ? error.message : String(error));
      process.exitCode = 1;
    });
}
