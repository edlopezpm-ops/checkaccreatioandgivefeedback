import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const MARK = path.join(ROOT, "src", "assets", "accreatio-mark.svg");
const ICONS = path.join(ROOT, "public", "icons");
const svg = await readFile(MARK, "utf8");
const source = `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
const browser = await chromium.launch();

const renderIcon = async (size, filename) => {
  const page = await browser.newPage({
    deviceScaleFactor: 1,
    viewport: { height: size, width: size },
  });
  await page.setContent(`
    <style>
      * { box-sizing: border-box; }
      html, body { width: 100%; height: 100%; margin: 0; background: transparent; }
      body { display: grid; place-items: center; }
      img { width: 88%; height: 88%; object-fit: contain; }
    </style>
    <img src="${source}" alt="">
  `);
  await page.screenshot({
    omitBackground: true,
    path: path.join(ICONS, filename),
  });
  await page.close();
};

await renderIcon(192, "accreatio-192.png");
await renderIcon(512, "accreatio-512.png");

const social = await browser.newPage({
  deviceScaleFactor: 1,
  viewport: { height: 630, width: 1200 },
});
await social.setContent(`
  <style>
    * { box-sizing: border-box; }
    html, body { width: 100%; height: 100%; margin: 0; }
    body {
      display: grid;
      grid-template-columns: 410px 1fr;
      align-items: center;
      padding: 72px 94px;
      overflow: hidden;
      color: #f5f0ff;
      background:
        radial-gradient(circle at 82% 24%, rgba(124, 91, 241, .34), transparent 42%),
        radial-gradient(circle at 18% 86%, rgba(80, 168, 232, .22), transparent 38%),
        #100c22;
      font-family: Inter, system-ui, sans-serif;
    }
    body::after {
      content: "";
      position: absolute;
      inset: 0;
      opacity: .24;
      background-image: radial-gradient(circle, #d9d2ff 0 1px, transparent 1.5px);
      background-size: 83px 71px;
    }
    img { position: relative; z-index: 1; width: 340px; height: 340px; }
    section { position: relative; z-index: 1; }
    h1 { margin: 0; font-family: Georgia, serif; font-size: 88px; letter-spacing: -.04em; }
    p { max-width: 560px; margin: 22px 0 0; color: #c8bfdc; font-size: 25px; line-height: 1.45; }
  </style>
  <img src="${source}" alt="">
  <section>
    <h1>accreatio</h1>
    <p>From idea to a structured beginning.</p>
  </section>
`);
await social.screenshot({
  path: path.join(ICONS, "accreatio-social.png"),
});
await social.close();
await browser.close();
