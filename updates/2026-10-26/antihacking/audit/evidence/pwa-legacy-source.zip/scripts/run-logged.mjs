import { spawn } from "node:child_process";
import { createWriteStream, readFileSync } from "node:fs";
import { mkdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";

const root = fileURLToPath(new URL("../", import.meta.url));
const pkg = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8"));
const [script, ...extra] = process.argv.slice(2);
if (
  extra.length ||
  !script ||
  script === "log" ||
  !/^[a-z0-9][a-z0-9:-]*$/.test(script) ||
  !Object.hasOwn(pkg.scripts, script) ||
  !process.env.npm_execpath
) {
  console.error("Usage: npm run log -- <existing package script>");
  process.exit(2);
}
const directory = path.join(root, ".local", "logs");
await mkdir(directory, { recursive: true });
const stamp = new Date().toISOString().replaceAll(/[:.]/g, "-");
const logfile = path.join(
  directory,
  `${stamp}-${script.replaceAll(":", "-")}-${randomUUID()}.log`,
);
const log = createWriteStream(logfile, { flags: "wx" });
await new Promise((resolve, reject) => {
  log.once("open", resolve);
  log.once("error", reject);
});
log.write(`Script: ${script}\nStarted UTC: ${new Date().toISOString()}\n`);
console.log(`Log: ${path.relative(root, logfile)}`);
const child = spawn(
  process.execPath,
  [process.env.npm_execpath, "run", script],
  {
    cwd: root,
    shell: false,
    windowsHide: true,
    env: {
      ...process.env,
      WRANGLER_LOG_PATH: path.join(directory, "wrangler"),
    },
    stdio: ["inherit", "pipe", "pipe"],
  },
);
for (const [stream, output] of [
  [child.stdout, process.stdout],
  [child.stderr, process.stderr],
]) {
  stream.on("data", (chunk) => {
    output.write(chunk);
    if (!log.write(chunk)) {
      stream.pause();
      log.once("drain", () => stream.resume());
    }
  });
}
child.on("error", (error) => {
  log.write(`Launch error: ${error.code ?? "unknown"}\n`);
  process.exitCode = 1;
});
child.on("close", (code, signal) => {
  const exitCode = code ?? 1;
  log.end(`\nExit: ${exitCode}; signal: ${signal ?? "none"}\n`);
  process.exitCode = exitCode;
});
