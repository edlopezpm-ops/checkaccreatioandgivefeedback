import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { chromium } from "playwright";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const TARGET_URL = pathToFileURL(
  path.join(ROOT, "accreatio-project-map.html"),
).href;
const map = JSON.parse(
  await fs.readFile(path.join(ROOT, "project-map.json"), "utf8"),
);
const screenshotDirectory = process.env.ACCREATIO_MAP_SCREENSHOT_DIR;

// The declared stacks, as the browser serialises them back from
// getComputedStyle. Chromium drops the quotes around families that do not need
// them, so these are not byte-identical to the CSS source.
const ui =
  'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
// design-v10 retired the serif display face: brand, headings, and UI share one
// host-resident sans, separated by weight and size rather than by family.
const display = ui;
const code =
  'ui-monospace, "Cascadia Mono", "Segoe UI Mono", "Roboto Mono", Menlo, Consolas, monospace';

const sorted = (values) => [...values].sort();
const dataIds = async (locator, attribute) =>
  locator.evaluateAll(
    (elements, name) =>
      elements.map((element) => element.getAttribute(name)).sort(),
    attribute,
  );

let browser;
try {
  browser = await chromium.launch();
  const page = await browser.newPage({
    viewport: { width: 1440, height: 900 },
  });
  const requests = [];
  const runtimeErrors = [];
  const observe = (observedPage) => {
    observedPage.on("request", (request) => requests.push(request.url()));
    observedPage.on("pageerror", (error) => runtimeErrors.push(error.message));
    observedPage.on("console", (message) => {
      if (message.type() === "error") runtimeErrors.push(message.text());
    });
  };
  observe(page);

  await page.goto(TARGET_URL, { waitUntil: "load" });
  await page
    .getByRole("heading", { name: "Interactive project architecture" })
    .waitFor();
  const aekrBanner = page.getByRole("img", {
    name: "Build with AEKR — AI Engineering Knowledge Repo",
  });
  assert.match(
    await aekrBanner.getAttribute("src"),
    /^data:image\/png;base64,/,
  );
  assert.ok(
    await aekrBanner.evaluate(
      (image) => image.complete && image.naturalWidth === 1474,
    ),
  );

  assert.equal(await page.locator(".node").count(), map.nodes.length);
  assert.equal(await page.locator(".edge-group").count(), map.edges.length);
  assert.equal(await page.locator(".flow-card").count(), map.flows.length);
  assert.deepEqual(
    await page.evaluate(() => {
      const role = (selector) => {
        const style = getComputedStyle(document.querySelector(selector));
        return [style.fontFamily, style.fontWeight];
      };
      return {
        brand: role(".brand-name"),
        button: role(".control-button"),
        h1: role("h1"),
        h2: role("h2"),
        primary: role(".flow-card strong"),
        secondary: role(".flow-card p"),
      };
    }),
    {
      brand: [display, "700"],
      button: [ui, "600"],
      h1: [display, "700"],
      h2: [display, "700"],
      primary: [ui, "600"],
      secondary: [ui, "400"],
    },
  );

  const desktopDiagram = await page.locator(".diagram-card").boundingBox();
  const desktopFlows = await page.locator(".flow-panel").boundingBox();
  assert.ok(desktopDiagram && desktopFlows);
  assert.ok(
    desktopFlows.x >= desktopDiagram.x + desktopDiagram.width,
    "flow panel must be to the right of the diagram on desktop",
  );

  for (const flow of map.flows) {
    const card = page.locator(`[data-flow-id="${flow.id}"]`);
    await card.click();
    assert.equal(await card.getAttribute("aria-pressed"), "true");
    assert.equal(
      await page.locator('.flow-card[aria-pressed="true"]').count(),
      1,
    );

    const expectedNodes = sorted(
      new Set(flow.steps.map((step) => step.nodeId)),
    );
    const expectedEdges = sorted(
      new Set(flow.steps.map((step) => step.edgeId).filter(Boolean)),
    );
    assert.deepEqual(
      await dataIds(page.locator(".node.is-active"), "data-node-id"),
      expectedNodes,
    );
    assert.deepEqual(
      await dataIds(page.locator(".edge-group.is-active"), "data-edge-id"),
      expectedEdges,
    );
    assert.equal(
      await page.locator(".node.is-muted").count(),
      map.nodes.length - expectedNodes.length,
    );
    assert.equal(
      await page.locator(".edge-group.is-muted").count(),
      map.edges.length - expectedEdges.length,
    );
    assert.equal(
      await page.locator("#flow-detail .step-button").count(),
      flow.steps.length,
    );
    assert.ok(
      (await page.locator("#active-flow-status").textContent()).includes(
        flow.label,
      ),
    );
  }

  await page.getByRole("button", { name: "Show all" }).click();
  assert.equal(
    await page.locator(".node.is-active, .node.is-muted").count(),
    0,
  );
  assert.equal(
    await page.locator(".edge-group.is-active, .edge-group.is-muted").count(),
    0,
  );
  assert.equal(
    await page.locator('.flow-card[aria-pressed="true"]').count(),
    0,
  );

  const keyboardFlow = page.locator(`[data-flow-id="${map.flows[0].id}"]`);
  await keyboardFlow.focus();
  await keyboardFlow.press("Enter");
  assert.equal(await keyboardFlow.getAttribute("aria-pressed"), "true");

  const inspectedNode = map.nodes.find((node) => node.id === "pure-domain");
  const node = page.locator('[data-node-id="pure-domain"]');
  await node.focus();
  await node.press("Enter");
  await page
    .locator("#node-details")
    .getByRole("heading", { name: inspectedNode.label })
    .waitFor();
  assert.deepEqual(
    await page
      .locator(".path-chip")
      .first()
      .evaluate((element) => {
        const style = getComputedStyle(element);
        return [style.fontFamily, style.fontWeight];
      }),
    [code, "400"],
  );

  await page.getByRole("button", { name: "Zoom in" }).click();
  assert.equal(await page.locator("#zoom-level").textContent(), "115%");
  await page.getByRole("button", { name: "Fit" }).click();
  assert.equal(await page.locator("#zoom-level").textContent(), "100%");

  const viewports = [
    { width: 1024, height: 768 },
    { width: 768, height: 1024 },
    { width: 390, height: 844 },
  ];
  for (const viewport of viewports) {
    await page.setViewportSize(viewport);
    const metrics = await page.evaluate(() => {
      const diagram = document
        .querySelector(".diagram-card")
        .getBoundingClientRect();
      const flows = document
        .querySelector(".flow-panel")
        .getBoundingClientRect();
      return {
        clientWidth: document.documentElement.clientWidth,
        scrollWidth: document.documentElement.scrollWidth,
        diagramBottom: diagram.bottom,
        flowTop: flows.top,
      };
    });
    assert.ok(
      metrics.scrollWidth <= metrics.clientWidth,
      `page overflows horizontally at ${viewport.width}px`,
    );
    assert.ok(
      metrics.flowTop >= metrics.diagramBottom,
      `flow panel must stack below the diagram at ${viewport.width}px`,
    );
  }

  const mobilePage = await browser.newPage({
    viewport: { width: 390, height: 844 },
  });
  observe(mobilePage);
  await mobilePage.goto(TARGET_URL, { waitUntil: "load" });
  assert.equal(await mobilePage.locator("#zoom-level").textContent(), "400%");
  const mobileLabel = await mobilePage
    .locator(".node-label")
    .first()
    .boundingBox();
  assert.ok(
    mobileLabel?.height >= 12,
    `mobile node label must remain readable; rendered height was ${mobileLabel?.height}`,
  );
  assert.equal(
    await mobilePage
      .locator("#architecture")
      .evaluate((element) => getComputedStyle(element).touchAction),
    "none",
  );
  await mobilePage.locator(`[data-flow-id="${map.flows[0].id}"]`).click();

  if (screenshotDirectory) {
    await fs.mkdir(screenshotDirectory, { recursive: true });
    await mobilePage.evaluate(() => {
      window.scrollTo(0, 0);
      document.activeElement?.blur?.();
    });
    await mobilePage.screenshot({
      path: path.join(screenshotDirectory, "project-map-mobile.png"),
      fullPage: true,
    });
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.screenshot({
      path: path.join(screenshotDirectory, "project-map-desktop.png"),
      fullPage: true,
    });
  }

  assert.equal(requests.length, 2);
  assert.ok(requests.every((url) => url === TARGET_URL));
  assert.deepEqual(runtimeErrors, []);
  console.log(
    `PASS project map file:// smoke (${map.flows.length} flows, 4 viewports, zero external requests)`,
  );
} finally {
  if (browser) await browser.close().catch(() => {});
}
