import { execFileSync } from "node:child_process";
import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

// Development-only dependency metadata. This script is not part of the app.
const npmCli = process.env.npm_execpath;
if (!npmCli) throw new Error("Run through npm run security:inventory.");
const output = path.join(
  ".local/logs",
  `security-${new Date().toISOString().replaceAll(":", "-")}-${randomUUID()}`,
);
await mkdir(output, { recursive: true });
function run(args, allowsAuditFailure = false) {
  try {
    return execFileSync(process.execPath, [npmCli, ...args], {
      encoding: "utf8",
      maxBuffer: 16 * 1024 * 1024,
      windowsHide: true,
      // npm 12 forwards its global allow-scripts setting into lifecycle env;
      // reclassifying that as a project override rejects even read-only audit.
      // These two metadata commands install/execute no package scripts.
      env: Object.fromEntries(
        Object.entries(process.env).filter(
          ([name]) => name.toLowerCase() !== "npm_config_allow_scripts",
        ),
      ),
      stdio: ["ignore", "pipe", "pipe"],
    });
  } catch (error) {
    if (allowsAuditFailure && error.status === 1 && error.stdout)
      return String(error.stdout);
    throw new Error(`Dependency inventory command failed: ${args[0]}`);
  }
}
const sbom = JSON.parse(run(["sbom", "--sbom-format=cyclonedx"]));
const audit = JSON.parse(run(["audit", "--json", "--audit-level=high"], true));
if (sbom.bomFormat !== "CycloneDX" || !audit.metadata?.vulnerabilities)
  throw new Error("Dependency inventory response is incomplete.");
await writeFile(
  path.join(output, "sbom.cyclonedx.json"),
  JSON.stringify(sbom, null, 2),
);
await writeFile(
  path.join(output, "npm-audit.json"),
  JSON.stringify(audit, null, 2),
);
const vulnerabilities = audit.metadata.vulnerabilities;
const receipt = {
  result:
    vulnerabilities.high + vulnerabilities.critical === 0 ? "PASS" : "FAIL",
  componentCount: sbom.components?.length ?? 0,
  vulnerabilities,
  scope:
    "Installed development and build dependency inventory; no project or account data",
};
await writeFile(
  path.join(output, "receipt.json"),
  JSON.stringify(receipt, null, 2),
);
console.log(JSON.stringify({ ...receipt, evidence: output }));
if (receipt.result !== "PASS") process.exitCode = 1;
