import { readFile, readdir, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const repositoryRoot = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
);
const desktopRoot = path.join(repositoryRoot, "dist-desktop");
const webRoot = path.join(repositoryRoot, "dist");
const desktopOnly = process.argv.includes("--desktop-only");
const webOnly = process.argv.includes("--web-only");
if (desktopOnly && webOnly)
  throw new Error("Choose one artifact surface: --web-only or --desktop-only.");
const textExtensions = new Set([
  ".css",
  ".html",
  ".js",
  ".json",
  ".map",
  ".mjs",
  ".txt",
  ".webmanifest",
  ".xml",
]);

async function filesBelow(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const target = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...(await filesBelow(target)));
    else if (entry.isFile()) files.push(target);
  }
  return files;
}

async function readArtifact(directory) {
  const details = await stat(directory).catch(() => null);
  if (!details?.isDirectory())
    throw new Error(
      `Missing build artifact: ${path.relative(repositoryRoot, directory)}`,
    );
  const files = await filesBelow(directory);
  const text = [];
  for (const file of files) {
    if (!textExtensions.has(path.extname(file).toLowerCase())) continue;
    text.push({
      file: path.relative(repositoryRoot, file),
      value: await readFile(file, "utf8"),
    });
  }
  return { files, text };
}

function assertAbsent(artifact, checks) {
  const findings = [];
  for (const file of artifact.files) {
    const relative = path.relative(repositoryRoot, file);
    for (const check of checks.filter(({ scope }) => scope === "path"))
      if (check.pattern.test(relative))
        findings.push(`${check.label}: ${relative}`);
  }
  for (const item of artifact.text)
    for (const check of checks.filter(({ scope }) => scope === "content"))
      if (check.pattern.test(item.value))
        findings.push(`${check.label}: ${item.file}`);
  if (findings.length)
    throw new Error(`Desktop surface boundary failed:\n${findings.join("\n")}`);
}

function assertWebMarkers(artifact) {
  const combined = artifact.text.map(({ value }) => value).join("\n");
  const paths = artifact.files.map((file) =>
    path.relative(repositoryRoot, file),
  );
  const requirements = [
    ["Blog reader", /(?:blog-page|>Blog<|\bBlog\b)/i],
    ["Blog read endpoint", /\/api\/blog\/posts/i],
    ["Blog admin session endpoint", /\/api\/admin\/blog\/session/i],
    ["Blog publish endpoint", /\/api\/admin\/blog\/posts/i],
    ["publish capability", /canPublish/],
  ];
  const missing = requirements
    .filter(([, pattern]) => !pattern.test(combined))
    .map(([label]) => label);
  const requiredFiles = [
    ["PWA manifest", /(?:^|[/\\])manifest\.webmanifest$/i],
    ["service worker", /(?:^|[/\\])sw\.js$/i],
    ["Workbox runtime", /(?:^|[/\\])workbox[^/\\]*\.js$/i],
  ];
  missing.push(
    ...requiredFiles
      .filter(([, pattern]) => !paths.some((file) => pattern.test(file)))
      .map(([label]) => label),
  );
  if (missing.length)
    throw new Error(`Web surface markers missing: ${missing.join(", ")}`);
}

let desktop;
// Desktop scanning is retained for historical artifact custody. Current web
// verification must not depend on an obsolete prototype build being present.
if (!webOnly) {
  desktop = await readArtifact(desktopRoot);
  assertAbsent(desktop, [
    {
      label: "founding post 1",
      pattern: /Introducing accreatio/i,
      scope: "content",
    },
    {
      label: "founding post 2",
      pattern: /Nebula made ideas for accreatio/i,
      scope: "content",
    },
    {
      label: "founding post 3",
      pattern: /A small paradox, but a paradox after all/i,
      scope: "content",
    },
    {
      label: "Blog reader/editor module marker",
      pattern:
        /(?:BlogExperience|BLOG_POSTS|blog-page|blog-experience|blog-post|blog-composer|blog-admin)/i,
      scope: "content",
    },
    {
      label: "Blog API path",
      pattern: /\/api\/(?:admin\/)?blog(?:\/|\b)/i,
      scope: "content",
    },
    {
      label: "Blog publish capability",
      pattern: /(?:canPublish|Idempotency-Key)/,
      scope: "content",
    },
    {
      label: "PWA virtual module",
      pattern: /(?:virtual:pwa-register|workbox-|serviceWorker\.register)/i,
      scope: "content",
    },
    {
      label: "PWA manifest",
      pattern: /manifest\.webmanifest$/i,
      scope: "path",
    },
    {
      label: "service worker",
      pattern: /(?:^|[/\\])(?:sw|service-worker)(?:[.-][^/\\.]+)?\.js$/i,
      scope: "path",
    },
    {
      label: "Workbox artifact",
      pattern: /(?:^|[/\\])workbox[^/\\]*\.js$/i,
      scope: "path",
    },
  ]);
}

if (!desktopOnly) assertWebMarkers(await readArtifact(webRoot));

process.stdout.write(
  `${JSON.stringify({
    desktopFiles: desktop?.files.length ?? 0,
    mode: webOnly ? "web-only" : desktopOnly ? "desktop-only" : "full",
    ok: true,
  })}\n`,
);
