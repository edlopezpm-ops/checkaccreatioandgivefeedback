import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { readFile, mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";
import { unzipSync, strFromU8 } from "fflate";
import { harness } from "../tests/helpers/accountHarness.ts";
import { handleCollection } from "../functions/_lib/collection.ts";

const root = fileURLToPath(new URL("../", import.meta.url)),
  port = 4197,
  target = `http://127.0.0.1:${port}`;
const output = path.join(root, ".local/logs/collect-browser");
await mkdir(output, { recursive: true });
const preview = spawn(
  process.execPath,
  [
    path.join(root, "node_modules/vite/bin/vite.js"),
    "preview",
    "--host",
    "127.0.0.1",
    "--port",
    String(port),
    "--strictPort",
  ],
  { cwd: root, stdio: "ignore", windowsHide: true },
);
const h = await harness();
h.db.now = Date.now();
h.db.sqlite.exec(
  await readFile(
    path.join(root, "migrations-auth/0009_optional_collection.sql"),
    "utf8",
  ),
);
const cookie = await h.login();
const env = { ...h.env, COLLECT_ENABLED: "true" };
const requests = [],
  errors = [],
  external = [];
let browser;
async function install(context) {
  context.on("page", (page) =>
    page.on("pageerror", (error) => errors.push(error.message)),
  );
  await context.route("**/*", async (route) => {
    const r = route.request(),
      url = new URL(r.url());
    if (url.origin !== target) {
      external.push(url.origin);
      return route.abort();
    }
    const fulfill = async (response) =>
      route.fulfill({
        status: response.status,
        headers: Object.fromEntries(response.headers),
        body: await response.text(),
      });
    if (url.pathname.startsWith("/api/collect/")) {
      requests.push({
        action: url.pathname.split("/").at(-1),
        method: r.method(),
        purpose: r.method() === "POST" ? r.postDataJSON()?.purpose : undefined,
      });
      return fulfill(
        await handleCollection(
          {
            env,
            request: new Request(r.url(), {
              method: r.method(),
              headers: r.headers(),
              ...(r.method() === "POST" ? { body: r.postData() } : {}),
            }),
          },
          url.pathname.split("/").at(-1),
        ),
      );
    }
    if (url.pathname === "/api/auth/v1/methods")
      return route.fulfill({
        contentType: "application/json",
        body: JSON.stringify({
          version: "auth.v1",
          methods: {
            google: { available: true },
            github: { available: false },
            emailOtp: { available: false },
          },
        }),
      });
    if (url.pathname === "/api/account/session")
      return fulfill(await h.call("session", { method: "GET", cookie }));
    if (url.pathname.startsWith("/api/"))
      return route.fulfill({
        status: 403,
        contentType: "application/json",
        body: JSON.stringify({ error: { code: "fixture_denied" } }),
      });
    return route.continue();
  });
}
async function until(check) {
  for (let i = 0; i < 100; i++) {
    if (await check()) return;
    await new Promise((r) => setTimeout(r, 50));
  }
  throw Error("Expected collection state was not observed");
}
const usage = (page) =>
  page.evaluate(() =>
    window.dispatchEvent(
      new CustomEvent("accreatio:usage", {
        detail: {
          kind: "usage",
          feature: "creation",
          outcome: "completed",
          durationBand: "1-5-minutes",
        },
      }),
    ),
  );
try {
  await until(async () => {
    try {
      return (await fetch(target)).ok;
    } catch {
      return false;
    }
  });
  browser = await chromium.launch({ headless: true });
  // Collection assertions do not exercise nebula motion; test:web covers it.
  const context = await browser.newContext({
    acceptDownloads: true,
    reducedMotion: "reduce",
  });
  await install(context);
  const page = await context.newPage();
  await page.goto(`${target}/?lang=en`);
  const layer = page.getByRole("region", { name: "Privacy choices" });
  await layer.waitFor();
  assert.equal(await layer.getByRole("button").count(), 3);
  for (const button of await layer.getByRole("button").all())
    assert.ok((await button.boundingBox()).height >= 44);
  await usage(page);
  assert.equal(requests.filter((r) => r.method === "POST").length, 0);
  await layer
    .getByRole("button", { name: "Reject non-essential cookies", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Privacy and data", exact: true })
    .click();
  const dialog = page.getByRole("dialog", {
    name: "Privacy and data",
    exact: true,
  });
  await dialog.waitFor();
  assert.match(await dialog.innerText(), /Download my data/);
  const localDownload = page.waitForEvent("download");
  await dialog
    .getByRole("button", { name: "Download local data", exact: true })
    .click();
  const downloaded = await localDownload;
  await downloaded.saveAs(path.join(output, "synthetic-local-data.zip"));
  const files = unzipSync(
    new Uint8Array(
      await readFile(path.join(output, "synthetic-local-data.zip")),
    ),
  );
  const manifest = JSON.parse(
    strFromU8(files["accreatio-local-data/manifest.json"]),
  );
  assert.equal(manifest.product, "accreatio");
  assert.match(manifest.limitations.join(" "), /closed tab/);
  assert.equal(
    requests.filter((r) => r.method === "POST").length,
    0,
    "essential local export does not collect",
  );
  await dialog
    .getByRole("button", { name: "Accept all optional", exact: true })
    .click();
  await usage(page);
  await until(
    () =>
      h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()
        .n >= 1,
  );
  await dialog
    .getByRole("button", { name: "Reject non-essential cookies", exact: true })
    .click();
  await until(
    () =>
      h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()
        .n === 0,
  );
  await dialog
    .getByText("Independent voluntary survey", { exact: true })
    .click();
  await dialog
    .getByLabel("Professional role", { exact: true })
    .selectOption("developer");
  await dialog
    .getByLabel("Feature priority", { exact: true })
    .selectOption("offline");
  await dialog
    .getByRole("button", { name: "Share my answers with AEKR", exact: true })
    .click();
  await until(
    () =>
      h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()
        .n === 1,
  );
  const stored = JSON.parse(
    h.db.sqlite.prepare("SELECT payload_json FROM collection_records").get()
      .payload_json,
  );
  assert.deepEqual(stored, {
    kind: "research",
    answers: { role: "developer", priority: "offline" },
  });
  assert.equal(
    await page.evaluate(
      () =>
        JSON.parse(localStorage.getItem("accreatio:cookie-preferences"))
          .analytics,
    ),
    false,
  );
  const optionalDownload = page.waitForEvent("download");
  await dialog
    .getByRole("button", {
      name: "Download choices and contributions",
      exact: true,
    })
    .click();
  const optional = await optionalDownload;
  await optional.saveAs(path.join(output, "synthetic-optional-data.json"));
  const optionalData = JSON.parse(
    await readFile(path.join(output, "synthetic-optional-data.json"), "utf8"),
  );
  assert.equal(optionalData.server[0].records.length, 1);
  assert.doesNotMatch(
    JSON.stringify(optionalData),
    /token_hash|Bearer|sessionKey|ownerKey/,
  );
  await dialog
    .getByRole("button", {
      name: "Withdraw research and delete contributions",
      exact: true,
    })
    .click();
  await until(
    () =>
      h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()
        .n === 0,
  );
  const second = await context.newPage();
  await second.goto(`${target}/?lang=en`);
  await second
    .getByRole("button", { name: "Privacy and data", exact: true })
    .click();
  const secondDialog = second.getByRole("dialog", {
    name: "Privacy and data",
    exact: true,
  });
  await secondDialog
    .getByRole("button", { name: "Accept all optional", exact: true })
    .click();
  await until(() =>
    page.evaluate(
      () =>
        JSON.parse(localStorage.getItem("accreatio:cookie-preferences"))
          .analytics,
    ),
  );
  await Promise.all([usage(page), usage(second)]);
  await until(
    () =>
      h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()
        .n >= 2,
  );
  assert.equal(
    h.db.sqlite
      .prepare(
        "SELECT COUNT(*) n FROM collection_permissions WHERE purpose='analytics' AND revoked_at IS NULL",
      )
      .get().n,
    1,
    "independent browser tabs share one current grant",
  );
  await dialog
    .getByRole("button", { name: "Reject non-essential cookies", exact: true })
    .click();
  await until(
    async () => !(await secondDialog.getByRole("checkbox").isChecked()),
  );
  const before = requests.length;
  await usage(second);
  await new Promise((r) => setTimeout(r, 100));
  assert.equal(requests.length, before);
  await second.close();
  await page.setViewportSize({ width: 390, height: 844 });
  assert.equal(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    true,
  );
  await page.screenshot({ path: path.join(output, "privacy-mobile.png") });
  await dialog.getByRole("button", { name: "Close", exact: true }).click();
  await page
    .getByRole("button", { name: "Privacy and data", exact: true })
    .focus();
  await page.keyboard.press("Enter");
  await dialog.waitFor();
  await page.keyboard.press("Escape");
  assert.equal(
    await page
      .getByRole("button", { name: "Privacy and data", exact: true })
      .evaluate((el) => document.activeElement === el),
    true,
  );
  const gpc = await browser.newContext({ reducedMotion: "reduce" });
  await install(gpc);
  await gpc.addInitScript(() =>
    Object.defineProperty(navigator, "globalPrivacyControl", { value: true }),
  );
  const gp = await gpc.newPage();
  await gp.goto(`${target}/?lang=en`);
  assert.equal(
    await gp
      .getByRole("button", { name: "Accept all optional", exact: true })
      .isDisabled(),
    true,
  );
  await gpc.close();
  const blocked = await browser.newContext({ reducedMotion: "reduce" });
  await install(blocked);
  await blocked.addInitScript(() => {
    Storage.prototype.setItem = function () {
      throw Error("synthetic storage disabled");
    };
  });
  const bp = await blocked.newPage();
  await bp.goto(`${target}/?lang=en`);
  await bp
    .getByRole("button", { name: "Accept all optional", exact: true })
    .click();
  await bp
    .getByRole("button", { name: "Privacy and data", exact: true })
    .click();
  assert.match(
    await bp.getByRole("dialog").innerText(),
    /Optional collection is off/,
  );
  await blocked.close();
  for (const mode of ["preference-quota", "quota", "preference-silent"]) {
    const quotaContext = await browser.newContext({ reducedMotion: "reduce" });
    await install(quotaContext);
    const quotaPage = await quotaContext.newPage();
    await quotaPage.goto(`${target}/?lang=en`);
    await quotaPage
      .getByRole("button", { name: "Accept all optional", exact: true })
      .click();
    await usage(quotaPage);
    await until(
      () =>
        h.db.sqlite
          .prepare(
            "SELECT COUNT(*) n FROM collection_records JOIN collection_permissions USING(token_hash) WHERE purpose='analytics'",
          )
          .get().n > 0,
    );
    await quotaPage
      .getByRole("button", { name: "Privacy and data", exact: true })
      .click();
    const quotaDialog = quotaPage.getByRole("dialog", {
      name: "Privacy and data",
      exact: true,
    });
    await quotaDialog
      .getByText("Independent voluntary survey", { exact: true })
      .click();
    await quotaDialog
      .getByLabel("Professional role", { exact: true })
      .selectOption("developer");
    await quotaDialog
      .getByRole("button", { name: "Share my answers with AEKR", exact: true })
      .click();
    await until(
      () =>
        h.db.sqlite
          .prepare(
            "SELECT COUNT(*) n FROM collection_records JOIN collection_permissions USING(token_hash) WHERE purpose='research'",
          )
          .get().n === 1,
    );
    const researchCapability = await quotaPage.evaluate((failureMode) => {
      localStorage.setItem("synthetic:necessary-preference", "preserve");
      localStorage.setItem("synthetic:project-draft", "preserve");
      const research = Object.entries(localStorage).find(([key]) =>
        key.startsWith("accreatio:collect-capability:research:v2:"),
      );
      const original = Storage.prototype.setItem;
      Storage.prototype.setItem = function (key, value) {
        if (
          failureMode === "preference-silent" &&
          key === "accreatio:cookie-preferences"
        )
          return;
        if (failureMode === "quota" || key === "accreatio:cookie-preferences")
          throw new DOMException(
            "synthetic full storage",
            "QuotaExceededError",
          );
        return original.call(this, key, value);
      };
      return research;
    }, mode);
    await quotaDialog
      .getByRole("button", {
        name: "Reject non-essential cookies",
        exact: true,
      })
      .click();
    assert.equal(
      await quotaPage.evaluate(() =>
        localStorage.getItem("accreatio:cookie-preferences"),
      ),
      null,
      `${mode}: failed rejection synchronously removes the earlier positive choice`,
    );
    if (mode !== "quota")
      await until(
        () =>
          h.db.sqlite
            .prepare(
              "SELECT COUNT(*) n FROM collection_records JOIN collection_permissions USING(token_hash) WHERE purpose='analytics'",
            )
            .get().n === 0,
      );
    const analyticsPosts = () =>
      requests.filter((r) => r.action === "record" && r.purpose === "analytics")
        .length;
    const beforeUsage = analyticsPosts();
    await usage(quotaPage);
    await new Promise((resolve) => setTimeout(resolve, 100));
    assert.equal(analyticsPosts(), beforeUsage);
    await quotaPage.reload();
    await usage(quotaPage);
    await new Promise((resolve) => setTimeout(resolve, 100));
    assert.equal(
      analyticsPosts(),
      beforeUsage,
      `${mode}: fresh browser module stays off`,
    );
    assert.deepEqual(
      await quotaPage.evaluate(
        (key) => [
          localStorage.getItem(key),
          localStorage.getItem("synthetic:necessary-preference"),
          localStorage.getItem("synthetic:project-draft"),
        ],
        researchCapability[0],
      ),
      [researchCapability[1], "preserve", "preserve"],
    );
    await quotaPage
      .getByRole("button", {
        name: "Reject non-essential cookies",
        exact: true,
      })
      .click();
    await until(
      () =>
        h.db.sqlite
          .prepare(
            "SELECT COUNT(*) n FROM collection_records JOIN collection_permissions USING(token_hash) WHERE purpose='analytics'",
          )
          .get().n === 0,
    );
    assert.equal(
      h.db.sqlite
        .prepare(
          "SELECT COUNT(*) n FROM collection_records JOIN collection_permissions USING(token_hash) WHERE purpose='research'",
        )
        .get().n,
      1,
      "analytics restriction preserves independently shared research",
    );
    await quotaPage
      .getByRole("button", { name: "Privacy and data", exact: true })
      .click();
    await quotaDialog
      .getByText("Independent voluntary survey", { exact: true })
      .click();
    await quotaDialog
      .getByRole("button", {
        name: "Withdraw research and delete contributions",
        exact: true,
      })
      .click();
    await until(
      () =>
        h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()
          .n === 0,
    );
    await quotaContext.close();
  }
  assert.deepEqual(external, []);
  assert.deepEqual(errors, []);
  const report = {
    result: "PASS",
    scope:
      "Synthetic local built-browser UI + actual receiver/SQLite, no real users/OAuth/external transmission",
    cases: [
      "default off",
      "symmetric first layer",
      "rejection preserves local ZIP",
      "positive allowlisted server delivery",
      "withdrawal deletes contributions",
      "research independent of analytics",
      "optional export manifest",
      "cross-tab restriction and shared grant",
      "mobile width and targets",
      "keyboard/native dialog focus",
      "GPC",
      "storage failure",
      "preference quota rejection survives reload without analytics POSTs",
      "full write quota rejection preserves research, capabilities and local data",
      "silent preference write rejection survives reload without analytics POSTs",
    ],
    serverRecordCount: h.db.sqlite
      .prepare("SELECT COUNT(*) n FROM collection_records")
      .get().n,
    externalRequests: external.length,
  };
  await writeFile(
    path.join(output, "result.json"),
    JSON.stringify(report, null, 2),
  );
  console.log(JSON.stringify(report));
} catch (error) {
  const active = browser?.contexts()[0]?.pages()[0];
  if (active) {
    await active.screenshot({ path: path.join(output, "failure.png") });
    await writeFile(path.join(output, "failure.html"), await active.content());
  }
  throw error;
} finally {
  if (browser) await browser.close();
  preview.kill();
}
