import { spawn as nodeSpawn } from "node:child_process";
import { createHash } from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";

export const AEKR_STATE_SCHEMA_VERSION = 2;

export type OrchestrationDecision =
  | "approve"
  | "reject"
  | "changes-requested"
  | "pause"
  | "escalate"
  | "terminate";

export type RunLifecycle =
  | "RUNNING"
  | "WAITING_HUMAN_APPROVAL"
  | "PAUSED"
  | "BLOCKED"
  | "TIMED_OUT"
  | "FAILED"
  | "CANCELLED"
  | "COMPLETED";

export type AttemptPhase =
  | "WAITING_EXECUTION_APPROVAL"
  | "IN_FLIGHT"
  | "WAITING_RESULT_APPROVAL"
  | "RESULT_BLOCKED";

export interface AekrAttemptSnapshot {
  attempt_id: string;
  step_index: number;
  phase: AttemptPhase;
  action_id?: string | null;
  action_digest?: string | null;
  result_status?: string | null;
  result_summary?: string | null;
}

export interface AekrRunSnapshot {
  schema_version: 2;
  run_id: string;
  project_name: string;
  lifecycle: RunLifecycle;
  revision: number;
  current_step_index: number;
  active_attempt: AekrAttemptSnapshot | null;
  correlation_id: string;
  work_session_id: string;
}

export interface OrchestrationPaths {
  toolkitDir: string;
  configPath: string;
  projectDir: string;
  controlRoot: string;
  controlDir: string;
  statePath: string;
  logPath: string;
  stopPath: string;
}

export interface OrchestrationStartOptions {
  toolkitDir: string;
  configPath: string;
  projectDir: string;
  controlRoot: string;
  pythonCommand?: string;
  newWorkSession?: boolean;
  retryInFlight?: boolean;
}

interface WritableInput {
  write(chunk: string): boolean;
}

interface ChildHandle {
  stdin: WritableInput;
  kill?(): boolean;
  once(
    event: "close" | "error",
    listener: (...args: unknown[]) => void,
  ): unknown;
}

export type SpawnOrchestrator = (
  command: string,
  args: readonly string[],
  options: {
    cwd: string;
    env: NodeJS.ProcessEnv;
    shell: false;
    windowsHide: true;
    stdio: ["pipe", "ignore", "ignore"];
  },
) => ChildHandle;

const DECISION_INPUT: Record<OrchestrationDecision, string> = {
  approve: "1\n",
  reject: "2\n",
  "changes-requested": "3\n",
  pause: "4\n",
  escalate: "5\n",
  terminate: "6\n",
};

const LIFECYCLES = new Set<RunLifecycle>([
  "RUNNING",
  "WAITING_HUMAN_APPROVAL",
  "PAUSED",
  "BLOCKED",
  "TIMED_OUT",
  "FAILED",
  "CANCELLED",
  "COMPLETED",
]);
const ATTEMPT_PHASES = new Set<AttemptPhase>([
  "WAITING_EXECUTION_APPROVAL",
  "IN_FLIGHT",
  "WAITING_RESULT_APPROVAL",
  "RESULT_BLOCKED",
]);

const ensureObject = (
  value: unknown,
  label: string,
): Record<string, unknown> => {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error(`Invalid AEKR ${label}`);
  return value as Record<string, unknown>;
};

export function parseAekrSnapshot(value: unknown): AekrRunSnapshot {
  const state = ensureObject(value, "state snapshot");
  if (state.schema_version !== AEKR_STATE_SCHEMA_VERSION)
    throw new Error(
      `Unsupported AEKR state schema ${String(state.schema_version)}`,
    );
  if (!LIFECYCLES.has(state.lifecycle as RunLifecycle))
    throw new Error("Invalid AEKR lifecycle");
  for (const key of [
    "run_id",
    "project_name",
    "correlation_id",
    "work_session_id",
  ])
    if (typeof state[key] !== "string" || !state[key])
      throw new Error(`Invalid AEKR state field ${key}`);
  for (const key of ["revision", "current_step_index"])
    if (!Number.isInteger(state[key]) || (state[key] as number) < 0)
      throw new Error(`Invalid AEKR state field ${key}`);

  let activeAttempt: AekrAttemptSnapshot | null = null;
  if (state.active_attempt !== null) {
    const attempt = ensureObject(state.active_attempt, "active attempt");
    if (
      typeof attempt.attempt_id !== "string" ||
      !attempt.attempt_id ||
      !Number.isInteger(attempt.step_index) ||
      !ATTEMPT_PHASES.has(attempt.phase as AttemptPhase)
    )
      throw new Error("Invalid AEKR active attempt");
    activeAttempt = attempt as unknown as AekrAttemptSnapshot;
  }
  if (
    state.lifecycle === "WAITING_HUMAN_APPROVAL" &&
    !["WAITING_EXECUTION_APPROVAL", "WAITING_RESULT_APPROVAL"].includes(
      activeAttempt?.phase ?? "",
    )
  )
    throw new Error("AEKR approval state has no gate-waiting attempt");
  return {
    ...state,
    active_attempt: activeAttempt,
  } as unknown as AekrRunSnapshot;
}

function normalizedProjectIdentity(projectDir: string): string {
  const resolved = path.resolve(projectDir);
  return process.platform === "win32"
    ? resolved.replaceAll("/", "\\").toLowerCase()
    : resolved;
}

export function orchestrationPaths(
  options: OrchestrationStartOptions,
): OrchestrationPaths {
  const projectDir = path.resolve(options.projectDir);
  const controlRoot = path.resolve(options.controlRoot);
  const identity = createHash("sha256")
    .update(normalizedProjectIdentity(projectDir), "utf8")
    .digest("hex")
    .slice(0, 24);
  const controlDir = path.join(controlRoot, identity);
  return {
    toolkitDir: path.resolve(options.toolkitDir),
    configPath: path.resolve(options.configPath),
    projectDir,
    controlRoot,
    controlDir,
    statePath: path.join(controlDir, "state.json"),
    logPath: path.join(controlDir, "orchestration-log.jsonl"),
    stopPath: path.join(controlDir, "STOP"),
  };
}

async function existingRealDirectory(candidate: string, label: string) {
  const resolved = await fs.realpath(candidate);
  if (!(await fs.stat(resolved)).isDirectory())
    throw new Error(`${label} must be an existing directory`);
  return resolved;
}

export async function preflightOrchestration(
  options: OrchestrationStartOptions,
): Promise<OrchestrationPaths> {
  const calculated = orchestrationPaths(options);
  const toolkitDir = await existingRealDirectory(
    calculated.toolkitDir,
    "AEKR toolkit",
  );
  const projectDir = await existingRealDirectory(
    calculated.projectDir,
    "Project",
  );
  const configPath = await fs.realpath(calculated.configPath);
  if (!(await fs.stat(configPath)).isFile())
    throw new Error("AEKR config must be an existing file");
  const configRoot = await existingRealDirectory(
    path.join(projectDir, ".ai-engineering"),
    "AEKR config directory",
  );
  const configRelative = path.relative(configRoot, configPath);
  if (
    configRelative === "" ||
    configRelative.startsWith("..") ||
    path.isAbsolute(configRelative)
  )
    throw new Error(
      "AEKR config must be inside the project's .ai-engineering directory",
    );
  await fs.access(path.join(toolkitDir, "runtime", "cli.py"));
  await fs.mkdir(calculated.controlRoot, { recursive: true });
  const controlRoot = await existingRealDirectory(
    calculated.controlRoot,
    "Control root",
  );
  const relative = path.relative(projectDir, controlRoot);
  if (
    relative === "" ||
    (!relative.startsWith("..") && !path.isAbsolute(relative))
  )
    throw new Error("AEKR control root must be outside the project directory");
  return orchestrationPaths({
    ...options,
    toolkitDir,
    projectDir,
    configPath,
    controlRoot,
  });
}

export class OrchestrationController {
  private child: ChildHandle | null = null;
  private paths: OrchestrationPaths | null = null;
  private submittedRevision: number | null = null;

  constructor(
    private readonly spawnProcess: SpawnOrchestrator = nodeSpawn as SpawnOrchestrator,
  ) {}

  get active(): boolean {
    return this.child !== null;
  }

  async start(options: OrchestrationStartOptions): Promise<OrchestrationPaths> {
    if (this.child) throw new Error("An AEKR process is already active");
    if (options.retryInFlight && !options.newWorkSession)
      throw new Error("retryInFlight requires newWorkSession");
    const paths = await preflightOrchestration(options);
    await fs.rm(paths.stopPath, { force: true });
    const args = [
      "-B",
      "-m",
      "runtime.cli",
      "--config",
      paths.configPath,
      "--project-dir",
      paths.projectDir,
    ];
    if (options.newWorkSession) args.push("--new-work-session");
    if (options.retryInFlight) args.push("--retry-in-flight");
    const child = this.spawnProcess(options.pythonCommand ?? "python", args, {
      cwd: paths.toolkitDir,
      env: {
        ...process.env,
        PYTHONPATH: paths.toolkitDir,
        AEKR_CONTROL_ROOT: paths.controlRoot,
      },
      shell: false,
      windowsHide: true,
      // stdout is human-oriented, not a protocol; the durable state/journal
      // are authoritative. Ignoring both output streams also prevents an
      // unattended child from blocking on a full pipe buffer.
      stdio: ["pipe", "ignore", "ignore"],
    });
    this.child = child;
    this.paths = paths;
    this.submittedRevision = null;
    const cleanup = () => {
      if (this.child === child) this.child = null;
      void fs.rm(paths.stopPath, { force: true });
    };
    child.once("close", cleanup);
    child.once("error", cleanup);
    return paths;
  }

  async snapshot(): Promise<AekrRunSnapshot | null> {
    if (!this.paths) return null;
    try {
      return parseAekrSnapshot(
        JSON.parse(await fs.readFile(this.paths.statePath, "utf8")),
      );
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
      throw error;
    }
  }

  async decide(decision: OrchestrationDecision): Promise<void> {
    if (!this.child) throw new Error("No active AEKR process");
    const state = await this.snapshot();
    if (!state || state.lifecycle !== "WAITING_HUMAN_APPROVAL")
      throw new Error("AEKR is not waiting for a human decision");
    if (this.submittedRevision === state.revision)
      throw new Error(
        "A decision was already submitted for this state revision",
      );
    this.submittedRevision = state.revision;
    if (!this.child.stdin.write(DECISION_INPUT[decision])) {
      this.submittedRevision = null;
      throw new Error("Could not submit the AEKR decision");
    }
  }

  async cancel(): Promise<void> {
    if (!this.child || !this.paths) throw new Error("No active AEKR process");
    await fs.mkdir(this.paths.controlDir, { recursive: true });
    try {
      await fs.writeFile(
        this.paths.stopPath,
        "cancel requested by accreatio\n",
        {
          encoding: "utf8",
          flag: "wx",
          mode: 0o600,
        },
      );
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
    }
  }

  async shutdown(timeoutMs = 5_000): Promise<void> {
    const child = this.child;
    if (!child) return;
    await this.cancel();
    if (this.child !== child) return;
    await new Promise<void>((resolve) => {
      const timeout = setTimeout(resolve, timeoutMs);
      child.once("close", () => {
        clearTimeout(timeout);
        resolve();
      });
    });
    if (this.child === child) child.kill?.();
  }
}
