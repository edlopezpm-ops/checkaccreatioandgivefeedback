import fs from "node:fs/promises";
import { constants, existsSync } from "node:fs";
import path from "node:path";
import { portableLeafName } from "../shared/inputValidation.js";
import { MAX_FILE_BYTES } from "../shared/domain.js";

/** Reject pre-existing symlink/junction ancestors before creating directories.
 * This is not a sandbox against a local process concurrently replacing parents. */
export async function ensureSafeDirectory(dir: string) {
  const absolute = path.resolve(dir);
  const check = async () => {
    let current = absolute;
    for (;;) {
      try {
        const st = await fs.lstat(current);
        if (st.isSymbolicLink() || !st.isDirectory())
          throw new Error("Unsafe project destination");
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      }
      const parent = path.dirname(current);
      if (parent === current) break;
      current = parent;
    }
  };
  await check();
  await fs.mkdir(absolute, { recursive: true });
  await check();
  return absolute;
}

export function containedFilePath(dir: string, name: string) {
  if (!portableLeafName(name)) throw new Error("Invalid destination filename");
  const target = path.resolve(dir, name);
  if (path.dirname(target) !== path.resolve(dir))
    throw new Error("File destination is outside the selected directory");
  return target;
}

export async function versionedPath(dir: string, name: string) {
  const ext = path.extname(name);
  const base = path.basename(name, ext);
  let candidate = containedFilePath(dir, name);
  let index = 1;
  while (existsSync(candidate))
    candidate = containedFilePath(dir, `${base} (${index++})${ext}`);
  return candidate;
}

export async function writeVersioned(
  dir: string,
  name: string,
  content: string,
) {
  containedFilePath(dir, name);
  await ensureSafeDirectory(dir);
  for (;;) {
    const target = await versionedPath(dir, name);
    try {
      await fs.writeFile(target, content, { encoding: "utf8", flag: "wx" });
      return target;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
    }
  }
}

export interface SelectedFileIdentity {
  size: number;
  mtimeMs: number;
  ino: number;
  dev: number;
}
export const sameFileIdentity = (
  actual: SelectedFileIdentity,
  expected: SelectedFileIdentity,
) =>
  actual.size === expected.size &&
  actual.mtimeMs === expected.mtimeMs &&
  actual.ino === expected.ino &&
  actual.dev === expected.dev;

export async function copyVersioned(
  source: string,
  dir: string,
  name: string,
  expected?: SelectedFileIdentity,
) {
  containedFilePath(dir, name);
  const st = await fs.lstat(source);
  if (
    !st.isFile() ||
    st.isSymbolicLink() ||
    st.size > MAX_FILE_BYTES ||
    (expected && !sameFileIdentity(st, expected))
  )
    throw new Error("Attachment changed; select it again");
  const input = await fs.open(
    source,
    constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0),
  );
  try {
    const selected = expected ?? st;
    const actual = await input.stat();
    if (!actual.isFile() || !sameFileIdentity(actual, selected))
      throw new Error("Attachment changed; select it again");
    await ensureSafeDirectory(dir);
    for (;;) {
      const target = await versionedPath(dir, name);
      let output;
      try {
        output = await fs.open(target, "wx");
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "EEXIST") continue;
        throw error;
      }
      try {
        const buffer = Buffer.alloc(64 * 1024);
        let copied = 0;
        while (copied < selected.size) {
          const { bytesRead } = await input.read(
            buffer,
            0,
            Math.min(buffer.length, selected.size - copied),
            copied,
          );
          if (!bytesRead)
            throw new Error("Attachment changed; select it again");
          let written = 0;
          while (written < bytesRead) {
            const { bytesWritten } = await output.write(
              buffer,
              written,
              bytesRead - written,
              copied + written,
            );
            if (!bytesWritten)
              throw new Error("Attachment copy could not finish");
            written += bytesWritten;
          }
          copied += bytesRead;
        }
        if (!sameFileIdentity(await input.stat(), selected))
          throw new Error("Attachment changed; select it again");
        await output.close();
        return target;
      } catch (error) {
        await output.close().catch(() => undefined);
        await fs.unlink(target).catch(() => undefined);
        throw error;
      }
    }
  } finally {
    await input.close();
  }
}
