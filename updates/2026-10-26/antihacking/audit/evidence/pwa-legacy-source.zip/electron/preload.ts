import { contextBridge, ipcRenderer } from "electron";
contextBridge.exposeInMainWorld("accreatio", {
  chooseFolder: () => ipcRenderer.invoke("dialog:folder"),
  chooseAttachments: () => ipcRenderer.invoke("dialog:attachments"),
  loadSettings: () => ipcRenderer.invoke("settings:load"),
  saveSettings: (s: unknown) => ipcRenderer.invoke("settings:save", s),
  githubStatus: () => ipcRenderer.invoke("github:status"),
  connectGithub: () => ipcRenderer.invoke("github:connect"),
  loadHistory: () => ipcRenderer.invoke("history:load"),
  execute: (request: unknown) => ipcRenderer.invoke("project:execute", request),
  checkProviders: () => ipcRenderer.invoke("providers:check"),
  orchestrationPreflight: (request: unknown) =>
    ipcRenderer.invoke("orchestration:preflight", request),
  orchestrationStart: (request: unknown) =>
    ipcRenderer.invoke("orchestration:start", request),
  orchestrationSnapshot: () => ipcRenderer.invoke("orchestration:snapshot"),
  orchestrationDecide: (decision: unknown) =>
    ipcRenderer.invoke("orchestration:decide", decision),
  orchestrationCancel: () => ipcRenderer.invoke("orchestration:cancel"),
});
