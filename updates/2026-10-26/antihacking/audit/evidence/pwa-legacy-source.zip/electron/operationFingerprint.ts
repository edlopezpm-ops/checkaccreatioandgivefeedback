import { createHash } from "node:crypto";
import type { ExecutionRequest } from "../src/types.js";
import {
  canonicalJson,
  executionFingerprintValue,
} from "../src/operationGuard.js";

export async function nodeExecutionFingerprint(
  request: ExecutionRequest,
): Promise<string> {
  return createHash("sha256")
    .update(canonicalJson(executionFingerprintValue(request)), "utf8")
    .digest("hex");
}
