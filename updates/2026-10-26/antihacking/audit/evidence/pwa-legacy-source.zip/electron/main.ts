import {
  app,
  BrowserWindow,
  dialog,
  ipcMain,
  shell,
  type IpcMainInvokeEvent,
} from "electron";
import path from "node:path";
import os from "node:os";
import fs from "node:fs/promises";
import { existsSync, realpathSync } from "node:fs";
import { spawn } from "node:child_process";
import { pathToFileURL } from "node:url";
import {
  ACCEPTED_EXTENSIONS,
  discoveryMd,
  defaultOrchestration,
  generatePrompt,
  governance,
  projectSignature,
  renderOrchestrationConfig,
  slugify,
  validationErrors,
} from "../shared/domain.js";
import type {
  ProjectDefinition as Definition,
  Settings,
} from "../shared/domain.js";
import type {
  ArtifactEvidence,
  ExecutionRequest,
  ExecutionResult,
  ExecutionStepResult,
} from "../src/types.js";
import {
  LogicalOperationGuard,
  validateExecutionRequest,
} from "../src/operationGuard.js";
import { nodeExecutionFingerprint } from "./operationFingerprint.js";
import {
  PROVIDER_REGISTRY,
  availabilityById,
  isProviderId,
  type FixedCliProbe,
  type ProviderAvailability,
  type ProviderAvailabilityResult,
  type ProviderDescriptor,
} from "../shared/providerRegistry.js";
import {
  copyVersioned,
  writeVersioned,
  ensureSafeDirectory,
  sameFileIdentity,
  type SelectedFileIdentity,
} from "./files.js";
import {
  assertSettingsShape,
  portableLeafName,
} from "../shared/inputValidation.js";
import {
  OrchestrationController,
  preflightOrchestration,
  type OrchestrationDecision,
} from "./orchestration.js";
const ACCEPTED = new Set<string>(ACCEPTED_EXTENSIONS);
const selectedAttachments = new Map<
  string,
  SelectedFileIdentity & { name: string; extension: string }
>();
const trustedWindowIds = new Set<number>();

function requireTrustedSender(event: IpcMainInvokeEvent) {
  if (
    !trustedWindowIds.has(event.sender.id) ||
    !event.senderFrame ||
    event.senderFrame !== event.sender.mainFrame
  )
    throw new Error("Untrusted application request");
  const current = event.senderFrame.url;
  if (executeSmokeRequested && current === EXECUTE_SMOKE_DOCUMENT) return;
  const devUrl = process.env.VITE_DEV_SERVER_URL;
  const expected = devUrl
    ? new URL("desktop.html", devUrl).href
    : pathToFileURL(
        path.join(__dirname, "..", "..", "dist-desktop", "desktop.html"),
      ).href;
  const actualUrl = new URL(current);
  const expectedUrl = new URL(expected);
  if (
    actualUrl.origin !== expectedUrl.origin ||
    actualUrl.pathname !== expectedUrl.pathname ||
    actualUrl.protocol !== expectedUrl.protocol
  )
    throw new Error("Untrusted application request");
}
const handleTrusted = (
  channel: string,
  listener: Parameters<typeof ipcMain.handle>[1],
) =>
  ipcMain.handle(channel, (event, ...args) => {
    requireTrustedSender(event);
    return listener(event, ...args);
  });
const defaults = (): Settings => {
  const docs = app.getPath("documents");
  return {
    baseFolder: path.join(docs, "Projects"),
    toolkitPath: "",
    futureProjectsPath: "",
    defaultBranch: "main",
    preferredIde: "VS Code",
    theme: "dark",
    locale: "es",
    confirmBeforeRun: true,
  };
};
const dataFile = (name: string) => path.join(app.getPath("userData"), name);
async function readJson<T>(file: string, fallback: T): Promise<T> {
  try {
    return { ...fallback, ...JSON.parse(await fs.readFile(file, "utf8")) };
  } catch {
    return fallback;
  }
}
// Remove legacy product-name migration at 1.0.0 after the private beta migration window.
const legacyDataFiles = (name: string) =>
  ["Inflaton", "Periastron"].map((product) =>
    path.join(app.getPath("appData"), product, name),
  );
async function readMigrated<T>(name: string, fallback: T): Promise<T> {
  const current = dataFile(name);
  if (!executeSmokeRequested && !existsSync(current)) {
    const legacy = legacyDataFiles(name).find(existsSync);
    if (legacy) {
      await fs.mkdir(path.dirname(current), { recursive: true });
      await fs.copyFile(legacy, current);
    }
  }
  return readJson(current, fallback);
}
const run = (cmd: string, args: string[], cwd: string) =>
  new Promise<string>((resolve, reject) => {
    const c = spawn(cmd, args, { cwd, windowsHide: true });
    let out = "",
      err = "";
    c.stdout.on("data", (d) => (out += d));
    c.stderr.on("data", (d) => (err += d));
    c.on("error", reject);
    c.on("close", (code) =>
      code === 0
        ? resolve(out.trim())
        : reject(new Error(err.trim() || `${cmd} exited ${code}`)),
    );
  });
// Diagnostic-only: never throws, and reads both streams. Some CLI builds
// print human-readable status to stderr even on success (verified for
// `codex login status` during the AEKR Mode 1 pilot) -- a throwing,
// stdout-only helper would misreport a genuinely valid login as absent.
const MAX_PROVIDER_DIAGNOSTIC_CHARS = 4096;
const sanitizeProviderDiagnostic = (value: string) =>
  value
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "")
    .slice(0, MAX_PROVIDER_DIAGNOSTIC_CHARS);
const runProviderProbe = (
  descriptor: ProviderDescriptor,
  probe: FixedCliProbe,
): Promise<{ code: number | null; combined: string }> =>
  new Promise((resolve) => {
    let combined = "";
    const append = (data: unknown) => {
      if (combined.length >= MAX_PROVIDER_DIAGNOSTIC_CHARS) return;
      combined = sanitizeProviderDiagnostic(combined + String(data));
    };
    try {
      if (!PROVIDER_REGISTRY.includes(descriptor))
        return resolve({ code: null, combined: "" });
      const c = spawn(probe.executable, [...probe.argv], {
        cwd: app.getPath("home"),
        windowsHide: true,
      });
      c.stdout.on("data", append);
      c.stderr.on("data", append);
      c.on("error", () => resolve({ code: null, combined }));
      c.on("close", (code) => resolve({ code, combined }));
    } catch {
      resolve({ code: null, combined });
    }
  });
async function checkProvider(
  descriptor: ProviderDescriptor,
): Promise<ProviderAvailabilityResult> {
  const version = await runProviderProbe(
    descriptor,
    descriptor.desktopDetection.versionProbe,
  );
  if (version.code !== 0)
    return {
      providerId: descriptor.id,
      state: "not_installed",
      reasonCode: "cli_not_found",
    };
  const auth = await runProviderProbe(
    descriptor,
    descriptor.desktopDetection.authProbe,
  );
  return {
    providerId: descriptor.id,
    ...descriptor.desktopDetection.classifyAuth(auth),
  };
}
async function checkProviders(): Promise<ProviderAvailability> {
  return Promise.all(PROVIDER_REGISTRY.map(checkProvider));
}
async function requireFreshProvidersForConfig(configPath: string) {
  const config = await fs.readFile(configPath, "utf8");
  if (
    /^\s*max_budget_usd\s*:/m.test(config) ||
    /^\s*ceiling\s*:/m.test(config) ||
    /^\s*model_profile\s*:/m.test(config) ||
    /funding:\s*\n\s*mode:\s*api\b/m.test(config)
  )
    throw new Error("api_exact_hard_stop_unavailable");
  const requested = [
    ...config.matchAll(/^\s+kind:\s+([a-z][a-z0-9_]*)\s*$/gm),
  ].map((match) => match[1]);
  if (
    !requested.length ||
    requested.some((provider) => !isProviderId(provider))
  )
    throw new Error("Provider configuration is missing or unsupported");
  const availability = availabilityById(await checkProviders());
  for (const providerId of new Set(requested)) {
    if (!isProviderId(providerId)) continue;
    const result = availability.get(providerId);
    if (result?.state !== "installed_authenticated")
      throw new Error(
        `${PROVIDER_REGISTRY.find(({ id }) => id === providerId)?.displayName ?? providerId} is not ready: ${result?.reasonCode ?? "auth_status_unreadable"}`,
      );
  }
}
async function githubStatus() {
  try {
    await run("gh", ["--version"], app.getPath("home"));
    try {
      const login = await run(
        "gh",
        ["api", "user", "--jq", ".login"],
        app.getPath("home"),
      );
      return { installed: true, authenticated: true, login };
    } catch {
      return { installed: true, authenticated: false };
    }
  } catch {
    return { installed: false, authenticated: false };
  }
}
async function execute(request: ExecutionRequest): Promise<ExecutionResult> {
  const { operationId, definition: d, settings: s } = request;
  const logs: string[] = [];
  const artifacts: ArtifactEvidence[] = [];
  const stepIds = [
    ...(d.action !== "tracking"
      ? ["repository-root", "repository-docs", "attachments"]
      : []),
    ...(d.initializeGit && d.action !== "tracking" ? ["git"] : []),
    ...(d.createRemote && d.action !== "tracking" ? ["github"] : []),
    ...(d.action !== "repository" ? ["tracking"] : []),
    "history",
    ...(d.openIde && d.action !== "tracking" ? ["ide"] : []),
  ];
  const steps: ExecutionStepResult[] = stepIds.map((id) => ({
    id,
    status: "skipped",
    summary: "Not attempted",
    artifacts: [],
  }));
  const log = (m: string) => logs.push(`[${new Date().toISOString()}] ${m}`);
  const slug = slugify(d.name),
    projectPath = path.resolve(d.destination, slug),
    trackingPath = s.futureProjectsPath
      ? path.resolve(s.futureProjectsPath, slug)
      : "";
  let durableEffect = false;
  const step = (id: string) => steps.find((entry) => entry.id === id)!;
  const evidence = (
    id: string,
    kind: ArtifactEvidence["kind"],
    location: string,
    displayName = path.basename(location),
  ) => {
    const item = { kind, location, displayName };
    artifacts.push(item);
    step(id).artifacts.push(item);
    return item;
  };
  const complete = (id: string, summary: string) =>
    Object.assign(step(id), { status: "completed" as const, summary });
  let activeStep: ExecutionStepResult | undefined;
  const runStep = async (
    id: string,
    summary: string,
    work: () => Promise<void>,
  ) => {
    activeStep = step(id);
    await work();
    complete(id, summary);
    activeStep = undefined;
  };
  const result = (
    ok: boolean,
    outcome: ExecutionResult["outcome"],
    error?: string,
  ): ExecutionResult => ({
    operationId,
    ok,
    dryRun: d.dryRun,
    projectPath,
    completed: steps
      .filter(({ status }) => status === "completed")
      .map(({ id }) => id),
    logs,
    ...(error ? { error } : {}),
    outcome,
    steps,
    artifacts,
  });
  try {
    const validation = validationErrors(d, s);
    if (Object.keys(validation).length)
      throw new Error(
        `Invalid project definition: ${Object.values(validation).join(", ")}`,
      );
    for (const a of d.attachments) {
      if (!("path" in a) || typeof a.path !== "string" || !a.path)
        throw new Error(
          "Invalid project definition: desktop attachment path is required",
        );
      const selected = selectedAttachments.get(a.path);
      if (
        !selected ||
        selected.name !== a.name ||
        selected.extension !== a.extension ||
        selected.size !== a.size
      )
        throw new Error(
          "Attachment is not an authorized file selection; select it again",
        );
      const actual = await fs.lstat(a.path);
      if (
        !actual.isFile() ||
        actual.isSymbolicLink() ||
        !sameFileIdentity(actual, selected)
      )
        throw new Error("Attachment changed; select it again");
    }
    if (d.dryRun) {
      log(
        `${existsSync(projectPath) ? "Would augment existing" : "Would create"}: ${projectPath}`,
      );
      d.attachments.forEach((a) => log(`Would copy: ${a.name}`));
      for (const item of steps) item.summary = "Skipped because Dry run is on";
      return result(true, "dry-run");
    }
    if (d.action !== "tracking") {
      const repoExists = existsSync(projectPath);
      await runStep("repository-root", "Repository ready", async () => {
        await ensureSafeDirectory(
          path.join(projectPath, "docs", "product", "sources"),
        );
        await ensureSafeDirectory(path.join(projectPath, ".accreatio"));
        durableEffect ||= !repoExists;
        evidence(
          "repository-root",
          "repository-root",
          projectPath,
          "Repository used",
        );
      });
      log(
        repoExists
          ? "Existing project detected; using versioned writes."
          : `Created ${projectPath}`,
      );
      await runStep(
        "repository-docs",
        "Generated project documents",
        async () => {
          const write = async (dir: string, name: string, content: string) => {
            const target = await writeVersioned(dir, name, content);
            durableEffect = true;
            evidence("repository-docs", "generated-file", target);
          };
          await write(
            projectPath,
            "PROJECT_PROMPT.md",
            generatePrompt(d, s.locale),
          );
          await write(
            path.join(projectPath, "docs", "product"),
            "discovery.md",
            discoveryMd(d),
          );
          await write(projectPath, "AGENTS.md", governance(d));
          const signature = projectSignature(d, {
            createdBy: "accreatio",
            appVersion: app.getVersion(),
          });
          await write(
            path.join(projectPath, ".accreatio"),
            "project.json",
            JSON.stringify(signature, null, 2),
          );
          if (d.orchestration.enabled) {
            await write(
              path.join(projectPath, ".ai-engineering"),
              "orchestration.yaml",
              renderOrchestrationConfig(d, s),
            );
            log("Orchestration starting config written to .ai-engineering/");
          }
        },
      );
      await runStep("attachments", "Copied discovery sources", async () => {
        for (const a of d.attachments) {
          if (!("path" in a) || typeof a.path !== "string" || !a.path)
            throw new Error(
              "Invalid project definition: desktop attachment path is required",
            );
          const target = await copyVersioned(
            a.path,
            path.join(projectPath, "docs", "product", "sources"),
            a.name,
            selectedAttachments.get(a.path),
          );
          durableEffect = true;
          evidence("attachments", "attachment", target);
          log(`Copied source: ${path.basename(target)}`);
        }
      });
      if (d.initializeGit) {
        await runStep("git", "Git repository ready", async () => {
          if (!existsSync(path.join(projectPath, ".git"))) {
            await run(
              "git",
              ["init", "-b", s.defaultBranch || "main"],
              projectPath,
            );
            durableEffect = true;
          }
          evidence(
            "git",
            "git-repository",
            path.join(projectPath, ".git"),
            ".git",
          );
          log("Git ready");
        });
      }
      if (d.createRemote) {
        await runStep(
          "github",
          "GitHub remote created; no push performed",
          async () => {
            const st = await githubStatus();
            if (!st.authenticated)
              throw new Error(
                "GitHub CLI is not authenticated. Connect it in Settings.",
              );
            const visibility = d.remotePrivate ? "--private" : "--public";
            await run(
              "gh",
              [
                "repo",
                "create",
                slug,
                visibility,
                "--source",
                projectPath,
                "--remote",
                "origin",
              ],
              projectPath,
            );
            durableEffect = true;
            const location = st.login
              ? `https://github.com/${st.login}/${slug}`
              : slug;
            evidence(
              "github",
              "github-remote",
              location,
              "origin (no push performed)",
            );
            log("GitHub repository created; no push performed");
          },
        );
      }
    }
    if (d.action !== "repository") {
      await runStep(
        "tracking",
        "Tracking written with version protection",
        async () => {
          await ensureSafeDirectory(trackingPath);
          const target = await writeVersioned(
            trackingPath,
            "PROJECT_STATUS.md",
            `# ${d.name} — Project Status\n\n- Phase: ${d.phase}\n- Route: ${d.route}\n- Dedicated repo: ${d.action === "both" ? projectPath : "Not created"}\n- Created by: accreatio ${app.getVersion()}\n\n## Context\n\n${d.context}\n`,
          );
          durableEffect = true;
          evidence("tracking", "tracking-file", target);
          log("Tracking written with version protection");
        },
      );
    }
    await runStep("history", "Execution history updated", async () => {
      const history = await readMigrated<{ entries: unknown[] }>(
        "history.json",
        { entries: [] },
      );
      history.entries.unshift({
        id: crypto.randomUUID(),
        name: d.name,
        path: projectPath,
        createdAt: new Date().toISOString(),
        action: d.action,
      });
      history.entries = history.entries.slice(0, 50);
      await fs.writeFile(
        dataFile("history.json"),
        JSON.stringify(history, null, 2),
        "utf8",
      );
      durableEffect = true;
    });
    if (d.openIde && d.action !== "tracking") {
      await runStep("ide", "IDE launch requested", async () => {
        if (s.preferredIde === "VS Code")
          await run("code", ["--new-window", projectPath], projectPath);
        else {
          const openError = await shell.openPath(projectPath);
          if (openError) throw new Error(openError);
        }
        evidence("ide", "ide-launch", projectPath, s.preferredIde);
      });
    }
    return result(true, "success");
  } catch (e) {
    const error = e instanceof Error ? e.message : String(e);
    if (activeStep)
      Object.assign(activeStep, {
        status: "failed" as const,
        summary: "Step failed",
        error,
      });
    log(`ERROR — ${error}`);
    return result(
      false,
      durableEffect || artifacts.length > 0 ? "partial" : "failure",
      error,
    );
  }
}

const EXECUTE_SMOKE_PREFIX = "--accreatio-execute-smoke=";
const executeSmokeRequested = process.argv.some((value) =>
  value.startsWith(EXECUTE_SMOKE_PREFIX),
);
const EXECUTE_SMOKE_DOCUMENT = `data:text/html;charset=utf-8,${encodeURIComponent(
  "<!doctype html><meta charset=\"utf-8\"><meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; script-src 'none'; connect-src 'none'\"><title>accreatio execute smoke</title>",
)}`;

if (executeSmokeRequested && !app.isPackaged) {
  app.commandLine.appendSwitch("noerrdialogs");
}

function requestedExecuteSmokeRoot(): string | null {
  const argument = process.argv.find((value) =>
    value.startsWith(EXECUTE_SMOKE_PREFIX),
  );
  if (!argument) return null;
  if (app.isPackaged)
    throw new Error(
      "The execute smoke hook is unavailable in packaged builds.",
    );
  const candidate = realpathSync(
    path.resolve(argument.slice(EXECUTE_SMOKE_PREFIX.length)),
  );
  const temporaryRoot = realpathSync(os.tmpdir());
  if (
    path.dirname(candidate).toLocaleLowerCase("en-US") !==
      temporaryRoot.toLocaleLowerCase("en-US") ||
    !path.basename(candidate).startsWith("accreatio-execute-")
  )
    throw new Error(
      "The execute smoke root must be an isolated temp directory.",
    );
  return candidate;
}

const inlineJson = (value: unknown) =>
  JSON.stringify(value)
    .replaceAll("&", "\\u0026")
    .replaceAll("<", "\\u003c")
    .replaceAll(">", "\\u003e")
    .replaceAll("\u2028", "\\u2028")
    .replaceAll("\u2029", "\\u2029");

async function runExecuteSmoke(win: BrowserWindow, root: string) {
  const definition: Definition = {
    name: "Execution Smoke",
    phase: "idea",
    context: "Exercise the real privileged IPC execution path.",
    restrictions: "Temporary isolated directory only.",
    route: "local",
    action: "repository",
    destination: root,
    participants: [{ id: "participant-01", role: "generalist", label: "" }],
    attachments: [],
    initializeGit: false,
    createRemote: false,
    remotePrivate: true,
    openIde: false,
    dryRun: false,
    orchestration: {
      ...defaultOrchestration(),
      sessionMaxDurationSeconds: 7200,
      maxIterationsPerEntity: 3,
      maxProviderInvocations: 20,
      maxConsecutiveFailures: 2,
    },
  };
  const settings: Settings = {
    baseFolder: root,
    toolkitPath: "",
    futureProjectsPath: "",
    defaultBranch: "main",
    preferredIde: "VS Code",
    theme: "dark",
    locale: "en",
    confirmBeforeRun: true,
  };
  const resultFile = path.join(root, "smoke-result.json");
  let exitCode = 1;
  let envelope: unknown;
  try {
    const payload = inlineJson({ definition, settings });
    const result = await win.webContents.executeJavaScript(
      `(() => {
        const payload = ${payload};
        if (!window.accreatio) throw new Error("preload bridge unavailable");
        const request = (operationId, definition = payload.definition) => ({
          operationId, definition, settings: payload.settings
        });
        return (async () => {
          const id1 = "00000000-0000-4000-8000-000000000001";
          const concurrent = await Promise.all([
            window.accreatio.execute(request(id1)),
            window.accreatio.execute(request(id1)),
            window.accreatio.execute(request("00000000-0000-4000-8000-000000000002")),
          ]);
          const rerun = await window.accreatio.execute(request("00000000-0000-4000-8000-000000000003"));
          const invalid = { ...payload.definition, name: "" };
          const failureId = "00000000-0000-4000-8000-000000000004";
          const failures = await Promise.all([
            window.accreatio.execute(request(failureId, invalid)),
            window.accreatio.execute(request(failureId, invalid)),
          ]);
          const recovery = await window.accreatio.execute(request("00000000-0000-4000-8000-000000000005"));
          return { concurrent, rerun, failures, recovery };
        })();
      })()`,
    );
    envelope = { result };
    exitCode =
      result?.concurrent?.every((item: { ok?: boolean }) => item.ok) &&
      result?.rerun?.ok === true &&
      result?.failures?.every((item: { ok?: boolean }) => item.ok === false) &&
      result?.recovery?.ok === true
        ? 0
        : 1;
  } catch (error) {
    envelope = {
      fatalError: error instanceof Error ? error.message : String(error),
    };
  }
  try {
    await fs.writeFile(resultFile, JSON.stringify(envelope, null, 2), {
      encoding: "utf8",
      flag: "wx",
    });
  } catch (error) {
    console.error(
      `Execute smoke could not write its result: ${error instanceof Error ? error.message : String(error)}`,
    );
    exitCode = 1;
  }
  app.exit(exitCode);
}

function createWindow({
  show = true,
  onDidFinishLoad,
}: {
  show?: boolean;
  onDidFinishLoad?: (win: BrowserWindow) => void;
} = {}) {
  const win = new BrowserWindow({
    show,
    width: 1480,
    height: 940,
    minWidth: 1080,
    minHeight: 720,
    backgroundColor: "#0b0f14",
    title: "accreatio",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  const trustedWindowId = win.webContents.id;
  trustedWindowIds.add(trustedWindowId);
  win.webContents.once("destroyed", () =>
    trustedWindowIds.delete(trustedWindowId),
  );
  win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
  win.webContents.session.setPermissionRequestHandler(
    (_webContents, _permission, callback) => callback(false),
  );
  if (!executeSmokeRequested)
    win.webContents.on("will-navigate", (event, url) => {
      const devUrl = process.env.VITE_DEV_SERVER_URL;
      const productionUrl = pathToFileURL(
        path.join(__dirname, "..", "..", "dist-desktop", "desktop.html"),
      ).href;
      const allowed = devUrl
        ? new URL(url).origin === new URL(devUrl).origin
        : url.startsWith(productionUrl);
      if (!allowed) event.preventDefault();
    });
  if (onDidFinishLoad)
    win.webContents.once("did-finish-load", () => onDidFinishLoad(win));
  if (executeSmokeRequested) win.loadURL(EXECUTE_SMOKE_DOCUMENT);
  else if (process.env.VITE_DEV_SERVER_URL)
    win.loadURL(new URL("desktop.html", process.env.VITE_DEV_SERVER_URL).href);
  else
    win.loadFile(
      path.join(__dirname, "..", "..", "dist-desktop", "desktop.html"),
    );
  return win;
}
app.whenReady().then(() => {
  const orchestration = new OrchestrationController();
  app.once("before-quit", (event) => {
    if (!orchestration.active) return;
    event.preventDefault();
    void orchestration.shutdown().finally(() => app.quit());
  });
  const orchestrationOptions = (value: unknown) => {
    if (!value || typeof value !== "object" || Array.isArray(value))
      throw new Error("Invalid orchestration request");
    const request = value as Record<string, unknown>;
    for (const key of ["toolkitDir", "projectDir", "configPath"])
      if (typeof request[key] !== "string" || !request[key])
        throw new Error(`Invalid orchestration field ${key}`);
    const requestedToolkit = request.toolkitDir as string;
    const toolkitDir = existsSync(
      path.join(requestedToolkit, "runtime", "cli.py"),
    )
      ? requestedToolkit
      : path.join(requestedToolkit, "toolkit", "orchestrator");
    return {
      toolkitDir,
      projectDir: request.projectDir as string,
      configPath: request.configPath as string,
      controlRoot: dataFile("orchestration"),
      newWorkSession: request.newWorkSession === true,
      retryInFlight: request.retryInFlight === true,
    };
  };
  let smokeRoot: string | null;
  try {
    smokeRoot = requestedExecuteSmokeRoot();
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    app.exit(2);
    return;
  }
  handleTrusted("dialog:folder", async () => {
    const r = await dialog.showOpenDialog({
      properties: ["openDirectory", "createDirectory"],
    });
    return r.canceled ? null : r.filePaths[0];
  });
  handleTrusted("dialog:attachments", async () => {
    const r = await dialog.showOpenDialog({
      properties: ["openFile", "multiSelections"],
      filters: [
        {
          name: "Discovery sources",
          extensions: [...ACCEPTED].map((x) => x.slice(1)),
        },
      ],
    });
    if (r.canceled) return [];
    return Promise.all(
      r.filePaths.map(async (p) => {
        const st = await fs.lstat(p);
        if (
          !st.isFile() ||
          st.isSymbolicLink() ||
          !portableLeafName(path.basename(p))
        )
          throw new Error("Unsupported attachment source or filename");
        selectedAttachments.set(p, {
          size: st.size,
          mtimeMs: st.mtimeMs,
          ino: st.ino,
          dev: st.dev,
          name: path.basename(p),
          extension: path.extname(p).toLowerCase(),
        });
        return {
          path: p,
          name: path.basename(p),
          size: st.size,
          extension: path.extname(p).toLowerCase(),
        };
      }),
    );
  });
  handleTrusted("settings:load", () =>
    readMigrated("settings.json", defaults()),
  );
  handleTrusted("settings:save", async (_e, s) => {
    assertSettingsShape(s);
    await fs.writeFile(
      dataFile("settings.json"),
      JSON.stringify(s, null, 2),
      "utf8",
    );
  });
  handleTrusted("github:status", githubStatus);
  handleTrusted("github:connect", async () => {
    spawn("gh", ["auth", "login", "--web", "--git-protocol", "https"], {
      detached: true,
      windowsHide: false,
      stdio: "ignore",
    }).unref();
  });
  handleTrusted(
    "history:load",
    async () =>
      (
        await readMigrated<{ entries: unknown[] }>("history.json", {
          entries: [],
        })
      ).entries,
  );
  const executionGuard = new LogicalOperationGuard(
    nodeExecutionFingerprint,
    execute,
  );
  handleTrusted("project:execute", (_event, value) => {
    const request = validateExecutionRequest(value);
    if (request.webAttachments !== undefined)
      throw new Error("Web attachments are invalid in the Electron host");
    return executionGuard.run(request);
  });
  handleTrusted("providers:check", () => checkProviders());
  handleTrusted("orchestration:preflight", (_event, request) =>
    preflightOrchestration(orchestrationOptions(request)),
  );
  handleTrusted("orchestration:start", async (_event, request) => {
    const options = orchestrationOptions(request);
    await requireFreshProvidersForConfig(options.configPath);
    return orchestration.start(options);
  });
  handleTrusted("orchestration:snapshot", () => orchestration.snapshot());
  handleTrusted(
    "orchestration:decide",
    (_event, decision: OrchestrationDecision) => {
      if (
        ![
          "approve",
          "reject",
          "changes-requested",
          "pause",
          "escalate",
          "terminate",
        ].includes(decision)
      )
        throw new Error("Invalid orchestration decision");
      return orchestration.decide(decision);
    },
  );
  handleTrusted("orchestration:cancel", () => orchestration.cancel());
  if (smokeRoot) {
    createWindow({
      show: false,
      onDidFinishLoad: (win) => void runExecuteSmoke(win, smokeRoot),
    });
  } else {
    createWindow();
    app.on("activate", () => {
      if (!BrowserWindow.getAllWindows().length) createWindow();
    });
  }
});
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
