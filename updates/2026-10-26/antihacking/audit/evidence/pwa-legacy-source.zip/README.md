# accreatio

## Security and web-only delivery — 2026-10-22

The accepted pearl/charcoal/red identity and archived former design remain in place. Current hardening restricts untrusted attachments to inspected/reconstructed DOCX, PDF, PNG and JPEG, bounds public Blog URL parsing, rejects noncanonical production API hosts before D1, and adds early request-envelope limits. [Cloudflare edge protection](docs/EDGE_SECURITY_2026-10-22.md) records the active free bot and burst controls. The desktop prototype is obsolete, was never released and will never be released; active dependencies and delivery commands are web-only.

See [attachment security](docs/ATTACHMENT_SECURITY_2026-10-22.md), [the lifecycle decision](docs/WEB_ONLY_DELIVERY_2026-10-22.md), and [today's public review update](https://edlopezpm-ops.github.io/checkaccreatioandgivefeedback/update-2026-10-22.html). The dated October 21 release records below are historical evidence. Source, test, hosted and independent-audit results remain separately identified in the final delivery receipt.

accreatio prepares the brief for a software project: its idea, constraints, supporting material and instructions to continue with a coding assistant. The free web beta processes project content in the browser and exports an inspectable ZIP. Sign-in and allowance use a separate account service; project preparation does not require repository access, an IDE or an AI provider. accreatio is web-only. The desktop prototype is obsolete, was never released, and will never be released under the owner's 2026-10-22 instruction. Electron source and historical artifacts remain for custody; see [web-only delivery](docs/WEB_ONLY_DELIVERY_2026-10-22.md).

The [official web identity](docs/ACCREATIO_BRANDING.md) is the logo supplied and selected by Ed on 2026-10-22. Its original image and checksum are preserved in the repository. The current palette is matte Iceland pearl `#E8EAE7`, charcoal `#303235` and intense red `#E2232A`; the [design record](docs/DESIGN_ICELAND_PEARL_2026-10-22.md) explains theme behavior and links the preserved prior design.

The [initial design deployment receipt](docs/DESIGN_RELEASE_2026-10-22.md) preserves the first pearl release. The [visual polish receipt](docs/VISUAL_POLISH_RELEASE_2026-10-22.md) records the subsequent nebula, alignment, dark-logo and browser identity delivery.

The browser draft belongs to the verified account and session. Signing out clears the current site draft, selected-file references and prepared ZIP; a later sign-in starts blank. Restoration requires verified matching ownership. A bounded, one-use OAuth handoff can preserve a saved draft through same-owner reauthentication; it does not restore a draft cleared by sign out. Previously downloaded files, introduction completion, cookie preferences and account allowance are independent.

The web application also has a public Blog with administrator-only publishing. Published editorial posts persist in Cloudflare D1 through same-origin Pages Functions. Account email, revocable sessions and export receipts use a separate D1 account store. Project content, attachments and local drafts stay on the device; accreatio does not retain GitHub, IDE, or AI-provider credentials.

## Final product delivery 0.9.1 — 2026-10-21

Version **0.9.1**, application source
`a16c53dba5c29c5da15ff31e9f41d5a7610ad7d1`, is deployed to
[accreatio.com](https://accreatio.com/). The current authority is the owner's
instruction to deliver the final product through AI, without an additional
human release or UAT gate. The
[final product delivery receipt](docs/FINAL_PRODUCT_RELEASE_2026-10-21.md)
records the exact deployment, readback, changes and evidence scopes.

Full `verify` passed **387/387 tests**, builds and functional smokes. Lighthouse
measured **97/100/100/69** for performance/accessibility/best practices/SEO.
The combined custom UI run recorded twelve PASS cases followed by a WebKit
timeout; directed reproduction against the same asset passed. The cause of
that timeout has not been demonstrated. Those results remain distinct from
personal Google/GitHub OAuth, authenticated production controls/export under a
personal provider session and physical iPhone Safari, which are not claimed.
These are evidence limits, not additional conditions for this delivery.

The release binds browser drafts to verified account/session ownership,
invalidates stale writes and late ZIP results, handles logout/account changes
and multiple tabs, and preserves the independent account allowance. It adds
the purple Advanced options treatment and contextual input/schema,
YAML/Markdown, path and IPC controls. Text limits are 20,000 UTF-16 units for
idea/context, 10,000 for constraints and 5,000 per participant task; some emoji
count as two units. The beta label and the existing security, privacy and
licensing boundaries remain in force.

### Historical deployment checkpoint 0.9.0

The following dated record preserves the previous 0.9.0 result and its
R01–R12 criteria. Its “incomplete”, pending acceptance and gate language is
historical; it does not govern the final 0.9.1 delivery above.

<details>
<summary>Read the preserved 0.9.0 deployment checkpoint</summary>

Code `97f0b485c14374ebb9711015b8f2914578f83cb9` is deployed to
[accreatio.com](https://accreatio.com/), deployment
`434eef0b-6693-46c1-a789-d356d4b37e25`, created at
`2026-10-21T16:07:38Z` and successful at `2026-10-21T16:07:42Z`, under Ed's
authorization to deploy on `.com`. Readback at `2026-10-21T16:08:09Z` passed:
the served JavaScript and basic sample bytes/SHA-256 match the local artifacts.
The previous `3027a9b5`/`0dec26d` deployment remains historical evidence in the runbook.
Global status remains **0 — NO COMPLETADO — EN CURSO O BLOQUEADO**: the last
demonstrated milestone is production deployment plus anonymous public smoke,
not completion of real OAuth or authenticated production export.

The [R01–R12 readiness matrix](docs/READINESS_2026-10-21.md) owns current acceptance status, and the [release runbook](docs/READINESS_RELEASE_2026-10-21.md) records configuration, migrations, deployment and bounded verification. The latest production readback passed for public routes, legal versions, capabilities and sample bytes, with existing D1 migration `0006` unchanged. The earlier in-app browser observation showed Google/GitHub buttons and the welcome example, with a service-worker reload preserving the draft; the latest button layout has the local diagnostics below. Actual provider sign-in, linked-account controls, authenticated UI export and physical iPhone Safari remain unexecuted. The [2026-10-20 readiness](docs/APP_READINESS_2026-10-20.md), [initial production setup](docs/PRODUCTION_SETUP_2026-10-20.md) and [repository/archive baseline](docs/REVIVAL_BASELINE_2026-10-20.md) retain their historical evidence.

Ed authorized the GitHub configuration and approved the policy texts and versions. Separate GitHub Apps are registered for controlled preview (`accreatio-preview-identity`, App ID `5412791`, private owner-only) and production (`accreatio-web-identity`, App ID `5412799`, public). Each has only read-only email permission, exact callbacks, no webhook and no callback wildcards. All four GitHub runtime bindings are loaded in each environment, with `ACCOUNT_GITHUB_ENABLED=true` in both. Production capability readback reports Google and GitHub available, OTP disabled and `Cache-Control: no-store`. No client secret or other credential value belongs in Git or evidence logs.

The preview account backup passed an isolated SQLite restore. The separate D1 `accreatio-accounts-readiness-preview` received its encrypted snapshot and migrations `0005`/`0006`, preserving all original rows/columns with no policy backfill. The old preview D1 remains intact; preview maintenance points to the isolated store. The controlled preview deployment remains behind Cloudflare Access and its owner-dependent verification is BLOCKED; Access was not removed when Ed redirected delivery to `.com`.

Production received additive migration `0006` on its existing D1. Protected before/after backups compared in isolated SQLite preserve every original column/row: two accounts, two identities, one policy receipt, one export receipt and zero sessions/transactions. No production database fork, destructive reset or personal-data decryption was performed; existing compatible production maintenance was unchanged. Real OAuth checks and production authenticated export remain pending because personal consent was not assumed. Subscription billing remains outside this increment.

Full local `verify` for source `97f0b485` completed with exit 0: 355 tests, builds and functional smokes passed. Lighthouse measured performance 96, accessibility 100, best practices 100 and SEO 69 under the existing private-beta noindex gate. The external AEKR source check was skipped because its checkout was unavailable; vendored payloads, license and actual ZIP checks passed. The canonical receipt is `.local/logs/2026-10-21T16-04-47-541Z-verify-5b7242e8-d5b5-4111-aa44-1717ed014ec4.log`. These results do not establish hosted OAuth success or production acceptance.

The approved notices `2026-10-21-privacy` and `2026-10-21-beta` are deployed and publicly confirmed, with purpose `account-core-v1` unchanged. Markdown, public legal HTML, cookie inventory and receipt constants are aligned without historical acceptance backfill. Optional analytics and advertising remain off, with independent cookie preferences and existing retention limits. Approval and deployment do not imply formal legal review. The [privacy and tracking baseline](docs/PRIVACY_TRACKING_BASELINE_2026-10-20.md) remains historical context.

### Sign-in button adjustment — deployed

Source `97f0b485c14374ebb9711015b8f2914578f83cb9` includes CSS/layout commit `357d297`. Google and GitHub now have equal-width desktop buttons, 44px height and 12px spacing; mobile stacks them at full available width. Provider details and navigation are separated from the buttons. Six local ES/EN viewport cases at 1280/390/320px passed, preserving Google's logo/font/padding and adding no GitHub icon. Production serves the verified artifact `index-BO-vhWup.js`, 488442 bytes, SHA-256 `7fd03978c22af76fe65b3ad9020e82292899794019113f571160876e8e0e5470`, identical to the local build. Full verify and production artifact readback passed; real provider authorization remains outside those checks.

The example checker can reproduce the manifest's recorded source revision after later commits. Regeneration at `357d297` changes only the exported `.accreatio/project.json` sourceRevision; handoff text, instructions and attachments remain byte-identical. The basic sample is now 19635 bytes, SHA-256 `bbf72008cecfdf648718ba85c86f1e234e14877f2c5c2d33b56f21b2d9225b57`, with provenance in `public/examples/manifest.json`; production readback matched these local bytes.

</details>

## Run the web app

```powershell
npm.cmd install
npm.cmd run dev:web
```

For the production web build, run `npm.cmd run build` (or `npm.cmd run build:web`) and `npm.cmd run preview`. `dev`, `start`, `build`, `typecheck` and `verify` target the web delivery. `dev:desktop`, `build:desktop`, `test:electron` and `package:win` fail closed with the retirement reason. The [historical desktop notes](docs/SOP_DESKTOP.md) preserve the unreleased prototype record.

## Web application and delivery status

The web app supports GitHub identity alongside Google, explicit provider linking, shared account/allowance, encrypted email storage, own-data export/deletion and scheduled retention controls. Provider tokens are discarded after backend processing; neither provider receives project content from accreatio. Sensitive account actions require a new OAuth check of a connected identity, bound to the action and valid for five minutes; that check does not establish that a password or MFA was entered again. The [identity runbook](docs/GITHUB_IDENTITY_ACTIVATION.md) records configuration and evidence scope; the [R01–R12 matrix](docs/READINESS_2026-10-21.md) preserves the historical 0.9.0 checkpoint. The [final delivery receipt](docs/FINAL_PRODUCT_RELEASE_2026-10-21.md) states the current result. Cloudflare Access remains separate for administration and historical previews. The [own OTP delivery record](docs/OWN_EMAIL_OTP_2026-09-05.md) is historical evidence for the optional email method.

Zero direct service cost remains mandatory. Google and GitHub are enabled in production; configuration and visible buttons do not prove completion of a real provider authorization. Email OTP depends on its independent delivery capability and remains disabled in production. Provider sign-in does not depend on that mail transport. The configurable 1,000-account admission limit is independent of provider capacity; see [privacy operations](docs/ACCOUNT_PRIVACY_OPERATIONS.md) for the existing operating boundaries.

The v14 frontend and its [protected review preview](https://design-v14-preview.accreatio.pages.dev) are historical evidence: boxed agent/export choices and centered FAQ/ToS are described in [Design v14 results](docs/design-v14/RESULT.md). The 0.9.0 interface change preserved the accepted night-only visual identity while replacing repeated export choices, improving recovery and exposing a public generated sample. The [original AEKR footer restoration](docs/design-v12/FOOTER_RESTORATION.md) remains the artwork reference; inactive pending social icons are hidden. Earlier previews retain their original URLs.

The [archived account preview](https://archive-email-auth-preview.accreatio.pages.dev) and [previous Access account release](docs/ACCOUNT_RELEASE_2026-09-05.md) retain earlier account/allowance evidence. Current service limits remain five new export authorizations per rolling 24 hours and same-operation retry within 48 hours while the ZIP remains in the tab. About, the sample and published Blog posts are public; publishing requires separate administrator authorization. Logs and caches follow [the shared local-artifact standard](docs/LOCAL_ARTIFACTS.md).

The earlier protected production beta at [accreatio.pages.dev](https://accreatio.pages.dev) uses Cloudflare Access. Release `0.8.0` was deployed from exact commit `8735952c01560218d9dc5d95d5f298329f18d6e5` after full Windows CI and a fresh Claude AEKR code/documentation audit. Its separate production and preview Blog databases received the reviewed migration and three founding posts. Those historical release facts are recorded in [W1 Release Readiness](docs/W1_RELEASE_READINESS.md); they do not establish acceptance of the own OTP implementation or a broad public release.

The founding Blog edition contains **Introducing accreatio**, **Nebula made ideas for accreatio**, and **A small paradox, but a paradox after all.** AI-assisted contributions remain clearly identified alongside Ed Lopez's writing; technology providers are not corporate authors, sponsors, or endorsers of the posts.

AI tools remain optional. Mode 1 starts disabled and uses Codex as its default when configured; Claude Code remains available. Repository and exported-project settings disable automatic Claude Code commit and pull-request attribution without changing permissions or invoking a provider.

## Capabilities

- Public view/article URLs preserve English or Spanish with `lang=en` or `lang=es`; web appearance is night-only.
- Supporting files: `.docx`, `.pdf`, `.png`, `.jpg`, `.jpeg`; maximum 20 files, 20 MiB each, 100 MiB total per operation. Browser-local parsers reject active/unsupported content; images and documents are reconstructed before ZIP inclusion. See [attachment security](docs/ATTACHMENT_SECURITY_2026-10-22.md) for the strict compatibility and resource limits. Generated project Markdown/JSON/YAML are separate product outputs.
- One to four mutually exclusive planned agent roles recorded in `AGENTS.md`.
- A browser-generated starter ZIP with project context, phase, decisions, supporting files and a canonical starting instruction; basic preparation does not impose an orchestrator or runtime.
- Account/session-bound local draft journal plus IndexedDB, with verified restoration, position and answers; only attachment counts persist, so files must be selected again after reload. Sign out clears the site draft and prepared ZIP; the next sign-in starts blank.
- Editable review, optional check without downloading, one ZIP export action and a continuation screen with the shared starting instruction and exact same-operation retry.
- Web-only Blog reading plus an append-only publisher for the verified owner and separately allowlisted AEKR service identities.
- A guided project questionnaire with one main question at a time, reversible navigation and an editable final review.
- A local two-canvas visual atmosphere: a faster autonomous procedural WebGL nebula with left-click smoke bursts, a deterministic three-depth star field, constrained-device fallbacks, and no remote visual service.
- Retained Electron source records the obsolete, unreleased prototype's filesystem/Git/GitHub/IDE operations. Those operations are not web capabilities or a release candidate.

## Security boundaries

The web prepares project files in the browser; its separate account service handles sign-in, revocable sessions, policy receipts and allowance. Project content is not sent to that service. The retained prototype's privileged IPC/filesystem/Git implementation is historical source, outside the web runtime. User-authored text is never passed to a shell command.

Published Blog reads are public. Administration verifies the Cloudflare Access JWT signature, issuer, audience, lifetime and actor claim shape before applying its separate allowlist. Publishing is authorized server-side; hiding the composer is not treated as access control. Sensitive administrator identity values resolve to safe audit labels and are neither stored with posts nor intentionally logged.

Google/GitHub flows use server-held transaction state and PKCE; matching email alone does not link accounts. Normal sessions use hashed revocable tokens and Secure/HttpOnly/SameSite=Strict cookies. If the separate OTP capability is enabled, it uses bounded validity/attempts, atomic consumption and keyed verifiers instead of plaintext codes. IP-derived HMAC keys support authentication abuse prevention, with cleanup eligibility after 48 hours; they are not product analytics. See [Privacy Policy](docs/PRIVACY_POLICY.md) for account and OTP retention.

accreatio reduces exposure through least privilege, local project processing, no embedded credentials, and no project telemetry or cloud sync. Web publication checks exclude internal source/configuration and unreviewed archives. Legacy renderer and packaging metadata are preserved for custody; no desktop package is built or released. See [SECURITY.md](docs/SECURITY.md).

## Documentation

- [Final product delivery 0.9.1](docs/FINAL_PRODUCT_RELEASE_2026-10-21.md) — current deployed result, verification and evidence limits; delivery by AI under the owner's instruction.
- [Historical R01–R12 matrix](docs/READINESS_2026-10-21.md) and [0.9.0 release runbook](docs/READINESS_RELEASE_2026-10-21.md) — preserved checkpoints; the [GitHub identity runbook](docs/GITHUB_IDENTITY_ACTIVATION.md) records provider configuration and evidence scope.
- [Historical archive](docs/archive/README.md) ? superseded designs, audits and handoffs.
- [Local logs and caches](docs/LOCAL_ARTIFACTS.md) ? diagnostic paths, archive locations and AI access.

- [Design v14](docs/design-v14/DESIGN.md) — boxed agent/export controls and centered FAQ/ToS.
- [Export enforcement research](docs/AUTH_ENFORCEMENT_OPTIONS.md) — historical alternatives; local ZIP with service authorization is selected.
- [Design v13](docs/design-v13/DESIGN.md) — confirmation-time export choice and persistent contextual FAQ/ToS.
- [Email access and rolling allowance](docs/AUTH_ROADMAP.md) — accepted implementation, data boundaries and preview rollout.
- [Account implementation](docs/AUTH_ROADMAP.md) — Google OIDC, protected emails, self-service data controls, acceptance and compatible rollback.
- [Own email OTP delivery](docs/OWN_EMAIL_OTP_2026-09-05.md) — historical transport limits, verification and rollback.
- [Blog roadmap](docs/BLOG_ROADMAP.md) — current publishing capability, authenticated acceptance, editorial recovery and proposed revision workflow after v12.
- [Design v12](docs/design-v12/DESIGN.md) — night-only web polish, Blog wordmark typography, social footer, 50-character names, four unique roles and direct ZIP handoff.
- [Design v11](docs/design-v11/DESIGN.md) — guided creation, click-responsive nebula, recovered v10 baseline, verification scope and legacy rollback policy. User acceptance remains separate from engineering verification.
- [Web-only delivery](docs/WEB_ONLY_DELIVERY_2026-10-22.md) — current product scope, retired commands and historical custody.
- [Historical desktop notes](docs/SOP_DESKTOP.md) — preserved operating notes for the obsolete, never-released Electron prototype.
- [SOP — Web edition](docs/SOP_WEB.md) — step-by-step user guide for the browser/PWA edition.
- [Troubleshooting Whitepaper](docs/TROUBLESHOOTING_WHITEPAPER.md) — internal diagnostics, including historical desktop material.
- [FAQ](docs/FAQ.md), [Privacy Policy](docs/PRIVACY_POLICY.md), [Terms of Service](docs/TERMS_OF_SERVICE.md) — product guide and owner-approved deployed notices, versioned 2026-10-21; formal legal review remains separate.
- [Web Strategy](docs/WEB_STRATEGY.md), [Web Architecture](docs/WEB_ARCHITECTURE.md), [SaaS Architecture Sketch](docs/SAAS_ARCHITECTURE_SKETCH.md) — the W0–W3 web/orchestration roadmap and its current status.
- [Protected Web Portal Release Readiness](docs/W1_RELEASE_READINESS.md) — fail-closed Access, D1/Functions, exact-commit deployment, acceptance, and rollback runbook.
- [Interactive Project Map](accreatio-project-map.html) — self-contained architecture viewer with selectable end-to-end flows; open it directly with `file://`.
- [Project Map contract](PROJECT_MAP.md) and [canonical JSON](project-map.json) — map semantics and the `{nodes, edges, flows: [{steps}]}` source for agents and tooling.
- [Design v8 specification](docs/design-v8/DESIGN.md), [design gate](docs/design-v8/DESIGN_AUDIT.md), and [fresh Claude audit](docs/design-v8/CLAUDE_AUDIT_REPORT.md) — historical web editorial architecture, Access authorization, D1 persistence, hard Electron boundary, and the exact-candidate `PASS_WITH_OBSERVATIONS` verdict with no Blocker/Major/Minor findings.

- [Super prompt](docs/prompts/ACCREATIO_SUPER_PROMPT_v1.0.0.md) — copyable Spanish context prompt covering the product, architecture, governance, current state, and Project Map contract.

## License

Private-use, no-cost software. See [LICENSE](LICENSE). Dependencies retain their own open-source licenses.

---

Built with the **AI Engineering Knowledge Repo (AEKR)** workflow: governed discovery → explicit decisions and risks → local-first implementation → evidence → independent audit.

![Build with AEKR](assets/aekr-banner.png)
