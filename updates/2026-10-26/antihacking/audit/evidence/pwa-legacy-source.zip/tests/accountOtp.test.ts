import assert from "node:assert/strict";
import test from "node:test";
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import { harness, POLICY_AUTHORIZATION } from "./helpers/accountHarness";

async function requestCode(
  h: Awaited<ReturnType<typeof harness>>,
  email = "person@example.test",
) {
  const response = await h.call("otp/request", {
    body: { policyAuthorization: POLICY_AUTHORIZATION, email },
  });
  assert.equal(response.status, 200);
  const body = await response.json();
  return { ...body, code: h.mailbox.at(-1)!.code };
}

test("own OTP is six digits, HMAC protected, email normalized and session cookie independent of Access", async () => {
  const h = await harness();
  const challenge = await requestCode(h, " Person@Example.Test ");
  assert.match(challenge.code, /^\d{6}$/);
  assert.equal(challenge.expiresAt, new Date(h.db.now + 600_000).toISOString());
  assert.equal(challenge.resendAt, new Date(h.db.now + 60_000).toISOString());
  const stored = h.db.sqlite
    .prepare("SELECT * FROM account_otp_challenges")
    .get()!;
  assert.equal(stored.email, "person@example.test");
  assert.match(stored.verifier as string, /^[a-f0-9]{64}$/);
  assert.notEqual(stored.verifier, challenge.code);
  assert.equal(Object.values(stored).includes(challenge.code), false);
  const verified = await h.call("otp/verify", {
    body: { challengeId: challenge.challengeId, code: challenge.code },
    token: "forged",
  });
  assert.equal(verified.status, 200);
  const cookie = verified.headers.get("Set-Cookie")!;
  assert.match(
    cookie,
    /^__Host-accreatio_session=[a-f0-9]{64}; Path=\/; Secure; HttpOnly; SameSite=Strict; Max-Age=86400$/,
  );
  const account = await verified.json();
  assert.equal(account.email, "person@example.test");
  assert.equal(account.remaining, 5);
  assert.equal(
    (await h.call("session", { method: "GET", cookie })).status,
    200,
  );
  const consumed = h.db.sqlite
    .prepare("SELECT email, verifier FROM account_otp_challenges")
    .get()!;
  assert.equal(consumed.email, null);
  assert.equal(consumed.verifier, null);
});

test("local owner and session markers are purpose-separated, stable and never authenticate requests", async () => {
  const h = await harness();
  const challenge = await requestCode(h);
  const verified = await h.call("otp/verify", {
    body: { challengeId: challenge.challengeId, code: challenge.code },
  });
  assert.equal(verified.status, 200);
  const cookie = verified.headers.get("Set-Cookie")!.split(";")[0];
  const account = await verified.json();
  const token = cookie.split("=")[1];
  const tokenHash = Buffer.from(
    await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token)),
  ).toString("hex");
  const accountId = h.db.sqlite
    .prepare("SELECT account_id FROM account_sessions WHERE token_hash=?")
    .get(tokenHash)!.account_id as string;
  const identityKey = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(h.env.ACCOUNT_IDENTITY_KEY),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const marker = async (domain: string, value: string) =>
    `v1:${Buffer.from(
      await crypto.subtle.sign(
        "HMAC",
        identityKey,
        new TextEncoder().encode(JSON.stringify([domain, value])),
      ),
    ).toString("hex")}`;
  assert.equal(
    account.ownerKey,
    await marker("accreatio.local-owner.v1", accountId),
  );
  assert.equal(
    account.sessionKey,
    await marker("accreatio.local-session.v1", tokenHash),
  );
  assert.notEqual(account.ownerKey, account.sessionKey);
  const session = await (
    await h.call("session", { method: "GET", cookie })
  ).json();
  const policy = await (
    await h.call("policy", { cookie, body: POLICY_AUTHORIZATION })
  ).json();
  for (const value of [session, policy]) {
    assert.equal(value.ownerKey, account.ownerKey);
    assert.equal(value.sessionKey, account.sessionKey);
  }

  const rotatedCookie = await h.login();
  const rotated = await (
    await h.call("session", { method: "GET", cookie: rotatedCookie })
  ).json();
  assert.equal(rotated.ownerKey, account.ownerKey);
  assert.notEqual(rotated.sessionKey, account.sessionKey);
  const otherCookie = await h.login({ email: "other@example.test" });
  const other = await (
    await h.call("session", { method: "GET", cookie: otherCookie })
  ).json();
  assert.notEqual(other.ownerKey, account.ownerKey);
  assert.notEqual(other.sessionKey, account.sessionKey);

  for (const key of [account.ownerKey, account.sessionKey]) {
    const denied = await h.call("session", {
      method: "GET",
      cookie: `__Host-accreatio_session=${key}`,
    });
    assert.equal(denied.status, 401);
    const body = await denied.json();
    assert.equal(body.ownerKey, undefined);
    assert.equal(body.sessionKey, undefined);
  }
});

test("incorrect and expired OTP fail uniformly; attempt five may succeed; used code cannot be reused", async () => {
  const h = await harness();
  const challenge = await requestCode(h);
  const wrong = challenge.code === "000000" ? "999999" : "000000";
  for (let i = 0; i < 4; i++) {
    const response = await h.call("otp/verify", {
      body: { challengeId: challenge.challengeId, code: wrong },
    });
    assert.equal(response.status, 401);
    assert.equal((await response.json()).error.code, "otp_invalid");
  }
  const correct = { challengeId: challenge.challengeId, code: challenge.code };
  assert.equal((await h.call("otp/verify", { body: correct })).status, 200);
  assert.equal((await h.call("otp/verify", { body: correct })).status, 401);
  h.db.now += 60_000;
  const expired = await requestCode(h);
  h.db.now += 600_000;
  assert.equal(
    (
      await h.call("otp/verify", {
        body: { challengeId: expired.challengeId, code: expired.code },
      })
    ).status,
    401,
  );
});

test("five wrong concurrent attempts lock the challenge including a later correct guess", async () => {
  const h = await harness();
  const challenge = await requestCode(h);
  const wrong = challenge.code === "000000" ? "999999" : "000000";
  const responses = await Promise.all(
    Array.from({ length: 12 }, () =>
      h.call("otp/verify", {
        body: { challengeId: challenge.challengeId, code: wrong },
      }),
    ),
  );
  assert.equal(
    responses.every((r) => r.status === 401),
    true,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT attempts FROM account_otp_challenges").get()
      ?.attempts,
    5,
  );
  assert.equal(
    (
      await h.call("otp/verify", {
        body: { challengeId: challenge.challengeId, code: challenge.code },
      })
    ).status,
    401,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()?.n,
    0,
  );
});

test("simultaneous verification of one OTP produces exactly one account and one session", async () => {
  const h = await harness();
  const challenge = await requestCode(h);
  const responses = await Promise.all(
    Array.from({ length: 12 }, () =>
      h.call("otp/verify", {
        body: { challengeId: challenge.challengeId, code: challenge.code },
      }),
    ),
  );
  assert.equal(responses.filter((r) => r.status === 200).length, 1);
  assert.equal(responses.filter((r) => r.status === 401).length, 11);
  assert.equal(responses.filter((r) => r.headers.has("Set-Cookie")).length, 1);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()?.n,
    1,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()?.n,
    1,
  );
});

test("resend cooldown is atomic and a newly issued code invalidates its predecessor", async () => {
  const h = await harness();
  const challenge = await requestCode(h);
  const responses = await Promise.all(
    Array.from({ length: 8 }, () =>
      h.call("otp/request", {
        body: {
          policyAuthorization: POLICY_AUTHORIZATION,
          email: "PERSON@example.test",
        },
      }),
    ),
  );
  assert.equal(
    responses.every((r) => r.status === 429),
    true,
  );
  assert.equal(h.mailbox.length, 1);
  assert.equal(responses[0].headers.get("Retry-After"), "60");
  h.db.now += 60_000;
  const resent = await requestCode(h);
  assert.notEqual(resent.challengeId, challenge.challengeId);
  assert.equal(
    (
      await h.call("otp/verify", {
        body: { challengeId: challenge.challengeId, code: challenge.code },
      })
    ).status,
    401,
  );
  assert.equal(
    (
      await h.call("otp/verify", {
        body: { challengeId: resent.challengeId, code: resent.code },
      })
    ).status,
    200,
  );
});

test("email, IP and global rolling delivery budgets apply atomically before transport", async () => {
  const h = await harness();
  for (let i = 0; i < 5; i++) {
    await requestCode(h);
    h.db.now += 60_000;
  }
  assert.equal(
    (
      await h.call("otp/request", {
        body: {
          policyAuthorization: POLICY_AUTHORIZATION,
          email: "person@example.test",
        },
      })
    ).status,
    429,
  );
  assert.equal(h.mailbox.length, 5);
  h.db.now += 3_600_000;
  await requestCode(h);

  const ip = await harness();
  const ipResponses = await Promise.all(
    Array.from({ length: 8 }, (_, i) =>
      ip.call("otp/request", {
        body: {
          policyAuthorization: POLICY_AUTHORIZATION,
          email: `test${i}@example.test`,
        },
        env: { ...ip.env, ACCOUNT_OTP_IP_HOURLY: "2" },
      }),
    ),
  );
  assert.equal(ipResponses.filter((r) => r.status === 200).length, 2);
  assert.equal(ip.mailbox.length, 2);
  const global = await harness();
  const globalResponses = await Promise.all(
    Array.from({ length: 8 }, (_, i) =>
      global.call("otp/request", {
        body: {
          policyAuthorization: POLICY_AUTHORIZATION,
          email: `test${i}@example.test`,
        },
        ip: `192.0.2.${i + 1}`,
        env: { ...global.env, ACCOUNT_OTP_GLOBAL_DAILY: "2" },
      }),
    ),
  );
  assert.equal(globalResponses.filter((r) => r.status === 200).length, 2);
  assert.equal(global.mailbox.length, 2);
  global.db.now += 86_400_000;
  assert.equal(
    (
      await global.call("otp/request", {
        body: {
          policyAuthorization: POLICY_AUTHORIZATION,
          email: "fresh@example.test",
        },
        env: { ...global.env, ACCOUNT_OTP_GLOBAL_DAILY: "2" },
      })
    ).status,
    200,
  );
});

test("OTP challenges bind code to purpose, challenge ID and account identity", async () => {
  const h = await harness();
  const first = await requestCode(h);
  const second = await requestCode(h, "second@example.test");
  h.db.sqlite
    .prepare(
      "UPDATE account_otp_challenges SET verifier = (SELECT verifier FROM account_otp_challenges WHERE id = ?) WHERE id = ?",
    )
    .run(first.challengeId, second.challengeId);
  assert.equal(
    (
      await h.call("otp/verify", {
        body: { challengeId: second.challengeId, code: first.code },
      })
    ).status,
    401,
  );
  assert.equal(
    (
      await h.call("otp/verify", {
        body: { challengeId: crypto.randomUUID(), code: first.code },
      })
    ).status,
    401,
  );
  assert.throws(() =>
    h.db.sqlite
      .prepare("UPDATE account_otp_challenges SET purpose = 'other'")
      .run(),
  );
});

test("transport failure leaves no usable code and still consumes the delivery budget", async () => {
  const h = await harness();
  const response = await h.call("otp/request", {
    body: {
      policyAuthorization: POLICY_AUTHORIZATION,
      email: "person@example.test",
    },
    env: {
      ...h.env,
      ACCOUNT_MAILER: {
        fetch: async () =>
          Response.json({ error: "provider-detail" }, { status: 502 }),
      },
    },
  });
  assert.equal(response.status, 503);
  const body = await response.json();
  assert.equal(body.error.code, "otp_delivery_unavailable");
  assert.equal(JSON.stringify(body).includes("provider-detail"), false);
  const stored = h.db.sqlite
    .prepare(
      "SELECT email, verifier, invalidated_at FROM account_otp_challenges",
    )
    .get()!;
  assert.equal(stored.email, null);
  assert.equal(stored.verifier, null);
  assert.equal(typeof stored.invalidated_at, "number");
  assert.equal(
    (
      await h.call("otp/request", {
        body: {
          policyAuthorization: POLICY_AUTHORIZATION,
          email: "person@example.test",
        },
      })
    ).status,
    429,
  );
  assert.equal(h.mailbox.length, 0);
});

test("OTP rejects foreign origins, non-JSON, excess fields, unbounded bodies and unsafe configuration", async () => {
  const h = await harness();
  assert.equal(
    (
      await h.call("otp/request", {
        body: {
          policyAuthorization: POLICY_AUTHORIZATION,
          email: "person@example.test",
        },
        origin: "https://attacker.test",
      })
    ).status,
    403,
  );
  assert.equal(
    (
      await h.call("otp/request", {
        body: {
          policyAuthorization: POLICY_AUTHORIZATION,
          email: "person@example.test",
        },
        headers: { "Sec-Fetch-Site": "cross-site" },
      })
    ).status,
    403,
  );
  assert.equal(
    (
      await h.call("otp/request", {
        body: {
          policyAuthorization: POLICY_AUTHORIZATION,
          email: "person@example.test",
          extra: true,
        },
      })
    ).status,
    400,
  );
  for (const email of [
    "a\r\nbcc:other@example.test",
    "invalid",
    "a..b@example.test",
    "x".repeat(65) + "@example.test",
  ])
    assert.equal(
      (
        await h.call("otp/request", {
          body: { policyAuthorization: POLICY_AUTHORIZATION, email },
        })
      ).status,
      400,
    );
  assert.equal(
    (
      await h.call("otp/request", {
        body: {
          policyAuthorization: POLICY_AUTHORIZATION,
          email: "x".repeat(1000),
        },
      })
    ).status,
    413,
  );
  assert.equal(
    (
      await h.call("otp/request", {
        body: {
          policyAuthorization: POLICY_AUTHORIZATION,
          email: "person@example.test",
        },
        headers: { "Content-Type": "text/plain" },
      })
    ).status,
    415,
  );
  for (const changes of [
    { ACCOUNT_OTP_KEY: undefined },
    { ACCOUNT_OTP_KEY: h.env.ACCOUNT_IDENTITY_KEY },
    { ACCOUNT_MAILER: undefined },
    { ACCOUNT_OTP_GLOBAL_DAILY: "101" },
    { ACCOUNT_MAX_ACCOUNTS: "0" },
  ])
    assert.equal(
      (
        await h.call("otp/request", {
          body: {
            policyAuthorization: POLICY_AUTHORIZATION,
            email: "person@example.test",
          },
          env: { ...h.env, ...changes },
        })
      ).status,
      503,
    );
  assert.equal(h.mailbox.length, 0);
});

test("configurable account capacity still permits existing identity login and preserves quota", async () => {
  const h = await harness();
  const cookie = await h.login();
  const accountId = h.db.sqlite.prepare("SELECT id FROM accounts").get()?.id;
  await h.call("authorize", {
    cookie,
    body: { operationId: crypto.randomUUID() },
  });
  h.db.now += 60_000;
  const existing = await requestCode(h, " PERSON@example.test ");
  const verified = await h.call("otp/verify", {
    body: { challengeId: existing.challengeId, code: existing.code },
    env: { ...h.env, ACCOUNT_MAX_ACCOUNTS: "1" },
  });
  assert.equal(verified.status, 200);
  assert.equal((await verified.json()).remaining, 4);
  assert.equal(
    h.db.sqlite.prepare("SELECT id FROM accounts").get()?.id,
    accountId,
  );
  const fresh = await requestCode(h, "new@example.test");
  const refused = await h.call("otp/verify", {
    body: { challengeId: fresh.challengeId, code: fresh.code },
    env: { ...h.env, ACCOUNT_MAX_ACCOUNTS: "1" },
  });
  assert.equal(refused.status, 503);
  assert.equal((await refused.json()).error.code, "beta_capacity");
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()?.n,
    1,
  );
});

test("deletion clears and invalidates pending email challenges, then re-registration retains rolling quota", async () => {
  const h = await harness();
  const cookie = await h.login();
  await h.call("authorize", {
    cookie,
    body: { operationId: crypto.randomUUID() },
  });
  h.db.now += 60_000;
  const pending = await requestCode(h);
  await h.controlProof(cookie, "delete");
  assert.equal((await h.call("delete", { cookie })).status, 200);
  assert.equal(
    (
      await h.call("otp/verify", {
        body: { challengeId: pending.challengeId, code: pending.code },
      })
    ).status,
    401,
  );
  assert.equal(
    h.db.sqlite
      .prepare(
        "SELECT COUNT(*) AS n FROM account_otp_challenges WHERE email IS NOT NULL",
      )
      .get()?.n,
    0,
  );
  const fresh = await h.login();
  assert.equal(
    (await (await h.call("session", { method: "GET", cookie: fresh })).json())
      .remaining,
    4,
  );
});

test("OTP migration revokes legacy sessions while preserving accounts and export receipts", () => {
  const db = new DatabaseSync(":memory:");
  db.exec(
    readFileSync(
      new URL("../migrations-auth/0001_accounts.sql", import.meta.url),
      "utf8",
    ),
  );
  db.exec(
    "INSERT INTO accounts VALUES ('id','identity','person@example.test',0,0,NULL); INSERT INTO account_sessions VALUES ('hash','id',9999999999999); INSERT INTO export_authorizations VALUES ('id','operation',0)",
  );
  db.exec(
    readFileSync(
      new URL("../migrations-auth/0002_own_email_otp.sql", import.meta.url),
      "utf8",
    ),
  );
  assert.equal(
    db.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()?.n,
    0,
  );
  assert.equal(
    db.prepare("SELECT identity_key FROM accounts").get()?.identity_key,
    "identity",
  );
  assert.equal(
    db.prepare("SELECT COUNT(*) AS n FROM export_authorizations").get()?.n,
    1,
  );
  db.close();
});

test("a failed session write rolls the whole OTP consumption transaction back", async () => {
  const h = await harness();
  const challenge = await requestCode(h);
  h.db.sqlite.exec(
    "CREATE TRIGGER reject_session BEFORE INSERT ON account_sessions BEGIN SELECT RAISE(ABORT, 'fixture outage'); END",
  );
  const body = { challengeId: challenge.challengeId, code: challenge.code };
  assert.equal((await h.call("otp/verify", { body })).status, 503);
  assert.equal(
    h.db.sqlite.prepare("SELECT consumed_at FROM account_otp_challenges").get()
      ?.consumed_at,
    null,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()?.n,
    0,
  );
  h.db.sqlite.exec("DROP TRIGGER reject_session");
  assert.equal((await h.call("otp/verify", { body })).status, 200);
});

test("OTP reuses the precise Access-era identity HMAC and its existing quota receipts", async () => {
  const h = await harness();
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(h.env.ACCOUNT_IDENTITY_KEY),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const raw = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode("person@example.test"),
  );
  const identityKey = Buffer.from(raw).toString("hex");
  const accountId = crypto.randomUUID();
  h.db.sqlite
    .prepare(
      "INSERT INTO accounts (id, identity_key, email, created_at, last_seen_at) VALUES (?, ?, ?, ?, ?)",
    )
    .run(accountId, identityKey, "person@example.test", h.db.now, h.db.now);
  h.db.sqlite
    .prepare("INSERT INTO export_authorizations VALUES (?, ?, ?)")
    .run(accountId, crypto.randomUUID(), h.db.now);
  const cookie = await h.login({ email: " Person@Example.Test " });
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()?.n,
    1,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT id FROM accounts").get()?.id,
    accountId,
  );
  assert.equal(
    (await (await h.call("session", { method: "GET", cookie })).json())
      .remaining,
    4,
  );
});
