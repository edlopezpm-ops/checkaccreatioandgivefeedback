import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import {
  blogPostFromUrl,
  isBlogSlug,
  MAX_BLOG_SLUG_LENGTH,
} from "../shared/blogSlug";

test("Blog slug admission preserves published and trailing-hyphen slugs", () => {
  for (const slug of ["introducing-accreatio", "post-01", "a", "post-"])
    assert.equal(isBlogSlug(slug), true);
  assert.equal(isBlogSlug("a".repeat(MAX_BLOG_SLUG_LENGTH)), true);
  for (const slug of [
    null,
    {},
    "",
    "-post",
    "post--01",
    "Post",
    "p/01",
    "a".repeat(129),
  ])
    assert.equal(isBlogSlug(slug), false);
  assert.equal(
    blogPostFromUrl("https://accreatio.com/?post=post%2D01"),
    "post-01",
  );
  assert.equal(
    blogPostFromUrl("https://accreatio.com/?post=post%2D%2D01"),
    null,
  );
  assert.equal(blogPostFromUrl("https://accreatio.com/?post=%61%21"), null);
});

test("crafted Blog query and API slug fail within a bounded subprocess", () => {
  const result = spawnSync(
    process.execPath,
    [
      "--import",
      "tsx",
      "--input-type=module",
      "-e",
      'import { isBlogSlug, blogPostFromUrl } from "./shared/blogSlug.ts"; for (const length of [28, 128, 1000000]) { const input="a".repeat(length)+"!"; if(isBlogSlug(input) || blogPostFromUrl("https://accreatio.com/?post="+encodeURIComponent(input)) !== null) process.exit(1); }',
    ],
    { cwd: process.cwd(), timeout: 5000, encoding: "utf8" },
  );
  assert.equal(result.error, undefined);
  assert.equal(result.status, 0, result.stderr);
});
