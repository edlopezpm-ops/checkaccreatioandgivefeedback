import assert from "node:assert/strict";
import test from "node:test";
import { buildLocalDataExport } from "../src/localDataExport";
import {
  defaultOrchestration,
  type ProjectDefinition,
  type Settings,
} from "../src/types";
const project: ProjectDefinition = {
  name: "=SUM(1,1)",
  phase: "idea",
  context: "unfinished local draft",
  restrictions: "",
  route: "local",
  action: "repository",
  destination: "browser-download",
  participants: [],
  attachments: [],
  initializeGit: false,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: true,
  orchestration: defaultOrchestration(),
};
const settings = { locale: "en", theme: "light" } as Settings;
test("personal local download preserves incomplete user data as JSON, uses fixed paths, reports unavailable attachments", () => {
  const files = buildLocalDataExport(
    project,
    settings,
    [],
    2,
    "2026-10-22T00:00:00Z",
  );
  assert.deepEqual(
    files.map((v) => v.path),
    [
      "accreatio-local-data/preferences.json",
      "accreatio-local-data/project.json",
      "accreatio-local-data/manifest.json",
    ],
  );
  const data = JSON.parse(String(files[1].input));
  assert.equal(data.name, "=SUM(1,1)");
  const manifest = JSON.parse(String(files.at(-1)!.input));
  assert.equal(manifest.missingAttachmentCount, 2);
  assert.match(manifest.limitations.join(" "), /memory-only|closed tab/);
  assert.ok(
    files.every((v) => !v.path.endsWith(".csv")),
    "JSON retains fidelity without executing spreadsheet formula cells",
  );
});
test("unverified local context excludes any project or attachment instead of reading another owner journal", () => {
  const files = buildLocalDataExport(null, settings, [], 0);
  assert.equal(
    files.some((v) => v.path.endsWith("project.json")),
    false,
  );
  assert.match(
    String(files.at(-1)?.input),
    /No currently verified local project context/,
  );
});
