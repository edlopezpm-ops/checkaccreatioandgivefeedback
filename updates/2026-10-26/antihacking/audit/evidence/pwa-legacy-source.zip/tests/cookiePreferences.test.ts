import assert from "node:assert/strict";
import test from "node:test";
import {
  COOKIE_PREFERENCE_KEY,
  COOKIE_PREFERENCE_MAX_AGE,
  readCookiePreference,
  rejectOptionalCookies,
  type PreferenceStorage,
} from "../src/account/cookiePreferences";

function store(): PreferenceStorage & { values: Map<string, string> } {
  const values = new Map<string, string>();
  return {
    values,
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => void values.set(key, value),
    removeItem: (key) => void values.delete(key),
  };
}

test("no cookie preference is written before an explicit rejection", () => {
  const storage = store();
  assert.equal(readCookiePreference(storage, 1000), null);
  assert.equal(storage.values.size, 0);
});

test("rejection persists only the necessary-only preference without an identifier", () => {
  const storage = store();
  const result = rejectOptionalCookies(storage, 1000);
  assert.equal(result.persisted, true);
  assert.deepEqual(result.preference, {
    schemaVersion: 1,
    necessary: true,
    analytics: false,
    advertising: false,
    recordedAt: 1000,
  });
  assert.deepEqual(readCookiePreference(storage, 1100), result.preference);
  assert.equal(storage.values.size, 1);
});

test("expiry is enforced at 180 days and removes the expired local preference", () => {
  const storage = store();
  rejectOptionalCookies(storage, 1000);
  assert.ok(readCookiePreference(storage, 999 + COOKIE_PREFERENCE_MAX_AGE));
  assert.equal(
    readCookiePreference(storage, 1000 + COOKIE_PREFERENCE_MAX_AGE),
    null,
  );
  assert.equal(storage.values.size, 0);
});

test("a forged optional grant, future record or unknown schema cannot enable collection", () => {
  const storage = store();
  for (const overrides of [
    { analytics: true },
    { advertising: true },
    { schemaVersion: 2 },
    { recordedAt: 2000 },
    { identifier: "unwanted" },
  ]) {
    storage.setItem(
      COOKIE_PREFERENCE_KEY,
      JSON.stringify({
        schemaVersion: 1,
        necessary: true,
        analytics: false,
        advertising: false,
        recordedAt: 1000,
        ...overrides,
      }),
    );
    assert.equal(readCookiePreference(storage, 1500), null);
    assert.equal(storage.values.size, 0);
  }
});

test("blocked or malformed storage never prevents necessary-only use", () => {
  const storage = store();
  storage.setItem(COOKIE_PREFERENCE_KEY, "{bad");
  assert.equal(readCookiePreference(storage, 1000), null);
  const blocked = {
    getItem: () => {
      throw new Error("blocked");
    },
    setItem: () => {
      throw new Error("blocked");
    },
    removeItem: () => {
      throw new Error("blocked");
    },
  };
  assert.equal(readCookiePreference(blocked, 1000), null);
  assert.equal(rejectOptionalCookies(blocked, 1000).persisted, false);
  assert.equal(rejectOptionalCookies(null, 1000).preference.analytics, false);
});
