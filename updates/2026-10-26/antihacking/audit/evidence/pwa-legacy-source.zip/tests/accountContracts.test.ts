import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { DEFAULT_ACCOUNT_FEATURE_CONFIG } from "../src/account/contracts";
import { createMockAccountProvider } from "../src/account/mockProvider";

test("future account capabilities default entirely off", () => {
  assert.deepEqual(DEFAULT_ACCOUNT_FEATURE_CONFIG, {
    enabled: false,
    consentUiEnabled: false,
    analyticsEnabled: false,
    advertisingEnabled: false,
  });
});

test("mock provider covers passwordless lifecycle and local data requests", () => {
  const provider = createMockAccountProvider();
  assert.equal(provider.getState().status, "logged-out");
  const issuedAt = Date.now();
  const challengeState = provider.sendChallenge(
    "person@example.test",
    "magic-link",
  );
  assert.equal(challengeState.status, "challenge-sent");
  if (challengeState.status === "challenge-sent") {
    const expiresAt = Date.parse(challengeState.challenge.expiresAt);
    assert.ok(expiresAt > issuedAt);
    assert.ok(expiresAt <= Date.now() + 10 * 60 * 1000);
  }
  assert.equal(provider.verify("000000").status, "verified");
  assert.equal(provider.openAccount().status, "account");
  const exported = provider.requestData("export");
  assert.equal(exported.status, "account");
  if (exported.status === "account")
    assert.deepEqual(
      exported.requests.map((request) => request.kind),
      ["export"],
    );
  const deleted = provider.requestData("deletion");
  if (deleted.status === "account")
    assert.deepEqual(
      deleted.requests.map((request) => request.kind),
      ["export", "deletion"],
    );
  assert.equal(provider.logout().status, "logged-out");
});

test("mock exposes invalid and expired states without external I/O", () => {
  const invalid = createMockAccountProvider();
  invalid.sendChallenge("person@example.test", "email-code");
  assert.equal(invalid.verify("wrong").status, "error");
  const expired = createMockAccountProvider();
  expired.sendChallenge("person@example.test", "email-code");
  assert.equal(expired.expireChallenge().status, "expired");
});

test("account boundary contains no network or credential primitives", () => {
  const sources = [
    "../src/account/contracts.ts",
    "../src/account/mockProvider.ts",
    "../src/account/consent.ts",
    "../src/components/account/AuthFlow.tsx",
    "../src/components/account/AccountShell.tsx",
    "../src/components/account/PrivacyControls.tsx",
  ].map((path) => readFileSync(new URL(path, import.meta.url), "utf8"));
  const implementation = sources.join("\n");
  assert.doesNotMatch(
    implementation,
    /fetch\s*\(|XMLHttpRequest|WebSocket|EventSource|sendBeacon|https?:\/\//,
  );
  assert.doesNotMatch(implementation, /type=["']password["']/);
});
