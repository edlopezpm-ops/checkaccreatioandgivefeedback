import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const styles = readFileSync(
  new URL("../src/styles.css", import.meta.url),
  "utf8",
);
const app = readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
const appFrame = readFileSync(
  new URL("../src/components/AppFrame.tsx", import.meta.url),
  "utf8",
);

const tokenNames = (block: string) =>
  [...block.matchAll(/--([\w-]+)\s*:/g)].map((match) => match[1]).sort();

const contrastRatio = (foreground: string, background: string) => {
  const luminance = (hex: string) => {
    const channels = hex
      .slice(1)
      .match(/.{2}/g)!
      .map((value) => Number.parseInt(value, 16) / 255)
      .map((value) =>
        value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4,
      );
    return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2];
  };
  const values = [luminance(foreground), luminance(background)].sort(
    (a, b) => b - a,
  );
  return (values[0] + 0.05) / (values[1] + 0.05);
};

test("dark and light themes assign the identical semantic token contract", () => {
  const root = styles.match(/:root\s*{([\s\S]*?)\n}/)?.[1];
  const light = styles.match(/\[data-theme="light"\]\s*{([\s\S]*?)\n}/)?.[1];
  assert.ok(root);
  assert.ok(light);
  assert.deepEqual(tokenNames(light), tokenNames(root));
  assert.match(root, /color-scheme:\s*dark/);
  assert.match(light, /color-scheme:\s*light/);
});

test("Iceland pearl and soft dark themes retain the neutral hierarchy and restrained red", () => {
  const expectedDark = {
    "app-background": "#242726",
    "surface-primary": "#2b2e2c",
    "surface-secondary": "#303431",
    "surface-elevated": "#353936",
    "surface-muted": "#292c2a",
    "text-primary": "#f0f1ed",
    "text-secondary": "#c5c9c5",
    "text-muted": "#b2b9b2",
    "accent-primary": "#d8ddd5",
    "accent-detail": "#e2232a",
    "accent-detail-hover": "#c81d24",
    "accent-detail-active": "#b41920",
    "text-on-detail": "#ffffff",
  };
  const expectedLight = {
    "app-background": "#e8eae7",
    "surface-primary": "#eef0eb",
    "surface-secondary": "#e1e5dd",
    "surface-elevated": "#f3f5ef",
    "surface-muted": "#e4e7df",
    "control-background-selected": "#dce2d6",
    "text-primary": "#303235",
    "text-secondary": "#515852",
    "text-muted": "#5e655e",
    "accent-primary": "#303235",
    "accent-detail": "#e2232a",
    "accent-detail-hover": "#c81d24",
    "accent-detail-active": "#b41920",
    "text-on-detail": "#ffffff",
  };
  const root = styles.match(/:root\s*{([\s\S]*?)\n}/)?.[1] ?? "";
  const light =
    styles.match(/\[data-theme="light"\]\s*{([\s\S]*?)\n}/)?.[1] ?? "";
  for (const [token, value] of Object.entries(expectedDark))
    assert.match(root, new RegExp(`--${token}:\\s*${value}`, "i"));
  for (const [token, value] of Object.entries(expectedLight))
    assert.match(light, new RegExp(`--${token}:\\s*${value}`, "i"));
});

test("final text and status pairs meet WCAG AA normal-text contrast", () => {
  const pairs = [
    ["text-primary", "app-background"],
    ["text-secondary", "surface-primary"],
    ["text-muted", "surface-primary"],
    ["text-muted", "app-background"],
    ["text-muted", "surface-secondary"],
    ["text-muted", "surface-muted"],
    ["text-muted", "control-background-selected"],
    ["control-text", "control-background"],
    ["control-placeholder", "control-background"],
    ["text-on-accent", "accent-primary"],
    ["text-on-detail", "accent-detail"],
    ["text-on-detail", "accent-detail-hover"],
    ["text-on-detail", "accent-detail-active"],
    ["success", "success-muted"],
    ["warning", "warning-muted"],
    ["danger", "danger-muted"],
    ["information", "information-muted"],
  ];
  for (const [theme, block] of [
    ["dark", styles.match(/:root\s*{([\s\S]*?)\n}/)?.[1]],
    ["light", styles.match(/\[data-theme="light"\]\s*{([\s\S]*?)\n}/)?.[1]],
  ]) {
    assert.ok(block);
    const value = (token: string) => {
      const hex = block.match(
        new RegExp(`--${token}:\\s*(#[\\da-f]{6})`, "i"),
      )?.[1];
      assert.ok(hex, `${theme} must define --${token} as a hex color`);
      return hex;
    };
    for (const [foreground, background] of pairs)
      assert.ok(
        contrastRatio(value(foreground), value(background)) >= 4.5,
        `${theme}: --${foreground} on --${background} must be at least 4.5:1`,
      );
  }
});

test("web defaults to pearl with a guarded local preference and both hosts can switch", () => {
  const preference = app.match(/const loadWebTheme[\s\S]*?\n};/)?.[0] ?? "";
  assert.match(
    preference,
    /try\s*{[\s\S]*?localStorage\.getItem\(WEB_THEME_KEY\)/,
  );
  assert.match(preference, /\? "dark"\s*:\s*"light"/);
  assert.match(preference, /catch\s*{\s*return "light"/);
  assert.doesNotMatch(preference, /matchMedia|prefers-color-scheme/);
  assert.match(app, /const WEB_THEME_KEY = "accreatio:theme"/);
  assert.match(app, /theme: loadWebTheme\(\)/);
  const toggle =
    app.match(/const toggleTheme = \(\) => \{[\s\S]*?\n  };/)?.[0] ?? "";
  assert.match(
    toggle,
    /if \(isWeb\)\s*{\s*try\s*{\s*window\.localStorage\.setItem\(WEB_THEME_KEY, theme\)/,
  );
  assert.match(toggle, /setS\(\(current\) => \(\{ \.\.\.current, theme }\)\)/);
  assert.match(app, /onThemeToggle=\{toggleTheme\}/);
  assert.equal(
    [...app.matchAll(/localStorage\.setItem\(WEB_THEME_KEY,/g)].length,
    1,
  );
  assert.match(app, /const theme = s\.theme/);
  assert.match(app, /document\.documentElement\.dataset\.theme\s*=\s*theme/);
  assert.match(app, /theme=\{s\.theme\}/);
  assert.doesNotMatch(app, /hideThemeToggle=\{isWeb\}/);
  assert.match(appFrame, /Switch to light theme/);
  assert.match(appFrame, /Switch to dark theme/);
  assert.match(appFrame, /Switch to Spanish/);
  assert.match(appFrame, /Cambiar a inglés/);
});

test("navigation and genuine choice controls expose their current state", () => {
  assert.match(
    appFrame,
    /aria-current=\{\s*currentDestination === item\.id \? "page" : undefined\s*\}/,
  );
  assert.match(app, /aria-pressed=\{v === value\}/);
  assert.match(app, /aria-pressed=\{active\}/);
  assert.doesNotMatch(
    appFrame.match(/<div className="header-actions">([\s\S]*?)<\/div>/)?.[1] ??
      "",
    /aria-pressed/,
  );
});

test("Settings controls retain visible label association and controlled values", () => {
  for (const value of ["s.preferredIde", "s.locale", "s.theme"]) {
    assert.match(
      app,
      new RegExp(
        `<label>[\\s\\S]*?<select[\\s\\S]*?value=\\{${value.replace(".", "\\.")}\\}`,
      ),
    );
  }
});

test("all App buttons declare non-submit behavior and disabled controls stay native", () => {
  const buttons = [...app.matchAll(/<button\b([^>]*)>/g)];
  assert.ok(buttons.length > 0);
  for (const [, attributes] of buttons) {
    assert.match(attributes, /\btype="button"/);
  }
  const foundation = readFileSync(
    new URL("../src/components/creation/FoundationStage.tsx", import.meta.url),
    "utf8",
  );
  const team = readFileSync(
    new URL("../src/components/creation/TeamStage.tsx", import.meta.url),
    "utf8",
  );
  const review = readFileSync(
    new URL("../src/components/creation/ReviewStage.tsx", import.meta.url),
    "utf8",
  );
  assert.match(
    foundation,
    /disabled=\{\s*inspectingAttachments \|\| project\.attachments\.length >= MAX_FILES\s*\}/,
  );
  assert.match(team, /disabled=\{project\.participants\.length === 1\}/);
  assert.match(review, /disabled=\{!valid \|\| running\}/);
});

test("legacy theme variables and component color literals are absent", () => {
  const componentCss = styles
    .replace(/:root\s*{[\s\S]*?\n}/, "")
    .replace(/\[data-theme="light"\]\s*{[\s\S]*?\n}/, "");
  assert.doesNotMatch(
    componentCss,
    /var\(--(?:bg|panel|panel2|border|muted|cream|cream2|input)\)/,
  );
  assert.doesNotMatch(componentCss, /#[\da-f]{3,8}|rgba?\(/i);
  const lightBlock = styles.match(
    /\[data-theme="light"\]\s*{([\s\S]*?)\n}/,
  )?.[1];
  assert.ok(lightBlock);
  assert.doesNotMatch(lightBlock, /!important/);
});
