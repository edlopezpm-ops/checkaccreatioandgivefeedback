import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  creationFocusTarget,
  focusCreationTarget,
} from "../src/components/creation/TeamStage";

const read = (path: string) =>
  readFileSync(new URL(`../${path}`, import.meta.url), "utf8");

const app = read("src/App.tsx");
const navigation = read("src/components/creation/StageNavigation.tsx");
const foundation = read("src/components/creation/FoundationStage.tsx");
const context = read("src/components/creation/ContextStage.tsx");
const team = read("src/components/creation/TeamStage.tsx");
const delivery = read("src/components/creation/DeliveryStage.tsx");
const styles = `${read("src/styles.css")}\n${read("src/responsive.css")}`;

test("creation navigation exposes five reversible stages with textual states", () => {
  for (const stage of ["foundation", "context", "team", "delivery", "review"])
    assert.match(navigation, new RegExp(`"${stage}"`));
  for (const state of ["Current", "Complete", "Needs attention", "Not started"])
    assert.match(navigation, new RegExp(state));
  assert.match(
    navigation,
    /aria-current=\{stage === current \? "step" : undefined\}/,
  );
  assert.match(navigation, /onClick=\{\(\) => onSelect\(stage\)\}/);
  assert.match(navigation, /<select/);
});

test("question exit validates and focuses the first invalid Foundation or Context field", () => {
  assert.match(app, /canMoveToQuestion\(creationQuestion, next, errors\)/);
  assert.equal(
    creationFocusTarget("foundation", { attachments: "invalid" }),
    "project-attachments",
  );
  assert.match(app, /focusCreationTarget\(firstInvalidId\)/);
  assert.match(foundation, /id="project-name"/);
  assert.match(context, /id="project-context"/);
  assert.match(foundation, /aria-invalid=\{Boolean\(errors\.name\)\}/);
  assert.match(context, /aria-invalid=\{Boolean\(errors\.context\)\}/);
  assert.equal(foundation.match(/id="project-attachments"/g)?.length, 1);
  assert.match(
    foundation,
    /id="project-attachments"\s+className=\{`attachment-workspace/,
  );
});

test("every Team and Delivery validation path resolves to a focusable visible target", () => {
  let focused = "";
  const root = {
    getElementById: (id: string) => ({ focus: () => (focused = id) }),
  };

  for (const [error, expectedTarget] of [
    ["participants", "project-participants"],
    ["orchestration", "project-mode1-configuration"],
    ["funding", "project-mode1-configuration"],
  ] as const) {
    const target = creationFocusTarget("team", { [error]: "invalid" });
    focusCreationTarget(target, root);
    assert.equal(target, expectedTarget, `Team ${error} target`);
    assert.equal(focused, expectedTarget, `Team ${error} error moves focus`);
  }
  for (const error of ["destination", "tracking", "openIde", "createRemote"]) {
    const target = creationFocusTarget("delivery", { [error]: "invalid" });
    focusCreationTarget(target, root);
    assert.equal(focused, target, `Delivery ${error} error moves focus`);
  }
  assert.match(team, /id="project-participants"[\s\S]*?tabIndex=\{-1\}/);
  assert.match(team, /id="project-mode1-configuration"[\s\S]*?type="button"/);
  assert.match(
    team,
    /aria-describedby=\{mode1Error \? "project-mode1-error" : undefined\}/,
  );
  assert.match(
    team,
    /mode1TriggerRef\.current\?\.closest\("details"\)\?\.setAttribute\("open", ""\)/,
  );
  assert.match(delivery, /id="project-tracking"[\s\S]*?tabIndex=\{-1\}/);
  assert.match(
    delivery,
    /id="project-repository-options"[\s\S]*?tabIndex=\{-1\}/,
  );
  assert.match(app, /creationFocusTarget\(creationStage, errors\)/);
});

test("Foundation and Context preserve the domain values as controlled inputs", () => {
  for (const value of ["project.name", "project.phase", "project.attachments"])
    assert.match(foundation, new RegExp(value.replace(".", "\\.")));
  for (const value of [
    "project.context",
    "project.restrictions",
    "project.route",
  ])
    assert.match(context, new RegExp(value.replace(".", "\\.")));
  assert.match(app, /onChange=\{setP\}/);
  assert.match(app, /onPhaseChange=\{changeProjectPhase\}/);
});

test("responsive stage navigation follows rail, strip, and selector breakpoints", () => {
  assert.match(
    styles,
    /grid-template-columns:\s*minmax\(0, var\(--creation-form\)\) var\(--nav-rail\)/,
  );
  assert.match(styles, /grid-template-areas:\s*"stage navigation"/);
  assert.match(
    styles,
    /@media \(max-width: 1199px\)[\s\S]*grid-template-areas:\s*"navigation" "stage"[\s\S]*\.stage-navigation ol/,
  );
  assert.match(
    styles,
    /@media \(max-width: 767px\)[\s\S]*\.stage-navigation[\s\S]*display:\s*none/,
  );
  assert.match(styles, /\.stage-selector[\s\S]*display:\s*grid/);
});

test("advanced and locality primitives communicate configured and transient state", () => {
  assert.match(foundation, /Only in this tab/);
  assert.match(foundation, /without their names or bytes/);
  assert.match(foundation, /Discovery sources · none added/);
  assert.match(context, /Constraints configured/);
  assert.match(context, /Constraints · none added/);
});
