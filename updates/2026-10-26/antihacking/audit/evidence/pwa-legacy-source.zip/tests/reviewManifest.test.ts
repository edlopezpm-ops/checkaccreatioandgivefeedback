import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import * as React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import {
  buildExecutionPreview,
  generatePrompt,
  planActions,
} from "../src/core";
import { ReviewStage } from "../src/components/creation/ReviewStage";
import {
  defaultOrchestration,
  type ProjectDefinition,
  type Settings,
} from "../src/types";

Object.assign(globalThis, { React });

const project: ProjectDefinition = {
  name: "Manifest demo",
  phase: "discovery-active",
  context: "Known context",
  restrictions: "Zero cost",
  route: "local",
  action: "repository",
  destination: "/projects",
  participants: [
    { id: "participant-01", role: "implementer", label: "Implementation" },
  ],
  attachments: [
    { path: "/source/brief.md", name: "brief.md", extension: ".md", size: 12 },
  ],
  initializeGit: true,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: true,
  orchestration: defaultOrchestration(),
};
const settings: Settings = {
  baseFolder: "/projects",
  toolkitPath: "/toolkit",
  futureProjectsPath: "/toolkit/future_projects",
  defaultBranch: "main",
  preferredIde: "VS Code",
  confirmBeforeRun: true,
  theme: "dark",
  locale: "en",
};

// The safe-run choice has to sit beside the button it modifies. It used to
// live on Delivery, one screen earlier, so the user picked the outcome before
// seeing what was at stake.
test("Review carries the dry-run choice next to the confirm action", () => {
  const html = renderToStaticMarkup(
    React.createElement(ReviewStage, {
      actions: planActions(project, settings),
      copied: false,
      locale: "en",
      onChange: () => {},
      onConfirm: () => {},
      onCopy: () => {},
      onDownload: () => {},
      onStageChange: () => {},
      preview: buildExecutionPreview(project, settings, "desktop"),
      project,
      prompt: generatePrompt(project, "en"),
      running: false,
      stageStates: {
        foundation: "complete",
        context: "complete",
        team: "complete",
        delivery: "complete",
        review: "current",
      },
      valid: true,
    }),
  );
  const confirm = html.slice(html.indexOf('class="review-stage__confirm"'));
  assert.match(confirm, /review-stage__dry-run/);
  assert.match(confirm, /Review without writing/);
  assert.match(confirm, /Review and confirm/);
  assert.match(confirm, /Preview without creating files/);
});

test("Review presents the unchanged prompt and deterministic plan in a read-only manifest", () => {
  const prompt = generatePrompt(project, "en");
  const actions = planActions(project, settings);
  const html = renderToStaticMarkup(
    React.createElement(ReviewStage, {
      actions,
      copied: false,
      locale: "en",
      onChange: () => {},
      onConfirm: () => {},
      onCopy: () => {},
      onDownload: () => {},
      onStageChange: () => {},
      preview: buildExecutionPreview(project, settings, "desktop"),
      project,
      prompt,
      running: false,
      stageStates: {
        foundation: "complete",
        context: "complete",
        team: "complete",
        delivery: "complete",
        review: "current",
      },
      valid: true,
    }),
  );
  assert.match(html, /Delivery manifest/);
  assert.match(html, /Deterministic plan/);
  assert.match(html, /Full prompt/);
  assert.match(html, /brief\.md/);
  assert.ok(
    html.includes(
      prompt
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;"),
    ),
  );
  for (const action of actions) assert.match(html, new RegExp(action.label));
  assert.match(html, /Review and confirm/);
  assert.equal((html.match(/<details\b/g) ?? []).length, 3);
  assert.doesNotMatch(html, /<details[^>]*\bopen(?:=|\s|>)/);
});

test("App confines full prompt and plan to Review and exposes contextual summary earlier", () => {
  const app = readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
  assert.match(app, /<ReviewStage/);
  assert.match(app, /creationStage !== "review"/);
  assert.match(app, /<SummaryDrawer/);
  assert.doesNotMatch(app, /className="panel preview"/);
  assert.doesNotMatch(app, /className="panel plan"/);
});

test("Review keeps files, plan and prompt in native disclosures with copy and Markdown download", () => {
  const source = readFileSync(
    new URL("../src/components/creation/ReviewStage.tsx", import.meta.url),
    "utf8",
  );
  assert.match(source, /<details[\s\S]*?id="review-manifest"/);
  assert.match(source, /<details[\s\S]*?id="review-plan"/);
  assert.match(source, /<details[\s\S]*?id="review-prompt"/);
  assert.match(source, /Files and delivery limits/);
  assert.match(source, /How your package will be prepared/);
  assert.match(source, /View the complete instructions/);
  assert.match(source, /onCopy/);
  assert.match(source, /onDownload/);
});
