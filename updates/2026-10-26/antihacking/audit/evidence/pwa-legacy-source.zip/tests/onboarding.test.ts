import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const read = (path: string) =>
  readFileSync(new URL(path, import.meta.url), "utf8");
const app = read("../src/App.tsx");
const onboarding = read("../src/components/Onboarding.tsx");
const styles = read("../src/styles.css");
const responsive = read("../src/responsive.css");

test("first-run onboarding has two outcome-led, local-first screens", () => {
  assert.match(onboarding, /What you will make/);
  assert.match(onboarding, /What stays local/);
  assert.match(onboarding, /5–10 minutes/);
  assert.match(onboarding, /local folder on desktop/);
  assert.match(onboarding, /downloadable ZIP on the web/);
  assert.doesNotMatch(
    onboarding,
    /Cloudflare handles access|creates no internal account/,
  );
  assert.match(onboarding, /desktop edition requires no account/);
  assert.match(onboarding, /syncs no projects to the cloud/);
  assert.match(onboarding, /web keeps accounts and Blog posts separate/);
  assert.match(onboarding, /Selected files remain only in the tab/);
});

test("guided completion enters creation without a skip escape hatch", () => {
  assert.doesNotMatch(onboarding, /Omitir|Skip|onboarding-skip/);
  assert.match(onboarding, /Continue/);
  assert.match(onboarding, /Finish and create/);
  assert.match(onboarding, /onClick=\{onComplete\}/);
  assert.match(app, /saveOnboardingCompletion\(\)/);
  assert.match(app, /View welcome/);
  assert.match(app, /setShowOnboarding\(true\)/);
});

test("onboarding is semantic, keyboard-native, and explains unavailable storage", () => {
  assert.match(onboarding, /<main className="onboarding" aria-labelledby=/);
  assert.match(onboarding, /role="status"/);
  assert.match(onboarding, /may appear again/);
  const buttons = [...onboarding.matchAll(/<button\b([^>]*)>/g)];
  assert.ok(buttons.length >= 3);
  for (const [, attributes] of buttons)
    assert.match(attributes, /type="button"/);
  assert.match(
    styles,
    /\.onboarding-actions button\s*{[\s\S]*?min-height:\s*var\(--touch-target\)/,
  );
});

test("mobile onboarding uses one-column facts and a safe-area action region", () => {
  assert.match(
    responsive,
    /@media \(max-width: 767px\)[\s\S]*?\.onboarding-facts\s*{[\s\S]*?grid-template-columns:\s*1fr/,
  );
  assert.match(
    responsive,
    /\.onboarding-actions\s*{[\s\S]*?env\(safe-area-inset-bottom\)/,
  );
  assert.doesNotMatch(styles, /\.onboarding\s*{[^}]*min-width/);
});
