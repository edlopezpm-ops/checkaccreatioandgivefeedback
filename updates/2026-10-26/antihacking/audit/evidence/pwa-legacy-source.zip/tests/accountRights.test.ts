import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import {
  createRightsTransaction,
  completeRightsAccess,
} from "../functions/_lib/auth/rights";
import type {
  CreateOidcTransaction,
  ValidatedIdentity,
} from "../functions/_lib/auth/oidc-contracts";
import { harness } from "./helpers/accountHarness";

async function fixture() {
  const h = await harness();
  if (
    !h.db.sqlite
      .prepare("PRAGMA table_info(account_auth_transactions)")
      .all()
      .some((column) => column.name === "rights_only")
  )
    h.db.sqlite.exec(
      readFileSync(
        new URL("../migrations-auth/0008_rights_only.sql", import.meta.url),
        "utf8",
      ),
    );
  const accountId = crypto.randomUUID();
  h.db.sqlite
    .prepare(
      "INSERT INTO accounts(id,identity_key,email,created_at,last_seen_at) VALUES(?,?,?,?,?)",
    )
    .run(
      accountId,
      `rights-${accountId}`,
      "existing@example.test",
      h.db.now,
      h.db.now,
    );
  h.db.sqlite
    .prepare(
      "INSERT INTO account_external_identities(id,account_id,issuer,subject,locator_hmac,created_at,last_authenticated_at) VALUES(?,?,?,?,?,?,?)",
    )
    .run(
      crypto.randomUUID(),
      accountId,
      "https://accounts.google.com",
      "existing-subject",
      `locator-${accountId}`,
      h.db.now,
      h.db.now,
    );
  const identity: ValidatedIdentity = {
    issuer: "https://accounts.google.com",
    subject: "existing-subject",
    email: "a-different-email@example.test",
    emailVerified: true,
    authoritativeEmail: true,
    hostedDomain: null,
    displayName: "Do not update stored profile",
  };
  const transaction = (
    overrides: Partial<CreateOidcTransaction & { rightsOnly: boolean }> = {},
  ): CreateOidcTransaction & { rightsOnly: boolean } => ({
    id: crypto.randomUUID(),
    stateHash: crypto.randomUUID(),
    browserHash: crypto.randomUUID(),
    ipHash: "rights-test-ip",
    secretsCiphertext: "v1:synthetic-encrypted-transaction",
    returnMode: "redirect",
    previousSessionTokenHash: null,
    purpose: "account_access",
    provider: "google",
    verificationAction: "data",
    rightsOnly: true,
    ...overrides,
  });
  async function claimed(
    overrides: Partial<CreateOidcTransaction & { rightsOnly: boolean }> = {},
  ) {
    const input = transaction(overrides);
    await createRightsTransaction(h.db, input);
    const claimNonce = crypto.randomUUID();
    h.db.sqlite
      .prepare(
        "UPDATE account_auth_transactions SET status='claimed',claim_nonce=? WHERE id=?",
      )
      .run(claimNonce, input.id);
    return {
      transactionId: input.id,
      claimNonce,
      identity,
      sessionTokenHash: crypto.randomUUID(),
    };
  }
  return { ...h, accountId, identity, transaction, claimed };
}

test("rights-only verification without a current session issues only a five-minute scoped proof and preserves account/policy/quota", async () => {
  const f = await fixture();
  const originalAccount = f.db.sqlite
    .prepare("SELECT * FROM accounts WHERE id=?")
    .get(f.accountId);
  const originalIdentity = f.db.sqlite
    .prepare("SELECT * FROM account_external_identities WHERE account_id=?")
    .get(f.accountId);
  f.db.sqlite
    .prepare(
      "INSERT INTO account_sessions(token_hash,account_id,expires_at) VALUES(?,?,?)",
    )
    .run("ordinary-session-fixture", f.accountId, f.db.now + 86400000);
  f.db.sqlite
    .prepare(
      "INSERT INTO account_session_metadata(token_hash,method,authenticated_at,security_version) VALUES(?,'oidc',?,0)",
    )
    .run("ordinary-session-fixture", f.db.now);
  const originalSession = f.db.sqlite
    .prepare("SELECT * FROM account_sessions WHERE token_hash=?")
    .get("ordinary-session-fixture");
  const claim = await f.claimed();
  const result = await completeRightsAccess(f.db, claim);
  assert.deepEqual(result, { expiresAt: f.db.now + 300000, rightsOnly: true });
  const meta = f.db.sqlite
    .prepare("SELECT * FROM account_session_metadata WHERE token_hash=?")
    .get(claim.sessionTokenHash)!;
  assert.equal(meta.rights_only, 1);
  assert.equal(meta.verification_action, "data");
  assert.equal(meta.security_version, 0);
  assert.deepEqual(
    f.db.sqlite.prepare("SELECT * FROM accounts WHERE id=?").get(f.accountId),
    originalAccount,
  );
  assert.deepEqual(
    f.db.sqlite
      .prepare("SELECT * FROM account_external_identities WHERE account_id=?")
      .get(f.accountId),
    originalIdentity,
  );
  assert.deepEqual(
    f.db.sqlite
      .prepare("SELECT * FROM account_sessions WHERE token_hash=?")
      .get("ordinary-session-fixture"),
    originalSession,
  );
  for (const table of [
    "account_policy_authorizations",
    "export_authorizations",
  ])
    assert.equal(
      f.db.sqlite.prepare(`SELECT COUNT(*) AS n FROM ${table}`).get()!.n,
      0,
    );
  const tx = f.db.sqlite
    .prepare("SELECT * FROM account_auth_transactions WHERE id=?")
    .get(claim.transactionId)!;
  assert.equal(tx.status, "completed");
  for (const field of [
    "secrets_ciphertext",
    "previous_session_token_hash",
    "issued_session_token_hash",
    "policy_authorized_at",
    "policy_privacy_notice_version",
    "policy_terms_version",
    "policy_purpose_version",
  ])
    assert.equal(tx[field], null);
  assert.throws(
    () =>
      f.db.sqlite
        .prepare(
          "UPDATE account_session_metadata SET rights_only=0 WHERE token_hash=?",
        )
        .run(claim.sessionTokenHash),
    /rights_session_scope_immutable/,
  );
  assert.throws(
    () =>
      f.db.sqlite
        .prepare(
          "UPDATE account_session_metadata SET verification_action='delete' WHERE token_hash=?",
        )
        .run(claim.sessionTokenHash),
    /rights_session_scope_immutable/,
  );
  await assert.rejects(
    completeRightsAccess(f.db, claim),
    /rights_verification_unavailable/,
  );
  assert.equal(
    f.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
    2,
  );
});

test("rights-only GitHub proof resolves the exact linked subject without profile or email matching", async () => {
  const f = await fixture();
  f.db.sqlite
    .prepare(
      "INSERT INTO account_external_identities(id,account_id,issuer,subject,locator_hmac,created_at,last_authenticated_at) VALUES(?,?,?,?,?,?,?)",
    )
    .run(
      crypto.randomUUID(),
      f.accountId,
      "https://github.com",
      "7654321",
      `github-${f.accountId}`,
      f.db.now,
      f.db.now,
    );
  const claim = await f.claimed({
    provider: "github",
    verificationAction: "delete",
  });
  claim.identity = {
    issuer: "https://github.com",
    subject: "7654321",
    email: null,
    emailVerified: false,
    authoritativeEmail: false,
  };
  assert.deepEqual(await completeRightsAccess(f.db, claim), {
    expiresAt: f.db.now + 300000,
    rightsOnly: true,
  });
  assert.equal(
    f.db.sqlite
      .prepare("SELECT account_id FROM account_sessions WHERE token_hash=?")
      .get(claim.sessionTokenHash)!.account_id,
    f.accountId,
  );
  assert.equal(
    f.db.sqlite
      .prepare(
        "SELECT verification_action FROM account_session_metadata WHERE token_hash=?",
      )
      .get(claim.sessionTokenHash)!.verification_action,
    "delete",
  );
  assert.equal(
    f.db.sqlite
      .prepare("SELECT email FROM accounts WHERE id=?")
      .get(f.accountId)!.email,
    "existing@example.test",
  );
});

test("rights transactions have a separate atomic IP/global admission budget and never cancel ordinary browser transactions", async () => {
  const f = await fixture();
  const browserHash = "shared-browser";
  const normalId = crypto.randomUUID();
  f.db.sqlite
    .prepare(
      "INSERT INTO account_auth_transactions(id,state_hash,browser_hash,ip_hash,secrets_ciphertext,return_mode,status,created_at,expires_at) VALUES(?,?,?,?,?,'redirect','created',?,?)",
    )
    .run(
      normalId,
      crypto.randomUUID(),
      browserHash,
      "normal-ip",
      "normal-secret-fixture",
      f.db.now,
      f.db.now + 600000,
    );
  const first = f.transaction({ browserHash });
  const created = await createRightsTransaction(f.db, first);
  assert.equal(created.expiresAt, f.db.now + 600000);
  const initial = f.db.sqlite
    .prepare("SELECT * FROM account_auth_transactions WHERE id=?")
    .get(first.id)!;
  assert.equal(initial.account_id, null);
  assert.equal(initial.access_security_version, null);
  assert.equal(initial.policy_authorized_at, null);
  const next = f.transaction({ browserHash });
  await createRightsTransaction(f.db, next);
  assert.equal(
    f.db.sqlite
      .prepare("SELECT status FROM account_auth_transactions WHERE id=?")
      .get(first.id)!.status,
    "failed",
  );
  assert.equal(
    f.db.sqlite
      .prepare("SELECT status FROM account_auth_transactions WHERE id=?")
      .get(normalId)!.status,
    "created",
  );
  const remainder = await Promise.allSettled(
    Array.from({ length: 21 }, () =>
      createRightsTransaction(f.db, f.transaction()),
    ),
  );
  assert.equal(
    remainder.filter((row) => row.status === "fulfilled").length,
    18,
  );
  assert.equal(
    f.db.sqlite
      .prepare(
        "SELECT COUNT(*) AS n FROM account_auth_transactions WHERE rights_only=1",
      )
      .get()!.n,
    20,
  );
  for (let index = 0; index < 70; index++)
    await createRightsTransaction(
      f.db,
      f.transaction({ ipHash: `ip-${index}` }),
    );
  await assert.rejects(
    createRightsTransaction(f.db, f.transaction({ ipHash: "one-more-ip" })),
    (error: unknown) => {
      assert.equal((error as { status: number }).status, 429);
      return true;
    },
  );
  assert.equal(
    f.db.sqlite
      .prepare(
        "SELECT COUNT(*) AS n FROM account_auth_transactions WHERE rights_only=1",
      )
      .get()!.n,
    90,
  );
});

test("rights proof never matches email, admits an unknown/deleted subject, accepts a mismatched provider or completes an expired claim", async () => {
  for (const mode of ["unknown", "deleted", "provider", "nonce", "expired"]) {
    const f = await fixture();
    const claim = await f.claimed({ verificationAction: "delete" });
    if (mode === "unknown")
      claim.identity = {
        ...f.identity,
        subject: "unknown-subject",
        email: "existing@example.test",
      };
    if (mode === "deleted")
      f.db.sqlite
        .prepare(
          "UPDATE accounts SET deleted_at=?,security_version=security_version+1 WHERE id=?",
        )
        .run(f.db.now, f.accountId);
    if (mode === "provider")
      claim.identity = {
        issuer: "https://github.com",
        subject: "existing-subject",
        email: "existing@example.test",
        emailVerified: true,
        authoritativeEmail: true,
      };
    if (mode === "nonce") claim.claimNonce = crypto.randomUUID();
    if (mode === "expired") f.db.now += 600001;
    await assert.rejects(
      completeRightsAccess(f.db, claim),
      /rights_verification_unavailable/,
    );
    assert.equal(
      f.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!
        .n,
      0,
      mode,
    );
    assert.equal(
      f.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
      1,
      mode,
    );
    assert.equal(
      f.db.sqlite
        .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
        .get()!.n,
      0,
      mode,
    );
  }
});

test("completion rolls back every rights session write when expiry or revocation races the batch", async () => {
  for (const mode of ["expiry", "revocation", "completion-expiry"]) {
    const f = await fixture();
    const claim = await f.claimed();
    if (mode === "completion-expiry") f.db.now += 590000;
    const originalBatch = f.db.batch.bind(f.db);
    f.db.batch = async (statements) => {
      if (mode === "completion-expiry") {
        // The five-minute proof is still live, but the original ten-minute
        // transaction expires between issuance and the final status write.
        const completion = statements[4];
        const originalRead = completion.read.bind(completion);
        completion.read = () => {
          f.db.now += 20000;
          return originalRead();
        };
        return originalBatch(statements);
      }
      const [first, ...rest] = statements;
      const originalRead = first.read.bind(first);
      first.read = () => {
        const result = originalRead();
        if (mode === "expiry") f.db.now += 600001;
        else
          f.db.sqlite
            .prepare(
              "UPDATE accounts SET security_version=security_version+1 WHERE id=?",
            )
            .run(f.accountId);
        return result;
      };
      return originalBatch([first, ...rest]);
    };
    await assert.rejects(
      completeRightsAccess(f.db, claim),
      /rights_verification_unavailable/,
    );
    assert.equal(
      f.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!
        .n,
      0,
      mode,
    );
    assert.equal(
      f.db.sqlite
        .prepare("SELECT COUNT(*) AS n FROM account_session_metadata")
        .get()!.n,
      0,
      mode,
    );
    assert.equal(
      f.db.sqlite
        .prepare("SELECT status FROM account_auth_transactions WHERE id=?")
        .get(claim.transactionId)!.status,
      "claimed",
      mode,
    );
  }
});
