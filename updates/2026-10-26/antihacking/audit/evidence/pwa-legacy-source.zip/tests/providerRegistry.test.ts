import test from "node:test";
import assert from "node:assert/strict";
import {
  DEFAULT_PROVIDER_ID,
  PROVIDER_IDS,
  PROVIDER_REGISTRY,
  availabilityById,
  classifyClaudeAuth,
  classifyCodexAuth,
  getProviderDescriptor,
  isProviderId,
  isSerializableProvider,
  providerEligibility,
  serializeAekrAdapter,
  unsupportedHostAvailability,
  validateProviderRegistry,
} from "../shared/providerRegistry";
import { defaultFunding } from "../shared/funding";

test("production registry contains exactly the two evidenced providers", () => {
  assert.deepEqual(PROVIDER_IDS, ["claude_code", "codex"]);
  assert.equal(DEFAULT_PROVIDER_ID, "codex");
  assert.deepEqual(
    PROVIDER_REGISTRY.map(({ id, displayName, capabilities }) => ({
      id,
      displayName,
      capabilities,
    })),
    [
      {
        id: "claude_code",
        displayName: "Claude Code",
        capabilities: [
          "subscription_cli",
          "desktop_cli_detection",
          "aekr_adapter_serialization",
        ],
      },
      {
        id: "codex",
        displayName: "Codex",
        capabilities: [
          "subscription_cli",
          "desktop_cli_detection",
          "aekr_adapter_serialization",
        ],
      },
    ],
  );
  assert.equal(isProviderId("mock"), false);
  assert.equal(isSerializableProvider("codex"), true);
});

test("registry owns exact fixed probes", () => {
  assert.deepEqual(
    PROVIDER_REGISTRY.map(({ desktopDetection }) => ({
      versionProbe: desktopDetection.versionProbe,
      authProbe: desktopDetection.authProbe,
    })),
    [
      {
        versionProbe: { executable: "claude", argv: ["--version"] },
        authProbe: { executable: "claude", argv: ["auth", "status"] },
      },
      {
        versionProbe: { executable: "codex", argv: ["--version"] },
        authProbe: { executable: "codex", argv: ["login", "status"] },
      },
    ],
  );
});

test("Claude classifier fails closed for every unsupported auth result", () => {
  assert.deepEqual(
    classifyClaudeAuth({
      code: 0,
      combined: JSON.stringify({ loggedIn: true, authMethod: "claude.ai" }),
    }),
    { state: "installed_authenticated", reasonCode: "ready" },
  );
  assert.equal(
    classifyClaudeAuth({
      code: 0,
      combined: JSON.stringify({ loggedIn: true, authMethod: "api_key" }),
    }).reasonCode,
    "unsupported_auth_mode",
  );
  assert.equal(
    classifyClaudeAuth({ code: 0, combined: '{"loggedIn":false}' }).reasonCode,
    "not_logged_in",
  );
  assert.equal(
    classifyClaudeAuth({ code: 0, combined: "not json" }).reasonCode,
    "auth_status_unreadable",
  );
});

test("Codex classifier accepts ChatGPT and rejects API key or unreadable auth", () => {
  assert.deepEqual(
    classifyCodexAuth({ code: 0, combined: "Logged in using ChatGPT" }),
    { state: "installed_authenticated", reasonCode: "ready" },
  );
  assert.equal(
    classifyCodexAuth({ code: 0, combined: "Logged in using API key" })
      .reasonCode,
    "unsupported_auth_mode",
  );
  assert.equal(
    classifyCodexAuth({ code: 0, combined: "Please log in" }).reasonCode,
    "not_logged_in",
  );
  assert.equal(
    classifyCodexAuth({ code: 1, combined: "ChatGPT" }).reasonCode,
    "auth_status_unreadable",
  );
});

test("availability validation requires one known result per provider", () => {
  const results = unsupportedHostAvailability();
  const indexed = availabilityById(results);
  assert.equal(indexed.get("claude_code")?.state, "unsupported_host");
  assert.equal(indexed.get("codex")?.reasonCode, "host_cannot_detect");
  assert.throws(
    () => availabilityById(results.slice(1)),
    /invalidProviderAvailability/,
  );
  assert.throws(
    () =>
      availabilityById([
        results[0],
        {
          providerId: "codex",
          state: "installed_authenticated",
          reasonCode: "cli_not_found",
        },
      ]),
    /invalidProviderAvailability/,
  );
  assert.throws(
    () => availabilityById([...results, results[0]]),
    /invalidProviderAvailability/,
  );
  assert.throws(
    () =>
      availabilityById([
        ...results.slice(0, 1),
        {
          providerId: "mock",
          state: "not_installed",
          reasonCode: "cli_not_found",
        },
      ]),
    /invalidProviderAvailability/,
  );
});

test("eligibility separates export, execution, unsupported, and unchecked", () => {
  assert.deepEqual(providerEligibility("claude_code", null, "execute"), {
    enabled: false,
    status: "unavailable",
    reasonCode: "auth_status_unreadable",
  });
  const unsupported = unsupportedHostAvailability()[0];
  assert.deepEqual(providerEligibility("claude_code", unsupported, "export"), {
    enabled: true,
    status: "unsupported",
    reasonCode: "host_cannot_detect",
  });
  assert.equal(
    providerEligibility(
      "claude_code",
      {
        providerId: "claude_code",
        state: "installed_authenticated",
        reasonCode: "ready",
      },
      "execute",
    ).enabled,
    true,
  );
});

test("adapter serialization preserves exact current policies", () => {
  const claude = getProviderDescriptor("claude_code");
  const codex = getProviderDescriptor("codex");
  assert.ok(claude && codex);
  assert.deepEqual(
    serializeAekrAdapter(claude, {
      canonicalRole: "architect",
      funding: defaultFunding(),
    }),
    ["kind: claude_code"],
  );
  assert.deepEqual(
    serializeAekrAdapter(codex, {
      canonicalRole: "implementer",
      funding: defaultFunding(),
    }),
    ["kind: codex", "sandbox: workspace-write"],
  );
  assert.deepEqual(
    serializeAekrAdapter(codex, {
      canonicalRole: "auditor",
      funding: defaultFunding(),
    }),
    ["kind: codex", "sandbox: read-only"],
  );
});

test("test-only invalid descriptors cannot enter the production registry", () => {
  assert.throws(
    () =>
      validateProviderRegistry([
        {
          id: "mock",
          capabilities: ["aekr_adapter_serialization"],
        },
      ]),
    /invalidProviderSerializer/,
  );
  assert.throws(
    () =>
      validateProviderRegistry([
        {
          id: "test-only",
          capabilities: ["aekr_adapter_serialization"],
        },
      ]),
    /invalidProviderRegistry/,
  );
  assert.throws(
    () =>
      validateProviderRegistry([
        { id: "mock", capabilities: [] },
        { id: "mock", capabilities: [] },
      ]),
    /invalidProviderRegistry/,
  );
});
