import assert from "node:assert/strict";
import { mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import test from "node:test";

test("publication gate allows public code/examples but rejects maps, internal config, sources and unreviewed archives", async (t) => {
  const { checkWebSecurityArtifacts } =
    await import("../scripts/check-web-security-artifacts.mjs");
  const cache = new URL("../.local/cache/", import.meta.url);
  await mkdir(cache, { recursive: true });
  const root = await mkdtemp(new URL("web-security-artifact-", cache));
  t.after(() => rm(root, { recursive: true, force: true }));
  await writeFile(path.join(root, "index.html"), "<html>Public app</html>");
  await mkdir(path.join(root, "assets"));
  await mkdir(path.join(root, "examples"));
  const publicJs = path.join(root, "assets", "index.js");
  await writeFile(
    publicJs,
    'console.log("ACCOUNT_EMAIL_ENCRYPTION_KEY is a documented environment name");',
  );
  await writeFile(
    path.join(root, "examples", "accreatio-basic-sample.zip"),
    "fixture archive path only",
  );
  assert.equal((await checkWebSecurityArtifacts(root)).files, 3);
  for (const filename of [
    ".env.local",
    "wrangler.toml",
    "source.ts",
    "backup.sql",
    "bundle.js.map.br",
    "source-backup.zip",
  ]) {
    const target = path.join(root, filename);
    await writeFile(target, "synthetic fixture only");
    await assert.rejects(
      checkWebSecurityArtifacts(root),
      /publication gate failed/i,
    );
    await rm(target);
  }
  await writeFile(
    publicJs,
    "console.log(1);\n//# sourceMappingURL=data:application/json;base64,e30=",
  );
  await assert.rejects(checkWebSecurityArtifacts(root), /source-map directive/);
  await writeFile(publicJs, "console.log(1);");
  await mkdir(path.join(root, "functions"));
  await assert.rejects(
    checkWebSecurityArtifacts(root),
    /internal directory: functions/,
  );
});
