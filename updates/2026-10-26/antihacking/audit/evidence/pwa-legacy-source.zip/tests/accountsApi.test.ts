import assert from "node:assert/strict";
import test from "node:test";
import { harness } from "./helpers/accountHarness";

test("legacy login returns only to the app without authentication; identity requires an own session", async () => {
  const h = await harness();
  const response = await h.call("login", { method: "GET", token: "forged" });
  assert.equal(response.status, 303);
  assert.equal(response.headers.get("Location"), "/");
  assert.equal(response.headers.get("Cache-Control"), "no-store");
  assert.equal(response.headers.get("Set-Cookie"), null);
  assert.equal(await response.text(), "");
  h.db.fail = true;
  const disabled = await h.call("login", {
    method: "GET",
    url: "https://preview.accreatio.test/api/account/login?returnTo=https://other.test/&account=continue",
    env: { ...h.env, ACCOUNT_ENABLED: "false" },
  });
  assert.equal(disabled.status, 303);
  assert.equal(disabled.headers.get("Location"), "/");
  assert.equal(disabled.headers.get("Set-Cookie"), null);
  assert.equal((await h.call("login", { method: "POST" })).status, 405);
  h.db.fail = false;
  assert.equal((await h.call("identity", { method: "GET" })).status, 401);
  assert.equal((await h.call("session")).status, 401);
  const cookie = await h.login();
  const identity = await h.call("identity", {
    method: "GET",
    cookie,
    token: "forged",
  });
  assert.deepEqual(await identity.json(), {
    email: "person@example.test",
    displayName: "person",
  });
  const session = await h.call("session", { method: "GET", cookie, token: "" });
  assert.equal(
    (await session.json()).expiresAt,
    new Date(h.db.now + 86_400_000).toISOString(),
  );
});

test("Access assertions do not create product sessions", async () => {
  const h = await harness();
  for (const token of [await h.token(), "forged", ""]) {
    assert.equal((await h.call("session", { token })).status, 401);
  }
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()?.n,
    0,
  );
});

test("export admission rejects absent, stale or foreign context before quota or receipt access", async () => {
  const h = await harness();
  const firstCookie = await h.login();
  const first = await (
    await h.call("session", { cookie: firstCookie, method: "GET" })
  ).json();
  const operationId = crypto.randomUUID();
  const firstContext = {
    ownerKey: first.ownerKey,
    sessionKey: first.sessionKey,
  };
  assert.equal(
    (
      await h.call("authorize", {
        cookie: firstCookie,
        body: { operationId, ...firstContext },
      })
    ).status,
    200,
  );
  const rotatedCookie = await h.login();
  const otherCookie = await h.login({ email: "other@example.test" });
  const other = await (
    await h.call("session", { cookie: otherCookie, method: "GET" })
  ).json();
  for (const [cookie, context] of [
    [firstCookie, {}],
    [firstCookie, { ownerKey: first.ownerKey }],
    [firstCookie, { ...firstContext, sessionKey: other.sessionKey }],
    [firstCookie, { ...firstContext, ownerKey: other.ownerKey }],
    [rotatedCookie, firstContext],
    [otherCookie, firstContext],
  ] as const) {
    const denied = await h.call("authorize", {
      cookie,
      body: { operationId, ...context },
      bindExportContext: false,
    });
    assert.equal(denied.status, 409);
    assert.deepEqual(await denied.json(), {
      error: {
        code: "account_context_changed",
        message: "Your account session changed. Prepare this ZIP again.",
      },
    });
  }
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM export_authorizations")
      .get()!.n,
    1,
  );
  assert.equal(
    (
      await h
        .call("session", { cookie: otherCookie, method: "GET" })
        .then((r) => r.json())
    ).remaining,
    5,
  );
  const accepted = await h.call("authorize", {
    cookie: otherCookie,
    body: {
      operationId,
      ownerKey: other.ownerKey,
      sessionKey: other.sessionKey,
    },
  });
  assert.equal(accepted.status, 200);
  assert.equal((await accepted.json()).remaining, 4);
});

test("six concurrent operations across two sessions admit exactly five; replay uses the original receipt", async () => {
  const h = await harness();
  const cookies = await Promise.all([h.login(), h.login()]);
  const operations = Array.from({ length: 6 }, () => crypto.randomUUID());
  const responses = await Promise.all(
    operations.map((operationId, i) =>
      h.call("authorize", { cookie: cookies[i % 2], body: { operationId } }),
    ),
  );
  assert.equal(responses.filter((r) => r.status === 200).length, 5);
  assert.equal(responses.filter((r) => r.status === 429).length, 1);
  const winner = responses.findIndex((r) => r.status === 200);
  const receipt = await responses[winner].json();
  const replay = await h.call("authorize", {
    cookie: cookies[1],
    body: { operationId: operations[winner] },
  });
  assert.equal(replay.status, 200);
  const repeated = await replay.json();
  assert.equal(repeated.operationId, receipt.operationId);
  assert.equal(repeated.issuedAt, receipt.issuedAt);
  assert.equal(repeated.remaining, 0);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM export_authorizations").get()
      ?.n,
    5,
  );
  const session = await h.call("session", {
    cookie: cookies[0],
    method: "GET",
  });
  assert.equal((await session.json()).remaining, 0);
});

test("midnight does not reset allowance; one slot returns at the exact rolling boundary", async () => {
  const h = await harness();
  let cookie = await h.login();
  const start = h.db.now;
  for (let n = 0; n < 5; n++) {
    assert.equal(
      (
        await h.call("authorize", {
          cookie,
          body: { operationId: crypto.randomUUID() },
        })
      ).status,
      200,
    );
    h.db.now += 1000;
  }
  h.db.now = Date.parse("2026-09-06T00:01:00Z");
  assert.equal(
    (
      await h.call("authorize", {
        cookie,
        body: { operationId: crypto.randomUUID() },
      })
    ).status,
    429,
  );
  h.db.now = start + 86_400_000 - 1000;
  cookie = await h.login();
  assert.equal(
    (
      await h.call("authorize", {
        cookie,
        body: { operationId: crypto.randomUUID() },
      })
    ).status,
    429,
  );
  h.db.now += 1000;
  assert.equal(
    (
      await h.call("authorize", {
        cookie,
        body: { operationId: crypto.randomUUID() },
      })
    ).status,
    200,
  );
  assert.equal(
    (
      await h.call("authorize", {
        cookie,
        body: { operationId: crypto.randomUUID() },
      })
    ).status,
    429,
  );
});

test("logout revokes the app token; changing browser or deleting/re-registering preserves active quota", async () => {
  const h = await harness();
  let cookie = await h.login();
  for (let n = 0; n < 5; n++)
    await h.call("authorize", {
      cookie,
      body: { operationId: crypto.randomUUID() },
    });
  assert.equal((await h.call("logout", { cookie })).status, 200);
  assert.equal(
    (await h.call("session", { cookie, method: "GET" })).status,
    401,
  );
  cookie = await h.login();
  assert.equal(
    (await (await h.call("session", { cookie, method: "GET" })).json())
      .remaining,
    0,
  );
  await h.controlProof(cookie, "delete");
  assert.equal((await h.call("delete", { cookie })).status, 200);
  assert.equal(
    h.db.sqlite.prepare("SELECT email FROM accounts").get()?.email,
    null,
  );
  assert.equal(
    (await h.call("session", { cookie, method: "GET" })).status,
    401,
  );
  cookie = await h.login();
  assert.equal(
    (
      await h.call("authorize", {
        cookie,
        body: { operationId: crypto.randomUUID() },
      })
    ).status,
    429,
  );
});

test("own session ignores provider assertions; origin, arbitrary fields, database outage and kill switch fail closed", async () => {
  const h = await harness();
  const cookie = await h.login();
  assert.equal(
    (
      await h.call("session", {
        cookie,
        method: "GET",
        claims: { email: "other@example.test" },
      })
    ).status,
    200,
  );
  assert.equal(
    (
      await h.call("authorize", {
        cookie,
        origin: "https://hostile.test",
        body: { operationId: crypto.randomUUID() },
      })
    ).status,
    403,
  );
  assert.equal(
    (
      await h.call("authorize", {
        cookie,
        body: { operationId: crypto.randomUUID(), email: "other@example.test" },
      })
    ).status,
    400,
  );
  const closed = await h.call("session", {
    cookie,
    env: { ...h.env, ACCOUNT_ENABLED: "false" },
  });
  assert.equal(closed.status, 503);
  assert.equal(closed.headers.get("Cache-Control"), "no-store");
  h.db.fail = true;
  assert.equal(
    (
      await h.call("authorize", {
        cookie,
        body: { operationId: crypto.randomUUID() },
      })
    ).status,
    503,
  );
  h.db.fail = false;
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM export_authorizations").get()
      ?.n,
    0,
  );
});

test("expired app sessions fail without an external provider; old receipts are never free new exports", async () => {
  const h = await harness();
  const cookie = await h.login();
  const operationId = crypto.randomUUID();
  await h.call("authorize", { cookie, body: { operationId } });
  h.db.now += 86_400_000;
  assert.equal(
    (await h.call("session", { cookie, method: "GET" })).status,
    401,
  );
  h.db.now += 86_400_000 + 1000;
  const fresh = await h.login();
  const response = await h.call("authorize", {
    cookie: fresh,
    body: { operationId },
  });
  assert.equal(response.status, 200);
  assert.equal((await response.json()).remaining, 4);
});
