import assert from "node:assert/strict";
import { POLICY_AUTHORIZATION } from "./helpers/accountHarness";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { build } from "esbuild";
import { Miniflare, convertV4MiniflareOptions } from "miniflare";

test(
  "OIDC executes in workerd with real D1 and signature verification",
  { timeout: 60_000 },
  async () => {
    const origin = "https://accreatio.pages.dev";
    const issuer = "https://accounts.google.com";
    const clientId = "worker-fixture.apps.googleusercontent.com";
    const pair = await crypto.subtle.generateKey(
      {
        name: "RSASSA-PKCS1-v1_5",
        modulusLength: 2048,
        publicExponent: new Uint8Array([1, 0, 1]),
        hash: "SHA-256",
      },
      true,
      ["sign", "verify"],
    );
    const publicKey = await crypto.subtle.exportKey("jwk", pair.publicKey);
    let authorization: URL;
    let jwksRequests = 0;
    // This wrapper exists only inside the local test bundle. Production receives
    // no mock-provider binding or user-selectable token endpoint.
    const output = await build({
      stdin: {
        contents: `import {handleOidc} from './functions/_lib/auth/oidc.ts';
        import {handleAccount} from './functions/_lib/accounts.ts';
        export default { fetch(request, env) {
          const url = new URL(request.url);
          if(url.pathname.startsWith('/api/account/')) return handleAccount({request,env},url.pathname.split('/').at(-1));
          const action = url.pathname.endsWith('/start') ? 'start' : url.pathname.endsWith('/callback') ? 'callback' : 'methods';
          return handleOidc({request, env}, action, {
            fetch: (url, init) => env.GOOGLE_FIXTURE.fetch(new Request(url, init)),
            now: () => Date.now(), randomUUID: () => crypto.randomUUID(), subtle: crypto.subtle
          });
        }};`,
        resolveDir: process.cwd(),
        loader: "ts",
      },
      bundle: true,
      platform: "browser",
      target: "es2022",
      format: "esm",
      write: false,
    });
    const options = convertV4MiniflareOptions({
      modules: true,
      script: output.outputFiles[0].text,
      // Matches the product's wrangler.toml and the installed workerd binary.
      compatibilityDate: "2026-08-06",
      d1Databases: ["ACCOUNT_DB"],
      bindings: {
        ACCOUNT_ENABLED: "true",
        ACCOUNT_OIDC_ENABLED: "true",
        ACCOUNT_OTP_ENABLED: "false",
        ACCOUNT_IDENTITY_KEY: "a".repeat(64),
        ACCOUNT_OTP_KEY: "b".repeat(64),
        ACCOUNT_OIDC_TRANSACTION_KEY: "c".repeat(64),
        ACCOUNT_EMAIL_ENCRYPTION_KEY: "d".repeat(64),
        ACCOUNT_EMAIL_LOOKUP_KEY: "e".repeat(64),
        ACCOUNT_AUTH_LOCATOR_KEY: "f".repeat(64),
        GOOGLE_CLIENT_ID: clientId,
        GOOGLE_CLIENT_SECRET: "synthetic-worker-client-secret",
        GOOGLE_REDIRECT_URI: `${origin}/api/auth/v1/oidc/google/callback`,
      },
      serviceBindings: {
        GOOGLE_FIXTURE: async (request) => {
          if (request.url === "https://www.googleapis.com/oauth2/v3/certs") {
            jwksRequests++;
            return Response.json({
              keys: [
                {
                  ...publicKey,
                  kid: "workerd-fixture-key",
                  alg: "RS256",
                  use: "sig",
                },
              ],
            });
          }
          assert.equal(request.url, "https://oauth2.googleapis.com/token");
          const body = new URLSearchParams(await request.text());
          const verifier = body.get("code_verifier")!;
          assert.equal(
            Buffer.from(
              await crypto.subtle.digest(
                "SHA-256",
                new TextEncoder().encode(verifier),
              ),
            ).toString("base64url"),
            authorization.searchParams.get("code_challenge"),
          );
          assert.equal(body.get("client_id"), clientId);
          const now = Math.floor(Date.now() / 1000);
          const data = [
            { alg: "RS256", kid: "workerd-fixture-key" },
            {
              iss: issuer,
              aud: clientId,
              sub: "workerd-fixture-subject",
              iat: now,
              exp: now + 3600,
              nonce: authorization.searchParams.get("nonce"),
              email: "workerd.synthetic@gmail.com",
              email_verified: true,
              name: "Worker Profile",
            },
          ]
            .map((value) =>
              Buffer.from(JSON.stringify(value)).toString("base64url"),
            )
            .join(".");
          const signature = Buffer.from(
            await crypto.subtle.sign(
              "RSASSA-PKCS1-v1_5",
              pair.privateKey,
              new TextEncoder().encode(data),
            ),
          ).toString("base64url");
          return Response.json({
            token_type: "Bearer",
            access_token: "synthetic-provider-token",
            id_token: `${data}.${signature}`,
            expires_in: 3600,
          });
        },
      },
    });
    const mf = new Miniflare(options);
    try {
      const db = await mf.getD1Database("ACCOUNT_DB");
      for (const filename of [
        "0001_accounts.sql",
        "0002_own_email_otp.sql",
        "0003_google_oidc_privacy.sql",
        "0004_google_display_name.sql",
        "0005_account_policy_authorization.sql",
        "0006_github_identity_linking.sql",
        "0007_abuse_guard.sql",
        "0008_rights_only.sql",
      ]) {
        const sql = await readFile(
          new URL(`../migrations-auth/${filename}`, import.meta.url),
          "utf8",
        );
        for (const statement of sql
          .replace(/--[^\n]*/g, "")
          // Keep a CREATE TRIGGER body intact, including its internal ';'.
          .split(/;\s*(?=CREATE|ALTER|UPDATE|$)/)
          .map((part) => part.trim())
          .filter(Boolean))
          await db.prepare(statement).run();
      }
      for (const policyAuthorization of [
        undefined,
        { ...POLICY_AUTHORIZATION, termsAccepted: false },
        { ...POLICY_AUTHORIZATION, purposeVersion: "old" },
      ]) {
        const denied = await mf.dispatchFetch(
          `${origin}/api/auth/v1/oidc/google/start`,
          {
            method: "POST",
            headers: { Origin: origin, "Content-Type": "application/json" },
            body: JSON.stringify({
              purpose: "sign_in",
              returnRoute: "builder",
              mode: "popup",
              policyAuthorization,
            }),
          },
        );
        assert.ok([400, 403, 409].includes(denied.status));
      }
      assert.equal(
        (
          await db
            .prepare("SELECT COUNT(*) AS n FROM account_auth_transactions")
            .first<{ n: number }>()
        )?.n,
        0,
      );
      const start = await mf.dispatchFetch(
        `${origin}/api/auth/v1/oidc/google/start`,
        {
          method: "POST",
          headers: { Origin: origin, "Content-Type": "application/json" },
          body: JSON.stringify({
            purpose: "sign_in",
            returnRoute: "builder",
            mode: "popup",
            policyAuthorization: POLICY_AUTHORIZATION,
          }),
        },
      );
      assert.equal(start.status, 200, await start.clone().text());
      const started = (await start.json()) as {
        authorizationUrl: string;
        transactionId: string;
      };
      authorization = new URL(started.authorizationUrl);
      const cookie = start.headers.get("Set-Cookie")!.split(";")[0];
      const callback = new URL(`${origin}/api/auth/v1/oidc/google/callback`);
      callback.searchParams.set("code", "workerd-fixture-code");
      callback.searchParams.set(
        "state",
        authorization.searchParams.get("state")!,
      );
      callback.searchParams.set("iss", issuer);
      const completed = await mf.dispatchFetch(callback.href, {
        headers: { Cookie: cookie },
        redirect: "manual",
      });
      assert.equal(completed.status, 303);
      assert.match(completed.headers.get("Location")!, /auth=success$/);
      assert.match(
        completed.headers.get("Set-Cookie")!,
        /__Host-accreatio_session=[a-f0-9]{64}; Path=\/; Secure; HttpOnly; SameSite=Strict/,
      );
      assert.equal(jwksRequests, 1);
      assert.equal(
        (
          await db
            .prepare("SELECT COUNT(*) AS count FROM account_sessions")
            .first<{ count: number }>()
        )?.count,
        1,
      );
      const sessionCookie = completed.headers.get("Set-Cookie")!.split(";")[0];
      const accountRequest = (
        action: string,
        method = "GET",
        body?: unknown,
        cookieValue = sessionCookie,
        requestOrigin = origin,
      ) =>
        mf.dispatchFetch(`${origin}/api/account/${action}`, {
          method,
          headers: {
            Cookie: cookieValue,
            Origin: requestOrigin,
            "Content-Type": "application/json",
          },
          ...(body ? { body: JSON.stringify(body) } : {}),
        });
      assert.equal(
        (
          (await (await accountRequest("session")).json()) as {
            policyAuthorizationRequired: boolean;
          }
        ).policyAuthorizationRequired,
        false,
      );
      assert.equal(
        (
          await db
            .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
            .first<{ n: number }>()
        )?.n,
        1,
      );
      await db.prepare("DELETE FROM account_policy_authorizations").run();
      const unchangedTables = [
        "accounts",
        "account_sessions",
        "account_session_metadata",
        "account_external_identities",
      ];
      const beforeExpiry = await Promise.all(
        unchangedTables.map((table) =>
          db.prepare(`SELECT * FROM ${table} ORDER BY rowid`).all(),
        ),
      );
      // Deterministically cross the real D1 clock boundary after the receipt
      // write. The completion guard must roll back the whole login batch.
      await db
        .prepare(
          "CREATE TRIGGER expire_login_after_receipt AFTER INSERT ON account_policy_authorizations BEGIN UPDATE account_auth_transactions SET expires_at=unixepoch()*1000 WHERE status='claimed'; END",
        )
        .run();
      const expiringStart = await mf.dispatchFetch(
        `${origin}/api/auth/v1/oidc/google/start`,
        {
          method: "POST",
          headers: {
            Origin: origin,
            Cookie: sessionCookie,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            purpose: "sign_in",
            returnRoute: "builder",
            mode: "popup",
            policyAuthorization: POLICY_AUTHORIZATION,
          }),
        },
      );
      assert.equal(expiringStart.status, 200);
      const expiring = (await expiringStart.json()) as {
        authorizationUrl: string;
        transactionId: string;
      };
      authorization = new URL(expiring.authorizationUrl);
      callback.searchParams.set(
        "state",
        authorization.searchParams.get("state")!,
      );
      const deniedCompletion = await mf.dispatchFetch(callback.href, {
        headers: {
          Cookie: expiringStart.headers.get("Set-Cookie")!.split(";")[0],
        },
        redirect: "manual",
      });
      assert.match(deniedCompletion.headers.get("Location")!, /auth=failure$/);
      const afterExpiry = await Promise.all(
        unchangedTables.map((table) =>
          db.prepare(`SELECT * FROM ${table} ORDER BY rowid`).all(),
        ),
      );
      assert.deepEqual(
        afterExpiry.map((result) => result.results),
        beforeExpiry.map((result) => result.results),
      );
      assert.equal(
        (
          await db
            .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
            .first<{ n: number }>()
        )?.n,
        0,
      );
      assert.deepEqual(
        await db
          .prepare(
            "SELECT status,issued_session_token_hash FROM account_auth_transactions WHERE id=?",
          )
          .bind(expiring.transactionId)
          .first(),
        { status: "failed", issued_session_token_hash: null },
      );
      await db.prepare("DROP TRIGGER expire_login_after_receipt").run();
      assert.equal(
        (
          (await (await accountRequest("session")).json()) as {
            policyAuthorizationRequired: boolean;
          }
        ).policyAuthorizationRequired,
        true,
      );
      const exportContext = (await (
        await accountRequest("session")
      ).json()) as { ownerKey: string; sessionKey: string };
      assert.equal(
        (
          await accountRequest("authorize", "POST", {
            operationId: crypto.randomUUID(),
            ownerKey: exportContext.ownerKey,
            sessionKey: exportContext.sessionKey,
          })
        ).status,
        403,
      );
      assert.equal(
        (
          await accountRequest(
            "policy",
            "POST",
            POLICY_AUTHORIZATION,
            sessionCookie,
            "https://wrong.test",
          )
        ).status,
        403,
      );
      await db
        .prepare(
          "CREATE TRIGGER policy_failure BEFORE INSERT ON account_policy_authorizations BEGIN SELECT RAISE(ABORT,'fixture failure'); END",
        )
        .run();
      assert.equal(
        (await accountRequest("policy", "POST", POLICY_AUTHORIZATION)).status,
        503,
      );
      assert.equal(
        (
          await db
            .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
            .first<{ n: number }>()
        )?.n,
        0,
      );
      await db.prepare("DROP TRIGGER policy_failure").run();
      assert.equal(
        (await accountRequest("policy", "POST", POLICY_AUTHORIZATION)).status,
        200,
      );
      const saved = await db
        .prepare("SELECT authorized_at FROM account_policy_authorizations")
        .first<{ authorized_at: number }>();
      const repeated = await Promise.all([
        accountRequest("policy", "POST", POLICY_AUTHORIZATION),
        accountRequest("policy", "POST", POLICY_AUTHORIZATION),
      ]);
      assert.ok(repeated.every((r) => r.status === 200));
      assert.equal(
        (
          await db
            .prepare("SELECT authorized_at FROM account_policy_authorizations")
            .first<{ authorized_at: number }>()
        )?.authorized_at,
        saved?.authorized_at,
      );
      const exported = await accountRequest("data");
      assert.equal(exported.status, 401);

      const beforeAccess = await db.prepare("SELECT * FROM accounts").first();
      const rights = await mf.dispatchFetch(
        `${origin}/api/auth/v1/oidc/google/start`,
        {
          method: "POST",
          headers: {
            Origin: origin,
            Cookie: sessionCookie,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            purpose: "account_access",
            verificationAction: "data",
            returnRoute: "builder",
            mode: "popup",
          }),
        },
      );
      assert.equal(rights.status, 200);
      const rightsStart = (await rights.json()) as { authorizationUrl: string };
      authorization = new URL(rightsStart.authorizationUrl);
      callback.searchParams.set(
        "state",
        authorization.searchParams.get("state")!,
      );
      const rightsCompleted = await mf.dispatchFetch(callback.href, {
        headers: { Cookie: rights.headers.get("Set-Cookie")!.split(";")[0] },
        redirect: "manual",
      });
      assert.match(rightsCompleted.headers.get("Location")!, /auth=success$/);
      const ownData = await accountRequest(
        "data",
        "GET",
        undefined,
        rightsCompleted.headers.get("Set-Cookie")!.split(";")[0],
      );
      assert.equal(ownData.status, 200);
      assert.deepEqual(
        ((await ownData.json()) as { policyAuthorization: unknown })
          .policyAuthorization,
        {
          ...POLICY_AUTHORIZATION,
          authorizedAt: new Date(saved!.authorized_at).toISOString(),
        },
      );
      assert.notEqual(
        rightsCompleted.headers.get("Set-Cookie")!.split(";")[0],
        sessionCookie,
      );
      assert.deepEqual(
        await db.prepare("SELECT * FROM accounts").first(),
        beforeAccess,
      );
      assert.equal(
        (
          await db
            .prepare("SELECT authorized_at FROM account_policy_authorizations")
            .first<{ authorized_at: number }>()
        )?.authorized_at,
        saved?.authorized_at,
      );
      assert.equal(
        (
          await db
            .prepare(
              "SELECT secrets_ciphertext FROM account_auth_transactions WHERE id=?",
            )
            .bind(started.transactionId)
            .first<{ secrets_ciphertext: string | null }>()
        )?.secrets_ciphertext,
        null,
      );
      assert.equal(
        (
          await db
            .prepare("SELECT email FROM accounts")
            .first<{ email: string | null }>()
        )?.email,
        null,
      );
      assert.equal(
        (
          await db
            .prepare(
              "SELECT COUNT(*) AS n FROM accounts WHERE display_name_ciphertext LIKE 'v1:%'",
            )
            .first<{ n: number }>()
        )?.n,
        1,
      );
      // Exercise the database trigger used by a compatible older deletion writer.
      await db.prepare("UPDATE accounts SET deleted_at=unixepoch()*1000").run();
      assert.equal(
        (
          await db
            .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
            .first<{ n: number }>()
        )?.n,
        0,
      );
      assert.equal(
        (
          await db
            .prepare("SELECT display_name_ciphertext FROM accounts")
            .first<{ display_name_ciphertext: string | null }>()
        )?.display_name_ciphertext,
        null,
      );
    } finally {
      await mf.dispose();
    }
  },
);
