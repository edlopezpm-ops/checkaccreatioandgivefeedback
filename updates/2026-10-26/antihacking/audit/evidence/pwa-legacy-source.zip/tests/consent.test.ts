import test from "node:test";
import assert from "node:assert/strict";
import {
  advertisingAdapter,
  analyticsAdapter,
  DEFAULT_CONSENT,
  setOptionalConsent,
} from "../src/account/consent";

test("necessary consent is separate while optional purposes default refused", () => {
  assert.deepEqual(DEFAULT_CONSENT, {
    necessary: true,
    analytics: false,
    advertising: false,
  });
  assert.deepEqual(setOptionalConsent(DEFAULT_CONSENT, "analytics", true), {
    necessary: true,
    analytics: true,
    advertising: false,
  });
  assert.equal(DEFAULT_CONSENT.necessary, true);
});

test("analytics and advertising adapters are inert no-ops", () => {
  assert.equal(analyticsAdapter.kind, "no-op");
  assert.equal(advertisingAdapter.kind, "no-op");
  assert.equal(analyticsAdapter.record("test", { ignored: true }), undefined);
  assert.equal(advertisingAdapter.record("test"), undefined);
});
