import assert from "node:assert/strict";
import test from "node:test";
import * as React from "react";
import { renderToStaticMarkup } from "react-dom/server";

import { ContextStage } from "../src/components/creation/ContextStage";
import { DeliveryStage } from "../src/components/creation/DeliveryStage";
import { FoundationStage } from "../src/components/creation/FoundationStage";
import { TeamStage } from "../src/components/creation/TeamStage";
import { defaultOrchestration, type ProjectDefinition } from "../src/types";

Object.assign(globalThis, { React });

// The creation flow drifted into explaining instead of instructing. Without a
// hard limit, prose accumulates one helpful sentence at a time until a screen
// is a wall of text again.
//
// An earlier version of this guard read the source files and passed on every
// screen, because it only ever looked at the header and the field hints. It
// gave false comfort. This one renders the real component and counts the
// prose a user actually sees.
//
// Counted: prose that is not a control and not a title -- stage intros, helper
// text, notes.
// Not counted: field labels (<strong>), button text, option text, the <h1>,
// and anything the user typed. Those are load-bearing or not authored copy.
const BUDGET_WORDS = 60;

const project: ProjectDefinition = {
  name: "Demo",
  phase: "idea",
  context: "Context",
  restrictions: "",
  route: "local",
  action: "repository",
  destination: "/projects",
  participants: [
    { id: "participant-01", role: "generalist", label: "Global view" },
  ],
  attachments: [],
  initializeGit: false,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: true,
  orchestration: defaultOrchestration(),
};

const responsibilities = {
  generalist: { es: "Visión global", en: "Global view" },
  architect: { es: "Diseño", en: "Design" },
  implementer: { es: "Implementación", en: "Implementation" },
  auditor: { es: "Auditoría", en: "Audit" },
};

const noop = () => {};

/** Strips controls and titles, then reduces what remains to visible words. */
export const prose = (html: string) => {
  const withoutControls = html
    .replace(/<button[\s\S]*?<\/button>/g, " ")
    .replace(/<option[\s\S]*?<\/option>/g, " ")
    .replace(/<strong[\s\S]*?<\/strong>/g, " ")
    .replace(/<h1[\s\S]*?<\/h1>/g, " ")
    .replace(/<svg[\s\S]*?<\/svg>/g, " ");
  return withoutControls
    .replace(/<[^>]+>/g, " ")
    .replace(/&[a-z]+;|&#\d+;/gi, " ")
    .split(/\s+/)
    .filter(Boolean);
};

const screens = (locale: "en" | "es") => {
  const shared = {
    project,
    locale,
    errors: {},
    errorText: () => undefined,
    onChange: noop,
  } as const;
  return [
    [
      "Foundation",
      React.createElement(FoundationStage, {
        ...shared,
        isWeb: true,
        onAttachmentsSelected: noop,
        onRemoveAttachment: noop,
        attachmentIssues: [],
        restoredAttachmentCount: 0,
        webAttachments: [],
      } as never),
    ],
    ["Context", React.createElement(ContextStage, { ...shared } as never)],
    [
      "Team",
      React.createElement(TeamStage, {
        ...shared,
        isWeb: false,
        onAddParticipant: noop,
        onConfigureMode1: noop,
        mode1TriggerRef: { current: null },
        responsibilities,
      } as never),
    ],
    [
      "Delivery",
      React.createElement(DeliveryStage, {
        ...shared,
        isWeb: false,
        onBrowse: noop,
      } as never),
    ],
  ] as const;
};

test("each creation screen stays inside its instructional copy budget", () => {
  const over: string[] = [];
  for (const locale of ["en", "es"] as const)
    for (const [name, element] of screens(locale)) {
      const words = prose(renderToStaticMarkup(element)).length;
      if (words > BUDGET_WORDS)
        over.push(
          `${name} (${locale}): ${words} words, budget ${BUDGET_WORDS}`,
        );
    }
  assert.deepEqual(
    over,
    [],
    `Screens over the copy budget:\n  ${over.join("\n  ")}`,
  );
});

// Two equally weighted primary buttons make the user decide which one is "the"
// action. Exactly one primary per screen; everything else is secondary.
test("each creation screen presents at most one primary action", () => {
  for (const [name, element] of screens("en")) {
    const html = renderToStaticMarkup(element);
    const primaries = [
      ...html.matchAll(/<button[^>]*class="[^"]*\bprimary\b[^"]*"/g),
    ];
    assert.ok(
      primaries.length <= 1,
      `${name} renders ${primaries.length} primary actions; one is the limit`,
    );
  }
});
