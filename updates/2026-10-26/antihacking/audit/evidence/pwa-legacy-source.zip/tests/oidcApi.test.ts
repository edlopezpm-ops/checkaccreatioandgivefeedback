import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import {
  handleOidc,
  googleIdentity,
  openOidcSecrets,
  sealOidcSecrets,
  type OidcAction,
} from "../functions/_lib/auth/oidc";
import {
  handleAccount,
  type AccountBindings,
} from "../functions/_lib/accounts";
import { harness, POLICY_AUTHORIZATION } from "./helpers/accountHarness";

const origin = "https://accreatio.pages.dev";
const callbackPath = "/api/auth/v1/oidc/google/callback";
const issuer = "https://accounts.google.com";
const clientId = "test.apps.googleusercontent.com";
const key = "c".repeat(64);

// The production openid-client implementation and SQLite SQL both run here.
// Only Google HTTPS responses are fixtures; these tests are NOT hosted sign-in
// acceptance and do not send email or communicate with a Google account.
async function oidcHarness() {
  const base = await harness();
  base.db.now = Math.floor(Date.now() / 1000) * 1000;
  if (
    !(
      base.db.sqlite.prepare("PRAGMA table_info(accounts)").all() as {
        name: string;
      }[]
    ).some((column) => column.name === "email_ciphertext")
  ) {
    base.db.sqlite.exec(
      readFileSync(
        new URL(
          "../migrations-auth/0003_google_oidc_privacy.sql",
          import.meta.url,
        ),
        "utf8",
      ),
    );
  }
  const env: AccountBindings = {
    ...base.env,
    ACCOUNT_OIDC_ENABLED: "true",
    ACCOUNT_OTP_ENABLED: "false",
    GOOGLE_CLIENT_ID: clientId,
    GOOGLE_CLIENT_SECRET: "synthetic-client-secret",
    GOOGLE_REDIRECT_URI: `${origin}${callbackPath}`,
    ACCOUNT_OIDC_TRANSACTION_KEY: key,
    ACCOUNT_EMAIL_ENCRYPTION_KEY: "d".repeat(64),
    ACCOUNT_EMAIL_LOOKUP_KEY: "e".repeat(64),
    ACCOUNT_AUTH_LOCATOR_KEY: "f".repeat(64),
    ACCOUNT_EMAIL_KEY_VERSION: "v1",
  };
  const pair = await crypto.subtle.generateKey(
    {
      name: "RSASSA-PKCS1-v1_5",
      modulusLength: 2048,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: "SHA-256",
    },
    true,
    ["sign", "verify"],
  );
  const publicKey = await crypto.subtle.exportKey("jwk", pair.publicKey);
  let authorization: URL;
  let overrides: Record<string, unknown> = {};
  let damageSignature = false;
  let malformedResponse:
    | "oversized"
    | "redirect"
    | "failure"
    | "invalid_client"
    | "invalid_grant"
    | "untrusted-error"
    | undefined;
  let tokenRequests = 0;
  let jwksRequests = 0;
  let interruptToken: (() => Promise<void>) | undefined;
  const dependencies = {
    ...base.dependencies,
    fetch: async (
      input: RequestInfo | URL,
      init?: RequestInit,
    ): Promise<Response> => {
      const url = String(input);
      assert.equal(init?.redirect, "manual");
      if (url === "https://www.googleapis.com/oauth2/v3/certs") {
        jwksRequests++;
        return Response.json({
          keys: [
            { ...publicKey, kid: "fixture-key", alg: "RS256", use: "sig" },
          ],
        });
      }
      assert.equal(url, "https://oauth2.googleapis.com/token");
      tokenRequests++;
      const body = init?.body;
      assert.ok(body instanceof URLSearchParams);
      assert.equal(body.get("client_id"), clientId);
      assert.equal(body.get("client_secret"), env.GOOGLE_CLIENT_SECRET);
      assert.equal(body.get("redirect_uri"), env.GOOGLE_REDIRECT_URI);
      assert.equal(body.get("grant_type"), "authorization_code");
      assert.equal(body.get("code"), "fixture-code");
      const verifier = body.get("code_verifier");
      assert.ok(verifier);
      const challenge = Buffer.from(
        await crypto.subtle.digest(
          "SHA-256",
          new TextEncoder().encode(verifier),
        ),
      ).toString("base64url");
      assert.equal(challenge, authorization.searchParams.get("code_challenge"));
      if (interruptToken) await interruptToken();
      if (malformedResponse === "redirect")
        return new Response(null, {
          status: 302,
          headers: { Location: "https://attacker.invalid/" },
        });
      if (malformedResponse === "oversized")
        return new Response("x".repeat(33_000), {
          headers: { "Content-Type": "application/json" },
        });
      if (malformedResponse === "failure")
        throw new Error("synthetic-token-secret-that-must-not-leak");
      if (
        malformedResponse === "invalid_client" ||
        malformedResponse === "invalid_grant" ||
        malformedResponse === "untrusted-error"
      )
        return Response.json(
          {
            error:
              malformedResponse === "untrusted-error"
                ? "private@example.test/token-secret"
                : malformedResponse,
            error_description: "private@example.test synthetic-provider-secret",
          },
          { status: 400 },
        );
      const claims = {
        iss: issuer,
        sub: "fixture-subject",
        aud: clientId,
        iat: base.db.now / 1000,
        exp: base.db.now / 1000 + 3600,
        nonce: authorization.searchParams.get("nonce"),
        email: "accreatio.synthetic@gmail.com",
        email_verified: true,
        ...overrides,
      };
      const header = Buffer.from(
        JSON.stringify({ alg: "RS256", kid: "fixture-key" }),
      ).toString("base64url");
      const payload = Buffer.from(JSON.stringify(claims)).toString("base64url");
      const signed = `${header}.${payload}`;
      const signature = new Uint8Array(
        await crypto.subtle.sign(
          "RSASSA-PKCS1-v1_5",
          pair.privateKey,
          new TextEncoder().encode(signed),
        ),
      );
      if (damageSignature) signature[0] ^= 1;
      return Response.json({
        access_token: "synthetic-third-party-access-token",
        token_type: "Bearer",
        expires_in: 3600,
        id_token: `${signed}.${Buffer.from(signature).toString("base64url")}`,
      });
    },
  };
  async function call(
    action: OidcAction,
    options: {
      method?: string;
      path?: string;
      body?: unknown;
      cookie?: string;
      id?: string;
      requestOrigin?: string;
      config?: AccountBindings;
    } = {},
  ) {
    const method =
      options.method ??
      (action === "start" || action === "cancel" ? "POST" : "GET");
    return handleOidc(
      {
        request: new Request(
          `${origin}${options.path ?? `/api/auth/v1/${action}`}`,
          {
            method,
            headers: {
              Origin: options.requestOrigin ?? origin,
              "Content-Type": "application/json",
              "CF-Connecting-IP": "192.0.2.17",
              ...(options.cookie ? { Cookie: options.cookie } : {}),
            },
            ...(options.body !== undefined
              ? { body: JSON.stringify(options.body) }
              : {}),
          },
        ),
        env: options.config ?? env,
        params: options.id ? { id: options.id } : {},
      },
      action,
      dependencies,
    );
  }
  async function start(
    cookie?: string,
    mode: "popup" | "redirect" = "popup",
    purpose: "sign_in" | "account_access" = "sign_in",
    verificationAction: "data" | "delete" = "data",
  ) {
    const response = await call("start", {
      cookie,
      body: {
        purpose,
        returnRoute: "builder",
        mode,
        ...(purpose === "sign_in"
          ? { policyAuthorization: POLICY_AUTHORIZATION }
          : { verificationAction }),
      },
    });
    assert.equal(response.status, 200, await response.clone().text());
    const body = (await response.json()) as {
      transactionId: string;
      authorizationUrl: string;
      expiresAt: string;
    };
    authorization = new URL(body.authorizationUrl);
    const txCookie = response.headers.get("Set-Cookie")!.split(";")[0];
    return { ...body, cookie: txCookie, response, authorization };
  }
  function callback(cookie: string, additions = "") {
    const state = authorization.searchParams.get("state")!;
    return call("callback", {
      cookie,
      path: `${callbackPath}?code=fixture-code&iss=${encodeURIComponent(issuer)}&state=${state}${additions}`,
    });
  }
  const sessions = () =>
    base.db.sqlite.prepare("SELECT * FROM account_sessions").all();
  return {
    ...base,
    env,
    dependencies,
    call,
    start,
    callback,
    sessions,
    claims: (value: Record<string, unknown>) => {
      overrides = value;
    },
    badSignature: () => {
      damageSignature = true;
    },
    failProvider: (value: typeof malformedResponse) => {
      malformedResponse = value;
    },
    atToken: (value: () => Promise<void>) => {
      interruptToken = value;
    },
    counts: () => ({ tokenRequests, jwksRequests }),
  };
}

test("Google methods stay off without all keys or matching configured origin", async () => {
  const h = await oidcHarness();
  for (const config of [
    { ...h.env, ACCOUNT_OIDC_ENABLED: "false" },
    { ...h.env, ACCOUNT_EMAIL_ENCRYPTION_KEY: undefined },
    { ...h.env, GOOGLE_REDIRECT_URI: `https://other.example${callbackPath}` },
    { ...h.env, ACCOUNT_OIDC_TRANSACTION_KEY: h.env.ACCOUNT_IDENTITY_KEY },
  ]) {
    const response = await h.call("methods", { config });
    assert.deepEqual(await response.json(), {
      version: "auth.v1",
      methods: {
        google: { available: false },
        github: { available: false },
        emailOtp: { available: false },
      },
    });
  }
  assert.equal(
    (await (await h.call("methods")).json()).methods.google.available,
    true,
  );
});

test("OIDC rejects missing, false, stale and malformed policy choices before transaction creation or Google I/O", async () => {
  const h = await oidcHarness();
  for (const [policyAuthorization, status] of [
    [undefined, 400],
    [{ ...POLICY_AUTHORIZATION, accountDataAuthorized: false }, 403],
    [{ ...POLICY_AUTHORIZATION, termsAccepted: false }, 403],
    [{ ...POLICY_AUTHORIZATION, privacyNoticeVersion: "old" }, 409],
    [{ ...POLICY_AUTHORIZATION, termsVersion: "old" }, 409],
    [{ ...POLICY_AUTHORIZATION, purposeVersion: "old" }, 409],
    [{ ...POLICY_AUTHORIZATION, extra: true }, 400],
  ] as const) {
    const response = await h.call("start", {
      body: {
        purpose: "sign_in",
        returnRoute: "builder",
        mode: "popup",
        policyAuthorization,
      },
    });
    assert.equal(response.status, status);
  }
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_auth_transactions")
      .get()?.n,
    0,
  );
  assert.deepEqual(h.counts(), { tokenRequests: 0, jwksRequests: 0 });
});

test("rights-only reauthentication refreshes the existing browser without new policy, profile or account writes", async () => {
  const h = await oidcHarness();
  const initial = await h.start();
  const signed = await h.callback(initial.cookie);
  const oldCookie = signed.headers.get("Set-Cookie")!.split(";")[0];
  h.db.sqlite.exec("DELETE FROM account_policy_authorizations");
  const before = h.db.sqlite.prepare("SELECT * FROM accounts").get();
  h.db.now += 360_000;
  const access = await h.start(oldCookie, "popup", "account_access");
  const tx = h.db.sqlite
    .prepare(
      "SELECT account_id,access_security_version,policy_authorized_at FROM account_auth_transactions WHERE id=?",
    )
    .get(access.transactionId)!;
  assert.equal(tx.account_id, before?.id);
  assert.equal(tx.access_security_version, before?.security_version);
  assert.equal(tx.policy_authorized_at, null);
  h.claims({ name: "Must not overwrite profile", email: "changed@gmail.com" });
  const renewed = await h.callback(access.cookie);
  assert.equal(renewed.status, 303);
  assert.match(renewed.headers.get("Location")!, /auth=success$/);
  const freshCookie = renewed.headers.get("Set-Cookie")!.split(";")[0];
  assert.notEqual(freshCookie, oldCookie);
  assert.deepEqual(h.db.sqlite.prepare("SELECT * FROM accounts").get(), before);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
      .get()?.n,
    0,
  );
  assert.equal(h.sessions().length, 1);
  const accountCall = (
    action: "session" | "data" | "delete" | "authorize",
    cookie: string,
    method = "GET",
    body?: unknown,
  ) =>
    handleAccount(
      {
        request: new Request(`${origin}/api/account/${action}`, {
          method,
          headers: {
            Cookie: cookie,
            Origin: origin,
            "Content-Type": "application/json",
          },
          ...(body ? { body: JSON.stringify(body) } : {}),
        }),
        env: h.env,
      },
      action,
      h.dependencies,
    );
  assert.equal((await accountCall("session", oldCookie)).status, 401);
  assert.equal(
    (await (await accountCall("session", freshCookie)).json())
      .policyAuthorizationRequired,
    true,
  );
  const data = await accountCall("data", freshCookie);
  assert.equal(data.status, 200);
  assert.equal((await data.json()).policyAuthorization, null);
  const exportContext = await (
    await accountCall("session", freshCookie)
  ).json();
  assert.equal(
    (
      await accountCall("authorize", freshCookie, "POST", {
        operationId: crypto.randomUUID(),
        ownerKey: exportContext.ownerKey,
        sessionKey: exportContext.sessionKey,
      })
    ).status,
    403,
  );
  assert.equal((await accountCall("delete", freshCookie, "POST")).status, 401);
  const deletion = await h.start(
    freshCookie,
    "popup",
    "account_access",
    "delete",
  );
  const deletionProof = await h.callback(deletion.cookie);
  assert.equal(
    (
      await accountCall(
        "delete",
        deletionProof.headers.get("Set-Cookie")!.split(";")[0],
        "POST",
      )
    ).status,
    200,
  );
});

test("rights-only start requires an active existing browser and rejects policy-bearing or cross-origin requests", async () => {
  const h = await oidcHarness();
  const body = {
    purpose: "account_access",
    verificationAction: "data",
    returnRoute: "builder",
    mode: "popup",
  };
  assert.equal((await h.call("start", { body })).status, 401);
  assert.equal(
    (
      await h.call("start", {
        body,
        cookie: `__Host-accreatio_session=${"0".repeat(64)}`,
      })
    ).status,
    401,
  );
  assert.equal(
    (
      await h.call("start", {
        body: { ...body, policyAuthorization: POLICY_AUTHORIZATION },
      })
    ).status,
    400,
  );
  assert.equal(
    (await h.call("start", { body, requestOrigin: "https://other.test" }))
      .status,
    403,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_auth_transactions")
      .get()?.n,
    0,
  );
  assert.deepEqual(h.counts(), { tokenRequests: 0, jwksRequests: 0 });
});

test("Google login and policy receipt roll back together if the receipt cannot be written", async () => {
  const h = await oidcHarness();
  const started = await h.start();
  h.db.sqlite.exec(
    "CREATE TRIGGER policy_failure BEFORE INSERT ON account_policy_authorizations BEGIN SELECT RAISE(ABORT,'fixture failure'); END",
  );
  const response = await h.callback(started.cookie);
  assert.match(response.headers.get("Location")!, /auth=failure$/);
  assert.equal(response.headers.get("Set-Cookie"), null);
  assert.equal(h.sessions().length, 0);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()?.n,
    0,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
      .get()?.n,
    0,
  );
  const tx = h.db.sqlite
    .prepare(
      "SELECT status,policy_authorized_at,secrets_ciphertext FROM account_auth_transactions WHERE id=?",
    )
    .get(started.transactionId)!;
  assert.equal(tx.status, "failed");
  assert.equal(tx.policy_authorized_at, null);
  assert.equal(tx.secrets_ciphertext, null);
});

test("concurrent rights callbacks issue one new session, without manufacturing policy acceptance", async () => {
  const h = await oidcHarness();
  const first = await h.start();
  const signed = await h.callback(first.cookie);
  h.db.sqlite.exec("DELETE FROM account_policy_authorizations");
  const access = await h.start(
    signed.headers.get("Set-Cookie")!.split(";")[0],
    "popup",
    "account_access",
  );
  const responses = await Promise.all([
    h.callback(access.cookie),
    h.callback(access.cookie),
  ]);
  assert.equal(
    responses.filter((response) =>
      /auth=success$/.test(response.headers.get("Location")!),
    ).length,
    1,
  );
  assert.equal(h.counts().tokenRequests, 2);
  assert.equal(h.sessions().length, 1);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
      .get()?.n,
    0,
  );
});

test("rights-only transaction failure preserves the prior browser session and account records", async () => {
  const h = await oidcHarness();
  const first = await h.start();
  const signed = await h.callback(first.cookie);
  const before = h.sessions();
  h.db.sqlite.exec("DELETE FROM account_policy_authorizations");
  const access = await h.start(
    signed.headers.get("Set-Cookie")!.split(";")[0],
    "popup",
    "account_access",
  );
  h.db.sqlite.exec(
    "CREATE TRIGGER rights_failure BEFORE UPDATE OF status ON account_auth_transactions WHEN NEW.purpose='account_access' AND NEW.status='completed' BEGIN SELECT RAISE(ABORT,'fixture failure'); END",
  );
  const response = await h.callback(access.cookie);
  assert.match(response.headers.get("Location")!, /auth=failure$/);
  assert.deepEqual(h.sessions(), before);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
      .get()?.n,
    0,
  );
});

for (const failure of [
  "wrong_identity",
  "revoked",
  "deleted",
  "expired",
  "changed_version",
] as const) {
  test(`rights-only callback refuses ${failure} without resurrecting or authorizing an account`, async () => {
    const h = await oidcHarness();
    const first = await h.start();
    const signed = await h.callback(first.cookie);
    const cookie = signed.headers.get("Set-Cookie")!.split(";")[0];
    h.db.sqlite.exec("DELETE FROM account_policy_authorizations");
    const access = await h.start(cookie, "popup", "account_access");
    if (failure === "wrong_identity")
      h.claims({ sub: "different-provider-subject" });
    h.atToken(async () => {
      if (failure === "revoked")
        h.db.sqlite.exec("DELETE FROM account_sessions");
      if (failure === "deleted")
        h.db.sqlite.exec("UPDATE accounts SET deleted_at=unixepoch()*1000");
      if (failure === "expired")
        h.db.sqlite.exec(
          "UPDATE account_sessions SET expires_at=unixepoch()*1000",
        );
      if (failure === "changed_version")
        h.db.sqlite.exec(
          "UPDATE accounts SET security_version=security_version+1",
        );
    });
    const response = await h.callback(access.cookie);
    assert.match(response.headers.get("Location")!, /auth=failure$/);
    assert.equal(response.headers.get("Set-Cookie"), null);
    assert.equal(
      h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()?.n,
      1,
    );
    assert.equal(
      h.db.sqlite
        .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
        .get()?.n,
      0,
    );
  });
}

test("OIDC starts with minimal scopes, bound encrypted transaction and separate Lax cookie", async () => {
  const h = await oidcHarness();
  const started = await h.start();
  assert.equal(started.authorization.origin, issuer);
  assert.equal(
    started.authorization.searchParams.get("scope"),
    "openid email profile",
  );
  assert.equal(
    started.authorization.searchParams.get("code_challenge_method"),
    "S256",
  );
  assert.equal(started.authorization.searchParams.get("response_type"), "code");
  assert.equal(started.authorization.searchParams.has("access_type"), false);
  assert.match(
    started.response.headers.get("Set-Cookie")!,
    /Secure; HttpOnly; SameSite=Lax/,
  );
  const saved = JSON.stringify(
    h.db.sqlite.prepare("SELECT * FROM account_auth_transactions").all(),
  );
  assert.ok(!saved.includes(started.authorization.searchParams.get("nonce")!));
  assert.ok(!saved.includes(started.authorization.searchParams.get("state")!));
  assert.ok(!saved.includes(started.cookie.split("=")[1]));
});

test("OIDC rejects cross-origin starts, linking and caller-controlled redirect", async () => {
  const h = await oidcHarness();
  const body = {
    purpose: "sign_in",
    returnRoute: "builder",
    mode: "popup",
    policyAuthorization: POLICY_AUTHORIZATION,
  };
  assert.equal(
    (await h.call("start", { body, requestOrigin: "https://attacker.invalid" }))
      .status,
    403,
  );
  assert.equal(
    (await h.call("start", { body: { ...body, purpose: "link" } })).status,
    400,
  );
  assert.equal(
    (
      await h.call("start", {
        body: { ...body, redirectUri: "https://attacker.invalid" },
      })
    ).status,
    400,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS total FROM account_auth_transactions")
      .get()?.total,
    0,
  );
});

test("real library validates signed Google response and issues only own Strict session", async () => {
  const h = await oidcHarness();
  const started = await h.start();
  const response = await h.callback(started.cookie);
  assert.equal(response.status, 303);
  assert.equal(
    response.headers.get("Location"),
    `${origin}/api/auth/v1/complete?auth=success`,
  );
  assert.match(
    response.headers.get("Set-Cookie")!,
    /^__Host-accreatio_session=[a-f0-9]{64}; Path=\/; Secure; HttpOnly; SameSite=Strict/,
  );
  assert.equal(h.sessions().length, 1);
  assert.equal(
    h.counts().jwksRequests,
    1,
    "signature verification must retrieve JWKS",
  );
  assert.deepEqual(
    await (
      await h.call("status", {
        cookie: started.cookie,
        id: started.transactionId,
      })
    ).json(),
    { status: "completed" },
  );
  const tx = h.db.sqlite
    .prepare(
      "SELECT secrets_ciphertext FROM account_auth_transactions WHERE id=?",
    )
    .get(started.transactionId);
  assert.equal(tx?.secrets_ciphertext, null);
  const database = JSON.stringify([
    h.db.sqlite.prepare("SELECT * FROM accounts").all(),
    h.sessions(),
    h.db.sqlite.prepare("SELECT * FROM account_external_identities").all(),
  ]);
  assert.ok(!database.includes("synthetic-third-party-access-token"));
  assert.ok(!database.includes("accreatio.synthetic@gmail.com"));
  assert.ok(
    !database.includes(
      response.headers.get("Set-Cookie")!.split(";")[0].split("=")[1],
    ),
  );
});

for (const [label, claims] of [
  ["wrong issuer", { iss: "https://attacker.invalid" }],
  ["wrong audience", { aud: "other.apps.googleusercontent.com" }],
  ["wrong authorized party", { azp: "other.apps.googleusercontent.com" }],
  ["wrong nonce", { nonce: "attacker-nonce" }],
  ["expired token", { exp: 100 }],
  ["future issued-at", { iat: Math.floor(Date.now() / 1000) + 3600 }],
  ["unverified email for new account", { email_verified: false }],
  [
    "external email for new account",
    { email: "owner@example.test", email_verified: true },
  ],
] as const) {
  test(`OIDC rejects ${label} without a session or account`, async () => {
    const h = await oidcHarness();
    const started = await h.start();
    h.claims(claims);
    const response = await h.callback(started.cookie);
    assert.equal(response.headers.get("Set-Cookie"), null);
    assert.match(response.headers.get("Location")!, /auth=failure$/);
    assert.equal(h.sessions().length, 0);
    assert.equal(
      h.db.sqlite.prepare("SELECT COUNT(*) AS total FROM accounts").get()
        ?.total,
      0,
    );
    assert.equal(
      (
        await (
          await h.call("status", {
            id: started.transactionId,
            cookie: started.cookie,
          })
        ).json()
      ).status,
      "failed",
    );
  });
}

test("invalid JWS signature is rejected even from the configured token endpoint", async () => {
  const h = await oidcHarness();
  const started = await h.start();
  h.badSignature();
  const response = await h.callback(started.cookie);
  assert.equal(response.headers.get("Set-Cookie"), null);
  assert.equal(h.sessions().length, 0);
  assert.equal(h.counts().jwksRequests, 1);
});

test("callback replay and concurrent callbacks perform exactly one token exchange", async () => {
  const h = await oidcHarness();
  const started = await h.start();
  const responses = await Promise.all([
    h.callback(started.cookie),
    h.callback(started.cookie),
  ]);
  assert.equal(
    responses.filter((response) => response.headers.has("Set-Cookie")).length,
    1,
  );
  assert.equal(h.counts().tokenRequests, 1);
  assert.equal(h.sessions().length, 1);
});

test("callback requires browser binding and rejects duplicate state without exchange", async () => {
  const h = await oidcHarness();
  const started = await h.start();
  await h.callback("__Host-accreatio_auth_tx=" + "9".repeat(64));
  await h.callback(started.cookie, "&state=duplicate");
  await h.callback(`${started.cookie}; ${started.cookie}`);
  assert.equal(h.counts().tokenRequests, 0);
  assert.equal(h.sessions().length, 0);
  assert.equal(
    (
      await h.call("status", {
        cookie: "__Host-accreatio_auth_tx=" + "8".repeat(64),
        id: started.transactionId,
      })
    ).status,
    404,
  );
});

test("cancel racing a token exchange prevents late cookie issuance", async () => {
  const h = await oidcHarness();
  const started = await h.start();
  h.atToken(async () => {
    const cancelled = await h.call("cancel", {
      cookie: started.cookie,
      id: started.transactionId,
    });
    assert.deepEqual(await cancelled.json(), { status: "failed" });
  });
  const response = await h.callback(started.cookie);
  assert.equal(response.headers.get("Set-Cookie"), null);
  assert.equal(h.sessions().length, 0);
});

for (const failure of ["oversized", "redirect", "failure"] as const) {
  test(`provider ${failure} fails closed and clears transaction secrets`, async () => {
    const h = await oidcHarness();
    const started = await h.start();
    h.failProvider(failure);
    const response = await h.callback(started.cookie);
    assert.equal(response.headers.get("Set-Cookie"), null);
    assert.equal(h.sessions().length, 0);
    assert.ok(!(await response.text()).includes("synthetic-token-secret"));
    assert.equal(
      h.db.sqlite
        .prepare(
          "SELECT secrets_ciphertext FROM account_auth_transactions WHERE id=?",
        )
        .get(started.transactionId)?.secrets_ciphertext,
      null,
    );
  });
}

test("transaction AES-GCM binds account-independent transaction id and rejects key/tag changes", async () => {
  const value = {
    nonce: "n".repeat(43),
    verifier: "v".repeat(43),
    state: "s".repeat(43),
    redirectUri: `${origin}${callbackPath}`,
  };
  const envelope = await sealOidcSecrets("transaction-a", value, key);
  assert.deepEqual(
    await openOidcSecrets("transaction-a", envelope, key),
    value,
  );
  await assert.rejects(openOidcSecrets("transaction-b", envelope, key));
  await assert.rejects(
    openOidcSecrets("transaction-a", envelope, "9".repeat(64)),
  );
  const altered =
    envelope.slice(0, -2) + (envelope.endsWith("00") ? "ff" : "00");
  await assert.rejects(openOidcSecrets("transaction-a", altered, key));
});

test("linked-identity profile remains usable without a current email or Google MFA claims", () => {
  const now = Math.floor(Date.now() / 1000);
  const identity = googleIdentity({
    iss: issuer,
    sub: "stable",
    aud: clientId,
    iat: now,
    exp: now + 3600,
  });
  assert.equal(identity.subject, "stable");
  assert.equal(identity.email, null);
  assert.equal(identity.authoritativeEmail, false);
  assert.equal("amr" in identity, false);
});

test("callback diagnostics contain only fixed codes and distinguish provider exchange, validation and admission", async (context) => {
  const output: unknown[][] = [];
  context.mock.method(console, "warn", (...args: unknown[]) => {
    output.push(args);
  });
  for (const scenario of [
    "configuration",
    "callback_binding",
    "transaction_decrypt",
    "authorization_response",
    "provider_invalid_client",
    "provider_invalid_grant",
    "token_exchange",
    "untrusted-error",
    "token_validation",
    "bad_signature",
    "account_admission",
  ] as const) {
    const h = await oidcHarness();
    const started = await h.start();
    if (scenario === "configuration") h.env.ACCOUNT_OIDC_ENABLED = "false";
    if (scenario === "transaction_decrypt")
      h.db.sqlite
        .prepare(
          "UPDATE account_auth_transactions SET secrets_ciphertext=? WHERE id=?",
        )
        .run("private@example.test synthetic-secret", started.transactionId);
    if (scenario === "provider_invalid_client")
      h.failProvider("invalid_client");
    if (scenario === "provider_invalid_grant") h.failProvider("invalid_grant");
    if (scenario === "token_exchange") h.failProvider("failure");
    if (scenario === "untrusted-error") h.failProvider("untrusted-error");
    if (scenario === "token_validation")
      h.claims({ nonce: "private@example.test synthetic-token" });
    if (scenario === "bad_signature") h.badSignature();
    if (scenario === "account_admission") h.claims({ email_verified: false });
    const response =
      scenario === "authorization_response"
        ? await h.call("callback", {
            cookie: started.cookie,
            path: `${callbackPath}?state=${started.authorization.searchParams.get("state")}&iss=${encodeURIComponent(issuer)}&error=access_denied&error_description=private%40example.test`,
          })
        : await h.callback(
            scenario === "callback_binding" ? "" : started.cookie,
          );
    const expected =
      scenario === "untrusted-error"
        ? "token_exchange"
        : scenario === "bad_signature"
          ? "token_validation"
          : scenario === "authorization_response"
            ? "provider_authorization_rejected"
            : scenario;
    assert.deepEqual(
      output.splice(0),
      [[JSON.stringify({ event: "oidc_callback_failed", code: expected })]],
      scenario,
    );
    assert.equal(response.status, 303);
    assert.match(response.headers.get("Location")!, /auth=failure$/);
    assert.equal(response.headers.get("Set-Cookie"), null);
    assert.equal(h.sessions().length, 0);
  }
  const h = await oidcHarness();
  const started = await h.start();
  assert.match(
    (await h.callback(started.cookie)).headers.get("Location")!,
    /auth=success$/,
  );
  assert.deepEqual(output, []);
});
