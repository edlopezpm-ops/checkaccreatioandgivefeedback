import assert from "node:assert/strict";
import test from "node:test";
import path from "node:path";
import { readFileSync } from "node:fs";
import {
  FORBIDDEN_EXPORT_EXTENSIONS,
  buildExportManifest,
  exportManifestPaths,
  getStartingInstruction,
  ORCHESTRATION_CONFIG_PATH,
} from "../shared/exportManifest";
import { AEKR_REVISION } from "../shared/aekrPayload.generated";
import { defaultOrchestration } from "../shared/domain";
import type { ProjectDefinition, Settings } from "../shared/domain";

const project = (over: Partial<ProjectDefinition> = {}): ProjectDefinition => ({
  name: "Warehouse Copilot",
  phase: "discovery-active",
  context: "Replace manual cycle-count re-entry.",
  restrictions: "No vendor integration budget.",
  route: "local",
  action: "repository",
  destination: "C:\\projects",
  participants: [{ id: "participant-01", role: "generalist", label: "design" }],
  attachments: [],
  initializeGit: true,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: false,
  orchestration: defaultOrchestration(),
  ...over,
});
const settings = (locale: "en" | "es" = "en"): Settings => ({
  baseFolder: "C:\\projects",
  toolkitPath: "",
  futureProjectsPath: "",
  defaultBranch: "main",
  preferredIde: "VS Code",
  theme: "dark",
  locale,
  confirmBeforeRun: true,
});
const options = {
  createdBy: "test",
  appVersion: "0.0.0-test",
  createdAt: "2026-10-21T00:00:00.000Z",
};
const advanced = () =>
  project({ orchestration: { ...defaultOrchestration(), enabled: true } });
const read = (files: ReturnType<typeof buildExportManifest>, name: string) => {
  const file = files.find((f) => f.path === name);
  assert.ok(file, `missing ${name}`);
  return file.content;
};

for (const locale of ["es", "en"] as const)
  for (const enabled of [false, true]) {
    test(`${locale}, orchestration=${enabled}: all mandatory paths and local Markdown links resolve`, () => {
      const files = buildExportManifest(
        enabled ? advanced() : project(),
        settings(locale),
        options,
      );
      const paths = new Set(files.map((f) => f.path));
      assert.equal(paths.size, files.length, "duplicate archive path");
      for (const file of files) {
        assert.ok(file.content.length > 0);
        assert.ok(
          !path.posix.isAbsolute(file.path) &&
            !file.path.includes("..") &&
            !file.path.includes("\\"),
          file.path,
        );
        assert.ok(
          !FORBIDDEN_EXPORT_EXTENSIONS.some((ext) => file.path.endsWith(ext)),
          file.path,
        );
        if (!file.path.endsWith(".md")) continue;
        for (const link of file.content.matchAll(/\]\(([^)]+)\)/g)) {
          const target = link[1].split("#")[0];
          if (/^https?:/.test(target) || !target) continue;
          const resolved = path.posix.normalize(
            path.posix.join(path.posix.dirname(file.path), target),
          );
          assert.ok(paths.has(resolved), `${file.path}: unresolved ${target}`);
        }
      }
      const contract = JSON.parse(read(files, ".accreatio/contract.json"));
      for (const required of contract.requiredPaths)
        assert.ok(paths.has(required), required);
      assert.equal(contract.canonicalInstructions, "AGENTS.md");
      assert.equal(contract.orchestration.runtimeIncluded, false);
      assert.equal(
        contract.orchestration.configPath,
        enabled ? ORCHESTRATION_CONFIG_PATH : null,
      );
      assert.ok(
        read(files, "START.md").includes(getStartingInstruction(locale)),
      );
      assert.match(
        read(files, "docs/master.md"),
        /^Status: DISCOVERY_IN_PROGRESS$/m,
      );
      assert.match(
        read(files, "docs/master.md"),
        /^governance-profile: Lean$/m,
      );
      assert.ok(!read(files, "docs/master.md").includes("[YYYY-MM-DD]"));
    });
  }

test("basic package starts with project context and imposes no runtime setup", () => {
  const files = buildExportManifest(project(), settings(), options);
  assert.ok(
    !files.some(
      (f) =>
        f.path.startsWith("orchestrator/") ||
        f.path.includes("orchestration.yaml") ||
        f.path.endsWith("orchestration-loop.md"),
    ),
  );
  assert.match(
    read(files, "START.md"),
    /do not need to install or build an orchestrator/,
  );
  assert.match(read(files, "AGENTS.md"), /Orchestration is \*\*disabled\*\*/);
  const prompt = read(files, "PROJECT_PROMPT.md");
  assert.ok(prompt.includes(project().context));
  assert.ok(prompt.includes(project().restrictions));
  assert.doesNotMatch(prompt, /toolkit\/MASTER_SOP|project-lifecycle\/SOP/);
  assert.match(read(files, "docs/product/discovery.md"), /PROJECT_PROMPT.md/);
  assert.ok(
    !read(files, "docs/product/discovery.md").includes(project().context),
  );
});

test("advanced package uses one config and includes all setup dependencies", () => {
  const files = buildExportManifest(advanced(), settings(), options);
  const config = read(files, ORCHESTRATION_CONFIG_PATH);
  assert.match(config, /project_name: warehouse-copilot/);
  assert.doesNotMatch(
    config,
    /checkout|toolkit\/orchestrator|orchestrator.config.yaml/,
  );
  for (const name of [
    "BUILD_ORCHESTRATOR",
    "CONFIGURATION",
    "GATES",
    "RUNTIME_CONTRACT",
  ])
    assert.ok(read(files, `orchestrator/${name}.md`).length > 100);
  assert.match(read(files, "orchestrator/BUILD_ORCHESTRATOR.md"), /Python 3/);
  assert.match(
    read(files, "orchestrator/BUILD_ORCHESTRATOR.md"),
    /not inherently safe/,
  );
  assert.match(read(files, "orchestrator/GATES.md"), /HUMAN_ONLY/);
  assert.match(
    read(files, "orchestrator/RUNTIME_CONTRACT.md"),
    /Never pass user-authored text to a shell/i,
  );
});

test("AGENTS is canonical; adapters do not duplicate policy or imply universal CODEX loading", () => {
  const files = buildExportManifest(project(), settings(), options);
  const agents = read(files, "AGENTS.md");
  assert.ok(agents.length > 1000);
  for (const name of ["CLAUDE.md", "CODEX.md"]) {
    const adapter = read(files, name);
    assert.ok(adapter.length < 400);
    assert.match(adapter, /AGENTS.md/);
    assert.notEqual(adapter, agents);
  }
  assert.match(read(files, "CODEX.md"), /Automatic loading .* is not assumed/);
  assert.deepEqual(JSON.parse(read(files, ".claude/settings.json")), {
    attribution: { commit: "", pr: "" },
  });
});

test("template license and pinned provenance are retained without granting application rights", () => {
  const files = buildExportManifest(project(), settings(), options);
  assert.equal(
    read(files, "LICENSES/AEKR-TEMPLATES.txt").trim(),
    readFileSync("assets/AEKR-BANNER-LICENSE.txt", "utf8")
      .replace(/\r\n/g, "\n")
      .trim(),
  );
  const signature = JSON.parse(read(files, ".accreatio/project.json"));
  assert.equal(signature.aekrRevision, AEKR_REVISION);
  assert.equal(signature.phase, "discovery-active");
  assert.equal(signature.governanceProfile, "Lean");
  assert.equal(signature.orchestrationEnabled, false);
  assert.match(
    read(files, "EXPORT_NOTICE.md"),
    /grants no new rights to accreatio application code/,
  );
});

test("all phases get a meaningful state and an appropriate first action without fabricated approval", () => {
  for (const phase of [
    "idea",
    "discovery-active",
    "discovery-complete",
  ] as const) {
    const files = buildExportManifest(project({ phase }), settings(), options);
    assert.match(
      read(files, "docs/master.md"),
      new RegExp(`^phase: ${phase}$`, "m"),
    );
    assert.match(read(files, "docs/master.md"), /no approvals/);
    assert.doesNotMatch(
      read(files, "docs/master.md"),
      /BUILD_IN_PROGRESS|DESIGN_COMPLETE/,
    );
  }
});

test("paths preview matches the exact generated contract", () => {
  assert.deepEqual(
    exportManifestPaths(project(), settings()),
    buildExportManifest(project(), settings(), options).map((f) => f.path),
  );
});
