import assert from "node:assert/strict";
import test from "node:test";
import {
  AccountError,
  authorizeWebExport,
  deleteWebRightsAccount,
  loadWebRightsData,
  startProviderSignIn,
} from "../src/account/webClient";

test("an ordinary export suspension locks its product session while a rights-only denial does not", async (t) => {
  const original = Object.getOwnPropertyDescriptor(globalThis, "window");
  Object.defineProperty(globalThis, "window", {
    configurable: true,
    value: new EventTarget(),
  });
  t.after(() => {
    if (original) Object.defineProperty(globalThis, "window", original);
    else Reflect.deleteProperty(globalThis, "window");
  });
  let invalidations = 0;
  window.addEventListener("accreatio:session-invalid", () => invalidations++);
  t.mock.method(globalThis, "fetch", async () =>
    Response.json(
      { error: { code: "account_suspended", message: "Service suspended." } },
      { status: 429 },
    ),
  );
  await assert.rejects(
    authorizeWebExport(crypto.randomUUID(), {
      ownerKey: `v1:${"a".repeat(64)}`,
      sessionKey: `v1:${"b".repeat(64)}`,
    }),
    (error: unknown) =>
      error instanceof AccountError && error.code === "account_suspended",
  );
  assert.equal(invalidations, 1);
  await assert.rejects(
    loadWebRightsData(crypto.randomUUID()),
    (error: unknown) =>
      error instanceof AccountError && error.code === "account_suspended",
  );
  assert.equal(invalidations, 1);
});

test("rights-only browser proof uses its dedicated start route without policy or ordinary admission", async (t) => {
  const requests: { path: string; options: RequestInit | undefined }[] = [];
  t.mock.method(globalThis, "fetch", async (path, options) => {
    requests.push({ path: String(path), options });
    return Response.json({
      transactionId: "opaque-rights-transaction-012345",
      authorizationUrl:
        "https://accounts.google.com/o/oauth2/v2/auth?state=opaque",
      expiresAt: "2026-10-22T13:00:00.000Z",
    });
  });
  await startProviderSignIn("google", "popup", {
    purpose: "account_access",
    rightsOnly: true,
    verificationAction: "data",
  });
  assert.equal(requests[0].path, "/api/auth/v1/rights/google/start");
  assert.deepEqual(JSON.parse(String(requests[0].options?.body)), {
    purpose: "account_access",
    returnRoute: "builder",
    mode: "popup",
    rightsOnly: true,
    verificationAction: "data",
  });
  for (const options of [
    { purpose: "sign_in", rightsOnly: true, verificationAction: "data" },
    {
      purpose: "account_access",
      rightsOnly: true,
      verificationAction: "link_google",
    },
  ] as const)
    await assert.rejects(
      startProviderSignIn("google", "popup", options),
      (error: unknown) =>
        error instanceof AccountError &&
        error.code === "rights_action_required",
    );
  assert.equal(requests.length, 1);
});

test("rights data/deletion send only the dedicated proof header and never request a product session", async (t) => {
  const transactionId = crypto.randomUUID();
  const requests: { path: string; options: RequestInit | undefined }[] = [];
  t.mock.method(globalThis, "fetch", async (path, options) => {
    requests.push({ path: String(path), options });
    return Response.json({ ok: true, account: { id: "own-account" } });
  });
  const data = await loadWebRightsData(transactionId);
  assert.deepEqual(data.account, { id: "own-account" });
  await deleteWebRightsAccount(transactionId);
  assert.deepEqual(
    requests.map((request) => request.path),
    ["/api/account/data", "/api/account/delete"],
  );
  assert.equal(requests[0].options?.method, "GET");
  assert.equal(requests[1].options?.method, "POST");
  for (const request of requests) {
    assert.equal(
      new Headers(request.options?.headers).get("X-Accreatio-Rights"),
      "1",
    );
    assert.equal(
      new Headers(request.options?.headers).get(
        "X-Accreatio-Rights-Transaction",
      ),
      transactionId,
    );
    assert.equal(request.options?.credentials, "same-origin");
    assert.equal(request.options?.redirect, "manual");
    assert.equal(request.options?.body, undefined);
  }
  await assert.rejects(
    loadWebRightsData("unknown"),
    (error: unknown) =>
      error instanceof AccountError && error.code === "rights_context_changed",
  );
  assert.equal(requests.length, 2);
});

test("rights errors use Retry-After metadata without invalidating an unrelated product session", async (t) => {
  const transactionId = crypto.randomUUID();
  t.mock.method(globalThis, "fetch", async () =>
    Response.json(
      { error: { code: "request_rate_limited", message: "Try later." } },
      { status: 429, headers: { "Retry-After": "37" } },
    ),
  );
  await assert.rejects(
    loadWebRightsData(transactionId),
    (error: unknown) =>
      error instanceof AccountError &&
      error.code === "request_rate_limited" &&
      error.retryAfter === 37,
  );
  t.mock.method(globalThis, "fetch", async () =>
    Response.json(
      {
        error: { code: "reauthentication_required", message: "Verify again." },
      },
      { status: 401 },
    ),
  );
  // No window shim is installed: dispatching a product-session event would fail.
  await assert.rejects(
    loadWebRightsData(transactionId),
    (error: unknown) =>
      error instanceof AccountError &&
      error.code === "reauthentication_required",
  );
});
