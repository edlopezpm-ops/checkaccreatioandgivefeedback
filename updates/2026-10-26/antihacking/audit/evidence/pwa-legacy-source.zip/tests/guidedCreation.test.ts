import test from "node:test";
import assert from "node:assert/strict";
import React, { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import {
  GuidedBasics,
  GuidedCreation,
} from "../src/components/creation/GuidedCreation";
import { SummaryDrawer } from "../src/components/creation/SummaryDrawer";
import { TeamStage } from "../src/components/creation/TeamStage";
import {
  canMoveToQuestion,
  guidedQuestions,
  questionInvalid,
  questionStage,
  stageQuestion,
} from "../src/components/creation/guidedFlow";
import { validateProject } from "../src/core";
import {
  defaultOrchestration,
  type ProjectDefinition,
  type Settings,
} from "../src/types";

// Match the existing server-render harness for components using Vite's JSX transform.
Object.assign(globalThis, { React });

const project: ProjectDefinition = {
  name: "Orchard",
  phase: "idea",
  context: "Help neighbors grow food.",
  restrictions: "",
  route: "local",
  action: "repository",
  destination: "browser-download",
  participants: [
    { id: "participant-01", role: "generalist", label: "Plan and build" },
  ],
  attachments: [],
  initializeGit: false,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: true,
  orchestration: defaultOrchestration(),
};
const settings: Settings = {
  baseFolder: "",
  toolkitPath: "",
  futureProjectsPath: "",
  defaultBranch: "main",
  preferredIde: "VS Code",
  confirmBeforeRun: true,
  theme: "dark",
  locale: "en",
};

test("an idea omits attachments, while both discovery paths offer optional files before context", () => {
  assert.deepEqual(guidedQuestions("idea"), [
    "name",
    "phase",
    "context",
    "restrictions",
    "route",
    "team",
    "delivery",
    "review",
  ]);
  for (const phase of ["discovery-active", "discovery-complete"] as const) {
    const questions = guidedQuestions(phase);
    assert.equal(questions[questions.indexOf("phase") + 1], "attachments");
    assert.equal(questions[questions.indexOf("attachments") + 1], "context");
    assert.equal(questions.at(-1), "review");
  }
});

test("unanswered future questions never prevent a valid current answer or backwards navigation", () => {
  const errors = validateProject(
    { ...project, context: "", destination: "" },
    settings,
  );
  assert.equal(canMoveToQuestion("name", "phase", errors), true);
  assert.equal(canMoveToQuestion("context", "restrictions", errors), false);
  assert.equal(canMoveToQuestion("context", "phase", errors), true);
  assert.equal(canMoveToQuestion("delivery", "team", errors), true);
  assert.equal(canMoveToQuestion("delivery", "review", errors), false);
});

test("all protected team and delivery errors block forward motion and allow corrections", () => {
  for (const field of ["participants", "orchestration", "funding"]) {
    assert.equal(
      canMoveToQuestion("team", "delivery", { [field]: "invalid" }),
      false,
    );
    assert.equal(
      canMoveToQuestion("team", "route", { [field]: "invalid" }),
      true,
    );
  }
  for (const field of ["destination", "tracking", "openIde", "createRemote"]) {
    assert.equal(
      canMoveToQuestion("delivery", "review", { [field]: "invalid" }),
      false,
    );
  }
  assert.equal(questionInvalid("name", { name: "invalid" }), true);
  assert.equal(
    questionInvalid("attachments", { attachments: "invalid" }),
    true,
  );
});

test("review edit links return to the correct question without rewriting project values", () => {
  const saved = structuredClone(project);
  for (const stage of ["foundation", "context", "team", "delivery"] as const) {
    assert.equal(questionStage(stageQuestion(stage)), stage);
    assert.equal(
      canMoveToQuestion("review", stageQuestion(stage), { name: "required" }),
      true,
    );
  }
  assert.deepEqual(project, saved);
});

test("each basic interaction has one title and exposes only its relevant input in both languages", () => {
  for (const locale of ["es", "en"] as const) {
    for (const current of [
      "name",
      "phase",
      "context",
      "restrictions",
      "route",
    ] as const) {
      const html = renderToStaticMarkup(
        createElement(GuidedBasics, {
          current,
          locale,
          project,
          errors: {},
          errorText: () => undefined,
          onChange: () => {},
          onMove: () => {},
          onPhaseChange: () => true,
        }),
      );
      assert.equal((html.match(/<h1\b/g) ?? []).length, 1);
      if (current === "phase" || current === "route") {
        assert.equal((html.match(/type="button"/g) ?? []).length, 3);
        assert.equal((html.match(/aria-pressed="true"/g) ?? []).length, 1);
        assert.doesNotMatch(html, /<(?:input|textarea)/);
      } else {
        assert.equal((html.match(/<(?:input|textarea)\b/g) ?? []).length, 1);
        assert.match(html, new RegExp(`id="project-${current}"`));
      }
    }
  }
});

test("guided frame has accurate branch progress, explicit optional skip, and editable review return", () => {
  const html = renderToStaticMarkup(
    createElement(GuidedCreation, {
      current: "restrictions",
      locale: "en",
      project,
      feedback: null,
      hasReviewed: true,
      onMove: () => {},
      toolbar: null,
      children: createElement("h1", null, "Boundaries"),
    }),
  );
  assert.match(html, /<main\b/);
  assert.match(html, /aria-valuemax="8"/);
  assert.match(html, /aria-valuenow="4"/);
  assert.match(html, /Skip for now/);
  assert.match(html, /Back to review/);
  assert.doesNotMatch(html, /role="alert"/);
});

test("the web name input accepts free text up to 50 characters and retains the desktop limit", () => {
  for (const isWeb of [true, false]) {
    const html = renderToStaticMarkup(
      createElement(GuidedBasics, {
        current: "name",
        isWeb,
        locale: "en",
        project: { ...project, name: "Mi café & ideas!" },
        errors: {},
        errorText: () => undefined,
        onChange: () => {},
        onMove: () => {},
        onPhaseChange: () => true,
      }),
    );
    assert.match(html, new RegExp(`maxLength="${isWeb ? 50 : 80}"`));
    assert.match(html, /value="Mi café &amp; ideas!"/);
    assert.doesNotMatch(html, /pattern=/);
  }
});

const fourParticipants: ProjectDefinition["participants"] = [
  { id: "participant-01", role: "generalist", label: "Generalist" },
  { id: "participant-02", role: "architect", label: "Architect" },
  { id: "participant-03", role: "implementer", label: "Implementer" },
  { id: "participant-04", role: "auditor", label: "Auditor" },
];

const renderTeam = (participants = fourParticipants, isWeb = true) =>
  renderToStaticMarkup(
    createElement(TeamStage, {
      isWeb,
      locale: "en",
      project: { ...project, participants },
      errors: {},
      errorText: () => undefined,
      onAddParticipant: () => {},
      onChange: () => {},
      onConfigureMode1: () => {},
      mode1TriggerRef: { current: null },
      responsibilities: {
        generalist: { en: "Coordinate", es: "Coordinar" },
        architect: { en: "Design", es: "Diseñar" },
        implementer: { en: "Build", es: "Construir" },
        auditor: { en: "Audit", es: "Auditar" },
      },
    }),
  );

test("four web roles disable additions and other selected roles while retaining each current option", () => {
  const html = renderTeam();
  const selects = [...html.matchAll(/<select\b[^>]*>(.*?)<\/select>/g)];
  assert.equal(selects.length, 4);
  for (const [index, select] of selects.entries()) {
    const options = [...select[1].matchAll(/<option\b([^>]*)>/g)];
    assert.equal(options.length, 4);
    for (const option of options) {
      const current = option[1].includes(
        `value="${fourParticipants[index].role}"`,
      );
      assert.equal(option[1].includes("disabled="), !current);
      assert.equal(option[1].includes("selected="), current);
    }
  }
  assert.match(
    html,
    /<button[^>]*disabled=""[^>]*aria-describedby="project-participant-limit"/,
  );
  assert.match(html, /id="project-participant-limit"[^>]*role="status"/);
  assert.match(html, /Maximum of 4 participants reached/);
  const desktop = renderTeam(fourParticipants, false);
  assert.doesNotMatch(desktop, /disabled=""/);
  assert.match(desktop, /Roles may repeat/);
  assert.match(desktop, /1 to 6/);
});

test("an oversized restored web team remains visible and its duplicate current roles stay selectable", () => {
  const participants = [
    ...fourParticipants,
    { ...fourParticipants[0], id: "participant-05" },
  ];
  const html = renderTeam(participants);
  const selects = [...html.matchAll(/<select\b[^>]*>(.*?)<\/select>/g)];
  assert.equal(selects.length, 5);
  for (const index of [0, 4]) {
    const current = [...selects[index][1].matchAll(/<option\b([^>]*)>/g)].find(
      (option) => option[1].includes('value="generalist"'),
    )!;
    assert.doesNotMatch(current[1], /disabled=/);
    assert.match(current[1], /selected=/);
  }
  assert.match(
    html,
    /This draft has more than 4 participants. Remove participants to continue/,
  );
});

test("web summary expands with progress and reflects current attachments, team, route, guides and confirmation", () => {
  const render = (current: "name" | "delivery", definition = project) =>
    renderToStaticMarkup(
      createElement(SummaryDrawer, {
        current,
        isWeb: true,
        locale: "en",
        project: definition,
      }),
    );
  const initial = render("name");
  assert.match(initial, /<dd>Orchard<\/dd>/);
  assert.doesNotMatch(
    initial,
    /Attached files|Participants|Included guides|Delivery/,
  );
  const configured: ProjectDefinition = {
    ...project,
    phase: "discovery-complete",
    route: "mixed",
    participants: fourParticipants,
    attachments: [{ name: "notes.md", extension: ".md", size: 12 }],
    initializeGit: true,
    openIde: true,
  };
  const delivery = render("delivery", configured);
  assert.match(delivery, /1 file · 4 participants/);
  assert.match(delivery, /<dt>Attached files<\/dt><dd>1<\/dd>/);
  assert.match(delivery, /<dt>Participants<\/dt><dd>4<\/dd>/);
  for (const text of [
    "Defined idea",
    "Local and managed",
    "Project ZIP",
    "Git · IDE",
    "Review first",
  ])
    assert.ok(delivery.includes(text));
  const changed = render("delivery", {
    ...configured,
    attachments: [],
    participants: [fourParticipants[0]],
    initializeGit: false,
    openIde: false,
    dryRun: false,
  });
  assert.match(changed, /0 files · 1 participant/);
  assert.match(changed, /<dt>Included guides<\/dt><dd>None<\/dd>/);
  assert.match(changed, /Download after confirmation/);
});
