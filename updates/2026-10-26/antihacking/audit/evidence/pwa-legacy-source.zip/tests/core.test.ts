import test from "node:test";
import assert from "node:assert/strict";
import {
  ACCEPTED_EXTENSIONS,
  generatePrompt,
  MAX_FILES,
  planActions,
  slugify,
  validateProject,
  validateAttachmentSet,
  MAX_FILE_BYTES,
  MAX_TOTAL_BYTES,
  buildExecutionPreview,
} from "../src/core";
import type { ProjectDefinition, Settings } from "../src/types";
import { defaultOrchestration, updateProjectFlag } from "../shared/domain";
const settings: Settings = {
  baseFolder: "C:\\Projects",
  toolkitPath: "C:\\Toolkit",
  futureProjectsPath: "C:\\Toolkit\\future_projects",
  defaultBranch: "main",
  preferredIde: "VS Code",
  confirmBeforeRun: true,
  theme: "dark",
  locale: "es",
};
const project: ProjectDefinition = {
  name: "Órbita Inicial",
  phase: "discovery-active",
  context: "Una herramienta local",
  restrictions: "Costo 0",
  route: "local",
  action: "repository",
  destination: "C:\\Projects",
  participants: [
    { id: "1", role: "architect", label: "Design" },
    { id: "2", role: "auditor", label: "Independent review" },
  ],
  attachments: [],
  initializeGit: true,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: true,
  orchestration: defaultOrchestration(),
};
test("portable deterministic slug", () =>
  assert.equal(slugify(project.name), "orbita-inicial"));
test("requires identity, context, destination and at least one participant", () => {
  const e = validateProject(
    { ...project, name: "", context: "", destination: "", participants: [] },
    settings,
  );
  assert.deepEqual(Object.keys(e).sort(), [
    "context",
    "destination",
    "name",
    "participants",
  ]);
});
test("IDE and GitHub imply Git repository", () => {
  const e = validateProject(
    { ...project, initializeGit: false, createRemote: true, openIde: true },
    settings,
  );
  assert.ok(e.createRemote);
  assert.ok(e.openIde);
});
test("rejects unsafe attachment type and large file", () => {
  const e = validateProject(
    {
      ...project,
      attachments: [
        {
          path: "x.exe",
          name: "x.exe",
          extension: ".exe",
          size: 26 * 1024 * 1024,
        },
      ],
    },
    settings,
  );
  assert.equal(e.attachments, "invalid");
});
test("document allowlist excludes audio and video", () => {
  assert.ok(ACCEPTED_EXTENSIONS.includes(".pdf"));
  assert.ok(!ACCEPTED_EXTENSIONS.includes(".mp3"));
  assert.ok(!ACCEPTED_EXTENSIONS.includes(".mp4"));
});
test("bilingual prompt includes participants, IDs, and sources", () => {
  const p = {
    ...project,
    attachments: [
      { path: "x.pdf", name: "x.pdf", extension: ".pdf", size: 10 },
    ],
  };
  assert.match(generatePrompt(p, "es"), /Participantes planificados \(2\)/);
  assert.match(generatePrompt(p, "en"), /1\. \[1\] Architect/);
  assert.match(
    generatePrompt(p, "en"),
    /Attached discovery sources: \[x.pdf\]/,
  );
});
test("action plan includes attachment, GitHub and signature governance", () => {
  const ids = planActions(
    {
      ...project,
      createRemote: true,
      attachments: [
        { path: "x.pdf", name: "x.pdf", extension: ".pdf", size: 10 },
      ],
    },
    settings,
  ).map((x) => x.id);
  assert.deepEqual(ids, ["folder", "attachments", "docs", "git", "github"]);
});
test("tracking plan and preview advertise only the tracking artifact", () => {
  const tracking = {
    ...project,
    action: "tracking" as const,
    attachments: [
      { path: "x.pdf", name: "x.pdf", extension: ".pdf", size: 10 },
    ],
  };
  assert.deepEqual(
    planActions(tracking, settings).map(({ id }) => id),
    ["tracking"],
  );
  const preview = buildExecutionPreview(tracking, settings, "desktop");
  assert.deepEqual(
    preview.artifacts.map(({ kind }) => kind),
    ["tracking"],
  );
});

test("execution preview distinguishes desktop both and W1 ZIP semantics", () => {
  const both = { ...project, action: "both" as const, dryRun: false };
  const desktop = buildExecutionPreview(both, settings, "desktop");
  assert.ok(desktop.artifacts.some(({ kind }) => kind === "repository"));
  assert.ok(desktop.artifacts.some(({ kind }) => kind === "tracking"));
  const manifest = [
    "orbita-inicial/PROJECT_PROMPT.md",
    "orbita-inicial/docs/product/sources/source.pdf",
  ];
  const web = buildExecutionPreview(both, settings, "web", manifest);
  assert.equal(web.artifacts[0].destination, "orbita-inicial.zip");
  assert.deepEqual(
    web.artifacts.slice(1).map(({ destination }) => destination),
    manifest,
  );
  assert.match(web.limitations.join(" "), /tracking is not available/i);
  assert.throws(
    () =>
      buildExecutionPreview(
        { ...project, action: "tracking" },
        settings,
        "web",
      ),
    /isn't supported/,
  );
});
test("tracking path is a configuration error, not a destination error", () => {
  const e = validateProject(
    { ...project, action: "tracking" },
    { ...settings, futureProjectsPath: "" },
  );
  assert.equal(e.tracking, "missingTrackingPath");
  assert.equal(e.destination, undefined);
});
test("dry-run is recommended but never required", () => {
  const e = validateProject({ ...project, dryRun: false }, settings);
  assert.equal(Object.keys(e).length, 0);
});
test("repeated roles are valid and participant IDs remain unique", () => {
  const repeated = [
    project.participants[0],
    { ...project.participants[0], id: "another-architect" },
  ];
  assert.equal(
    validateProject({ ...project, participants: repeated }, settings)
      .participants,
    undefined,
  );
  assert.equal(
    validateProject(
      { ...project, participants: [repeated[0], { ...repeated[1], id: "1" }] },
      settings,
    ).participants,
    "duplicateParticipantIdentity",
  );
});

test("participant count and identity grammar enforce the 1-6 contract", () => {
  assert.equal(
    validateProject({ ...project, participants: [] }, settings).participants,
    "participantCount",
  );
  const six = Array.from({ length: 6 }, (_, i) => ({
    id: `participant-${i + 1}`,
    role: "generalist" as const,
    label: "",
  }));
  assert.equal(
    validateProject({ ...project, participants: six }, settings).participants,
    undefined,
  );
  assert.equal(
    validateProject(
      {
        ...project,
        participants: [...six, { ...six[0], id: "participant-7" }],
      },
      settings,
    ).participants,
    "participantCount",
  );
  assert.equal(
    validateProject(
      { ...project, participants: [{ ...six[0], id: " unsafe" }] },
      settings,
    ).participants,
    "invalidParticipantIdentity",
  );
});

test("Mode 1 associations must match participant IDs and order", () => {
  const orchestration = {
    ...defaultOrchestration(),
    enabled: true,
    participants: project.participants.map((participant) => ({
      participantId: participant.id,
      provider: "codex" as const,
      task: "Bounded task",
    })),
  };
  assert.equal(
    validateProject({ ...project, orchestration }, settings).orchestration,
    undefined,
  );
  assert.equal(
    validateProject(
      {
        ...project,
        orchestration: {
          ...orchestration,
          participants: [...orchestration.participants].reverse(),
        },
      },
      settings,
    ).orchestration,
    "invalidOrchestrationParticipants",
  );
});

test("Mode 1 rejects unknown provider IDs without silently defaulting", () => {
  const orchestration = {
    ...defaultOrchestration(),
    enabled: true,
    participants: project.participants.map((participant) => ({
      participantId: participant.id,
      provider: "future_provider",
      task: "Bounded task",
    })),
  } as ProjectDefinition["orchestration"];
  assert.equal(
    validateProject({ ...project, orchestration }, settings).orchestration,
    "invalidOrchestrationParticipants",
  );
});

test("governance preserves instance order and audit independence language", async () => {
  const { governance, projectSignature } = await import("../shared/domain");
  const text = governance(project);
  assert.match(text, /1\. \[1\] \*\*architect\*\*/);
  assert.match(text, /separate context\/tool invocation/);
  assert.deepEqual(
    projectSignature(project, {
      createdBy: "test",
      appVersion: "1",
      createdAt: "fixed",
    }),
    {
      schemaVersion: 2,
      createdBy: "test",
      appVersion: "1",
      projectName: project.name,
      createdAt: "fixed",
      plannedParticipants: project.participants,
      fundingPolicy: defaultOrchestration().funding,
      sourceFiles: [],
    },
  );
});
test("attachments are capped at twenty files", () => {
  const attachments = Array.from({ length: MAX_FILES + 1 }, (_, i) => ({
    path: `x${i}.pdf`,
    name: `x${i}.pdf`,
    extension: ".pdf",
    size: 1,
  }));
  assert.equal(
    validateProject({ ...project, attachments }, settings).attachments,
    "invalid",
  );
});
test("structured attachment validation covers extension integrity and exact size boundaries", () => {
  assert.deepEqual(
    validateAttachmentSet([
      { name: "a.PDF", extension: ".pdf", size: MAX_FILE_BYTES },
    ]),
    [],
  );
  assert.deepEqual(
    validateAttachmentSet([{ name: "a.pdf", extension: ".txt", size: 1 }]).map(
      (issue) => issue.code,
    ),
    ["unsupportedExtension"],
  );
  assert.deepEqual(
    validateAttachmentSet([
      { name: "a.pdf", extension: ".pdf", size: MAX_FILE_BYTES + 1 },
    ]).map((issue) => issue.code),
    ["fileTooLarge"],
  );
  assert.deepEqual(
    validateAttachmentSet([
      { name: "archive.part.DOCX", extension: ".docx", size: 0 },
    ]),
    [],
  );
  assert.ok(
    validateAttachmentSet([
      { name: "no-extension", extension: "", size: 0 },
    ]).some((issue) => issue.code === "unsupportedExtension"),
  );
  assert.ok(
    validateAttachmentSet([
      { name: "x.png", extension: ".png", size: Number.NaN },
    ]).some((issue) => issue.code === "fileTooLarge"),
  );
});
test("structured attachment validation covers exact and excessive aggregate totals", () => {
  const exact = Array.from({ length: 5 }, (_, index) => ({
    name: `${index}.pdf`,
    extension: ".pdf",
    size: MAX_TOTAL_BYTES / 5,
  }));
  assert.deepEqual(validateAttachmentSet(exact), []);
  assert.ok(
    validateAttachmentSet([
      ...exact,
      { name: "over.jpeg", extension: ".jpeg", size: 1 },
    ]).some((issue) => issue.code === "totalTooLarge"),
  );
});
test("Spanish action plan is localized and expandable", () => {
  const first = planActions(project, settings)[0];
  assert.equal(first.label, "Crear carpeta dedicada");
  assert.ok(first.description.length > 20);
});
test("UI flag transitions preserve the shared Git invariant", () => {
  const enabled = updateProjectFlag(
    { ...project, initializeGit: false },
    "createRemote",
    true,
  );
  assert.equal(enabled.initializeGit, true);
  const disabled = updateProjectFlag(
    { ...enabled, openIde: true },
    "initializeGit",
    false,
  );
  assert.equal(disabled.createRemote, false);
  assert.equal(disabled.openIde, false);
});
