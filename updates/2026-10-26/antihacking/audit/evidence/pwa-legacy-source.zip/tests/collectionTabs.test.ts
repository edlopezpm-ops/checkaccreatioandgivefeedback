import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { pathToFileURL } from "node:url";
import path from "node:path";
import { transform } from "esbuild";
import { harness } from "./helpers/accountHarness";
import { handleCollection } from "../functions/_lib/collection";
import { saveOptionalChoice } from "../src/account/cookiePreferences";
const usage = {
  kind: "usage",
  feature: "creation",
  outcome: "opened",
  durationBand: "instant",
  locale: "en",
  device: "desktop",
} as const;
async function separateTab() {
  const file = path.resolve("src/account/collection.ts");
  const source = readFileSync(file, "utf8").replace(
    /from\s+"(\.[^"]+)"/g,
    (_all, relative) =>
      `from "${pathToFileURL(path.resolve(path.dirname(file), `${relative}.ts`)).href}"`,
  );
  const compiled = (
    await transform(source, { loader: "ts", format: "esm", target: "es2022" })
  ).code;
  return import(
    `data:text/javascript;base64,${Buffer.from(`${compiled}\n// independent tab ${crypto.randomUUID()}`).toString("base64")}`
  ) as Promise<typeof import("../src/account/collection")>;
}
function locks() {
  let previous = Promise.resolve();
  return {
    request: async (_name: string, work: () => Promise<unknown>) => {
      let release!: () => void;
      const tail = new Promise<void>((resolve) => {
        release = resolve;
      });
      const before = previous;
      previous = before.then(() => tail);
      await before;
      try {
        return await work();
      } finally {
        release();
      }
    },
  };
}
async function setup(t: test.TestContext, withLocks: boolean) {
  const values = new Map<string, string>();
  const storage = {
    get length() {
      return values.size;
    },
    key: (i: number) => [...values.keys()][i] ?? null,
    getItem: (k: string) => values.get(k) ?? null,
    setItem: (k: string, v: string) => void values.set(k, v),
    removeItem: (k: string) => void values.delete(k),
  };
  for (const [name, value] of [
    ["localStorage", storage],
    ["navigator", withLocks ? { locks: locks() } : {}],
  ] as const) {
    const old = Object.getOwnPropertyDescriptor(globalThis, name);
    Object.defineProperty(globalThis, name, { configurable: true, value });
    t.after(() => {
      if (old) Object.defineProperty(globalThis, name, old);
      else Reflect.deleteProperty(globalThis, name);
    });
  }
  const h = await harness();
  h.db.now = Date.now();
  h.db.sqlite.exec(
    readFileSync(
      new URL(
        "../migrations-auth/0009_optional_collection.sql",
        import.meta.url,
      ),
      "utf8",
    ),
  );
  const env = { ...h.env, COLLECT_ENABLED: "true" };
  let offlineRevoke = false,
    grantCount = 0;
  const held: (() => void)[] = [];
  let holdResponses = false,
    holdRequests = false;
  const recordRequests: { token: string | null }[] = [];
  t.mock.method(globalThis, "fetch", async (input, init) => {
    const action = String(input).split("/").at(-1) as
        "preference" | "record" | "data",
      body = JSON.parse(String(init?.body));
    const headers = new Headers(init?.headers);
    headers.set("Origin", "https://accreatio.test");
    if (body.action === "revoke" && offlineRevoke)
      throw Error("synthetic offline withdrawal");
    if (body.action === "grant") {
      grantCount++;
      if (holdRequests)
        await new Promise<void>((resolve) => held.push(resolve));
    }
    const response = await handleCollection(
      {
        env,
        request: new Request(`https://accreatio.test/api/collect/${action}`, {
          method: "POST",
          headers,
          body: JSON.stringify(body),
        }),
      },
      action,
    );
    if (body.action === "grant" && holdResponses)
      await new Promise<void>((resolve) => held.push(resolve));
    if (action === "record")
      recordRequests.push({ token: headers.get("Authorization") });
    return response;
  });
  const tabs = await Promise.all([separateTab(), separateTab()]);
  assert.notEqual(
    tabs[0].recordUsage,
    tabs[1].recordUsage,
    "the fixture must have independent module state",
  );
  const live = () =>
    Number(
      h.db.sqlite
        .prepare(
          "SELECT COUNT(*) n FROM collection_permissions WHERE revoked_at IS NULL",
        )
        .get()?.n,
    );
  const records = () =>
    Number(
      h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()?.n,
    );
  const saved = () =>
    [...values.keys()].filter((k) =>
      k.startsWith("accreatio:collect-capability:analytics:v2:"),
    );
  return {
    ...h,
    storage,
    values,
    tabs,
    live,
    records,
    saved,
    recordRequests,
    grants: () => grantCount,
    held,
    setOffline: (v: boolean) => {
      offlineRevoke = v;
    },
    holdResponses: () => {
      holdResponses = true;
    },
    holdRequests: () => {
      holdRequests = true;
    },
  };
}
async function until(check: () => boolean) {
  for (let i = 0; i < 100; i++) {
    if (check()) return;
    await new Promise((resolve) => setTimeout(resolve, 5));
  }
  throw Error("Concurrent fixture did not reach the expected boundary");
}
test("same-origin Web Lock serializes two independent tabs into one current purpose capability", async (t) => {
  const h = await setup(t, true);
  saveOptionalChoice(h.storage, true);
  await Promise.all(h.tabs.map((tab) => tab.recordUsage(usage)));
  assert.equal(h.grants(), 1);
  assert.equal(h.live(), 1);
  assert.equal(h.records(), 2);
  assert.equal(h.saved().length, 1);
  saveOptionalChoice(h.storage, false);
  assert.equal(await h.tabs[0].withdrawCollection("analytics"), true);
  assert.equal(h.live(), 0);
  assert.equal(h.records(), 0);
  assert.equal(h.saved().length, 0);
});
test("two concurrent grant responses retain every capability through repeated offline withdrawals and a successful retry", async (t) => {
  const h = await setup(t, false);
  saveOptionalChoice(h.storage, true);
  h.holdResponses();
  const work = h.tabs.map((tab) => tab.recordUsage(usage));
  await until(() => h.held.length === 2);
  assert.equal(h.grants(), 2);
  assert.equal(h.live(), 2);
  h.setOffline(true);
  for (const release of h.held) release();
  await Promise.all(work);
  assert.equal(
    h.saved().length,
    2,
    "neither concurrent response may overwrite the other capability",
  );
  assert.ok(h.records() >= 1);
  saveOptionalChoice(h.storage, false);
  assert.equal(await h.tabs[0].withdrawCollection("analytics"), false);
  assert.equal(await h.tabs[1].withdrawCollection("analytics"), false);
  assert.equal(
    h.saved().length,
    2,
    "a second withdrawal must not overwrite the first pending capability",
  );
  assert.equal(h.live(), 2);
  assert.ok(
    h
      .saved()
      .every((key) => JSON.parse(h.values.get(key)!).state === "pending"),
  );
  h.setOffline(false);
  assert.equal(await h.tabs[1].retryWithdrawals(), true);
  assert.equal(h.saved().length, 0);
  assert.equal(h.live(), 0);
  assert.equal(h.records(), 0);
  assert.equal(await h.tabs[0].retryWithdrawals(), true);
});
test("withdrawal before a grant reaches the server prevents its late activation, including a lost response", async (t) => {
  const h = await setup(t, false);
  saveOptionalChoice(h.storage, true);
  h.holdRequests();
  const pending = h.tabs[0].recordUsage(usage);
  await until(() => h.held.length === 1);
  assert.equal(
    h.saved().length,
    1,
    "capability is durable before its network grant",
  );
  saveOptionalChoice(h.storage, false);
  assert.equal(await h.tabs[1].withdrawCollection("analytics"), true);
  h.held[0]();
  await pending;
  assert.equal(h.live(), 0);
  assert.equal(h.records(), 0);
  assert.equal(h.recordRequests.length, 0);
  assert.equal(h.saved().length, 0);
});
