import assert from "node:assert/strict";
import { test } from "node:test";
import {
  cloneMode1Draft,
  isAekrCompatibleTopology,
  isMode1DraftDirty,
  isMode1DraftValid,
  normalizeMode1Draft,
  openMode1Draft,
  parseIntegerInRange,
  validateMode1Draft,
} from "../src/components/mode1/mode1Draft";
import { defaultFunding } from "../shared/funding";
import { defaultOrchestration } from "../shared/domain";
import type { ParticipantInstance } from "../src/types";

const participant = (
  id: string,
  role: ParticipantInstance["role"] = "generalist",
): ParticipantInstance => ({ id, role, label: "" });

test("openMode1Draft seeds defaults for unassigned participants", () => {
  const draft = openMode1Draft(
    [participant("participant-01"), participant("participant-02", "architect")],
    defaultOrchestration(),
    "Demo",
  );
  assert.equal(draft.participants.length, 2);
  assert.equal(draft.participants[0].provider, "codex");
  assert.match(draft.participants[1].task, /Demo/);
  assert.equal(draft.compatibilityBlocked, false);
});

test("openMode1Draft preserves existing assignments by participant ID", () => {
  const orchestration = {
    ...defaultOrchestration(),
    participants: [
      {
        participantId: "participant-01",
        provider: "codex",
        task: "Custom task",
      },
    ],
  };
  const draft = openMode1Draft(
    [participant("participant-01")],
    orchestration,
    "Demo",
  );
  assert.equal(draft.participants[0].provider, "codex");
  assert.equal(draft.participants[0].task, "Custom task");
});

test("isAekrCompatibleTopology rejects repeated roles and more than 4 participants", () => {
  assert.equal(
    isAekrCompatibleTopology([{ role: "generalist" }, { role: "architect" }]),
    true,
  );
  assert.equal(
    isAekrCompatibleTopology([{ role: "generalist" }, { role: "generalist" }]),
    false,
  );
  assert.equal(
    isAekrCompatibleTopology([
      { role: "generalist" },
      { role: "architect" },
      { role: "implementer" },
      { role: "auditor" },
      { role: "generalist" },
    ]),
    false,
  );
});

test("openMode1Draft marks compatibilityBlocked for unsupported topology", () => {
  const draft = openMode1Draft(
    [participant("participant-01"), participant("participant-02")],
    defaultOrchestration(),
    "Demo",
  );
  assert.equal(draft.compatibilityBlocked, true);
});

test("parseIntegerInRange accepts only complete integers in bounds", () => {
  assert.equal(parseIntegerInRange("60", 60, 7200), 60);
  assert.equal(parseIntegerInRange("7200", 60, 7200), 7200);
  assert.equal(parseIntegerInRange("", 60, 7200), null);
  assert.equal(parseIntegerInRange("59", 60, 7200), null);
  assert.equal(parseIntegerInRange("7201", 60, 7200), null);
  assert.equal(parseIntegerInRange("1.5", 1, 10), null);
  assert.equal(parseIntegerInRange("-1", 1, 10), null);
  assert.equal(parseIntegerInRange("01", 1, 10), 1);
});

test("validateMode1Draft flags empty task and unknown provider without destroying other rows", () => {
  const draft = openMode1Draft(
    [participant("participant-01")],
    defaultOrchestration(),
    "Demo",
  );
  draft.participants[0].task = "   ";
  const errors = validateMode1Draft(draft);
  assert.equal(errors.participants["participant-01"], "task");

  draft.participants[0].task = "Do the thing";
  draft.participants[0].provider = "unknown_provider";
  const errors2 = validateMode1Draft(draft);
  assert.equal(errors2.participants["participant-01"], "provider");
});

test("validateMode1Draft flags out-of-range numeric limits independently", () => {
  const draft = openMode1Draft(
    [participant("participant-01")],
    defaultOrchestration(),
    "Demo",
  );
  draft.sessionMaxDurationSeconds = "10";
  draft.maxProviderInvocations = "";
  const errors = validateMode1Draft(draft);
  assert.equal(errors.sessionMaxDurationSeconds, true);
  assert.equal(errors.maxProviderInvocations, true);
  assert.equal(errors.maxIterationsPerEntity, false);
  assert.equal(errors.maxConsecutiveFailures, false);
});

test("parseIntegerInRange covers the exact min/max boundary and one-past-boundary for all four schema limits (CODEX_REVIEW L3)", () => {
  const limits: [string, number, number][] = [
    ["sessionMaxDurationSeconds", 60, 7200],
    ["maxIterationsPerEntity", 1, 10],
    ["maxProviderInvocations", 1, 100],
    ["maxConsecutiveFailures", 1, 10],
  ];
  for (const [, min, max] of limits) {
    assert.equal(parseIntegerInRange(String(min), min, max), min);
    assert.equal(parseIntegerInRange(String(max), min, max), max);
    assert.equal(parseIntegerInRange(String(min - 1), min, max), null);
    assert.equal(parseIntegerInRange(String(max + 1), min, max), null);
  }
});

test("normalizeMode1Draft returns null for an invalid draft and preserves nothing implicitly", () => {
  const draft = openMode1Draft(
    [participant("participant-01")],
    defaultOrchestration(),
    "Demo",
  );
  draft.sessionMaxDurationSeconds = "not-a-number";
  assert.equal(normalizeMode1Draft(draft), null);
  assert.equal(isMode1DraftValid(draft), false);
});

test("normalizeMode1Draft converts a valid draft to a canonical OrchestrationConfig", () => {
  const draft = openMode1Draft(
    [participant("participant-01"), participant("participant-02", "architect")],
    defaultOrchestration(),
    "Demo",
  );
  const normalized = normalizeMode1Draft(draft);
  assert.ok(normalized);
  assert.equal(normalized!.enabled, true);
  assert.equal(normalized!.participants.length, 2);
  assert.equal(normalized!.sessionMaxDurationSeconds, 1800);
  assert.deepEqual(normalized!.funding, defaultFunding());
});

test("normalizeMode1Draft refuses an AEKR-incompatible topology even if every field is otherwise valid", () => {
  const draft = openMode1Draft(
    [participant("participant-01"), participant("participant-02")],
    defaultOrchestration(),
    "Demo",
  );
  assert.equal(draft.compatibilityBlocked, true);
  assert.equal(normalizeMode1Draft(draft), null);
});

test("cloneMode1Draft produces an independent deep copy", () => {
  const draft = openMode1Draft(
    [participant("participant-01")],
    defaultOrchestration(),
    "Demo",
  );
  const clone = cloneMode1Draft(draft);
  clone.participants[0].task = "changed";
  clone.funding = { ...clone.funding, maxCost: "0" };
  assert.notEqual(clone.participants[0].task, draft.participants[0].task);
});

test("validateMode1Draft blocks Save when the carried-over funding policy is invalid or unsupported (CODEX_REVIEW H1)", () => {
  const draft = openMode1Draft(
    [participant("participant-01")],
    defaultOrchestration(),
    "Demo",
  );
  // A malformed/unsupported api policy that survived migration must never
  // be silently re-saved while the dialog only ever displays subscription.
  draft.funding = {
    mode: "api",
    providerId: "claude_code",
    modelProfileId: "does-not-exist",
    currency: "USD",
    maxCost: "5",
    hardStopAcknowledged: true,
  };
  const errors = validateMode1Draft(draft);
  assert.equal(errors.funding, true);
  assert.equal(isMode1DraftValid(draft), false);
  assert.equal(normalizeMode1Draft(draft), null);
});

test("validateMode1Draft accepts the default subscription funding policy", () => {
  const draft = openMode1Draft(
    [participant("participant-01")],
    defaultOrchestration(),
    "Demo",
  );
  assert.deepEqual(draft.funding, defaultFunding());
  const errors = validateMode1Draft(draft);
  assert.equal(errors.funding, false);
});

test("isMode1DraftDirty detects edits and cancel-time equality", () => {
  const draft = openMode1Draft(
    [participant("participant-01")],
    defaultOrchestration(),
    "Demo",
  );
  const snapshot = cloneMode1Draft(draft);
  assert.equal(isMode1DraftDirty(draft, snapshot), false);
  draft.participants[0].task = "edited";
  assert.equal(isMode1DraftDirty(draft, snapshot), true);
});
