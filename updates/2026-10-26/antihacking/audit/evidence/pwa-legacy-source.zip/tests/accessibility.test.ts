import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import * as React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { StageNavigation } from "../src/components/creation/StageNavigation";
import { CreationWorkspace } from "../src/components/creation/CreationWorkspace";
import { ReviewStage } from "../src/components/creation/ReviewStage";
import { WebExperienceIntro } from "../src/components/WebExperience";
import type { ExecutionPreview, ProjectDefinition } from "../src/types";
import { defaultOrchestration } from "../shared/domain";

Object.assign(globalThis, { React });

const read = (path: string) =>
  readFileSync(new URL(path, import.meta.url), "utf8");
const project: ProjectDefinition = {
  name: "",
  phase: "idea",
  context: "",
  restrictions: "No network",
  route: "local",
  action: "repository",
  destination: "browser-download",
  participants: [{ id: "participant-01", role: "generalist", label: "" }],
  attachments: [],
  initializeGit: false,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: true,
  orchestration: defaultOrchestration(),
};

test("creation navigation keeps landmark, DOM order, native controls, and textual states", () => {
  const html = renderToStaticMarkup(
    React.createElement(StageNavigation, {
      current: "context",
      locale: "en",
      onSelect: () => undefined,
      states: {
        foundation: "complete",
        context: "current",
        team: "attention",
        delivery: "upcoming",
        review: "upcoming",
      },
    }),
  );
  assert.match(html, /<nav[^>]+aria-label="Project creation stages"/);
  assert.match(html, /<ol>/);
  assert.match(html, /aria-current="step"/);
  assert.match(html, /Complete/);
  assert.match(html, /Needs attention/);
  assert.ok(html.indexOf("Foundation") < html.indexOf("Review"));
  assert.match(html, /<label class="stage-selector">[\s\S]*<select/);
});

test("a rejected mobile stage change has a visible and announced explanation", () => {
  const html = renderToStaticMarkup(
    React.createElement(
      CreationWorkspace,
      {
        current: "foundation",
        feedback:
          "Complete Foundation before continuing. Review the first highlighted field.",
        locale: "en",
        onStageChange: () => undefined,
        states: {
          foundation: "attention",
          context: "upcoming",
          team: "upcoming",
          delivery: "upcoming",
          review: "upcoming",
        },
      },
      React.createElement("section", null, "Stage content"),
    ),
  );
  assert.match(html, /class="stage-navigation__feedback" role="alert"/);
  assert.match(html, /Complete Foundation before continuing/);
});

// Position has to be readable without counting five rail icons, and readable
// by assistive tech without inferring it from a percentage.
test("the creation flow reports position as a labelled progress bar", () => {
  const render = (current: "foundation" | "delivery", locale: "en" | "es") =>
    renderToStaticMarkup(
      React.createElement(
        CreationWorkspace,
        {
          current,
          locale,
          onStageChange: () => undefined,
          states: {
            foundation: "complete",
            context: "complete",
            team: "complete",
            delivery: "current",
            review: "upcoming",
          },
        },
        React.createElement("section", null, "Stage content"),
      ),
    );

  const first = render("foundation", "en");
  assert.match(first, /role="progressbar"/);
  assert.match(first, /aria-valuemin="1"[\s\S]*?aria-valuemax="5"/);
  assert.match(first, /aria-valuenow="1"/);
  assert.match(first, /aria-valuetext="Step 1 of 5"/);

  const fourth = render("delivery", "en");
  assert.match(fourth, /aria-valuenow="4"/);
  assert.match(fourth, /80%/);

  assert.match(render("delivery", "es"), /aria-valuetext="Paso 4 de 5"/);
});

test("incomplete Review explains the cause and links to the next corrective action", () => {
  const preview: ExecutionPreview = {
    host: "web",
    dryRun: true,
    action: "repository",
    headline: "Review only",
    artifacts: [],
    limitations: ["No ZIP will be requested."],
  };
  const html = renderToStaticMarkup(
    React.createElement(ReviewStage, {
      actions: [],
      copied: false,
      locale: "en",
      onChange: () => undefined,
      onConfirm: () => undefined,
      onCopy: () => undefined,
      onDownload: () => undefined,
      onStageChange: () => undefined,
      preview,
      project,
      prompt: "# Project prompt",
      running: false,
      stageStates: {
        foundation: "attention",
        context: "attention",
        team: "complete",
        delivery: "complete",
        review: "current",
      },
      valid: false,
    }),
  );
  assert.match(html, /role="alert"/);
  assert.match(html, /Information is missing/);
  assert.match(html, /Foundation · review/);
  assert.match(html, /Context · review/);
  assert.match(html, /disabled=""/);
  assert.match(html, /Fix the indicated stages/);
});

test("web draft failure and fatal boundary state cause plus recovery action", () => {
  const html = renderToStaticMarkup(
    React.createElement(WebExperienceIntro, {
      locale: "en",
      draftState: "error",
      onNewDraft: () => undefined,
    }),
  );
  assert.match(html, /role="alert"/);
  assert.match(html, /could not save this change/i);
  assert.match(html, /keep a copy of visible work before leaving/i);
  const main = read("../src/main.tsx");
  assert.match(main, /unexpected interface error stopped this view/i);
  assert.match(main, /last locally saved state/i);
  assert.match(main, /type="button"[\s\S]*Reload/);
});

test("History and provider-unavailable states communicate cause and next action", () => {
  const app = read("../src/App.tsx");
  const mode1 = read("../src/components/mode1/Mode1ConfigurationDialog.tsx");
  assert.match(app, /History fills after you run a project/);
  assert.match(app, /it is not restored from cloud sync/);
  assert.match(app, /Create your first project/);
  assert.match(app, /CLI not found/);
  assert.match(app, /Sign-in required/);
  assert.match(mode1, /cannot check local CLI installation or sign-in/);
  assert.match(
    mode1,
    /desktop prototype is obsolete|desktop prototype is retired|will never be released/,
  );
});

test("app landmarks and heading ownership remain explicit across the rebuilt flow", () => {
  const app = read("../src/App.tsx");
  const frame = read("../src/components/AppFrame.tsx");
  const workspace = read("../src/components/creation/CreationWorkspace.tsx");
  const about = read("../src/components/AboutExperience.tsx");
  const blog = read("../src/components/BlogExperience.tsx");
  assert.match(workspace, /<main className="creation-workspace">/);
  assert.match(workspace, /<section className="creation-workspace__stage">/);
  assert.match(about, /<article[^>]+aria-labelledby="about-product-title"/);
  assert.match(about, /<h1 id="about-product-title">/);
  assert.match(about, /aria-labelledby="about-faq-title"/);
  assert.match(about, /aria-labelledby="about-administration-title"/);
  assert.match(
    blog,
    /<main className="blog-page" aria-labelledby="blog-title">/,
  );
  assert.match(blog, /<h1 id="blog-title" tabIndex=\{-1\}>/);
  assert.match(blog, /<article[\s\S]*?aria-labelledby=/);
  assert.match(frame, /className="skip-link" href="#app-content"/);
  assert.match(frame, /id="app-content"[\s\S]*?tabIndex=\{-1\}/);
  assert.match(app, /<GuidedCreation/);
  assert.doesNotMatch(app, /className="section-head"[\s\S]{0,300}<h1/);
  assert.match(app, /document\.documentElement\.lang = s\.locale/);
  assert.match(app, /meta\[name="theme-color"\]/);
  assert.match(app, /<dialog[\s\S]*?aria-labelledby="execution-confirm-title"/);
  assert.match(app, /dialog\.showModal\(\)/);
  assert.doesNotMatch(app, /document\.addEventListener\("keydown"/);
});
