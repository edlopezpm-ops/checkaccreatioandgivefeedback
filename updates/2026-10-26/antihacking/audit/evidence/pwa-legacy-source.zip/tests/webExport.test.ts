import test from "node:test";
import assert from "node:assert/strict";
import {
  buildProjectFiles,
  buildWebExport,
  resolveWebAttachments,
} from "../src/webExport";
import { downloadZip } from "client-zip";
import { inflateRawSync } from "node:zlib";
import {
  generatePrompt,
  validateProject,
  renderOrchestrationConfig,
  renderSetupMd,
  planActions,
} from "../src/core";
import type { ProjectDefinition, Settings, WebAttachment } from "../src/types";
import { defaultOrchestration } from "../shared/domain";
import { safePdfAttachment, staticPdfBlob } from "./helpers/safeAttachment";

const project = (
  overrides: Partial<ProjectDefinition> = {},
): ProjectDefinition => ({
  name: "inventory copilot",
  phase: "idea",
  context: "known context",
  restrictions: "",
  route: "local",
  action: "repository",
  destination: "",
  participants: [{ id: "participant-01", role: "generalist", label: "" }],
  attachments: [],
  initializeGit: true,
  createRemote: true,
  remotePrivate: true,
  openIde: true,
  dryRun: false,
  orchestration: defaultOrchestration(),
  ...overrides,
});
const settings: Settings = {
  baseFolder: "",
  toolkitPath: "",
  futureProjectsPath: "future_projects",
  defaultBranch: "main",
  preferredIde: "VS Code",
  theme: "dark",
  locale: "en",
  confirmBeforeRun: true,
};

function unzipEntries(bytes: Uint8Array) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const output = new Map<string, Uint8Array>();
  const end = bytes.length - 22;
  assert.equal(view.getUint32(end, true), 0x06054b50);
  let offset = view.getUint32(end + 16, true);
  const count = view.getUint16(end + 10, true);
  for (let index = 0; index < count; index += 1) {
    assert.equal(view.getUint32(offset, true), 0x02014b50);
    const method = view.getUint16(offset + 10, true);
    const compressedSize = view.getUint32(offset + 20, true);
    const nameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const localOffset = view.getUint32(offset + 42, true);
    const name = new TextDecoder().decode(
      bytes.subarray(offset + 46, offset + 46 + nameLength),
    );
    const localNameLength = view.getUint16(localOffset + 26, true);
    const localExtraLength = view.getUint16(localOffset + 28, true);
    const start = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = bytes.subarray(start, start + compressedSize);
    output.set(
      name,
      method === 0
        ? compressed.slice()
        : new Uint8Array(inflateRawSync(compressed)),
    );
    offset += 46 + nameLength + extraLength + commentLength;
  }
  return output;
}

test("buildProjectFiles matches the desktop-shared prompt content exactly", () => {
  const p = project();
  const files = buildProjectFiles(p, settings, { appVersion: "1.2.3" });
  const prompt = files.find((f) => f.path.endsWith("PROJECT_PROMPT.md"));
  assert.equal(prompt?.content, generatePrompt(p, settings.locale));
});

test("buildProjectFiles produces the documented ZIP layout under the slug", () => {
  const files = buildProjectFiles(project(), settings, { appVersion: "1.2.3" });
  const paths = files.map((f) => f.path).sort();
  // The self-contained basic contract; runtime dependencies are optional.
  // Every entry is inert text; tests/exportManifest.test.ts enforces that.
  assert.deepEqual(paths, [
    "inventory-copilot/.accreatio/contract.json",
    "inventory-copilot/.accreatio/project.json",
    "inventory-copilot/.claude/settings.json",
    "inventory-copilot/AGENTS.md",
    "inventory-copilot/CLAUDE.md",
    "inventory-copilot/CODEX.md",
    "inventory-copilot/EXPORT_NOTICE.md",
    "inventory-copilot/LICENSES/AEKR-TEMPLATES.txt",
    "inventory-copilot/OWNER_PROFILE.md",
    "inventory-copilot/PROJECT_PROMPT.md",
    "inventory-copilot/SETUP.md",
    "inventory-copilot/START.md",
    "inventory-copilot/docs/adr/0001-record-architecture-decisions.md",
    "inventory-copilot/docs/delivery/audit-checklist.md",
    "inventory-copilot/docs/delivery/definition-of-done.md",
    "inventory-copilot/docs/delivery/participants.md",
    "inventory-copilot/docs/master.md",
    "inventory-copilot/docs/product/discovery.md",
    "inventory-copilot/docs/tool-entrypoints.md",
  ]);
});

test("buildProjectFiles signature identifies the web edition and app version", () => {
  const files = buildProjectFiles(project(), settings, { appVersion: "1.2.3" });
  const signature = JSON.parse(
    files.find((f) => f.path.endsWith("project.json"))!.content,
  );
  assert.equal(signature.createdBy, "accreatio-web");
  assert.equal(signature.appVersion, "1.2.3");
  assert.equal(signature.projectName, "inventory copilot");
});

test("buildProjectFiles refuses tracking-only exports with an explicit reason", () => {
  assert.throws(
    () =>
      buildProjectFiles(project({ action: "tracking" }), settings, {
        appVersion: "1.2.3",
      }),
    /tracking-only export isn't supported/i,
  );
});

test("SETUP.md renders literal commands only for actions a browser can't run itself", () => {
  const p = project();
  const setup = renderSetupMd(planActions(p, settings), p, settings);
  assert.match(setup, /cd inventory-copilot/);
  assert.match(setup, /git init -b main/);
  assert.match(
    setup,
    /gh repo create inventory-copilot --private --source \. --remote origin/,
  );
  assert.match(setup, /code --new-window \./);
});

test("SETUP.md omits git\\/github\\/ide commands when those actions are not planned", () => {
  const p = project({
    initializeGit: false,
    createRemote: false,
    openIde: false,
  });
  const setup = renderSetupMd(planActions(p, settings), p, settings);
  assert.doesNotMatch(setup, /git init/);
  assert.doesNotMatch(setup, /gh repo create/);
  assert.doesNotMatch(setup, /code --new-window/);
});

test("SETUP refuses shell syntax in restored branch settings", () => {
  const p = project();
  for (const defaultBranch of [
    "main; echo leaked",
    "$(whoami)",
    "main`whoami`",
    "--help",
    "main\nwhoami",
    "foo/../bar",
  ]) {
    const unsafe = { ...settings, defaultBranch };
    assert.throws(
      () => renderSetupMd(planActions(p, unsafe), p, unsafe),
      /Invalid branch name/,
    );
  }
  const safe = { ...settings, defaultBranch: "feature/local-launch" };
  assert.match(
    renderSetupMd(planActions(p, safe), p, safe),
    /git init -b feature\/local-launch/,
  );
});

test("buildProjectFiles omits orchestration.yaml when orchestration is disabled", () => {
  const files = buildProjectFiles(project(), settings, { appVersion: "1.2.3" });
  assert.ok(!files.some((f) => f.path.endsWith("orchestration.yaml")));
});

test("buildProjectFiles includes orchestration.yaml when enabled", () => {
  const p = project({
    orchestration: {
      ...defaultOrchestration(),
      enabled: true,
      participants: [{ participantId: "participant-01", provider: "codex" }],
      sessionMaxDurationSeconds: 3600,
      maxIterationsPerEntity: 3,
      maxProviderInvocations: 20,
      maxConsecutiveFailures: 2,
    },
  });
  const files = buildProjectFiles(p, settings, { appVersion: "1.2.3" });
  const orch = files.find((f) => f.path.endsWith("orchestration.yaml"));
  assert.ok(orch);
  assert.equal(orch!.content, renderOrchestrationConfig(p, settings));
  assert.doesNotMatch(orch!.content, /TODO/);
  assert.match(orch!.content, /Coordinate the approved scope/);
});

test("renderOrchestrationConfig only allows workspace-write for the Implementador role", () => {
  const p = project({
    participants: [{ id: "participant-01", role: "architect", label: "" }],
    orchestration: {
      ...defaultOrchestration(),
      enabled: true,
      participants: [{ participantId: "participant-01", provider: "codex" }],
      sessionMaxDurationSeconds: 7200,
      maxIterationsPerEntity: 3,
      maxProviderInvocations: 20,
      maxConsecutiveFailures: 2,
    },
  });
  const yaml = renderOrchestrationConfig(p, settings);
  assert.match(yaml, /Arquitecto/);
  assert.match(yaml, /sandbox: read-only/);
  assert.doesNotMatch(yaml, /sandbox: workspace-write/);
});

test("renderOrchestrationConfig marks the Auditor role's action_kind as an independent audit", () => {
  const p = project({
    participants: [{ id: "participant-01", role: "auditor", label: "" }],
    orchestration: {
      ...defaultOrchestration(),
      enabled: true,
      participants: [
        { participantId: "participant-01", provider: "claude_code" },
      ],
      sessionMaxDurationSeconds: 7200,
      maxIterationsPerEntity: 3,
      maxProviderInvocations: 20,
      maxConsecutiveFailures: 2,
    },
  });
  const yaml = renderOrchestrationConfig(p, settings);
  assert.match(yaml, /action_kind: EXECUTE_INDEPENDENT_AUDIT/);
  assert.doesNotMatch(yaml, /max_budget_usd/);
  assert.doesNotMatch(yaml, /ceiling:/);
});

test("mixed providers serialize byte-compatible adapter fields and no registry metadata", () => {
  const p = project({
    participants: [
      { id: "participant-01", role: "architect", label: "" },
      { id: "participant-02", role: "implementer", label: "" },
    ],
    orchestration: {
      ...defaultOrchestration(),
      enabled: true,
      participants: [
        {
          participantId: "participant-01",
          provider: "claude_code",
          task: "Design",
        },
        {
          participantId: "participant-02",
          provider: "codex",
          task: "Implement",
        },
      ],
    },
  });
  const yaml = renderOrchestrationConfig(p, settings);
  assert.match(yaml, /Arquitecto:\n    kind: claude_code/);
  assert.match(
    yaml,
    /Implementador:\n    kind: codex\n    sandbox: workspace-write/,
  );
  assert.doesNotMatch(
    yaml,
    /displayName|capabilities|desktopDetection|reasonCode|subscription_cli/,
  );
  const exported = buildProjectFiles(p, settings, { appVersion: "1.2.3" });
  assert.equal(
    exported.find((file) => file.path.endsWith("orchestration.yaml"))?.content,
    yaml,
  );
});

test("unknown providers fail before web ZIP file assembly", () => {
  const p = project({
    orchestration: {
      ...defaultOrchestration(),
      enabled: true,
      participants: [
        {
          participantId: "participant-01",
          provider: "future_provider",
          task: "Task",
        },
      ],
    } as ProjectDefinition["orchestration"],
  });
  assert.throws(
    () => buildProjectFiles(p, settings, { appVersion: "1.2.3" }),
    (error: unknown) =>
      error instanceof Error &&
      error.name === "ProviderGenerationError" &&
      error.message === "unknownProvider",
  );
});

test("Mode 1 validation rejects role drift and empty tasks", () => {
  const p = project({
    orchestration: {
      enabled: true,
      participants: [
        { participantId: "participant-01", provider: "codex", task: "" },
      ],
      sessionMaxDurationSeconds: 7200,
      maxIterationsPerEntity: 3,
      maxProviderInvocations: 20,
      maxConsecutiveFailures: 2,
    },
  });
  const errors = validateProject(p, settings);
  assert.equal(errors.orchestration, "invalidOrchestrationParticipants");
});

test("compatible one- and four-participant Mode 1 YAML preserves the current AEKR contract with identity comments", () => {
  const participants = [
    { id: "participant-01", role: "generalist" as const, label: "" },
    { id: "participant-02", role: "architect" as const, label: "" },
    { id: "participant-03", role: "implementer" as const, label: "" },
    { id: "participant-04", role: "auditor" as const, label: "" },
  ];
  for (const selected of [participants.slice(0, 1), participants]) {
    const p = project({
      participants: selected,
      orchestration: {
        ...defaultOrchestration(),
        enabled: true,
        participants: selected.map((item) => ({
          participantId: item.id,
          provider: "claude_code" as const,
          task: `Task for ${item.id}`,
        })),
      },
    });
    const yaml = renderOrchestrationConfig(p, settings);
    assert.match(yaml, /role_sequence:/);
    assert.match(yaml, new RegExp(`# participant_id: ${selected[0].id}`));
    assert.doesNotMatch(yaml, /^participants:/m);
  }
});

test("repeated-role and five/six-participant Mode 1 configurations fail closed with the exact contract error", () => {
  const topologies = [2, 5, 6].map((count) =>
    Array.from({ length: count }, (_, index) => ({
      id: `participant-${String(index + 1).padStart(2, "0")}`,
      role: (["generalist", "architect", "implementer", "auditor"] as const)[
        index % 4
      ],
      label: "",
    })),
  );
  for (const participants of topologies) {
    if (participants.length === 2)
      participants[1] = { ...participants[1], role: "generalist" };
    const p = project({
      participants,
      orchestration: {
        ...defaultOrchestration(),
        enabled: true,
        participants: participants.map((item) => ({
          participantId: item.id,
          provider: "codex" as const,
          task: "Task",
        })),
      },
    });
    assert.equal(
      validateProject(p, settings).orchestration,
      "orchestrationContractUnsupported",
    );
    assert.throws(
      () => buildProjectFiles(p, settings, { appVersion: "1.2.3" }),
      /orchestrationContractUnsupported/,
    );
  }
});

test("provenance v2 and generated files are deterministic with fixed provenance time", () => {
  const p = project();
  const first = buildProjectFiles(p, settings, { appVersion: "1.2.3" });
  const second = buildProjectFiles(p, settings, { appVersion: "1.2.3" });
  const signature = JSON.parse(
    first.find((file) => file.path.endsWith("project.json"))!.content,
  );
  assert.equal(signature.schemaVersion, 2);
  assert.deepEqual(signature.plannedParticipants, p.participants);
  assert.deepEqual(signature.fundingPolicy, defaultOrchestration().funding);
  assert.equal(
    first
      .filter((file) => !file.path.endsWith("project.json"))
      .map((file) => file.content)
      .join("\n"),
    second
      .filter((file) => !file.path.endsWith("project.json"))
      .map((file) => file.content)
      .join("\n"),
  );
});

test("web resolver sanitizes hostile names and allocates deterministic case-insensitive collisions", () => {
  const attachments: WebAttachment[] = [
    {
      id: "1",
      name: "../CON.pdf",
      extension: ".pdf",
      size: 1,
      blob: new Blob(["a"]),
    },
    {
      id: "2",
      name: "con.PDF",
      extension: ".pdf",
      size: 1,
      blob: new Blob(["b"]),
    },
    {
      id: "3",
      name: "a\\b.txt",
      extension: ".txt",
      size: 1,
      blob: new Blob(["c"]),
    },
  ];
  assert.deepEqual(
    resolveWebAttachments(attachments, "demo").map((item) => item.archiveName),
    ["attachment-CON.pdf", "attachment-con (2).pdf", "b.txt"],
  );
});

test("actual ZIP extraction includes inspected PDF bytes and preserves duplicate-name allocation", async () => {
  const webAttachments = await Promise.all([
    safePdfAttachment("notes.pdf", "one"),
    safePdfAttachment("NOTES.PDF", "two"),
    safePdfAttachment("../source.pdf", "three"),
  ]);
  const p = project({
    attachments: webAttachments.map(({ name, extension, size }) => ({
      name,
      extension,
      size,
    })),
  });
  const entries = buildWebExport(p, settings, webAttachments, {
    appVersion: "1.2.3",
  });
  const zip = await downloadZip(
    entries.map((entry) => ({ name: entry.path, input: entry.input })),
  ).blob();
  const extracted = unzipEntries(new Uint8Array(await zip.arrayBuffer()));
  const resolved = resolveWebAttachments(webAttachments, "inventory-copilot");
  for (let index = 0; index < webAttachments.length; index += 1) {
    const entry = extracted.get(resolved[index].archivePath);
    assert.ok(entry, resolved[index].archivePath);
    assert.deepEqual(
      entry,
      new Uint8Array(await webAttachments[index].blob.arrayBuffer()),
    );
  }
  const prompt = String(
    entries.find((entry) => entry.path.endsWith("PROJECT_PROMPT.md"))?.input,
  );
  const signature = JSON.parse(
    String(entries.find((entry) => entry.path.endsWith("project.json"))?.input),
  );
  for (const item of resolved)
    assert.match(
      prompt,
      new RegExp(item.archiveName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"),
    );
  assert.deepEqual(
    signature.sourceFiles,
    resolved.map((item) => item.archiveName),
  );
});

test("synchronous ZIP construction rejects uninspected allowed-extension bytes", async () => {
  const blob = await staticPdfBlob();
  const metadata = { name: "source.pdf", extension: ".pdf", size: blob.size };
  assert.throws(
    () =>
      buildWebExport(
        project({ attachments: [metadata] }),
        settings,
        [{ ...metadata, id: "raw", blob }],
        { appVersion: "test" },
      ),
    /inspect|validat|prepar/i,
  );
});

test("rebuilt flow preserves the complete definition through prompt, plan, structure, and ZIP", () => {
  const definition = project({
    name: "equivalence launch",
    phase: "discovery-active",
    context: "Customer interviews and an existing prototype",
    restrictions: "Offline only; zero direct service cost",
    route: "mixed",
    destination: "browser-download",
    participants: [
      { id: "participant-01", role: "implementer", label: "Build" },
      { id: "participant-02", role: "auditor", label: "Audit" },
    ],
    orchestration: {
      ...defaultOrchestration(),
      enabled: true,
      participants: [
        {
          participantId: "participant-01",
          provider: "codex",
          task: "Implement the approved plan",
        },
        {
          participantId: "participant-02",
          provider: "claude_code",
          task: "Audit independently",
        },
      ],
    },
    initializeGit: true,
    createRemote: true,
    openIde: true,
  });
  assert.deepEqual(validateProject(definition, settings), {});
  const prompt = generatePrompt(definition, "en");
  for (const value of [
    "equivalence launch",
    "Discovery in progress",
    "Customer interviews",
    "Offline only",
    "mixed",
    "implementer",
    "auditor",
  ])
    assert.match(prompt, new RegExp(value, "i"));
  const actions = planActions(definition, settings);
  const actionText = JSON.stringify(actions);
  assert.match(actionText, /git/i);
  assert.match(actionText, /github/i);
  assert.match(actionText, /VS Code/i);
  const entries = buildWebExport(definition, settings, [], {
    appVersion: "test",
  });
  const paths = entries.map(({ path }) => path);
  for (const suffix of [
    "PROJECT_PROMPT.md",
    "docs/product/discovery.md",
    "AGENTS.md",
    ".accreatio/project.json",
    ".ai-engineering/orchestration.yaml",
    "SETUP.md",
  ])
    assert.ok(
      paths.some((path) => path.endsWith(suffix)),
      suffix,
    );
  const setup = String(
    entries.find(({ path }) => path.endsWith("SETUP.md"))?.input,
  );
  assert.match(setup, /git init/);
  assert.match(setup, /gh repo create/);
  assert.match(setup, /code --new-window/);
});
