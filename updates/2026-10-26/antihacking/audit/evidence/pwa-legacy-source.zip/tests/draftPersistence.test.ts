import test from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

// Isolate module-level writer/revision state per simulated tab. Only durable
// storage I/O, domain migration and fixture shape validation are replaced; the production persistence
// source executes unchanged. Node 24 is also the repository's CI runtime.
const harness = String.raw`
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { stripTypeScriptTypes } from 'node:module';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';
const key = 'accreatio:account-draft:v1';
const contextKey = 'accreatio:draft-context:v1';
const draftKey = 'account-current:v1';
const identity = { ownerKey: 'v1:' + 'a'.repeat(64), sessionKey: 'v1:' + '1'.repeat(64) };
const identityB = { ownerKey: 'v1:' + 'b'.repeat(64), sessionKey: 'v1:' + '2'.repeat(64) };
const seedContext = { ...identity, generation: 'seed-generation' };
const project = { name: 'Original', attachments: [] };
const initial = { schemaVersion: 5, project, revision: '1:seed:initial', ...seedContext };
const journal = new Map([[key, JSON.stringify(initial)], [contextKey, JSON.stringify(seedContext)]]);
const indexed = new Map([[draftKey, initial], [contextKey, seedContext]]);
const faults = { localWrite: false, localRemove: false, database: false, pauseNextGet: false };
let releaseRead, readPaused;
const pauseRead = () => new Promise(resolve => { readPaused = resolve; faults.pauseNextGet = true; });
const storage = {
  getItem: k => journal.get(k) ?? null,
  setItem: (k, v) => { if (faults.localWrite) throw Error('QuotaExceededError'); journal.set(k, v); },
  removeItem: k => { if (faults.localRemove) throw Error('StorageUnavailable'); journal.delete(k); }
};
const db = {
  get: async (_store, k) => { if (faults.database) throw Error('IndexedDBUnavailable'); return indexed.get(k); },
  transaction: () => {
    if (faults.database) throw Error('IndexedDBUnavailable');
    return {
      store: { get: async k => { if (faults.pauseNextGet) { faults.pauseNextGet = false; await new Promise(resolve => { releaseRead = resolve; readPaused(); }); } return indexed.get(k); }, put: async (v, k) => indexed.set(k, v), delete: async k => indexed.delete(k) },
      done: Promise.resolve(), abort() {}
    };
  }
};
const source = stripTypeScriptTypes(readFileSync('src/draftStore.ts', 'utf8'), { mode: 'strip' });
async function tab(options = {}) {
  const window = new EventTarget();
  let invalidations = 0;
  const invalidationEvents = [];
  window.addEventListener('accreatio:draft-invalidated', event => { invalidations++; invalidationEvents.push({ sessionEnded: event.sessionEnded }); });
  const context = vm.createContext({
    navigator: options.writer === false ? { locks: { request: async (_name, _options, callback) => callback(null) } } : {}, window, Event, crypto: webcrypto, Date: { now: () => 1000 },
    localStorage: storage, console, Math, Promise
  });
  const domain = new vm.SyntheticModule(['migrateProjectDefinition'], function () {
    this.setExport('migrateProjectDefinition', value => value ? { project: value.project ?? value, warnings: [] } : null);
  }, { context });
  // This persistence fixture intentionally uses only name/attachments. Real
  // project shape admission is exercised by draftStore.test.ts; reject an
  // invalid fixture name here so recovery notices can still be tested.
  const shape = new vm.SyntheticModule(['projectShapeErrors'], function () {
    this.setExport('projectShapeErrors', value => typeof value.name === 'string' ? {} : { name: 'invalid' });
  }, { context });
  const idb = new vm.SyntheticModule(['openDB'], function () { this.setExport('openDB', async () => db); }, { context });
  await domain.link(() => {}); await domain.evaluate();
  await shape.link(() => {}); await shape.evaluate();
  await idb.link(() => {}); await idb.evaluate();
  const module = new vm.SourceTextModule(source, { context, importModuleDynamically: async () => idb });
  await module.link(specifier => specifier.includes('inputValidation') ? shape : domain); await module.evaluate();
  if (!options.unbound) await module.namespace.bindAccountDraft(options.identity ?? identity);
  return { ...module.namespace, invalidations: () => invalidations, invalidationEvents: () => invalidationEvents, dispatchStorage: marker => window.dispatchEvent(Object.assign(new Event('storage'), { key: contextKey, newValue: JSON.stringify(marker) })) };
}
`;

function runScenario(scenario: string) {
  const result = spawnSync(
    process.execPath,
    ["--experimental-vm-modules", "--input-type=module", "-"],
    {
      cwd: fileURLToPath(new URL("..", import.meta.url)),
      input: `${harness}\n${scenario}`,
      encoding: "utf8",
      timeout: 15_000,
    },
  );
  assert.equal(result.error, undefined, String(result.error));
  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
}

test("malformed persisted draft opens a blank fallback with a recovery warning", () => {
  runScenario(`
const a = await tab();
const corrupt = { ...initial, project: { name: { invalid: true }, attachments: [] } };
journal.set(key, JSON.stringify(corrupt));
indexed.set(draftKey, corrupt);
const restored = await a.loadDraftWithWarnings({ name: '', attachments: [] });
assert.equal(restored.project.name, '');
assert.equal(restored.warnings.includes('invalidDraftRecovered'), true);
assert.deepEqual(Array.from(restored.project.attachments), []);
`);
});

test("acknowledged IndexedDB edits survive failed journal write and cleanup", () => {
  runScenario(`
const a = await tab();
await a.loadDraftWithWarnings(project);
faults.localWrite = true;
faults.localRemove = true;
await a.saveDraft({ ...project, name: 'Acknowledged newer edit' });
assert.equal(indexed.get(draftKey).project.name, 'Acknowledged newer edit');
assert.equal(JSON.parse(journal.get(key)).project.name, 'Original');
const restored = await a.loadDraftWithWarnings(project);
assert.equal(restored.project.name, 'Acknowledged newer edit');
await a.saveDraft({ ...project, name: 'Next acknowledged edit' });
assert.equal((await a.loadDraftWithWarnings(project)).project.name, 'Next acknowledged edit');
`);
});

test("immediate journal writes preserve last input, navigation and count without attachment names", () => {
  runScenario(`
const a = await tab();
await a.loadDraftWithWarnings(project);
const first = a.saveDraft({ ...project, name: 'First input' });
const second = a.saveDraft({ ...project, name: 'Last input', attachments: [{ name: 'private-note.txt', size: 10, extension: '.txt' }] }, { question: 'team', hasReviewed: true, locale: 'es' }, 2);
const immediate = JSON.parse(journal.get(key));
assert.equal(immediate.project.name, 'Last input');
assert.equal(immediate.navigation.question, 'team');
assert.equal(immediate.transientAttachments.count, 2);
assert.doesNotMatch(journal.get(key), /private-note|\\.txt|"size"/);
await Promise.all([first, second]);
assert.equal(indexed.get(draftKey).project.name, 'Last input');
assert.ok(Number(indexed.get(draftKey).revision.split(':')[0]) > 1000);
`);
});

test("without Web Locks stale tab cannot overwrite or clear a newer draft", () => {
  runScenario(`
const a = await tab(); const b = await tab();
await a.loadDraftWithWarnings(project); await b.loadDraftWithWarnings(project);
await a.saveDraft({ ...project, name: 'Other tab latest edit' });
await assert.rejects(b.saveDraft({ ...project, name: 'Stale overwrite' }), /draft_other_tab/);
await assert.rejects(b.clearDraft(), /draft_other_tab/);
assert.equal(JSON.parse(journal.get(key)).project.name, 'Other tab latest edit');
assert.equal(indexed.get(draftKey).project.name, 'Other tab latest edit');
`);
});

test("unavailable durable stores reject save instead of acknowledging it", () => {
  runScenario(`
const a = await tab(); await a.loadDraftWithWarnings(project);
faults.localWrite = true; faults.database = true;
await assert.rejects(a.saveDraft({ ...project, name: 'Not durably saved' }), /IndexedDBUnavailable/);
assert.equal(JSON.parse(journal.get(key)).project.name, 'Original');
assert.equal(indexed.get(draftKey).project.name, 'Original');
`);
});

test("future draft version rejects writes and preserves the stored payload", () => {
  runScenario(`
const a = await tab();
const future = JSON.stringify({ ...initial, schemaVersion: 6 });
journal.set(key, future); indexed.delete(draftKey);
await assert.rejects(a.loadDraftWithWarnings(project), /draft_newer_version/);
await assert.rejects(a.saveDraft({ ...project, name: 'Old client overwrite' }), /draft_other_tab/);
assert.equal(journal.get(key), future);
`);
});

test("a future schema in either durable store cannot be hidden by revision ordering", () => {
  for (const futureStore of ["journal", "indexed"]) {
    runScenario(`
const a = await tab();
const future = { ...initial, schemaVersion: 6, project: { ...project, name: 'Future client draft' } };
const current = { ...initial, revision: '2000:old-client:latest' };
journal.set(key, JSON.stringify(${futureStore === "journal" ? "future" : "current"}));
indexed.set(draftKey, ${futureStore === "indexed" ? "future" : "current"});
const before = journal.get(key);
await assert.rejects(a.loadDraftWithWarnings(project), /draft_newer_version/);
await assert.rejects(a.saveDraft({ ...project, name: 'Old client overwrite' }), /draft_other_tab/);
assert.equal(journal.get(key), before);
assert.equal(${futureStore === "journal" ? "JSON.parse(journal.get(key))" : "indexed.get(draftKey)"}.schemaVersion, 6);
`);
  }
});

test("account draft I/O requires a validated binding and never adopts legacy unowned data", () => {
  runScenario(`
const a = await tab({ unbound: true });
await assert.rejects(a.loadDraftWithWarnings(project), /draft_not_bound/);
await assert.rejects(a.saveDraft(project), /draft_not_bound/);
await assert.rejects(a.clearDraft(), /draft_not_bound/);
await assert.rejects(a.bindAccountDraft({ ownerKey: 'email@example.test', sessionKey: identity.sessionKey }), /draft_invalid_identity/);
journal.clear(); indexed.clear();
journal.set('accreatio:draft-journal:v5', JSON.stringify(initial));
indexed.set('current', initial);
journal.set('accreatio:cookie-preferences', 'keep-cookies');
journal.set('accreatio:onboarding', 'keep-onboarding');
await a.bindAccountDraft(identityB);
assert.equal(await a.loadDraft(project), null);
assert.equal(journal.has('accreatio:draft-journal:v5'), false);
assert.equal(indexed.has('current'), false);
assert.equal(journal.get('accreatio:cookie-preferences'), 'keep-cookies');
assert.equal(journal.get('accreatio:onboarding'), 'keep-onboarding');
`);
});

test("owner or new sign-in changes discard answers options navigation and attachment count", () => {
  runScenario(`
const a = await tab();
await a.saveDraft({ ...project, name: 'A private answer', orchestration: { enabled: true } }, { question: 'review', hasReviewed: true, locale: 'es' }, 2);
await a.bindAccountDraft({ ...identity, sessionKey: 'v1:' + '3'.repeat(64) });
assert.equal(await a.loadDraftWithWarnings(project), null);
await a.saveDraft({ ...project, name: 'A second private answer' });
await a.bindAccountDraft(identityB, true);
assert.equal(await a.loadDraft(project), null);
assert.equal(journal.has(key), false);
assert.equal(indexed.has(draftKey), false);
assert.equal(a.invalidations(), 0);
`);
});

test("same-session reload and explicit live same-owner reauthentication retain the draft", () => {
  runScenario(`
const a = await tab();
await a.saveDraft({ ...project, name: 'Same owner answer' }, { question: 'review', hasReviewed: true, locale: 'en' }, 1);
const reloaded = await tab();
assert.equal((await reloaded.loadDraftWithWarnings(project)).project.name, 'Same owner answer');
await a.bindAccountDraft({ ...identity, sessionKey: 'v1:' + '3'.repeat(64) }, true);
const retained = await a.loadDraftWithWarnings(project);
assert.equal(retained.project.name, 'Same owner answer');
assert.equal(retained.navigation.question, 'review');
assert.equal(retained.transientAttachmentCount, 1);
assert.equal(JSON.parse(journal.get(key)).sessionKey, 'v1:' + '3'.repeat(64));
await a.purgeAccountDraft();
await a.bindAccountDraft(identity, true);
assert.equal(await a.loadDraft(project), null);
`);
});

test("a nonwriter can purge a future draft and stale writers cannot resurrect it", () => {
  runScenario(`
const a = await tab();
const b = await tab({ writer: false });
journal.set(key, JSON.stringify({ ...initial, schemaVersion: 100 }));
indexed.set(draftKey, { ...initial, schemaVersion: 100 });
await b.purgeAccountDraft();
assert.equal(journal.has(key), false);
assert.equal(indexed.has(draftKey), false);
await assert.rejects(a.saveDraft({ ...project, name: 'Stale secret' }), /draft_context_changed/);
await assert.rejects(a.clearDraft(), /draft_context_changed/);
await b.bindAccountDraft(identityB);
assert.equal(await b.loadDraft(project), null);
assert.equal(b.invalidations(), 0);
`);
});

test("purge synchronously invalidates an in-flight queued write before its transaction completes", () => {
  runScenario(`
const a = await tab();
const paused = pauseRead();
const write = a.saveDraft({ ...project, name: 'Pending old account bytes' });
const rejected = assert.rejects(write, /draft_context_changed/);
await paused;
const purge = a.purgeAccountDraft();
await assert.rejects(a.saveDraft(project), /draft_not_bound/);
releaseRead();
await rejected; await purge;
assert.equal(journal.has(key), false);
assert.equal(indexed.has(draftKey), false);
await a.bindAccountDraft(identityB);
assert.equal(await a.loadDraft(project), null);
`);
});

test("failed cleanup in both stores cannot expose a former owner's bytes to the next session", () => {
  runScenario(`
const a = await tab();
await a.saveDraft({ ...project, name: 'Old owner private answer' });
faults.localWrite = true; faults.localRemove = true; faults.database = true;
await assert.rejects(a.purgeAccountDraft(), /draft_storage_unavailable/);
await assert.rejects(a.loadDraft(project), /draft_not_bound/);
await assert.rejects(a.bindAccountDraft(identityB), /draft_storage_unavailable/);
await assert.rejects(a.loadDraft(project), /draft_not_bound/);
faults.localWrite = false; faults.localRemove = false; faults.database = false;
await a.bindAccountDraft(identityB);
assert.equal(await a.loadDraft(project), null);
await a.bindAccountDraft({ ...identity, sessionKey: 'v1:' + '4'.repeat(64) });
assert.equal(await a.loadDraft(project), null);
`);
});

test("only an external different context invalidates the bound tab and emits a local event", () => {
  runScenario(`
const a = await tab();
a.dispatchStorage(seedContext);
assert.equal(a.invalidations(), 0);
const b = await tab();
await b.bindAccountDraft(identityB);
a.dispatchStorage(JSON.parse(journal.get(contextKey)));
assert.equal(a.invalidations(), 1);
a.dispatchStorage(JSON.parse(journal.get(contextKey)));
assert.equal(a.invalidations(), 1);
await assert.rejects(a.loadDraft(project), /draft_not_bound/);
assert.equal(b.invalidations(), 0);
`);
});

test("external logout tombstones and removed context emit sessionEnded without restoring the old session", () => {
  runScenario(`
const a = await tab();
const logoutTab = await tab({ writer: false });
await logoutTab.purgeAccountDraft();
a.dispatchStorage(JSON.parse(journal.get(contextKey)));
assert.deepEqual(a.invalidationEvents(), [{ sessionEnded: true }]);
await assert.rejects(a.loadDraft(project), /draft_not_bound/);
assert.deepEqual(logoutTab.invalidationEvents(), []);
const reentered = await tab();
reentered.dispatchStorage(null);
assert.deepEqual(reentered.invalidationEvents(), [{ sessionEnded: true }]);
await assert.rejects(reentered.saveDraft(project), /draft_not_bound/);
`);
});

test("external owner session and generation changes emit sessionEnded false for account recheck", () => {
  runScenario(`
for (const marker of [
  { ...identityB, generation: 'new-owner' },
  { ...identity, sessionKey: 'v1:' + '3'.repeat(64), generation: 'new-session' },
  { ...identity, generation: 'new-generation' },
]) {
  const a = await tab();
  a.dispatchStorage(JSON.parse(journal.get(contextKey)));
  assert.deepEqual(a.invalidationEvents(), []);
  a.dispatchStorage(marker);
  assert.deepEqual(a.invalidationEvents(), [{ sessionEnded: false }]);
  await assert.rejects(a.loadDraft(project), /draft_not_bound/);
}
`);
});

test("stale-account purge cannot erase the new account's context or draft", () => {
  runScenario(`
const a = await tab();
const b = await tab();
await b.bindAccountDraft(identityB);
await b.saveDraft({ ...project, name: 'New owner safe answer' });
const before = journal.get(key);
await assert.rejects(a.purgeAccountDraft(), /draft_context_changed/);
assert.equal(journal.get(key), before);
assert.equal((await b.loadDraft(project)).name, 'New owner safe answer');
`);
});

test("transactional context rejects a stale queued writer even before storage events arrive", () => {
  runScenario(`
const a = await tab();
const paused = pauseRead();
const write = a.saveDraft({ ...project, name: 'Stale queued answer' });
const rejected = assert.rejects(write, /draft_context_changed/);
await paused;
// Simulate the durable half of another tab's account switch before its storage event.
indexed.set(contextKey, { ...identityB, generation: 'other-generation' });
indexed.delete(draftKey);
releaseRead();
await rejected;
assert.equal(indexed.has(draftKey), false);
`);
});

test("same-session binding preserves a future payload but another account can discard it", () => {
  runScenario(`
journal.set(key, JSON.stringify({ ...initial, schemaVersion: 99 }));
indexed.set(draftKey, { ...initial, revision: '9999:seed:newer' });
const a = await tab({ unbound: true });
await assert.rejects(a.bindAccountDraft(identity), /draft_newer_version/);
assert.equal(JSON.parse(journal.get(key)).schemaVersion, 99);
await a.bindAccountDraft(identityB);
assert.equal(await a.loadDraft(project), null);
assert.equal(journal.has(key), false);
`);
});

test("a changed durable context cannot be hidden by the old matching journal", () => {
  runScenario(`
const a = await tab();
indexed.set(contextKey, { ...identityB, generation: 'other-generation' });
indexed.delete(draftKey);
await assert.rejects(a.loadDraft(project), /draft_context_changed/);
`);
});
