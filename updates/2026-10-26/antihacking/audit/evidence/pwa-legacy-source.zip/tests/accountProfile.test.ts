import assert from "node:assert/strict";
import test from "node:test";
import { harness, POLICY_AUTHORIZATION } from "./helpers/accountHarness";
import { oidcStore } from "../functions/_lib/auth/oidc-store";
import { googleIdentity } from "../functions/_lib/auth/oidc";
import { toHex } from "../functions/_lib/auth/privacy";

async function setup() {
  const h = await harness();
  Object.assign(h.env, {
    ACCOUNT_EMAIL_ENCRYPTION_KEY: "1".repeat(64),
    ACCOUNT_EMAIL_LOOKUP_KEY: "2".repeat(64),
    ACCOUNT_AUTH_LOCATOR_KEY: "3".repeat(64),
  });
  const store = oidcStore(h.env, h.dependencies);
  async function login(
    displayName?: string,
    subject = "profile-subject",
    email = "profile@gmail.com",
  ) {
    const id = crypto.randomUUID(),
      stateHash = crypto.randomUUID(),
      browserHash = crypto.randomUUID(),
      claimNonce = crypto.randomUUID();
    await store.createTransaction({
      id,
      stateHash,
      browserHash,
      ipHash: crypto.randomUUID(),
      secretsCiphertext: "fixture",
      returnMode: "redirect",
      previousSessionTokenHash: null,
      policyAuthorization: POLICY_AUTHORIZATION,
    });
    assert.ok(
      await store.claimTransaction({ stateHash, browserHash, claimNonce }),
    );
    const token = toHex(crypto.getRandomValues(new Uint8Array(32)));
    const sessionTokenHash = toHex(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token)),
    );
    await store.completeGoogleLogin({
      transactionId: id,
      claimNonce,
      sessionTokenHash,
      identity: {
        issuer: "https://accounts.google.com",
        subject,
        email,
        emailVerified: true,
        authoritativeEmail: true,
        hostedDomain: null,
        displayName,
      },
    });
    return `__Host-accreatio_session=${token}`;
  }
  return { ...h, profileLogin: login };
}

test("Google profile name is bounded Unicode display data only", () => {
  const now = Math.floor(Date.now() / 1000);
  const claims = {
    iss: "https://accounts.google.com",
    sub: "subject",
    aud: "client",
    iat: now,
    exp: now + 3600,
  };
  assert.equal(
    googleIdentity({ ...claims, name: "  Ed  Lo\u0301pez  " }).displayName,
    "Ed López",
  );
  for (const name of [
    undefined,
    "",
    " ",
    42,
    "x".repeat(121),
    "private\nname",
    "spoof\u202ename",
    "\ud800",
  ])
    assert.equal(googleIdentity({ ...claims, name }).displayName, null);
  assert.equal(
    googleIdentity({ ...claims, name: "李 明" }).displayName,
    "李 明",
  );
});

test("profile name is encrypted, refreshed and exported without changing identity, contact or quota", async () => {
  const h = await setup();
  const cookie = await h.profileLogin("Ed López");
  const first = h.db.sqlite.prepare("SELECT * FROM accounts").get()!;
  assert.equal(
    (await (await h.call("session", { method: "GET", cookie })).json())
      .displayName,
    "Ed López",
  );
  assert.ok(first.display_name_ciphertext);
  assert.equal(
    first.privacy_notice_version,
    POLICY_AUTHORIZATION.privacyNoticeVersion,
  );
  assert.ok(!String(first.display_name_ciphertext).includes("Ed"));
  await h.controlProof(cookie, "data");
  assert.equal(
    (await (await h.call("data", { method: "GET", cookie })).json())
      .displayName,
    "Ed López",
  );
  await h.call("authorize", {
    cookie,
    body: { operationId: crypto.randomUUID() },
  });
  const changed = await h.profileLogin("Ed Updated");
  const second = h.db.sqlite.prepare("SELECT * FROM accounts").get()!;
  assert.equal(second.id, first.id);
  assert.equal(second.identity_key, first.identity_key);
  assert.equal(second.email_ciphertext, first.email_ciphertext);
  const session = await (
    await h.call("session", { method: "GET", cookie: changed })
  ).json();
  assert.equal(session.displayName, "Ed Updated");
  assert.equal(session.remaining, 4);
  const missing = await h.profileLogin();
  assert.equal(
    (await (await h.call("session", { method: "GET", cookie: missing })).json())
      .displayName,
    "Ed Updated",
  );
  await h.controlProof(missing, "delete");
  assert.equal((await h.call("delete", { cookie: missing })).status, 200);
  assert.equal(
    h.db.sqlite.prepare("SELECT display_name_ciphertext FROM accounts").get()!
      .display_name_ciphertext,
    null,
  );
});

test("legacy and pre-profile accounts retain fallback; rollback deletion trigger purges the additional ciphertext", async () => {
  const h = await setup();
  const cookie = await h.login();
  assert.equal(
    (await (await h.call("session", { method: "GET", cookie })).json())
      .displayName,
    "person",
  );
  const preProfile = await h.profileLogin();
  assert.equal(
    (
      await (
        await h.call("session", { method: "GET", cookie: preProfile })
      ).json()
    ).displayName,
    "profile",
  );
  const named = await h.profileLogin("Private Display");
  assert.equal(
    (await (await h.call("session", { method: "GET", cookie: named })).json())
      .displayName,
    "Private Display",
  );
  // Simulate the compatible older writer: it knows deleted_at but not the new
  // column. Schema 0004 must still purge this PII immediately.
  h.db.sqlite
    .prepare(
      "UPDATE accounts SET deleted_at=? WHERE identity_scheme='federated-v1'",
    )
    .run(h.db.now);
  assert.equal(
    h.db.sqlite
      .prepare(
        "SELECT display_name_ciphertext FROM accounts WHERE identity_scheme='federated-v1'",
      )
      .get()!.display_name_ciphertext,
    null,
  );
  assert.equal(
    h.db.sqlite
      .prepare(
        "SELECT COUNT(*) AS n FROM accounts WHERE identity_scheme='legacy-email-v1' AND deleted_at IS NULL",
      )
      .get()!.n,
    1,
  );
});

test("name encryption rejects email ciphertext and ciphertext from another account", async () => {
  const h = await setup();
  const first = await h.profileLogin("First");
  const row = h.db.sqlite.prepare("SELECT * FROM accounts").get()!;
  h.db.sqlite
    .prepare(
      "UPDATE accounts SET display_name_ciphertext=email_ciphertext WHERE id=?",
    )
    .run(row.id);
  assert.equal(
    (await h.call("session", { method: "GET", cookie: first })).status,
    503,
  );
  const second = await h.profileLogin(
    "Second",
    "profile-2",
    "profile2@gmail.com",
  );
  h.db.sqlite
    .prepare("UPDATE accounts SET display_name_ciphertext=? WHERE id!=?")
    .run(row.display_name_ciphertext, row.id);
  assert.equal(
    (await h.call("session", { method: "GET", cookie: second })).status,
    503,
  );
});
