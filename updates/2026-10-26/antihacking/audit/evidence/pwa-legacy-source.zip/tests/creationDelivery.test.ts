import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import * as React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { DeliveryStage } from "../src/components/creation/DeliveryStage";
import {
  creationFocusTarget,
  TeamStage,
} from "../src/components/creation/TeamStage";
import { defaultOrchestration, type ProjectDefinition } from "../src/types";

// The repository's test tsconfig uses classic JSX; expose React for existing
// creation primitives that intentionally rely on Vite's automatic runtime.
Object.assign(globalThis, { React });

const project: ProjectDefinition = {
  name: "Demo",
  phase: "idea",
  context: "Context",
  restrictions: "",
  route: "local",
  action: "repository",
  destination: "/projects",
  participants: [
    { id: "participant-01", role: "generalist", label: "Global view" },
  ],
  attachments: [],
  initializeGit: false,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: true,
  orchestration: defaultOrchestration(),
};
const responsibilities = {
  generalist: { es: "Visión global", en: "Global view" },
  architect: { es: "Diseño", en: "Design" },
  implementer: { es: "Implementación", en: "Implementation" },
  auditor: { es: "Auditoría", en: "Audit" },
};

test("Team preserves ordered participants, repeated roles, responsibilities, and Mode 1 disclosure", () => {
  const html = renderToStaticMarkup(
    React.createElement(TeamStage, {
      project,
      locale: "en",
      isWeb: false,
      errors: {},
      errorText: () => undefined,
      onAddParticipant: () => {},
      onChange: () => {},
      onConfigureMode1: () => {},
      mode1TriggerRef: { current: null },
      responsibilities,
    }),
  );
  assert.match(html, /1 to 6 · order is preserved/);
  assert.match(html, /participant-01/);
  assert.match(html, /Canonical role/);
  assert.match(html, /Global view/);
  assert.match(html, /Mode 1 orchestration · manual mode/);
  assert.match(html, /Prepare Mode 1 configuration/);
});

// Dry-run deliberately no longer lives here: it moved to Review, beside the
// button whose consequence it changes. See ReviewStage and design-v10.
test("Delivery exposes equivalent action, destination, Git, GitHub, and IDE inputs", () => {
  const html = renderToStaticMarkup(
    React.createElement(DeliveryStage, {
      project,
      locale: "en",
      isWeb: false,
      errors: {},
      errorText: () => undefined,
      onBrowseDestination: () => {},
      onChange: () => {},
      onOpenSettings: () => {},
    }),
  );
  for (const text of [
    "Create a project folder",
    "Create tracking only",
    "Create project and tracking",
    "Destination folder",
    "Initialize Git",
    "Create private GitHub remote",
    "Open in the IDE",
    "GitHub never pushes automatically",
  ])
    assert.match(html, new RegExp(text));
  assert.match(html, /Existing files receive versioned copies/);
  assert.doesNotMatch(html, /Dry run|dry-run-choice/);
});

test("web Delivery is truthful about ZIP output and local-tool limitations", () => {
  const html = renderToStaticMarkup(
    React.createElement(DeliveryStage, {
      project: { ...project, destination: "browser-download" },
      locale: "en",
      isWeb: true,
      errors: {},
      errorText: () => undefined,
      onBrowseDestination: () => {},
      onChange: () => {},
      onOpenSettings: () => {},
    }),
  );
  assert.match(html, /Download a project ZIP/);
  assert.match(html, /accreatio is web-only and does not run local tracking/);
  assert.match(html, /add guides to the ZIP; they do not run local tools/);
  assert.match(html, /prepared in this tab and downloaded as a ZIP/);
});

test("App wires Team and Delivery into stage validation and the shared workspace pattern", () => {
  const app = readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
  assert.match(app, /creationStage === "team"/);
  assert.match(app, /creationStage === "delivery"/);
  assert.match(
    app,
    /errors\.participants \|\| errors\.orchestration \|\| errors\.funding/,
  );
  assert.equal(
    creationFocusTarget("delivery", { destination: "required" }),
    "project-destination",
  );
  assert.match(app, /<TeamStage/);
  assert.match(app, /<DeliveryStage/);
});
