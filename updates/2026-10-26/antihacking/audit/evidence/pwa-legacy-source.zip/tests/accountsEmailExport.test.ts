import assert from "node:assert/strict";
import test from "node:test";
import { handleEmailExport } from "../functions/api/admin/accounts/emails";
import { harness } from "./helpers/accountHarness";

test("email export requires a separate human owner allowlist and paginates without duplicates", async () => {
  const h = await harness();
  const env = {
    ...h.env,
    BLOG_ACCESS_ISSUER: h.env.ACCOUNT_ACCESS_ISSUER,
    BLOG_ACCESS_AUDIENCES: h.env.ACCOUNT_ACCESS_AUDIENCES,
    BLOG_HUMAN_ADMINS: JSON.stringify({
      "person@example.test": { sub: "verified-human", label: "owner" },
    }),
    ACCOUNT_EMAIL_ADMINS: "{}",
  };
  async function request(after = "", claims = {}) {
    return handleEmailExport(
      {
        request: new Request(
          `https://accreatio.pages.dev/api/admin/accounts/emails?after=${after}`,
          {
            headers: { "Cf-Access-Jwt-Assertion": await h.token(claims) },
          },
        ),
        env,
      },
      h.dependencies,
    );
  }
  assert.equal((await request()).status, 403);
  env.ACCOUNT_EMAIL_ADMINS = env.BLOG_HUMAN_ADMINS;
  assert.equal((await request("", { sub: "different-subject" })).status, 403);
  assert.equal((await request("invalid")).status, 400);
  for (let i = 0; i < 501; i++) {
    h.db.sqlite
      .prepare(
        "INSERT INTO accounts (id, identity_key, email, created_at, last_seen_at) VALUES (?, ?, ?, 0, 0)",
      )
      .run(crypto.randomUUID(), `test-${i}`, `test-${i}@example.test`);
  }
  const response = await request();
  assert.equal(response.status, 200);
  assert.equal(response.headers.get("Cache-Control"), "no-store");
  const first = await response.json();
  assert.equal(first.emails.length, 500);
  const second = await (await request(first.nextCursor)).json();
  assert.equal(second.emails.length, 1);
  assert.equal(second.nextCursor, null);
  assert.equal(new Set([...first.emails, ...second.emails]).size, 501);
});
