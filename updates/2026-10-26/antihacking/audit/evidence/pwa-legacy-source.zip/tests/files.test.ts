import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { copyVersioned, writeVersioned } from "../electron/files";

test("versioned writes and attachment copies never overwrite existing files", async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), "accreatio-files-"));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const source = path.join(root, "source.txt");
  const destination = path.join(root, "destination");
  await fs.writeFile(source, "new source");
  await fs.mkdir(destination);
  await fs.writeFile(path.join(destination, "source.txt"), "original");

  const copied = await copyVersioned(source, destination, "source.txt");
  assert.equal(path.basename(copied), "source (1).txt");
  assert.equal(
    await fs.readFile(path.join(destination, "source.txt"), "utf8"),
    "original",
  );
  assert.equal(await fs.readFile(copied, "utf8"), "new source");

  const first = await writeVersioned(destination, "project.md", "one");
  const second = await writeVersioned(destination, "project.md", "two");
  assert.equal(path.basename(first), "project.md");
  assert.equal(path.basename(second), "project (1).md");
});

test("concurrent intentional writes still create base and versioned files", async (t) => {
  const root = await fs.mkdtemp(
    path.join(os.tmpdir(), "accreatio-files-concurrent-"),
  );
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const written = await Promise.all([
    writeVersioned(root, "prompt.md", "first"),
    writeVersioned(root, "prompt.md", "second"),
  ]);
  assert.deepEqual(written.map((file) => path.basename(file)).sort(), [
    "prompt (1).md",
    "prompt.md",
  ]);
});

test("Electron privileged copy boundary requires a real desktop attachment path", async () => {
  const source = await fs.readFile(
    new URL("../electron/main.ts", import.meta.url),
    "utf8",
  );
  assert.match(source, /desktop attachment path is required/);
  assert.match(source, /if \(!\("path" in a\)/);
});
