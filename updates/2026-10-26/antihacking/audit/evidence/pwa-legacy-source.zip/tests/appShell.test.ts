import test from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";

const read = (path: string) =>
  readFileSync(new URL(path, import.meta.url), "utf8");
const app = read("../src/App.tsx");
const webEntry = read("../src/main.web.tsx");
const desktopEntry = read("../src/main.desktop.tsx");
const frame = read("../src/components/AppFrame.tsx");
const formation = read("../src/components/FormationMark.tsx");
const brandSvg = read("../src/assets/accreatio-mark.svg");
const aekrSvg = read("../src/assets/aekr-mark.svg");
const status = read("../src/components/StatusNotice.tsx");
const responsive = read("../src/responsive.css");
const styles = read("../src/styles.css");
const webBranding = read("../src/web-branding.css");
const index = read("../index.html");
const manifest = read("../public/manifest.webmanifest");
const packageJson = JSON.parse(read("../package.json")) as {
  build: { win: { icon: string } };
};

test("AppFrame exposes semantic product navigation and existing host destinations", () => {
  assert.match(frame, /<header\s+className=\{`app-header/);
  assert.match(frame, /<nav[\s\S]*aria-label=/);
  assert.match(frame, /aria-current=/);
  for (const destination of [
    "new",
    "orchestrationCenter",
    "settings",
    "history",
    "about",
  ])
    assert.match(app, new RegExp(`"${destination}"`));
  assert.match(webEntry, /id: "blog"/);
  assert.match(webEntry, /extraDestination: blogDestination/);
  assert.doesNotMatch(desktopEntry, /Blog|blog/);
  assert.doesNotMatch(app, /BlogExperience|content\/blog|["']blog["']/);
  assert.match(
    app,
    /onDestinationChange=\{async \(destination\) => \{[\s\S]*?setTab\(destination\);[\s\S]*?setShowOnboarding\(false\)/,
  );
});

test("desktop retains its vector mark and web uses the supplied official raster lockup", () => {
  // Desktop keeps the original mark; the web-only stylesheet replaces its
  // presentation with the owner's complete supplied lettering and symbol.
  assert.match(formation, /accreatio-mark\.svg/);
  assert.match(brandSvg, /viewBox="0 0 256 256"/);
  assert.match(brandSvg, /accreatio orbital a mark/);
  assert.match(brandSvg, /M146 174v-13/);
  assert.doesNotMatch(brandSvg, /<image\b|<rect\b/);
  assert.match(formation, /className="formation-mark"/);
  assert.doesNotMatch(formation, /brand-icon/);
  assert.match(styles, /\.formation-mark img\s*{/);
  assert.match(frame, /onActivate=\{onBrandActivate\}/);
  assert.match(
    app,
    /const openWelcome = \(\) => \{[\s\S]*?setTab\("new"\);[\s\S]*?setShowOnboarding\(true\)/,
  );
  assert.match(app, /onBrandActivate=\{openWelcome\}/);
  assert.match(index, /branding\/accreatio-web-social\.png/);
  assert.match(manifest, /branding\/accreatio-web-192\.png/);
  assert.match(manifest, /branding\/accreatio-web-512\.png/);
  assert.match(webEntry, /import "\.\/web-branding\.css"/);
  assert.doesNotMatch(desktopEntry, /web-branding/);
  for (const theme of ["light", "dark"]) {
    const lockup = read(`../public/branding/accreatio-lockup-${theme}.svg`);
    assert.match(lockup, /<image\b[^>]*href="data:image\/png;base64,/);
    assert.equal([...lockup.matchAll(/<image\b/g)].length, 1);
    assert.doesNotMatch(lockup, /<(?:path|text|polygon|circle|rect)\b/);
    assert.ok(
      webBranding.includes(
        `--web-brand-lockup: url("/branding/accreatio-lockup-${theme}.svg")`,
      ),
    );
  }
  assert.match(
    webBranding,
    /\.formation-mark img\s*{[^}]*content:\s*var\(--web-brand-lockup\)/,
  );
  assert.match(
    webBranding,
    /\.app-shell--web \.about-brand-link img\s*{[^}]*content:\s*var\(--web-brand-lockup\)/,
  );
  assert.equal(packageJson.build.win.icon, "public/icons/accreatio-512.png");
  assert.ok(
    existsSync(new URL(`../${packageJson.build.win.icon}`, import.meta.url)),
  );
});

test("shell carries a subtle local AEKR build signature", () => {
  assert.match(
    frame,
    /<AekrSignature webLinks=\{webFooter\} locale=\{locale\} \/>/,
  );
  assert.match(aekrSvg, /viewBox="0 0 64 64"/);
  assert.doesNotMatch(aekrSvg, /<image\b|<rect\b/);
  assert.match(styles, /\.aekr-signature\s*{[\s\S]*?opacity:\s*0\.84/);
  assert.match(
    styles,
    /\.aekr-signature\s*{[\s\S]*?background:\s*color-mix\([\s\S]*?backdrop-filter:\s*blur\(8px\)/,
  );
});

test("status is scoped, textual, and politely announced", () => {
  assert.match(frame, /<StatusNotice \{\.\.\.status\} \/>/);
  assert.match(status, /role="status"/);
  assert.match(status, /CircleCheck/);
  assert.match(status, /TriangleAlert/);
  assert.doesNotMatch(frame, /<footer/);
  assert.match(app, /Draft saved locally/);
  assert.match(app, /Project not run/);
});

test("shell uses the specified responsive boundaries without a page minimum width", () => {
  assert.match(responsive, /@media \(max-width: 1199px\)/);
  assert.match(responsive, /@media \(max-width: 767px\)/);
  assert.doesNotMatch(responsive, /body\s*{[^}]*min-width:\s*760px/);
  assert.match(styles, /body\s*{[\s\S]*?min-width:\s*0/);
  assert.match(styles, /--touch-target:\s*2\.75rem/);
  assert.match(styles, /\.app-header\s*{[\s\S]*?position:\s*sticky/);
  assert.match(styles, /\.app-shell > \.app-content\s*{/);
  assert.doesNotMatch(
    styles,
    /\.app-shell > :not\([^}]+\)\s*{[\s\S]*?position:\s*relative/,
  );
});

test("language and theme actions retain keyboard-native button behavior", () => {
  assert.match(frame, /Switch to Spanish/);
  assert.match(frame, /Switch to light theme/);
  assert.match(frame, /Switch to dark theme/);
  const buttons = [...frame.matchAll(/<button\b([^>]*)>/g)];
  assert.ok(buttons.length >= 3);
  for (const [, attributes] of buttons)
    assert.match(attributes, /\btype="button"/);
  assert.match(styles, /outline:\s*3px solid var\(--focus-ring\)/);
  assert.match(frame, /className="skip-link"/);
  assert.match(styles, /\.skip-link:focus\s*{[\s\S]*?translateY\(0\)/);
  assert.match(app, /document\.documentElement\.lang = s\.locale/);
  assert.match(app, /const theme = s\.theme/);
  assert.match(app, /theme === "dark" \? "#242726" : "#e8eae7"/);
  assert.doesNotMatch(app, /hideThemeToggle=\{isWeb\}/);
  assert.match(app, /theme=\{s\.theme\}/);
  assert.match(
    app,
    /const toggleTheme = \(\) => \{\s*const theme = s\.theme === "dark" \? "light" : "dark";[\s\S]*?setS\(\(current\) => \(\{ \.\.\.current, theme }\)\)/,
  );
  assert.match(app, /onThemeToggle=\{toggleTheme\}/);
  assert.match(app, /webFooter=\{isWeb\}/);
});
