import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const read = (path: string) =>
  readFileSync(new URL(path, import.meta.url), "utf8");
const styles = read("../src/styles.css");
const responsive = read("../src/responsive.css");
const extras = read("../src/extras.css");
const polish = read("../src/polish.css");
const blog = read("../src/components/BlogExperience.css");
const css = `${styles}\n${responsive}\n${extras}\n${polish}\n${blog}`;

test("reduced motion removes meaningful animation and transition movement", () => {
  assert.match(styles, /@media \(prefers-reduced-motion: reduce\)/);
  assert.match(styles, /scroll-behavior:\s*auto\s*!important/);
  assert.match(styles, /transition-duration:\s*0\.01ms\s*!important/);
  assert.match(styles, /animation-duration:\s*0\.01ms\s*!important/);
  assert.match(styles, /animation-iteration-count:\s*1\s*!important/);
  assert.match(polish, /@media \(prefers-reduced-motion: reduce\)/);
});

test("interactive control families retain the 44px target contract", () => {
  assert.match(styles, /--touch-target:\s*2\.75rem/);
  for (const selector of [
    ".product-nav button",
    ".header-actions button",
    ".stage-navigation__item",
    ".review-stage__status button",
    ".review-prompt__head button",
    ".choice-cards button",
  ]) {
    const escaped = selector.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    assert.match(
      css,
      new RegExp(
        `${escaped}\\s*\\{[\\s\\S]*?min-height:\\s*var\\(--touch-target\\)`,
      ),
    );
  }
  assert.match(extras, /\.secondary\s*{[\s\S]*?min-height:\s*44px/);
  assert.match(polish, /\.fatal-error button\s*{[\s\S]*?min-height:\s*44px/);
});

test("320px layouts contain intrinsic content and never impose a desktop width", () => {
  assert.match(responsive, /@media \(max-width: 767px\)/);
  assert.match(
    responsive,
    /\.creation-workspace\s*{[\s\S]*?padding:\s*8px 16px/,
  );
  assert.match(
    styles,
    /html,[\s\S]*?#root\s*{[\s\S]*?max-width:\s*100%[\s\S]*?overflow-x:\s*clip/,
  );
  assert.match(
    responsive,
    /\.review-prompt pre\s*{[\s\S]*?overflow-wrap:\s*anywhere/,
  );
  assert.match(
    responsive,
    /\.settings-page,[\s\S]*?\.review-prompt pre\s*{[\s\S]*?min-width:\s*0[\s\S]*?max-width:\s*100%/,
  );
  assert.doesNotMatch(css, /min-width:\s*(?:[4-9]\d\d|[1-9]\d{3,})px/);
});

test("responsive IA switches rail to strip then selector at approved boundaries", () => {
  assert.match(
    responsive,
    /@media \(max-width: 1199px\)[\s\S]*?\.stage-navigation ol\s*{[\s\S]*?repeat\(5/,
  );
  assert.match(
    responsive,
    /@media \(max-width: 767px\)[\s\S]*?\.stage-navigation\s*{[\s\S]*?display:\s*none/,
  );
  assert.match(
    responsive,
    /@media \(max-width: 767px\)[\s\S]*?\.stage-selector\s*{[\s\S]*?display:\s*grid/,
  );
  assert.match(
    responsive,
    /@media \(max-width: 767px\)[\s\S]*?\.stage-navigation__feedback\s*{[\s\S]*?display:\s*block/,
  );
  assert.match(
    responsive,
    /@media \(max-width: 767px\)[\s\S]*?\.creation-stage input,[\s\S]*?scroll-margin-top:\s*13rem/,
  );
  assert.match(
    responsive,
    /@media \(max-width: 600px\)[\s\S]*?\.mode1-dialog\s*{[\s\S]*?inset:\s*0/,
  );
  assert.match(
    responsive,
    /@media \(max-width: 1199px\)[\s\S]*?\.app-header\s*{[\s\S]*?"brand actions" "nav nav" "status status"/,
  );
  assert.match(
    blog,
    /@media \(max-width: 767px\)[\s\S]*?main\.blog-page\s*{[\s\S]*?padding:\s*8px 16px/,
  );
  assert.match(
    blog,
    /@media \(max-width: 767px\)[\s\S]*?\.blog-admin__row\s*{[\s\S]*?grid-template-columns:\s*1fr/,
  );
});
