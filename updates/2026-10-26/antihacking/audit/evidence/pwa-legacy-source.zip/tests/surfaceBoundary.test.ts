import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";

const read = (relative: string) =>
  readFileSync(new URL(relative, import.meta.url), "utf8");

test("web and desktop have distinct renderer entries and outputs", () => {
  const vite = read("../vite.config.mts");
  const webDocument = read("../index.html");
  const desktopDocument = read("../desktop.html");
  const electron = read("../electron/main.ts");

  assert.match(webDocument, /src\/main\.web\.tsx/);
  assert.match(webDocument, /manifest\.webmanifest/);
  assert.match(desktopDocument, /src\/main\.desktop\.tsx/);
  assert.doesNotMatch(
    desktopDocument,
    /manifest\.webmanifest|service.?worker/i,
  );
  assert.match(vite, /mode === "desktop"/);
  assert.match(vite, /outDir: "dist-desktop"/);
  assert.match(vite, /publicDir: desktop \? false : "public"/);
  assert.match(vite, /!desktop &&\s*VitePWA/);
  assert.match(electron, /dist-desktop", "desktop\.html"/);
  assert.doesNotMatch(electron, /"dist", "index\.html"/);
});

test("only the web entry contributes the optional Blog and PWA graph", () => {
  const sharedEntry = read("../src/main.tsx");
  const webEntry = read("../src/main.web.tsx");
  const desktopEntry = read("../src/main.desktop.tsx");
  const app = read("../src/App.tsx");

  assert.match(webEntry, /components\/BlogExperience/);
  assert.match(webEntry, /serviceWorker\.register/);
  assert.match(webEntry, /extraDestination: blogDestination/);
  assert.doesNotMatch(desktopEntry, /Blog|blog|pwa|serviceWorker/);
  assert.doesNotMatch(
    sharedEntry,
    /BlogExperience|content\/blog|virtual:pwa|serviceWorker/,
  );
  assert.doesNotMatch(app, /BlogExperience|content\/blog|["']blog["']/);
  assert.match(app, /extraDestination\.render/);
  assert.match(
    app,
    /\["new", "orchestrationCenter", "settings", "history", "about"\]/,
  );
});

test("artifact scan fails closed on Blog administration and PWA leakage", () => {
  const scanner = read("../scripts/surface-boundary-smoke.mjs");
  assert.match(scanner, /Introducing accreatio/);
  assert.match(scanner, /Nebula made ideas for accreatio/);
  assert.match(scanner, /A small paradox, but a paradox after all/);
  assert.match(scanner, /\/api\\\/\(\?:admin\\\/\)\?blog/);
  assert.match(scanner, /manifest\\\.webmanifest/);
  assert.match(scanner, /PWA manifest/);
  assert.match(scanner, /service worker/);
  assert.match(scanner, /workbox/);
  assert.match(scanner, /canPublish/);
  assert.match(scanner, /Web surface markers missing/);
});
