import test from "node:test";
import assert from "node:assert/strict";
import {
  DRAFT_SCHEMA_VERSION,
  ONBOARDING_SCHEMA_VERSION,
  loadOnboardingPreference,
  normalizeDraft,
  normalizeDraftWithWarnings,
  saveOnboardingCompletion,
  serializeDraft,
} from "../src/draftStore";
import { defaultOrchestration } from "../shared/domain";
import { validationErrors } from "../shared/domain";
import type { ProjectDefinition } from "../src/types";

const fallback: ProjectDefinition = {
  name: "",
  phase: "idea",
  context: "",
  restrictions: "",
  route: "local",
  action: "repository",
  destination: "browser-download",
  participants: [{ id: "participant-01", role: "generalist", label: "" }],
  attachments: [],
  initializeGit: false,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: true,
  orchestration: defaultOrchestration(),
};

const legacy = {
  ...fallback,
  participants: undefined,
  agents: [
    { id: "legacy-architect", role: "architect", label: "  Exact label  " },
    { id: "legacy-auditor", role: "auditor", label: "Audit" },
  ],
  orchestration: {
    enabled: true,
    roles: [
      { role: "architect", provider: "codex", task: "  Exact task  " },
      { role: "auditor", provider: "claude_code", task: "Audit exactly" },
    ],
    sessionMaxDurationSeconds: 3600,
    maxIterationsPerEntity: 2,
    maxProviderInvocations: 8,
    maxConsecutiveFailures: 2,
  },
};

test("onboarding completion is versioned, local, and does not alter drafts", () => {
  const values = new Map<string, string>();
  const storage = {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => values.set(key, value),
  };
  assert.deepEqual(loadOnboardingPreference(storage), {
    completed: false,
    storageAvailable: true,
  });
  assert.equal(saveOnboardingCompletion(storage), true);
  assert.deepEqual(loadOnboardingPreference(storage), {
    completed: true,
    storageAvailable: true,
  });
  assert.equal(values.size, 1);
  assert.match(
    [...values.values()][0],
    new RegExp(`"schemaVersion":${ONBOARDING_SCHEMA_VERSION}`),
  );
});

test("onboarding storage failures fail open with a truthful recovery state", () => {
  const unavailable = {
    getItem: () => {
      throw new Error("blocked");
    },
    setItem: () => {
      throw new Error("blocked");
    },
  };
  assert.deepEqual(loadOnboardingPreference(unavailable), {
    completed: false,
    storageAvailable: false,
  });
  assert.equal(saveOnboardingCompletion(unavailable), false);
});

test("normalizeDraft migrates a legacy project without orchestration", () => {
  const migrated = normalizeDraft(
    { ...legacy, name: "Legacy", orchestration: undefined },
    fallback,
  );
  assert.equal(migrated?.name, "Legacy");
  assert.equal(migrated?.participants[0].id, "legacy-architect");
  assert.equal(migrated?.orchestration.participants.length, 2);
});

test("normalizeDraft reads the versioned envelope and rejects corrupt values", () => {
  const migrated = normalizeDraft(
    { schemaVersion: 4, project: { ...fallback, name: "Current" } },
    fallback,
  );
  assert.equal(migrated?.name, "Current");
  assert.equal(normalizeDraft("corrupt", fallback), null);
});

test("draft restoration rejects malformed renderable values before installation", () => {
  for (const malformed of [
    { name: { text: "broken" } },
    { context: 17 },
    { restrictions: null },
    { phase: "unknown" },
    { route: [] },
    { destination: false },
    { initializeGit: "false" },
    { orchestration: { roles: [null] } },
    { context: "x".repeat(20_001) },
    { unexpected: "field" },
  ]) {
    assert.equal(
      normalizeDraft(
        { schemaVersion: 5, project: { ...fallback, ...malformed } },
        fallback,
      ),
      null,
      JSON.stringify(malformed).slice(0, 100),
    );
  }
});

test("unfinished valid drafts remain restorable after shape validation", () => {
  const incomplete = normalizeDraftWithWarnings(
    {
      schemaVersion: 5,
      project: { ...fallback, name: "", context: "", restrictions: "" },
    },
    fallback,
  );
  assert.ok(incomplete);
  assert.equal(incomplete.project.name, "");
  assert.equal(incomplete.project.context, "");
  assert.equal(validationErrors(incomplete.project).name, "required");
});

test("v1 direct and v2 envelopes migrate losslessly by ID, order, label, task, provider, and limits", () => {
  for (const value of [
    legacy,
    { schemaVersion: 1, project: legacy },
    { schemaVersion: 2, project: legacy },
  ]) {
    const migrated = normalizeDraft(value, fallback)!;
    assert.deepEqual(
      migrated.participants.map(({ id, role, label }) => ({ id, role, label })),
      legacy.agents,
    );
    assert.deepEqual(migrated.orchestration.participants, [
      {
        participantId: "legacy-architect",
        provider: "codex",
        task: "  Exact task  ",
      },
      {
        participantId: "legacy-auditor",
        provider: "claude_code",
        task: "Audit exactly",
      },
    ]);
    assert.equal(migrated.orchestration.sessionMaxDurationSeconds, 3600);
  }
});

test("v5 attachment schema is stable, future versions fail closed, and corrupt IDs recover visibly", () => {
  assert.equal(DRAFT_SCHEMA_VERSION, 5);
  const current = { ...fallback, name: "Current" };
  const normalized = normalizeDraft(
    { schemaVersion: 4, project: current },
    fallback,
  )!;
  assert.deepEqual(
    normalizeDraft({ schemaVersion: 5, project: normalized }, fallback),
    normalized,
  );
  assert.equal(
    normalizeDraft({ schemaVersion: 6, project: current }, fallback),
    null,
  );
  const recovered = normalizeDraftWithWarnings(
    {
      ...legacy,
      agents: [
        { ...legacy.agents[0], id: "bad id" },
        { ...legacy.agents[1], id: "bad id" },
      ],
    },
    fallback,
  )!;
  assert.deepEqual(
    recovered.project.participants.map(({ id }) => id),
    ["participant-01", "participant-02"],
  );
  assert.ok(recovered.warnings.includes("participantIdentityRecovered"));
});

test("v5 serializer strips attachment metadata and retains only a count marker", () => {
  const stored = serializeDraft({
    ...fallback,
    attachments: [{ name: "secret.pdf", extension: ".pdf", size: 12 }],
  });
  assert.deepEqual(stored.project.attachments, []);
  assert.deepEqual(stored.transientAttachments, { count: 1 });
  assert.doesNotMatch(JSON.stringify(stored), /secret\.pdf|\.pdf|"size":12/);
  const restored = normalizeDraftWithWarnings(stored, fallback)!;
  assert.deepEqual(restored.project.attachments, []);
  assert.equal(restored.transientAttachmentCount, 1);
});

test("account context stays outside the domain project and navigation survives normalization", () => {
  const project = { ...fallback, name: "Bound account project" };
  const navigation = {
    question: "review",
    hasReviewed: true,
    locale: "es" as const,
  };
  const envelope = {
    ...serializeDraft(project, navigation, 3),
    ownerKey: `v1:${"a".repeat(64)}`,
    sessionKey: `v1:${"b".repeat(64)}`,
    generation: "opaque-generation",
  };
  const normalized = normalizeDraftWithWarnings(envelope, fallback)!;
  assert.deepEqual(
    normalized.project,
    normalizeDraft(serializeDraft(project), fallback),
  );
  assert.deepEqual(normalized.navigation, navigation);
  assert.equal(normalized.transientAttachmentCount, 3);
  assert.equal("ownerKey" in normalized.project, false);
  assert.equal("sessionKey" in normalized.project, false);
  assert.equal("generation" in normalized.project, false);
});

test("v4 to v5 migration strips legacy attachment values and caps the count-only notice", () => {
  const value = {
    schemaVersion: 4,
    project: {
      ...fallback,
      attachments: Array.from({ length: 25 }, (_, index) => ({
        name: `private-${index}.txt`,
        path: `/tmp/${index}`,
        blob: new Blob([String(index)]),
      })),
    },
  };
  const restored = normalizeDraftWithWarnings(value, fallback)!;
  assert.deepEqual(restored.project.attachments, []);
  assert.equal(restored.transientAttachmentCount, 20);
});

test("both registered providers and mixed assignments remain stable", () => {
  const migrated = normalizeDraft(
    { schemaVersion: 3, project: legacy },
    fallback,
  )!;
  assert.deepEqual(
    migrated.orchestration.participants.map(({ participantId, provider }) => ({
      participantId,
      provider,
    })),
    [
      { participantId: "legacy-architect", provider: "codex" },
      { participantId: "legacy-auditor", provider: "claude_code" },
    ],
  );
});

test("missing funding migrates to subscription while explicit invalid funding is preserved", () => {
  for (const value of [
    legacy,
    { schemaVersion: 1, project: legacy },
    { schemaVersion: 2, project: legacy },
    { schemaVersion: 3, project: legacy },
  ]) {
    assert.deepEqual(
      normalizeDraft(value, fallback)?.orchestration.funding,
      defaultOrchestration().funding,
    );
  }
  const explicitInvalid = {
    mode: "api",
    providerId: "codex",
    modelProfileId: "unsupported",
    currency: "USD",
    maxCost: "10",
    hardStopAcknowledged: true,
  };
  const migrated = normalizeDraft(
    {
      schemaVersion: 4,
      project: {
        ...fallback,
        orchestration: {
          ...fallback.orchestration,
          enabled: false,
          participants: [
            {
              participantId: "participant-01",
              provider: "codex",
              task: "Do not call a provider",
            },
          ],
          funding: explicitInvalid,
        },
      },
    },
    fallback,
  )!;
  assert.deepEqual(migrated.orchestration.funding, explicitInvalid);
  assert.equal(validationErrors(migrated).funding, "api_not_supported");
});

test("unknown provider IDs are preserved, warned, and block validation", () => {
  const current = {
    ...fallback,
    name: "Unknown provider",
    context: "Context",
    orchestration: {
      ...fallback.orchestration,
      enabled: true,
      participants: [
        {
          participantId: "participant-01",
          provider: "future_provider",
          task: "Review the provider assignment",
        },
      ],
    },
  };
  const migrated = normalizeDraftWithWarnings(
    { schemaVersion: 3, project: current },
    fallback,
  )!;
  assert.equal(
    migrated.project.orchestration.participants[0].provider,
    "future_provider",
  );
  assert.ok(migrated.warnings.includes("unknownProviderNeedsReview"));
  assert.equal(
    validationErrors(migrated.project).orchestration,
    "invalidOrchestrationParticipants",
  );
});
