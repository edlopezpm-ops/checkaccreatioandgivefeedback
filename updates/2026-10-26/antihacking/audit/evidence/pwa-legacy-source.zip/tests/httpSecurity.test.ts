import assert from "node:assert/strict";
import test from "node:test";
import { ApiError, errorResponse, jsonResponse } from "../functions/_lib/http";

test("API JSON and failures retain host-only HTTPS policy and safe retry metadata", (t) => {
  t.mock.method(console, "error", () => {});
  const responses = [
    jsonResponse({ ok: true }),
    errorResponse(
      new ApiError(429, "limited", "Try again later.", 3.2),
      "fixture",
    ),
    errorResponse(new Error("not public"), "fixture"),
  ];
  for (const response of responses) {
    assert.equal(
      response.headers.get("Strict-Transport-Security"),
      "max-age=86400",
    );
    assert.equal(response.headers.get("X-Content-Type-Options"), "nosniff");
    assert.equal(response.headers.get("X-Frame-Options"), "DENY");
    assert.equal(response.headers.get("Referrer-Policy"), "no-referrer");
    assert.equal(response.headers.get("Cache-Control"), "no-store");
  }
  assert.equal(responses[0].headers.get("Retry-After"), null);
  assert.equal(responses[1].headers.get("Retry-After"), "4");
  assert.equal(responses[2].headers.get("Retry-After"), null);
  for (const value of [NaN, Infinity, -2, 0])
    assert.equal(
      new ApiError(429, "limited", "Retry.", value).retryAfterSeconds,
      undefined,
    );
  assert.equal(
    new ApiError(503, "busy", "Retry.", 999999).retryAfterSeconds,
    86400,
  );
});
