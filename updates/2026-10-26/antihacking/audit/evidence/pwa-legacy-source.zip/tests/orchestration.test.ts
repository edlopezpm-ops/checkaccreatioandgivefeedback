import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import { readFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { EventEmitter } from "node:events";
import {
  OrchestrationController,
  orchestrationPaths,
  parseAekrSnapshot,
  type SpawnOrchestrator,
} from "../electron/orchestration";

const validState = (overrides: Record<string, unknown> = {}) => ({
  schema_version: 2,
  run_id: "run-1",
  project_name: "example",
  lifecycle: "WAITING_HUMAN_APPROVAL",
  revision: 4,
  current_step_index: 0,
  active_attempt: {
    attempt_id: "attempt-1",
    step_index: 0,
    phase: "WAITING_EXECUTION_APPROVAL",
  },
  correlation_id: "correlation-1",
  work_session_id: "session-1",
  ...overrides,
});

test("snapshot parser fails closed on unknown schemas and inconsistent gates", () => {
  assert.throws(
    () => parseAekrSnapshot(validState({ schema_version: 3 })),
    /unsupported/i,
  );
  assert.throws(
    () => parseAekrSnapshot(validState({ active_attempt: null })),
    /gate-waiting/i,
  );
  assert.equal(parseAekrSnapshot(validState()).revision, 4);
});

test("controller launches fixed argv without a shell and gates stdin decisions", async () => {
  const root = await fs.mkdtemp(
    path.join(os.tmpdir(), "accreatio-orchestration-"),
  );
  const toolkitDir = path.join(root, "toolkit");
  const projectDir = path.join(root, "project");
  const controlRoot = path.join(root, "control");
  const configPath = path.join(
    projectDir,
    ".ai-engineering",
    "orchestration.yaml",
  );
  await fs.mkdir(path.join(toolkitDir, "runtime"), { recursive: true });
  await fs.mkdir(projectDir);
  await fs.mkdir(path.dirname(configPath));
  await fs.writeFile(path.join(toolkitDir, "runtime", "cli.py"), "");
  await fs.writeFile(configPath, "mode: 1\n");

  const events = new EventEmitter();
  const writes: string[] = [];
  let invocation: Parameters<SpawnOrchestrator> | undefined;
  const spawn: SpawnOrchestrator = (...args) => {
    invocation = args;
    return Object.assign(events, {
      stdin: { write: (chunk: string) => (writes.push(chunk), true) },
    });
  };
  const controller = new OrchestrationController(spawn);
  const paths = await controller.start({
    toolkitDir,
    projectDir,
    controlRoot,
    configPath,
  });
  const canonicalProjectDir = await fs.realpath(projectDir);
  const canonicalConfigPath = await fs.realpath(configPath);
  const canonicalControlRoot = await fs.realpath(controlRoot);
  assert.deepEqual(invocation?.[1], [
    "-B",
    "-m",
    "runtime.cli",
    "--config",
    canonicalConfigPath,
    "--project-dir",
    canonicalProjectDir,
  ]);
  assert.equal(invocation?.[2].shell, false);
  assert.equal(invocation?.[2].env.AEKR_CONTROL_ROOT, canonicalControlRoot);

  await fs.mkdir(paths.controlDir, { recursive: true });
  await fs.writeFile(paths.statePath, JSON.stringify(validState()));
  await controller.decide("approve");
  assert.deepEqual(writes, ["1\n"]);
  await assert.rejects(controller.decide("reject"), /already submitted/i);

  await fs.writeFile(
    paths.statePath,
    JSON.stringify(validState({ revision: 5, lifecycle: "RUNNING" })),
  );
  await assert.rejects(controller.decide("pause"), /not waiting/i);
  await controller.cancel();
  assert.match(await fs.readFile(paths.stopPath, "utf8"), /cancel requested/i);
  setTimeout(() => events.emit("close", 0), 0);
  await controller.shutdown(50);
});

test("control state location is deterministic and outside the project", () => {
  const paths = orchestrationPaths({
    toolkitDir: "/tmp/toolkit",
    configPath: "/tmp/config.yaml",
    projectDir: "/tmp/project",
    controlRoot: "/tmp/control",
  });
  assert.match(path.basename(paths.controlDir), /^[a-f0-9]{24}$/);
  assert.equal(path.dirname(paths.statePath), paths.controlDir);
});

test("Mode 1 start preflight rejects paid and legacy monetary configuration without fallback", () => {
  const main = readFileSync(
    new URL("../electron/main.ts", import.meta.url),
    "utf8",
  );
  const preflight =
    main.match(
      /async function requireFreshProvidersForConfig[\s\S]*?\n}/,
    )?.[0] ?? "";
  assert.match(preflight, /max_budget_usd/);
  assert.match(preflight, /ceiling/);
  assert.match(preflight, /model_profile/);
  assert.match(preflight, /api_exact_hard_stop_unavailable/);
  assert.doesNotMatch(preflight, /fallback|subscription_cli/);
});
