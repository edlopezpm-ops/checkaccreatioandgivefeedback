import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { Miniflare, convertV4MiniflareOptions } from "miniflare";

test(
  "ambient workerd fetch works through runtimeDependencies and the real OIDC client",
  { timeout: 60_000 },
  async () => {
    const output = await build({
      stdin: {
        contents: `import {runtimeDependencies} from './functions/_lib/platform.ts';
      import {googleClient} from './functions/_lib/auth/oidc.ts';
      import * as oidc from 'openid-client';
      export default { async fetch(request) {
        try {
          if(new URL(request.url).pathname === '/direct') {
            const response = await runtimeDependencies().fetch('https://oauth2.googleapis.com/token', {
              method:'POST', body:new URLSearchParams({grant_type:'authorization_code'}),
              redirect:'manual', signal:AbortSignal.timeout(10000)
            });
            return Response.json({status:response.status});
          }
          await oidc.authorizationCodeGrant(
            googleClient({clientId:'synthetic.apps.googleusercontent.com',clientSecret:'synthetic-secret'}),
            new URL('https://accreatio.pages.dev/api/auth/v1/oidc/google/callback?code=synthetic-code&state=synthetic-state&iss=https%3A%2F%2Faccounts.google.com'),
            {expectedState:'synthetic-state',expectedNonce:'synthetic-nonce',pkceCodeVerifier:'v'.repeat(43),idTokenExpected:true}
          );
          return Response.json({unexpectedSuccess:true}, {status:500});
        } catch(error) {
          return Response.json({providerRejectedClient:error instanceof oidc.ResponseBodyError && error.error==='invalid_client'}, {status:422});
        }
      }};`,
        resolveDir: process.cwd(),
        loader: "ts",
      },
      bundle: true,
      platform: "browser",
      target: "es2022",
      format: "esm",
      write: false,
    });
    let outgoing = 0;
    const options = convertV4MiniflareOptions({
      modules: true,
      script: output.outputFiles[0].text,
      compatibilityDate: "2026-08-06",
      // The actual ambient workerd fetch executes; only its outbound network is
      // replaced. Do not inject/override RuntimeDependencies.fetch in this test.
      outboundService: async (request) => {
        outgoing++;
        assert.equal(request.url, "https://oauth2.googleapis.com/token");
        assert.equal(request.method, "POST");
        const body = new URLSearchParams(await request.text());
        assert.equal(body.get("grant_type"), "authorization_code");
        if (outgoing === 2) {
          assert.equal(
            body.get("client_id"),
            "synthetic.apps.googleusercontent.com",
          );
          assert.equal(body.get("client_secret"), "synthetic-secret");
          assert.equal(body.get("code_verifier"), "v".repeat(43));
        }
        return Response.json({ error: "invalid_client" }, { status: 400 });
      },
    });
    const mf = new Miniflare(options);
    try {
      const direct = await mf.dispatchFetch("https://probe.invalid/direct");
      assert.equal(direct.status, 200);
      assert.deepEqual(await direct.json(), { status: 400 });
      const client = await mf.dispatchFetch("https://probe.invalid/oidc");
      assert.equal(client.status, 422);
      assert.deepEqual(await client.json(), { providerRejectedClient: true });
      assert.equal(outgoing, 2);
    } finally {
      await mf.dispose();
    }
  },
);
