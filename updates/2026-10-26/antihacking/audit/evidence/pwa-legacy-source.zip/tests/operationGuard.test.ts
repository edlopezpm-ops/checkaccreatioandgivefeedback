import test from "node:test";
import assert from "node:assert/strict";
import {
  canonicalJson,
  executionFingerprintValue,
  LogicalOperationGuard,
  validateExecutionRequest,
} from "../src/operationGuard";

type Request = { operationId: string; payload: unknown };
const id = (n: number) =>
  `00000000-0000-4000-8000-${String(n).padStart(12, "0")}`;
const deferred = <T>() => {
  let resolve!: (value: T) => void;
  let reject!: (reason: unknown) => void;
  const promise = new Promise<T>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
};
const tick = () => new Promise<void>((resolve) => setImmediate(resolve));

test("canonical JSON sorts object keys, preserves arrays, and rejects unsafe values", () => {
  assert.equal(
    canonicalJson({ z: 1, a: { d: 2, c: [3, 1] } }),
    '{"a":{"c":[3,1],"d":2},"z":1}',
  );
  assert.throws(() => canonicalJson({ missing: undefined }));
  assert.throws(() => canonicalJson(Number.NaN));
  const cyclic: Record<string, unknown> = {};
  cyclic.self = cyclic;
  assert.throws(() => canonicalJson(cyclic));
});

test("execution fingerprint identity projects attachment metadata without Blob content", () => {
  const projected = executionFingerprintValue({
    operationId: id(1),
    definition: {} as never,
    settings: {} as never,
    webAttachments: [
      { name: "brief.md", size: 4, extension: ".md", blob: {} as Blob },
    ],
  });
  assert.equal(
    canonicalJson(projected),
    '{"definition":{},"settings":{},"webAttachments":[{"extension":".md","name":"brief.md","size":4}]}',
  );
});

test("execution envelope validation is strict and does not log payloads", () => {
  const original = console.log;
  const messages: unknown[] = [];
  console.log = (...values) => messages.push(values);
  try {
    assert.throws(() =>
      validateExecutionRequest({
        operationId: "bad",
        definition: {},
        settings: {},
      }),
    );
    assert.equal(messages.length, 0);
  } finally {
    console.log = original;
  }
});

test("guard reserves synchronously, replays IDs, coalesces in-flight fingerprints, and permits reruns", async () => {
  const barriers = [deferred<string>(), deferred<string>()];
  let calls = 0;
  const guard = new LogicalOperationGuard<Request, string>(
    async (request) => canonicalJson(request.payload),
    async () => barriers[calls++].promise,
  );
  const first = guard.run({ operationId: id(1), payload: { b: 2, a: 1 } });
  const replay = guard.run({ operationId: id(1), payload: { a: 1, b: 2 } });
  const coalesced = guard.run({ operationId: id(2), payload: { a: 1, b: 2 } });
  await tick();
  await tick();
  assert.equal(calls, 1);
  barriers[0].resolve("first");
  assert.deepEqual(await Promise.all([first, replay, coalesced]), [
    "first",
    "first",
    "first",
  ]);
  const rerun = guard.run({ operationId: id(3), payload: { a: 1, b: 2 } });
  await tick();
  await tick();
  assert.equal(calls, 2);
  barriers[1].resolve("second");
  assert.equal(await rerun, "second");
  assert.equal(
    await guard.run({ operationId: id(1), payload: { a: 1, b: 2 } }),
    "first",
  );
  await assert.rejects(
    guard.run({ operationId: id(1), payload: { a: 9 } }),
    /different payload/,
  );
});

test("guard caches failures, releases fingerprints, and evicts only settled IDs", async () => {
  let calls = 0;
  const guard = new LogicalOperationGuard<Request, string>(
    async (request) => canonicalJson(request.payload),
    async () => {
      calls += 1;
      throw new Error(`failure ${calls}`);
    },
    1,
  );
  await assert.rejects(
    guard.run({ operationId: id(1), payload: "same" }),
    /failure 1/,
  );
  await assert.rejects(
    guard.run({ operationId: id(1), payload: "same" }),
    /failure 1/,
  );
  await assert.rejects(
    guard.run({ operationId: id(2), payload: "same" }),
    /failure 2/,
  );
  await assert.rejects(
    guard.run({ operationId: id(1), payload: "same" }),
    /failure 3/,
  );
  assert.equal(calls, 3);
});
