import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  defaultFunding,
  evaluateFundingEligibility,
  normalizeMaxCost,
  parseMinorUnits,
} from "../shared/funding";

test("subscription funding has an exact zero-paid-use default", () => {
  assert.deepEqual(defaultFunding(), {
    mode: "subscription_cli",
    currency: "USD",
    maxCost: "0",
    hardStop: true,
  });
  assert.deepEqual(evaluateFundingEligibility(defaultFunding(), [], []), {
    valid: true,
  });
});

test("money parsing uses canonical USD minor units without Number arithmetic", () => {
  assert.equal(parseMinorUnits("0"), 0n);
  assert.equal(parseMinorUnits("12.3"), 1230n);
  assert.equal(parseMinorUnits("12.34"), 1234n);
  assert.equal(normalizeMaxCost("12.30"), "12.3");
  for (const invalid of [
    "",
    "00",
    "01",
    "+1",
    "-1",
    "1.",
    ".5",
    "1.234",
    "1e2",
    "1,00",
  ])
    assert.equal(parseMinorUnits(invalid), null, invalid);
});

test("malformed and unsupported API policies fail closed with stable reasons", () => {
  assert.equal(
    evaluateFundingEligibility(null, [], []).reasonCode,
    "funding_invalid",
  );
  assert.equal(
    evaluateFundingEligibility(
      {
        mode: "api",
        providerId: "codex",
        modelProfileId: "",
        currency: "USD",
        maxCost: "1",
        hardStopAcknowledged: false,
      },
      [],
      [],
    ).reasonCode,
    "api_acknowledgment_required",
  );
  assert.equal(
    evaluateFundingEligibility(
      {
        mode: "api",
        providerId: "codex",
        modelProfileId: "profile",
        currency: "USD",
        maxCost: "0",
        hardStopAcknowledged: true,
      },
      [],
      [],
    ).reasonCode,
    "funding_invalid",
  );
});

const exactProvider = {
  id: "fixture_provider",
  capabilities: ["api_funding", "exact_cumulative_cost_hard_stop"],
  apiModelProfiles: [
    {
      id: "fixture_exact",
      currency: "USD" as const,
      enforcement: "exact" as const,
      enforcementScope: "cumulative_execution" as const,
      aekrContractVersion: "fixture-v1",
    },
  ],
};
const apiPolicy = {
  mode: "api",
  providerId: "fixture_provider",
  modelProfileId: "fixture_exact",
  currency: "USD",
  maxCost: "5.25",
  hardStopAcknowledged: true,
};

test("only an injected exact cumulative contract fixture is API eligible", () => {
  const assignments = [
    { participantId: "participant-01", provider: "fixture_provider" },
  ];
  assert.deepEqual(
    evaluateFundingEligibility(
      apiPolicy,
      assignments,
      [exactProvider],
      ["fixture-v1"],
    ),
    { valid: true },
  );
  assert.equal(
    evaluateFundingEligibility(
      apiPolicy,
      [{ participantId: "participant-01", provider: "codex" }],
      [exactProvider],
      ["fixture-v1"],
    ).reasonCode,
    "api_provider_mismatch",
  );
  assert.equal(
    evaluateFundingEligibility(apiPolicy, assignments, [exactProvider], [])
      .reasonCode,
    "api_exact_hard_stop_unavailable",
  );
});

test("the Mode 1 dialog exposes subscription and an accessibly explained unavailable API mode", () => {
  const dialog = readFileSync(
    new URL(
      "../src/components/mode1/Mode1ConfigurationDialog.tsx",
      import.meta.url,
    ),
    "utf8",
  );
  const group =
    dialog.match(
      /<fieldset className="mode1-funding-fieldset">[\s\S]*?<\/fieldset>/,
    )?.[0] ?? "";
  assert.match(group, /name="mode1-funding-mode"/);
  assert.match(group, /value="subscription_cli"/);
  assert.match(
    group,
    /value="api"[\s\S]*?disabled[\s\S]*?aria-describedby="mode1-api-funding-unavailable"/,
  );
  assert.match(group, /apiUnavailable/);
  assert.match(group, /maxProviderInvocations/);
  assert.doesNotMatch(group, /credential|payment method|API key field/i);
});

test("desktop preflight rejects paid or legacy monetary configuration without fallback", () => {
  const main = readFileSync(
    new URL("../electron/main.ts", import.meta.url),
    "utf8",
  );
  const preflight =
    main.match(
      /async function requireFreshProvidersForConfig[\s\S]*?\n}/,
    )?.[0] ?? "";
  assert.match(preflight, /max_budget_usd/);
  assert.match(preflight, /ceiling/);
  assert.match(preflight, /model_profile/);
  assert.match(preflight, /api_exact_hard_stop_unavailable/);
  assert.doesNotMatch(preflight, /fallback|subscription_cli/);
});
