import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import test from "node:test";
import { presentBlogAttribution } from "../src/blogAttribution";

const read = (path: string) =>
  readFileSync(new URL(path, import.meta.url), "utf8");

interface FoundingPost {
  id: string;
  slug: string;
  title: string;
  summary: string;
  paragraphs: string[];
  language: "en" | "es";
  author: string;
  authorRole: string;
  signature: string;
  publishedAt: string;
}

const fixture = JSON.parse(read("../content/blog/founding-posts.json")) as {
  schemaVersion: number;
  posts: FoundingPost[];
};
const component = read("../src/components/BlogExperience.tsx");
const webEntry = read("../src/main.web.tsx");
const desktopEntry = read("../src/main.desktop.tsx");

test("the deterministic editorial fixture contains the three owner-authorized posts", () => {
  assert.equal(fixture.schemaVersion, 1);
  assert.deepEqual(
    fixture.posts.map(({ title }) => title),
    [
      "Introducing accreatio",
      "Nebula made ideas for accreatio",
      "A small paradox, but a paradox after all.",
    ],
  );
  assert.deepEqual(
    fixture.posts.map(({ paragraphs }) => paragraphs.length),
    [4, 3, 20],
  );
  assert.equal(fixture.posts[0].authorRole.includes("OpenAI"), true);
  assert.equal(fixture.posts[1].author, "AEKR AI contributor");
  assert.equal(fixture.posts[1].authorRole.includes("AI-assisted"), true);
  assert.equal(fixture.posts[2].author, "Ed Lopez");
  assert.equal(fixture.posts[0].signature, "Made with AI - Codex AEKR mode.");
  assert.equal(
    fixture.posts[1].signature,
    "Created with AI assistance through AEKR.",
  );
  assert.equal(fixture.posts[2].signature, "Ed Lopez");
  assert.equal(
    createHash("sha256")
      .update(fixture.posts[2].paragraphs.join("\n\n"))
      .digest("hex"),
    "1e0247d30c7372958576e4367aeed2174aa23e6d032ef2046cabec3c1b9ca057",
  );
});

test("legacy Claude AI posts use neutral bylines without rewriting stored content", () => {
  const original = {
    ...fixture.posts[1],
    author: "Claude",
    authorRole: "AI system from Anthropic · with Ed Lopez and Codex · AEKR",
    signature: "Made with AI — Claude AEKR mode.",
  };
  const before = JSON.stringify(original);
  assert.deepEqual(presentBlogAttribution(original), {
    author: fixture.posts[1].author,
    authorRole: fixture.posts[1].authorRole,
    signature: fixture.posts[1].signature,
  });
  assert.equal(JSON.stringify(original), before);
  assert.equal(presentBlogAttribution(fixture.posts[1]), fixture.posts[1]);
  assert.equal(presentBlogAttribution(fixture.posts[2]), fixture.posts[2]);
  const human = {
    author: "Claude",
    authorRole: "Engineer",
    signature: "Claude",
  };
  assert.equal(presentBlogAttribution(human), human);
});

test("the web Blog reads the API and exposes append-only publishing controls", () => {
  assert.match(component, /fetch\("\/api\/blog\/posts"/);
  assert.match(component, /fetch\("\/api\/admin\/blog\/session"/);
  assert.match(component, /fetch\("\/api\/admin\/blog\/posts"/);
  assert.match(component, /"Idempotency-Key": key/);
  assert.match(component, /"X-Accreatio-Publish": "blog-v1"/);
  assert.match(component, /crypto\.randomUUID\(\)/);
  assert.match(component, /session\.canPublish && session\.actor/);
  assert.match(component, /Published posts cannot yet be edited or deleted/);
  assert.match(component, /accreatio <span>Blog<\/span>/);
  assert.match(component, /className="blog-post__language"/);
  assert.doesNotMatch(component, /dangerouslySetInnerHTML/);
});

test("Blog and its editorial client remain web-only", () => {
  assert.match(webEntry, /components\/BlogExperience/);
  assert.match(webEntry, /extraDestination: blogDestination/);
  assert.doesNotMatch(desktopEntry, /Blog|blog|api\/admin|api\/blog/);
  assert.doesNotMatch(
    read("../src/App.tsx"),
    /BlogExperience|content\/blog|["']blog["']/,
  );
});
