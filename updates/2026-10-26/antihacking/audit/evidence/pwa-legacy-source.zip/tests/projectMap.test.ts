import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import vm from "node:vm";
import {
  renderProjectMapHtml,
  validateProjectMap,
} from "../scripts/generate-project-map.mjs";

const root = process.cwd();

async function fixtures() {
  const [source, template, html, aekrBanner] = await Promise.all([
    fs.readFile(path.join(root, "project-map.json"), "utf8"),
    fs.readFile(
      path.join(root, "scripts", "project-map.template.html"),
      "utf8",
    ),
    fs.readFile(path.join(root, "accreatio-project-map.html"), "utf8"),
    fs.readFile(path.join(root, "assets", "aekr-banner.png")),
  ]);
  const aekrBannerDataUri = `data:image/png;base64,${aekrBanner.toString("base64")}`;
  return { map: JSON.parse(source), template, html, aekrBannerDataUri };
}

test("project map has unique IDs and every flow resolves through exact edges", async () => {
  const { map } = await fixtures();
  assert.deepEqual(validateProjectMap(map), []);
  assert.ok(map.nodes.length >= 12);
  assert.ok(
    map.flows.some((flow: { status: string }) => flow.status === "planned"),
  );
  assert.ok(
    map.flows.some((flow: { status: string }) => flow.status === "hold"),
  );
});

test("self-contained HTML embeds a byte-equivalent copy of the canonical JSON", async () => {
  const { map, html, aekrBannerDataUri } = await fixtures();
  const embedded = html.match(
    /<script id="project-map-data" type="application\/json">([\s\S]*?)<\/script>/,
  );
  assert.ok(embedded, "embedded project-map data script is missing");
  assert.deepEqual(JSON.parse(embedded[1]), map);
  assert.doesNotMatch(html, /<script\s+[^>]*src=/i);
  assert.doesNotMatch(html, /<link\s+[^>]*href=/i);
  assert.doesNotMatch(html, /\bfetch\s*\(/i);
  assert.doesNotMatch(html, /https?:\/\//i);
  assert.ok(html.includes(`src="${aekrBannerDataUri}"`));
  assert.match(
    html,
    /class="map-footer__aekr"[\s\S]*?alt="Build with AEKR — AI Engineering Knowledge Repo"/,
  );
});

test("committed HTML is generated from the canonical JSON and current template", async () => {
  const { map, template, html, aekrBannerDataUri } = await fixtures();
  assert.equal(html, renderProjectMapHtml(map, template, aekrBannerDataUri));
});

test("viewer exposes responsive, keyboard, status, and reduced-motion affordances", async () => {
  const { html } = await fixtures();
  assert.match(html, /viewBox="0 0 1580 1010"/);
  assert.match(html, /id="architecture"\s+role="group"/);
  assert.match(html, /aria-live="polite"/);
  assert.match(html, /id="clear-flow"/);
  assert.match(html, /prefers-reduced-motion:\s*reduce/);
  assert.match(html, /overflow-x:\s*hidden/);
  assert.doesNotMatch(html, /\.innerHTML\s*=/);
  for (const status of ["current", "upstream", "planned", "hold"])
    assert.match(html, new RegExp(`data-status="${status}"`));
});

test("inline viewer program is syntactically valid JavaScript", async () => {
  const { html } = await fixtures();
  const scripts = [
    ...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g),
  ];
  assert.equal(scripts.length, 2);
  assert.doesNotThrow(() => new vm.Script(scripts[1][1]));
});

test("validator rejects a flow edge that does not connect consecutive steps", async () => {
  const { map } = await fixtures();
  const invalid = structuredClone(map);
  invalid.flows[0].steps[0].edgeId = "e-ui-domain";
  assert.ok(
    validateProjectMap(invalid).some((error) =>
      error.includes("must connect operator to renderer-ui"),
    ),
  );
});
