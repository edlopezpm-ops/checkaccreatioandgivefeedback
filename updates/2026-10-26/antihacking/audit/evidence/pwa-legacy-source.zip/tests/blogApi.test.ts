import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import test from "node:test";
import {
  handleAdminSession,
  handleListPosts,
  handlePublishPost,
} from "../functions/_lib/handlers";
import type {
  BlogBindings,
  BlogDatabase,
  BlogPreparedStatement,
  DatabaseValue,
  RuntimeDependencies,
} from "../functions/_lib/platform";

const ISSUER = "https://accreatio.cloudflareaccess.com";
const AUDIENCE = "audience-123";
const NOW = Date.parse("2026-08-06T12:00:00.000Z");
const NEW_ID = "6add7868-0205-4bf5-91cf-6a2257185de4";
const IDEMPOTENCY_KEY = "10d42a29-c7e0-44cd-a4cf-626f894fecc6";

interface StoredRow {
  readonly id: string;
  readonly slug: string;
  readonly title: string;
  readonly summary: string;
  readonly paragraphs_json: string;
  readonly language: string;
  readonly author: string;
  readonly author_role: string;
  readonly signature: string;
  readonly published_at: string;
  readonly created_at: string;
  readonly actor_kind: string;
  readonly actor_label: string;
  readonly idempotency_key: string;
  readonly publication_status: string;
}

class FakeStatement implements BlogPreparedStatement {
  private values: DatabaseValue[] = [];

  constructor(
    private readonly database: FakeDatabase,
    readonly query: string,
  ) {}

  bind(...values: DatabaseValue[]) {
    this.values = values;
    this.database.calls.push({ query: this.query, values: [...values] });
    return this;
  }

  async first<T>(): Promise<T | null> {
    if (this.database.fail) throw new Error("simulated D1 failure");
    const row = this.database.rows.find(
      (candidate) =>
        candidate.actor_kind === this.values[0] &&
        candidate.actor_label === this.values[1] &&
        candidate.idempotency_key === this.values[2],
    );
    return (row as T | undefined) ?? null;
  }

  async run() {
    if (this.database.fail) throw new Error("simulated D1 failure");
    if (this.query.includes("INSERT INTO blog_posts")) {
      const existing = this.database.rows.find(
        (row) =>
          row.actor_kind === this.values[11] &&
          row.actor_label === this.values[12] &&
          row.idempotency_key === this.values[13],
      );
      if (existing) return { success: true, meta: { changes: 0 } };
      const row: StoredRow = {
        id: String(this.values[0]),
        slug: String(this.values[1]),
        title: String(this.values[2]),
        summary: String(this.values[3]),
        paragraphs_json: String(this.values[4]),
        language: String(this.values[5]),
        author: String(this.values[6]),
        author_role: String(this.values[7]),
        signature: String(this.values[8]),
        published_at: String(this.values[9]),
        created_at: String(this.values[10]),
        actor_kind: String(this.values[11]),
        actor_label: String(this.values[12]),
        idempotency_key: String(this.values[13]),
        publication_status: String(this.values[14]),
      };
      this.database.rows.push(row);
      return { success: true, meta: { changes: 1 } };
    }
    return { success: false, meta: { changes: 0 } };
  }

  async all<T>() {
    if (this.database.fail) throw new Error("simulated D1 failure");
    const rows = [...this.database.rows]
      .filter((row) => row.publication_status === this.values[0])
      .sort((left, right) =>
        right.published_at.localeCompare(left.published_at),
      );
    return { success: true, results: rows as T[] };
  }
}

class FakeDatabase implements BlogDatabase {
  readonly rows: StoredRow[] = [];
  readonly preparedQueries: string[] = [];
  readonly calls: Array<{
    readonly query: string;
    readonly values: readonly DatabaseValue[];
  }> = [];
  fail = false;

  prepare(query: string) {
    this.preparedQueries.push(query);
    return new FakeStatement(this, query);
  }
}

const json = async (response: Response) =>
  JSON.parse(await response.text()) as unknown;

const base64Url = (value: Uint8Array | string) =>
  Buffer.from(typeof value === "string" ? value : value)
    .toString("base64url")
    .replace(/=+$/u, "");

const createJwtHarness = async () => {
  const pair = (await crypto.subtle.generateKey(
    {
      name: "RSASSA-PKCS1-v1_5",
      modulusLength: 2048,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: "SHA-256",
    },
    true,
    ["sign", "verify"],
  )) as CryptoKeyPair;
  const publicJwk = await crypto.subtle.exportKey("jwk", pair.publicKey);
  const kid = "test-key";

  const sign = async (
    claims: Readonly<Record<string, unknown>>,
    headerOverrides = {},
  ) => {
    const header = base64Url(
      JSON.stringify({ alg: "RS256", kid, typ: "JWT", ...headerOverrides }),
    );
    const payload = base64Url(JSON.stringify(claims));
    const signature = new Uint8Array(
      await crypto.subtle.sign(
        "RSASSA-PKCS1-v1_5",
        pair.privateKey,
        new TextEncoder().encode(`${header}.${payload}`),
      ),
    );
    return `${header}.${payload}.${base64Url(signature)}`;
  };

  const dependencies: RuntimeDependencies = {
    fetch: async () =>
      new Response(
        JSON.stringify({
          keys: [{ ...publicJwk, kid, alg: "RS256", use: "sig" }],
        }),
        { headers: { "Content-Type": "application/json" } },
      ),
    now: () => NOW,
    randomUUID: () => NEW_ID,
    subtle: crypto.subtle,
  };

  return { sign, dependencies };
};

const standardClaims = (overrides: Readonly<Record<string, unknown>> = {}) => ({
  aud: [AUDIENCE],
  email: "owner@example.com",
  exp: Math.floor(NOW / 1000) + 300,
  iat: Math.floor(NOW / 1000) - 30,
  iss: ISSUER,
  sub: "human-subject",
  type: "app",
  ...overrides,
});

const environment = (database = new FakeDatabase()): BlogBindings => ({
  BLOG_DB: database,
  BLOG_ACCESS_ISSUER: ISSUER,
  BLOG_ACCESS_AUDIENCES: JSON.stringify([AUDIENCE]),
  BLOG_HUMAN_ADMINS: JSON.stringify({
    "owner@example.com": { sub: "human-subject", label: "ed" },
  }),
  BLOG_AGENT_ADMINS: JSON.stringify({ "agent-client.access": "codex-aekr" }),
});

const request = (path: string, token: string, init: RequestInit = {}) =>
  new Request(`https://accreatio.pages.dev${path}`, {
    ...init,
    headers: {
      "Cf-Access-Jwt-Assertion": token,
      ...init.headers,
    },
  });

const validPost = {
  title: "A safe <script> title",
  summary: "Stored as text, never interpreted as HTML.",
  paragraphs: ["<img src=x onerror=alert(1)>", "A second paragraph."],
  language: "en",
  author: "Ed Lopez",
  authorRole: "Founder and product owner",
  signature: "Ed Lopez",
};

const publishHeaders = {
  "Content-Type": "application/json",
  "Idempotency-Key": IDEMPOTENCY_KEY,
  Origin: "https://accreatio.pages.dev",
  "X-Accreatio-Publish": "blog-v1",
};

test("admin capability requires a cryptographically verified Access token", async () => {
  const { dependencies, sign } = await createJwtHarness();
  const missing = await handleAdminSession(
    {
      request: new Request(
        "https://accreatio.pages.dev/api/admin/blog/session",
      ),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(missing.status, 401);
  assert.equal(missing.headers.get("Access-Control-Allow-Origin"), null);
  assert.equal(missing.headers.get("Cache-Control"), "no-store");

  const wrongIssuer = await sign(
    standardClaims({ iss: "https://other.cloudflareaccess.com" }),
  );
  const deniedIssuer = await handleAdminSession(
    {
      request: request("/api/admin/blog/session", wrongIssuer),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(deniedIssuer.status, 401);

  const wrongAudience = await sign(
    standardClaims({ aud: ["another-audience"] }),
  );
  const deniedAudience = await handleAdminSession(
    {
      request: request("/api/admin/blog/session", wrongAudience),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(deniedAudience.status, 401);

  const validToken = await sign(standardClaims());
  const [validHeader, validPayload, validSignature] = validToken.split(".");
  const tamperedSignature = `${validSignature.startsWith("A") ? "B" : "A"}${validSignature.slice(1)}`;
  const tamperedToken = `${validHeader}.${validPayload}.${tamperedSignature}`;
  const deniedSignature = await handleAdminSession(
    {
      request: request("/api/admin/blog/session", tamperedToken),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(deniedSignature.status, 401);
});

test("JWKS requests use Workers-compatible manual redirects and reject 302 responses", async () => {
  const { dependencies, sign } = await createJwtHarness();
  const token = await sign(standardClaims());
  const fetches: Array<{ url: string; init: RequestInit | undefined }> = [];
  const response = await handleAdminSession(
    { request: request("/api/admin/blog/session", token), env: environment() },
    {
      ...dependencies,
      fetch: async (url, init) => {
        fetches.push({ url: String(url), init });
        return new Response(null, {
          status: 302,
          headers: { Location: "https://redirected.example.test/certs" },
        });
      },
    },
  );
  assert.equal(fetches.length, 1, "JWKS redirects must never be followed");
  assert.equal(fetches[0].url, `${ISSUER}/cdn-cgi/access/certs`);
  assert.equal(fetches[0].init?.cache, "no-store");
  assert.equal(fetches[0].init?.redirect, "manual");
  assert.equal(response.status, 503);
  assert.deepEqual(await json(response), {
    error: {
      code: "access_keys_unavailable",
      message: "Blog authentication is temporarily unavailable.",
    },
  });
});

test("session exposes only an allowlisted human or service actor's safe label", async () => {
  const { dependencies, sign } = await createJwtHarness();
  const humanToken = await sign(standardClaims());
  const human = await handleAdminSession(
    {
      request: request("/api/admin/blog/session", humanToken),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(human.status, 200);
  assert.deepEqual(await json(human), {
    canPublish: true,
    actor: { kind: "human", label: "ed" },
  });

  const agentToken = await sign(
    standardClaims({
      email: undefined,
      sub: "",
      common_name: "agent-client.access",
    }),
  );
  const agent = await handleAdminSession(
    {
      request: request("/api/admin/blog/session", agentToken),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(agent.status, 200);
  assert.deepEqual(await json(agent), {
    canPublish: true,
    actor: { kind: "agent", label: "codex-aekr" },
  });

  const readerToken = await sign(
    standardClaims({ email: "reader@example.com" }),
  );
  const reader = await handleAdminSession(
    {
      request: request("/api/admin/blog/session", readerToken),
      env: environment(),
    },
    dependencies,
  );
  assert.deepEqual(await json(reader), { canPublish: false, actor: null });

  const replacementIdentity = await sign(
    standardClaims({ sub: "different-subject" }),
  );
  const sameEmailDifferentSubject = await handleAdminSession(
    {
      request: request("/api/admin/blog/session", replacementIdentity),
      env: environment(),
    },
    dependencies,
  );
  assert.deepEqual(await json(sameEmailDifferentSubject), {
    canPublish: false,
    actor: null,
  });
});

test("anonymous readers can list posts without Access configuration or valid credentials", async () => {
  const database = new FakeDatabase();
  for (const headers of [
    {},
    { "Cf-Access-Jwt-Assertion": "malformed-or-expired-token" },
  ]) {
    const response = await handleListPosts({
      request: new Request("https://accreatio.pages.dev/api/blog/posts", {
        headers,
      }),
      env: { BLOG_DB: database },
    });
    assert.equal(response.status, 200);
    assert.equal(response.headers.get("Access-Control-Allow-Origin"), null);
    assert.equal(response.headers.get("Cache-Control"), "no-store");
    assert.deepEqual(await json(response), { posts: [] });
  }
});

test("anonymous and ordinary Access identities cannot publish or reach the write database", async () => {
  const { dependencies, sign } = await createJwtHarness();
  const database = new FakeDatabase();
  database.fail = true;
  const tokens = [
    "",
    ...(await Promise.all(
      [
        { email: "reader@example.com" },
        { sub: "replacement-subject" },
        { email: undefined, sub: "", common_name: "unlisted-agent.access" },
      ].map((claims) => sign(standardClaims(claims))),
    )),
  ];
  for (const token of tokens) {
    const response = await handlePublishPost(
      {
        request: request("/api/admin/blog/posts", token, {
          method: "POST",
          headers: publishHeaders,
          body: JSON.stringify(validPost),
        }),
        env: environment(database),
      },
      dependencies,
    );
    assert.equal(response.status, token ? 403 : 401);
  }
  assert.deepEqual(database.preparedQueries, []);
  assert.deepEqual(database.rows, []);
});

test("publishing capability depends on admin identity, not database availability", async () => {
  const { dependencies, sign } = await createJwtHarness();
  const env = { ...environment(), BLOG_DB: undefined };
  for (const email of ["owner@example.com", "reader@example.com"]) {
    const response = await handleAdminSession(
      {
        request: request(
          "/api/admin/blog/session",
          await sign(standardClaims({ email })),
        ),
        env,
      },
      dependencies,
    );
    assert.equal(response.status, 200);
    assert.deepEqual(
      await json(response),
      email === "owner@example.com"
        ? { canPublish: true, actor: { kind: "human", label: "ed" } }
        : { canPublish: false, actor: null },
    );
  }
});

test("public reads expose only published content to anonymous, ordinary and admin visitors", async () => {
  const { dependencies, sign } = await createJwtHarness();
  const database = new FakeDatabase();
  const env = environment(database);
  const ownerToken = await sign(standardClaims());
  const published = await handlePublishPost(
    {
      request: request("/api/admin/blog/posts", ownerToken, {
        method: "POST",
        headers: publishHeaders,
        body: JSON.stringify(validPost),
      }),
      env,
    },
    dependencies,
  );
  assert.equal(published.status, 201);
  const { post } = (await json(published)) as { post: unknown };
  database.rows.push({
    ...database.rows[0],
    id: "unpublished-post",
    slug: "unpublished-post",
    title: "Private editorial draft",
    publication_status: "draft",
  });
  const agentToken = await sign(
    standardClaims({
      email: undefined,
      sub: "",
      common_name: "agent-client.access",
    }),
  );
  const readerToken = await sign(
    standardClaims({ email: "reader@example.com" }),
  );
  for (const token of ["", readerToken, ownerToken, agentToken]) {
    const response = await handleListPosts({
      request: request("/api/blog/posts", token),
      env,
    });
    assert.equal(response.status, 200);
    assert.equal(response.headers.get("Cache-Control"), "no-store");
    assert.deepEqual(await json(response), { posts: [post] });
  }
});

test("mixed human and service claim shapes fail closed", async () => {
  const { dependencies, sign } = await createJwtHarness();
  const token = await sign(
    standardClaims({ common_name: "agent-client.access" }),
  );
  const response = await handleAdminSession(
    { request: request("/api/admin/blog/session", token), env: environment() },
    dependencies,
  );
  assert.equal(response.status, 401);
});

test("operational error logs contain no token, identity, or post body", async () => {
  const { dependencies, sign } = await createJwtHarness();
  const token = await sign(
    standardClaims({ email: "private-reader@example.com" }),
  );
  const captured: string[] = [];
  const originalError = console.error;
  console.error = (...values: unknown[]) => {
    captured.push(values.map(String).join(" "));
  };
  let response: Response | undefined;
  try {
    response = await handlePublishPost(
      {
        request: request("/api/admin/blog/posts", token, {
          method: "POST",
          headers: publishHeaders,
          body: JSON.stringify({
            ...validPost,
            paragraphs: ["private unpublished body"],
          }),
        }),
        env: environment(),
      },
      dependencies,
    );
  } finally {
    console.error = originalError;
  }
  assert.ok(response);
  assert.equal(response.status, 403);
  const log = captured.join("\n");
  assert.match(log, /publisher_not_authorized/);
  assert.doesNotMatch(log, /private-reader|private unpublished|human-subject/);
  assert.equal(log.includes(token), false);
});

test("browser publishing requires same-origin, custom header, JSON, and bounded exact fields", async () => {
  const { dependencies, sign } = await createJwtHarness();
  const token = await sign(standardClaims());

  const crossOrigin = await handlePublishPost(
    {
      request: request("/api/admin/blog/posts", token, {
        method: "POST",
        headers: { ...publishHeaders, Origin: "https://example.net" },
        body: JSON.stringify(validPost),
      }),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(crossOrigin.status, 403);

  const noCustomHeader = await handlePublishPost(
    {
      request: request("/api/admin/blog/posts", token, {
        method: "POST",
        headers: { ...publishHeaders, "X-Accreatio-Publish": "wrong" },
        body: JSON.stringify(validPost),
      }),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(noCustomHeader.status, 403);

  const withoutOrigin = { ...publishHeaders };
  delete (withoutOrigin as { Origin?: string }).Origin;
  const missingOrigin = await handlePublishPost(
    {
      request: request("/api/admin/blog/posts", token, {
        method: "POST",
        headers: withoutOrigin,
        body: JSON.stringify(validPost),
      }),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(missingOrigin.status, 403);

  const wrongMediaType = await handlePublishPost(
    {
      request: request("/api/admin/blog/posts", token, {
        method: "POST",
        headers: { ...publishHeaders, "Content-Type": "text/plain" },
        body: JSON.stringify(validPost),
      }),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(wrongMediaType.status, 415);

  const oversized = await handlePublishPost(
    {
      request: request("/api/admin/blog/posts", token, {
        method: "POST",
        headers: publishHeaders,
        body: JSON.stringify({
          ...validPost,
          paragraphs: ["x".repeat(33_000)],
        }),
      }),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(oversized.status, 413);

  const invalidFields = await handlePublishPost(
    {
      request: request("/api/admin/blog/posts", token, {
        method: "POST",
        headers: publishHeaders,
        body: JSON.stringify({ ...validPost, unexpected: true }),
      }),
      env: environment(),
    },
    dependencies,
  );
  assert.equal(invalidFields.status, 422);
});

test("publish is append-only and retries return the original post", async () => {
  const { dependencies, sign } = await createJwtHarness();
  const token = await sign(standardClaims());
  const database = new FakeDatabase();
  const env = environment(database);

  const first = await handlePublishPost(
    {
      request: request("/api/admin/blog/posts", token, {
        method: "POST",
        headers: publishHeaders,
        body: JSON.stringify(validPost),
      }),
      env,
    },
    dependencies,
  );
  assert.equal(first.status, 201);
  const firstPayload = await json(first);
  assert.deepEqual(firstPayload, {
    post: {
      id: NEW_ID,
      slug: "a-safe-script-title-6add7868",
      ...validPost,
      publishedAt: "2026-08-06T12:00:00.000Z",
    },
  });
  assert.equal(
    first.headers.get("Content-Type"),
    "application/json; charset=utf-8",
  );
  assert.equal(first.headers.get("Access-Control-Allow-Origin"), null);
  assert.equal(database.rows[0].actor_label, "ed");
  assert.equal(database.rows[0].actor_kind, "human");
  assert.equal(
    JSON.stringify(database.rows).includes("owner@example.com"),
    false,
  );
  assert.equal(JSON.stringify(database.rows).includes("human-subject"), false);

  const retry = await handlePublishPost(
    {
      request: request("/api/admin/blog/posts", token, {
        method: "POST",
        headers: publishHeaders,
        body: JSON.stringify({
          ...validPost,
          title: "A changed retry is ignored",
        }),
      }),
      env,
    },
    dependencies,
  );
  assert.equal(retry.status, 200);
  assert.equal(retry.headers.get("Idempotency-Replayed"), "true");
  assert.deepEqual(await json(retry), firstPayload);
  assert.equal(database.rows.length, 1);
  assert.equal(
    database.calls.some(({ query }) => query.includes(validPost.title)),
    false,
  );
});

test("an allowlisted agent may publish without a browser Origin", async () => {
  const { dependencies, sign } = await createJwtHarness();
  const token = await sign(
    standardClaims({
      email: undefined,
      sub: "",
      common_name: "agent-client.access",
    }),
  );
  const headers = { ...publishHeaders };
  delete (headers as { Origin?: string }).Origin;
  const database = new FakeDatabase();
  const response = await handlePublishPost(
    {
      request: request("/api/admin/blog/posts", token, {
        method: "POST",
        headers,
        body: JSON.stringify(validPost),
      }),
      env: environment(database),
    },
    dependencies,
  );
  assert.equal(response.status, 201);
  assert.equal(database.rows[0].actor_kind, "agent");
  assert.equal(database.rows[0].actor_label, "codex-aekr");
});

test("D1 failures are explicit for public readers and do not pretend that a read succeeded", async () => {
  const database = new FakeDatabase();
  database.fail = true;
  for (const env of [{ BLOG_DB: database }, {}]) {
    const response = await handleListPosts({
      request: new Request("https://accreatio.pages.dev/api/blog/posts"),
      env,
    });
    assert.equal(response.status, 503);
    assert.deepEqual(await json(response), {
      error: {
        code: "editorial_database_unavailable",
        message: "Blog posts are temporarily unavailable.",
      },
    });
  }
});

test("the canonical fixture preserves Ed's body and the real Claude revision", () => {
  const fixture = JSON.parse(
    readFileSync(
      new URL("../content/blog/founding-posts.json", import.meta.url),
      "utf8",
    ),
  ) as { posts: Array<{ paragraphs: string[]; signature: string }> };
  assert.equal(fixture.posts.length, 3);
  assert.equal(
    createHash("sha256")
      .update(fixture.posts[2].paragraphs.join("\n\n"))
      .digest("hex"),
    "1e0247d30c7372958576e4367aeed2174aa23e6d032ef2046cabec3c1b9ca057",
  );
  assert.equal(fixture.posts[1].paragraphs.length, 3);
  assert.match(
    fixture.posts[1].paragraphs[0],
    /false of this one, and worth correcting outright/,
  );
  assert.equal(
    fixture.posts[1].signature,
    "Created with AI assistance through AEKR.",
  );

  const migration = readFileSync(
    new URL("../migrations/0001_blog.sql", import.meta.url),
    "utf8",
  );
  assert.match(migration, /blog_posts_append_only_update/);
  assert.match(migration, /blog_posts_append_only_delete/);
  assert.doesNotMatch(
    migration,
    /owner@example\.com|human-subject|agent-client\.access/,
  );
});
