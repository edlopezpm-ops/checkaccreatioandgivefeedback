import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";
import { createNebula } from "../src/components/nebula";

const read = (path: string) =>
  fs.readFileSync(new URL(path, import.meta.url), "utf8");

const atmosphere = read("../src/components/Atmosphere.tsx");
const starField = read("../src/components/StarField.tsx");
const app = read("../src/App.tsx");
const frame = read("../src/components/AppFrame.tsx");
const styles = read("../src/styles.css");
const responsive = read("../src/responsive.css");

const numericTable = (source: string, name: string) => {
  const block = source.match(
    new RegExp(
      `const ${name}: Record<AtmosphereVariant, number> = \\{([\\s\\S]*?)\\};`,
    ),
  )?.[1];
  assert.ok(block, `${name} must exist`);
  return Object.fromEntries(
    [
      ...block.matchAll(
        /\b(home|creation|review|export|about|quiet):\s*([\d.]+)/g,
      ),
    ].map(([, variant, value]) => [variant, Number(value)]),
  );
};

test("atmosphere persists in the shell and responds to product state", () => {
  for (const state of [
    "home",
    "creation",
    "review",
    "export",
    "about",
    "quiet",
  ])
    assert.match(app, new RegExp(`"${state}"`));
  assert.match(atmosphere, /aria-hidden="true"/);
  assert.match(frame, /<Atmosphere theme=\{theme\} variant=\{atmosphere\}/);
  assert.match(styles, /\.atmosphere\s*{[\s\S]*?pointer-events:\s*none/);
});

test("procedural nebula moves autonomously and clicks sample visible gas", () => {
  const nebula = read("../src/components/nebula.ts");
  assert.match(atmosphere, /import\("\.\/nebula"\)/);
  assert.match(atmosphere, /createNebula/);
  assert.match(atmosphere, /import \{ StarField \} from "\.\/StarField"/);
  assert.match(nebula, /powerPreference: "low-power"/);
  assert.match(nebula, /const FRAME_INTERVAL_MS = 1000 \/ 30/);
  assert.match(nebula, /WEBGL_lose_context/);
  assert.doesNotMatch(nebula, /https?:\/\//);
  assert.doesNotMatch(
    atmosphere + starField + nebula,
    /pointermove|setPointer|u_pointer|PARALLAX_BY_VARIANT/,
  );
  assert.match(
    atmosphere,
    /addEventListener\("click", burstOnClick, \{ passive: true \}/,
  );
  assert.match(atmosphere, /event\.button !== 0/);
  assert.match(atmosphere, /event\.detail === 0/);
  assert.match(atmosphere, /event\.pointerType !== "mouse"/);
  assert.match(atmosphere, /event\.target\.matches/);
  assert.match(atmosphere, /event\.target\.closest/);
  assert.match(nebula, /gl\.readPixels\(0, 0, 1, 1/);
  assert.match(nebula, /density \* visibility \* clearing/);
  assert.match(nebula, /pickedPixel\[0\] \/ 255/);
  assert.match(nebula, /BURST_LIFETIME_SECONDS/);
  assert.match(nebula, /nextBurst = \(nextBurst \+ 1\) % 4/);
  assert.deepEqual(numericTable(atmosphere, "SPEED_BY_VARIANT"), {
    home: 2.6,
    creation: 1.9,
    review: 1.25,
    export: 2.1,
    about: 1.9,
    quiet: 0.8,
  });

  assert.match(starField, /const CSS_PIXELS_PER_MM = 96 \/ 25\.4/);
  assert.match(starField, /const FRAME_INTERVAL_MS = 1000 \/ 30/);
  assert.match(starField, /const STAR_TRAJECTORY_MULTIPLIER = 1\.35/);
  assert.match(starField, /const STAR_SPEED_MULTIPLIER = 1\.15/);
  assert.match(starField, /depth: "far",[\s\S]*?driftRadiusMm: 1,/);
  assert.match(starField, /depth: "mid",[\s\S]*?driftRadiusMm: 1\.5,/);
  assert.match(starField, /depth: "near",[\s\S]*?driftRadiusMm: 2\.5,/);
  assert.match(starField, /Math\.pow\(random\(\), spec\.xExponent\)/);
  assert.match(
    starField,
    /between\(random, spec\.periodSeconds\) \* 1000\) \/\s*STAR_SPEED_MULTIPLIER/,
  );
  assert.match(
    starField,
    /spec\.driftRadiusMm \*\s*CSS_PIXELS_PER_MM \*\s*STAR_TRAJECTORY_MULTIPLIER/,
  );
  assert.match(starField, /className="atmosphere__starfield"/);
  assert.match(styles, /mask-image:\s*linear-gradient\([\s\S]*?to left/);
  assert.doesNotMatch(styles, /--nebula-pointer|--nebula-cursor|--nebula-far/);
  assert.match(
    styles,
    /\.atmosphere__starfield\s*{[\s\S]*?mask-image:\s*linear-gradient\([\s\S]*?to left/,
  );
});

test("renderer lifecycle pauses offscreen and falls back safely", () => {
  assert.match(
    styles,
    /@media \(prefers-reduced-motion: reduce\)[\s\S]*?\.atmosphere > div,\s*\.atmosphere > canvas\s*{[\s\S]*?animation:\s*none/,
  );
  assert.match(atmosphere, /prefers-reduced-motion: reduce/);
  assert.match(atmosphere, /\(update: slow\)/);
  assert.match(atmosphere, /saveData/);
  assert.match(atmosphere, /visibilitychange/);
  assert.match(atmosphere, /webglcontextlost/);
  assert.match(atmosphere, /effectRef\.current\?\.destroy\(\)/);
  assert.match(atmosphere, /data-renderer=\{renderer\}/);
  assert.match(
    starField,
    /const motionEnabled = !paused && !reducedMotion && !saveData && !slowUpdate/,
  );
  assert.match(starField, /\? "static" : "active"/);
  assert.match(styles, /data-renderer="fallback"/);
});

test("responsive atmosphere has no cursor decoration or mismatched canvas transform", () => {
  assert.doesNotMatch(
    atmosphere + styles + responsive,
    /atmosphere__cursor-field/,
  );
  assert.doesNotMatch(responsive, /\.atmosphere__webgl/);
  assert.match(responsive, /@media \(width >= 112\.5rem\)/);
});

test("nebula picking respects bounds and opacity, caps bursts, and clears them after their lifetime", (t) => {
  const bounds = { left: 100, top: 50, width: 1000, height: 500 };
  const uniforms = new Map<string, number | number[]>();
  let scheduled: FrameRequestCallback | undefined;
  let density = 0;
  let opacity = "0.8";
  let removed = false;
  let readCount = 0;
  let lost = false;
  let framebuffer: unknown = null;
  const gl = new Proxy<Record<string, unknown>>(
    {
      getShaderParameter: () => true,
      getProgramParameter: () => true,
      getUniformLocation: (_program: unknown, name: string) => name,
      getAttribLocation: () => 0,
      checkFramebufferStatus: () => "FRAMEBUFFER_COMPLETE",
      getExtension: () => ({
        loseContext: () => {
          lost = true;
        },
      }),
      isContextLost: () => lost,
      bindFramebuffer: (_target: unknown, value: unknown) => {
        framebuffer = value;
      },
      uniform1f: (name: string, value: number) => uniforms.set(name, value),
      uniform2f: (name: string, x: number, y: number) =>
        uniforms.set(name, [x, y]),
      uniform4fv: (name: string, value: Float32Array) =>
        uniforms.set(name, Array.from(value)),
      readPixels: (
        x: number,
        y: number,
        width: number,
        height: number,
        _format: unknown,
        _type: unknown,
        pixel: Uint8Array,
      ) => {
        assert.deepEqual([x, y, width, height], [0, 0, 1, 1]);
        assert.notEqual(framebuffer, null);
        readCount++;
        pixel.set([density, 0, 0, 255]);
      },
    },
    {
      get(target, key: string) {
        if (key in target) return target[key];
        if (/^[A-Z_0-9]+$/.test(key)) return key;
        if (key.startsWith("create")) return () => ({});
        return () => undefined;
      },
    },
  );
  const canvas = {
    getContext: () => gl,
    getBoundingClientRect: () => bounds,
    remove: () => {
      removed = true;
    },
    width: 0,
    height: 0,
  };
  const globals = {
    document: { createElement: () => canvas },
    window: {
      devicePixelRatio: 2,
      requestAnimationFrame: (callback: FrameRequestCallback) => {
        scheduled = callback;
        return 1;
      },
      cancelAnimationFrame: () => {
        scheduled = undefined;
      },
      getComputedStyle: () => ({ opacity }),
    },
    ResizeObserver: class {
      observe() {}
      disconnect() {}
    },
  };
  for (const [key, value] of Object.entries(globals)) {
    const previous = Object.getOwnPropertyDescriptor(globalThis, key);
    Object.defineProperty(globalThis, key, { configurable: true, value });
    t.after(() => {
      if (previous) Object.defineProperty(globalThis, key, previous);
      else Reflect.deleteProperty(globalThis, key);
    });
  }
  const host = {
    appendChild() {},
    getBoundingClientRect: () => bounds,
  } as unknown as HTMLElement;
  const effect = createNebula(host, { theme: "dark", speed: 2.6 });
  assert.ok(effect);
  t.after(() => effect.destroy());
  assert.equal(
    effect.burstAt(850, 175),
    false,
    "nothing is hittable before the first rendered frame",
  );
  scheduled?.(50);
  assert.equal(
    effect.burstAt(99, 175),
    false,
    "coordinates outside the canvas are ignored",
  );
  assert.equal(effect.burstAt(Number.NaN, 175), false);
  assert.equal(readCount, 0);
  assert.equal(effect.burstAt(850, 175), false, "empty gas rejects the click");
  assert.deepEqual(
    uniforms.get("u_pickUv"),
    [0.75, 0.75],
    "CSS coordinates map to the same shader point even at high DPI",
  );
  assert.equal(framebuffer, null, "picking restores the visible framebuffer");
  density = 100;
  opacity = "0";
  assert.equal(
    effect.burstAt(850, 175),
    false,
    "a hidden renderer does not react",
  );
  opacity = "0.8";
  for (let i = 0; i < 5; i++)
    assert.equal(effect.burstAt(700 + i * 10, 175), true);
  scheduled?.(100);
  const active = uniforms.get("u_bursts[0]") as number[];
  assert.equal(active.length, 16);
  assert.equal(
    active.filter((value, index) => index % 4 === 3 && value === 1).length,
    4,
    "repeated clicks cannot grow the burst pool",
  );
  for (let now = 150; now <= 1800; now += 50) scheduled?.(now);
  assert.deepEqual(
    uniforms.get("u_bursts[0]"),
    new Array(16).fill(0),
    "every bubble dissipates",
  );
  effect.destroy();
  assert.equal(removed, true);
  assert.equal(scheduled, undefined);
  assert.equal(effect.burstAt(850, 175), false);
});
