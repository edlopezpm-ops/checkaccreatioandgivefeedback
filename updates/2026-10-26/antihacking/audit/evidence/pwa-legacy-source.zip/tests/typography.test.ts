import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

const read = (path: string) =>
  fs.readFileSync(new URL(path, import.meta.url), "utf8");

const styles = read("../src/styles.css");
const blog = read("../src/components/BlogExperience.css");
const legal = read("../public/legal/legal.css");
const projectMap = read("../scripts/project-map.template.html");

const body =
  'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';

// Declared families must be host-resident faces. Prettier wraps the longer
// stacks across lines, so match the comma-separated list rather than one
// literal string.
const expectedFamilies: ReadonlyArray<readonly [string, string]> = [
  ["--font-brand", body],
  ["--font-heading", body],
  ["--font-body", body],
  ["--font-ui", body],
  [
    "--font-code",
    'ui-monospace, "Cascadia Mono", "Segoe UI Mono", "Roboto Mono", Menlo, Consolas, monospace',
  ],
];

const expectedWeights = [
  "--fw-regular: 400;",
  "--fw-medium: 500;",
  "--fw-semibold: 600;",
  "--fw-bold: 700;",
];

const familyPattern = (token: string, families: string) =>
  new RegExp(
    `${token}:\\s*${families
      .split(/,\s*/)
      .map((family) => family.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
      .join(",\\s*")};`,
  );

test("all presentation surfaces expose the approved typography tokens", () => {
  for (const surface of [styles, legal, projectMap]) {
    for (const [token, families] of expectedFamilies)
      assert.match(surface, familyPattern(token, families));
    for (const weight of expectedWeights) assert.ok(surface.includes(weight));
  }
  assert.doesNotMatch(styles, /--font-(?:display|sans|mono)\s*:/);
});

// The guard below is about what the stylesheet declares, not what a comment
// explains, so prose naming an undelivered family stays legal.
const withoutComments = (surface: string) =>
  surface.replace(/\/\*[\s\S]*?\*\//g, "");

test("no surface declares a font family the build never delivers", () => {
  // The product ships no font file and the Project Map enforces
  // `font-src 'none'`, so naming a licensed or bundled-only family would
  // silently fall through to an OS generic on every machine but the author's.
  for (const surface of [styles, blog, legal, projectMap].map(
    withoutComments,
  )) {
    assert.doesNotMatch(surface, /@font-face/);
    assert.doesNotMatch(surface, /Posterama|"Inter"|JetBrains Mono/);
    assert.doesNotMatch(
      surface,
      /fonts\.googleapis|fonts\.gstatic|use\.typekit|@import\s+url/,
    );
  }
});

test("application typography follows semantic product roles", () => {
  assert.match(
    styles,
    /\.formation-mark strong,[\s\S]*?\.about-brand-link span,[\s\S]*?\.about-product-close strong\s*{[\s\S]*?font-family:\s*var\(--font-brand\)[\s\S]*?font-weight:\s*var\(--fw-bold\)/,
  );
  assert.match(
    blog,
    /\.blog-close strong\s*{[\s\S]*?font-family:\s*var\(--font-brand\)[\s\S]*?font-weight:\s*var\(--fw-bold\)/,
  );
  assert.match(
    styles,
    /h1,[\s\S]*?h2\s*{[\s\S]*?font-family:\s*var\(--font-heading\)[\s\S]*?font-weight:\s*var\(--fw-bold\)/,
  );
  assert.match(
    styles,
    /h3,[\s\S]*?h4\s*{[\s\S]*?font-family:\s*var\(--font-ui\)[\s\S]*?font-weight:\s*var\(--fw-semibold\)/,
  );
  assert.match(
    styles,
    /button\s*{[\s\S]*?font-family:\s*var\(--font-ui\)[\s\S]*?font-weight:\s*var\(--fw-semibold\)/,
  );
  assert.match(
    styles,
    /\.product-nav button\s*{[\s\S]*?font-weight:\s*var\(--fw-medium\)/,
  );
  assert.match(
    styles,
    /label,[\s\S]*?legend\s*{[\s\S]*?font-family:\s*var\(--font-ui\)[\s\S]*?font-weight:\s*var\(--fw-medium\)/,
  );
  assert.match(
    styles,
    /label strong,[\s\S]*?legend strong\s*{[\s\S]*?font-weight:\s*inherit/,
  );
  assert.match(
    styles,
    /label small,[\s\S]*?legend small\s*{[\s\S]*?font-family:\s*var\(--font-body\)[\s\S]*?font-weight:\s*var\(--fw-regular\)/,
  );
  assert.match(
    styles,
    /input,[\s\S]*?textarea,[\s\S]*?select\s*{[\s\S]*?font-family:\s*var\(--font-body\)[\s\S]*?font-weight:\s*var\(--fw-regular\)/,
  );
  for (const selector of [
    "field-label strong",
    "status-notice strong",
    "onboarding-progress",
    "onboarding-facts dt",
    "summary-drawer dt",
    "about-eyebrow",
  ]) {
    const escaped = selector.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    assert.match(
      styles,
      new RegExp(
        `\\.${escaped}\\s*\\{[\\s\\S]*?font-family:\\s*var\\(--font-ui\\)[\\s\\S]*?font-weight:\\s*var\\(--fw-medium\\)`,
      ),
    );
  }
  assert.match(
    styles,
    /code,[\s\S]*?pre,[\s\S]*?kbd,[\s\S]*?samp\s*{[\s\S]*?font-family:\s*var\(--font-code\)/,
  );
});

test("legal pages and the project map retain the same role hierarchy", () => {
  assert.match(legal, /h1,[\s\S]*?h2\s*{[\s\S]*?var\(--font-heading\)/);
  assert.match(legal, /nav\s*{[\s\S]*?var\(--fw-medium\)/);
  assert.match(projectMap, /body\s*{[\s\S]*?var\(--font-body\)/);
  assert.match(projectMap, /h1,[\s\S]*?h2\s*{[\s\S]*?var\(--font-heading\)/);
  assert.match(projectMap, /\.brand-name\s*{[\s\S]*?var\(--font-brand\)/);
  assert.match(projectMap, /\.path-chip\s*{[\s\S]*?var\(--font-code\)/);
  assert.match(
    projectMap,
    /\.edge-label text\s*{[\s\S]*?font-family:\s*var\(--font-body\)[\s\S]*?font-weight:\s*var\(--fw-regular\)/,
  );
  for (const selector of [
    "skip-link",
    "eyebrow",
    "legend-title",
    "status-token",
    "flow-meta",
    "step-number",
  ]) {
    assert.match(
      projectMap,
      new RegExp(`\\.${selector},?[\\s\\S]*?font-family: var\\(--font-ui\\)`),
    );
  }
  assert.match(
    projectMap,
    /\.flow-card p\s*{[\s\S]*?font-family:\s*var\(--font-body\)[\s\S]*?font-weight:\s*var\(--fw-regular\)/,
  );
  assert.match(projectMap, /font-src 'none'/);
});
