import assert from "node:assert/strict";
import test from "node:test";
import { ACCOUNT_POLICY } from "../shared/accountPolicy";
import {
  AccountError,
  authorizeWebExport,
  loadWebAccount,
  loadWebAccountData,
  loadWebAuthMethods,
  loadGoogleSignInStatus,
  cancelGoogleSignIn,
  startGoogleSignIn,
  requestEmailCode,
  saveWebAccountPolicy,
  verifyEmailCode,
} from "../src/account/webClient";

const account = {
  ownerKey: `v1:${"a".repeat(64)}`,
  sessionKey: `v1:${"b".repeat(64)}`,
  email: "person@example.test",
  displayName: "Sample Person",
  expiresAt: "2026-09-06T10:00:00.000Z",
  remaining: 5,
  nextAvailableAt: null,
  policyAuthorizationRequired: false,
};
const policyAuthorization = {
  ...ACCOUNT_POLICY,
  accountDataAuthorized: true,
  termsAccepted: true,
};
const challenge = {
  challengeId: "opaque-challenge",
  expiresAt: "2026-09-06T10:00:00.000Z",
  resendAt: "2026-09-06T09:51:00.000Z",
};

test("all account DTO entry points reject absent or malformed local ownership markers", async (t) => {
  const mock = t.mock.method(globalThis, "fetch", async () =>
    Response.json(account),
  );
  const loaders = [
    () => loadWebAccount(),
    () => saveWebAccountPolicy(policyAuthorization),
    () => verifyEmailCode(challenge.challengeId, "012345"),
  ];
  for (const load of loaders) {
    assert.deepEqual(await load(), account);
    for (const key of ["ownerKey", "sessionKey"] as const) {
      for (const invalid of [
        undefined,
        null,
        42,
        "",
        "a".repeat(64),
        `v2:${"a".repeat(64)}`,
        `v1:${"A".repeat(64)}`,
        `v1:${"a".repeat(63)}`,
        `v1:${"a".repeat(65)}`,
        `${account[key]}\n`,
      ]) {
        mock.mock.mockImplementation(async () =>
          Response.json({ ...account, [key]: invalid }),
        );
        await assert.rejects(
          load(),
          (error: unknown) =>
            error instanceof AccountError && error.code === "unavailable",
        );
      }
    }
    mock.mock.mockImplementation(async () => Response.json(account));
  }
});

test("export authorization binds the captured account and session without loading a replacement identity", async (t) => {
  const originalWindow = Object.getOwnPropertyDescriptor(globalThis, "window");
  Object.defineProperty(globalThis, "window", {
    configurable: true,
    value: new EventTarget(),
  });
  t.after(() => {
    if (originalWindow)
      Object.defineProperty(globalThis, "window", originalWindow);
    else Reflect.deleteProperty(globalThis, "window");
  });
  const requests: { path: string; body: unknown }[] = [];
  const quotaEvents: unknown[] = [];
  let rechecks = 0;
  window.addEventListener("accreatio:account-recheck", () => {
    rechecks++;
  });
  window.addEventListener("accreatio:quota", (event) => {
    quotaEvents.push((event as CustomEvent).detail);
  });
  const operationId = crypto.randomUUID();
  const mock = t.mock.method(globalThis, "fetch", async (path, options) => {
    requests.push({
      path: String(path),
      body: JSON.parse(String(options?.body)),
    });
    return Response.json({
      operationId,
      remaining: 4,
      nextAvailableAt: null,
      issuedAt: "2026-10-21T10:00:00.000Z",
      retryExpiresAt: "2026-10-23T10:00:00.000Z",
    });
  });
  const expected = {
    ownerKey: account.ownerKey,
    sessionKey: account.sessionKey,
  };
  assert.deepEqual(await authorizeWebExport(operationId, expected), {
    issuedAt: "2026-10-21T10:00:00.000Z",
    retryExpiresAt: "2026-10-23T10:00:00.000Z",
  });
  assert.deepEqual(requests, [
    { path: "/api/account/authorize", body: { operationId, ...expected } },
  ]);
  assert.deepEqual(quotaEvents, [
    { remaining: 4, nextAvailableAt: null, ...expected },
  ]);
  await assert.rejects(
    authorizeWebExport(operationId, { ...expected, sessionKey: "" }),
    (error: unknown) =>
      error instanceof AccountError && error.code === "sign_in_required",
  );
  assert.equal(requests.length, 1);
  mock.mock.mockImplementation(async () =>
    Response.json(
      {
        error: { code: "account_context_changed", message: "Session changed." },
      },
      { status: 409 },
    ),
  );
  await assert.rejects(
    authorizeWebExport(operationId, expected),
    (error: unknown) =>
      error instanceof AccountError && error.code === "account_context_changed",
  );
  assert.equal(requests.length, 1);
  assert.equal(rechecks, 1);
  assert.equal(
    mock.mock.callCount(),
    2,
    "A changed context triggers revalidation without retrying this export under another account",
  );
  mock.mock.mockImplementation(async () =>
    Response.json(
      {
        error: { code: "quota_exhausted", message: "No exports remaining." },
        remaining: 0,
        nextAvailableAt: "2026-10-22T10:00:00.000Z",
      },
      { status: 429 },
    ),
  );
  await assert.rejects(authorizeWebExport(operationId, expected), AccountError);
  assert.deepEqual(quotaEvents.at(-1), {
    remaining: 0,
    nextAvailableAt: "2026-10-22T10:00:00.000Z",
    ...expected,
  });
});

test("account session uses the profile name and preserves legacy email fallback", async (t) => {
  const mock = t.mock.method(globalThis, "fetch", async () =>
    Response.json(account),
  );
  assert.equal((await loadWebAccount()).displayName, "Sample Person");
  const { displayName: _displayName, ...legacy } = account;
  mock.mock.mockImplementation(async () => Response.json(legacy));
  assert.equal((await loadWebAccount()).displayName, "person");
  mock.mock.mockImplementation(async () =>
    Response.json({ ...legacy, email: "" }),
  );
  assert.equal((await loadWebAccount()).displayName, "Account");
  for (const displayName of [
    null,
    7,
    "",
    " ",
    "name\u202E",
    "name\n",
    "a".repeat(121),
  ]) {
    mock.mock.mockImplementation(async () =>
      Response.json({ ...account, displayName }),
    );
    await assert.rejects(
      loadWebAccount(),
      (error: unknown) =>
        error instanceof AccountError && error.code === "unavailable",
    );
  }
});

test("only explicit current authorization clears the account policy gate", async (t) => {
  const mock = t.mock.method(globalThis, "fetch", async () =>
    Response.json(account),
  );
  assert.equal((await loadWebAccount()).policyAuthorizationRequired, false);
  const { policyAuthorizationRequired: _required, ...legacy } = account;
  mock.mock.mockImplementation(async () => Response.json(legacy));
  assert.equal((await loadWebAccount()).policyAuthorizationRequired, true);
  for (const policyAuthorizationRequired of [true, null, "false", 0]) {
    mock.mock.mockImplementation(async () =>
      Response.json({ ...account, policyAuthorizationRequired }),
    );
    assert.equal((await loadWebAccount()).policyAuthorizationRequired, true);
  }
});

test("account client keeps navigation and network failures distinct without following redirects", async (t) => {
  let requestOptions: RequestInit | undefined;
  const fetchMock = t.mock.method(
    globalThis,
    "fetch",
    async (_input: RequestInfo | URL, options?: RequestInit) => {
      requestOptions = options;
      return { type: "opaqueredirect", status: 0 } as Response;
    },
  );
  await assert.rejects(
    loadWebAccount(),
    (error: unknown) =>
      error instanceof AccountError && error.code === "sign_in_required",
  );
  assert.equal(requestOptions?.redirect, "manual");
  assert.equal(requestOptions?.credentials, "same-origin");
  assert.equal(requestOptions?.cache, "no-store");
  fetchMock.mock.mockImplementation(async () => {
    throw new TypeError("Failed to fetch");
  });
  await assert.rejects(
    loadWebAccount(),
    (error: unknown) =>
      error instanceof AccountError && error.code === "unreachable",
  );
});

test("method discovery fails closed and contains no account selector", async (t) => {
  const calls: { path: string; options?: RequestInit }[] = [];
  const fixture = {
    version: "auth.v1",
    methods: {
      google: { available: true },
      github: { available: false },
      emailOtp: { available: false },
    },
  };
  const mock = t.mock.method(globalThis, "fetch", async (path, options) => {
    calls.push({ path: String(path), options });
    return Response.json(fixture);
  });
  assert.deepEqual(await loadWebAuthMethods(), fixture);
  assert.equal(calls[0].path, "/api/auth/v1/methods");
  assert.equal(calls[0].options?.body, undefined);
  assert.equal(calls[0].options?.redirect, "manual");
  for (const malformed of [
    null,
    {},
    { ...fixture, version: 1 },
    { ...fixture, methods: { google: { available: "true" } } },
  ]) {
    mock.mock.mockImplementation(async () => Response.json(malformed));
    await assert.rejects(loadWebAuthMethods(), AccountError);
  }
});

test("Google navigation accepts only the configured HTTPS authorization endpoint", async (t) => {
  const fixture = {
    transactionId: "opaque-transaction-123456",
    authorizationUrl:
      "https://accounts.google.com/o/oauth2/v2/auth?state=opaque",
    expiresAt: "2026-09-08T23:30:00.000Z",
  };
  const requests: { path: string; options?: RequestInit }[] = [];
  const mock = t.mock.method(globalThis, "fetch", async (path, options) => {
    requests.push({ path: String(path), options });
    return Response.json(fixture);
  });
  assert.deepEqual(
    await startGoogleSignIn("popup", policyAuthorization),
    fixture,
  );
  assert.deepEqual(JSON.parse(String(requests[0].options?.body)), {
    purpose: "sign_in",
    returnRoute: "builder",
    mode: "popup",
    policyAuthorization,
  });
  assert.equal(requests[0].path, "/api/auth/v1/oidc/google/start");
  for (const authorizationUrl of [
    "https://accounts.google.com.evil.test/o/oauth2/v2/auth",
    "http://accounts.google.com/o/oauth2/v2/auth",
    "https://accounts.google.com/other",
    "https://user:pass@accounts.google.com/o/oauth2/v2/auth",
    "https://accounts.google.com/o/oauth2/v2/auth#fragment",
    "javascript:alert(1)",
    "/api/account/login",
  ]) {
    mock.mock.mockImplementation(async () =>
      Response.json({ ...fixture, authorizationUrl }),
    );
    await assert.rejects(
      startGoogleSignIn("redirect", policyAuthorization),
      AccountError,
    );
  }
});

test("Google account-control verification omits authorization and project data", async (t) => {
  const fixture = {
    transactionId: "opaque-transaction-123456",
    authorizationUrl:
      "https://accounts.google.com/o/oauth2/v2/auth?state=opaque",
    expiresAt: "2026-10-20T23:30:00.000Z",
  };
  const requests: { path: string; options?: RequestInit }[] = [];
  t.mock.method(globalThis, "fetch", async (path, options) => {
    requests.push({ path: String(path), options });
    return Response.json(fixture);
  });
  assert.deepEqual(
    await startGoogleSignIn("redirect", undefined, true),
    fixture,
  );
  // A stale choices argument must not turn rights verification into a grant.
  assert.deepEqual(
    await startGoogleSignIn("popup", policyAuthorization, true),
    fixture,
  );
  for (const [index, mode] of ["redirect", "popup"].entries()) {
    assert.equal(requests[index].path, "/api/auth/v1/oidc/google/start");
    assert.deepEqual(JSON.parse(String(requests[index].options?.body)), {
      purpose: "account_access",
      verificationAction: "data",
      returnRoute: "builder",
      mode,
    });
    assert.equal(requests[index].options?.credentials, "same-origin");
    assert.equal(requests[index].options?.redirect, "manual");
  }
});

test("policy authorization posts only the five explicit choices/version fields and parses the session", async (t) => {
  const requests: { path: string; options?: RequestInit }[] = [];
  const mock = t.mock.method(globalThis, "fetch", async (path, options) => {
    requests.push({ path: String(path), options });
    return Response.json(account);
  });
  assert.deepEqual(await saveWebAccountPolicy(policyAuthorization), account);
  assert.equal(requests[0].path, "/api/account/policy");
  assert.equal(requests[0].options?.method, "POST");
  assert.deepEqual(JSON.parse(String(requests[0].options?.body)), {
    privacyNoticeVersion: ACCOUNT_POLICY.privacyNoticeVersion,
    termsVersion: ACCOUNT_POLICY.termsVersion,
    purposeVersion: ACCOUNT_POLICY.purposeVersion,
    accountDataAuthorized: true,
    termsAccepted: true,
  });
  const { policyAuthorizationRequired: _required, ...legacy } = account;
  mock.mock.mockImplementation(async () => Response.json(legacy));
  assert.equal(
    (await saveWebAccountPolicy(policyAuthorization))
      .policyAuthorizationRequired,
    true,
  );
  mock.mock.mockImplementation(async () =>
    Response.json({ ...account, expiresAt: "bad" }),
  );
  await assert.rejects(saveWebAccountPolicy(policyAuthorization), AccountError);
});

test("transaction polling and cancellation expose only bounded status, never identity or tokens", async (t) => {
  const requests: { path: string; options?: RequestInit }[] = [];
  const mock = t.mock.method(globalThis, "fetch", async (path, options) => {
    requests.push({ path: String(path), options });
    return Response.json({
      status: "completed",
      email: "discard@example.test",
      token: "discard",
    });
  });
  const id = "opaque-transaction-123456";
  assert.equal(await loadGoogleSignInStatus(id), "completed");
  assert.equal(await cancelGoogleSignIn(id), "completed");
  assert.equal(requests[0].path, `/api/auth/v1/transactions/${id}/status`);
  assert.equal(requests[0].options?.method, "GET");
  assert.equal(requests[1].path, `/api/auth/v1/transactions/${id}/cancel`);
  assert.equal(requests[1].options?.method, "POST");
  assert.equal(requests[1].options?.body, "{}");
  await assert.rejects(loadGoogleSignInStatus("../other"), AccountError);
  assert.equal(requests.length, 2);
  mock.mock.mockImplementation(async () =>
    Response.json({ status: "approved" }),
  );
  await assert.rejects(loadGoogleSignInStatus(id), AccountError);
  mock.mock.mockImplementation(async () =>
    Response.json({ status: "pending" }),
  );
  await assert.rejects(cancelGoogleSignIn(id), AccountError);
});

test("only OTP verification establishes a session; session reads are GET and payloads contain no project data", async (t) => {
  const requests: Array<{
    url: string;
    method: string | undefined;
    body: unknown;
  }> = [];
  t.mock.method(
    globalThis,
    "fetch",
    async (input: RequestInfo | URL, options?: RequestInit) => {
      requests.push({
        url: String(input),
        method: options?.method,
        body: options?.body ? JSON.parse(String(options.body)) : null,
      });
      return Response.json(
        String(input).endsWith("otp/request") ? challenge : account,
      );
    },
  );
  assert.deepEqual(await loadWebAccount(), account);
  assert.deepEqual(
    await requestEmailCode("  person@example.test  ", policyAuthorization),
    challenge,
  );
  assert.deepEqual(
    await verifyEmailCode(challenge.challengeId, "012345"),
    account,
  );
  assert.deepEqual(requests, [
    { url: "/api/account/session", method: "GET", body: null },
    {
      url: "/api/account/otp/request",
      method: "POST",
      body: { email: "person@example.test", policyAuthorization },
    },
    {
      url: "/api/account/otp/verify",
      method: "POST",
      body: { challengeId: challenge.challengeId, code: "012345" },
    },
  ]);
});

test("OTP errors survive HTTP 401 and rate limits expose bounded retry information", async (t) => {
  const mock = t.mock.method(globalThis, "fetch", async () =>
    Response.json(
      { error: { code: "otp_invalid", message: "Invalid code" } },
      { status: 401 },
    ),
  );
  await assert.rejects(
    verifyEmailCode("challenge", "123456"),
    (error: unknown) =>
      error instanceof AccountError && error.code === "otp_invalid",
  );
  mock.mock.mockImplementation(async () =>
    Response.json(
      { error: { code: "otp_rate_limited", message: "Wait", retryAfter: 60 } },
      { status: 429 },
    ),
  );
  await assert.rejects(
    requestEmailCode("person@example.test", policyAuthorization),
    (error: unknown) =>
      error instanceof AccountError &&
      error.code === "otp_rate_limited" &&
      error.retryAfter === 60,
  );
});

test("account client rejects HTML and malformed application data", async (t) => {
  const mock = t.mock.method(
    globalThis,
    "fetch",
    async () =>
      new Response("Unexpected login page", {
        status: 403,
        headers: { "Content-Type": "text/html" },
      }),
  );
  await assert.rejects(
    loadWebAccount(),
    (error: unknown) =>
      error instanceof AccountError && error.code === "sign_in_required",
  );
  for (const body of [
    null,
    { ...account, expiresAt: "bad" },
    { ...account, remaining: 6 },
  ]) {
    mock.mock.mockImplementation(async () => Response.json(body));
    await assert.rejects(
      loadWebAccount(),
      (error: unknown) =>
        error instanceof AccountError && error.code === "unavailable",
    );
  }
  mock.mock.mockImplementation(async () =>
    Response.json({ ...challenge, resendAt: "bad" }),
  );
  await assert.rejects(
    requestEmailCode("person@example.test", policyAuthorization),
    (error: unknown) =>
      error instanceof AccountError && error.code === "unavailable",
  );
  mock.mock.mockImplementation(
    async () =>
      new Response("{", { headers: { "Content-Type": "application/json" } }),
  );
  await assert.rejects(
    loadWebAccount(),
    (error: unknown) =>
      error instanceof AccountError && error.code === "unavailable",
  );
});

test("account data download preserves the server's recent-authentication requirement", async (t) => {
  const mock = t.mock.method(globalThis, "fetch", async () =>
    Response.json(
      {
        error: { code: "reauthentication_required", message: "Sign in again." },
      },
      { status: 401 },
    ),
  );
  await assert.rejects(
    loadWebAccountData(),
    (error) =>
      error instanceof AccountError &&
      error.code === "reauthentication_required",
  );
  mock.mock.mockImplementation(async () =>
    Response.json({
      email: "person@example.test",
      identities: [],
      authorizations: [],
    }),
  );
  assert.deepEqual(await loadWebAccountData(), {
    email: "person@example.test",
    identities: [],
    authorizations: [],
  });
});
