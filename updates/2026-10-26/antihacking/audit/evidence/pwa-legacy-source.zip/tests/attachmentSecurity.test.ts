import test from "node:test";
import assert from "node:assert/strict";
import { zipSync, unzipSync, strToU8 } from "fflate";
import { PDFDocument, PDFName, PDFString } from "pdf-lib";
import {
  AttachmentSecurityError,
  assertPreparedAttachment,
  prepareAttachment,
} from "../src/attachmentSecurity";

const types = `<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>`;
const relations = `<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`;
const documentXml = `<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Project context &amp; decisions</w:t></w:r></w:p></w:body></w:document>`;
function docx(overrides: Record<string, string | Uint8Array> = {}) {
  const files: Record<string, string | Uint8Array> = {
    "[Content_Types].xml": types,
    "_rels/.rels": relations,
    "word/document.xml": documentXml,
    ...overrides,
  };
  return new Blob([
    zipSync(
      Object.fromEntries(
        Object.entries(files).map(([name, value]) => [
          name,
          typeof value === "string" ? strToU8(value) : value,
        ]),
      ),
    ),
  ]);
}
async function pdfBlob() {
  const document = await PDFDocument.create();
  document.addPage([300, 200]).drawText("Project context and decisions");
  return new Blob([await document.save()]);
}
const rejectsCode = async (operation: Promise<unknown>, code?: string) => {
  await assert.rejects(
    operation,
    (error) =>
      error instanceof AttachmentSecurityError &&
      (!code || error.code === code),
  );
};

test("static DOCX is parsed and reconstructed, and exact Blob proof cannot be forged", async () => {
  const original = docx();
  const clean = await prepareAttachment(original, "Context.DOCX");
  assert.notEqual(clean, original);
  assert.equal(
    clean.type,
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  );
  const files = unzipSync(new Uint8Array(await clean.arrayBuffer()));
  assert.match(
    new TextDecoder().decode(files["word/document.xml"]),
    /Project context &amp; decisions/,
  );
  assert.doesNotThrow(() => assertPreparedAttachment(clean, "Context.DOCX"));
  assert.throws(
    () => assertPreparedAttachment(original, "Context.DOCX"),
    /unprepared/,
  );
  assert.throws(
    () => assertPreparedAttachment(clean, "renamed.docx"),
    /unprepared/,
  );
  assert.throws(
    () => assertPreparedAttachment(clean.slice(), "Context.DOCX"),
    /unprepared/,
  );
  assert.equal(await prepareAttachment(clean, "Context.DOCX"), clean);
  const repeated = await prepareAttachment(original, "Context.DOCX");
  assert.deepEqual(
    new Uint8Array(await repeated.arrayBuffer()),
    new Uint8Array(await clean.arrayBuffer()),
  );
});

test("extension and actual content must both be admitted", async () => {
  for (const filename of [
    "run.exe",
    "script.js",
    "data.json",
    "notes.txt",
    "README.md",
    "vector.svg",
    "macro.docm",
    "old.doc",
    "photo.png.js",
  ])
    await rejectsCode(
      prepareAttachment(new Blob(["safe text"]), filename),
      "unsupported",
    );
  for (const filename of ["fake.docx", "fake.pdf", "fake.png", "fake.jpg"])
    await rejectsCode(
      prepareAttachment(new Blob(["<script>not admitted</script>"]), filename),
      "malformed",
    );
  await rejectsCode(
    prepareAttachment(
      new Blob([new Uint8Array(20 * 1024 * 1024 + 1)]),
      "large.pdf",
    ),
    "tooLarge",
  );
  await rejectsCode(prepareAttachment(new Blob(), "empty.pdf"), "tooLarge");
});

test("DOCX macros, embeddings, active fields, external targets and XML entities are rejected", async () => {
  const cases = [
    docx({ "word/vbaProject.bin": new Uint8Array([1, 2, 3]) }),
    docx({ "word/embeddings/oleObject1.bin": new Uint8Array([1, 2, 3]) }),
    docx({
      "word/document.xml": documentXml.replace(
        "<w:body>",
        '<w:body><w:fldSimple w:instr="DDEAUTO cmd"/>',
      ),
    }),
    docx({
      "word/document.xml": documentXml.replace(
        "<w:body>",
        "<w:body><w:object/>",
      ),
    }),
    docx({
      "_rels/.rels": relations.replace(
        'Target="word/document.xml"',
        'Target="https://example.com/payload" TargetMode="External"',
      ),
    }),
    docx({
      "_rels/.rels": relations.replace(
        'Target="word/document.xml"',
        'Target="word/document.xml" TargetMode="Extern&#97;l"',
      ),
    }),
    docx({
      "word/document.xml":
        '<!DOCTYPE w:document [<!ENTITY e SYSTEM "file:///local">]>' +
        documentXml,
    }),
    docx({
      "[Content_Types].xml": types.replace(
        "wordprocessingml.document.main+xml",
        "ms-word.document.macroEnabled.main+xml",
      ),
    }),
  ];
  for (const input of cases)
    await rejectsCode(prepareAttachment(input, "active.docx"), "activeContent");
});

test("DOCX rejects non-OOXML, traversal, duplicate names and excessive expansion", async () => {
  await rejectsCode(
    prepareAttachment(
      docx({ "word/document.xml": "<document/>" }),
      "not-word.docx",
    ),
    "malformed",
  );
  await rejectsCode(
    prepareAttachment(docx({ "../outside.xml": "<root/>" }), "traversal.docx"),
    "malformed",
  );
  await rejectsCode(
    prepareAttachment(
      docx({ "word/DOCUMENT.xml": documentXml }),
      "duplicate.docx",
    ),
    "malformed",
  );
  await rejectsCode(
    prepareAttachment(
      docx({ "word/oversize.xml": new Uint8Array(20 * 1024 * 1024 + 1) }),
      "expanded.docx",
    ),
    "tooLarge",
  );
  const deeplyNested = "<a>".repeat(65) + "</a>".repeat(65);
  await rejectsCode(
    prepareAttachment(
      docx({ "word/document.xml": deeplyNested }),
      "nested.docx",
    ),
    "malformed",
  );
});

test("DOCX mismatched local headers, encrypted flags, corrupt CRC and suffix polyglots fail closed", async () => {
  const original = new Uint8Array(await docx().arrayBuffer());
  const central = original.findIndex(
    (_, index) =>
      original[index] === 0x50 &&
      original[index + 1] === 0x4b &&
      original[index + 2] === 1 &&
      original[index + 3] === 2,
  );
  const wrongLocalName = original.slice();
  wrongLocalName[30] = 65;
  await rejectsCode(
    prepareAttachment(new Blob([wrongLocalName]), "header.docx"),
    "malformed",
  );
  const encrypted = original.slice();
  encrypted[central + 8] |= 1;
  await rejectsCode(
    prepareAttachment(new Blob([encrypted]), "encrypted.docx"),
    "unsupported",
  );
  const crc = original.slice();
  crc[14] ^= 1;
  await rejectsCode(
    prepareAttachment(new Blob([crc]), "crc.docx"),
    "malformed",
  );
  await rejectsCode(
    prepareAttachment(
      new Blob([original, "trailing executable bytes"]),
      "polyglot.docx",
    ),
    "malformed",
  );
});

test("static PDF is parsed and rewritten instead of passing through arbitrary trailing bytes", async () => {
  const input = await pdfBlob();
  const clean = await prepareAttachment(
    new Blob([input, "<script>discarded suffix</script>"]),
    "context.pdf",
  );
  assert.equal(clean.type, "application/pdf");
  assert.equal(
    (await PDFDocument.load(await clean.arrayBuffer())).getPageCount(),
    1,
  );
  assert.equal(
    new TextDecoder()
      .decode(await clean.arrayBuffer())
      .includes("discarded suffix"),
    false,
  );
  assert.doesNotThrow(() => assertPreparedAttachment(clean, "context.pdf"));
});

test("PDF JavaScript in compressed object streams and form actions are rejected", async () => {
  const document = await PDFDocument.create();
  document.addPage();
  document.addJavaScript("test", "void 0");
  await rejectsCode(
    prepareAttachment(
      new Blob([await document.save({ useObjectStreams: true })]),
      "compressed.pdf",
    ),
    "activeContent",
  );
  const form = await PDFDocument.create();
  const page = form.addPage();
  form.getForm().createTextField("name").addToPage(page);
  await rejectsCode(
    prepareAttachment(new Blob([await form.save()]), "form.pdf"),
    "activeContent",
  );
});

function rawPdf(objects: string[]) {
  let source = "%PDF-1.7\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(source.length);
    source += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xref = source.length;
  source += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  source += offsets
    .slice(1)
    .map((offset) => `${String(offset).padStart(10, "0")} 00000 n \n`)
    .join("");
  source += `trailer\n<< /Root 1 0 R /Size ${objects.length + 1} >>\nstartxref\n${xref}\n%%EOF\n`;
  return new Blob([source]);
}

function encodedActionPdf() {
  return rawPdf([
    "<< /Type /Catalog /Pages 2 0 R /#4Fpen#41ction 4 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 200] >>",
    "<< /S /Java#53cript /#4A#53 (void 0) >>",
  ]);
}
test("PDF escaped action and key names are decoded structurally", async () => {
  const input = encodedActionPdf();
  const parsed = await PDFDocument.load(await input.arrayBuffer());
  assert.ok(parsed.catalog.get(PDFName.of("OpenAction")));
  await rejectsCode(prepareAttachment(input, "encoded.pdf"), "activeContent");
});

test("PDF Flate expansion is bounded before object-stream/high-level parser allocation", async () => {
  const document = await PDFDocument.create();
  document.addPage();
  document.context.register(
    document.context.flateStream(new Uint8Array(8 * 1024 * 1024 + 1)),
  );
  const input = new Blob([await document.save({ useObjectStreams: false })]);
  assert.ok(input.size < 20_000);
  await rejectsCode(prepareAttachment(input, "expansion.pdf"), "tooLarge");
});

function pageTreeFixture(levels: number, duplicateChildren = false) {
  const objects = ["<< /Type /Catalog /Pages 2 0 R >>"];
  for (let level = 0; level < levels; level += 1) {
    const id = level + 2;
    const child = id + 1;
    const parent = level > 0 ? `/Parent ${id - 1} 0 R` : "";
    objects.push(
      `<< /Type /Pages ${parent} /Kids [${child} 0 R${duplicateChildren ? ` ${child} 0 R` : ""}] /Count 1 >>`,
    );
  }
  objects.push(
    `<< /Type /Page /Parent ${levels + 1} 0 R /MediaBox [0 0 300 200] >>`,
  );
  return rawPdf(objects);
}

test("PDF page-tree DAGs and cycles are rejected before high-level page traversal", async () => {
  const fixtures = [
    pageTreeFixture(22, true),
    rawPdf([
      "<< /Type /Catalog /Pages 2 0 R >>",
      "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
      "<< /Type /Pages /Parent 2 0 R /Kids [2 0 R] /Count 1 >>",
    ]),
  ];
  const originalGetPages = PDFDocument.prototype.getPages;
  let pageAccesses = 0;
  PDFDocument.prototype.getPages = function () {
    pageAccesses += 1;
    return originalGetPages.call(this);
  };
  try {
    for (const input of fixtures)
      await rejectsCode(prepareAttachment(input, "graph.pdf"), "malformed");
    assert.equal(pageAccesses, 0);
  } finally {
    PDFDocument.prototype.getPages = originalGetPages;
  }
});

test("PDF page-tree validation enforces parent links, actual counts and depth", async () => {
  for (const objects of [
    [
      "<< /Type /Catalog /Pages 2 0 R >>",
      "<< /Type /Pages /Kids [3 0 R] /Count 2 >>",
      "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 200] >>",
    ],
    [
      "<< /Type /Catalog /Pages 2 0 R >>",
      "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
      "<< /Type /Page /Parent 1 0 R /MediaBox [0 0 300 200] >>",
    ],
  ])
    await rejectsCode(
      prepareAttachment(rawPdf(objects), "invalid-tree.pdf"),
      "malformed",
    );
  await rejectsCode(
    prepareAttachment(pageTreeFixture(66), "deep-tree.pdf"),
    "tooLarge",
  );
  const ordinary = await prepareAttachment(
    pageTreeFixture(20),
    "ordinary-tree.pdf",
  );
  assert.equal(
    (await PDFDocument.load(await ordinary.arrayBuffer())).getPageCount(),
    1,
  );
});

test("PDF stream external-file keys are rejected including escaped keys", async () => {
  for (const key of ["F", "#46", "FFilter", "FDecodeParms"]) {
    const input = rawPdf([
      "<< /Type /Catalog /Pages 2 0 R >>",
      "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
      "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 200] >>",
      `<< /Length 0 /${key} << /FS /URL /F (https://example.invalid/external-content) >> >>\nstream\n\nendstream`,
    ]);
    await rejectsCode(
      prepareAttachment(input, "external.pdf"),
      "activeContent",
    );
  }
});

test("PDF static HTTPS links remain usable; non-HTTPS and launch actions fail closed", async () => {
  for (const [uri, accepted] of [
    ["https://example.com/context", true],
    ["javascript:void(0)", false],
    ["file:///local", false],
    ["http://example.com", false],
  ] as const) {
    const document = await PDFDocument.create();
    const page = document.addPage();
    page.node.addAnnot(
      document.context.register(
        document.context.obj({
          Type: "Annot",
          Subtype: "Link",
          F: 4,
          Rect: [0, 0, 50, 20],
          A: { S: "URI", URI: PDFString.of(uri) },
        }),
      ),
    );
    const input = new Blob([await document.save()]);
    if (accepted)
      assert.equal(
        (await prepareAttachment(input, "links.pdf")).type,
        "application/pdf",
      );
    else
      await rejectsCode(prepareAttachment(input, "links.pdf"), "activeContent");
  }
  const launch = await PDFDocument.create();
  launch.addPage();
  launch.catalog.set(
    PDFName.of("OpenAction"),
    launch.context.obj({ S: "Launch", F: PDFString.of("run.exe") }),
  );
  await rejectsCode(
    prepareAttachment(new Blob([await launch.save()]), "launch.pdf"),
    "activeContent",
  );
});

test("image dimensions are bounded before browser decode, with no original-byte fallback", async () => {
  const bytes = new Uint8Array(33);
  const view = new DataView(bytes.buffer);
  view.setUint32(0, 0x89504e47);
  view.setUint32(4, 0x0d0a1a0a);
  view.setUint32(8, 13);
  view.setUint32(12, 0x49484452);
  view.setUint32(16, 100_000);
  view.setUint32(20, 100_000);
  await rejectsCode(
    prepareAttachment(new Blob([bytes]), "huge.png"),
    "tooLarge",
  );
  view.setUint32(16, 1);
  view.setUint32(20, 1);
  await rejectsCode(
    prepareAttachment(new Blob([bytes]), "cannot-decode.png"),
    "unavailable",
  );
});
