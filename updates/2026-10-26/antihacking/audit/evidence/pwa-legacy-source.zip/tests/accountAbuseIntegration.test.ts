import assert from "node:assert/strict";
import test from "node:test";
import {
  createRightsTransaction,
  completeRightsAccess,
} from "../functions/_lib/auth/rights";
import { harness } from "./helpers/accountHarness";
import { POLICY_AUTHORIZATION } from "./helpers/accountHarness";

async function fixture() {
  const h = await harness();
  const cookie = await h.login();
  const accountId = h.db.sqlite.prepare("SELECT id FROM accounts").get()!
    .id as string;
  const env = {
    ...h.env,
    ACCOUNT_ABUSE_ENABLED: "true",
    ACCOUNT_AUTH_LOCATOR_KEY: "3".repeat(64),
  };
  function suspend() {
    h.db.sqlite
      .prepare(
        `INSERT INTO account_abuse_state(account_id,level,episode_window_start,last_episode_at,suspended_until,recurrence_until,expires_at)
      VALUES(?,1,?,?,?,?,?)`,
      )
      .run(
        accountId,
        h.db.now,
        h.db.now,
        h.db.now + 600000,
        h.db.now + 172800000,
        h.db.now + 172800000,
      );
  }
  h.db.sqlite
    .prepare(
      "INSERT INTO account_external_identities(id,account_id,issuer,subject,locator_hmac,created_at,last_authenticated_at) VALUES(?,?,'https://accounts.google.com','subject','locator',?,?)",
    )
    .run(crypto.randomUUID(), accountId, h.db.now, h.db.now);
  const rightsHeaders = (transactionId: string) => ({
    "X-Accreatio-Rights": "1",
    "X-Accreatio-Rights-Transaction": transactionId,
  });
  async function proof(action: "data" | "delete") {
    const raw = (action === "data" ? "a" : "b").repeat(64);
    const hash = Buffer.from(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)),
    ).toString("hex");
    const transactionId = crypto.randomUUID(),
      claimNonce = crypto.randomUUID();
    await createRightsTransaction(h.db, {
      id: transactionId,
      stateHash: crypto.randomUUID(),
      browserHash: crypto.randomUUID(),
      ipHash: "fixture-ip",
      secretsCiphertext: "synthetic-encrypted-state",
      returnMode: "popup",
      previousSessionTokenHash: null,
      purpose: "account_access",
      provider: "google",
      verificationAction: action,
      rightsOnly: true,
    });
    h.db.sqlite
      .prepare(
        "UPDATE account_auth_transactions SET status='claimed',claim_nonce=? WHERE id=?",
      )
      .run(claimNonce, transactionId);
    await completeRightsAccess(h.db, {
      transactionId,
      claimNonce,
      sessionTokenHash: hash,
      identity: {
        issuer: "https://accounts.google.com",
        subject: "subject",
        email: null,
        emailVerified: false,
        authoritativeEmail: false,
        hostedDomain: null,
        displayName: null,
      },
    });
    return { cookie: `__Host-accreatio_rights=${raw}`, transactionId };
  }
  return { ...h, cookie, accountId, env, suspend, proof, rightsHeaders };
}

test("suspension rejects product access and policy changes while scoped own-data remains available", async () => {
  const f = await fixture();
  f.suspend();
  for (const [action, body] of [
    ["session", undefined],
    ["policy", POLICY_AUTHORIZATION],
  ] as const) {
    const response = await f.call(action, {
      cookie: f.cookie,
      body,
      env: f.env,
    });
    assert.equal(response.status, 429);
    assert.equal((await response.json()).error.code, "account_suspended");
    assert.equal(response.headers.get("Retry-After"), "600");
  }
  const rights = await f.proof("data");
  const ordinary = rights.cookie.replace(
    "__Host-accreatio_rights",
    "__Host-accreatio_session",
  );
  assert.equal(
    (await f.call("session", { cookie: ordinary, env: f.env })).status,
    401,
  );
  const data = await f.call("data", {
    method: "GET",
    cookie: `${f.cookie}; ${rights.cookie}`,
    headers: f.rightsHeaders(rights.transactionId),
    env: f.env,
  });
  assert.equal(data.status, 200);
  const payload = await data.json();
  assert.equal(payload.accountId, f.accountId);
  assert.equal(
    payload.securityRestriction.reason,
    "repeated_request_limit_exceeded",
  );
  assert.equal(payload.securityRestriction.suspendedUntil, f.db.now + 600000);
  assert.equal(JSON.stringify(payload).includes("n1:"), false);
  assert.equal(
    (
      await f.call("delete", {
        cookie: rights.cookie,
        headers: f.rightsHeaders(rights.transactionId),
        env: f.env,
      })
    ).status,
    401,
  );
});

test("rights deletion works during suspension and clears only its own browser cookie", async () => {
  const f = await fixture();
  f.suspend();
  const rights = await f.proof("delete");
  const response = await f.call("delete", {
    cookie: `${f.cookie}; ${rights.cookie}`,
    headers: f.rightsHeaders(rights.transactionId),
    env: f.env,
  });
  assert.equal(response.status, 200);
  assert.match(
    response.headers.get("Set-Cookie")!,
    /__Host-accreatio_rights=;/,
  );
  assert.doesNotMatch(
    response.headers.get("Set-Cookie")!,
    /__Host-accreatio_session=/,
  );
  assert.ok(
    f.db.sqlite
      .prepare("SELECT deleted_at FROM accounts WHERE id=?")
      .get(f.accountId)!.deleted_at,
  );
  assert.equal(
    f.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
    0,
  );
});

test("ordinary logout revokes the rights proof and clears both necessary cookies", async () => {
  const f = await fixture();
  const rights = await f.proof("data");
  const response = await f.call("logout", {
    cookie: `${f.cookie}; ${rights.cookie}`,
    env: f.env,
  });
  assert.equal(response.status, 200);
  assert.equal(response.headers.getSetCookie().length, 2);
  assert.equal(
    f.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
    0,
  );
});

test("logout remains idempotent after ordinary session revocation and revokes a remaining rights proof", async () => {
  const f = await fixture();
  f.db.sqlite.exec("DELETE FROM account_sessions");
  const rights = await f.proof("data");
  f.suspend();
  const response = await f.call("logout", {
    cookie: `${f.cookie}; ${rights.cookie}`,
    env: f.env,
  });
  assert.equal(response.status, 200);
  assert.equal(response.headers.getSetCookie().length, 2);
  assert.equal(
    f.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
    0,
  );
  assert.equal((await f.call("logout", { env: f.env })).status, 200);
});

test("a rights cookie replaced by another tab cannot switch the account behind a pending deletion confirmation", async () => {
  const f = await fixture();
  const rightsA = await f.proof("delete");
  const otherId = crypto.randomUUID();
  f.db.sqlite
    .prepare(
      "INSERT INTO accounts(id,identity_key,created_at,last_seen_at) VALUES(?,?,?,?)",
    )
    .run(otherId, "other-account", f.db.now, f.db.now);
  const tokenB = "c".repeat(64);
  const hashB = Buffer.from(
    await crypto.subtle.digest("SHA-256", new TextEncoder().encode(tokenB)),
  ).toString("hex");
  f.db.sqlite
    .prepare("INSERT INTO account_sessions VALUES(?,?,?)")
    .run(hashB, otherId, f.db.now + 300000);
  f.db.sqlite
    .prepare(
      "INSERT INTO account_session_metadata(token_hash,method,authenticated_at,security_version,verification_action,rights_only) VALUES(?,'oidc',?,0,'delete',1)",
    )
    .run(hashB, f.db.now);
  const response = await f.call("delete", {
    cookie: `__Host-accreatio_rights=${tokenB}`,
    headers: f.rightsHeaders(rightsA.transactionId),
    env: f.env,
  });
  assert.equal(response.status, 401);
  assert.equal((await response.json()).error.code, "reauthentication_required");
  assert.equal(
    f.db.sqlite
      .prepare(
        "SELECT COUNT(*) AS n FROM accounts WHERE deleted_at IS NOT NULL",
      )
      .get()!.n,
    0,
  );
  assert.equal(
    (
      await f.call("delete", {
        cookie: rightsA.cookie,
        headers: { "X-Accreatio-Rights": "1" },
        env: f.env,
      })
    ).status,
    401,
  );
});
