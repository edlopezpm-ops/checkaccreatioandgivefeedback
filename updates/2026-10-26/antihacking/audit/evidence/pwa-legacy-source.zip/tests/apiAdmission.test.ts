import assert from "node:assert/strict";
import test from "node:test";
import { harness } from "./helpers/accountHarness";
import {
  handleApiAdmission,
  classifyApiRequest,
} from "../functions/_lib/apiAdmission";
import { onRequest } from "../functions/api/_middleware";
import { ApiError, SECURITY_HEADERS } from "../functions/_lib/http";

const request = (path: string) =>
  new Request(`https://accreatio.test${path}`, {
    headers: { "CF-Connecting-IP": "192.0.2.1" },
  });
function assertSecurity(response: Response) {
  for (const [name, value] of Object.entries(SECURITY_HEADERS))
    assert.equal(response.headers.get(name), value);
}

test("production API aliases cannot bypass the canonical edge hostname before D1", async () => {
  const h = await harness();
  h.db.fail = true;
  for (const [url, config] of [
    ["https://accreatio.pages.dev/api/account/session", "accreatio.com"],
    ["https://hash.accreatio.pages.dev/api/blog/posts", "accreatio.com"],
    [
      "https://accreatio.com.attacker.test/api/account/session",
      "accreatio.com",
    ],
    ["http://accreatio.com/api/blog/posts", "accreatio.com"],
    ["https://accreatio.com:8443/api/blog/posts", "accreatio.com"],
    ["https://accreatio.com/api/blog/posts", "*.accreatio.com"],
    ["https://accreatio.com/api/blog/posts", ""],
  ]) {
    const response = await handleApiAdmission({
      request: new Request(url),
      env: {
        ...h.env,
        API_ALLOWED_HOSTS: config,
        ACCOUNT_ABUSE_ENABLED: "true",
      },
      async next() {
        assert.fail("alias must stop before handler");
      },
    });
    assert.equal(response.status, 403);
    assert.equal((await response.json()).error.code, "unapproved_host");
  }
  for (const [host, allowed] of [
    ["accreatio.com", "accreatio.com"],
    [
      "google-oidc-preview.accreatio.pages.dev",
      "google-oidc-preview.accreatio.pages.dev",
    ],
  ]) {
    const response = await handleApiAdmission({
      request: new Request(`https://${host}/api/blog/posts`),
      env: { API_ALLOWED_HOSTS: allowed },
      async next() {
        return new Response("ready");
      },
    });
    assert.equal(response.status, 200);
  }
});

test("invalid request envelopes stop before database/provider work", async () => {
  const h = await harness();
  h.db.fail = true;
  for (const [input, status] of [
    [
      new Request("https://accreatio.test/api/blog/posts", { method: "PUT" }),
      405,
    ],
    [
      new Request(
        "https://accreatio.test/api/blog/posts?x=" + "a".repeat(8192),
      ),
      414,
    ],
    [
      new Request("https://accreatio.test/api/admin/blog/posts", {
        method: "POST",
        headers: { "Content-Length": "32769" },
      }),
      413,
    ],
    [
      new Request("https://accreatio.test/api/admin/blog/posts", {
        method: "POST",
        headers: { "Content-Length": "invalid" },
      }),
      400,
    ],
  ] as const) {
    const response = await handleApiAdmission({
      request: input,
      env: { ...h.env, ACCOUNT_ABUSE_ENABLED: "true" },
      async next() {
        assert.fail("handler must not run");
      },
    });
    assert.equal(response.status, status);
    assertSecurity(response);
  }
});

test("agent-provider and user-agent spoofing cannot create a fresh network budget", async () => {
  const h = await harness();
  let proceeded = 0;
  const agents = [
    "Mozilla/5.0",
    "GPTBot",
    "ClaudeBot",
    "Gemini",
    "Unknown-Agent",
  ];
  for (let index = 0; index < 25; index += 1) {
    const response = await handleApiAdmission({
      request: new Request(
        `https://accreatio.test/api/auth/v1/oidc/google/start?email=alias${index}`,
        {
          headers: {
            "CF-Connecting-IP": "192.0.2.1",
            "User-Agent": agents[index % agents.length],
          },
        },
      ),
      env: {
        ...h.env,
        ACCOUNT_ABUSE_ENABLED: "true",
        ACCOUNT_AUTH_LOCATOR_KEY: "3".repeat(64),
      },
      async next() {
        proceeded++;
        return new Response("ready");
      },
    });
    assert.equal(response.status, index < 20 ? 200 : 429);
  }
  assert.equal(proceeded, 20);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_abuse_buckets")
      .get()!.n,
    1,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_abuse_state").get()!
      .n,
    0,
  );
});

test("network middleware aggregates providers and encoded aliases before expensive handler execution", async () => {
  const h = await harness();
  let proceeded = 0;
  const paths = [
    "/api/auth/v1/oidc/google/start",
    "/api/auth/v1/oidc/github/start?different=email",
    "/api/auth/v1/oidc/google/%73tart/",
  ];
  const result = await Promise.all(
    Array.from({ length: 30 }, (_, index) =>
      onRequest({
        request: request(paths[index % paths.length]),
        env: {
          ...h.env,
          ACCOUNT_ABUSE_ENABLED: "true",
          ACCOUNT_AUTH_LOCATOR_KEY: "3".repeat(64),
        },
        async next() {
          proceeded++;
          return new Response("synthetic handler");
        },
      }),
    ),
  );
  assert.equal(proceeded, 20);
  assert.equal(result.filter((response) => response.status === 429).length, 10);
  for (const response of result) assertSecurity(response);
  const denied = result.find((response) => response.status === 429)!;
  const body = await denied.json();
  assert.equal(body.error.code, "request_rate_limited");
  assert.ok(
    Number.isFinite(body.error.retryAfter) && body.error.retryAfter > 0,
  );
  assert.equal(
    denied.headers.get("Retry-After"),
    String(body.error.retryAfter),
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_abuse_buckets")
      .get()!.n,
    1,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_abuse_state").get()!
      .n,
    0,
  );
});

test("unknown paths share one finite class rather than allocating arbitrary route keys", async () => {
  const h = await harness();
  let proceeded = 0;
  const result = await Promise.all(
    Array.from({ length: 200 }, (_, index) =>
      handleApiAdmission({
        request: request(`/api/unknown-${index}?route=${index}`),
        env: {
          ...h.env,
          ACCOUNT_ABUSE_ENABLED: "true",
          ACCOUNT_AUTH_LOCATOR_KEY: "3".repeat(64),
        },
        async next() {
          proceeded++;
          return new Response(null, { status: 404 });
        },
      }),
    ),
  );
  assert.equal(proceeded, 180);
  assert.equal(result.filter((response) => response.status === 429).length, 20);
  assert.deepEqual(
    h.db.sqlite
      .prepare("SELECT route_class,request_count FROM account_abuse_buckets")
      .all()
      .map((row) => ({ ...row })),
    [{ route_class: "public-read", request_count: 180 }],
  );
  assertSecurity(result[0]);
});

test("reserved rights paths reach session validation without consuming anonymous bucket capacity", async () => {
  const h = await harness();
  h.db.sqlite
    .exec(`WITH RECURSIVE n(value) AS(VALUES(1) UNION ALL SELECT value+1 FROM n WHERE value<4096)
    INSERT INTO account_abuse_buckets(scope_key,scope_kind,route_class,window_start,request_count,expires_at)
    SELECT 'fixture-'||value,'network','public-read',0,0,${h.db.now + 3_600_000} FROM n;`);
  for (const path of [
    "/api/account/data",
    "/api/account/delete",
    "/api/auth/v1/rights/google/start",
    "/api/auth/v1/rights/github/start",
  ]) {
    assert.equal(classifyApiRequest(request(path)), null);
    let reached = false;
    const response = await handleApiAdmission({
      request: request(path),
      env: { ...h.env, ACCOUNT_ABUSE_ENABLED: "true" },
      async next() {
        reached = true;
        throw new ApiError(
          401,
          "sign_in_required",
          "Use your existing account.",
        );
      },
    });
    assert.equal(reached, true);
    assert.equal(response.status, 401);
    assertSecurity(response);
  }
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_abuse_buckets")
      .get()!.n,
    4096,
  );
  assert.equal(
    classifyApiRequest(request("/api/account/data/unrecognized")),
    "public-read",
  );
  assert.equal(
    classifyApiRequest(request("/api/auth/v1/oidc/google/callback")),
    "callback",
  );
  assert.equal(
    classifyApiRequest(request("/api/auth/v1/transactions/opaque/status")),
    "auth-status",
  );
});

test("disabled middleware preserves handlers, while failures remain generic and all responses get headers", async () => {
  const h = await harness();
  h.db.fail = true;
  const disabled = await handleApiAdmission({
    request: request("/api/account/session"),
    env: h.env,
    async next() {
      return new Response("ready", {
        headers: { "X-Frame-Options": "SAMEORIGIN" },
      });
    },
  });
  assert.equal(disabled.status, 200);
  assert.equal(await disabled.text(), "ready");
  assertSecurity(disabled);
  let proceeded = false;
  const failed = await handleApiAdmission({
    request: request("/api/account/session"),
    env: {
      ...h.env,
      ACCOUNT_ABUSE_ENABLED: "true",
      ACCOUNT_AUTH_LOCATOR_KEY: "3".repeat(64),
    },
    async next() {
      proceeded = true;
      return new Response("unreachable");
    },
  });
  assert.equal(failed.status, 503);
  assert.equal(proceeded, false);
  assertSecurity(failed);
  assert.doesNotMatch(await failed.text(), /database offline|192\.0\.2|333333/);
  const exception = await handleApiAdmission({
    request: request("/api/other"),
    env: h.env,
    async next() {
      throw new Error("private synthetic diagnostic");
    },
  });
  assert.equal(exception.status, 503);
  assertSecurity(exception);
  assert.doesNotMatch(await exception.text(), /private synthetic/);
});
