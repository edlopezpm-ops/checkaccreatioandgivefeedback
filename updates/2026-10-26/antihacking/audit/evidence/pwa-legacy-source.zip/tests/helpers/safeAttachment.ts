import { PDFDocument, StandardFonts } from "pdf-lib";
import { prepareAttachment } from "../../src/attachmentSecurity";
import type { WebAttachment } from "../../src/types";

export async function staticPdfBlob(): Promise<Blob> {
  const doc = await PDFDocument.create();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  doc.addPage().drawText("Local attachment fixture", { font });
  return new Blob([new Uint8Array(await doc.save())], {
    type: "application/pdf",
  });
}

export async function safePdfAttachment(
  name = "source.pdf",
  id = "one",
): Promise<WebAttachment> {
  const blob = await prepareAttachment(await staticPdfBlob(), name);
  return { id, name, extension: ".pdf", size: blob.size, blob };
}
