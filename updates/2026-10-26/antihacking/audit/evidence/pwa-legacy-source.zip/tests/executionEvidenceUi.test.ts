import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { OutcomePanel } from "../src/components/creation/OutcomePanel";
import type { ExecutionResult } from "../src/types";

const app = fs.readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
const outcome = fs.readFileSync(
  new URL("../src/components/creation/OutcomePanel.tsx", import.meta.url),
  "utf8",
);

test("execution evidence UI includes localized outcome and recovery copy", () => {
  for (const phrase of [
    "Review completed. No ZIP was created or downloaded.",
    "Revisión completada. No se creó ni descargó ningún ZIP.",
    "Some work completed",
    "Parte del trabajo se completó",
    "Nothing was completed",
    "No se completó nada",
    "ZIP prepared; download requested",
    "ZIP preparado; descarga solicitada",
    "Created or versioned",
    "Creado o versionado",
    "Failed",
    "Skipped",
  ])
    assert.match(
      outcome,
      new RegExp(phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")),
    );
});

test("execution evidence UI avoids browser-save certainty and announces results", () => {
  assert.doesNotMatch(
    outcome,
    /ZIP exported|ZIP exportado|ZIP saved|ZIP guardado/,
  );
  assert.match(outcome, /aria-live="polite"/);
  assert.match(outcome, /cannot confirm that the file was saved/);
  assert.match(outcome, /Edit and export again/);
  assert.match(outcome, /new guarded operation/);
  assert.match(outcome, /Nothing was pushed to GitHub automatically/);
});

test("creation switches to the dedicated outcome and offers only safe follow-up actions", () => {
  assert.match(app, /running \|\| result \? \(/);
  assert.match(app, /<OutcomePanel/);
  assert.doesNotMatch(app, /function Result\(/);
  assert.match(outcome, /onCopyPath/);
  assert.match(outcome, /onOpenOrchestration/);
  assert.doesNotMatch(outcome, /bridge\.execute|buildWebExport|downloadZip\(/);
});

test("only a successful web dry-run offers the guarded ZIP callback and disables it while busy", () => {
  const result: ExecutionResult = {
    operationId: "review-only",
    ok: true,
    dryRun: true,
    completed: [],
    logs: [],
    outcome: "dry-run",
    steps: [],
    artifacts: [],
  };
  const render = (
    isWeb = true,
    running = false,
    downloadZipDisabled = false,
    value = result,
  ) =>
    renderToStaticMarkup(
      createElement(OutcomePanel, {
        isWeb,
        locale: "en",
        running,
        downloadZipDisabled,
        result: value,
        onBackToReview: () => {},
        onCopyPath: () => {},
        onOpenOrchestration: () => {},
        onDownloadZip: () => {},
      }),
    );
  const ready = render();
  assert.match(ready, /Create and download ZIP/);
  assert.match(ready, /confirm the details before the download/);
  assert.doesNotMatch(ready, /Turn it off in Review/);
  assert.doesNotMatch(ready, /disabled=""/);
  assert.match(render(true, false, true), /class="start" disabled=""/);
  const running = render(true, true);
  assert.match(running, /Preparing ZIP…/);
  assert.match(running, /class="start" disabled=""/);
  assert.doesNotMatch(render(false), /Create and download ZIP/);
  assert.match(render(false), /Turn it off in Review/);
  assert.doesNotMatch(
    render(true, false, false, { ...result, ok: false, outcome: "failure" }),
    /Create and download ZIP/,
  );
  assert.doesNotMatch(
    render(true, false, false, {
      ...result,
      dryRun: false,
      outcome: "success",
    }),
    /Create and download ZIP/,
  );
});
