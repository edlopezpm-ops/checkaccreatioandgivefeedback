import assert from "node:assert/strict";
import test from "node:test";
import { DatabaseSync, backup } from "node:sqlite";
import { readFileSync } from "node:fs";
import { mkdir, mkdtemp } from "node:fs/promises";
import path from "node:path";
import { harness, POLICY_AUTHORIZATION } from "./helpers/accountHarness";
import { handleOidc, type OidcAction } from "../functions/_lib/auth/oidc";
import { githubSubject } from "../functions/_lib/auth/github";
import { oidcStore } from "../functions/_lib/auth/oidc-store";
import { handleAccount } from "../functions/_lib/accounts";

const origin = "https://accreatio.pages.dev";
const callbackPath = "/api/auth/v1/oidc/github/callback";
const sha = async (value: string) =>
  Buffer.from(
    await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)),
  ).toString("hex");

// Production handlers, cryptography, SQL and migration run locally. The only
// substitution is GitHub HTTPS; no provider credential or account is used.
async function setup() {
  const h = await harness();
  Object.assign(h.env, {
    ACCOUNT_GITHUB_ENABLED: "true",
    ACCOUNT_OIDC_ENABLED: "true",
    ACCOUNT_OTP_ENABLED: "false",
    GITHUB_CLIENT_ID: "Iv23.synthetic",
    GITHUB_CLIENT_SECRET: "synthetic-only-secret",
    GITHUB_REDIRECT_URI: `${origin}${callbackPath}`,
    GOOGLE_CLIENT_ID: "fixture.apps.googleusercontent.com",
    GOOGLE_CLIENT_SECRET: "fixture-secret",
    GOOGLE_REDIRECT_URI: `${origin}/api/auth/v1/oidc/google/callback`,
    ACCOUNT_EMAIL_ENCRYPTION_KEY: "1".repeat(64),
    ACCOUNT_EMAIL_LOOKUP_KEY: "2".repeat(64),
    ACCOUNT_AUTH_LOCATOR_KEY: "3".repeat(64),
    ACCOUNT_OIDC_TRANSACTION_KEY: "4".repeat(64),
  });
  let authorization: URL;
  let email: string | null = "private@example.test";
  let subject = "9007199254740993";
  let pages = 1;
  let failure = "";
  let interrupt: (() => Promise<void>) | undefined;
  const requests: string[] = [];
  const deps = {
    ...h.dependencies,
    fetch: async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = String(input);
      requests.push(url);
      assert.equal(init?.redirect, "manual");
      assert.ok(init?.signal);
      if (failure === "timeout")
        throw new DOMException("synthetic-private-error", "TimeoutError");
      if (url === "https://github.com/login/oauth/access_token") {
        const body = init?.body as URLSearchParams;
        assert.equal(body.get("client_id"), h.env.GITHUB_CLIENT_ID);
        assert.equal(body.get("client_secret"), h.env.GITHUB_CLIENT_SECRET);
        assert.equal(body.get("redirect_uri"), h.env.GITHUB_REDIRECT_URI);
        assert.equal(body.get("code"), "fixture-code");
        const challenge = Buffer.from(
          await crypto.subtle.digest(
            "SHA-256",
            new TextEncoder().encode(body.get("code_verifier")!),
          ),
        ).toString("base64url");
        assert.equal(
          challenge,
          authorization.searchParams.get("code_challenge"),
        );
        if (interrupt) await interrupt();
        if (failure === "invalid_code")
          return Response.json({ error: "bad_verification_code" });
        if (failure === "redirect")
          return new Response(null, {
            status: 302,
            headers: { Location: "https://attacker.invalid" },
          });
        return Response.json({
          access_token: "synthetic_transient_token",
          token_type: "bearer",
          refresh_token: "discard_me",
        });
      }
      assert.equal(
        (init?.headers as Record<string, string>).Authorization,
        "Bearer synthetic_transient_token",
      );
      if (failure === "permission")
        return Response.json(
          { message: "private@example.test" },
          { status: 403 },
        );
      if (url === "https://api.github.com/user")
        return new Response(
          `{"id":${subject},"login":"mutable-handle","name":"Synthetic GitHub","email":null,"avatar_url":"https://unused.invalid/avatar"}`,
          { headers: { "Content-Type": "application/json" } },
        );
      const parsed = new URL(url);
      assert.equal(
        parsed.origin + parsed.pathname,
        "https://api.github.com/user/emails",
      );
      const page = Number(parsed.searchParams.get("page"));
      assert.equal(parsed.searchParams.get("per_page"), "100");
      return Response.json(
        page === pages && email
          ? [{ email, primary: true, verified: true }]
          : [
              {
                email: "secondary@example.test",
                primary: false,
                verified: true,
              },
              {
                email: "unverified@example.test",
                primary: true,
                verified: false,
              },
            ],
        {
          headers:
            page < pages
              ? {
                  Link: `<https://api.github.com/user/emails?page=${page + 1}>; rel="next"`,
                }
              : {},
        },
      );
    },
  };
  async function call(
    action: OidcAction,
    options: {
      body?: unknown;
      cookie?: string;
      path?: string;
      id?: string;
      provider?: "google" | "github";
      origin?: string;
      env?: typeof h.env;
    } = {},
  ) {
    return handleOidc(
      {
        request: new Request(
          `${origin}${options.path ?? `/api/auth/v1/${action}`}`,
          {
            method: action === "start" || action === "cancel" ? "POST" : "GET",
            headers: {
              Origin: options.origin ?? origin,
              "Content-Type": "application/json",
              ...(options.cookie ? { Cookie: options.cookie } : {}),
            },
            ...(options.body === undefined
              ? {}
              : { body: JSON.stringify(options.body) }),
          },
        ),
        env: options.env ?? h.env,
        params: { id: options.id ?? "" },
      },
      action,
      deps,
      undefined,
      options.provider ?? "github",
    );
  }
  async function start(
    cookie?: string,
    purpose: "sign_in" | "account_access" | "link_provider" = "sign_in",
    verificationAction?: string,
  ) {
    const response = await call("start", {
      cookie,
      body: {
        purpose,
        mode: "popup",
        returnRoute: "builder",
        ...(purpose === "sign_in"
          ? { policyAuthorization: POLICY_AUTHORIZATION }
          : {}),
        ...(verificationAction ? { verificationAction } : {}),
      },
    });
    assert.equal(response.status, 200, await response.clone().text());
    const result = await response.json();
    authorization = new URL(result.authorizationUrl);
    return {
      ...result,
      cookie: response.headers.get("Set-Cookie")!.split(";")[0],
      response,
    };
  }
  function callback(
    cookie: string,
    query = `code=fixture-code&state=${authorization.searchParams.get("state")}`,
  ) {
    return call("callback", { cookie, path: `${callbackPath}?${query}` });
  }
  async function login(cookie?: string) {
    const tx = await start(cookie);
    const response = await callback(tx.cookie);
    assert.match(response.headers.get("Location")!, /auth=success$/);
    return {
      tx,
      response,
      cookie: response.headers.get("Set-Cookie")!.split(";")[0],
    };
  }
  async function verify(cookie: string, action: string) {
    const tx = await start(cookie, "account_access", action);
    const response = await callback(tx.cookie);
    assert.match(response.headers.get("Location")!, /auth=success$/);
    return { cookie: response.headers.get("Set-Cookie")!.split(";")[0] };
  }
  async function googleProof(
    cookie: string,
    action: "data" | "delete" | "link_google" | "link_github",
    subject = "google-stable",
  ) {
    const store = oidcStore(h.env, deps);
    const tx = {
      id: crypto.randomUUID(),
      stateHash: crypto.randomUUID(),
      browserHash: crypto.randomUUID(),
      claimNonce: crypto.randomUUID(),
    };
    await store.createTransaction({
      ...tx,
      provider: "google",
      purpose: "account_access",
      verificationAction: action,
      ipHash: "fixture",
      secretsCiphertext: "fixture",
      returnMode: "popup",
      previousSessionTokenHash: await sha(cookie.split("=")[1]),
    });
    assert.ok(await store.claimTransaction(tx));
    const token = Buffer.from(
      crypto.getRandomValues(new Uint8Array(32)),
    ).toString("hex");
    await store.completeGoogleLogin({
      transactionId: tx.id,
      claimNonce: tx.claimNonce,
      sessionTokenHash: await sha(token),
      identity: {
        issuer: "https://accounts.google.com",
        subject,
        email: null,
        emailVerified: false,
        authoritativeEmail: false,
        hostedDomain: null,
      },
    });
    return `__Host-accreatio_session=${token}`;
  }
  async function account(
    action: "session" | "data" | "delete" | "logout" | "authorize",
    cookie: string,
    body?: unknown,
  ) {
    if (action === "authorize" && body && typeof body === "object") {
      const { ownerKey, sessionKey } = await (
        await account("session", cookie)
      ).json();
      body = { ...body, ownerKey, sessionKey };
    }
    return handleAccount(
      {
        request: new Request(`${origin}/api/account/${action}`, {
          method: action === "session" || action === "data" ? "GET" : "POST",
          headers: {
            Origin: origin,
            Cookie: cookie,
            "Content-Type": "application/json",
          },
          ...(body ? { body: JSON.stringify(body) } : {}),
        }),
        env: h.env,
      },
      action,
      deps,
    );
  }
  return {
    ...h,
    call,
    start,
    callback,
    login,
    verify,
    googleProof,
    account,
    requests,
    store: oidcStore(h.env, deps),
    email: (value: string | null) => {
      email = value;
    },
    subject: (value: string) => {
      subject = value;
    },
    pages: (value: number) => {
      pages = value;
    },
    failure: (value: string) => {
      failure = value;
    },
    interrupt: (value: () => Promise<void>) => {
      interrupt = value;
    },
  };
}

test("GitHub numeric subject is lossless and excludes mutable, nested, duplicate or nonnumeric keys", () => {
  assert.equal(
    githubSubject(
      '{"id":9007199254740993,"login":"changed","nested":{"id":2}}',
    ),
    "9007199254740993",
  );
  assert.equal(githubSubject('{"\\u0069d":123}'), "123");
  for (const body of [
    '{"id":1,"id":2}',
    '{"id":"1"}',
    '{"nested":{"id":1}}',
    '{"id":1e3}',
    '{"id":0}',
    '{"id":-1}',
  ])
    assert.throws(() => githubSubject(body));
});

test("GitHub App capabilities fail closed and authorization uses S256 without OAuth scopes or installation", async () => {
  const h = await setup();
  assert.equal(
    (await (await h.call("methods")).json()).methods.github.available,
    true,
  );
  assert.equal(
    (
      await h.call("start", {
        body: {
          purpose: "account_access",
          returnRoute: "builder",
          mode: "popup",
        },
      })
    ).status,
    400,
  );
  for (const env of [
    { ...h.env, ACCOUNT_GITHUB_ENABLED: "false" },
    { ...h.env, GITHUB_CLIENT_SECRET: undefined },
    { ...h.env, GITHUB_REDIRECT_URI: `https://evil.invalid${callbackPath}` },
    { ...h.env, GITHUB_REDIRECT_URI: `${origin}${callbackPath}?returnTo=evil` },
  ])
    assert.equal(
      (await (await h.call("methods", { env })).json()).methods.github
        .available,
      false,
    );
  const tx = await h.start();
  const url = new URL(tx.authorizationUrl);
  assert.equal(
    url.origin + url.pathname,
    "https://github.com/login/oauth/authorize",
  );
  assert.equal(url.searchParams.get("code_challenge_method"), "S256");
  for (const key of [
    "scope",
    "code_verifier",
    "client_secret",
    "installation_id",
  ])
    assert.equal(url.searchParams.has(key), false);
  assert.match(
    tx.response.headers.get("Set-Cookie")!,
    /Secure; HttpOnly; SameSite=Lax/,
  );
  for (const body of [
    {
      purpose: "sign_in",
      mode: "popup",
      returnRoute: "https://evil.invalid",
      policyAuthorization: POLICY_AUTHORIZATION,
    },
    {
      purpose: "sign_in",
      mode: "popup",
      returnRoute: "builder",
      policyAuthorization: POLICY_AUTHORIZATION,
      verificationAction: "delete",
    },
  ])
    assert.equal((await h.call("start", { body })).status, 400);
  assert.equal(
    (await h.call("start", { origin: "https://evil.invalid", body: {} }))
      .status,
    403,
  );
});

test("private paginated primary verified email admits GitHub; session, export, quota and deletion use existing account controls", async () => {
  const h = await setup();
  h.pages(2);
  const first = await h.login();
  assert.match(
    first.response.headers.get("Set-Cookie")!,
    /Secure; HttpOnly; SameSite=Strict/,
  );
  assert.equal(first.response.headers.get("Cache-Control"), "no-store");
  assert.doesNotMatch(first.response.headers.get("Location")!, /state=|code=/);
  const session = await (await h.account("session", first.cookie)).json();
  assert.deepEqual(session.connectedProviders, ["github"]);
  assert.equal((await h.account("delete", first.cookie)).status, 401);
  assert.equal(
    (
      await h.call("start", {
        cookie: first.cookie,
        body: {
          purpose: "link_provider",
          returnRoute: "builder",
          mode: "popup",
        },
      })
    ).status,
    401,
  );
  assert.equal(session.email, "private@example.test");
  const op = crypto.randomUUID();
  const receipt = await (
    await h.account("authorize", first.cookie, { operationId: op })
  ).json();
  assert.equal(
    Date.parse(receipt.retryExpiresAt) - Date.parse(receipt.authorizedAt),
    172800000,
  );
  assert.equal((await h.account("data", first.cookie)).status, 401);
  const dataProof = await h.verify(first.cookie, "data");
  const data = await (await h.account("data", dataProof.cookie)).json();
  assert.equal(data.identities[0].subject, "9007199254740993");
  assert.equal(data.emailVerificationSource, "github");
  assert.equal(data.authorizations.length, 1);
  assert.doesNotMatch(
    JSON.stringify(data),
    /synthetic_transient_token|discard_me/,
  );
  const before = h.db.sqlite
    .prepare("SELECT id,email_ciphertext FROM accounts")
    .get()!;
  h.email(null);
  const again = await h.login(first.cookie);
  assert.deepEqual(
    h.db.sqlite.prepare("SELECT id,email_ciphertext FROM accounts").get(),
    before,
  );
  assert.equal(
    (await (await h.account("session", again.cookie)).json()).remaining,
    4,
  );
  const deleteProof = await h.verify(again.cookie, "delete");
  assert.equal((await h.account("delete", deleteProof.cookie)).status, 200);
  assert.equal((await h.account("session", again.cookie)).status, 401);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_external_identities")
      .get()!.n,
    0,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
      .get()!.n,
    0,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT expires_at FROM account_auth_tombstones LIMIT 1")
      .get()!.expires_at,
    h.db.now + 172800000,
  );
  h.email("private@example.test");
  const restored = await h.login();
  assert.equal(
    h.db.sqlite.prepare("SELECT id FROM accounts").get()!.id,
    before.id,
  );
  assert.equal(
    (await (await h.account("session", restored.cookie)).json()).remaining,
    4,
  );
});

test("callbacks bind browser and provider, expire, reject duplicates and atomically prevent concurrent replay", async () => {
  const h = await setup();
  const tx = await h.start();
  assert.match(
    (
      await h.callback("__Host-accreatio_auth_tx=" + "a".repeat(64))
    ).headers.get("Location")!,
    /auth=failure$/,
  );
  const wrong = await h.call("callback", {
    provider: "google",
    cookie: tx.cookie,
    path: `/api/auth/v1/oidc/google/callback?state=${new URL(tx.authorizationUrl).searchParams.get("state")}&code=fixture-code`,
  });
  assert.match(wrong.headers.get("Location")!, /auth=failure$/);
  const results = await Promise.all([
    h.callback(tx.cookie),
    h.callback(tx.cookie),
  ]);
  assert.equal(
    results.filter((result) => result.headers.get("Set-Cookie")).length,
    1,
  );
  assert.equal(
    h.requests.filter((url) => url.includes("access_token")).length,
    1,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    1,
  );
  assert.match(
    (await h.callback(tx.cookie)).headers.get("Location")!,
    /auth=failure$/,
  );
  const expired = await h.start();
  h.db.now += 600000;
  assert.match(
    (await h.callback(expired.cookie)).headers.get("Location")!,
    /auth=failure$/,
  );
});

test("GitHub failures are recoverable, redacted and leave no partial accounts or credentials", async () => {
  for (const mode of [
    "missing_email",
    "permission",
    "timeout",
    "invalid_code",
    "redirect",
    "cancelled",
  ]) {
    const h = await setup();
    if (mode === "missing_email") h.email(null);
    else h.failure(mode);
    const tx = await h.start();
    const result = await h.callback(
      tx.cookie,
      mode === "cancelled"
        ? `error=access_denied&state=${new URL(tx.authorizationUrl).searchParams.get("state")}`
        : undefined,
    );
    assert.match(result.headers.get("Location")!, /auth=failure$/);
    assert.equal(
      h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
      0,
    );
    const row = h.db.sqlite
      .prepare("SELECT * FROM account_auth_transactions")
      .get()!;
    assert.equal(row.secrets_ciphertext, null);
    assert.equal(row.status, "failed");
    assert.doesNotMatch(
      JSON.stringify(row),
      /synthetic_transient_token|discard_me|synthetic-only-secret/,
    );
    if (mode === "missing_email")
      assert.match(result.headers.get("Location")!, /verified_email_required/);
  }
});

test("explicit linking both directions preserves account, quota and policy; email equality never links", async () => {
  const h = await setup();
  const token = "d".repeat(64),
    hash = await sha(token);
  const seed = {
    id: crypto.randomUUID(),
    stateHash: crypto.randomUUID(),
    browserHash: crypto.randomUUID(),
    claimNonce: crypto.randomUUID(),
  };
  await h.store.createTransaction({
    ...seed,
    provider: "google",
    ipHash: "fixture",
    secretsCiphertext: "fixture",
    returnMode: "popup",
    previousSessionTokenHash: null,
    policyAuthorization: POLICY_AUTHORIZATION,
  });
  assert.ok(await h.store.claimTransaction(seed));
  await h.store.completeGoogleLogin({
    transactionId: seed.id,
    claimNonce: seed.claimNonce,
    sessionTokenHash: hash,
    identity: {
      issuer: "https://accounts.google.com",
      subject: "google-stable",
      email: "private@example.test",
      emailVerified: true,
      authoritativeEmail: true,
      hostedDomain: "example.test",
    },
  });
  const googleCookie = `__Host-accreatio_session=${token}`;
  const googleAccount = await (await h.account("session", googleCookie)).json();
  const before = h.db.sqlite.prepare("SELECT id FROM accounts").get()!;
  const policy = h.db.sqlite
    .prepare("SELECT * FROM account_policy_authorizations")
    .get();
  await h.account("authorize", googleCookie, {
    operationId: crypto.randomUUID(),
  });
  const collision = await h.start();
  const denied = await h.callback(collision.cookie);
  assert.match(denied.headers.get("Location")!, /identity_conflict/);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    1,
  );
  const currentProof = await h.googleProof(googleCookie, "link_github");
  const verifiedAccount = await (
    await h.account("session", currentProof)
  ).json();
  assert.equal(verifiedAccount.ownerKey, googleAccount.ownerKey);
  assert.notEqual(verifiedAccount.sessionKey, googleAccount.sessionKey);
  const link = await h.start(currentProof, "link_provider");
  const linked = await h.callback(link.cookie);
  assert.match(linked.headers.get("Location")!, /auth=success$/);
  const linkedCookie = linked.headers.get("Set-Cookie")!.split(";")[0];
  const linkedAccount = await (await h.account("session", linkedCookie)).json();
  assert.equal(linkedAccount.ownerKey, googleAccount.ownerKey);
  assert.notEqual(linkedAccount.sessionKey, verifiedAccount.sessionKey);
  assert.deepEqual(
    h.db.sqlite.prepare("SELECT * FROM account_policy_authorizations").get(),
    policy,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_external_identities")
      .get()!.n,
    2,
  );
  const githubLogin = await h.login();
  const githubAccount = await (
    await h.account("session", githubLogin.cookie)
  ).json();
  assert.equal(githubAccount.ownerKey, googleAccount.ownerKey);
  assert.notEqual(githubAccount.sessionKey, linkedAccount.sessionKey);
  assert.equal(
    h.db.sqlite.prepare("SELECT id FROM accounts").get()!.id,
    before.id,
  );
  assert.equal(
    (await (await h.account("session", githubLogin.cookie)).json()).remaining,
    4,
  );
  const ownProof = await h.verify(githubLogin.cookie, "data");
  const own = await (await h.account("data", ownProof.cookie)).json();
  assert.equal(own.identities.length, 2);
  const deletionProof = await h.verify(ownProof.cookie, "delete");
  assert.equal((await h.account("delete", deletionProof.cookie)).status, 200);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_external_identities")
      .get()!.n,
    0,
  );
  assert.equal(
    h.db.sqlite
      .prepare(
        "SELECT COUNT(*) AS n FROM account_auth_tombstones WHERE locator_kind='external'",
      )
      .get()!.n,
    2,
  );

  // Restoration retains allowance but does not silently restore the deleted
  // second identity. Explicit proof may reconnect its same-account tombstone.
  const restored = await h.login();
  assert.equal(
    h.db.sqlite.prepare("SELECT id FROM accounts").get()!.id,
    before.id,
  );
  const reconnectProof = await h.verify(restored.cookie, "link_google");
  const reconnect = {
    id: crypto.randomUUID(),
    stateHash: crypto.randomUUID(),
    browserHash: crypto.randomUUID(),
    claimNonce: crypto.randomUUID(),
  };
  await h.store.createTransaction({
    ...reconnect,
    provider: "google",
    purpose: "link_provider",
    ipHash: "fixture",
    secretsCiphertext: "fixture",
    returnMode: "popup",
    previousSessionTokenHash: await sha(reconnectProof.cookie.split("=")[1]),
  });
  assert.ok(
    await h.store.claimTransaction({ ...reconnect, provider: "google" }),
  );
  await h.store.completeGoogleLogin({
    transactionId: reconnect.id,
    claimNonce: reconnect.claimNonce,
    sessionTokenHash: "c".repeat(64),
    identity: {
      issuer: "https://accounts.google.com",
      subject: "google-stable",
      email: null,
      emailVerified: false,
      authoritativeEmail: false,
      hostedDomain: null,
    },
  });
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_external_identities")
      .get()!.n,
    2,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM export_authorizations")
      .get()!.n,
    1,
  );

  const reverse = await setup();
  const first = await reverse.login();
  const verified = await reverse.verify(first.cookie, "link_google");
  const previous = await sha(verified.cookie.split("=")[1]);
  const tx = {
    id: crypto.randomUUID(),
    stateHash: crypto.randomUUID(),
    browserHash: crypto.randomUUID(),
    claimNonce: crypto.randomUUID(),
  };
  await reverse.store.createTransaction({
    ...tx,
    provider: "google",
    purpose: "link_provider",
    ipHash: "fixture",
    secretsCiphertext: "fixture",
    returnMode: "popup",
    previousSessionTokenHash: previous,
  });
  assert.ok(
    await reverse.store.claimTransaction({ ...tx, provider: "google" }),
  );
  await reverse.store.completeGoogleLogin({
    transactionId: tx.id,
    claimNonce: tx.claimNonce,
    sessionTokenHash: "f".repeat(64),
    identity: {
      issuer: "https://accounts.google.com",
      subject: "google-other",
      email: "different@gmail.com",
      emailVerified: true,
      authoritativeEmail: true,
      hostedDomain: null,
    },
  });
  assert.equal(
    reverse.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    1,
  );
  assert.equal(
    reverse.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_external_identities")
      .get()!.n,
    2,
  );
});

test("additive GitHub migration preserves legacy identity, policies, sessions and receipts without acceptance backfill", () => {
  const db = new DatabaseSync(":memory:");
  db.exec("PRAGMA foreign_keys=ON");
  for (const file of [
    "0001_accounts.sql",
    "0002_own_email_otp.sql",
    "0003_google_oidc_privacy.sql",
    "0004_google_display_name.sql",
    "0005_account_policy_authorization.sql",
  ])
    db.exec(
      readFileSync(
        new URL(`../migrations-auth/${file}`, import.meta.url),
        "utf8",
      ),
    );
  db.exec(`INSERT INTO accounts(id,identity_key,email,created_at,last_seen_at) VALUES('existing','legacy','legacy@example.test',1,1);
    INSERT INTO account_sessions(token_hash,account_id,expires_at) VALUES('retained','existing',9999999999999);
    INSERT INTO account_session_metadata(token_hash,method,authenticated_at,security_version) VALUES('retained','oidc',1,0);
    INSERT INTO account_external_identities VALUES('google','existing','https://accounts.google.com','stable-google','locator',1,1);
    INSERT INTO export_authorizations(account_id,operation_id,issued_at) VALUES('existing','operation',1);
    INSERT INTO account_auth_transactions(id,state_hash,browser_hash,ip_hash,return_mode,status,created_at,expires_at,purpose) VALUES('old-tx','state','browser','ip','popup','created',1,9999999999999,'account_access');`);
  const tables = [
    "accounts",
    "account_external_identities",
    "export_authorizations",
    "account_policy_authorizations",
    "account_sessions",
  ];
  const before = tables.map((table) =>
    db.prepare(`SELECT * FROM ${table}`).all(),
  );
  db.exec(
    readFileSync(
      new URL(
        "../migrations-auth/0006_github_identity_linking.sql",
        import.meta.url,
      ),
      "utf8",
    ),
  );
  assert.deepEqual(
    tables.map((table) => db.prepare(`SELECT * FROM ${table}`).all()),
    before,
  );
  assert.deepEqual(
    {
      ...db
        .prepare("SELECT provider,intent FROM account_auth_transactions")
        .get(),
    },
    { provider: "google", intent: "account_access" },
  );
  assert.equal(
    db
      .prepare("SELECT verification_action FROM account_session_metadata")
      .get()!.verification_action,
    null,
  );
  assert.throws(
    () =>
      db
        .prepare(
          "INSERT INTO account_external_identities VALUES('duplicate','existing','https://accounts.google.com','stable-google','other-locator',1,1)",
        )
        .run(),
    /UNIQUE/,
  );
  db.close();
});

test("another account's identity cannot transfer, and logout during provider exchange prevents linkage", async () => {
  const h = await setup();
  const owner = await h.login();
  h.subject("123");
  h.email("other@example.test");
  const other = await h.login();
  const otherProof = await h.verify(other.cookie, "link_github");
  const attempt = await h.start(otherProof.cookie, "link_provider");
  h.subject("9007199254740993");
  assert.match(
    (await h.callback(attempt.cookie)).headers.get("Location")!,
    /identity_conflict/,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    2,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_external_identities")
      .get()!.n,
    2,
  );
  const ownerProof = await h.verify(owner.cookie, "link_github");
  const revoked = await h.start(ownerProof.cookie, "link_provider");
  h.interrupt(async () => {
    assert.equal((await h.account("logout", ownerProof.cookie)).status, 200);
  });
  const result = await h.callback(revoked.cookie);
  assert.match(result.headers.get("Location")!, /auth=failure$/);
  assert.equal(result.headers.has("Set-Cookie"), false);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_external_identities")
      .get()!.n,
    2,
  );
});

test("link completion crossing the five-minute proof deadline rolls back every identity/session write", async () => {
  const h = await setup();
  const first = await h.login();
  const proof = await h.verify(first.cookie, "link_google");
  const tx = {
    id: crypto.randomUUID(),
    stateHash: crypto.randomUUID(),
    browserHash: crypto.randomUUID(),
    claimNonce: crypto.randomUUID(),
  };
  await h.store.createTransaction({
    ...tx,
    provider: "google",
    purpose: "link_provider",
    ipHash: "fixture",
    secretsCiphertext: "fixture",
    returnMode: "popup",
    previousSessionTokenHash: await sha(proof.cookie.split("=")[1]),
  });
  assert.ok(await h.store.claimTransaction({ ...tx, provider: "google" }));
  h.db.now += 299999;
  const tables = [
    "accounts",
    "account_external_identities",
    "account_sessions",
    "account_session_metadata",
    "account_auth_transactions",
    "account_policy_authorizations",
  ];
  const snapshot = () =>
    tables.map((table) =>
      h.db.sqlite.prepare(`SELECT * FROM ${table} ORDER BY rowid`).all(),
    );
  const before = snapshot();
  const batch = h.db.batch.bind(h.db);
  h.db.batch = async (statements) => {
    const read = statements[6].read.bind(statements[6]);
    statements[6].read = () => {
      h.db.now++;
      return read();
    };
    return batch(statements);
  };
  await assert.rejects(
    h.store.completeGoogleLogin({
      transactionId: tx.id,
      claimNonce: tx.claimNonce,
      sessionTokenHash: "f".repeat(64),
      identity: {
        issuer: "https://accounts.google.com",
        subject: "linked-at-boundary",
        email: "linked@gmail.com",
        emailVerified: true,
        authoritativeEmail: true,
        hostedDomain: null,
      },
    }),
    /auth_link_incomplete/,
  );
  assert.deepEqual(snapshot(), before);
});

test("linking and action-scoped rights reject stale, revoked, changed or foreign identity context without Strict callback cookie", async () => {
  const h = await setup();
  const first = await h.login();
  const old = h.db.sqlite.prepare("SELECT * FROM accounts").get();
  h.db.now += 300001;
  const body = {
    purpose: "link_provider",
    mode: "popup",
    returnRoute: "builder",
  };
  assert.equal(
    (await h.call("start", { cookie: first.cookie, body })).status,
    401,
  );
  const proof = await h.start(first.cookie, "account_access", "data");
  h.email(null);
  const verified = await h.callback(proof.cookie); // Only Lax transaction cookie.
  assert.match(verified.headers.get("Location")!, /auth=success$/);
  const cookie = verified.headers.get("Set-Cookie")!.split(";")[0];
  assert.deepEqual(h.db.sqlite.prepare("SELECT * FROM accounts").get(), old);
  assert.equal((await h.account("data", cookie)).status, 200);
  assert.equal((await h.account("delete", cookie)).status, 401);
  const foreign = await h.start(cookie, "account_access", "delete");
  h.subject("123");
  assert.match(
    (await h.callback(foreign.cookie)).headers.get("Location")!,
    /auth=failure$/,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    1,
  );
  h.subject("9007199254740993");
  const revoked = await h.start(cookie, "account_access", "delete");
  await h.account("logout", cookie);
  assert.match(
    (await h.callback(revoked.cookie)).headers.get("Location")!,
    /auth=failure$/,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
    0,
  );
});

test("isolated SQLite backup and read-only restore preserve deletion, revocation, policy erasure and allowance continuity", async () => {
  const h = await setup();
  const first = await h.login();
  await h.account("authorize", first.cookie, {
    operationId: crypto.randomUUID(),
  });
  const proof = await h.verify(first.cookie, "delete");
  assert.equal((await h.account("delete", proof.cookie)).status, 200);
  const tables = [
    "accounts",
    "account_external_identities",
    "account_sessions",
    "account_session_metadata",
    "account_auth_transactions",
    "account_auth_tombstones",
    "account_policy_authorizations",
    "export_authorizations",
  ];
  const before = tables.map((table) =>
    h.db.sqlite.prepare(`SELECT * FROM ${table} ORDER BY rowid`).all(),
  );
  const cache = path.resolve(".local/cache");
  await mkdir(cache, { recursive: true });
  const folder = await mkdtemp(path.join(cache, "identity-backup-fixture-"));
  const file = path.join(folder, "deleted-account.sqlite");
  await backup(h.db.sqlite, file);
  const restored = new DatabaseSync(file, { readOnly: true });
  try {
    assert.deepEqual(
      tables.map((table) =>
        restored.prepare(`SELECT * FROM ${table} ORDER BY rowid`).all(),
      ),
      before,
    );
    assert.equal(
      restored.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
      0,
    );
    assert.equal(
      restored
        .prepare("SELECT COUNT(*) AS n FROM account_external_identities")
        .get()!.n,
      0,
    );
    assert.equal(
      restored
        .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
        .get()!.n,
      0,
    );
    assert.equal(
      restored.prepare("SELECT COUNT(*) AS n FROM export_authorizations").get()!
        .n,
      1,
    );
    assert.equal(
      restored
        .prepare("SELECT expires_at FROM account_auth_tombstones LIMIT 1")
        .get()!.expires_at,
      h.db.now + 172800000,
    );
  } finally {
    restored.close();
  }
});
