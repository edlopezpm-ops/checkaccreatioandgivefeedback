import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import React, { createElement, type ComponentProps } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { defaultOrchestration } from "../shared/domain";
import {
  FoundationStage,
  attachmentRejectionText,
} from "../src/components/creation/FoundationStage";
import { GuidedAttachments } from "../src/components/creation/GuidedAttachments";
Object.assign(globalThis, { React });

const app = fs.readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
const foundation = fs.readFileSync(
  new URL("../src/components/creation/FoundationStage.tsx", import.meta.url),
  "utf8",
);
const css = fs.readFileSync(
  new URL("../src/extras.css", import.meta.url),
  "utf8",
);

test("W1 attachment UI exposes local-only lifecycle, limits, statuses, and bilingual recovery", () => {
  const attachmentUi = `${app}\n${foundation}`;
  for (const phrase of [
    "Add local files",
    "Añadir archivos locales",
    "Only in this tab",
    "Solo en esta pestaña",
    "20-file limit reached",
    "Límite de 20 archivos alcanzado",
    "Your draft was restored",
    "Se restauró el borrador",
    "Ready",
    "Listo",
  ])
    assert.match(attachmentUi, new RegExp(phrase));
  assert.match(app, /\{ webAttachments \}/);
  assert.match(app, /resolveWebAttachments\(\s*webAttachments/);
});

test("attachment rows use semantic status tokens and 44px removal targets", () => {
  assert.match(css, /\.attachment-ready[\s\S]*var\(--success\)/);
  assert.match(css, /\.attachment-rejected[\s\S]*var\(--danger\)/);
  assert.match(css, /\.attachment-warning[\s\S]*var\(--warning\)/);
  assert.match(css, /min-width:\s*44px/);
  assert.match(css, /min-height:\s*44px/);
});

test("phase and New draft transitions disclose selected transient files", () => {
  assert.match(app, /Changing to Idea removes/);
  assert.match(app, /remove \$\{webAttachments\.length\} selected local file/);
  assert.match(app, /setWebAttachments\(\[\]\)/);
  assert.match(app, /setRejectedAttachments\(\[\]\)/);
});

test("Foundation explains browser draft metadata and non-persistent file bytes at point of use", () => {
  assert.match(foundation, /Only in this tab/);
  assert.match(foundation, /draft saves only the file count in this browser/);
  assert.match(foundation, /without their names or bytes/);
  assert.match(foundation, /select them again after a reload/i);
});

test("both attachment views disable mutations and announce local inspection", () => {
  const noop = () => {};
  const props: ComponentProps<typeof FoundationStage> = {
    errorText: () => undefined,
    errors: {},
    isWeb: true,
    inspectingAttachments: true,
    locale: "en",
    onAddAttachments: noop,
    onChange: noop,
    onDismissRestoredAttachments: noop,
    onPhaseChange: noop,
    onRemoveAttachment: noop,
    onRemoveRejectedAttachment: noop,
    project: {
      name: "",
      context: "",
      restrictions: "",
      phase: "discovery-active",
      route: "local",
      action: "repository",
      destination: "browser-download",
      participants: [{ id: "participant-01", role: "generalist", label: "" }],
      attachments: [{ name: "checked.pdf", extension: ".pdf", size: 123 }],
      initializeGit: false,
      createRemote: false,
      remotePrivate: true,
      openIde: false,
      dryRun: true,
      orchestration: defaultOrchestration(),
    },
    rejectedAttachments: [
      { id: "bad", name: "blocked.pdf", reason: "activeContent" },
    ],
    restoredAttachmentCount: 1,
    webAttachments: [],
  };
  for (const view of [FoundationStage, GuidedAttachments]) {
    const html = renderToStaticMarkup(createElement(view, props));
    assert.match(html, /aria-busy="true"/);
    assert.match(html, /role="status">Inspecting files locally/);
    const addButton = [
      ...html.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/g),
    ].find((match) => match[2].includes("Add local files"));
    assert.ok(addButton);
    assert.match(addButton[1], /disabled=""/);
    for (const label of ["Remove checked.pdf", "Remove blocked.pdf"])
      assert.match(
        html,
        new RegExp(`<button[^>]*disabled=""[^>]*aria-label="${label}"`),
      );
    assert.match(html, /DOCX, PDF, PNG, or JPEG/);
    assert.doesNotMatch(html, /MD, TXT|JSON, YAML/);
  }
});

test("attachment rejection messages are fixed and bilingual", () => {
  assert.equal(
    attachmentRejectionText("activeContent", "en"),
    "Active content is not allowed",
  );
  assert.equal(
    attachmentRejectionText("malformed", "es"),
    "Contenido o formato no válido",
  );
  assert.equal(
    attachmentRejectionText("secret parser payload", "en"),
    "File could not be admitted",
  );
});
