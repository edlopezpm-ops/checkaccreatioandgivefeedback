import assert from "node:assert/strict";
import test from "node:test";
import { buildSync } from "esbuild";
import { COLLECTION_VERSION } from "../shared/collection";

const preferenceKey = "accreatio:cookie-preferences";
const usage = {
  kind: "usage",
  feature: "creation",
  outcome: "opened",
  durationBand: "instant",
  locale: "en",
  device: "desktop",
} as const;
const compiled = buildSync({
  stdin: {
    contents:
      'export * from "./src/account/cookiePreferences"; export * from "./src/account/collection";',
    resolveDir: process.cwd(),
    loader: "ts",
  },
  bundle: true,
  write: false,
  format: "esm",
  platform: "browser",
}).outputFiles[0].text;
async function freshClient() {
  return import(
    `data:text/javascript;base64,${Buffer.from(`${compiled}\n// fresh client ${crypto.randomUUID()}`).toString("base64")}`
  ) as Promise<
    typeof import("../src/account/cookiePreferences") &
      typeof import("../src/account/collection")
  >;
}
async function setup(t: test.TestContext) {
  const values = new Map<string, string>();
  let mode = "normal";
  const storage = {
    get length() {
      if (mode === "blocked")
        throw new DOMException("blocked", "SecurityError");
      return values.size;
    },
    key: (i: number) => [...values.keys()][i] ?? null,
    getItem: (key: string) => {
      if (mode === "blocked")
        throw new DOMException("blocked", "SecurityError");
      return values.get(key) ?? null;
    },
    setItem: (key: string, value: string) => {
      if (mode === "blocked")
        throw new DOMException("blocked", "SecurityError");
      if (
        mode === "quota" ||
        (mode === "preference-quota" && key === preferenceKey)
      )
        throw new DOMException("full", "QuotaExceededError");
      if (mode === "preference-silent" && key === preferenceKey) return;
      values.set(key, value);
    },
    removeItem: (key: string) => {
      if (mode === "blocked")
        throw new DOMException("blocked", "SecurityError");
      values.delete(key);
    },
  };
  for (const [name, value] of [
    ["localStorage", storage],
    ["navigator", {}],
  ] as const) {
    const previous = Object.getOwnPropertyDescriptor(globalThis, name);
    Object.defineProperty(globalThis, name, { configurable: true, value });
    t.after(() => {
      if (previous) Object.defineProperty(globalThis, name, previous);
      else Reflect.deleteProperty(globalThis, name);
    });
  }
  const requests: { action: string; purpose: string; operation?: string }[] =
    [];
  t.mock.method(globalThis, "fetch", async (input, init) => {
    const body = JSON.parse(String(init?.body));
    const action = String(input).split("/").at(-1)!;
    requests.push({ action, purpose: body.purpose, operation: body.action });
    return Response.json(
      body.action === "grant"
        ? {
            token: new Headers(init?.headers).get("Authorization")?.slice(7),
            expiresAt: Date.now() + 86400000,
            version: COLLECTION_VERSION,
          }
        : { accepted: true, revoked: true },
    );
  });
  const client = await freshClient();
  t.after(() => client.stopPendingCollection());
  return {
    values,
    storage,
    requests,
    client,
    setMode: (value: string) => {
      mode = value;
    },
  };
}

for (const mode of ["preference-quota", "quota", "preference-silent"]) {
  test(`${mode}: failed rejection removes a prior positive choice before any current or fresh collector can send`, async (t) => {
    const h = await setup(t);
    const preserved = new Map([
      ["accreatio:theme", "dark"],
      ["accreatio:draft-journal", '{"synthetic":"draft"}'],
    ]);
    for (const [key, value] of preserved) h.storage.setItem(key, value);
    await h.client.submitResearch(
      { role: "developer", priority: "offline" },
      true,
    );
    const researchCapability = [...h.values].find(([key]) =>
      key.startsWith("accreatio:collect-capability:research:v2:"),
    )!;
    assert.equal(h.client.saveOptionalChoice(h.storage, true).persisted, true);
    await h.client.recordUsage(usage);
    assert.equal(
      h.requests.filter(
        (r) => r.action === "record" && r.purpose === "analytics",
      ).length,
      1,
      "the positive control must reach the actual collector",
    );
    const analyticsCapability = [...h.values].find(([key]) =>
      key.startsWith("accreatio:collect-capability:analytics:v2:"),
    )!;
    h.setMode(mode);
    const result = h.client.saveOptionalChoice(h.storage, false);
    assert.equal(result.persisted, false);
    assert.equal(result.preference.analytics, false);
    assert.equal(
      h.storage.getItem(preferenceKey),
      null,
      "removal is synchronous",
    );
    assert.equal(h.client.readCookiePreference(h.storage), null);
    const before = h.requests.length;
    await h.client.recordUsage(usage);
    assert.equal(h.requests.length, before);
    assert.equal(
      await h.client.withdrawCollection("analytics"),
      mode !== "quota",
    );
    if (mode === "quota")
      assert.equal(
        h.values.get(analyticsCapability[0]),
        analyticsCapability[1],
      );
    h.setMode("normal");
    const fresh = await freshClient();
    assert.notEqual(fresh.readCookiePreference, h.client.readCookiePreference);
    assert.equal(fresh.readCookiePreference(h.storage), null);
    const afterWithdrawal = h.requests.length;
    await fresh.recordUsage(usage);
    assert.equal(h.requests.length, afterWithdrawal, "reload sends zero POSTs");
    assert.equal(h.values.get(researchCapability[0]), researchCapability[1]);
    assert.equal(
      h.client.localCollection().filter((v) => v.purpose === "research").length,
      1,
    );
    for (const [key, value] of preserved)
      assert.equal(h.values.get(key), value);
    assert.equal(await fresh.withdrawCollection("analytics"), true);
    assert.equal(h.values.has(analyticsCapability[0]), false);
    assert.equal(fresh.saveOptionalChoice(h.storage, true).persisted, true);
    const resumed = h.requests.length;
    await fresh.recordUsage(usage);
    assert.ok(
      h.requests.length > resumed,
      "a new explicit choice can enable analytics",
    );
    assert.equal(await fresh.withdrawCollection("analytics"), true);
    assert.equal(await fresh.withdrawCollection("research"), true);
  });
}

test("a failed positive rewrite also cannot leave an earlier positive choice authoritative", async (t) => {
  const h = await setup(t);
  h.client.saveOptionalChoice(h.storage, true);
  h.setMode("preference-quota");
  assert.equal(
    h.client.saveOptionalChoice(h.storage, true).preference.analytics,
    false,
  );
  assert.equal(h.storage.getItem(preferenceKey), null);
  h.setMode("normal");
  await (await freshClient()).recordUsage(usage);
  assert.equal(h.requests.length, 0);
});

test("a stale failed restriction never deletes a later explicit choice from an independent client", async (t) => {
  const h = await setup(t);
  const now = Date.now();
  assert.equal(
    h.client.saveOptionalChoice(h.storage, true, now).persisted,
    true,
  );
  const originalChoice = h.storage.getItem(preferenceKey);
  h.setMode("blocked");
  assert.equal(h.client.saveOptionalChoice(h.storage, false).persisted, false);
  h.setMode("normal");
  const fresh = await freshClient();
  assert.equal(fresh.saveOptionalChoice(h.storage, true, now).persisted, true);
  const laterChoice = h.storage.getItem(preferenceKey);
  assert.ok(laterChoice);
  assert.equal(
    laterChoice,
    originalChoice,
    "same-millisecond grants need no new identifier",
  );
  assert.equal(h.client.readCookiePreference(h.storage), null);
  assert.equal(h.storage.getItem(preferenceKey), laterChoice);
  await h.client.recordUsage(usage);
  assert.equal(h.requests.length, 0, "the failed client remains off");
  await fresh.recordUsage(usage);
  assert.equal(
    h.requests.filter((r) => r.action === "record").length,
    1,
    "the later explicit choice remains effective in its client",
  );
  assert.equal(await fresh.withdrawCollection("analytics"), true);
});

test("blocked storage grants nothing and the failed client stays off until a new explicit choice after recovery", async (t) => {
  const h = await setup(t);
  h.client.saveOptionalChoice(h.storage, true);
  const originalChoice = h.storage.getItem(preferenceKey);
  h.setMode("blocked");
  assert.equal(h.client.saveOptionalChoice(h.storage, false).persisted, false);
  assert.equal(h.client.readCookiePreference(h.storage), null);
  await h.client.recordUsage(usage);
  await (await freshClient()).recordUsage(usage);
  assert.equal(h.requests.length, 0);
  h.setMode("normal");
  assert.equal(h.client.readCookiePreference(h.storage), null);
  assert.equal(h.storage.getItem(preferenceKey), originalChoice);
  const fresh = await freshClient();
  assert.equal(fresh.saveOptionalChoice(h.storage, false).persisted, true);
  await fresh.recordUsage(usage);
  assert.equal(h.requests.length, 0);
});
