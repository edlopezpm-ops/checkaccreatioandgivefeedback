import assert from "node:assert/strict";
import test from "node:test";
import {
  COOKIE_PREFERENCE_KEY,
  saveOptionalChoice,
  readCookiePreference,
} from "../src/account/cookiePreferences";
import { COLLECTION_VERSION } from "../shared/collection";
import {
  recordUsage,
  submitResearch,
  withdrawCollection,
  localCollection,
  downloadOptionalData,
  stopPendingCollection,
} from "../src/account/collection";
const usage = {
  kind: "usage",
  feature: "creation",
  outcome: "opened",
  durationBand: "instant",
  locale: "en",
  device: "desktop",
} as const;
test("client choice gates local and server collection, research is independent, withdrawal cancels pending work", async (t) => {
  const values = new Map<string, string>();
  const storage = {
    get length() {
      return values.size;
    },
    key: (index: number) => [...values.keys()][index] ?? null,
    getItem: (k: string) => values.get(k) ?? null,
    setItem: (k: string, v: string) => void values.set(k, v),
    removeItem: (k: string) => void values.delete(k),
  };
  const previous = Object.getOwnPropertyDescriptor(globalThis, "localStorage");
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: storage,
  });
  t.after(() => {
    if (previous) Object.defineProperty(globalThis, "localStorage", previous);
    else Reflect.deleteProperty(globalThis, "localStorage");
    stopPendingCollection();
  });
  const requests: {
    url: string;
    body: Record<string, unknown>;
    signal: AbortSignal | null | undefined;
  }[] = [];
  let held: () => void = () => {},
    hold = false;
  t.mock.method(globalThis, "fetch", async (input, init) => {
    const body = JSON.parse(String(init?.body));
    requests.push({ url: String(input), body, signal: init?.signal });
    if (String(input).endsWith("preference") && body.action === "grant")
      return Response.json({
        token: new Headers(init?.headers).get("Authorization")?.slice(7),
        version: COLLECTION_VERSION,
        expiresAt: Date.now() + 86400000,
      });
    if (hold && String(input).endsWith("record"))
      await new Promise<void>((resolve) => {
        held = resolve;
        init?.signal?.addEventListener("abort", resolve, { once: true });
      });
    return Response.json({ accepted: true, revoked: true, records: [] });
  });
  await recordUsage(usage);
  assert.equal(requests.length, 0);
  assert.equal(values.size, 0);
  saveOptionalChoice(storage, false);
  await recordUsage(usage);
  assert.equal(requests.length, 0);
  await submitResearch({ role: "developer", priority: "offline" }, true);
  assert.deepEqual(
    requests.map((v) => v.body.purpose),
    ["research", "research"],
  );
  assert.equal(readCookiePreference(storage)?.analytics, false);
  assert.equal(localCollection().length, 1);
  saveOptionalChoice(storage, true);
  await Promise.all([recordUsage(usage), recordUsage(usage)]);
  assert.equal(
    requests.filter(
      (v) => v.body.action === "grant" && v.body.purpose === "analytics",
    ).length,
    1,
    "concurrent events reuse one bounded purpose grant",
  );
  assert.equal(localCollection().length, 3);
  hold = true;
  const pending = recordUsage(usage);
  await new Promise((resolve) => setTimeout(resolve, 0));
  saveOptionalChoice(storage, false);
  assert.equal(await withdrawCollection("analytics"), true);
  held();
  await pending;
  assert.equal(
    requests
      .filter((v) => v.url.endsWith("record") && v.body.purpose === "analytics")
      .at(-1)?.signal?.aborted,
    true,
  );
  const before = requests.length;
  await recordUsage(usage);
  assert.equal(requests.length, before);
  assert.equal(
    localCollection().filter((v) => v.purpose === "analytics").length,
    0,
  );
  const exported = await downloadOptionalData();
  assert.equal(exported.server.length, 1);
  assert.equal(exported.limitations.length, 0);
  values.set(
    COOKIE_PREFERENCE_KEY,
    JSON.stringify({
      schemaVersion: 2,
      necessary: true,
      analytics: true,
      advertising: false,
      noticeVersion: "old",
      recordedAt: Date.now(),
    }),
  );
  await recordUsage(usage);
  assert.equal(
    requests.filter(
      (v) => v.body.action === "grant" && v.body.purpose === "analytics",
    ).length,
    1,
  );
});
test("storage failure never creates an opt-in", () => {
  const s = {
    getItem: () => null,
    setItem: () => {
      throw Error("blocked");
    },
    removeItem: () => {},
  };
  assert.equal(saveOptionalChoice(s, true).preference.analytics, false);
  assert.equal(saveOptionalChoice(null, true).persisted, false);
});
