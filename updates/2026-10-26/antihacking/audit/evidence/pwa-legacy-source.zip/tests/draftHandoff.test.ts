import test from "node:test";
import assert from "node:assert/strict";
import {
  DRAFT_HANDOFF_KEY,
  clearDraftHandoff,
  saveDraftHandoff,
  takeDraftHandoff,
} from "../src/account/draftHandoff";
const a = {
  ownerKey: `v1:${"a".repeat(64)}`,
  sessionKey: `v1:${"1".repeat(64)}`,
};
const b = `v1:${"b".repeat(64)}`;
const storage = () => {
  const values = new Map<string, string>();
  return {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => {
      values.set(key, value);
    },
    removeItem: (key: string) => {
      values.delete(key);
    },
  };
};
test("OAuth draft handoff is one-use, owner-bound and contains no project data", () => {
  const s = storage();
  saveDraftHandoff(a, s, 1000);
  assert.deepEqual(
    Object.keys(JSON.parse(s.getItem(DRAFT_HANDOFF_KEY)!)).sort(),
    ["expiresAt", "ownerKey", "sessionKey"],
  );
  assert.deepEqual(takeDraftHandoff(a.ownerKey, s, 1001), a);
  assert.equal(takeDraftHandoff(a.ownerKey, s, 1002), null);
  saveDraftHandoff(a, s, 1000);
  assert.equal(takeDraftHandoff(b, s, 1001), null);
  assert.equal(takeDraftHandoff(a.ownerKey, s, 1002), null);
});
test("logout, expiry, malformed metadata and failed consumption never transfer a draft", () => {
  const s = storage();
  saveDraftHandoff(a, s, 1000);
  clearDraftHandoff(s);
  assert.equal(takeDraftHandoff(a.ownerKey, s, 1001), null);
  saveDraftHandoff(a, s, 1000);
  assert.equal(takeDraftHandoff(a.ownerKey, s, 601000), null);
  saveDraftHandoff(a, s, 1000);
  assert.equal(
    takeDraftHandoff(
      a.ownerKey,
      {
        ...s,
        removeItem: () => {
          throw new Error("blocked");
        },
      },
      1001,
    ),
    null,
  );
  s.setItem(
    DRAFT_HANDOFF_KEY,
    JSON.stringify({ ...a, expiresAt: 2000, project: "untrusted" }),
  );
  assert.equal(takeDraftHandoff(a.ownerKey, s, 1001), null);
  s.setItem(DRAFT_HANDOFF_KEY, "{malformed");
  assert.equal(takeDraftHandoff(a.ownerKey, s, 1001), null);
});

test("every new login must confirm removal of a stale handoff before creating another", () => {
  const s = storage();
  saveDraftHandoff(a, s, 1000);
  assert.throws(
    () => clearDraftHandoff({ ...s, removeItem: () => {} }, true),
    /draft_handoff_not_cleared/,
  );
  assert.throws(
    () =>
      clearDraftHandoff(
        {
          ...s,
          removeItem: () => {
            throw new Error("blocked");
          },
        },
        true,
      ),
    /draft_handoff_not_cleared/,
  );
  clearDraftHandoff(s, true);
  assert.equal(takeDraftHandoff(a.ownerKey, s, 1001), null);
});

test("silent removal failures and a blocked sessionStorage getter fail closed without breaking logout cleanup", () => {
  const s = storage();
  saveDraftHandoff(a, s, 1000);
  assert.equal(
    takeDraftHandoff(a.ownerKey, { ...s, removeItem: () => {} }, 1001),
    null,
  );
  const original = Object.getOwnPropertyDescriptor(
    globalThis,
    "sessionStorage",
  );
  Object.defineProperty(globalThis, "sessionStorage", {
    configurable: true,
    get: () => {
      throw new Error("blocked storage getter");
    },
  });
  try {
    assert.doesNotThrow(() => clearDraftHandoff());
    assert.throws(
      () => clearDraftHandoff(undefined, true),
      /draft_handoff_not_cleared/,
    );
    assert.equal(takeDraftHandoff(a.ownerKey, undefined, 1001), null);
  } finally {
    if (original) Object.defineProperty(globalThis, "sessionStorage", original);
    else Reflect.deleteProperty(globalThis, "sessionStorage");
  }
});
