import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import {
  defaultOrchestration,
  generatePrompt,
  renderOrchestrationConfig,
  slugify,
  validateAttachmentSet,
  validationErrors,
} from "../shared/domain";
import {
  assertArchivePaths,
  PROJECT_TEXT_LIMITS,
} from "../shared/inputValidation";
import { validateExecutionRequest } from "../src/operationGuard";
import { buildWebExport } from "../src/webExport";
import { createWebExecutionBridge } from "../src/bridge/web";
import {
  containedFilePath,
  copyVersioned,
  ensureSafeDirectory,
  writeVersioned,
} from "../electron/files";
import type { ProjectDefinition, Settings } from "../shared/domain";

const settings: Settings = {
  baseFolder: "",
  toolkitPath: "",
  futureProjectsPath: "",
  defaultBranch: "main",
  preferredIde: "VS Code",
  theme: "dark",
  locale: "en",
  confirmBeforeRun: true,
};
const project = (): ProjectDefinition => ({
  name: "Security fixture",
  phase: "idea",
  context: "Legitimate project",
  restrictions: "",
  route: "local",
  action: "repository",
  destination: "browser-download",
  participants: [{ id: "participant-01", role: "generalist", label: "" }],
  attachments: [],
  initializeGit: false,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: false,
  orchestration: defaultOrchestration(),
});
const request = (definition: unknown) => ({
  operationId: "11111111-1111-4111-8111-111111111111",
  definition,
  settings,
});

test("strict snapshots reject wrong types, enums, unknown fields, controls and numeric YAML injection", () => {
  const p = project();
  const cases = [
    {},
    { ...p, phase: "invented" },
    { ...p, dryRun: "false" },
    { ...p, route: "aekr" },
    { ...p, hidden: "payload" },
    { ...p, name: "Name\n# heading" },
    { ...p, context: "text\u0000text" },
    { ...p, participants: [null] },
    ...["currency", "hardStop"].map((key) => ({
      ...p,
      orchestration: {
        ...p.orchestration,
        funding: { ...p.orchestration.funding, [key]: { nested: "payload" } },
      },
    })),
    ...[NaN, Infinity, 60.5, "60\nsynthetic_key: true"].map((value) => ({
      ...p,
      orchestration: { ...p.orchestration, sessionMaxDurationSeconds: value },
    })),
  ];
  for (const invalid of cases) {
    assert.throws(() => validateExecutionRequest(request(invalid)));
    assert.throws(() =>
      buildWebExport(invalid as ProjectDefinition, settings, [], {
        appVersion: "test",
      }),
    );
  }
  const injected = {
    ...p,
    orchestration: {
      ...p.orchestration,
      sessionMaxDurationSeconds: "60\nsynthetic_key: true",
    },
  };
  assert.throws(() =>
    renderOrchestrationConfig(
      injected as unknown as ProjectDefinition,
      settings,
    ),
  );
  let accessorCalled = false;
  assert.throws(() =>
    validateExecutionRequest({
      ...request(p),
      get operationId() {
        accessorCalled = true;
        return "11111111-1111-4111-8111-111111111111";
      },
    }),
  );
  assert.equal(accessorCalled, false);
});

test("invalid execution never fingerprints, builds, authorizes or downloads", () => {
  const calls: string[] = [];
  const execute = createWebExecutionBridge({
    fingerprint: async () => {
      calls.push("fingerprint");
      return "hash";
    },
    createArchive: async () => {
      calls.push("archive");
      return new Blob();
    },
    authorize: async () => {
      calls.push("authorize");
    },
    download: () => {
      calls.push("download");
    },
  });
  assert.throws(() =>
    execute(request({ ...project(), phase: "invented" }) as never),
  );
  assert.deepEqual(calls, []);
});

test("text boundaries preserve original values and reject oversize snapshots", () => {
  for (const key of ["context", "restrictions"] as const) {
    const p = { ...project(), [key]: "é".repeat(PROJECT_TEXT_LIMITS[key]) };
    assert.deepEqual(validationErrors(p, settings), {});
    const tooLong = { ...p, [key]: p[key] + "x" };
    assert.equal(validationErrors(tooLong, settings)[key], `${key}TooLong`);
    assert.throws(() => validateExecutionRequest(request(tooLong)));
    assert.equal(tooLong[key].length, PROJECT_TEXT_LIMITS[key] + 1);
  }
  const p = project();
  p.orchestration.participants = [
    {
      participantId: "participant-01",
      provider: "codex",
      task: "x".repeat(PROJECT_TEXT_LIMITS.task + 1),
    },
  ];
  assert.throws(() => validateExecutionRequest(request(p)));
});

test("SQL, script examples and Unicode stay literal without content censorship", () => {
  const text =
    "O'Connor — café 中文 🚀\nSELECT * FROM example;\n<script>window.example = true</script>\n```\n# quoted example";
  const p = {
    ...project(),
    context: text,
    restrictions: "Explain SQL injection safely",
  };
  assert.deepEqual(validationErrors(p, settings), {});
  const prompt = generatePrompt(p, "en");
  assert.ok(prompt.includes(text));
  assert.ok(prompt.includes("````text\n"));
  const html = renderToStaticMarkup(React.createElement("pre", null, prompt));
  assert.ok(!html.includes("<script>"));
  assert.ok(html.includes("&lt;script&gt;"));
  const files = buildWebExport(p, settings, [], { appVersion: "test" });
  assert.ok(
    files
      .find((file) => file.path.endsWith("PROJECT_PROMPT.md"))
      ?.content?.includes(text),
  );
});

test("archive paths reject traversal, absolute paths, controls, reserved names and collisions", () => {
  for (const bad of [
    "../outside.txt",
    "safe/../outside.txt",
    "safe/C:\\outside.txt",
    "safe/a\u0000.txt",
    "safe/CON.txt",
    "safe/a\\b.txt",
    "safe/a.",
  ])
    assert.throws(() => assertArchivePaths([bad], "safe"));
  assert.throws(() => assertArchivePaths(["safe/A.txt", "safe/a.txt"], "safe"));
  assert.equal(slugify("CON"), "project-con");
  assert.ok(
    validateAttachmentSet([{ name: "a\u0000.txt", extension: ".txt", size: 1 }])
      .length,
  );
});

test("file writes reject hostile destination names before creating a directory", async (t) => {
  const root = await fs.mkdtemp(
    path.join(os.tmpdir(), "accreatio-input-security-"),
  );
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const destination = path.join(root, "not-created");
  for (const bad of [
    "../outside.txt",
    "..\\outside.txt",
    "C:\\outside.txt",
    "NUL.txt",
    "a\u0000.txt",
    "a:b.txt",
  ]) {
    assert.throws(() => containedFilePath(destination, bad));
    await assert.rejects(writeVersioned(destination, bad, "fixture"));
  }
  assert.deepEqual(await fs.readdir(root), []);
});

test("file copies reject stale selections and enforce source size without a destination write", async (t) => {
  const root = await fs.mkdtemp(
    path.join(os.tmpdir(), "accreatio-file-security-"),
  );
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const source = path.join(root, "source.txt");
  const destination = path.join(root, "not-created");
  await fs.writeFile(source, "first");
  const selected = await fs.stat(source);
  await fs.writeFile(source, "changed-length");
  await assert.rejects(
    copyVersioned(source, destination, "source.txt", selected),
    /changed/,
  );
  assert.deepEqual(await fs.readdir(root), ["source.txt"]);
  await assert.rejects(
    copyVersioned(root, destination, "directory.txt"),
    /changed/,
  );
});

test("pre-existing junction destinations cannot redirect project writes", async (t) => {
  const root = await fs.mkdtemp(
    path.join(os.tmpdir(), "accreatio-link-security-"),
  );
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const outside = path.join(root, "outside");
  const redirect = path.join(root, "redirect");
  await fs.mkdir(outside);
  await fs.symlink(
    outside,
    redirect,
    process.platform === "win32" ? "junction" : "dir",
  );
  await assert.rejects(
    ensureSafeDirectory(path.join(redirect, "new")),
    /Unsafe/,
  );
  await assert.rejects(
    writeVersioned(redirect, "unexpected.txt", "fixture"),
    /Unsafe/,
  );
  assert.deepEqual(await fs.readdir(outside), []);
});
