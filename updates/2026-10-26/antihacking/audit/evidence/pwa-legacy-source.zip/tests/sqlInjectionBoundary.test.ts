import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import test from "node:test";
import {
  listPublishedPosts,
  publishPost,
  validateNewBlogPost,
} from "../functions/_lib/blog";
import type {
  BlogDatabase,
  BlogPreparedStatement,
  DatabaseValue,
  RuntimeDependencies,
} from "../functions/_lib/platform";
import { harness } from "./helpers/accountHarness";

function realBlogStore(sqlite: DatabaseSync): BlogDatabase {
  return {
    prepare(query) {
      let values: DatabaseValue[] = [];
      const statement: BlogPreparedStatement = {
        bind(...bound) {
          values = bound;
          return statement;
        },
        async first<T>() {
          return (
            (sqlite.prepare(query).get(...values) as T | undefined) ?? null
          );
        },
        async all<T>() {
          return {
            success: true,
            results: sqlite.prepare(query).all(...values) as T[],
          };
        },
        async run() {
          const result = sqlite.prepare(query).run(...values);
          return { success: true, meta: { changes: Number(result.changes) } };
        },
      };
      return statement;
    },
  };
}

test("real SQLite keeps Blog SQL-looking content literal through publish, list and idempotent retry", async (t) => {
  const sqlite = new DatabaseSync(":memory:");
  t.after(() => sqlite.close());
  sqlite.exec(
    readFileSync(
      new URL("../migrations/0001_blog.sql", import.meta.url),
      "utf8",
    ),
  );
  const store = realBlogStore(sqlite);
  const before = (await listPublishedPosts(store)).length;
  const input = validateNewBlogPost({
    title: "O'Reilly'); DROP TABLE blog_posts;--",
    summary: "Unicode Ω · ' OR 1=1 -- stays ordinary editorial text.",
    paragraphs: [
      "SELECT * FROM accounts; /* not a command */",
      "'); UPDATE blog_posts SET title='changed'; --",
    ],
    language: "en",
    author: "O'Reilly",
    authorRole: "SQL examples: ' UNION SELECT 1 --",
    signature: "Quoted text ' ; --",
  });
  const dependencies: RuntimeDependencies = {
    fetch,
    now: () => Date.parse("2026-10-22T12:00:00Z"),
    randomUUID: () => crypto.randomUUID(),
    subtle: crypto.subtle,
  };
  const key = crypto.randomUUID();
  const actor = { kind: "human", label: "sql-boundary" } as const;
  const published = await publishPost(store, actor, input, key, dependencies);
  assert.equal(published.replayed, false);
  for (const field of [
    "title",
    "summary",
    "author",
    "authorRole",
    "signature",
  ] as const)
    assert.equal(published.post[field], input[field]);
  assert.deepEqual(published.post.paragraphs, input.paragraphs);
  const retried = await publishPost(
    store,
    actor,
    { ...input, title: "Changed retry payload" },
    key,
    dependencies,
  );
  assert.equal(retried.replayed, true);
  assert.equal(retried.post.id, published.post.id);
  assert.equal(retried.post.title, input.title);
  const listed = await listPublishedPosts(store);
  assert.equal(listed.length, before + 1);
  assert.deepEqual(
    listed.find((post) => post.id === published.post.id),
    published.post,
  );
  assert.equal(
    sqlite.prepare("PRAGMA integrity_check").get()!.integrity_check,
    "ok",
  );
});

test("real account handlers preserve apostrophe emails and reject SQL-shaped identifiers without changing another account", async () => {
  const h = await harness();
  const quotedCookie = await h.login({ email: "reader'--@example.test" });
  const otherCookie = await h.login({ email: "other@example.test" });
  assert.equal(
    (
      await (
        await h.call("identity", { method: "GET", cookie: quotedCookie })
      ).json()
    ).email,
    "reader'--@example.test",
  );
  const operationId = crypto.randomUUID();
  assert.equal(
    (await h.call("authorize", { cookie: quotedCookie, body: { operationId } }))
      .status,
    200,
  );
  for (const injected of [
    "' OR 1=1 --",
    "x'); DROP TABLE accounts;--",
    "00000000-0000-4000-8000-000000000000' UNION SELECT 1",
  ]) {
    const response = await h.call("authorize", {
      cookie: otherCookie,
      body: { operationId: injected },
    });
    assert.equal(response.status, 400);
  }
  const other = await (
    await h.call("session", { method: "GET", cookie: otherCookie })
  ).json();
  assert.equal(other.remaining, 5);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    2,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM export_authorizations")
      .get()!.n,
    1,
  );
  assert.equal(
    h.db.sqlite.prepare("PRAGMA integrity_check").get()!.integrity_check,
    "ok",
  );
});
