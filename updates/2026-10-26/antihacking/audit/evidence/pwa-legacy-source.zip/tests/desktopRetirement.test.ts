import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import {
  mkdirSync,
  mkdtempSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

const root = fileURLToPath(new URL("../", import.meta.url));
const packageJson = JSON.parse(
  readFileSync(new URL("../package.json", import.meta.url), "utf8"),
) as { scripts: Record<string, string> };

test("default delivery commands target the web without a desktop release gate", () => {
  assert.equal(packageJson.scripts.dev, "npm run dev:web");
  assert.equal(packageJson.scripts.start, "npm run dev:web");
  assert.equal(packageJson.scripts.build, "npm run build:web");
  assert.doesNotMatch(packageJson.scripts.typecheck, /electron/);
  assert.doesNotMatch(
    packageJson.scripts.verify,
    /test:electron|build:desktop|package:win/,
  );
  assert.equal(
    packageJson.scripts["test:surface"],
    "node scripts/surface-boundary-smoke.mjs --web-only",
  );
});

test("documented desktop entry points fail closed with the retirement reason", () => {
  for (const command of [
    "dev:desktop",
    "build:desktop",
    "test:electron",
    "package:win",
  ]) {
    assert.equal(
      packageJson.scripts[command],
      "node scripts/retire-desktop.mjs",
      command,
    );
  }
  const result = spawnSync(
    process.execPath,
    [fileURLToPath(new URL("../scripts/retire-desktop.mjs", import.meta.url))],
    { cwd: root, shell: false, windowsHide: true, encoding: "utf8" },
  );
  assert.equal(result.error, undefined);
  assert.equal(result.status, 1);
  assert.match(result.stderr, /desktop is retired/);
  assert.match(
    result.stderr,
    /unreleased prototype and will never be released/,
  );
  assert.match(result.stderr, /accreatio is web-only/);
});

test("web surface verification succeeds without any desktop artifact", () => {
  const cache = path.join(root, ".local", "cache");
  mkdirSync(cache, { recursive: true });
  const fixture = mkdtempSync(path.join(cache, "retirement-smoke-"));
  try {
    mkdirSync(path.join(fixture, "scripts"));
    mkdirSync(path.join(fixture, "dist"));
    const scanner = path.join(fixture, "scripts", "surface-boundary-smoke.mjs");
    writeFileSync(
      scanner,
      readFileSync(
        new URL("../scripts/surface-boundary-smoke.mjs", import.meta.url),
      ),
    );
    writeFileSync(
      path.join(fixture, "dist", "app.js"),
      '"Blog /api/blog/posts /api/admin/blog/session /api/admin/blog/posts canPublish";',
    );
    for (const filename of ["manifest.webmanifest", "sw.js", "workbox-test.js"])
      writeFileSync(path.join(fixture, "dist", filename), "{}");
    const scan = () =>
      spawnSync(process.execPath, [scanner, "--web-only"], {
        cwd: fixture,
        shell: false,
        windowsHide: true,
        encoding: "utf8",
      });
    const result = scan();
    assert.equal(result.status, 0, result.stderr);
    assert.deepEqual(JSON.parse(result.stdout), {
      desktopFiles: 0,
      mode: "web-only",
      ok: true,
    });
    writeFileSync(path.join(fixture, "dist", "app.js"), "{}");
    const missingMarkers = scan();
    assert.equal(missingMarkers.status, 1);
    assert.match(missingMarkers.stderr, /Web surface markers missing/);
  } finally {
    assert.ok(
      path.resolve(fixture).startsWith(`${path.resolve(cache)}${path.sep}`),
    );
    rmSync(fixture, { recursive: true, force: true });
  }
});
