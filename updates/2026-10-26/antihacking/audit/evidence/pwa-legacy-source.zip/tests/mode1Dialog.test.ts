import assert from "node:assert/strict";
import { test } from "node:test";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { Mode1ConfigurationDialog } from "../src/components/mode1/Mode1ConfigurationDialog";
import { defaultOrchestration } from "../shared/domain";
import type { ParticipantInstance } from "../src/types";

// Structural verification only: renderToStaticMarkup does not run effects
// (showModal/focus/resize listeners never fire here), so this proves DOM
// shape, group order, and ARIA wiring without needing a browser/jsdom
// dependency. Interactive focus-trap/keyboard/responsive behavior is
// independently verified by the Test Engineer in a real host, per the
// approved design's own verification plan.

const baseProps = {
  locale: "en" as const,
  projectName: "Demo",
  providers: null,
  checkingProviders: false,
  hostKind: "electron" as const,
  onCheckProviders: () => {},
  providerReasonText: () => "Available",
  responsibilityLabel: (role: string) => role,
  onSave: () => {},
  onClose: () => {},
};

const participant = (
  id: string,
  role: ParticipantInstance["role"] = "generalist",
): ParticipantInstance => ({ id, role, label: "" });

test("Mode1ConfigurationDialog renders native dialog semantics and all four groups in order", () => {
  const html = renderToStaticMarkup(
    createElement(Mode1ConfigurationDialog, {
      ...baseProps,
      participants: [participant("participant-01")],
      orchestration: defaultOrchestration(),
    }),
  );
  assert.match(html, /<dialog/);
  assert.match(html, /aria-labelledby/);
  assert.match(html, /aria-describedby/);
  assert.match(html, /Configure Mode 1/);

  const participantsIndex = html.indexOf("Participants");
  const providersIndex = html.indexOf("Providers");
  const limitsIndex = html.indexOf("Execution limits");
  const fundingIndex = html.indexOf("Funding");
  assert.ok(participantsIndex >= 0 && providersIndex > participantsIndex);
  assert.ok(limitsIndex > providersIndex);
  assert.ok(fundingIndex > limitsIndex);

  assert.match(html, /Save configuration/);
  assert.match(html, /Cancel/);
});

test("Mode1ConfigurationDialog renders one row per participant and localizes to Spanish", () => {
  const html = renderToStaticMarkup(
    createElement(Mode1ConfigurationDialog, {
      ...baseProps,
      locale: "es",
      participants: [
        participant("participant-01"),
        participant("participant-02", "architect"),
      ],
      orchestration: defaultOrchestration(),
    }),
  );
  assert.match(html, /Configurar Mode 1/);
  assert.match(html, /participant-01/);
  assert.match(html, /participant-02/);
  assert.match(html, /Guardar configuraci/);
});

test("Mode1ConfigurationDialog shows the AEKR compatibility warning for an unsupported topology", () => {
  const html = renderToStaticMarkup(
    createElement(Mode1ConfigurationDialog, {
      ...baseProps,
      participants: [
        participant("participant-01"),
        participant("participant-02"),
      ],
      orchestration: defaultOrchestration(),
    }),
  );
  assert.match(html, /current AEKR Mode 1 format cannot bind providers/);
});

test("Mode1ConfigurationDialog shows the browser limitation note instead of a check button on the web host", () => {
  const html = renderToStaticMarkup(
    createElement(Mode1ConfigurationDialog, {
      ...baseProps,
      hostKind: "web",
      participants: [participant("participant-01")],
      orchestration: defaultOrchestration(),
    }),
  );
  assert.match(html, /This browser cannot check local CLI installation/);
  assert.doesNotMatch(html, /Check provider availability/);
});

test("Mode1ConfigurationDialog exposes the subscription funding option as selected and API as disabled", () => {
  const html = renderToStaticMarkup(
    createElement(Mode1ConfigurationDialog, {
      ...baseProps,
      participants: [participant("participant-01")],
      orchestration: defaultOrchestration(),
    }),
  );
  assert.match(html, /value="subscription_cli"/);
  assert.match(html, /value="api"/);
  assert.match(html, /Unavailable: no supported provider\/profile/);
});

test("Mode1ConfigurationDialog shows a blocking funding warning for an unresolved carried-over policy (CODEX_REVIEW H1)", () => {
  const html = renderToStaticMarkup(
    createElement(Mode1ConfigurationDialog, {
      ...baseProps,
      participants: [participant("participant-01")],
      orchestration: {
        ...defaultOrchestration(),
        funding: {
          mode: "api",
          providerId: "claude_code",
          modelProfileId: "does-not-exist",
          currency: "USD",
          maxCost: "5",
          hardStopAcknowledged: true,
        },
      },
    }),
  );
  assert.match(html, /cannot repair it/);
});
