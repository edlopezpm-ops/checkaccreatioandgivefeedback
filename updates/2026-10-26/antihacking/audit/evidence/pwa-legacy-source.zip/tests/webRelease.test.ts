import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

const read = (path: string) =>
  fs.readFileSync(new URL(path, import.meta.url), "utf8");

const headers = read("../public/_headers");
const robots = read("../public/robots.txt");
const index = read("../index.html");
const decisions = read("../DECISIONS.md");
const readiness = read("../docs/W1_RELEASE_READINESS.md");
const license = read("../LICENSE");

test("restricted beta keeps indexing and unauthenticated access fail-closed", () => {
  assert.match(headers, /X-Robots-Tag:\s*noindex, nofollow, noarchive/);
  assert.match(robots, /User-agent:\s*\*\s*\nDisallow:\s*\//);
  assert.doesNotMatch(robots, /Allow:\s*\//);
  assert.match(index, /name="robots" content="noindex,nofollow,noarchive"/);
  assert.match(decisions, /Access boundary: mandatory/);
  assert.match(decisions, /Unauthenticated access must fail closed/);
  assert.match(
    readiness,
    /Confirm anonymous requests to the stable and preview origins still fail closed/,
  );
  assert.match(
    readiness,
    /Exact `accreatio\.pages\.dev` plus wildcard `\*\.accreatio\.pages\.dev`/,
  );
  assert.match(
    readiness,
    /If an owner-authenticated or service-token check cannot run,[\s\S]*?acceptance must remain pending/,
  );
});

test("Lighthouse exempts only the intentional private-beta crawlability audit", () => {
  const lighthouse = read("../scripts/lighthouse-check.mjs");

  assert.match(
    lighthouse,
    /INTENTIONAL_SEO_EXEMPTIONS = new Set\(\["is-crawlable"\]\)/,
  );
  assert.match(lighthouse, /weightedFailures\.length > 0/);
  assert.match(
    lighthouse,
    /weightedFailures\.every\(\(auditRef\) =>\s+INTENTIONAL_SEO_EXEMPTIONS\.has\(auditRef\.id\)/,
  );
});

test("host CSP permits bounded canvas styles without permitting inline script", () => {
  const policy = headers.match(/Content-Security-Policy:\s*([^\n]+)/)?.[1];
  assert.ok(policy);
  assert.match(policy, /script-src 'self';/);
  assert.doesNotMatch(policy, /script-src[^;]*'unsafe-inline'/);
  assert.match(policy, /style-src 'self' 'unsafe-inline';/);
  assert.match(policy, /connect-src 'self';/);
  assert.match(policy, /frame-ancestors 'none'/);
});

test("current release copy distinguishes restricted beta from public launch", () => {
  const currentSurfaces = [
    read("../README.md"),
    read("../src/App.tsx"),
    read("../docs/WEB_STRATEGY.md"),
    read("../docs/SOP_WEB.md"),
    read("../docs/PRIVACY_POLICY.md"),
    read("../docs/TERMS_OF_SERVICE.md"),
    read("../public/legal/faq.html"),
    read("../public/legal/privacy.html"),
    read("../public/legal/terms.html"),
  ].join("\n");
  assert.doesNotMatch(
    currentSurfaces,
    /(?:publication|deployment|public deployment) remains (?:explicitly )?on hold/i,
  );
  assert.doesNotMatch(currentSurfaces, /future static hosting provider/i);
  assert.match(
    currentSurfaces,
    /access-restricted|restricted beta|beta web está limitada/i,
  );
  assert.match(
    license,
    /solely to persons explicitly authorized by the copyright holder/,
  );
});
