import test from "node:test";
import assert from "node:assert/strict";
import { selectBridge } from "../src/bridge";
import {
  createWebExecutionBridge,
  webBridge,
  WEB_BRIDGE_UNSUPPORTED,
} from "../src/bridge/web";
import type { ProjectDefinition, Settings } from "../src/types";
import { defaultOrchestration } from "../shared/domain";
import { validateProject } from "../src/core";
import { validateWebProject } from "../src/webExport";
import { safePdfAttachment, staticPdfBlob } from "./helpers/safeAttachment";

test("bridge selection uses the host API availability", () => {
  assert.equal(selectBridge(false).kind, "web");
  assert.equal(selectBridge(true).kind, "electron");
});

test("web provider detection reports unsupported host for every registry provider", async () => {
  assert.deepEqual(await webBridge.checkProviders(), [
    {
      providerId: "claude_code",
      state: "unsupported_host",
      reasonCode: "host_cannot_detect",
    },
    {
      providerId: "codex",
      state: "unsupported_host",
      reasonCode: "host_cannot_detect",
    },
  ]);
});

test("every unimplemented web bridge method explicitly reports unsupported", async () => {
  // execute() is real as of Phase P2.2 (W1 ZIP export) -- covered separately
  // below, not in this always-rejects list.
  const calls = [
    () => webBridge.chooseFolder(),
    () => webBridge.loadSettings(),
    () => webBridge.saveSettings({} as never),
    () => webBridge.githubStatus(),
    () => webBridge.connectGithub(),
    () => webBridge.loadHistory(),
    () =>
      webBridge.orchestrationPreflight({
        toolkitDir: "toolkit",
        projectDir: "project",
        configPath: "config",
      }),
    () =>
      webBridge.orchestrationStart({
        toolkitDir: "toolkit",
        projectDir: "project",
        configPath: "config",
      }),
    () => webBridge.orchestrationSnapshot(),
    () => webBridge.orchestrationDecide("pause"),
    () => webBridge.orchestrationCancel(),
  ];

  assert.equal(calls.length, 11);
  for (const call of calls) {
    await assert.rejects(call, new RegExp(WEB_BRIDGE_UNSUPPORTED, "i"));
  }
});

const project = (
  overrides: Partial<ProjectDefinition> = {},
): ProjectDefinition => ({
  name: "inventory copilot",
  phase: "idea",
  context: "known context",
  restrictions: "",
  route: "local",
  action: "repository",
  destination: "C:\\projects",
  participants: [{ id: "participant-01", role: "generalist", label: "" }],
  attachments: [],
  initializeGit: false,
  createRemote: false,
  remotePrivate: true,
  openIde: false,
  dryRun: false,
  orchestration: defaultOrchestration(),
  ...overrides,
});
const settings: Settings = {
  baseFolder: "",
  toolkitPath: "",
  futureProjectsPath: "future_projects",
  defaultBranch: "main",
  preferredIde: "VS Code",
  theme: "dark",
  locale: "en",
  confirmBeforeRun: true,
};
const request = (operationId: string, definition: ProjectDefinition) => ({
  operationId,
  definition,
  settings,
});
const operationId = (n: number) =>
  `00000000-0000-4000-8000-${String(n).padStart(12, "0")}`;

test("a session reset while building a ZIP prevents preparation, authorization and download", async () => {
  let current = true;
  let release!: (blob: Blob) => void;
  let started!: () => void;
  const building = new Promise<void>((resolve) => {
    started = resolve;
  });
  let prepared = 0,
    authorized = 0,
    downloaded = 0;
  const execute = createWebExecutionBridge({
    assertCurrent: () => {
      if (!current) throw new Error("session changed");
    },
    createArchive: () => {
      started();
      return new Promise<Blob>((resolve) => {
        release = resolve;
      });
    },
    prepared: () => {
      prepared++;
    },
    authorize: async () => {
      authorized++;
    },
    download: () => {
      downloaded++;
    },
  });
  const pending = execute(request(operationId(900), project()));
  await building;
  current = false;
  release(new Blob(["private A"]));
  const result = await pending;
  assert.equal(result.ok, false);
  assert.deepEqual([prepared, authorized, downloaded], [0, 0, 0]);
});

test("a session reset during authorization prevents the pending download", async () => {
  let current = true;
  let release!: () => void;
  let started!: () => void;
  const authorizing = new Promise<void>((resolve) => {
    started = resolve;
  });
  let downloads = 0;
  const execute = createWebExecutionBridge({
    assertCurrent: () => {
      if (!current) throw new Error("session changed");
    },
    createArchive: async () => new Blob(["private A"]),
    authorize: () => {
      started();
      return new Promise<void>((resolve) => {
        release = resolve;
      });
    },
    download: () => {
      downloads++;
    },
  });
  const pending = execute(request(operationId(901), project()));
  await authorizing;
  current = false;
  release();
  assert.equal((await pending).ok, false);
  assert.equal(downloads, 0);
});

test("web bridge execute reports validation errors without touching the DOM", async () => {
  const result = await webBridge.execute(
    request(operationId(1), project({ name: "", context: "" })),
  );
  assert.equal(result.ok, false);
  assert.equal(result.outcome, "failure");
  assert.deepEqual(result.artifacts, []);
  assert.match(result.error ?? "", /invalid project definition/i);
});

test("web bridge execute dry-run reports intent without producing a download", async () => {
  const result = await webBridge.execute(
    request(operationId(2), project({ dryRun: true })),
  );
  assert.equal(result.ok, true);
  assert.equal(result.dryRun, true);
  assert.equal(result.outcome, "dry-run");
  assert.ok(result.steps.every(({ status }) => status === "skipped"));
  assert.deepEqual(result.artifacts, []);
  assert.match(result.logs[0], /would export/i);
});

test("web limits reject restored definitions before dry review or archive creation", async () => {
  let archiveCalls = 0;
  let downloads = 0;
  const execute = createWebExecutionBridge({
    fingerprint: async (value) => value.operationId,
    createArchive: async () => {
      archiveCalls += 1;
      return new Blob(["zip"]);
    },
    download: () => {
      downloads += 1;
    },
  });
  const fiveRoles = [
    "generalist",
    "architect",
    "implementer",
    "auditor",
    "generalist",
  ] as const;
  const cases = [
    { definition: project({ name: "a".repeat(51) }), error: "webNameLength" },
    {
      definition: project({
        participants: [
          { id: "participant-01", role: "generalist", label: "" },
          { id: "participant-02", role: "generalist", label: "" },
        ],
      }),
      error: "duplicateParticipantRole",
    },
    {
      definition: project({
        participants: fiveRoles.map((role, index) => ({
          id: `participant-0${index + 1}`,
          role,
          label: "",
        })),
      }),
      error: "webParticipantCount",
    },
  ];
  let index = 100;
  for (const { definition, error } of cases) {
    const original = structuredClone(definition);
    // The retained desktop contract is unchanged; web validation does not mutate drafts.
    assert.deepEqual(validateProject(definition, settings), {});
    for (const dryRun of [true, false]) {
      const result = await execute(
        request(operationId(index++), { ...definition, dryRun }),
      );
      assert.equal(result.ok, false);
      assert.match(result.error ?? "", new RegExp(error));
      assert.deepEqual(result.artifacts, []);
    }
    assert.deepEqual(definition, original);
  }
  const boundary = project({
    name: "a".repeat(50),
    participants: fiveRoles.slice(0, 4).map((role, index) => ({
      id: `participant-0${index + 1}`,
      role,
      label: "",
    })),
  });
  assert.deepEqual(validateWebProject(boundary, settings), {});
  assert.equal(
    (await execute(request(operationId(index), { ...boundary, dryRun: true })))
      .ok,
    true,
  );
  assert.equal(archiveCalls, 0);
  assert.equal(downloads, 0);
});

test("web bridge execute reports tracking-only as unsupported without touching the DOM", async () => {
  const result = await webBridge.execute(
    request(operationId(3), project({ action: "tracking" })),
  );
  assert.equal(result.ok, false);
  assert.match(result.error ?? "", /tracking-only export isn't supported/i);
});

test("web bridge coalesces concurrent exports into one archive and download", async () => {
  let resolveArchive!: (blob: Blob) => void;
  const archive = new Promise<Blob>((resolve) => {
    resolveArchive = resolve;
  });
  let archiveCalls = 0;
  const downloads: string[] = [];
  const execute = createWebExecutionBridge({
    fingerprint: async (value) => JSON.stringify(value.definition),
    createArchive: async () => {
      archiveCalls += 1;
      return archive;
    },
    download: (_blob, filename) => downloads.push(filename),
  });
  const first = execute(request(operationId(10), project()));
  const repeated = execute(request(operationId(10), project()));
  const coalesced = execute(request(operationId(11), project()));
  await new Promise<void>((resolve) => setImmediate(resolve));
  assert.equal(archiveCalls, 1);
  resolveArchive(new Blob(["zip"]));
  const results = await Promise.all([first, repeated, coalesced]);
  assert.equal(downloads.length, 1);
  assert.deepEqual(
    results.map((result) => result.operationId),
    [operationId(10), operationId(10), operationId(10)],
  );
});

test("web bridge passes attachment Blobs to the archive and rejects stale sidecars", async () => {
  const attachment = await safePdfAttachment();
  let archivedInput: string | Blob | undefined;
  const execute = createWebExecutionBridge({
    fingerprint: async (value) => value.operationId,
    createArchive: async (entries) => {
      archivedInput = entries.find(
        (entry) => entry.kind === "attachment",
      )?.input;
      return new Blob(["zip"]);
    },
    download: () => undefined,
  });
  const definition = project({
    attachments: [
      {
        name: attachment.name,
        extension: attachment.extension,
        size: attachment.size,
      },
    ],
  });
  const result = await execute({
    ...request(operationId(20), definition),
    webAttachments: [attachment],
  });
  assert.equal(result.ok, true);
  assert.equal(archivedInput, attachment.blob);
  assert.equal(result.outcome, "success");
  assert.equal(result.webDelivery?.state, "download-requested");
  assert.equal(result.webDelivery?.browserPersistenceVerified, false);
  assert.deepEqual(
    result.webDelivery?.manifest,
    result.artifacts
      .filter(({ kind }) => kind === "zip-entry")
      .map(({ location }) => location),
  );
  const stale = await execute({
    ...request(operationId(21), definition),
    webAttachments: [],
  });
  assert.equal(stale.ok, false);
  assert.match(stale.error ?? "", /does not match/i);
});

test("web bridge dry run never creates an archive when attachments are selected", async () => {
  let calls = 0;
  const execute = createWebExecutionBridge({
    fingerprint: async (value) => value.operationId,
    createArchive: async () => {
      calls += 1;
      return new Blob();
    },
    download: () => undefined,
  });
  const attachment = await safePdfAttachment();
  const result = await execute({
    ...request(
      operationId(22),
      project({
        dryRun: true,
        attachments: [
          {
            name: attachment.name,
            extension: attachment.extension,
            size: attachment.size,
          },
        ],
      }),
    ),
    webAttachments: [attachment],
  });
  assert.equal(result.ok, true);
  assert.equal(calls, 0);
  assert.match(result.logs[0], /no ZIP was created/i);
});

test("direct bridge calls inspect file bytes before archive, retained ZIP, quota or download", async () => {
  let effects = 0;
  const execute = createWebExecutionBridge({
    fingerprint: async (value) => value.operationId,
    createArchive: async () => {
      effects++;
      return new Blob();
    },
    authorize: async () => {
      effects++;
    },
    prepared: () => {
      effects++;
    },
    download: () => {
      effects++;
    },
  });
  for (const [index, name, blob] of [
    [70, "renamed.pdf", new Blob(["MZ executable fixture"])],
    [71, "source.txt", new Blob(["text fixture"])],
    [72, "vector.png", new Blob(['<svg xmlns="http://www.w3.org/2000/svg"/>'])],
  ] as const) {
    const extension = name.slice(name.lastIndexOf("."));
    const metadata = { name, extension, size: blob.size };
    const result = await execute({
      ...request(operationId(index), project({ attachments: [metadata] })),
      webAttachments: [{ ...metadata, id: String(index), blob }],
    });
    assert.equal(result.ok, false);
    assert.equal(effects, 0);
  }
  // A genuine unprepared PDF exercises the final boundary without picker proof.
  const blob = await staticPdfBlob();
  const metadata = { name: "direct.pdf", extension: ".pdf", size: blob.size };
  const result = await execute({
    ...request(operationId(73), project({ attachments: [metadata] })),
    webAttachments: [{ ...metadata, id: "direct", blob }],
  });
  assert.equal(result.ok, true);
  assert.equal(effects, 4);
});

test("web bridge distinguishes ZIP and download-request failures without delivery evidence", async () => {
  const archiveFailure = createWebExecutionBridge({
    fingerprint: async (value) => value.operationId,
    createArchive: async () => {
      throw new Error("archive unavailable");
    },
  });
  const first = await archiveFailure(request(operationId(30), project()));
  assert.equal(first.outcome, "failure");
  assert.equal(first.steps[0].status, "failed");
  assert.equal(first.webDelivery, undefined);
  assert.deepEqual(first.artifacts, []);

  const requestFailure = createWebExecutionBridge({
    fingerprint: async (value) => value.operationId,
    createArchive: async () => new Blob(["zip"]),
    download: () => {
      throw new Error("download blocked");
    },
  });
  const second = await requestFailure(request(operationId(31), project()));
  assert.equal(second.outcome, "partial");
  assert.deepEqual(second.completed, ["zip-build"]);
  assert.deepEqual(
    second.steps.map(({ status }) => status),
    ["completed", "failed"],
  );
  assert.equal(second.webDelivery, undefined);
  assert.deepEqual(second.artifacts, []);
});
