# accreatio — Engineering Governance

## Mission

Build a zero-cost, local-first web project launch point that turns structured input into an explicit prompt, deterministic plan, and downloadable project bundle.

## Operating rules

- Separate configuration, validation, prompt generation, planning, and execution.
- Never overwrite an existing project file; use deterministic versioned copies.
- Never pass user-authored text to a shell command.
- accreatio is web-only. The original desktop prototype is obsolete, was never released and will never be released. Preserve its source as historical custody; desktop development, packaging and release commands must fail closed. See [the retirement decision](docs/WEB_ONLY_DELIVERY_2026-10-22.md).
- Untrusted browser attachments are limited to DOCX, PDF, PNG and JPEG. Enforce content inspection/reconstruction locally at selection and the final ZIP boundary; a file extension or caller flag is never evidence of safe content. Generated project Markdown/JSON/YAML and own-account JSON exports are separate product outputs, not permitted untrusted uploads.
- Project creation requires no AI provider, emits no telemetry, and performs no project cloud sync. Never store user, GitHub, IDE, or AI-provider credentials; the web-only editorial backend may use protected runtime configuration and its separate D1 Blog store. The owner-authorized web account service may retain encrypted email and profile display name, opaque account identifiers, hashed revocable sessions and quota receipts in a separate D1 account store; it never receives project contents or retains third-party credentials. The display name is presentation data only, included in account export and erased on deletion; profile photos and other profile fields are not retained.
- The owner-requested privacy controls may retain a minimal versioned account-processing authorization and Terms receipt with database time in that same account store. It requires a deliberate continuation action beside a visible Terms/necessary-processing notice and valid account proof, is included in own-account export and erased with account deletion; it adds no tracking, IP/user-agent record, historical acceptance backfill or cross-product consent. Cookie preferences remain independent and never grant optional collection through sign-in.
- The owner-authorized technical abuse guard is a separate, bounded account-store exception: fixed-route counters keyed by HMAC network/account/session values and minimal opaque account restriction state, with one-hour counter expiry and a 48-hour account-state window. Do not store raw IP, email, user agent, request bodies or project content in this guard, or repurpose it for analytics/cross-product identity. Three eligible attributable excess episodes in ten minutes may suspend an ordinary verified account for ten minutes, then one hour and up to 24 hours on recurrence within 48 hours. Network/email coincidence or content/AI assessment alone never sanctions an account; permanent closure is not automatic. Preserve separately verified own-data/deletion access, including the five-minute rights-only cookie, without requiring new Terms/account authorization. Soft deletion does not erase minimal abuse continuity early; expiry/capped cleanup and physical account removal bound it. See [the abuse-guard runbook](docs/ABUSE_GUARD_2026-10-22.md).
- GitHub is optional, uses the user's `gh` session, defaults private, and never pushes automatically.
- Dry-run remains available and defaults on.
- Verify with tests, typecheck, web build, artifact boundary smoke and functional UI pass. The retired desktop is never a release/packaging prerequisite.
- Commits and pushes are authorized by Ed Lopez for this project as of 2026-08-02.

## Bounded Collect authorization (2026-10-22)

The owner's complementary Collect/Security order authorizes prospective optional usage measurement and independently submitted structured research. This supersedes the earlier blanket no-telemetry wording only for the closed catalog in `shared/collection.ts`. Explicit browser choices, separate purpose capabilities, current server permission and version, 30-day expiry, withdrawal, export and bounded cleanup govern those new records. No project/attachment/ZIP text, credentials, account linkage, cross-product dataset, OAuth expansion or commercial transfer is authorized. Existing account, rights, abuse, editorial, zero-cost and retired-desktop boundaries remain. Source configuration enables `COLLECT_ENABLED` only after the documented additive migration and compatible deployment; it is not proof of remote activation. The owner's supplied institutional address/contact resolves that stated disclosure gap. Keep the representative's name private and provide the institutional request channel instead. Commercial delivery retains its separate exact-recipient/legal gate.

## Local logs and caches

Write command logs and diagnostics under `.local/logs/`, and reproducible caches under `.local/cache/`; never create root-level logs. Read ignored evidence by explicit path or `rg --files --hidden --no-ignore .local/logs`. Use `npm.cmd run log -- <script>` for unique output with preserved exit status. Follow [docs/LOCAL_ARTIFACTS.md](docs/LOCAL_ARTIFACTS.md) for retention and tool-required exceptions.

## Architecture

`src/core.ts` is pure domain logic. `src/App.tsx` is the web UI. `src/attachmentSecurity.ts` owns module-private admission proof for reconstructed browser attachments; the final export boundary requires that proof. `electron/` retains the obsolete, unreleased prototype for historical custody and is not a supported application surface.

## Planned-agent integrity

Generated projects may declare one to four roles. At session bootstrap, compare planned roles with agents/tools actually available. Warn on mismatch and get a user decision before reducing topology. Never represent self-review as independent audit.

## Cost constraint

Mandatory zero direct service cost until Ed explicitly changes this requirement. Prefer open-source dependencies and local capabilities.

## AEKR asset preservation

Use the canonical AEKR assets and local mappings in [docs/AEKR_BRANDING.md](docs/AEKR_BRANDING.md). Preserve the master logo, banner artwork and accepted web footer; never redraw or regenerate them when adding AEKR branding. Copy the approved source version and its license; run `npm.cmd run aekr:branding:check` to check the pinned copies. Ed accepted the soft-edge banner and authorized the README rollout on 2026-09-05, excluding archive and master archiving.

## accreatio official identity

Use the logo supplied and selected by Ed on 2026-10-22, documented in [docs/ACCREATIO_BRANDING.md](docs/ACCREATIO_BRANDING.md). Preserve its original PNG and SHA-256 provenance; reuse its symbol and custom lettering through deterministic crops and scaling. Do not redraw, retype, regenerate or silently replace it. The web palette is matte Iceland pearl `#E8EAE7` for the background, charcoal `#303235` for titles, intense red `#E2232A` for limited accents, `#515852` for body text and `#5E655E` for subtext. The owner delegated those two reading-color choices; preserve their accessible contrast. The pearl theme is the web default. The former design remains in `docs/design-backups/2026-10-22-pre-iceland/`.

Ed accepted this visual direction and requested denser nebula, global alignment refinements and removal of the pale logo background in dark mode on 2026-10-22. The dark SVG wrappers may use the documented native alpha/color filter to render the supplied contours in pearl/red with transparency; preserve the canonical PNG, exact PNG crops and light SVGs.
