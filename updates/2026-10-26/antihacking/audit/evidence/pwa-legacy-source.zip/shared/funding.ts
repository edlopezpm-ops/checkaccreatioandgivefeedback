import type { ProviderId } from "./providerRegistry";

export type CurrencyCode = "USD";

export interface SubscriptionCliFunding {
  mode: "subscription_cli";
  currency: "USD";
  maxCost: "0";
  hardStop: true;
}

export interface ApiFunding {
  mode: "api";
  providerId: ProviderId;
  modelProfileId: string;
  currency: CurrencyCode;
  maxCost: string;
  hardStopAcknowledged: true;
}

export type FundingPolicy = SubscriptionCliFunding | ApiFunding;

export type FundingReasonCode =
  | "funding_invalid"
  | "api_not_supported"
  | "api_profile_required"
  | "api_exact_hard_stop_unavailable"
  | "api_acknowledgment_required"
  | "api_provider_mismatch"
  | "api_currency_mismatch";

export interface FundingValidationResult {
  readonly valid: boolean;
  readonly reasonCode?: FundingReasonCode;
}

export interface FundingParticipantAssignment {
  readonly participantId: string;
  readonly provider: string;
}

export interface FundingProfileDescriptor {
  readonly id: string;
  readonly currency: CurrencyCode;
  readonly enforcement: "exact" | "estimated" | "none";
  readonly enforcementScope: "cumulative_execution" | "per_invocation" | "none";
  readonly aekrContractVersion: string;
}

export interface FundingProviderDescriptor {
  readonly id: string;
  readonly capabilities: readonly string[];
  readonly apiModelProfiles?: readonly FundingProfileDescriptor[];
}

export const defaultFunding = (): SubscriptionCliFunding => ({
  mode: "subscription_cli",
  currency: "USD",
  maxCost: "0",
  hardStop: true,
});

const MONEY_PATTERN = /^(0|[1-9]\d*)(\.\d{1,2})?$/;

export function parseMinorUnits(value: string): bigint | null {
  if (!MONEY_PATTERN.test(value)) return null;
  const [whole, fraction = ""] = value.split(".");
  return BigInt(whole) * 100n + BigInt(fraction.padEnd(2, "0") || "0");
}

export function normalizeMaxCost(value: string): string | null {
  const minorUnits = parseMinorUnits(value);
  if (minorUnits === null) return null;
  const whole = minorUnits / 100n;
  const fraction = String(minorUnits % 100n).padStart(2, "0");
  return fraction === "00"
    ? String(whole)
    : `${String(whole)}.${fraction.replace(/0$/, "")}`;
}

export function evaluateFundingEligibility(
  policy: unknown,
  assignments: readonly FundingParticipantAssignment[],
  providers: readonly FundingProviderDescriptor[],
  supportedAekrContractVersions: readonly string[] = [],
): FundingValidationResult {
  if (!policy || typeof policy !== "object")
    return { valid: false, reasonCode: "funding_invalid" };
  const candidate = policy as Record<string, unknown>;
  if (candidate.mode === "subscription_cli") {
    const subscriptionProvidersValid = assignments.every(({ provider: id }) =>
      providers.some(
        (provider) =>
          provider.id === id &&
          provider.capabilities.includes("subscription_cli"),
      ),
    );
    return candidate.currency === "USD" &&
      candidate.maxCost === "0" &&
      candidate.hardStop === true &&
      subscriptionProvidersValid
      ? { valid: true }
      : { valid: false, reasonCode: "funding_invalid" };
  }
  if (candidate.mode !== "api")
    return { valid: false, reasonCode: "funding_invalid" };
  if (candidate.hardStopAcknowledged !== true)
    return { valid: false, reasonCode: "api_acknowledgment_required" };
  if (typeof candidate.modelProfileId !== "string" || !candidate.modelProfileId)
    return { valid: false, reasonCode: "api_profile_required" };
  if (
    typeof candidate.maxCost !== "string" ||
    parseMinorUnits(candidate.maxCost) === null ||
    parseMinorUnits(candidate.maxCost) === 0n
  )
    return { valid: false, reasonCode: "funding_invalid" };
  const provider = providers.find(({ id }) => id === candidate.providerId);
  if (
    !provider ||
    !provider.capabilities.includes("api_funding") ||
    !provider.capabilities.includes("exact_cumulative_cost_hard_stop")
  )
    return { valid: false, reasonCode: "api_not_supported" };
  if (assignments.some(({ provider: id }) => id !== provider.id))
    return { valid: false, reasonCode: "api_provider_mismatch" };
  const profile = provider.apiModelProfiles?.find(
    ({ id }) => id === candidate.modelProfileId,
  );
  if (!profile) return { valid: false, reasonCode: "api_profile_required" };
  if (profile.currency !== candidate.currency)
    return { valid: false, reasonCode: "api_currency_mismatch" };
  if (
    profile.enforcement !== "exact" ||
    profile.enforcementScope !== "cumulative_execution" ||
    !supportedAekrContractVersions.includes(profile.aekrContractVersion)
  )
    return {
      valid: false,
      reasonCode: "api_exact_hard_stop_unavailable",
    };
  return { valid: true };
}
