/** Server-generated slugs fit within 89 characters. Keep old trailing-hyphen
 * compatibility while bounding all public URL/API consumers before scanning. */
export const MAX_BLOG_SLUG_LENGTH = 128;

export function isBlogSlug(value: unknown): value is string {
  if (
    typeof value !== "string" ||
    !value.length ||
    value.length > MAX_BLOG_SLUG_LENGTH
  )
    return false;
  let previousHyphen = true;
  for (let index = 0; index < value.length; index += 1) {
    const code = value.charCodeAt(index);
    if (code === 45) {
      if (previousHyphen) return false;
      previousHyphen = true;
    } else if ((code >= 97 && code <= 122) || (code >= 48 && code <= 57)) {
      previousHyphen = false;
    } else return false;
  }
  return true;
}

export function blogPostFromUrl(href: string): string | null {
  const value = new URL(href).searchParams.get("post");
  return isBlogSlug(value) ? value : null;
}
