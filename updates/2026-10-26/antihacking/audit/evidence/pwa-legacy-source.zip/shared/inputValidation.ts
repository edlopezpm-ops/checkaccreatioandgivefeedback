/** Local data contracts. These checks never classify intent or remove prose. */
export const PROJECT_TEXT_LIMITS = {
  context: 20_000,
  restrictions: 10_000,
  task: 5_000,
  path: 4_096,
  attachmentName: 240,
} as const;

const CONTROLS = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/;
const SINGLE_LINE_CONTROLS = /[\u0000-\u001f\u007f]/;
export const isPlainRecord = (
  value: unknown,
): value is Record<string, unknown> => {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return (
    (prototype === Object.prototype || prototype === null) &&
    Object.values(Object.getOwnPropertyDescriptors(value)).every(
      (d) => "value" in d,
    )
  );
};
const fields = (
  value: unknown,
  required: readonly string[],
  optional: readonly string[] = [],
): value is Record<string, unknown> =>
  isPlainRecord(value) &&
  required.every((key) => Object.hasOwn(value, key)) &&
  Object.keys(value).every(
    (key) => required.includes(key) || optional.includes(key),
  );
export const validText = (
  value: unknown,
  max: number,
  singleLine = false,
): value is string =>
  typeof value === "string" &&
  value.length <= max &&
  !(singleLine ? SINGLE_LINE_CONTROLS : CONTROLS).test(value);
const integer = (value: unknown, min: number, max: number) =>
  typeof value === "number" &&
  Number.isSafeInteger(value) &&
  value >= min &&
  value <= max;
const choice = (value: unknown, allowed: readonly string[]) =>
  typeof value === "string" && allowed.includes(value);

export function settingsShapeErrors(value: unknown): Record<string, string> {
  if (
    !fields(value, [
      "baseFolder",
      "toolkitPath",
      "futureProjectsPath",
      "defaultBranch",
      "preferredIde",
      "theme",
      "locale",
      "confirmBeforeRun",
    ])
  )
    return { settings: "invalid" };
  if (
    ["baseFolder", "toolkitPath", "futureProjectsPath"].some(
      (key) => !validText(value[key], PROJECT_TEXT_LIMITS.path, true),
    ) ||
    !validText(value.defaultBranch, 240, true) ||
    !choice(value.preferredIde, ["VS Code", "File Explorer"]) ||
    !choice(value.theme, ["dark", "light"]) ||
    !choice(value.locale, ["es", "en"]) ||
    typeof value.confirmBeforeRun !== "boolean"
  )
    return { settings: "invalid" };
  return {};
}

export function projectShapeErrors(value: unknown): Record<string, string> {
  const errors: Record<string, string> = {};
  if (
    !fields(value, [
      "name",
      "phase",
      "context",
      "restrictions",
      "route",
      "action",
      "destination",
      "participants",
      "attachments",
      "initializeGit",
      "createRemote",
      "remotePrivate",
      "openIde",
      "dryRun",
      "orchestration",
    ])
  )
    return { definition: "invalid" };
  if (!validText(value.name, 80, true)) errors.name = "invalid";
  for (const key of ["context", "restrictions"] as const) {
    if (!validText(value[key], PROJECT_TEXT_LIMITS[key]))
      errors[key] =
        typeof value[key] === "string" &&
        value[key].length > PROJECT_TEXT_LIMITS[key]
          ? `${key}TooLong`
          : "invalid";
  }
  if (!validText(value.destination, PROJECT_TEXT_LIMITS.path, true))
    errors.destination = "invalid";
  if (!choice(value.phase, ["idea", "discovery-active", "discovery-complete"]))
    errors.phase = "invalid";
  if (!choice(value.route, ["local", "vendor", "mixed"]))
    errors.route = "invalid";
  if (!choice(value.action, ["tracking", "repository", "both"]))
    errors.action = "invalid";
  for (const key of [
    "initializeGit",
    "createRemote",
    "remotePrivate",
    "openIde",
    "dryRun",
  ])
    if (typeof value[key] !== "boolean") errors[key] = "invalid";
  if (Array.isArray(value.participants) && value.participants.length > 6)
    errors.participants = "participantCount";
  else if (
    !Array.isArray(value.participants) ||
    value.participants.some(
      (p) =>
        !fields(p, ["id", "role", "label"]) ||
        !validText(p.id, 64, true) ||
        !choice(p.role, [
          "generalist",
          "architect",
          "implementer",
          "auditor",
        ]) ||
        !validText(p.label, 120, true),
    )
  )
    errors.participants = "invalidParticipantIdentity";
  if (
    !Array.isArray(value.attachments) ||
    value.attachments.length > 20 ||
    value.attachments.some(
      (a) =>
        !fields(a, ["name", "size", "extension"], ["path"]) ||
        !validText(a.name, PROJECT_TEXT_LIMITS.attachmentName, true) ||
        !validText(a.extension, 10, true) ||
        !integer(a.size, 0, 20 * 1024 * 1024) ||
        (a.path !== undefined &&
          !validText(a.path, PROJECT_TEXT_LIMITS.path, true)),
    )
  )
    errors.attachments = "invalid";
  const o = value.orchestration;
  if (
    !fields(o, [
      "enabled",
      "participants",
      "sessionMaxDurationSeconds",
      "maxIterationsPerEntity",
      "maxProviderInvocations",
      "maxConsecutiveFailures",
      "funding",
    ]) ||
    typeof o.enabled !== "boolean" ||
    !Array.isArray(o.participants) ||
    o.participants.length > 6 ||
    o.participants.some(
      (p) =>
        !fields(p, ["participantId", "provider"], ["task"]) ||
        !validText(p.participantId, 64, true) ||
        !validText(p.provider, 64, true) ||
        (p.task !== undefined && !validText(p.task, PROJECT_TEXT_LIMITS.task)),
    ) ||
    !integer(o.sessionMaxDurationSeconds, 60, 7200) ||
    !integer(o.maxIterationsPerEntity, 1, 10) ||
    !integer(o.maxProviderInvocations, 1, 100) ||
    !integer(o.maxConsecutiveFailures, 1, 10)
  ) {
    errors.orchestration = "invalidOrchestrationParticipants";
  } else {
    const f = o.funding;
    if (
      !isPlainRecord(f) ||
      (f.mode === "subscription_cli"
        ? !fields(f, ["mode", "currency", "maxCost", "hardStop"])
        : f.mode === "api"
          ? !fields(f, [
              "mode",
              "providerId",
              "modelProfileId",
              "currency",
              "maxCost",
              "hardStopAcknowledged",
            ])
          : true) ||
      !validText(f.maxCost, 32, true) ||
      !validText(f.currency, 3, true) ||
      (f.mode === "subscription_cli" && typeof f.hardStop !== "boolean") ||
      (f.mode === "api" &&
        (typeof f.hardStopAcknowledged !== "boolean" ||
          !validText(f.providerId, 64, true) ||
          !validText(f.modelProfileId, 120, true)))
    )
      errors.funding = "funding_invalid";
  }
  return errors;
}

export function assertProjectShape(value: unknown): void {
  const errors = projectShapeErrors(value);
  if (Object.keys(errors).length)
    throw new Error(
      `Invalid project definition: ${Object.entries(errors)
        .map(([field, code]) => `${field}: ${code}`)
        .join(", ")}`,
    );
}

export function assertSettingsShape(value: unknown): void {
  if (Object.keys(settingsShapeErrors(value)).length)
    throw new Error("Invalid project settings");
}

export const RESERVED_FILENAME =
  /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i;
export const portableLeafName = (value: string) =>
  validText(value, PROJECT_TEXT_LIMITS.attachmentName, true) &&
  value.length > 0 &&
  !/[<>:"|?*\\/]/.test(value) &&
  !/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/.test(value) &&
  value !== "." &&
  value !== ".." &&
  !/[. ]$/.test(value) &&
  !RESERVED_FILENAME.test(value);

export function assertArchivePaths(
  paths: readonly string[],
  root: string,
): void {
  if (!portableLeafName(root)) throw new Error("Invalid archive root");
  const used = new Set<string>();
  for (const path of paths) {
    const parts = path.split("/");
    const key = path.normalize("NFC").toLowerCase();
    if (
      path.length > 1024 ||
      parts.length < 2 ||
      parts[0] !== root ||
      parts.some((part) => !portableLeafName(part)) ||
      used.has(key)
    )
      throw new Error("Invalid or duplicate archive path");
    used.add(key);
  }
}
