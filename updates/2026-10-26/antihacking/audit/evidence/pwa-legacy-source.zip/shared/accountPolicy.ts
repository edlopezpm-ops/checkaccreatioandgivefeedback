export const ACCOUNT_POLICY = {
  privacyNoticeVersion: "2026-10-22b-privacy",
  termsVersion: "2026-10-22b-beta",
  purposeVersion: "account-core-v1",
} as const;

export type AccountPolicyAuthorization = {
  readonly privacyNoticeVersion: string;
  readonly termsVersion: string;
  readonly purposeVersion: string;
  readonly accountDataAuthorized: boolean;
  readonly termsAccepted: boolean;
};
