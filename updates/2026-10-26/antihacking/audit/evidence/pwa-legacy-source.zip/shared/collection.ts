/** Prospective accreatio-only collection. Never pass project/account objects here. */
export const COLLECTION_VERSION = "2026-10-22-collect-v1";
export const COLLECTION_RETENTION_MS = 30 * 86400000;
export const COLLECTION_MAX_RECORDS = 200;
export type CollectionPurpose = "analytics" | "research";
export const RESEARCH_FIELDS = {
  region: [
    "latin-america",
    "north-america",
    "europe",
    "asia-pacific",
    "africa-middle-east",
    "prefer-not-say",
  ],
  role: [
    "developer",
    "product",
    "designer",
    "founder",
    "student",
    "researcher",
    "other",
  ],
  industry: [
    "software",
    "education",
    "professional-services",
    "retail",
    "industry",
    "public-nonprofit",
    "other",
  ],
  experience: ["starting", "1-3-years", "4-10-years", "10-plus-years"],
  teamSize: ["solo", "2-5", "6-20", "21-100", "101-plus"],
  tools: ["vscode", "github", "gitlab", "codex", "claude", "other", "none"],
  goal: [
    "learn",
    "prototype",
    "launch-product",
    "client-delivery",
    "internal-tool",
    "research",
  ],
  challenge: [
    "clarity",
    "planning",
    "governance",
    "tooling",
    "collaboration",
    "delivery",
  ],
  integration: ["github", "gitlab", "jira", "linear", "local-ide", "none"],
  priority: [
    "templates",
    "accessibility",
    "offline",
    "collaboration",
    "integrations",
    "guidance",
  ],
  willingnessToPay: [
    "free-only",
    "under-10-usd-month",
    "10-25-usd-month",
    "26-50-usd-month",
    "over-50-usd-month",
    "unsure",
  ],
  satisfaction: ["1", "2", "3", "4", "5"],
  frequency: ["first-use", "less-than-monthly", "monthly", "weekly", "daily"],
} as const;
export type ResearchAnswers = Partial<
  Record<keyof typeof RESEARCH_FIELDS, string>
>;
export const USAGE_FEATURES = [
  "onboarding",
  "creation",
  "review",
  "export",
  "about",
  "blog",
  "privacy",
] as const;
export interface UsageRecord {
  kind: "usage";
  feature: (typeof USAGE_FEATURES)[number];
  outcome: "opened" | "left" | "completed" | "cancelled" | "error";
  durationBand:
    | "instant"
    | "under-minute"
    | "1-5-minutes"
    | "5-15-minutes"
    | "15-plus-minutes";
  locale: "en" | "es";
  device: "mobile" | "tablet" | "desktop";
}
export interface ResearchRecord {
  kind: "research";
  answers: ResearchAnswers;
}
export function parseCollectionRecord(
  value: unknown,
  purpose: CollectionPurpose,
): UsageRecord | ResearchRecord | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const v = value as Record<string, unknown>;
  if (purpose === "research") {
    if (
      Object.keys(v).sort().join() !== "answers,kind" ||
      v.kind !== "research" ||
      !v.answers ||
      typeof v.answers !== "object" ||
      Array.isArray(v.answers)
    )
      return null;
    const entries = Object.entries(v.answers);
    if (!entries.length || entries.length > Object.keys(RESEARCH_FIELDS).length)
      return null;
    for (const [key, answer] of entries) {
      const options = RESEARCH_FIELDS[key as keyof typeof RESEARCH_FIELDS] as
        readonly string[] | undefined;
      if (
        !Object.hasOwn(RESEARCH_FIELDS, key) ||
        !options ||
        typeof answer !== "string" ||
        !options.includes(answer)
      )
        return null;
    }
    return { kind: "research", answers: Object.fromEntries(entries) };
  }
  if (
    Object.keys(v).sort().join() !==
      "device,durationBand,feature,kind,locale,outcome" ||
    v.kind !== "usage" ||
    !["feature", "outcome", "durationBand", "locale", "device"].every(
      (k) => typeof v[k] === "string",
    ) ||
    !USAGE_FEATURES.includes(v.feature as UsageRecord["feature"]) ||
    !["opened", "left", "completed", "cancelled", "error"].includes(
      String(v.outcome),
    ) ||
    ![
      "instant",
      "under-minute",
      "1-5-minutes",
      "5-15-minutes",
      "15-plus-minutes",
    ].includes(String(v.durationBand)) ||
    !["en", "es"].includes(String(v.locale)) ||
    !["mobile", "tablet", "desktop"].includes(String(v.device))
  )
    return null;
  return {
    kind: "usage",
    feature: v.feature,
    outcome: v.outcome,
    durationBand: v.durationBand,
    locale: v.locale,
    device: v.device,
  } as UsageRecord;
}
