export type ProviderCapability =
  | "subscription_cli"
  | "desktop_cli_detection"
  | "aekr_adapter_serialization"
  | "api_funding"
  | "exact_cumulative_cost_hard_stop";

import type { CurrencyCode, FundingPolicy } from "./funding";

export interface ApiModelProfileDescriptor {
  readonly id: string;
  readonly displayName: string;
  readonly currency: CurrencyCode;
  readonly enforcement: "exact" | "estimated" | "none";
  readonly enforcementScope: "cumulative_execution" | "per_invocation" | "none";
  readonly aekrContractVersion: string;
  readonly adapterProfileId: string;
}

export type ProviderAvailabilityState =
  | "installed_authenticated"
  | "installed_unauthenticated"
  | "not_installed"
  | "unsupported_host";

export type ProviderAvailabilityReason =
  | "ready"
  | "cli_not_found"
  | "not_logged_in"
  | "unsupported_auth_mode"
  | "auth_status_unreadable"
  | "host_cannot_detect";

export interface FixedCliProbe {
  readonly executable: string;
  readonly argv: readonly string[];
}

export interface ProbeResult {
  readonly code: number | null;
  readonly combined: string;
}

export interface DesktopCliDetection {
  readonly versionProbe: FixedCliProbe;
  readonly authProbe: FixedCliProbe;
  readonly classifyAuth: (result: ProbeResult) => ProviderAuthClassification;
}

export interface ProviderAuthClassification {
  readonly state: "installed_authenticated" | "installed_unauthenticated";
  readonly reasonCode: ProviderAvailabilityReason;
}

export interface AekrAdapterDescriptor {
  readonly kind: string;
  readonly serialize: (context: AekrAdapterContext) => readonly string[];
}

export interface AekrAdapterContext {
  readonly canonicalRole:
    "generalist" | "architect" | "implementer" | "auditor";
  readonly funding: FundingPolicy;
}

const claudeDescriptor = {
  id: "claude_code",
  displayName: "Claude Code",
  capabilities: [
    "subscription_cli",
    "desktop_cli_detection",
    "aekr_adapter_serialization",
  ],
  desktopDetection: {
    versionProbe: { executable: "claude", argv: ["--version"] },
    authProbe: { executable: "claude", argv: ["auth", "status"] },
    classifyAuth: classifyClaudeAuth,
  },
  adapter: {
    kind: "claude_code",
    serialize: () => ["kind: claude_code"],
  },
  apiModelProfiles: [],
} as const;

const codexDescriptor = {
  id: "codex",
  displayName: "Codex",
  capabilities: [
    "subscription_cli",
    "desktop_cli_detection",
    "aekr_adapter_serialization",
  ],
  desktopDetection: {
    versionProbe: { executable: "codex", argv: ["--version"] },
    authProbe: { executable: "codex", argv: ["login", "status"] },
    classifyAuth: classifyCodexAuth,
  },
  adapter: {
    kind: "codex",
    serialize: ({ canonicalRole }: AekrAdapterContext) => [
      "kind: codex",
      `sandbox: ${canonicalRole === "implementer" ? "workspace-write" : "read-only"}`,
    ],
  },
  apiModelProfiles: [],
} as const;

export const PROVIDER_REGISTRY = [claudeDescriptor, codexDescriptor] as const;
export type ProviderId = (typeof PROVIDER_REGISTRY)[number]["id"];
export type ProviderDescriptor = (typeof PROVIDER_REGISTRY)[number];
export const PROVIDER_IDS = PROVIDER_REGISTRY.map(
  ({ id }) => id,
) as readonly ProviderId[];
export const DEFAULT_PROVIDER_ID: ProviderId = "codex";

export interface ProviderAvailabilityResult {
  readonly providerId: ProviderId;
  readonly state: ProviderAvailabilityState;
  readonly reasonCode: ProviderAvailabilityReason;
  readonly detail?: string;
}

export type ProviderAvailability = readonly ProviderAvailabilityResult[];

export type ProviderAction = "export" | "execute";
export interface ProviderEligibility {
  readonly enabled: boolean;
  readonly status: "available" | "unavailable" | "unsupported" | "disabled";
  readonly reasonCode: ProviderAvailabilityReason;
}

export class ProviderGenerationError extends Error {
  constructor(readonly code: "unknownProvider" | "providerNotSerializable") {
    super(code);
    this.name = "ProviderGenerationError";
  }
}

export function classifyClaudeAuth(
  result: ProbeResult,
): ProviderAuthClassification {
  try {
    const parsed = JSON.parse(result.combined) as {
      loggedIn?: unknown;
      authMethod?: unknown;
    };
    if (parsed.loggedIn === true && parsed.authMethod === "claude.ai")
      return { state: "installed_authenticated", reasonCode: "ready" };
    return {
      state: "installed_unauthenticated",
      reasonCode:
        parsed.loggedIn === true ? "unsupported_auth_mode" : "not_logged_in",
    };
  } catch {
    return {
      state: "installed_unauthenticated",
      reasonCode: "auth_status_unreadable",
    };
  }
}

export function classifyCodexAuth(
  result: ProbeResult,
): ProviderAuthClassification {
  if (result.code !== 0)
    return {
      state: "installed_unauthenticated",
      reasonCode: "auth_status_unreadable",
    };
  const normalized = result.combined.toLowerCase();
  if (normalized.includes("api key") || normalized.includes("apikey"))
    return {
      state: "installed_unauthenticated",
      reasonCode: "unsupported_auth_mode",
    };
  if (normalized.includes("chatgpt"))
    return { state: "installed_authenticated", reasonCode: "ready" };
  return {
    state: "installed_unauthenticated",
    reasonCode: "not_logged_in",
  };
}

export function validateProviderRegistry(
  descriptors: readonly {
    id: string;
    capabilities: readonly ProviderCapability[];
    adapter?: AekrAdapterDescriptor;
    apiModelProfiles?: readonly ApiModelProfileDescriptor[];
  }[],
): void {
  const ids = new Set<string>();
  for (const descriptor of descriptors) {
    if (!/^[a-z][a-z0-9_]*$/.test(descriptor.id) || ids.has(descriptor.id))
      throw new Error("invalidProviderRegistry");
    ids.add(descriptor.id);
    if (
      descriptor.capabilities.includes("aekr_adapter_serialization") &&
      (!descriptor.adapter ||
        descriptor.adapter.serialize({
          canonicalRole: "generalist",
          funding: {
            mode: "subscription_cli",
            currency: "USD",
            maxCost: "0",
            hardStop: true,
          },
        })[0] !== `kind: ${descriptor.adapter.kind}`)
    )
      throw new Error("invalidProviderSerializer");
    for (const profile of descriptor.apiModelProfiles ?? []) {
      if (
        !/^[a-z][a-z0-9._-]*$/.test(profile.id) ||
        !profile.displayName ||
        !profile.aekrContractVersion ||
        !profile.adapterProfileId
      )
        throw new Error("invalidProviderProfile");
    }
  }
}

validateProviderRegistry(PROVIDER_REGISTRY);

export const listProviderDescriptors = () => PROVIDER_REGISTRY;
export const isProviderId = (value: unknown): value is ProviderId =>
  typeof value === "string" && PROVIDER_IDS.includes(value as ProviderId);
export const getProviderDescriptor = (id: ProviderId) =>
  PROVIDER_REGISTRY.find((descriptor) => descriptor.id === id);
export const providerHasCapability = (
  descriptor: ProviderDescriptor,
  capability: ProviderCapability,
) =>
  (descriptor.capabilities as readonly ProviderCapability[]).includes(
    capability,
  );
export const isSerializableProvider = (id: ProviderId) => {
  const descriptor = getProviderDescriptor(id);
  return (
    !!descriptor &&
    providerHasCapability(descriptor, "aekr_adapter_serialization")
  );
};

export function availabilityById(
  results: unknown,
): ReadonlyMap<ProviderId, ProviderAvailabilityResult> {
  if (!Array.isArray(results)) throw new Error("invalidProviderAvailability");
  const map = new Map<ProviderId, ProviderAvailabilityResult>();
  for (const result of results) {
    if (!result || typeof result !== "object")
      throw new Error("invalidProviderAvailability");
    const candidate = result as ProviderAvailabilityResult;
    const stateReasonIsValid =
      (candidate.state === "installed_authenticated" &&
        candidate.reasonCode === "ready") ||
      (candidate.state === "not_installed" &&
        candidate.reasonCode === "cli_not_found") ||
      (candidate.state === "unsupported_host" &&
        candidate.reasonCode === "host_cannot_detect") ||
      (candidate.state === "installed_unauthenticated" &&
        [
          "not_logged_in",
          "unsupported_auth_mode",
          "auth_status_unreadable",
        ].includes(candidate.reasonCode));
    if (
      !isProviderId(candidate.providerId) ||
      ![
        "installed_authenticated",
        "installed_unauthenticated",
        "not_installed",
        "unsupported_host",
      ].includes(candidate.state) ||
      ![
        "ready",
        "cli_not_found",
        "not_logged_in",
        "unsupported_auth_mode",
        "auth_status_unreadable",
        "host_cannot_detect",
      ].includes(candidate.reasonCode) ||
      (candidate.detail !== undefined &&
        typeof candidate.detail !== "string") ||
      !stateReasonIsValid ||
      map.has(candidate.providerId)
    )
      throw new Error("invalidProviderAvailability");
    map.set(candidate.providerId, candidate);
  }
  if (map.size !== PROVIDER_REGISTRY.length)
    throw new Error("invalidProviderAvailability");
  return map;
}

export function providerEligibility(
  providerId: ProviderId,
  availability: ProviderAvailabilityResult | null,
  action: ProviderAction,
): ProviderEligibility {
  if (!isSerializableProvider(providerId))
    return {
      enabled: false,
      status: "disabled",
      reasonCode: "auth_status_unreadable",
    };
  if (action === "export") {
    if (availability?.state === "unsupported_host")
      return {
        enabled: true,
        status: "unsupported",
        reasonCode: "host_cannot_detect",
      };
    return {
      enabled: true,
      status: "available",
      reasonCode: availability?.reasonCode ?? "ready",
    };
  }
  if (availability?.state === "installed_authenticated")
    return { enabled: true, status: "available", reasonCode: "ready" };
  if (availability?.state === "unsupported_host")
    return {
      enabled: false,
      status: "unsupported",
      reasonCode: "host_cannot_detect",
    };
  return {
    enabled: false,
    status: "unavailable",
    reasonCode: availability?.reasonCode ?? "auth_status_unreadable",
  };
}

export function serializeAekrAdapter(
  descriptor: ProviderDescriptor,
  context: AekrAdapterContext,
): readonly string[] {
  if (!providerHasCapability(descriptor, "aekr_adapter_serialization"))
    throw new ProviderGenerationError("providerNotSerializable");
  return descriptor.adapter.serialize(context);
}

export const unsupportedHostAvailability = (): ProviderAvailability =>
  PROVIDER_REGISTRY.map(({ id }) => ({
    providerId: id,
    state: "unsupported_host",
    reasonCode: "host_cannot_detect",
  }));
