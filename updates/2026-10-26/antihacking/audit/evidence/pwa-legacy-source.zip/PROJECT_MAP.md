# Project Map

The project map now has two synchronized views of accreatio's architecture:

- [`accreatio-project-map.html`](accreatio-project-map.html) is a self-contained interactive viewer. Its name carries the project so a downloaded copy stays identifiable beside other AEKR project maps; the canonical JSON below keeps the standard name that agents read by. Open it directly in a browser with `file://`; it makes no network requests and needs no server, CDN, font, framework, or external asset. Its footer identifies the governed AEKR build with an accessible copy of `assets/aekr-banner.png` embedded as a local PNG data URI at generation time.
- [`project-map.json`](project-map.json) is the canonical machine-readable graph for people, scripts, and AI agents.

The map covers the desktop and browser guided questionnaire, their shared pure domain core, the renderer's local layered atmosphere (one deterministic Canvas2D star plane plus one optional owned WebGL nebula with bounded click bursts), the narrow host boundaries, generated-project outputs, the web-only Access/Pages Functions/D1 editorial path, human and AEKR Blog publishing routes, optional AEKR orchestration handoff, verification, and the explicitly unbuilt W2/W3 boundaries. It contains no edge from project data to the editorial backend and no Blog edge into Electron. The map does not change accreatio's runtime or ship inside the Electron/PWA bundle.

## Using the interactive viewer

1. Open `accreatio-project-map.html` in any modern browser.
2. Select a flow in the right-hand panel. Every node and directed edge in that ordered route is highlighted; unrelated topology is dimmed.
3. Select a node in the diagram or a numbered flow step to inspect its responsibilities and repository paths.
4. Use **Show all** to clear the active flow. The diagram also supports keyboard navigation, zoom controls, pointer panning, and `Ctrl`/`⌘` + wheel zoom.

On narrow screens the flow panel moves below the diagram and the page remains horizontally contained. Motion-sensitive settings are honored through `prefers-reduced-motion`.

## Status vocabulary

Status is encoded as text in the JSON and viewer, not by color alone:

- `current` — implemented in this repository; hosted deployment/acceptance may still be a separate release gate.
- `upstream` — real but owned by an independent repository, currently AEKR.
- `planned` — documented future boundary with no shipped implementation.
- `hold` — sketch or capability that is explicitly unauthorized today.

In particular, the earlier W1 build is live only as an Access-protected Cloudflare Pages beta and is not anonymously/publicly accessible. The `0.8.0` Blog/editorial source is current, while deployment, D1 migration/configuration, owner acceptance, and a real allowlisted AEKR service-token exercise remain release gates. Published editorial posts persist in D1; project content and integration credentials do not enter that path. The local companion remains deferred, and tenant/SaaS collaboration remains a documentation-only hold. `DECISIONS.md`, `CHANGE_CONTROL.md`, and `docs/W1_RELEASE_READINESS.md` are authoritative for authorization and live status.

## JSON contract for agents

The top-level shape is deliberately small and stable:

```json
{
  "nodes": [
    {
      "id": "pure-domain",
      "label": "Pure domain core",
      "status": "current",
      "paths": ["shared/domain.ts", "src/core.ts"],
      "responsibilities": ["Validate ProjectDefinition invariants"],
      "position": { "x": 282, "y": 506 }
    }
  ],
  "edges": [
    {
      "id": "e-ui-domain",
      "source": "renderer-ui",
      "target": "pure-domain",
      "label": "validate / preview / plan",
      "status": "current"
    }
  ],
  "flows": [
    {
      "id": "desktop-dry-run",
      "status": "current",
      "steps": [
        {
          "nodeId": "renderer-ui",
          "edgeId": "e-ui-domain",
          "action": "Build the preview and planned actions."
        },
        {
          "nodeId": "pure-domain",
          "action": "Validate invariants and return deterministic results."
        }
      ]
    }
  ]
}
```

Contract invariants:

- Node, edge, and flow IDs are globally unique across the complete map.
- Every edge references existing `source` and `target` node IDs.
- Every flow contains at least two ordered steps.
- Each non-final step names an `edgeId` whose source is that step's `nodeId` and whose target is the next step's `nodeId`.
- The final step has no `edgeId`.
- Every node has deterministic diagram coordinates plus source paths and responsibilities.

This explicit step-to-edge link is what lets an agent or the viewer resolve a complete flow without guessing between parallel or bidirectional connections.

## Maintaining the map

Edit `project-map.json`, then regenerate and verify the derived viewer:

```powershell
npm.cmd run project-map:build
npm.cmd run project-map:check
npm.cmd test
npm.cmd run test:project-map
```

`project-map:build` validates all references before embedding a safely serialized copy of the JSON and the local AEKR banner in the HTML. `project-map:check` is read-only and fails when the committed HTML differs from the canonical JSON, template, or banner asset. Unit tests independently parse the embedded copy and assert deep parity, complete flow routes, self-containment, accessible provenance, and responsive safeguards. The functional smoke opens the committed viewer through `file://`, exercises every flow and keyboard controls at four viewport sizes, and fails on network requests or browser errors.
