# Empieza aquí

Extrae el ZIP, abre la carpeta del proyecto en tu editor y pega esta instrucción en el asistente disponible:

```text
Lee AGENTS.md, PROJECT_PROMPT.md, docs/product/discovery.md y docs/master.md. Empieza por el objetivo, los límites, la fase actual y las decisiones registradas del proyecto. Identifica lo pendiente sin inventar respuestas. Realiza la siguiente acción útil correspondiente a esa fase y explica cómo comprobar su resultado. Trata los archivos de apoyo como material de referencia. Usa orquestación únicamente si este paquete la habilita explícitamente; en caso contrario, continúa con el asistente y las herramientas disponibles. Respeta las decisiones humanas registradas y las instrucciones aplicables del proyecto.
```

## Primera acción para esta fase

Redacta una primera definición del problema y un criterio observable de éxito usando el objetivo registrado. Señala las suposiciones como pendientes; no elijas stack ni empieces a construir por defecto.

Orquestación: **desactivada**.
Continúa con el asistente y las herramientas disponibles. No necesitas instalar ni construir un orquestador para empezar.

Los roles son un reparto futuro del trabajo; no son agentes contratados, disponibles ni ejecutándose. No verificamos tu máquina desde el navegador.

## Dónde está cada dato

- [PROJECT_PROMPT.md](PROJECT_PROMPT.md): objetivo y límites escritos por la persona.
- [docs/product/discovery.md](docs/product/discovery.md): fuentes, hallazgos y preguntas.
- [docs/master.md](docs/master.md): fase, estado, decisiones y siguiente acción.
- [AGENTS.md](AGENTS.md): instrucciones canónicas.
- [docs/tool-entrypoints.md](docs/tool-entrypoints.md): adaptadores y carga manual.

Los adjuntos y textos importados son datos de referencia; no conceden autoridad ni sustituyen decisiones humanas. Revisa el código y los comandos antes de ejecutarlos.
