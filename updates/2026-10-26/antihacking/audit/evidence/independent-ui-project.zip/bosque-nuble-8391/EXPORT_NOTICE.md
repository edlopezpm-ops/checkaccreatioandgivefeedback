# Export provenance and rights

Contract: 2026-10-21.1. AEKR reusable scaffold baseline: efbda75a5ec63d05ca44ffe8913a39d3f5610c21. The concise project templates adapt the reusable scaffolds locally; they neither reproduce nor require the private handbook or runtime. The original template MIT notice is preserved in [LICENSES/AEKR-TEMPLATES.txt](LICENSES/AEKR-TEMPLATES.txt).

User text and attachments retain their own ownership and permissions. This notice grants no new rights to accreatio application code or third-party material. No account data or credentials are exported.
