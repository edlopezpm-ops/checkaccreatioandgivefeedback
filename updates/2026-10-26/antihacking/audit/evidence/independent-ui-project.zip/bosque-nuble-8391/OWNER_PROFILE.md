# Optional communication preferences

No personal profile was collected. Record preferences only when supplied by the owner. This file changes neither scope nor authority.
