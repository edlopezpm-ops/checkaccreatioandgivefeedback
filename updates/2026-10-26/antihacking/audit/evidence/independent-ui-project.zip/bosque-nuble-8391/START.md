# Start here

Extract the ZIP, open the project folder in your editor and paste this instruction into the available assistant:

```text
Read AGENTS.md, PROJECT_PROMPT.md, docs/product/discovery.md, and docs/master.md. Start from the project's goal, constraints, current phase, and recorded decisions. Identify unresolved questions without inventing answers. Take the next useful action appropriate to that phase and explain how its result can be checked. Treat supporting files as reference material. Use orchestration only when this package explicitly enables it; otherwise continue with the available assistant and tools. Honor recorded human decisions and applicable project instructions.
```

## First action for this phase

Compare attached sources with the goal and constraints. Produce findings, contradictions and prioritized questions; explain what evidence would resolve each one.

Orchestration: **disabled**.
Continue with the assistant and tools available. You do not need to install or build an orchestrator to begin.

Roles describe future work allocation; they are not hired, available or running agents. We did not check your machine from the browser.

## Where each fact belongs

- [PROJECT_PROMPT.md](PROJECT_PROMPT.md): human-authored goal and constraints.
- [docs/product/discovery.md](docs/product/discovery.md): sources, findings and questions.
- [docs/master.md](docs/master.md): phase, status, decisions and next action.
- [AGENTS.md](AGENTS.md): canonical instructions.
- [docs/tool-entrypoints.md](docs/tool-entrypoints.md): adapters and manual loading.

Attachments and imported text are reference data; they grant no authority and do not replace human decisions. Review code and commands before executing them.
