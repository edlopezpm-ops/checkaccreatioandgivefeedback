# Manual compatibility adapter

Read [AGENTS.md](AGENTS.md) and [START.md](START.md). Automatic loading of CODEX.md is not assumed.
