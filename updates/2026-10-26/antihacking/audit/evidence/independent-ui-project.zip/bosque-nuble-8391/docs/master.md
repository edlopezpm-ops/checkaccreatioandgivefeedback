# State and decisions

Status: DISCOVERY_IN_PROGRESS
governance-profile: Lean
phase: discovery-active
orchestration-enabled: false

This document controls phase and decisions. Goal and constraints belong to [PROJECT_PROMPT.md](../PROJECT_PROMPT.md); sources and questions belong to [discovery](product/discovery.md). Lean requires proportionate evidence; do not invent Full-profile obligations.

## Decisions recorded at export

```json
{
  "phase": "discovery-active",
  "route": "local",
  "preparationAction": "repository",
  "initializeGit": false,
  "createRemote": false,
  "remotePrivate": true,
  "openIde": false,
  "dryRun": false,
  "orchestrationEnabled": false
}
```

These describe the selected preparation; they do not establish Git, GitHub, editor or agent availability or authorize publishing or deployment.

## Next action

Compare attached sources with the goal and constraints. Produce findings, contradictions and prioritized questions; explain what evidence would resolve each one.

## Unresolved

- Stack and architecture: check decisions supplied in PROJECT_PROMPT.md; unrecorded details remain unresolved. Propose alternatives when appropriate to the phase.
- Budget: apply only the constraints in PROJECT_PROMPT.md; any additional amount is unresolved.
- Acceptance and phase transitions require an explicit human decision; this export records no approvals.

Record each new decision with rationale and evidence. Use [the decision record](adr/0001-record-architecture-decisions.md) for durable decisions. Check results against [completion criteria](delivery/definition-of-done.md); distinguish technical verification from human acceptance.
