# Focused review

Read [master](../master.md), [objective](../../PROJECT_PROMPT.md) and
[discovery](../product/discovery.md). Review the bounded increment for fidelity,
missing decisions, unsafe behavior and evidence supporting each claim.
Provide reproducible conditions, evidence and impact. Label unconfirmed concerns.
Independent review needs a separate context; record self-review honestly when
that is all that is available. A verdict grants no approval or phase transition.
