# Proportionate completion criteria

Subordinate to [master](../master.md). Apply criteria for the current phase:
discovery has traceable findings, explicit unknowns and a proposed next action;
design has boundaries, alternatives and acceptance criteria; implementation
has relevant verification actually run, observed results and affected docs.
Do not require a build from a discovery task. Record what changed, why, how it
was checked and unresolved decisions. Technical checks do not establish human
acceptance, deployment, security certification or a phase transition.
