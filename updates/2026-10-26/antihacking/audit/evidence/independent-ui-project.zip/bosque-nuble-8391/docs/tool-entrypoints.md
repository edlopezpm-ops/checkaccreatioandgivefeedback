# Tool entry points

[AGENTS.md](../AGENTS.md) is canonical. [CLAUDE.md](../CLAUDE.md) points there
for tools using that filename. [CODEX.md](../CODEX.md) is a manual compatibility
pointer; automatic loading is not assumed. Adapters grant no permissions.
Open the extracted project folder as the assistant's working directory and
paste the instruction in [START.md](../START.md). Ask it to name the four
documents read and take the phase-appropriate action. If your tool does not
discover an adapter, load AGENTS and the named documents explicitly. No IDE,
AI account, paid service or machine capability was verified by this export.
