# Decision record

Status: PENDING — no separate architecture decision record exists yet.

First check decisions already supplied in PROJECT_PROMPT.md. Record a durable
decision after it is made: date, decision owner, context,
alternatives, selected option, rationale, consequences and evidence. Update
[master](../master.md). Do not invent stack, budget or approvals to fill a template.
