# Project instructions

Read and follow [AGENTS.md](AGENTS.md), the canonical project instructions. Begin with [START.md](START.md). This adapter adds no permissions.
