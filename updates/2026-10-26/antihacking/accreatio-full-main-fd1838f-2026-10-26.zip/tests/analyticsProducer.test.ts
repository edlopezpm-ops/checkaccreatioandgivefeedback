import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { handleAnalyticsProducer } from "../functions/_lib/analyticsProducer";
import {
  ANALYTICS_NOTICE_VERSION,
  parseAnalyticsEvent,
  parseSourceConfiguration,
} from "../shared/analyticsProducer";
const now = Date.now();
const actualCentralConfiguration = JSON.parse(
  readFileSync(
    new URL("./fixtures/analytics-source-v1.json", import.meta.url),
    "utf8",
  ),
);
test("actual central configuration contract admits production mode and fails closed for missing, synthetic or unknown modes", () => {
  const at = Date.parse(actualCentralConfiguration.issued_at);
  assert.ok(parseSourceConfiguration(actualCentralConfiguration, at));
  for (const mode of [undefined, "synthetic", "demo", "preview", true]) {
    assert.equal(
      parseSourceConfiguration({ ...actualCentralConfiguration, mode }, at),
      null,
    );
  }
});
const config = () => ({
  schema_version: 1,
  source_id: "accreatio-public-production",
  product: "accreatio",
  environment: "production",
  mode: "production",
  version: 2,
  issued_at: new Date(now).toISOString(),
  expires_at: new Date(now + 300000).toISOString(),
  enabled: true,
  events: ["public_product_viewed", "commercial_interest_selected"],
  fields: ["category", "offer_id"],
  purposes: ["aekr_marketing", "audience_licensing"],
  retention_days: 30,
  destinations: ["partner-a-demo"],
  restriction_reason: null,
});
const event = () => ({
  event_id: crypto.randomUUID(),
  schema_version: 1,
  occurred_at: new Date(now).toISOString(),
  purpose: "aekr_marketing",
  permission_ref: "10000000-0000-4000-8000-000000000001",
  source_configuration_version: 2,
  event: "public_product_viewed",
  category: "development",
});
function fixture() {
  const calls: {
    path: string;
    body: Record<string, unknown> | undefined;
    auth: string | null;
  }[] = [];
  let activeConfig = config();
  let preferenceStatus: string | null = null;
  let receiptExpiry: unknown = new Date(now + 30 * 86400000).toISOString();
  const permissions = new Map<string, string>();
  const fetcher = async (
    input: Parameters<typeof fetch>[0],
    init?: RequestInit,
  ) => {
    const url = new URL(String(input));
    const body = init?.body ? JSON.parse(String(init.body)) : undefined;
    calls.push({
      path: url.pathname,
      body,
      auth: new Headers(init?.headers).get("Authorization"),
    });
    if (url.pathname.endsWith("/config")) return Response.json(activeConfig);
    if (url.pathname.endsWith("/preferences")) {
      permissions.set(
        String(body.permission_ref ?? "10000000-0000-4000-8000-000000000001"),
        String(body.subject_ref),
      );
      return Response.json({
        permission_ref: "10000000-0000-4000-8000-000000000001",
        status: preferenceStatus ?? body.status,
        expires_at: receiptExpiry,
        granted_at:
          (preferenceStatus ?? body.status) === "granted"
            ? new Date(now).toISOString()
            : null,
        withdrawn_at:
          (preferenceStatus ?? body.status) === "granted"
            ? null
            : new Date(now).toISOString(),
      });
    }
    if (url.pathname.endsWith("/events")) {
      if (permissions.get(body.permission_ref) !== body.subject_ref)
        return Response.json({ error: "different-subject" }, { status: 403 });
      return Response.json({ accepted: true });
    }
    return Response.json({ acknowledged: true });
  };
  const call = (
    action: string,
    body?: unknown,
    overrides: {
      capability?: string;
      headers?: Record<string, string>;
      origin?: string;
      secret?: string;
    } = {},
  ) => {
    const origin = overrides.origin ?? "https://accreatio.com";
    const request = new Request(`${origin}/api/collection/${action}`, {
      method: body === undefined ? "GET" : "POST",
      headers: {
        Origin: origin,
        "Content-Type": "application/json",
        Authorization: `Bearer ${overrides.capability ?? "b".repeat(64)}`,
        ...overrides.headers,
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    return handleAnalyticsProducer(
      {
        request,
        env: {
          COLLECTION_SOURCE_TOKEN:
            overrides.secret ?? "source-credential_".repeat(3),
        },
      },
      action,
      { fetch: fetcher as typeof fetch, now: () => now },
    );
  };
  const grant = (purpose = "aekr_marketing") =>
    call("preference", {
      purpose,
      status: "granted",
      notice_version: ANALYTICS_NOTICE_VERSION,
      categories: ["development"],
      recipients: ["partner-a-demo"],
      gpc: false,
    });
  return {
    call,
    calls,
    grant,
    setPreferenceStatus: (status: string) => {
      preferenceStatus = status;
    },
    setReceiptExpiry: (expiry: unknown) => {
      receiptExpiry = expiry;
    },
    setConfig: (change: Partial<ReturnType<typeof config>>) => {
      activeConfig = { ...activeConfig, ...change };
    },
  };
}
test("producer returns the actual central preference decision, never the submitted grant", async () => {
  const h = fixture();
  h.setPreferenceStatus("denied");
  const response = await h.grant();
  assert.equal(response.status, 200);
  assert.equal((await response.json()).status, "denied");
  h.setPreferenceStatus("unknown");
  assert.equal((await h.grant()).status, 503);
});
test("producer preserves the actual shorter receipt expiry and rejects malformed or missing expiry", async () => {
  const h = fixture();
  const shorter = new Date(now + 30000).toISOString();
  h.setReceiptExpiry(shorter);
  assert.equal((await (await h.grant()).json()).expires_at, shorter);
  for (const expiry of [
    undefined,
    null,
    "not-a-date",
    new Date(now - 1).toISOString(),
  ]) {
    h.setReceiptExpiry(expiry);
    assert.equal((await h.grant()).status, 503);
  }
});
test("source configuration acknowledges only the validated applied source and never exposes credentials", async () => {
  const h = fixture();
  const response = await h.call("config");
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), config());
  assert.deepEqual(
    h.calls.map((c) => c.path),
    ["/api/collection/config", "/api/collection/ack"],
  );
  assert.deepEqual(h.calls[1].body, { source_configuration_version: 2 });
  assert.ok(
    h.calls.every((c) => c.auth?.startsWith("Bearer source-credential_")),
  );
  assert.equal(
    (
      await h.call("config", undefined, {
        origin: "https://preview.accreatio.pages.dev",
      })
    ).status,
    503,
  );
  h.setConfig({ expires_at: new Date(now - 1).toISOString() });
  assert.equal((await h.call("config")).status, 503);
  h.setConfig({ expires_at: new Date(now + 600000).toISOString() });
  assert.equal((await h.call("config")).status, 503);
  assert.equal(
    (await h.call("config", undefined, { secret: "invalid" })).status,
    503,
  );
});
test("browser capability binds server-derived subject and permission; caller trust labels and private fields stop before transmission", async () => {
  const h = fixture();
  assert.equal((await h.grant()).status, 200);
  const subject = h.calls.find((c) => c.path.endsWith("preferences"))?.body
    ?.subject_ref;
  assert.match(String(subject), /^[0-9a-f]{64}$/);
  assert.notEqual(subject, "b".repeat(64));
  assert.equal((await h.call("event", event())).status, 200);
  assert.equal(
    (
      await h.call("event", event(), {
        secret: "rotated-source-credential_".repeat(3),
      })
    ).status,
    200,
    "credential rotation preserves subject rights",
  );
  assert.equal(
    (await h.call("event", event(), { capability: "c".repeat(64) })).status,
    403,
  );
  for (const field of [
    "subject_ref",
    "source_id",
    "consent",
    "url",
    "query",
    "email",
    "project",
    "provenance_ref",
    "gpc",
  ]) {
    const before = h.calls.length;
    assert.equal(
      (await h.call("event", { ...event(), [field]: "private-text" })).status,
      400,
    );
    assert.equal(
      h.calls.length,
      before,
      `${field} must stop before outbound I/O`,
    );
  }
  assert.equal(
    (
      await h.call("event", event(), {
        headers: { Origin: "https://other.example" },
      })
    ).status,
    403,
  );
  assert.equal(
    (await h.call("event", event(), { capability: "not-a-capability" })).status,
    401,
  );
});
test("current backend pause/version/fields enforce collection; withdrawal and GPC remain effective while paused", async () => {
  const h = fixture();
  await h.grant();
  h.setConfig({ enabled: false });
  assert.equal((await h.call("event", event())).status, 403);
  const before = h.calls.filter((c) => c.path.endsWith("events")).length;
  assert.equal(
    (
      await h.call("preference", {
        purpose: "aekr_marketing",
        status: "withdrawn",
        notice_version: ANALYTICS_NOTICE_VERSION,
        categories: [],
        recipients: [],
        gpc: false,
      })
    ).status,
    200,
  );
  assert.equal(
    (
      await h.call(
        "event",
        { ...event(), purpose: "audience_licensing" },
        { headers: { "Sec-GPC": "1" } },
      )
    ).status,
    403,
  );
  assert.equal(h.calls.filter((c) => c.path.endsWith("events")).length, before);
  assert.equal(h.calls.at(-1)?.body?.gpc, true);
  assert.equal(h.calls.at(-1)?.body?.status, "withdrawn");
  h.setConfig({ enabled: true, version: 3 });
  assert.equal((await h.call("event", event())).status, 403);
  h.setConfig({ version: 2, fields: [] });
  assert.equal((await h.call("event", event())).status, 403);
  h.setConfig({ fields: ["category"] });
  assert.equal(
    (await h.call("event", { ...event(), event: "payment_confirmed" })).status,
    400,
  );
});
test("restricted data and unrestricted schema additions cannot enter the public signal contract", () => {
  assert.equal(
    parseAnalyticsEvent({
      event: "public_product_viewed",
      category: "gmail-derived",
    }),
    null,
  );
  assert.equal(
    parseAnalyticsEvent({
      event: "public_product_viewed",
      category: "development",
      payload: "private code",
    }),
    null,
  );
  assert.equal(
    parseSourceConfiguration({ ...config(), secret: "private" }),
    null,
  );
  assert.equal(
    parseSourceConfiguration({ ...config(), product: "marker" }),
    null,
  );
  assert.equal(
    parseSourceConfiguration({ ...config(), environment: "preview" }),
    null,
  );
});
