import assert from "node:assert/strict";
import test from "node:test";
import {
  commercialChoices,
  recordPublicSignal,
  setCommercialChoice,
} from "../src/account/analyticsProducer";

test("a late preference retry retains central expiry and malformed/missing receipts never activate local permission", async (t) => {
  let now = Date.now();
  const initialNow = now;
  const centralExpiry = initialNow + 30 * 86400000;
  const values = new Map<string, string>();
  const prior = Object.getOwnPropertyDescriptor(globalThis, "localStorage");
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: {
      get length() {
        return values.size;
      },
      key: (index: number) => [...values.keys()][index] ?? null,
      getItem: (key: string) => values.get(key) ?? null,
      setItem: (key: string, value: string) => void values.set(key, value),
      removeItem: (key: string) => void values.delete(key),
    },
  });
  t.after(() => {
    if (prior) Object.defineProperty(globalThis, "localStorage", prior);
    else Reflect.deleteProperty(globalThis, "localStorage");
  });
  t.mock.method(Date, "now", () => now);
  let expiry: unknown = new Date(centralExpiry).toISOString();
  let missing = false;
  let requests = 0;
  t.mock.method(globalThis, "fetch", async (input, init) => {
    requests++;
    if (String(input).endsWith("config"))
      return Response.json({
        schema_version: 1,
        source_id: "accreatio-public-production",
        product: "accreatio",
        environment: "production",
        mode: "production",
        version: 1,
        issued_at: new Date(now).toISOString(),
        expires_at: new Date(now + 300000).toISOString(),
        enabled: true,
        events: ["public_product_viewed"],
        fields: ["category"],
        purposes: ["aekr_marketing"],
        retention_days: 30,
        destinations: [],
        restriction_reason: null,
      });
    const body = JSON.parse(String(init?.body));
    return Response.json({
      permission_ref: "10000000-0000-4000-8000-000000000001",
      status: body.status,
      ...(!missing ? { expires_at: expiry } : {}),
      granted_at: new Date(initialNow).toISOString(),
      withdrawn_at: null,
    });
  });
  await setCommercialChoice("aekr_marketing", true);
  assert.equal(commercialChoices().aekr_marketing?.expires_at, centralExpiry);
  now = centralExpiry - 2000;
  await setCommercialChoice("aekr_marketing", true);
  assert.equal(
    commercialChoices().aekr_marketing?.expires_at,
    centralExpiry,
    "retry cannot renew permission locally",
  );
  now = centralExpiry + 1;
  const before = requests;
  assert.equal(
    await recordPublicSignal("aekr_marketing", {
      event: "public_product_viewed",
      category: "development",
    }),
    false,
  );
  assert.equal(
    requests,
    before,
    "expired permission stops before collection/configuration I/O",
  );
  for (const malformed of [
    "not-a-date",
    null,
    123,
    new Date(now - 1).toISOString(),
    new Date(now + 31 * 86400000).toISOString(),
  ]) {
    expiry = malformed;
    await assert.rejects(setCommercialChoice("aekr_marketing", true));
    assert.notEqual(commercialChoices().aekr_marketing?.status, "granted");
  }
  missing = true;
  await assert.rejects(setCommercialChoice("aekr_marketing", true));
});
