import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import test from "node:test";
import {
  ABUSE_ALLOWED_SQL,
  AbuseError,
  abuseErrorResponse,
  abuseNetworkKey,
  enforceAbuse,
  getAbuseAccountStatus,
  maintainAbuse,
  type AbusePrincipal,
  type AbuseRoute,
} from "../functions/_lib/abuse";
import { ApiError } from "../functions/_lib/http";
import type { AccountDatabase } from "../functions/_lib/accounts";
import type {
  BlogPreparedStatement,
  DatabaseValue,
} from "../functions/_lib/platform";

class Store implements AccountDatabase {
  sqlite = new DatabaseSync(":memory:");
  now = Date.parse("2026-10-22T12:00:05Z");
  fail = false;
  constructor() {
    this.sqlite.function("unixepoch", () => this.now / 1000);
    this.sqlite.exec(`PRAGMA foreign_keys=ON;
      CREATE TABLE accounts(id TEXT PRIMARY KEY,security_version INTEGER NOT NULL DEFAULT 0,deleted_at INTEGER);
      CREATE TABLE account_sessions(token_hash TEXT PRIMARY KEY,account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,expires_at INTEGER NOT NULL);
      CREATE TABLE account_session_metadata(token_hash TEXT PRIMARY KEY REFERENCES account_sessions(token_hash) ON DELETE CASCADE,security_version INTEGER NOT NULL,rights_only INTEGER NOT NULL DEFAULT 0);`);
    this.sqlite.exec(
      readFileSync(
        new URL("../migrations-auth/0007_abuse_guard.sql", import.meta.url),
        "utf8",
      ),
    );
  }
  prepare(query: string) {
    return new Statement(this, query);
  }
  async batch(statements: Statement[]) {
    if (this.fail) throw new Error("synthetic private database diagnostic");
    this.sqlite.exec("BEGIN");
    try {
      const result = statements.map((statement) => ({
        success: true,
        results: statement.read(),
      }));
      this.sqlite.exec("COMMIT");
      return result;
    } catch (error) {
      this.sqlite.exec("ROLLBACK");
      throw error;
    }
  }
}
class Statement implements BlogPreparedStatement {
  values: DatabaseValue[] = [];
  constructor(
    private store: Store,
    private query: string,
  ) {}
  bind(...values: DatabaseValue[]) {
    this.values = values;
    return this;
  }
  read() {
    if (this.store.fail)
      throw new Error("synthetic private database diagnostic");
    return this.store.sqlite.prepare(this.query).all(...this.values);
  }
  async first<T>() {
    return (this.read()[0] as T) ?? null;
  }
  async all<T>() {
    return { success: true, results: this.read() as T[] };
  }
  async run() {
    this.read();
    return { success: true };
  }
}
const secret = "3".repeat(64);
const request = (ip: string | null = "192.0.2.1") =>
  new Request("https://accreatio.test/api/account/session", {
    headers: ip ? { "CF-Connecting-IP": ip } : {},
  });
function fixture() {
  const db = new Store();
  let sequence = 0;
  function principal(
    accountId = "account-1",
    rightsOnly = false,
  ): AbusePrincipal {
    db.sqlite
      .prepare("INSERT OR IGNORE INTO accounts(id) VALUES(?)")
      .run(accountId);
    const version = db.sqlite
      .prepare("SELECT security_version FROM accounts WHERE id=?")
      .get(accountId)!.security_version as number;
    const tokenHash = (++sequence).toString(16).padStart(64, "0");
    db.sqlite
      .prepare("INSERT INTO account_sessions VALUES(?,?,?)")
      .run(tokenHash, accountId, db.now + 86_400_000);
    db.sqlite
      .prepare("INSERT INTO account_session_metadata VALUES(?,?,?)")
      .run(tokenHash, version, rightsOnly ? 1 : 0);
    return { accountId, tokenHash };
  }
  const call = (
    route: AbuseRoute,
    owner?: AbusePrincipal,
    sanctionEligible = false,
    ip: string | null = "192.0.2.1",
    networkChecked = false,
  ) =>
    enforceAbuse({
      db,
      secret,
      request: request(ip),
      route,
      principal: owner,
      sanctionEligible,
      networkChecked,
    });
  return { db, principal, call };
}

test("network keys ignore caller forwarding, canonicalize mapped IP and bound rotating IPv6 to /64", async () => {
  assert.equal(
    await abuseNetworkKey(
      secret,
      new Request("https://accreatio.test", {
        headers: { "X-Forwarded-For": "192.0.2.1" },
      }),
    ),
    null,
  );
  assert.equal(
    await abuseNetworkKey(secret, request("::ffff:192.0.2.1")),
    await abuseNetworkKey(secret, request("192.0.2.1")),
  );
  assert.equal(
    await abuseNetworkKey(secret, request("2001:db8:1:2::1")),
    await abuseNetworkKey(secret, request("2001:0db8:0001:0002::abcd")),
  );
  assert.notEqual(
    await abuseNetworkKey(secret, request("2001:db8:1:2::1")),
    await abuseNetworkKey(secret, request("2001:db8:1:3::1")),
  );
  assert.equal(
    await abuseNetworkKey(secret, request("2a06:98c0:3600::103")),
    null,
  );
  assert.equal(
    await abuseNetworkKey(secret, request("192.0.2.1, 192.0.2.2")),
    null,
  );
  const pseudo = new Request("https://accreatio.test", {
    headers: {
      "CF-Connecting-IP": "240.0.0.1",
      "CF-Connecting-IPv6": "2001:db8:1:2::1",
    },
  });
  assert.equal(
    await abuseNetworkKey(secret, pseudo),
    await abuseNetworkKey(secret, request("2001:db8:1:2::1")),
  );
});

test("concurrent valid requests atomically reserve every dimension and denials do not extend blocks", async () => {
  const h = fixture(),
    owner = h.principal();
  const results = await Promise.allSettled(
    Array.from({ length: 120 }, () => h.call("account-read", owner)),
  );
  assert.equal(
    results.filter((value) => value.status === "fulfilled").length,
    90,
  );
  const denied = results.filter((value) => value.status === "rejected");
  assert.equal(denied.length, 30);
  assert.ok(
    denied.every(
      (value) =>
        value.status === "rejected" && value.reason instanceof AbuseError,
    ),
  );
  assert.deepEqual(
    denied
      .map((value) => (value.reason as AbuseError).retryAfter)
      .sort((left, right) => left - right),
    [...Array<number>(29).fill(30), 55],
    "one initial minute-window denial and 29 cooldown denials, independent of request order",
  );
  const buckets = h.db.sqlite
    .prepare("SELECT * FROM account_abuse_buckets ORDER BY scope_kind")
    .all();
  assert.equal(buckets.length, 3);
  assert.ok(buckets.every((row) => row.request_count === 90));
  const before = h.db.sqlite
    .prepare(
      "SELECT blocked_until,strikes,last_excess_at FROM account_abuse_buckets WHERE scope_kind='session'",
    )
    .get();
  h.db.now += 10_000;
  await assert.rejects(h.call("account-read", owner), AbuseError);
  assert.deepEqual(
    h.db.sqlite
      .prepare(
        "SELECT blocked_until,strikes,last_excess_at FROM account_abuse_buckets WHERE scope_kind='session'",
      )
      .get(),
    before,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_abuse_state").get()!
      .n,
    0,
  );
  const error = denied.find(
    (value) => (value.reason as AbuseError).retryAfter === 55,
  );
  if (!error || error.status !== "rejected")
    throw new Error("missing initial minute-window denial");
  const response = abuseErrorResponse(error.reason)!;
  assert.equal(response.status, 429);
  assert.equal(response.headers.get("Retry-After"), "55");
  assert.equal((await response.json()).error.retryAfter, 55);
  assert.equal(response.headers.get("Cache-Control"), "no-store");
});

test("middleware charging is not repeated by authenticated guard and missing IP never creates a common ban", async () => {
  const h = fixture(),
    owner = h.principal();
  await h.call("account-read");
  await h.call("account-read", owner, false, "192.0.2.1", true);
  assert.equal(
    h.db.sqlite
      .prepare(
        "SELECT request_count FROM account_abuse_buckets WHERE scope_kind='network'",
      )
      .get()!.request_count,
    1,
  );
  await h.call("account-read", owner, false, null);
  await h.call("rights", owner, false, null);
  await assert.rejects(
    h.call("auth-start", undefined, false, null),
    (error: unknown) => error instanceof ApiError && error.status === 503,
  );
  assert.ok(
    h.db.sqlite
      .prepare("SELECT scope_key FROM account_abuse_buckets")
      .all()
      .every((row) => !String(row.scope_key).includes("unavailable")),
  );
});

test("fresh attributable episodes crossing the old state expiry still suspend within their rolling window", async () => {
  const h = fixture();
  const began = h.db.now;
  async function episode(owner: AbusePrincipal) {
    for (let i = 0; i < 8; i++) await h.call("export-authorize", owner, true);
    await assert.rejects(h.call("export-authorize", owner, true), AbuseError);
  }
  await episode(h.principal());
  h.db.now = began + 172_740_000;
  const owner = h.principal();
  await episode(owner);
  assert.equal(
    h.db.sqlite.prepare("SELECT expires_at FROM account_abuse_state").get()!
      .expires_at,
    h.db.now + 172_800_000,
  );
  h.db.now += 120_000;
  await episode(owner);
  assert.equal(
    h.db.sqlite.prepare("SELECT excess_count FROM account_abuse_state").get()!
      .excess_count,
    2,
  );
  h.db.now += 120_000;
  await episode(owner);
  const state = h.db.sqlite.prepare("SELECT * FROM account_abuse_state").get()!;
  assert.equal(state.level, 1);
  assert.equal(state.suspended_until, h.db.now + 600_000);
});

test("network-only excess cannot sanction a signed-in victim sharing that network", async () => {
  const h = fixture(),
    owner = h.principal();
  await Promise.all(Array.from({ length: 20 }, () => h.call("auth-start")));
  await assert.rejects(h.call("auth-start", owner, true), AbuseError);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_abuse_state").get()!
      .n,
    0,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
    1,
  );
});

test("an active cooldown in any dimension cannot produce strikes or account episodes in another dimension", async () => {
  const h = fixture(),
    owner = h.principal();
  for (let i = 0; i < 90; i++) await h.call("account-read", owner);
  h.db.sqlite
    .prepare(
      "UPDATE account_abuse_buckets SET request_count=120,last_excess_at=? WHERE scope_kind='account'",
    )
    .run(h.db.now - 120000);
  h.db.sqlite
    .prepare(
      "UPDATE account_abuse_buckets SET blocked_until=?,last_excess_at=?,strikes=5 WHERE scope_kind='session'",
    )
    .run(h.db.now + 900000, h.db.now - 120000);
  const rows = () =>
    h.db.sqlite
      .prepare("SELECT * FROM account_abuse_buckets ORDER BY scope_key")
      .all();
  const before = rows();
  await assert.rejects(h.call("account-read", owner, true), AbuseError);
  assert.deepEqual(rows(), before);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_abuse_state").get()!
      .n,
    0,
  );
});

test("three attributable episodes suspend for 10m then 1h then 24h and revoke full sessions only once", async () => {
  const h = fixture();
  async function episodes(expectedLevel: number, expectedDuration: number) {
    const owner = h.principal();
    const rights = h.principal("account-1", true);
    for (let episode = 0; episode < 3; episode++) {
      await Promise.all(
        Array.from({ length: 8 }, () =>
          h.call("export-authorize", owner, true),
        ),
      );
      await assert.rejects(h.call("export-authorize", owner, true), AbuseError);
      if (episode < 2) h.db.now += 60_000;
    }
    const state = h.db.sqlite
      .prepare("SELECT * FROM account_abuse_state")
      .get()!;
    assert.equal(state.level, expectedLevel);
    assert.equal(state.excess_count, 0);
    assert.equal(state.suspended_until, h.db.now + expectedDuration);
    assert.equal(state.recurrence_until, h.db.now + 172_800_000);
    assert.equal(state.revision, expectedLevel);
    assert.equal(
      h.db.sqlite.prepare("SELECT security_version FROM accounts").get()!
        .security_version,
      expectedLevel,
    );
    assert.equal(
      h.db.sqlite
        .prepare(
          "SELECT COUNT(*) AS n FROM account_sessions WHERE token_hash=?",
        )
        .get(owner.tokenHash)!.n,
      0,
    );
    assert.equal(
      h.db.sqlite
        .prepare(
          "SELECT COUNT(*) AS n FROM account_sessions WHERE token_hash=?",
        )
        .get(rights.tokenHash)!.n,
      1,
    );
    const before = { ...state };
    await assert.rejects(
      h.call("export-authorize", owner, true),
      (error: unknown) => error instanceof ApiError && error.status === 401,
    );
    assert.deepEqual(
      { ...h.db.sqlite.prepare("SELECT * FROM account_abuse_state").get()! },
      before,
    );
    const status = await getAbuseAccountStatus(h.db, "account-1");
    assert.deepEqual(status, {
      suspended: true,
      suspendedUntil: new Date(h.db.now + expectedDuration).toISOString(),
    });
    const newRights = h.principal("account-1", true);
    await h.call("rights", newRights, true);
    await h.call("callback");
    assert.deepEqual(
      { ...h.db.sqlite.prepare("SELECT * FROM account_abuse_state").get()! },
      before,
    );
    assert.equal(
      h.db.sqlite
        .prepare(
          `SELECT COUNT(*) AS n FROM accounts a WHERE ${ABUSE_ALLOWED_SQL("a.id")}`,
        )
        .get()!.n,
      0,
    );
    h.db.now += expectedDuration + 60_000;
    return state;
  }
  await episodes(1, 600_000);
  await episodes(2, 3_600_000);
  await episodes(3, 86_400_000);
  h.db.now += 172_800_000;
  await maintainAbuse(h.db);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_abuse_state").get()!
      .n,
    0,
  );
  assert.deepEqual(await getAbuseAccountStatus(h.db, "account-1"), {
    suspended: false,
    suspendedUntil: null,
  });
});

test("invalid, expired, rights-only and business-ineligible calls never create account episodes", async () => {
  const h = fixture(),
    owner = h.principal(),
    rights = h.principal("account-1", true);
  await assert.rejects(
    h.call("account-read", { ...owner, tokenHash: "f".repeat(64) }, true),
    (error: unknown) => error instanceof ApiError && error.status === 401,
  );
  await assert.rejects(
    h.call("account-read", rights, true),
    (error: unknown) => error instanceof ApiError && error.status === 401,
  );
  h.db.sqlite
    .prepare("UPDATE account_sessions SET expires_at=? WHERE token_hash=?")
    .run(h.db.now, owner.tokenHash);
  await assert.rejects(
    h.call("account-read", owner, true),
    (error: unknown) => error instanceof ApiError && error.status === 401,
  );
  const current = h.principal();
  for (let episode = 0; episode < 4; episode++) {
    await Promise.all(
      Array.from({ length: 8 }, () => h.call("export-authorize", current)),
    );
    await assert.rejects(h.call("export-authorize", current), AbuseError);
    h.db.now += 960_000;
  }
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_abuse_state").get()!
      .n,
    0,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT security_version FROM accounts").get()!
      .security_version,
    0,
  );
});

test("capacity is bounded and reserved rights capacity remains available", async () => {
  const h = fixture(),
    owner = h.principal();
  h.db.sqlite
    .exec(`WITH RECURSIVE n(value) AS(VALUES(1) UNION ALL SELECT value+1 FROM n WHERE value<7680)
    INSERT INTO account_abuse_buckets(scope_key,scope_kind,route_class,window_start,request_count,expires_at)
    SELECT 'fixture-'||value,'account','account-read',0,0,${h.db.now + 3_600_000} FROM n;`);
  await assert.rejects(
    h.call("account-read", owner),
    (error: unknown) => error instanceof ApiError && error.status === 503,
  );
  await h.call("rights", owner);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_abuse_buckets")
      .get()!.n,
    7682,
  );
  h.db.now += 3_600_001;
  await maintainAbuse(h.db);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_abuse_buckets")
      .get()!.n,
    7182,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    1,
  );
});

test("state cascades on account deletion, SQL predicates reject caller text and database failures fail closed", async () => {
  const h = fixture(),
    owner = h.principal();
  for (let i = 0; i < 8; i++) await h.call("export-authorize", owner, true);
  await assert.rejects(h.call("export-authorize", owner, true), AbuseError);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_abuse_state").get()!
      .n,
    1,
  );
  h.db.sqlite.prepare("DELETE FROM accounts WHERE id=?").run(owner.accountId);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_abuse_state").get()!
      .n,
    0,
  );
  assert.throws(() =>
    ABUSE_ALLOWED_SQL("accounts.id); DROP TABLE accounts;--"),
  );
  h.db.fail = true;
  await assert.rejects(
    h.call("public-read"),
    (error: unknown) =>
      error instanceof ApiError &&
      error.status === 503 &&
      !error.publicMessage.includes("private"),
  );
});

test("a failed dimension write rolls back every bucket reservation", async () => {
  const h = fixture();
  const owner = h.principal();
  h.db.sqlite
    .exec(`CREATE TRIGGER reject_fixture_account_bucket BEFORE INSERT ON account_abuse_buckets
    WHEN NEW.scope_kind='account' BEGIN SELECT RAISE(ABORT,'synthetic fixture'); END;`);
  await assert.rejects(
    h.call("account-read", owner, true),
    (error: unknown) => error instanceof ApiError && error.status === 503,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_abuse_buckets")
      .get()!.n,
    0,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_abuse_state").get()!
      .n,
    0,
  );
  h.db.sqlite.exec("DROP TRIGGER reject_fixture_account_bucket");
  await h.call("account-read", owner, true);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_abuse_buckets")
      .get()!.n,
    3,
  );
});

test("requests inside an existing long cooldown never become new account episodes", async () => {
  const h = fixture();
  const owner = h.principal();
  for (let index = 0; index < 90; index++) await h.call("account-read", owner);
  await assert.rejects(h.call("account-read", owner), AbuseError);
  h.db.sqlite
    .prepare(
      "UPDATE account_abuse_buckets SET blocked_until=? WHERE scope_kind='session'",
    )
    .run(h.db.now + 900_000);
  h.db.now += 120_000;
  const before = h.db.sqlite
    .prepare(
      "SELECT blocked_until,strikes,last_excess_at FROM account_abuse_buckets WHERE scope_kind='session'",
    )
    .get();
  await assert.rejects(h.call("account-read", owner, true), AbuseError);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_abuse_state").get()!
      .n,
    0,
  );
  assert.deepEqual(
    h.db.sqlite
      .prepare(
        "SELECT blocked_until,strikes,last_excess_at FROM account_abuse_buckets WHERE scope_kind='session'",
      )
      .get(),
    before,
  );
});

test("suspension, security-version increment and full-session revocation roll back together", async () => {
  const h = fixture();
  const owner = h.principal();
  for (let episode = 0; episode < 2; episode++) {
    for (let requestIndex = 0; requestIndex < 8; requestIndex++)
      await h.call("export-authorize", owner, true);
    await assert.rejects(h.call("export-authorize", owner, true), AbuseError);
    h.db.now += 60_000;
  }
  for (let requestIndex = 0; requestIndex < 8; requestIndex++)
    await h.call("export-authorize", owner, true);
  h.db.sqlite
    .exec(`CREATE TRIGGER reject_fixture_suspension BEFORE UPDATE OF security_version ON accounts
    BEGIN SELECT RAISE(ABORT,'synthetic fixture'); END;`);
  await assert.rejects(
    h.call("export-authorize", owner, true),
    (error: unknown) => error instanceof ApiError && error.status === 503,
  );
  const state = h.db.sqlite.prepare("SELECT * FROM account_abuse_state").get()!;
  assert.equal(state.level, 0);
  assert.equal(state.excess_count, 2);
  assert.equal(state.revision, 0);
  assert.equal(
    h.db.sqlite.prepare("SELECT security_version FROM accounts").get()!
      .security_version,
    0,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
    1,
  );
  h.db.sqlite.exec("DROP TRIGGER reject_fixture_suspension");
  await assert.rejects(h.call("export-authorize", owner, true), AbuseError);
  assert.equal(
    h.db.sqlite.prepare("SELECT revision FROM account_abuse_state").get()!
      .revision,
    1,
  );
});

test("three-episode detection uses a rolling ten-minute window across an older first episode", async () => {
  const h = fixture();
  const owner = h.principal();
  const start = h.db.now;
  for (const offset of [0, 9 * 60_000, 11 * 60_000, 13 * 60_000]) {
    h.db.now = start + offset;
    for (let index = 0; index < 8; index++)
      await h.call("export-authorize", owner, true);
    await assert.rejects(h.call("export-authorize", owner, true), AbuseError);
  }
  const state = h.db.sqlite.prepare("SELECT * FROM account_abuse_state").get()!;
  assert.equal(state.level, 1);
  assert.equal(state.suspended_until, h.db.now + 600_000);
});
