import assert from "node:assert/strict";
import test from "node:test";
import { policyDocument } from "../src/legal";

test("policy documents resolve only own canonical Terms, Privacy and Cookies with the chosen language", () => {
  const base = "https://accreatio.com/?view=welcome&lang=en";
  assert.deepEqual(policyDocument("/legal/terms.html?lang=es", base, "en"), {
    kind: "terms",
    locale: "es",
    href: "/legal/terms-es.html?lang=es",
    hash: "",
  });
  assert.deepEqual(policyDocument("/legal/privacy#espanol", base, "es"), {
    kind: "privacy",
    locale: "es",
    href: "/legal/privacy.html?lang=es",
    hash: "#espanol",
  });
  assert.deepEqual(policyDocument("/legal/cookies.html?lang=es", base, "en"), {
    kind: "cookies",
    locale: "es",
    href: "/legal/cookies.html?lang=es",
    hash: "",
  });
  assert.deepEqual(policyDocument("/legal/cookies#espanol", base, "en"), {
    kind: "cookies",
    locale: "en",
    href: "/legal/cookies.html?lang=en",
    hash: "#espanol",
  });
  for (const href of [
    "https://example.com/legal/privacy",
    "https://example.com/legal/cookies.html",
    "/legal/cookies-extra.html",
    "/?privacy=data",
    "/api/account/v1/data",
    "/legal/terms-extra.html",
  ])
    assert.equal(policyDocument(href, base, "en"), null);
});
