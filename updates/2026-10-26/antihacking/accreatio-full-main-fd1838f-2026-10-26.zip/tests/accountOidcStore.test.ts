import assert from "node:assert/strict";
import test from "node:test";
import {
  harness,
  POLICY_AUTHORIZATION,
  POLICY_CONTINUATION,
} from "./helpers/accountHarness";
import { oidcStore } from "../functions/_lib/auth/oidc-store";
import {
  backfillEmails,
  externalLocator,
  maintainAccounts,
  protectEmail,
  revealEmail,
  toHex,
} from "../functions/_lib/auth/privacy";
import maintenance from "../workers/account-maintenance/index";
import type { ValidatedGoogleIdentity } from "../functions/_lib/auth/oidc-contracts";

async function setup() {
  const h = await harness();
  Object.assign(h.env, {
    ACCOUNT_OIDC_ENABLED: "true",
    ACCOUNT_EMAIL_ENCRYPTION_KEY: "1".repeat(64),
    ACCOUNT_EMAIL_LOOKUP_KEY: "2".repeat(64),
    ACCOUNT_AUTH_LOCATOR_KEY: "3".repeat(64),
    ACCOUNT_OIDC_TRANSACTION_KEY: "4".repeat(64),
  });
  const store = oidcStore(h.env, h.dependencies);
  async function transaction(
    browserHash = crypto.randomUUID(),
    ipHash = crypto.randomUUID(),
    previousSessionTokenHash: string | null = null,
  ) {
    const id = crypto.randomUUID(),
      stateHash = crypto.randomUUID(),
      claimNonce = crypto.randomUUID();
    await store.createTransaction({
      id,
      stateHash,
      browserHash,
      ipHash,
      secretsCiphertext: "encrypted-fixture",
      returnMode: "popup",
      previousSessionTokenHash,
      policyAuthorization: POLICY_AUTHORIZATION,
    });
    return { id, stateHash, browserHash, claimNonce };
  }
  const google = (
    subject = "subject-1",
    email: string | null = "person@gmail.com",
  ): ValidatedGoogleIdentity => ({
    issuer: "https://accounts.google.com",
    subject,
    email,
    emailVerified: true,
    hostedDomain: null,
    authoritativeEmail: email?.endsWith("@gmail.com") ?? false,
  });
  async function login(
    identity = google(),
    previousSessionTokenHash: string | null = null,
  ) {
    const tx = await transaction(
      undefined,
      undefined,
      previousSessionTokenHash,
    );
    assert.ok(await store.claimTransaction(tx));
    const token = toHex(crypto.getRandomValues(new Uint8Array(32)));
    const hash = toHex(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token)),
    );
    await store.completeGoogleLogin({
      transactionId: tx.id,
      claimNonce: tx.claimNonce,
      identity,
      sessionTokenHash: hash,
    });
    assert.equal(
      (
        await h.call("policy", {
          cookie: `__Host-accreatio_session=${token}`,
          body: POLICY_CONTINUATION,
        })
      ).status,
      200,
    );
    return { tx, token, hash, cookie: `__Host-accreatio_session=${token}` };
  }
  return { ...h, store, transaction, google, oidcLogin: login };
}

test("Google-only login stores encrypted contact and hashed own session; stable subject preserves account and contact", async () => {
  const h = await setup();
  const first = await h.oidcLogin();
  const row = h.db.sqlite.prepare("SELECT * FROM accounts").get()!;
  assert.equal(row.email, null);
  assert.match(String(row.email_ciphertext), /^v1:/);
  assert.match(String(row.identity_key), /^fed-v1:/);
  assert.equal(
    (
      await (
        await h.call("session", { method: "GET", cookie: first.cookie })
      ).json()
    ).email,
    "person@gmail.com",
  );
  await h.oidcLogin({ ...h.google(), email: null, authoritativeEmail: false });
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    1,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT id FROM accounts").get()!.id,
    row.id,
  );
});

test("OAuth completion aborts every batch write when the clock reaches expiry between statements", async () => {
  const tables = [
    "accounts",
    "account_external_identities",
    "account_sessions",
    "account_session_metadata",
    "account_policy_authorizations",
    "account_auth_transactions",
    "account_auth_tombstones",
    "export_authorizations",
  ];
  // Profile, session, metadata, issue marker, receipt and completion boundaries.
  for (const boundary of [2, 7, 8, 9, 11, 12]) {
    const h = await setup();
    const first = await h.oidcLogin();
    h.db.sqlite.exec("DELETE FROM account_policy_authorizations");
    const tx = await h.transaction(undefined, undefined, first.hash);
    assert.ok(await h.store.claimTransaction(tx));
    const expiry = Number(
      h.db.sqlite
        .prepare("SELECT expires_at FROM account_auth_transactions WHERE id=?")
        .get(tx.id)!.expires_at,
    );
    h.db.now = expiry - 1000;
    const snapshot = () =>
      tables.map((table) =>
        h.db.sqlite.prepare(`SELECT * FROM ${table} ORDER BY rowid`).all(),
      );
    const before = snapshot();
    const batch = h.db.batch.bind(h.db);
    h.db.batch = async (statements) => {
      const statement = statements[boundary];
      const read = statement.read.bind(statement);
      statement.read = () => {
        h.db.now = expiry;
        return read();
      };
      return batch(statements);
    };
    await assert.rejects(
      h.store.completeGoogleLogin({
        transactionId: tx.id,
        claimNonce: tx.claimNonce,
        identity: { ...h.google(), displayName: "Must roll back" },
        sessionTokenHash: "a".repeat(64),
      }),
      /auth_completion_incomplete/,
      `statement ${boundary}`,
    );
    assert.deepEqual(snapshot(), before, `all rows roll back at ${boundary}`);
    assert.equal(
      h.db.sqlite
        .prepare(
          "SELECT COUNT(*) AS n FROM account_auth_transactions WHERE issued_session_token_hash IS NOT NULL",
        )
        .get()!.n,
      0,
    );
  }
});

test("new-account writes also roll back at completion expiry and successful logins do not redate an existing receipt", async () => {
  const h = await setup();
  const tx = await h.transaction();
  assert.ok(await h.store.claimTransaction(tx));
  const before = h.db.sqlite
    .prepare("SELECT * FROM account_auth_transactions WHERE id=?")
    .get(tx.id);
  const expiry = Number(before!.expires_at);
  h.db.now = expiry - 1000;
  const batch = h.db.batch.bind(h.db);
  h.db.batch = async (statements) => {
    const read = statements[12].read.bind(statements[12]);
    statements[12].read = () => {
      h.db.now = expiry;
      return read();
    };
    return batch(statements);
  };
  await assert.rejects(
    h.store.completeGoogleLogin({
      transactionId: tx.id,
      claimNonce: tx.claimNonce,
      identity: h.google(),
      sessionTokenHash: "b".repeat(64),
    }),
    /auth_completion_incomplete/,
  );
  for (const table of [
    "accounts",
    "account_sessions",
    "account_session_metadata",
    "account_external_identities",
    "account_policy_authorizations",
  ])
    assert.equal(
      h.db.sqlite.prepare(`SELECT COUNT(*) AS n FROM ${table}`).get()!.n,
      0,
      table,
    );
  assert.deepEqual(
    h.db.sqlite
      .prepare("SELECT * FROM account_auth_transactions WHERE id=?")
      .get(tx.id),
    before,
  );
  h.db.batch = batch;
  await h.oidcLogin();
  const receipt = h.db.sqlite
    .prepare("SELECT * FROM account_policy_authorizations")
    .get();
  h.db.now += 30_000;
  await h.oidcLogin();
  assert.deepEqual(
    h.db.sqlite.prepare("SELECT * FROM account_policy_authorizations").get(),
    receipt,
  );
  // Equal expiration timestamps must not let session pruning remove the newly
  // issued session before the completion guard observes it.
  for (let index = 0; index < 11; index++) await h.oidcLogin();
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
    10,
  );
  assert.equal(
    h.db.sqlite
      .prepare(
        "SELECT COUNT(*) AS n FROM account_auth_transactions WHERE status='completed' AND issued_session_token_hash IS NOT NULL",
      )
      .get()!.n,
    0,
  );
});

test("rights-only rotation rolls back its new session and preserves the old session if completion expires", async () => {
  for (const boundary of [1, 2, 3, 5]) {
    const h = await setup();
    const first = await h.oidcLogin();
    h.db.sqlite.exec("DELETE FROM account_policy_authorizations");
    const id = crypto.randomUUID();
    const stateHash = crypto.randomUUID();
    const browserHash = crypto.randomUUID();
    const claimNonce = crypto.randomUUID();
    await h.store.createTransaction({
      id,
      stateHash,
      browserHash,
      ipHash: crypto.randomUUID(),
      secretsCiphertext: "encrypted-fixture",
      returnMode: "popup",
      previousSessionTokenHash: first.hash,
      purpose: "account_access",
      verificationAction: "data",
    });
    assert.ok(
      await h.store.claimTransaction({ stateHash, browserHash, claimNonce }),
    );
    const before = {
      account: h.db.sqlite.prepare("SELECT * FROM accounts").get(),
      sessions: h.db.sqlite.prepare("SELECT * FROM account_sessions").all(),
      metadata: h.db.sqlite
        .prepare("SELECT * FROM account_session_metadata")
        .all(),
      tx: h.db.sqlite
        .prepare("SELECT * FROM account_auth_transactions WHERE id=?")
        .get(id),
    };
    const expiry = Number(before.tx!.expires_at);
    h.db.now = expiry - 1000;
    const batch = h.db.batch.bind(h.db);
    h.db.batch = async (statements) => {
      const read = statements[boundary].read.bind(statements[boundary]);
      statements[boundary].read = () => {
        h.db.now = expiry;
        return read();
      };
      return batch(statements);
    };
    await assert.rejects(
      h.store.completeGoogleLogin({
        transactionId: id,
        claimNonce,
        identity: h.google(),
        sessionTokenHash: "c".repeat(64),
      }),
      /auth_completion_incomplete/,
    );
    assert.deepEqual(
      {
        account: h.db.sqlite.prepare("SELECT * FROM accounts").get(),
        sessions: h.db.sqlite.prepare("SELECT * FROM account_sessions").all(),
        metadata: h.db.sqlite
          .prepare("SELECT * FROM account_session_metadata")
          .all(),
        tx: h.db.sqlite
          .prepare("SELECT * FROM account_auth_transactions WHERE id=?")
          .get(id),
      },
      before,
      `rights-only statement ${boundary}`,
    );
    assert.equal(
      h.db.sqlite
        .prepare("SELECT COUNT(*) AS n FROM account_policy_authorizations")
        .get()!.n,
      0,
    );
  }
});
test("same email different subject never links; untrusted external email cannot sign up; no quota or account writes", async () => {
  const h = await setup();
  await h.oidcLogin();
  await assert.rejects(h.oidcLogin(h.google("other-subject")));
  await assert.rejects(
    h.oidcLogin({
      ...h.google("external", "person@example.test"),
      authoritativeEmail: true,
    }),
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    1,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get()!.n,
    1,
  );
});
test("concurrent Google callbacks for one subject create one account and no orphan accounts", async () => {
  const h = await setup();
  const results = await Promise.allSettled([h.oidcLogin(), h.oidcLogin()]);
  assert.ok(results.some((r) => r.status === "fulfilled"));
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    1,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_external_identities")
      .get()!.n,
    1,
  );
});
test("transaction claim, cancellation and expiration prevent replay; admission keeps hourly receipts beyond secret TTL", async () => {
  const h = await setup();
  const tx = await h.transaction("browser", "ip");
  assert.equal(
    await h.store.claimTransaction({ ...tx, browserHash: "other" }),
    null,
  );
  assert.ok(await h.store.claimTransaction(tx));
  assert.equal(await h.store.claimTransaction(tx), null);
  assert.equal((await h.store.cancelTransaction(tx))?.status, "failed");
  await assert.rejects(
    h.store.completeGoogleLogin({
      transactionId: tx.id,
      claimNonce: tx.claimNonce,
      identity: h.google(),
      sessionTokenHash: "a".repeat(64),
    }),
  );
  const cancelled = h.db.sqlite
    .prepare("SELECT * FROM account_auth_transactions WHERE id=?")
    .get(tx.id)!;
  assert.equal(cancelled.secrets_ciphertext, null);
  const expired = await h.transaction();
  h.db.now += 600_000;
  assert.equal(await h.store.claimTransaction(expired), null);
  await maintainAccounts(h.db);
  assert.equal(
    h.db.sqlite
      .prepare(
        "SELECT secrets_ciphertext FROM account_auth_transactions WHERE id=?",
      )
      .get(expired.id)!.secrets_ciphertext,
    null,
  );
  h.env.ACCOUNT_OIDC_IP_HOURLY = "1";
  await assert.rejects(h.transaction("browser2", "ip"));
});
test("Google-only delete revokes all identities/sessions, purges PII and retains same principal and exhausted quota within 48h", async () => {
  const h = await setup();
  const first = await h.oidcLogin();
  const accountId = h.db.sqlite.prepare("SELECT id FROM accounts").get()!.id;
  for (let i = 0; i < 5; i++)
    assert.equal(
      (
        await h.call("authorize", {
          cookie: first.cookie,
          body: { operationId: crypto.randomUUID() },
        })
      ).status,
      200,
    );
  await h.controlProof(first.cookie, "delete");
  assert.equal((await h.call("delete", { cookie: first.cookie })).status, 200);
  const row = h.db.sqlite.prepare("SELECT * FROM accounts").get()!;
  assert.equal(row.email, null);
  assert.equal(row.email_ciphertext, null);
  assert.equal(row.email_lookup_key, null);
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_external_identities")
      .get()!.n,
    0,
  );
  assert.equal(
    (await h.call("session", { method: "GET", cookie: first.cookie })).status,
    401,
  );
  await assert.rejects(h.oidcLogin(h.google("different-subject")));
  const restored = await h.oidcLogin();
  assert.equal(
    h.db.sqlite.prepare("SELECT id FROM accounts").get()!.id,
    accountId,
  );
  assert.equal(
    (
      await (
        await h.call("session", { method: "GET", cookie: restored.cookie })
      ).json()
    ).remaining,
    0,
  );
  await h.controlProof(restored.cookie, "delete");
  await h.call("delete", { cookie: restored.cookie });
  h.db.now += 172_800_000;
  await maintainAccounts(h.db);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    0,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_auth_tombstones")
      .get()!.n,
    0,
  );
});
test("email encryption binds account/AAD and rejects tampering; backfill preserves legacy identity and receipt and is idempotent", async () => {
  const h = await setup();
  const cookie = await h.login();
  const account = h.db.sqlite.prepare("SELECT * FROM accounts").get()!;
  assert.equal(account.email, null);
  await h.call("authorize", {
    cookie,
    body: { operationId: crypto.randomUUID() },
  });
  const ciphertext = await protectEmail(
    "example@example.test",
    String(account.id),
    h.env,
    h.dependencies,
  );
  const record = {
    id: String(account.id),
    email: null,
    email_ciphertext: ciphertext.ciphertext,
    email_encryption_key_version: "v1",
  };
  assert.equal(
    await revealEmail(record, h.env, h.dependencies),
    "example@example.test",
  );
  await assert.rejects(
    revealEmail({ ...record, id: crypto.randomUUID() }, h.env, h.dependencies),
  );
  await assert.rejects(
    revealEmail(
      {
        ...record,
        email_ciphertext:
          record.email_ciphertext.slice(0, -2) +
          (record.email_ciphertext.endsWith("ff") ? "fe" : "ff"),
      },
      h.env,
      h.dependencies,
    ),
  );
  h.db.sqlite
    .prepare(
      "UPDATE accounts SET email='person@example.test',email_ciphertext=NULL,email_lookup_key=NULL WHERE id=?",
    )
    .run(account.id);
  assert.equal(await backfillEmails(h.env, h.dependencies), 1);
  assert.equal(await backfillEmails(h.env, h.dependencies), 0);
  assert.equal(
    h.db.sqlite.prepare("SELECT identity_key FROM accounts").get()!
      .identity_key,
    account.identity_key,
  );
  assert.equal(
    h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM export_authorizations")
      .get()!.n,
    1,
  );
  await h.controlProof(cookie, "data");
  assert.equal(
    (await (await h.call("data", { method: "GET", cookie })).json()).email,
    "person@example.test",
  );
});
test("scheduled maintenance runs without requests and has no public operation; locator serialization is deterministic and scoped", async () => {
  const h = await setup();
  const first = await h.oidcLogin();
  await h.controlProof(first.cookie, "delete");
  await h.call("delete", { cookie: first.cookie });
  h.db.now += 172_800_000;
  await maintenance.scheduled(
    {},
    { ...h.env, ACCOUNT_MAINTENANCE_ENABLED: "true" },
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get()!.n,
    0,
  );
  assert.equal(maintenance.fetch().status, 404);
  assert.equal(
    await externalLocator("issuer", "subject", h.env, h.dependencies),
    await externalLocator("issuer", "subject", h.env, h.dependencies),
  );
  assert.notEqual(
    await externalLocator("issuer:a", "b", h.env, h.dependencies),
    await externalLocator("issuer", "a:b", h.env, h.dependencies),
  );
});
