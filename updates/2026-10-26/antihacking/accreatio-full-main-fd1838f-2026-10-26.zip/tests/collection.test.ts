import assert from "node:assert/strict";
import test from "node:test";
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import {
  handleCollection,
  cleanCollection,
} from "../functions/_lib/collection";
import {
  COLLECTION_VERSION,
  COLLECTION_RETENTION_MS,
  parseCollectionRecord,
} from "../shared/collection";
import type {
  AccountDatabase,
  AccountBindings,
} from "../functions/_lib/accounts";
import type {
  DatabaseValue,
  BlogPreparedStatement,
} from "../functions/_lib/platform";
class Store implements AccountDatabase {
  sqlite = new DatabaseSync(":memory:");
  now = Date.now();
  constructor() {
    this.sqlite.exec("PRAGMA foreign_keys=ON");
    this.sqlite.function("unixepoch", () => this.now / 1000);
    this.sqlite.exec(
      readFileSync(
        new URL(
          "../migrations-auth/0009_optional_collection.sql",
          import.meta.url,
        ),
        "utf8",
      ),
    );
  }
  prepare(sql: string): BlogPreparedStatement {
    let args: DatabaseValue[] = [];
    const statement: BlogPreparedStatement = {
      bind(...values) {
        args = values;
        return statement;
      },
      first: async <T>() =>
        (this.sqlite.prepare(sql).get(...args) ?? null) as T | null,
      all: async <T>() => ({
        success: true,
        results: this.sqlite.prepare(sql).all(...args) as T[],
      }),
      run: async () => ({
        success: true,
        meta: {
          changes: Number(this.sqlite.prepare(sql).run(...args).changes),
        },
      }),
    };
    return statement;
  }
  async batch(statements: BlogPreparedStatement[]) {
    this.sqlite.exec("BEGIN");
    try {
      const result = [];
      for (const s of statements) {
        await s.run();
        result.push({ success: true });
      }
      this.sqlite.exec("COMMIT");
      return result;
    } catch (e) {
      this.sqlite.exec("ROLLBACK");
      throw e;
    }
  }
}
function fixture() {
  const db = new Store(),
    env: AccountBindings = { ACCOUNT_DB: db, COLLECT_ENABLED: "true" };
  const call = (
    action: "preference" | "record" | "data",
    body: unknown,
    token?: string,
    headers: Record<string, string> = {},
  ) =>
    handleCollection(
      {
        env,
        request: new Request(`https://accreatio.test/api/collect/${action}`, {
          method: "POST",
          headers: {
            Origin: "https://accreatio.test",
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
            ...headers,
          },
          body: JSON.stringify(body),
        }),
      },
      action,
    );
  const grant = async (purpose = "analytics") => {
    const response = await call("preference", {
      purpose,
      action: "grant",
      version: COLLECTION_VERSION,
    });
    assert.equal(response.status, 200, await response.clone().text());
    return (await response.json()).token as string;
  };
  const payload = {
    kind: "usage",
    feature: "creation",
    outcome: "completed",
    durationBand: "1-5-minutes",
    locale: "en",
    device: "desktop",
  };
  const record = (token?: string, overrides: Record<string, unknown> = {}) =>
    call(
      "record",
      {
        purpose: "analytics",
        version: COLLECTION_VERSION,
        id: crypto.randomUUID(),
        payload,
        ...overrides,
      },
      token,
    );
  return { db, env, call, grant, payload, record };
}
test("optional receiver positively stores and exports only the granted purpose, with no account relationship", async () => {
  const h = fixture(),
    a = await h.grant(),
    b = await h.grant();
  assert.equal((await h.record(a)).status, 200);
  const exportA = await h.call("data", { purpose: "analytics" }, a),
    exportB = await h.call("data", { purpose: "analytics" }, b);
  const value = await exportA.json();
  assert.equal(value.records.length, 1);
  assert.deepEqual(value.records[0].payload, h.payload);
  assert.equal((await exportB.json()).records.length, 0);
  assert.match(value.manifest.scope, /no account\/project link/);
  assert.doesNotMatch(
    JSON.stringify(value),
    /token_hash|Bearer|email|accountId|projectName/,
  );
  assert.deepEqual(
    h.db.sqlite
      .prepare("PRAGMA foreign_key_list(collection_permissions)")
      .all(),
    [],
  );
});
test("missing, cross-purpose, incompatible, inactive and forged grants fail closed", async () => {
  const h = fixture();
  assert.equal((await h.record()).status, 401);
  assert.equal((await h.record("a".repeat(64))).status, 403);
  const research = await h.grant("research");
  assert.equal((await h.record(research)).status, 403);
  const a = await h.grant();
  assert.equal((await h.record(a, { version: "old" })).status, 409);
  assert.equal(
    (
      await h.call(
        "preference",
        { purpose: "analytics", action: "grant", version: COLLECTION_VERSION },
        undefined,
        { Origin: "https://other.test" },
      )
    ).status,
    403,
  );
  h.env.COLLECT_ENABLED;
  Object.assign(h.env, { COLLECT_ENABLED: "false" });
  assert.equal((await h.record(a)).status, 503);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()?.n,
    0,
  );
});
test("GPC preserves independently granted first-party analytics under the new notice", async () => {
  const h = fixture();
  const grant = await h.call(
    "preference",
    { purpose: "analytics", action: "grant", version: COLLECTION_VERSION },
    undefined,
    { "Sec-GPC": "1" },
  );
  assert.equal(grant.status, 200);
  const token = (await grant.json()).token;
  const response = await h.call(
    "record",
    {
      purpose: "analytics",
      version: COLLECTION_VERSION,
      id: crypto.randomUUID(),
      payload: h.payload,
    },
    token,
    { "Sec-GPC": "1" },
  );
  assert.equal(response.status, 200);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()?.n,
    1,
  );
});

test("research works independently of analytics; only explicit enumerated answers reach storage", async () => {
  const h = fixture(),
    token = await h.grant("research"),
    id = crypto.randomUUID();
  const body = {
    purpose: "research",
    version: COLLECTION_VERSION,
    id,
    payload: {
      kind: "research",
      answers: {
        role: "developer",
        goal: "prototype",
        willingnessToPay: "10-25-usd-month",
        tools: "codex",
      },
    },
  };
  assert.equal((await h.call("record", body, token)).status, 200);
  assert.equal((await h.call("record", body, token)).status, 200);
  for (const answers of [
    { email: "synthetic@example.test" },
    { goal: "=SUM(1,1)" },
    { project: "private" },
    { role: ["developer"] },
    { toString: "developer" },
  ])
    assert.equal(
      (
        await h.call(
          "record",
          {
            ...body,
            id: crypto.randomUUID(),
            payload: { kind: "research", answers },
          },
          token,
        )
      ).status,
      400,
    );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()?.n,
    1,
  );
  assert.equal(
    parseCollectionRecord({ ...h.payload, locale: ["en"] }, "analytics"),
    null,
  );
});
test("withdrawal deletes available records and blocks prepared/replayed writes, even when collection is inactive", async () => {
  const h = fixture(),
    token = await h.grant();
  await h.record(token);
  Object.assign(h.env, { COLLECT_ENABLED: "false" });
  assert.equal(
    (
      await h.call(
        "preference",
        { purpose: "analytics", action: "revoke" },
        token,
      )
    ).status,
    200,
  );
  Object.assign(h.env, { COLLECT_ENABLED: "true" });
  assert.equal((await h.record(token)).status, 403);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()?.n,
    0,
  );
  const data = await h.call("data", { purpose: "analytics" }, token);
  assert.equal((await data.json()).records.length, 0);
});
test("30-day logical expiry and capped physical cleanup remove records; restoration invalidates old capabilities", async () => {
  const h = fixture(),
    token = await h.grant();
  await h.record(token);
  h.db.now += COLLECTION_RETENTION_MS;
  assert.equal((await h.record(token)).status, 403);
  assert.equal(
    (await h.call("data", { purpose: "analytics" }, token)).status,
    410,
  );
  await cleanCollection(h.db);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_permissions").get()
      ?.n,
    0,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()?.n,
    0,
  );
  const restored = await h.grant();
  await h.record(restored);
  // Restore runbook: collection remains off; all restored optional permissions
  // and rows are invalidated before traffic resumes, never old grants restored.
  h.db.sqlite.exec(
    "DELETE FROM collection_records; DELETE FROM collection_permissions;",
  );
  assert.equal((await h.record(restored)).status, 403);
});
test("per-purpose and global storage budgets bound writes without touching account rights", async () => {
  const h = fixture(),
    token = await h.grant();
  for (let n = 0; n < 200; n++)
    assert.equal((await h.record(token)).status, 200);
  assert.equal((await h.record(token)).status, 403);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()?.n,
    200,
  );
});

test("client-registered capability retries are idempotent and early or completed withdrawal prevents grant resurrection", async () => {
  const h = fixture(),
    token = "c".repeat(64),
    body = {
      purpose: "analytics",
      action: "grant",
      version: COLLECTION_VERSION,
    };
  for (let i = 0; i < 2; i++)
    assert.equal((await h.call("preference", body, token)).status, 200);
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_permissions").get()
      ?.n,
    1,
  );
  await h.record(token);
  assert.equal(
    (
      await h.call(
        "preference",
        { purpose: "analytics", action: "revoke" },
        token,
      )
    ).status,
    200,
  );
  assert.equal((await h.call("preference", body, token)).status, 429);
  const early = "d".repeat(64);
  assert.equal(
    (
      await h.call(
        "preference",
        { purpose: "analytics", action: "revoke" },
        early,
      )
    ).status,
    200,
  );
  assert.equal((await h.call("preference", body, early)).status, 429);
  assert.equal(
    h.db.sqlite
      .prepare(
        "SELECT COUNT(*) n FROM collection_permissions WHERE revoked_at IS NULL",
      )
      .get()?.n,
    0,
  );
  assert.equal(
    h.db.sqlite.prepare("SELECT COUNT(*) n FROM collection_records").get()?.n,
    0,
  );
});
