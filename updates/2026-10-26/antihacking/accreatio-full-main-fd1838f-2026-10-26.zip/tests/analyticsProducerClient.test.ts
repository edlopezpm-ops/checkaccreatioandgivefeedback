import assert from "node:assert/strict";
import test from "node:test";
import {
  commercialChoices,
  enforceCommercialGpc,
  recordPublicSignal,
  setCommercialChoice,
} from "../src/account/analyticsProducer";
import { saveOptionalChoice } from "../src/account/cookiePreferences";
test("analytics never grants advertising; fail-closed config, product-local rights, purpose withdrawal and GPC constrain actual requests", async (t) => {
  const values = new Map<string, string>();
  const storage = {
    get length() {
      return values.size;
    },
    key: (i: number) => [...values.keys()][i] ?? null,
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => void values.set(key, value),
    removeItem: (key: string) => void values.delete(key),
  };
  const priorStorage = Object.getOwnPropertyDescriptor(
    globalThis,
    "localStorage",
  );
  const priorNavigator = Object.getOwnPropertyDescriptor(
    globalThis,
    "navigator",
  );
  const navigatorValue = { globalPrivacyControl: false };
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: storage,
  });
  Object.defineProperty(globalThis, "navigator", {
    configurable: true,
    value: navigatorValue,
  });
  t.after(() => {
    if (priorStorage)
      Object.defineProperty(globalThis, "localStorage", priorStorage);
    else Reflect.deleteProperty(globalThis, "localStorage");
    if (priorNavigator)
      Object.defineProperty(globalThis, "navigator", priorNavigator);
    else Reflect.deleteProperty(globalThis, "navigator");
  });
  const calls: { path: string; body?: Record<string, unknown> }[] = [];
  let enabled = true;
  let denied = false;
  t.mock.method(globalThis, "fetch", async (input, init) => {
    const path = String(input),
      body = init?.body ? JSON.parse(String(init.body)) : undefined;
    calls.push({ path, body });
    assert.ok(
      path.startsWith("/api/collection/"),
      "browser only calls its own origin",
    );
    if (path.endsWith("config"))
      return Response.json({
        schema_version: 1,
        source_id: "accreatio-public-production",
        product: "accreatio",
        environment: "production",
        mode: "production",
        version: 1,
        issued_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 299000).toISOString(),
        enabled,
        events: ["public_product_viewed"],
        fields: ["category", "offer_id"],
        purposes: ["aekr_marketing", "audience_licensing"],
        retention_days: 30,
        destinations: ["partner-a-demo"],
        restriction_reason: null,
      });
    return Response.json({
      permission_ref: "10000000-0000-4000-8000-000000000001",
      status: denied && body?.status === "granted" ? "denied" : body?.status,
      expires_at: new Date(Date.now() + 30 * 86400000).toISOString(),
      granted_at:
        !denied && body?.status === "granted" ? new Date().toISOString() : null,
      withdrawn_at:
        !denied && body?.status === "granted" ? null : new Date().toISOString(),
      accepted: true,
    });
  });
  const signal = {
    event: "public_product_viewed",
    category: "development",
  } as const;
  assert.equal(await recordPublicSignal("aekr_marketing", signal), false);
  saveOptionalChoice(storage, true);
  assert.equal(await recordPublicSignal("aekr_marketing", signal), false);
  assert.equal(
    calls.length,
    0,
    "optional analytics permission emits no advertising request",
  );
  await setCommercialChoice("aekr_marketing", true);
  assert.equal(commercialChoices().aekr_marketing?.status, "granted");
  assert.equal(await recordPublicSignal("aekr_marketing", signal), true);
  assert.equal(await recordPublicSignal("audience_licensing", signal), false);
  enabled = false;
  const events = calls.filter((c) => c.path.endsWith("event")).length;
  assert.equal(await recordPublicSignal("aekr_marketing", signal), false);
  assert.equal(calls.filter((c) => c.path.endsWith("event")).length, events);
  await setCommercialChoice("aekr_marketing", false);
  assert.equal(commercialChoices().aekr_marketing?.status, "withdrawn");
  enabled = true;
  await setCommercialChoice("aekr_marketing", true);
  await setCommercialChoice("audience_licensing", true);
  navigatorValue.globalPrivacyControl = true;
  await enforceCommercialGpc();
  assert.equal(commercialChoices().audience_licensing?.status, "withdrawn");
  assert.equal(commercialChoices().aekr_marketing?.status, "granted");
  assert.equal(await recordPublicSignal("audience_licensing", signal), false);
  denied = true;
  await assert.rejects(setCommercialChoice("aekr_marketing", true));
  assert.notEqual(commercialChoices().aekr_marketing?.status, "granted");
  t.mock.method(globalThis, "fetch", async () => {
    throw Error("synthetic analytics outage");
  });
  assert.equal(await recordPublicSignal("aekr_marketing", signal), false);
});
