# Floating Cookies document — 26 October 2026

Owner request: “en accreatio, con Cookies también en un floating como privacy y tos, no a otra página”. The [machine-readable receipt](COOKIES_DIALOG_RELEASE_2026-10-26.json) records exact source, publication, verification and evidence scope. This is a separate continuation of the [earlier ToS/Privacy release](POLICY_DIALOGS_RELEASE_2026-10-26.md); that historical receipt remains unchanged.

## Delivered source

Cookies uses the same floating canonical-document dialog as Privacy and ToS. The current page, URL and EN/ES context remain in place. The common resolver covers existing Cookies surfaces and the obsolete “new tab” label is removed. Native modified clicks and the document fallback remain available. Policy text, account/consent logic, saved choices/defaults, backend, branding, typography and nebula have no change in this patch. No migration, dependency, service or new direct cost is introduced, and no optional collection activation is claimed.

[PR20](https://github.com/edlopezpm-ops/accreatio/pull/20) was merged normally at 2026-10-26T13:58:32Z with exact-head matching. Reviewed candidate 10d17ff9e7d69bc82f94e6cd36678aa97db5e6e8 and merge 681378eaf89af8d60a697a5a21b9437ed59ef898 have identical trees. No admin/force merge or rule change was used. The primary checkout and unrelated material were preserved.

## Native publication and hosted observation

The existing authenticated Pages dashboard published exact merge 681378e with native Git retry. Deployment [5493ee3b-564d-472a-aa1f-f9ae827eb958](https://5493ee3b.accreatio.pages.dev) succeeded for accreatio.com/www. The build started at 13:59:43.803719Z and reported the site deployed at 14:00:38.55877Z; the provider displayed 57 seconds. Node 22.23.4 / npm 10.9.9, the 86-file publication gate and Functions compilation passed. Automatic deployments remain paused. No credential, project setting, database migration or static-only upload changed. Previous deployment 3a5b2dcd-d875-428e-a1c1-1adb23b06a4c remains the dated outgoing publication.

Public HTTPS serves /assets/index-BFXX_x0O.js, 579890 bytes, SHA-256 4c18bb764cafe7d5262bd96596aa2d34b9af89da078ea03155ea7a5c52a2e660, identical to the reviewed local build. Coordinator in-app-browser checks covered the footer Cookies link in EN/ES on desktop and requested 390 px mobile layouts. Correct titles, open native modal, preserved welcome/locale URL, hidden root/body overflow while open and no horizontal document overflow were observed. Close, Escape and focus return to Cookies were observed in EN. The real About→Cookies link was also checked in ES, preserving the URL. Other internal locations are not claimed as hosted-tested.

The existing client initially retained the previous bundle; ordinary reloads loaded the new bundle. No site data was cleared and no cache/settings were changed; the stale-client cause is not proven. No login or consent choice was performed. These observations establish the listed UI states and module identity, not request counts or internal server-write counts. Four anonymous screenshots are retained locally with hashes in the JSON receipt.

## Actual verification

The [exact candidate CI](https://github.com/edlopezpm-ops/accreatio/actions/runs/40333660217) passed at 13:55:39Z: normal npm clean install, high-severity audit gate, all 502 tests, full verify script and 86-file web publication gate. Policy browser cases passed EN/ES at 1280, 390 and 320 px, with canonical-copy equality, focus, dismissal, scrolling, preserved choices, modifier passthrough and native/no-JavaScript fallback. GitGuardian passed. Lighthouse recorded 89/96/100/69 with the existing private-beta noindex exemption. The [published main CI](https://github.com/edlopezpm-ops/accreatio/actions/runs/40335352902) separately passed normal install, audit and full verify at 14:04:45Z.

Local chronology is explicit: 502 tests at 13:41 UTC and the full web smoke at 13:44 UTC preceded the final shared-surface adjustment; the final focused browser run at 13:46 UTC followed it. The subsequent exact-candidate CI passed the complete verification. This continuation read those existing logs and CI evidence without repeating the full suites. Ignored evidence paths and SHA-256 hashes are in the JSON receipt and are not assumed available in another checkout.

Implementation dispatch gpt-6.1-sol/ultra and independent bounded review gpt-6-astra/ultra were accepted, as confirmed by the coordinator for this session. The reviewer reported no functional blocker on the exact candidate, including preservation of canonical legal text, consent and backend scope. These are dispatch parameters, not independently inspected provider telemetry, legal approval or security certification. Technical delivery does not establish human acceptance of the beta.

This new receipt is documentation only. It preserves the earlier ToS/Privacy evidence and introduces no runtime change requiring publication.
