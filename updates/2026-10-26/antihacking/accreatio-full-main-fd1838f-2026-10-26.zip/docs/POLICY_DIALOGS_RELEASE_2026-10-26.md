# Floating policy documents — 26 October 2026

Published and observed at [accreatio.com](https://accreatio.com/?view=welcome&lang=en). The [machine-readable receipt](POLICY_DIALOGS_RELEASE_2026-10-26.json) owns exact source, deployment, verification and evidence boundaries.

## Delivered behavior

ToS and Privacy open current canonical legal documents in a native floating dialog, preserving the current page and URL. The existing choices surface remains separately named Privacy choices / Opciones de privacidad. EN/ES links retain their canonical destinations and native modified-click/fallback behavior. Focus containment, Escape, close/backdrop dismissal, focus return and real background-wheel locking are verified. Typography, canonical branding and nebula remain. PRs 17/18 change no legal text, account/consent logic or project payload.

## Source and native publication

| Evidence                     | Actual result                                                                                                                                   |
| ---------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| Policy implementation        | [PR 17](https://github.com/edlopezpm-ops/accreatio/pull/17), merge 2532829cc0cd042711d48482bdf7f16437d0fa64                                     |
| Toolchain/fixture leaf       | [PR 18](https://github.com/edlopezpm-ops/accreatio/pull/18), merge f2ccdd869badf34406413ca7b230b301d17ef589                                     |
| Successful native deployment | [3a5b2dcd-d875-428e-a1c1-1adb23b06a4c](https://3a5b2dcd.accreatio.pages.dev), exact main f2ccdd869badf34406413ca7b230b301d17ef589, 44 seconds   |
| Native toolchain             | Node 22.23.4 / npm 10.9.9; Worker compiled successfully; 29 Functions routing entries, /api/* included, no exclusions                           |
| Provider authority           | Existing authenticated dashboard and native Git retry; automatic deployments remain paused; no credential/settings change or static-only upload |
| Outgoing production          | 2c71b4bf-828a-4ce2-ad85-bb12a1117a3c, source5fba2922b49a00ff47f12aecbc5ee1d082430db4, retained                                                  |

Exactly two real build attempts occurred. The first, e06f05bb-6c80-4255-b4db-2de457e0cc7c for 2532829, failed during strict npm clean-install before artifacts/deployment: Missing undici@7.29.1. The reviewed lock-only effective dependency repair retains the existing Undici 7.30.1 security override and every resolved version/integrity. The second native build succeeded. No database migration or rollback occurred.

The publication also includes previously merged Analytics producer PR 16, which had not reached the outgoing production. This does not activate collection: fresh public control-plane readback at 2026-10-26T05:07:01.165947+00:00 shows all five real sources at version 1, enabled false, source_paused, production mode. This is not a claim that every legacy local/optional collector is globally off.

## Actual hosted proof

At2026-10-26T05:07:34.754Z, fresh anonymous Chromium contexts passed ToS and Privacy cases in EN/ES at 1280, 390 and 320 px. Canonical document text matches; URL/page, focus, dismissal, dialog bounds and wheel locking pass. Consent choices remain unchanged; no login, consent choice or form submission was performed. Observed browser application POST/other-write requests, unexpected writes and page errors are zero. These request observations do not imply zero internal D1 or security-counter writes from GETs.

The served main module is index-LTnW8-kH.js, 579816 bytes, SHA-256 d6b87dc2a344121af4d9c3d27472850d51741c146b3d651928bb60b0f329e283, identical to the reviewed build. Public methods return 200 JSON; an anonymous account session returns 401 JSON. Root HTML is not claimed byte-identical.

The existing in-app browser initially displayed old index-XluTHW5x.js. One ordinary reload changed it to index-LTnW8-kH.js; the new Privacy anchor/separate choices and full ToS dialog were then observed at the same landing URL with no horizontal overflow. No site-data clearing, cache/settings modification or additional deployment was used. The stale-client cause is not proven.

## Verification chronology

The merge decision used the authorized bounded parent-plus-leaf profile: parent 2532829 had full CI PASS; all 649 resolved package entries and 86 published files remained unchanged; exact npm 10/12 normal/default installs, ls/audits, build and focused identity/withdrawal proofs passed with independent review. No protected required check existed, and normal merge used no admin/force or rule change.

Earlier broad failures remain explicit: run 40267854238 recorded WebGL and identity timeouts; run 40269588780 passed 502 unit/type/build/artifact/web/account/identity/rights checks and failed the old Collect total-request observation 12 versus 11. Its actual extra request kind remains UNKNOWN. Controlled actual-client/receiver diagnostics demonstrate an already-in-flight necessary revoke producing the same count signature. The exact method/path/action/operation/purpose invariant rejects optional/unknown calls, passes 10/20/60 ms delayed cases and six negative cases, and retains capability removal, active grants = 0 and all server-state/storage assertions.

Later full results are actual subsequent evidence: [candidate 42218d6 CI](https://github.com/edlopezpm-ops/accreatio/actions/runs/40272159810) passed at 05:11:06Z; [deployed main f2ccdd8 CI](https://github.com/edlopezpm-ops/accreatio/actions/runs/40272214351) passed at 05:12:11Z, including 502 tests and all smokes. Main Lighthouse was89/96/100/69, with the existing private-beta noindex exemption. These later successes are not retroactively assigned to the earlier merge decision.

Local compatibility evidence used Node 24.18. npm 12's existing allowScripts policy blocked esbuild/workerd postinstall hooks under its normal/default install; no policy changed and no claim that every lifecycle hook ran is made. The successful native Node 22 / npm 10 build separately resolves provider compatibility.

Implementation dispatch was gpt-6.1-sol/ultra; independent bounded review dispatch was gpt-6-astra/ultra, both accepted with fork_turns none. These are coordinator-confirmed dispatcher parameters, not independently inspected provider telemetry, legal approval or security certification. The review scope and ignored local evidence paths are recorded in JSON; ignored evidence is not assumed available in another checkout.

This receipt and README pointer are documentation only. They do not alter the published application or require another deployment. Historical receipts and the unrelated primary-checkout audit material remain intact.
