import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";
import { handleAnalyticsProducer } from "../functions/_lib/analyticsProducer.ts";

const root = fileURLToPath(new URL("../", import.meta.url));
const output = path.join(root, ".local/logs/analytics-producer-browser");
await mkdir(output, { recursive: true });
const target = "http://127.0.0.1:4198";
const preview = spawn(
  process.execPath,
  [
    path.join(root, "node_modules/vite/bin/vite.js"),
    "preview",
    "--host",
    "127.0.0.1",
    "--port",
    "4198",
    "--strictPort",
  ],
  { cwd: root, stdio: "ignore", windowsHide: true },
);
const events = [],
  preferences = [],
  external = [],
  errors = [];
let enabled = true;
const central = async (input, init) => {
  const url = new URL(String(input));
  const body = init?.body ? JSON.parse(init.body) : null;
  if (url.pathname.endsWith("config"))
    return Response.json({
      schema_version: 1,
      source_id: "accreatio-public-preview",
      product: "accreatio",
      environment: "preview",
      mode: "production",
      version: 1,
      issued_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 299000).toISOString(),
      enabled,
      events: ["public_product_viewed", "commercial_interest_selected"],
      fields: ["category", "offer_id"],
      purposes: ["aekr_marketing", "audience_licensing"],
      retention_days: 30,
      destinations: ["partner-a-demo"],
      restriction_reason: enabled ? null : "hoc_paused",
    });
  if (url.pathname.endsWith("preferences")) {
    preferences.push(body);
    return Response.json({
      permission_ref: "10000000-0000-4000-8000-000000000001",
      status: body.status,
      expires_at: new Date(Date.now() + 30 * 86400000).toISOString(),
      granted_at: body.status === "granted" ? new Date().toISOString() : null,
      withdrawn_at: body.status === "granted" ? null : new Date().toISOString(),
    });
  }
  if (url.pathname.endsWith("events")) {
    events.push(body);
    return Response.json({ accepted: true });
  }
  return Response.json({ acknowledged: true });
};
let browser;
try {
  for (let n = 0; n < 100; n++) {
    try {
      if ((await fetch(target)).ok) break;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    reducedMotion: "reduce",
    viewport: { width: 1440, height: 1000 },
  });
  await context.route("**/*", async (route) => {
    const r = route.request(),
      url = new URL(r.url());
    if (url.origin !== target) {
      external.push(url.origin);
      return route.abort();
    }
    if (url.pathname.startsWith("/api/collection/")) {
      const response = await handleAnalyticsProducer(
        {
          request: new Request(r.url(), {
            method: r.method(),
            headers: r.headers(),
            ...(r.method() === "POST" ? { body: r.postData() } : {}),
          }),
          env: {
            COLLECTION_SOURCE_TOKEN: "synthetic-preview-credential_".repeat(2),
          },
        },
        url.pathname.split("/").at(-1),
        { fetch: central, now: Date.now },
      );
      return route.fulfill({
        status: response.status,
        headers: Object.fromEntries(response.headers),
        body: await response.text(),
      });
    }
    if (url.pathname.startsWith("/api/"))
      return route.fulfill({
        status: 401,
        contentType: "application/json",
        body: JSON.stringify({ error: { code: "synthetic_not_signed_in" } }),
      });
    return route.continue();
  });
  const page = await context.newPage();
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto(`${target}/?lang=en`);
  await page
    .getByRole("button", { name: "Reject non-essential cookies", exact: true })
    .click();
  assert.equal(events.length, 0);
  assert.equal(preferences.length, 0);
  await page
    .getByRole("button", {
      name: /^(Privacy choices|Opciones de privacidad)$/,
      exact: true,
    })
    .click();
  const dialog = page.getByRole("dialog");
  await dialog
    .getByText("Offers and optional commercial uses", { exact: true })
    .click();
  await dialog
    .getByText("Source connected · configuration 1", { exact: true })
    .waitFor();
  const marketing = dialog.getByRole("checkbox", {
    name: "AEKR commercial interests",
    exact: true,
  });
  const licensing = dialog.getByRole("checkbox", {
    name: "Audience licensing to named recipients",
    exact: true,
  });
  assert.equal(await marketing.isChecked(), false);
  assert.equal(await licensing.isChecked(), false);
  await marketing.click();
  await dialog
    .getByText("Choice confirmed for this purpose and browser.", {
      exact: true,
    })
    .waitFor();
  assert.equal(await marketing.isChecked(), true);
  await page.waitForFunction(
    () =>
      document.querySelector("button") &&
      localStorage
        .getItem("accreatio:commercial-preferences:2026-10-25")
        ?.includes('"status":"granted"'),
  );
  await dialog
    .getByRole("button", { name: "Share this interest", exact: true })
    .click();
  await dialog.getByText("Interest confirmed.", { exact: true }).waitFor();
  assert.ok(
    events.some((event) => event.event === "commercial_interest_selected"),
  );
  assert.ok(preferences.every((choice) => choice.purpose === "aekr_marketing"));
  assert.equal(await licensing.isChecked(), false);
  await page.screenshot({ path: path.join(output, "commercial-desktop.png") });
  const beforePause = events.length;
  enabled = false;
  await dialog
    .getByRole("button", { name: "Share this interest", exact: true })
    .click();
  await dialog
    .getByText("Interest was not shared; source paused or unavailable.", {
      exact: true,
    })
    .waitFor();
  assert.equal(events.length, beforePause);
  await dialog
    .getByRole("button", {
      name: "Withdraw every commercial use / retry",
      exact: true,
    })
    .click();
  await dialog
    .getByText("Withdrawal confirmed for every commercial purpose.", {
      exact: true,
    })
    .waitFor();
  assert.equal(await marketing.isChecked(), false);
  assert.ok(preferences.some((choice) => choice.status === "withdrawn"));
  await page.setViewportSize({ width: 390, height: 844 });
  assert.equal(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    true,
  );
  await page.screenshot({
    path: path.join(output, "commercial-mobile-withdrawn.png"),
  });
  assert.deepEqual(external, []);
  assert.deepEqual(errors, []);
  const result = {
    result: "PASS",
    mode: "synthetic local browser + real same-origin adapter + synthetic central fixture",
    eventCount: events.length,
    preferences: preferences.length,
    cases: [
      "default/reject sends no commercial event or identifier",
      "independent purpose choice",
      "public signal admission",
      "backend pause",
      "rights during pause",
      "desktop/mobile no overflow",
      "no external browser requests",
      "no page errors",
    ],
  };
  await writeFile(
    path.join(output, "result.json"),
    JSON.stringify(result, null, 2),
  );
  console.log(JSON.stringify(result));
} finally {
  if (browser) await browser.close();
  preview.kill();
}
