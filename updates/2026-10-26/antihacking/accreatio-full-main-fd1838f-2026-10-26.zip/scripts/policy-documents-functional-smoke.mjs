import assert from "node:assert/strict";
import { mkdir } from "node:fs/promises";
import path from "node:path";

export async function checkPolicyDocuments(browser, target) {
  const output = path.resolve(
    ".local/logs/playwright",
    `policy-documents-${new Date().toISOString().replaceAll(/[:.]/g, "-")}`,
  );
  await mkdir(output, { recursive: true });
  for (const locale of ["en", "es"]) {
    for (const width of [1280, 390, 320]) {
      const context = await browser.newContext({
        viewport: { width, height: 900 },
        reducedMotion: "reduce",
        serviceWorkers: "block",
      });
      const page = await context.newPage();
      const writes = [];
      page.on("request", (request) => {
        if (!["GET", "HEAD"].includes(request.method()))
          writes.push(request.url());
      });
      try {
        await page.goto(`${target}/?view=welcome&lang=${locale}`);
        const beforeUrl = page.url();
        const choicesBefore = await page.evaluate(() =>
          localStorage.getItem("accreatio:cookie-preferences"),
        );
        const footer = page.locator(".web-footer__policies");
        const terms = footer.getByRole("link", { name: "ToS", exact: true });
        const privacy = footer.getByRole("link", {
          name: "Privacy",
          exact: true,
        });
        const cookies = footer.getByRole("link", {
          name: "Cookies",
          exact: true,
        });
        assert.equal(
          await terms.getAttribute("href"),
          `/legal/terms${locale === "es" ? "-es" : ""}.html?lang=${locale}`,
        );
        await terms.click();
        const dialog = page.locator(".policy-document-dialog");
        const prose = dialog.locator(".policy-document-prose");
        await prose.waitFor();
        assert.equal(await prose.locator("h2").count(), 14);
        assert.equal(await prose.getAttribute("lang"), locale);
        assert.equal(
          await prose
            .locator('a[href*="/legal/cookies"]')
            .first()
            .getAttribute("href"),
          `/legal/cookies.html?lang=${locale}`,
        );
        assert.equal(page.url(), beforeUrl);
        assert.equal(context.pages().length, 1);
        assert.equal(
          await page.evaluate(() => document.body.style.overflow),
          "hidden",
        );
        assert.equal(
          await dialog
            .locator("h2#policy-document-title")
            .evaluate((element) => document.activeElement === element),
          true,
        );
        const fit = await dialog.evaluate((element) => {
          const bounds = element.getBoundingClientRect();
          return (
            bounds.left >= 0 &&
            bounds.right <= innerWidth &&
            bounds.top >= 0 &&
            bounds.bottom <= innerHeight
          );
        });
        assert.equal(fit, true);
        assert.equal(
          await page.evaluate(
            () => document.documentElement.scrollWidth <= innerWidth,
          ),
          true,
        );
        await prose.evaluate((element) => {
          element.scrollTop = element.scrollHeight;
        });
        assert.ok(await prose.evaluate((element) => element.scrollTop > 0));
        const backgroundScroll = await page.evaluate(() => window.scrollY);
        await page.mouse.move(1, 1);
        await page.mouse.wheel(0, -600);
        await page.waitForTimeout(100);
        assert.equal(
          await page.evaluate(() => window.scrollY),
          backgroundScroll,
        );
        await page.keyboard.press("Shift+Tab");
        assert.equal(
          await dialog.evaluate((element) =>
            element.contains(document.activeElement),
          ),
          true,
        );
        await page.screenshot({
          path: path.join(output, `terms-${locale}-${width}.png`),
        });
        await page.keyboard.press("Escape");
        await dialog.waitFor({ state: "detached" });
        assert.equal(
          await terms.evaluate((element) => document.activeElement === element),
          true,
        );
        assert.equal(
          await page.evaluate(() => document.body.style.overflow),
          "",
        );
        assert.equal(
          await page.evaluate(() => document.documentElement.style.overflow),
          "",
        );

        await privacy.click();
        await prose.waitFor();
        const canonical = await page.request.get(
          `${target}/legal/privacy.html?lang=${locale}`,
        );
        const expected = await page.evaluate(
          (html) => {
            const document = new DOMParser().parseFromString(html, "text/html");
            const main = document.querySelector("main");
            main.querySelector("nav").remove();
            main.querySelector("h1").remove();
            return main.textContent.replace(/\s+/g, " ").trim();
          },
          await canonical.text(),
        );
        assert.equal(
          (await prose.textContent()).replace(/\s+/g, " ").trim(),
          expected,
        );
        assert.equal(page.url(), beforeUrl);
        await page.screenshot({
          path: path.join(output, `privacy-${locale}-${width}.png`),
        });
        await page.mouse.click(1, 1);
        await dialog.waitFor({ state: "detached" });
        assert.equal(
          await privacy.evaluate(
            (element) => document.activeElement === element,
          ),
          true,
        );

        assert.equal(
          await cookies.getAttribute("href"),
          `/legal/cookies.html?lang=${locale}`,
        );
        assert.equal(await cookies.getAttribute("aria-haspopup"), "dialog");
        await cookies.click();
        await prose.waitFor();
        const canonicalCookies = await page.request.get(
          `${target}/legal/cookies.html?lang=${locale}`,
        );
        const expectedCookies = await page.evaluate(
          (html) => {
            const document = new DOMParser().parseFromString(html, "text/html");
            const main = document.querySelector("main");
            main.querySelector("nav").remove();
            main.querySelector("h1").remove();
            return main.textContent.replace(/\s+/g, " ").trim();
          },
          await canonicalCookies.text(),
        );
        assert.equal(
          (await prose.textContent()).replace(/\s+/g, " ").trim(),
          expectedCookies,
        );
        assert.equal(await dialog.getAttribute("lang"), locale);
        assert.equal(
          await dialog.locator("#policy-document-title").textContent(),
          locale === "es"
            ? "Cookies y almacenamiento del dispositivo"
            : "Cookies and device storage",
        );
        assert.equal(page.url(), beforeUrl);
        assert.equal(context.pages().length, 1);
        assert.equal(
          await dialog.evaluate((element) => {
            const bounds = element.getBoundingClientRect();
            return (
              bounds.left >= 0 &&
              bounds.right <= innerWidth &&
              bounds.top >= 0 &&
              bounds.bottom <= innerHeight &&
              document.documentElement.scrollWidth <= innerWidth
            );
          }),
          true,
        );
        await prose.evaluate((element) => {
          element.scrollTop = element.scrollHeight;
        });
        assert.ok(await prose.evaluate((element) => element.scrollTop > 0));
        await page.screenshot({
          path: path.join(output, `cookies-${locale}-${width}.png`),
        });
        await page.keyboard.press("Escape");
        await dialog.waitFor({ state: "detached" });
        assert.equal(
          await cookies.evaluate(
            (element) => document.activeElement === element,
          ),
          true,
        );
        assert.equal(
          await page.evaluate(() =>
            localStorage.getItem("accreatio:cookie-preferences"),
          ),
          choicesBefore,
        );
        assert.deepEqual(writes, []);

        const settings = footer.getByRole("button", {
          name: locale === "es" ? "Opciones de privacidad" : "Privacy choices",
          exact: true,
        });
        await settings.click();
        const preferences = page.locator(".cookie-preferences-dialog");
        await preferences.waitFor();
        for (const checkbox of await preferences.getByRole("checkbox").all())
          assert.equal(await checkbox.isChecked(), false);
        await preferences
          .getByRole("link", {
            name: locale === "es" ? "Privacidad" : "Privacy",
            exact: true,
          })
          .click();
        await prose.waitFor();
        await page.keyboard.press("Escape");
        await dialog.waitFor({ state: "detached" });
        assert.equal(
          await preferences.evaluate((element) => element.open),
          true,
        );
        assert.equal(
          await preferences.evaluate((element) =>
            element.contains(document.activeElement),
          ),
          true,
        );
        await page.keyboard.press("Escape");
        console.log(
          `PASS policy documents ${locale} ${width}px; canonical copy, focus, dismissal, scroll, choices unchanged`,
        );
      } finally {
        await context.close();
      }
    }
  }
  for (const locale of ["en", "es"]) {
    const context = await browser.newContext({
      serviceWorkers: "block",
      reducedMotion: "reduce",
    });
    try {
      const page = await context.newPage();
      await page.goto(`${target}/?view=welcome&lang=${locale}`);
      const beforeUrl = page.url();
      const cookieLink = page
        .locator(".web-footer__policies")
        .getByRole("link", { name: "Cookies", exact: true });
      for (const modifier of ["ctrlKey", "metaKey", "shiftKey", "altKey"]) {
        assert.equal(
          await cookieLink.evaluate((link, modifier) => {
            let intercepted;
            document.addEventListener(
              "click",
              (event) => {
                intercepted = event.defaultPrevented;
                // Observe the application listener, then isolate native navigation.
                event.preventDefault();
              },
              { once: true },
            );
            link.dispatchEvent(
              new MouseEvent("click", {
                bubbles: true,
                cancelable: true,
                [modifier]: true,
              }),
            );
            return intercepted;
          }, modifier),
          false,
        );
      }
      assert.equal(page.url(), beforeUrl);
      assert.equal(await page.locator(".policy-document-dialog").count(), 0);
      const savedChoice = await page.evaluate(() => {
        const choice = JSON.stringify({
          schemaVersion: 1,
          necessary: true,
          analytics: false,
          advertising: false,
          recordedAt: Date.now(),
        });
        localStorage.setItem("accreatio:cookie-preferences", choice);
        return choice;
      });
      // Other existing Cookies surfaces also use the common policy dialog.
      await cookieLink.evaluate((link) => {
        link.target = "_blank";
      });
      await cookieLink.click();
      await page.locator(".policy-document-prose").waitFor();
      assert.equal(page.url(), beforeUrl);
      assert.equal(context.pages().length, 1);
      assert.equal(
        await page.evaluate(() =>
          localStorage.getItem("accreatio:cookie-preferences"),
        ),
        savedChoice,
      );
      await page.keyboard.press("Escape");
      await page
        .locator(".policy-document-dialog")
        .waitFor({ state: "detached" });
      await page.addInitScript(() => {
        HTMLDialogElement.prototype.showModal = undefined;
      });
      for (const name of ["ToS", "Cookies"]) {
        await page.goto(`${target}/?view=welcome&lang=${locale}`);
        await page
          .locator(".web-footer__policies")
          .getByRole("link", { name, exact: true })
          .click();
        const document =
          name === "ToS" ? `terms${locale === "es" ? "-es" : ""}` : "cookies";
        await page.waitForURL(`**/legal/${document}.html?lang=${locale}`);
        assert.ok(await page.locator("main.legal-prose").textContent());
      }
      console.log(
        `PASS policy document modifier and native fallback ${locale}`,
      );
    } finally {
      await context.close();
    }
    const noScript = await browser.newContext({ javaScriptEnabled: false });
    try {
      const page = await noScript.newPage();
      await page.goto(`${target}/legal/cookies.html?lang=${locale}`);
      assert.ok(await page.locator("main.legal-prose").textContent());
      assert.equal(await page.locator("#espanol").getAttribute("lang"), "es");
      console.log(`PASS policy document no-JavaScript fallback ${locale}`);
    } finally {
      await noScript.close();
    }
  }
  console.log(`Policy document browser captures: ${output}`);
}
