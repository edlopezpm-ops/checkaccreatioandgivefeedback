import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { harness } from "../tests/helpers/accountHarness.ts";
import { protectDisplayName } from "../functions/_lib/auth/privacy.ts";
import {
  ACCOUNT_POLICY,
  ACCOUNT_COOKIES_NOTICE_VERSION,
} from "../shared/accountPolicy.ts";
import {
  minimalDocx,
  assertSameDocxParts,
} from "./attachment-smoke-fixtures.mjs";
import {
  continueQuestion,
  expectQuestion,
  finishGuidedQuestions,
  inspectProjectZip,
} from "./guided-creation-functional-smoke.mjs";

export async function assertPolicyNotice(page) {
  const notice = page.locator(".web-signin__policy");
  await notice.waitFor();
  assert.equal(await notice.getByRole("checkbox").count(), 0);
  assert.match(
    await notice.locator("#account-policy-terms").innerText(),
    /^(By continuing, you accept the AEKR Terms|Al continuar, aceptas los Términos de AEKR)/,
  );
  assert.match(
    await notice.locator("#account-policy-data").innerText(),
    /^(By continuing, you authorize AEKR to process|Al continuar, autorizas a AEKR a tratar)/,
  );
  assert.match(
    await notice.locator("#account-policy-scope").innerText(),
    /does not authorize advertising or analytics|No autorizas publicidad ni analítica/,
  );
  for (const path of ["terms", "privacy", "cookies"]) {
    const links = await notice.locator(`a[href^="/legal/${path}"]`).count();
    const message = `Policy notice must contain exactly one /legal/${path} link`;
    if (links !== 1)
      assert.equal(
        links,
        1,
        `${message}; snapshot: ${JSON.stringify(
          await page.evaluate(() => ({
            notice:
              document.querySelector(".web-signin__policy")?.outerHTML ?? null,
            signInButtons: [
              ...document.querySelectorAll(".web-signin button"),
            ].map((button) => ({
              text: button.textContent,
              disabled: button.disabled,
            })),
            loading: [...document.querySelectorAll('[role="status"]')].map(
              (status) => status.textContent,
            ),
          })),
        )}`,
      );
    assert.equal(links, 1, message);
  }
  for (const control of await page
    .locator('[aria-describedby*="account-policy-"]')
    .all()) {
    for (const id of (await control.getAttribute("aria-describedby"))
      .split(/\s+/)
      .filter((id) => id.startsWith("account-policy-")))
      assert.equal(
        await page.locator(`#${id}`).isVisible(),
        true,
        `${id} describes the action with a visible notice`,
      );
  }
}

// Reading, polling and revisiting the notice never authorize anything. The
// caller performs the intentional click only after these no-write assertions.
export async function assertClickwrapBeforeAction(page, button, mutationCount) {
  const before = mutationCount();
  await assertPolicyNotice(page);
  assert.equal(await button.isEnabled(), true);
  await page.waitForTimeout(40);
  assert.equal(
    mutationCount(),
    before,
    "Rendering and reading the notice send no authorization",
  );
}

export async function rejectNonEssentialCookies(page, mutationCount) {
  const before = mutationCount();
  const preferenceBefore = await page.evaluate(() =>
    localStorage.getItem("accreatio:cookie-preferences"),
  );
  const entry = page.getByRole("button", {
    name: /^(Privacy choices|Opciones de privacidad)$/,
  });
  const footerLayout = await entry.evaluate((trigger) => {
    const footer = trigger.closest(".web-footer");
    const controls = [
      trigger,
      footer?.querySelector(".web-footer__social"),
      footer?.querySelector(".web-footer__brand"),
    ];
    return {
      inFooter: Boolean(footer),
      controls: controls.map((control) => {
        if (!control) return null;
        const box = control.getBoundingClientRect();
        return {
          width: box.width,
          height: box.height,
          x: box.x,
          right: box.right,
        };
      }),
    };
  });
  assert.equal(footerLayout.inFooter, true);
  assert.equal(footerLayout.controls.filter(Boolean).length, 3);
  for (const control of footerLayout.controls) {
    assert.ok(
      control.width > 0 && control.height > 0,
      "Footer policies and original brand links remain visible",
    );
    assert.ok(
      control.x >= 0,
      "Footer controls remain reachable within the viewport",
    );
  }
  await entry.click();
  const dialog = page.getByRole("dialog", {
    name: /^(Privacy|Privacidad)$/,
  });
  await dialog.waitFor();
  assert.equal(
    mutationCount(),
    before,
    "Opening privacy preferences sends no account request",
  );
  assert.equal(
    await page.evaluate(() =>
      localStorage.getItem("accreatio:cookie-preferences"),
    ),
    preferenceBefore,
    "Opening preferences never writes a default choice",
  );
  const start = await page.evaluate(() => Date.now());
  await dialog
    .getByRole("button", {
      name: /^(Reject non-essential cookies|Rechazar no esenciales)$/,
    })
    .click();
  await dialog
    .getByRole("status")
    .filter({
      hasText:
        /Saved preference: necessary only|Preferencia guardada: solo necesarias/,
    })
    .waitFor();
  const end = await page.evaluate(() => Date.now());
  const preference = await page.evaluate(() =>
    JSON.parse(localStorage.getItem("accreatio:cookie-preferences")),
  );
  assert.deepEqual(Object.keys(preference).sort(), [
    "advertising",
    "analytics",
    "necessary",
    "recordedAt",
    "schemaVersion",
  ]);
  assert.deepEqual(
    { ...preference, recordedAt: 0 },
    {
      schemaVersion: 1,
      necessary: true,
      analytics: false,
      advertising: false,
      recordedAt: 0,
    },
  );
  assert.ok(
    Number.isSafeInteger(preference.recordedAt) &&
      preference.recordedAt >= start &&
      preference.recordedAt <= end,
  );
  assert.equal(
    mutationCount(),
    before,
    "Rejecting optional cookies sends no authorization or optional event",
  );
  await dialog.getByRole("button", { name: /^(Close|Cerrar)$/ }).click();
  assert.equal(
    await entry.evaluate((trigger) => document.activeElement === trigger),
    true,
    "Closing preferences returns focus to its footer trigger",
  );
  await entry.click();
  await dialog
    .getByRole("status")
    .filter({
      hasText:
        /Saved preference: necessary only|Preferencia guardada: solo necesarias/,
    })
    .waitFor();
  assert.deepEqual(
    await page.evaluate(() =>
      JSON.parse(localStorage.getItem("accreatio:cookie-preferences")),
    ),
    preference,
    "Reopening preserves the explicit local preference",
  );
  await dialog.getByRole("button", { name: /^(Close|Cerrar)$/ }).click();
  assert.equal(mutationCount(), before);
  return { preferenceBefore, preference };
}

async function readDurableBrowserDraft(page) {
  return page.evaluate(async () => {
    const databases = await indexedDB.databases();
    if (!databases.some((database) => database.name === "accreatio-drafts"))
      throw new Error("The expected draft database does not exist");
    return new Promise((resolve, reject) => {
      const opened = indexedDB.open("accreatio-drafts");
      opened.onerror = () => reject(opened.error);
      opened.onblocked = () =>
        reject(new Error("Draft database read was blocked"));
      opened.onupgradeneeded = () => opened.transaction.abort();
      opened.onsuccess = () => {
        const database = opened.result;
        const transaction = database.transaction("drafts", "readonly");
        const read = transaction
          .objectStore("drafts")
          .get("account-current:v1");
        let record;
        read.onsuccess = () => {
          record = read.result;
        };
        transaction.oncomplete = () => {
          database.close();
          resolve(record ?? null);
        };
        transaction.onabort = () => {
          database.close();
          reject(
            transaction.error ?? new Error("Draft read transaction aborted"),
          );
        };
      };
    });
  });
}

// Real browser/file bytes/service worker, with a synthetic Google transport.
// These assertions establish frontend preservation, not OIDC validation or a
// successful live Google account login. Backend OIDC is tested separately.
export async function checkGoogleAccountUi({
  browser,
  target,
  output,
  installAccountRoutes,
}) {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    acceptDownloads: true,
    reducedMotion: "reduce",
  });
  const errors = [];
  let inspectPrincipalNavigation = null;
  await context.route(
    "https://accounts.google.com/o/oauth2/v2/auth*",
    async (route) => {
      if (inspectPrincipalNavigation) await inspectPrincipalNavigation();
      await route.fulfill({
        contentType: "text/html",
        headers: { "Cross-Origin-Opener-Policy": "same-origin" },
        body: "<!doctype html><title>Synthetic Google login</title><p>Google UI fixture: no external request or identity.</p>",
      });
    },
  );
  const h = await harness();
  h.db.now = Math.floor(Date.now() / 1000) * 1000;
  const state = installAccountRoutes(h, true);
  const cookie = await h.login(
    { email: "google-ui@gmail.com" },
    { policyAuthorization: false },
  );
  const rejectedRights = await context.request.post(
    `${target}/api/auth/v1/oidc/google/start`,
    {
      data: {
        purpose: "account_access",
        verificationAction: "data",
        returnRoute: "builder",
        mode: "popup",
      },
    },
  );
  assert.equal(
    rejectedRights.status(),
    401,
    "Rights transport cannot create a session without a valid cookie",
  );
  assert.equal(state.authTransactions.size, 0);
  // A seeded presentation claim uses the production encryption/read path. This
  // fixture does not claim a real Google exchange or replace account responses.
  const fixtureDisplayName = "Google UI Creator";
  h.env.ACCOUNT_EMAIL_ENCRYPTION_KEY = "c".repeat(64);
  h.env.ACCOUNT_EMAIL_LOOKUP_KEY = "d".repeat(64);
  h.env.ACCOUNT_AUTH_LOCATOR_KEY = "e".repeat(64);
  const fixtureAccount = h.db.sqlite
    .prepare("SELECT id FROM accounts WHERE email = ?")
    .get("google-ui@gmail.com");
  assert.ok(fixtureAccount);
  h.db.sqlite
    .prepare(
      "INSERT INTO account_external_identities(id,account_id,issuer,subject,locator_hmac,created_at,last_authenticated_at) VALUES(?,?,'https://accounts.google.com',?,?,?,?)",
    )
    .run(
      "google-ui-fixture",
      fixtureAccount.id,
      "google-ui-fixture",
      "google-ui-fixture",
      h.db.now,
      h.db.now,
    );
  const protectedName = await protectDisplayName(
    fixtureDisplayName,
    fixtureAccount.id,
    h.env,
    h.dependencies,
  );
  h.db.sqlite
    .prepare("UPDATE accounts SET display_name_ciphertext = ? WHERE id = ?")
    .run(protectedName, fixtureAccount.id);
  await context.addCookies([
    {
      name: "__Host-accreatio_session",
      value: cookie.split("=")[1],
      domain: new URL(target).hostname,
      path: "/",
      httpOnly: true,
      secure: true,
      sameSite: "Strict",
    },
  ]);
  const page = await context.newPage();
  page.on("pageerror", (error) => errors.push(error.message));
  const googleButton = () =>
    page.getByRole("button", { name: "Continue with Google", exact: true });
  const authMutationCount = () =>
    state.authRequests.length +
    state.requests.filter((request) => request.method === "POST").length;
  const assertGoogleClickwrap = () =>
    assertClickwrapBeforeAction(page, googleButton(), authMutationCount);
  const accountTrigger = () => page.locator(".web-account-menu__trigger");
  const openAccountMenu = async () => {
    const trigger = accountTrigger();
    await trigger.waitFor();
    if ((await trigger.getAttribute("aria-expanded")) !== "true")
      await trigger.click();
    const panel = page.getByRole("region", { name: "Account", exact: true });
    await panel.waitFor();
    assert.equal(await trigger.getAttribute("aria-expanded"), "true");
    return panel;
  };
  const expireSession = async () => {
    h.db.sqlite.exec("DELETE FROM account_sessions");
    await page.evaluate(() =>
      window.dispatchEvent(new Event("accreatio:session-invalid")),
    );
    await googleButton().waitFor();
    await assertPolicyNotice(page);
    assert.equal(await accountTrigger().count(), 0);
    assert.equal(await page.locator("#web-account-menu-panel").count(), 0);
  };
  const checkLayouts = async () => {
    for (const width of [320, 390, 1280]) {
      await page.setViewportSize({ width, height: 900 });
      assert.equal(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
        true,
      );
      await page.evaluate(() =>
        window.scrollTo({ top: 0, left: 0, behavior: "instant" }),
      );
      await page.screenshot({
        path: path.join(output, `google-login-en-${width}.png`),
        fullPage: true,
      });
    }
    await page.setViewportSize({ width: 320, height: 900 });
    const spanishDiscovery = page.waitForResponse(
      (response) =>
        new URL(response.url()).pathname === "/api/auth/v1/methods" &&
        response.request().method() === "GET",
    );
    await page
      .getByRole("button", { name: "Switch to Spanish", exact: true })
      .click();
    assert.equal(
      (await spanishDiscovery).status(),
      200,
      "Spanish locale method discovery must finish before inspecting its notice",
    );
    await page
      .getByRole("button", { name: "Continuar con Google", exact: true })
      .waitFor();
    await assertPolicyNotice(page);
    await page.evaluate(() =>
      window.scrollTo({ top: 0, left: 0, behavior: "instant" }),
    );
    await page.screenshot({
      path: path.join(output, "google-login-es-320.png"),
      fullPage: true,
    });
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      true,
    );
    const englishDiscovery = page.waitForResponse(
      (response) =>
        new URL(response.url()).pathname === "/api/auth/v1/methods" &&
        response.request().method() === "GET",
    );
    await page
      .getByRole("button", { name: "Cambiar a inglés", exact: true })
      .click();
    assert.equal(
      (await englishDiscovery).status(),
      200,
      "English locale method discovery must finish before inspecting its notice",
    );
    await googleButton().waitFor();
    await assertPolicyNotice(page);
    await page.setViewportSize({ width: 390, height: 844 });
  };
  const popup = async (controls = false) => {
    if (!controls) await assertGoogleClickwrap();
    const opened = context.waitForEvent("page");
    await (
      controls
        ? page.getByRole("button", {
            name: "Verify Google for account controls",
            exact: true,
          })
        : googleButton()
    ).click();
    const authPage = await opened;
    await authPage.waitForURL("https://accounts.google.com/**");
    await authPage
      .getByText("Google UI fixture: no external request or identity.")
      .waitFor();
    assert.equal(await authPage.evaluate(() => window.opener), null);
    return authPage;
  };
  const transaction = () => [...state.authTransactions.entries()].at(-1);
  const downloadPrivacyData = async () => {
    const menu = await openAccountMenu();
    await menu
      .getByRole("button", { name: "Privacy and my data", exact: true })
      .click();
    const privacy = page.getByRole("dialog", { name: "Privacy", exact: true });
    const details = privacy.locator("details.web-signin__rights");
    if ((await details.getAttribute("open")) === null)
      await details.locator("summary").click();
    const downloading = page.waitForEvent("download");
    void downloading.catch(() => {});
    const opened = context.waitForEvent("page");
    await details
      .getByRole("button", { name: "Verify with Google", exact: true })
      .click();
    const proof = await opened;
    await proof.waitForURL("https://accounts.google.com/**");
    const transactionId = transaction()[0];
    await proof
      .goto(`${target}/api/fixture/google/complete?state=${transactionId}`)
      .catch((error) => {
        if (!proof.isClosed()) throw error;
      });
    const data = JSON.parse(
      await readFile(await (await downloading).path(), "utf8"),
    );
    await details
      .getByRole("button", { name: "Verify with Google", exact: true })
      .waitFor();
    await privacy.getByRole("button", { name: "Close", exact: true }).click();
    if (!proof.isClosed()) await proof.close();
    return { data, transactionId };
  };
  const mainMarker = "google-preservation-main-document";
  try {
    await page.goto(target);
    await page.evaluate(async () => {
      await navigator.serviceWorker.ready;
    });
    await page.reload();
    await page
      .getByRole("button", { name: "Prepare my project", exact: true })
      .click();
    await page
      .getByRole("button", { name: "Continue to sign in", exact: true })
      .click();
    await accountTrigger().waitFor();
    assert.equal(
      (await accountTrigger().innerText()).trim(),
      fixtureDisplayName,
    );
    assert.equal(
      await page.getByText("google-ui@gmail.com", { exact: true }).count(),
      0,
    );
    const initialAccountPanel = await openAccountMenu();
    await initialAccountPanel
      .getByText("google-ui@gmail.com", { exact: true })
      .waitFor();
    await initialAccountPanel
      .getByText("0 of 5 exports used in the last 24 hours", { exact: true })
      .waitFor();
    await initialAccountPanel
      .getByText("5 of 5 exports remaining", { exact: true })
      .waitFor();
    await page.keyboard.press("Escape");
    await page.locator("#web-account-menu-panel").waitFor({ state: "hidden" });
    // A pre-migration account has no receipt. Reading the session, visiting the
    // gate and exercising existing-account rights must never backfill one.
    const policyHeading = () =>
      page.getByRole("heading", {
        name: "Review your account and data",
        exact: true,
      });
    await policyHeading().waitFor();
    const rejectedMixedPurpose = await context.request.post(
      `${target}/api/auth/v1/oidc/google/start`,
      {
        data: {
          purpose: "account_access",
          returnRoute: "builder",
          mode: "popup",
          policyAuthorization: {
            ...ACCOUNT_POLICY,
            accountDataAuthorized: true,
            termsAccepted: true,
          },
        },
      },
    );
    assert.equal(rejectedMixedPurpose.status(), 400);
    assert.equal(state.authTransactions.size, 0);
    await assertPolicyNotice(page);
    const policyReceipts = () =>
      h.db.sqlite.prepare("SELECT * FROM account_policy_authorizations").all();
    assert.deepEqual(policyReceipts(), []);
    assert.equal(await page.locator("#project-name").count(), 0);
    const legacyAccounts = h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM accounts")
      .get().n;
    const legacyName = h.db.sqlite
      .prepare("SELECT display_name_ciphertext FROM accounts WHERE id=?")
      .get(fixtureAccount.id).display_name_ciphertext;
    const rightsPanel = await openAccountMenu();
    for (const name of ["Privacy and my data", "Sign out", "Delete account"])
      assert.equal(
        await rightsPanel
          .getByRole("button", { name, exact: true })
          .isEnabled(),
        true,
      );
    await page.keyboard.press("Escape");
    const legacy = await downloadPrivacyData();
    assert.equal(legacy.data.policyAuthorization, null);
    assert.deepEqual(policyReceipts(), []);
    h.db.now += 301_000;
    const expiredProof = await context.request.get(
      `${target}/api/account/data`,
      {
        headers: {
          "X-Accreatio-Rights": "1",
          "X-Accreatio-Rights-Transaction": legacy.transactionId,
        },
      },
    );
    assert.equal(
      expiredProof.status(),
      401,
      "An expired rights proof cannot silently download data",
    );
    const refreshed = await downloadPrivacyData();
    assert.equal(refreshed.data.policyAuthorization, null);
    await policyHeading().waitFor();
    await assertPolicyNotice(page);
    assert.deepEqual(policyReceipts(), []);
    assert.equal(
      h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM accounts").get().n,
      legacyAccounts,
    );
    assert.equal(
      h.db.sqlite
        .prepare("SELECT display_name_ciphertext FROM accounts WHERE id=?")
        .get(fixtureAccount.id).display_name_ciphertext,
      legacyName,
    );
    const savePolicy = page.getByRole("button", {
      name: "Save and continue",
      exact: true,
    });
    await assertClickwrapBeforeAction(page, savePolicy, authMutationCount);
    assert.deepEqual(policyReceipts(), []);
    await savePolicy.click();
    await page.locator("#project-name").waitFor();
    const receipt = policyReceipts()[0];
    assert.equal(policyReceipts().length, 1);
    assert.equal(receipt.authorized_at, h.db.now);
    assert.equal(
      receipt.privacy_notice_version,
      ACCOUNT_POLICY.privacyNoticeVersion,
    );
    assert.equal(receipt.terms_version, ACCOUNT_POLICY.termsVersion);
    assert.equal(receipt.purpose_version, ACCOUNT_POLICY.purposeVersion);
    const policyBody = {
      ...ACCOUNT_POLICY,
      accountDataAuthorized: true,
      termsAccepted: true,
      cookiesNoticeVersion: ACCOUNT_COOKIES_NOTICE_VERSION,
      cookiesNoticeAcknowledged: true,
    };
    assert.deepEqual(
      state.requests.filter((request) => request.action === "policy").at(-1)
        .body,
      policyBody,
    );
    h.db.now += 1_000;
    const duplicate = await page.evaluate(async (body) => {
      const response = await fetch("/api/account/policy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      return { status: response.status, body: await response.json() };
    }, policyBody);
    assert.equal(duplicate.status, 200);
    assert.equal(duplicate.body.policyAuthorizationRequired, false);
    assert.deepEqual(
      policyReceipts(),
      [receipt],
      "Same-version retry cannot create or redate a receipt",
    );
    // A later requirement in the same document needs another explicit action;
    // merely rendering the notice cannot reuse or silently backfill a grant.
    await page
      .locator("#project-name")
      .fill("Draft kept through policy review");
    const policyWrites = state.requests.filter(
      (request) => request.action === "policy",
    ).length;
    h.db.sqlite.exec("DELETE FROM account_policy_authorizations");
    await page.evaluate(() =>
      document.dispatchEvent(new Event("visibilitychange")),
    );
    await policyHeading().waitFor();
    await assertPolicyNotice(page);
    assert.equal(await savePolicy.isEnabled(), true);
    assert.equal(await page.locator("#project-name").count(), 0);
    assert.equal(
      state.requests.filter((request) => request.action === "policy").length,
      policyWrites,
    );
    assert.deepEqual(policyReceipts(), []);
    await assertClickwrapBeforeAction(page, savePolicy, authMutationCount);
    await savePolicy.click();
    await page.locator("#project-name").waitFor();
    assert.equal(
      await page.locator("#project-name").inputValue(),
      "Draft kept through policy review",
    );
    assert.equal(policyReceipts().length, 1);
    assert.equal(policyReceipts()[0].authorized_at, h.db.now);
    console.log(
      "PASS account policy: no backfill before explicit continue; fresh rights without acceptance; idempotent DB-time receipt; later review preserves draft",
    );
    await page.locator("#project-name").fill("Google file preservation");
    await continueQuestion(page);
    await page.getByRole("button", { name: /I'm exploring the idea/ }).click();
    await expectQuestion(page, "attachments");
    const attachmentBytes = minimalDocx(
      "Private local attachment: 001, á, 끝.",
    );
    const chooser = page.waitForEvent("filechooser");
    await page.getByRole("button", { name: "Add local files" }).click();
    await (
      await chooser
    ).setFiles({
      name: "google-preserved.docx",
      mimeType:
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      buffer: attachmentBytes,
    });
    await page
      .getByRole("button", {
        name: "Remove google-preserved.docx",
        exact: true,
      })
      .waitFor();
    await page.evaluate(async (marker) => {
      await navigator.serviceWorker.ready;
      window.__googleDocumentMarker = marker;
      window.__googleOriginalOpen = window.open;
      window.open = () => null;
    }, mainMarker);
    const beforePrivacyChoice = {
      sessions: h.db.sqlite
        .prepare("SELECT COUNT(*) AS n FROM account_sessions")
        .get().n,
      receipt: policyReceipts(),
      quota: h.db.sqlite
        .prepare("SELECT COUNT(*) AS n FROM export_authorizations")
        .get().n,
    };
    const { preferenceBefore } = await rejectNonEssentialCookies(
      page,
      authMutationCount,
    );
    assert.equal(preferenceBefore, null);
    assert.deepEqual(
      {
        sessions: h.db.sqlite
          .prepare("SELECT COUNT(*) AS n FROM account_sessions")
          .get().n,
        receipt: policyReceipts(),
        quota: h.db.sqlite
          .prepare("SELECT COUNT(*) AS n FROM export_authorizations")
          .get().n,
      },
      beforePrivacyChoice,
      "Rejecting optional cookies leaves account, policy receipt and quota unchanged",
    );
    await page
      .getByRole("button", {
        name: "Remove google-preserved.docx",
        exact: true,
      })
      .waitFor();
    assert.equal(
      await page.evaluate(() => window.__googleDocumentMarker),
      mainMarker,
    );
    assert.equal(
      await page.evaluate(() => navigator.serviceWorker.controller !== null),
      true,
    );
    const editorUrl = page.url();
    // No provider proof has completed in this sign-in flow. Cancelling or
    // failing it must leave the missing receipt missing until proof succeeds.
    h.db.sqlite.exec("DELETE FROM account_policy_authorizations");
    const authRequestsBeforeReauthentication = state.authRequests.length;
    await expireSession();
    await checkLayouts();
    assert.equal(
      state.authRequests.length,
      authRequestsBeforeReauthentication,
      "Expired session, notices and locale changes never start Google automatically",
    );
    assert.equal(
      await page.locator("#web-email").count(),
      0,
      "Unavailable OTP must not be offered",
    );
    assert.equal(
      await page
        .getByRole("button", { name: "Send code", exact: true })
        .count(),
      0,
    );
    const requestsBeforeBlockedPopup = state.authRequests.length;
    await assertGoogleClickwrap();
    await googleButton().click();
    await page
      .getByRole("alert")
      .filter({ hasText: "Allow a window for sign-in" })
      .waitFor();
    assert.equal(
      state.authRequests.length,
      requestsBeforeBlockedPopup,
      "Popup blockage is detected before starting a transaction",
    );
    assert.equal(page.url(), editorUrl);
    assert.deepEqual(policyReceipts(), []);

    await page.evaluate(() => {
      window.open = window.__googleOriginalOpen;
      window.__googleOriginalPut = IDBObjectStore.prototype.put;
      window.__googleOriginalSetItem = Storage.prototype.setItem;
      // A working journal is now a durable fallback. This failure case must
      // reject both stores, rather than treating successful journal saving as loss.
      Storage.prototype.setItem = function (...args) {
        if (args[0] === "accreatio:account-draft:v1")
          throw new DOMException("Synthetic quota", "QuotaExceededError");
        return window.__googleOriginalSetItem.apply(this, args);
      };
      IDBObjectStore.prototype.put = function (...args) {
        if (this.name === "drafts")
          throw new DOMException("Synthetic quota", "QuotaExceededError");
        return window.__googleOriginalPut.apply(this, args);
      };
    });
    const requestsBeforeFailedAttachmentFlush = state.authRequests.length;
    const sessionsBeforeFailedAttachmentFlush = h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM account_sessions")
      .get().n;
    const quotaBeforeFailedAttachmentFlush = h.db.sqlite
      .prepare("SELECT COUNT(*) AS n FROM export_authorizations")
      .get().n;
    const failedFlushPopup = await popup();
    assert.equal(
      state.authRequests.length,
      requestsBeforeFailedAttachmentFlush + 1,
      "A real popup may start sign-in while the attached draft stays in memory",
    );
    assert.equal(state.authRequests.at(-1).mode, "popup");
    assert.equal(page.url(), editorUrl);
    assert.equal(
      await page.evaluate(() => window.__googleDocumentMarker),
      mainMarker,
      "Failed persistence must never replace the document holding attachment bytes",
    );
    await failedFlushPopup.close();
    await page
      .getByRole("button", { name: "Cancel sign-in", exact: true })
      .click();
    await page.waitForFunction(
      () => !document.querySelector(".web-signin__google-button")?.disabled,
    );
    assert.equal(transaction()[1].status, "failed");
    assert.equal(
      h.db.sqlite.prepare("SELECT COUNT(*) AS n FROM account_sessions").get().n,
      sessionsBeforeFailedAttachmentFlush,
      "Starting and explicitly cancelling the popup issues no session",
    );
    assert.equal(
      h.db.sqlite
        .prepare("SELECT COUNT(*) AS n FROM export_authorizations")
        .get().n,
      quotaBeforeFailedAttachmentFlush,
      "A failed flush and cancelled sign-in consume no export allowance",
    );
    assert.deepEqual(policyReceipts(), []);
    assert.equal(
      await page.evaluate(() => window.__googleDocumentMarker),
      mainMarker,
    );
    await page.evaluate(() => {
      IDBObjectStore.prototype.put = window.__googleOriginalPut;
      Storage.prototype.setItem = window.__googleOriginalSetItem;
    });

    const cancelled = await popup();
    assert.equal(state.authRequests.at(-1).mode, "popup");
    // COOP may report the handle as closed while this real page is still open.
    // Closing it explicitly also must never be interpreted as successful login.
    await cancelled.close();
    await page
      .getByText("Complete sign-in in the Google window.", { exact: false })
      .waitFor();
    assert.equal(await accountTrigger().count(), 0);
    await page
      .getByRole("button", { name: "Cancel sign-in", exact: true })
      .click();
    await page.waitForFunction(
      () => !document.querySelector(".web-signin__google-button")?.disabled,
    );
    assert.equal(transaction()[1].status, "failed");
    assert.deepEqual(
      policyReceipts(),
      [],
      "Cancellation without provider proof cannot create a receipt",
    );
    assert.equal(
      await page.evaluate(() => window.__googleDocumentMarker),
      mainMarker,
    );

    state.authStatusFailures = 1;
    const expiring = await popup();
    await page
      .getByText("Reconnecting to check sign-in.", { exact: false })
      .waitFor();
    transaction()[1].status = "expired";
    await page
      .getByRole("alert")
      .filter({ hasText: "Sign-in expired" })
      .waitFor();
    await expiring.close();
    assert.deepEqual(
      policyReceipts(),
      [],
      "Expired sign-in without provider proof cannot create a receipt",
    );
    assert.equal(page.url(), editorUrl);
    assert.equal(
      await page.evaluate(() => window.__googleDocumentMarker),
      mainMarker,
    );

    const completing = await popup();
    const id = transaction()[0];
    await completing.goto(`${target}/api/fixture/google/complete?state=${id}`);
    await completing
      .getByText("Sign-in completed. Return to your project tab.")
      .waitFor();
    await accountTrigger().waitFor();
    assert.equal(
      policyReceipts().length,
      1,
      "The successful identity callback records the explicit sign-in authorization",
    );
    assert.equal(
      (await accountTrigger().innerText()).trim(),
      fixtureDisplayName,
    );
    await page
      .getByRole("button", {
        name: "Remove google-preserved.docx",
        exact: true,
      })
      .waitFor();
    assert.equal(page.url(), editorUrl);
    assert.equal(
      await page.evaluate(() => window.__googleDocumentMarker),
      mainMarker,
    );
    await completing.close();
    await continueQuestion(page);
    const projectContext =
      "Confirm exact local bytes survive Google popup sign-in.";
    await page.locator("#project-context").fill(projectContext);
    await finishGuidedQuestions(page);
    await page.locator(".review-stage__dry-run input").uncheck();
    await page.locator(".review-stage__confirm").getByRole("button").click();
    const downloaded = page.waitForEvent("download");
    await page.locator("dialog .modal-actions .confirm").click();
    const files = await inspectProjectZip(
      await downloaded,
      "Google file preservation",
      projectContext,
    );
    const preserved = [...files].find(([name]) =>
      name.endsWith("/google-preserved.docx"),
    );
    assert.ok(
      preserved,
      "Attachment must be present in the actual downloaded ZIP",
    );
    assertSameDocxParts(preserved[1], attachmentBytes);
    assert.ok(
      state.authRequests.every(
        (body) =>
          Object.keys(body).sort().join() ===
          (body.purpose === "account_access"
            ? `mode,purpose,returnRoute${body.rightsOnly ? ",rightsOnly" : ""}${body.verificationAction ? ",verificationAction" : ""}`
            : "mode,policyAuthorization,purpose,returnRoute"),
      ),
    );
    assert.ok(
      state.authRequests.every(
        (body) =>
          (body.mode === "popup" || body.purpose === "account_access") &&
          (body.purpose === "sign_in" || body.purpose === "account_access") &&
          body.returnRoute === "builder",
      ),
    );
    for (const body of state.authRequests.filter(
      (body) => body.purpose === "sign_in",
    ))
      assert.deepEqual(body.policyAuthorization, {
        ...ACCOUNT_POLICY,
        accountDataAuthorized: true,
        termsAccepted: true,
      });
    await page.screenshot({
      path: path.join(output, "google-preserved-bytes-390.png"),
      fullPage: true,
    });
    // The Privacy UI requests an independent rights proof without replacing
    // the ordinary session or adopting its identity into the project draft.
    h.db.now += 301_000;
    const { data: accountData } = await downloadPrivacyData();
    assert.equal(accountData.email, "google-ui@gmail.com");
    assert.equal(accountData.displayName, fixtureDisplayName);
    assert.equal(
      await page.evaluate(() => window.__googleDocumentMarker),
      mainMarker,
    );
    h.db.now += 301_000;
    await openAccountMenu();
    await page
      .getByRole("button", { name: "Delete account", exact: true })
      .click();
    await page
      .getByRole("button", { name: "Confirm deletion", exact: true })
      .click();
    await page
      .getByRole("alert")
      .filter({ hasText: "Sign in again to download your account data" })
      .waitFor();
    assert.equal(
      h.db.sqlite
        .prepare(
          "SELECT COUNT(*) AS n FROM accounts WHERE deleted_at IS NOT NULL",
        )
        .get().n,
      0,
    );
    const deleteRecoveryPopup = await popup(true);
    await deleteRecoveryPopup.goto(
      `${target}/api/fixture/google/complete?state=${transaction()[0]}`,
    );
    await accountTrigger().waitFor();
    await deleteRecoveryPopup.close();

    // Deliberately discard the attached draft before testing principal OAuth
    // navigation. Its latest replacement fields must be durably saved first.
    await page
      .getByRole("button", { name: "Edit and export again", exact: true })
      .click();
    page.once("dialog", (dialog) => dialog.accept());
    await page
      .getByRole("button", { name: /New draft/ })
      .first()
      .click();
    await page.locator("#project-name").fill("Latest saved Google draft");
    await expireSession();
    const requestsBeforeFailedFlush = state.authRequests.length;
    await page.evaluate(() => {
      Storage.prototype.setItem = function (...args) {
        if (args[0] === "accreatio:account-draft:v1")
          throw new DOMException("Synthetic quota", "QuotaExceededError");
        return window.__googleOriginalSetItem.apply(this, args);
      };
      IDBObjectStore.prototype.put = function (...args) {
        if (this.name === "drafts")
          throw new DOMException("Synthetic quota", "QuotaExceededError");
        return window.__googleOriginalPut.apply(this, args);
      };
    });
    await assertGoogleClickwrap();
    await googleButton().click();
    await page
      .getByRole("alert")
      .filter({ hasText: "We could not save your latest changes" })
      .waitFor();
    assert.equal(state.authRequests.length, requestsBeforeFailedFlush);
    assert.equal(new URL(page.url()).origin, target);
    await page.evaluate(() => {
      IDBObjectStore.prototype.put = window.__googleOriginalPut;
      Storage.prototype.setItem = window.__googleOriginalSetItem;
    });
    // This static same-origin document mounts no app and cannot autosave over
    // the draft. Read the committed record before fulfilling the external
    // provider navigation, after the app's explicit flush has completed.
    const storageReader = await context.newPage();
    await storageReader.goto(`${target}/api/fixture/google/done`);
    const draftEvidence = {
      expectedName: "Latest saved Google draft",
      durableBeforeProviderNavigation: null,
      readError: null,
      firstRenderedName: null,
      hydratedName: null,
      durableAfterCallback: null,
      heldReadName: null,
      editorBlockedUntilHydration: null,
    };
    inspectPrincipalNavigation = async () => {
      try {
        draftEvidence.durableBeforeProviderNavigation =
          await readDurableBrowserDraft(storageReader);
      } catch (error) {
        draftEvidence.readError = String(error);
      }
    };
    await assertGoogleClickwrap();
    await googleButton().click();
    await page.waitForURL("https://accounts.google.com/**");
    inspectPrincipalNavigation = null;
    await storageReader.close();
    await writeFile(
      path.join(output, "google-draft-hydration-receipt.json"),
      JSON.stringify({ phase: "before-callback", ...draftEvidence }, null, 2),
    );
    assert.equal(draftEvidence.readError, null);
    assert.equal(
      draftEvidence.durableBeforeProviderNavigation?.schemaVersion,
      5,
    );
    assert.equal(
      draftEvidence.durableBeforeProviderNavigation?.project.name,
      draftEvidence.expectedName,
      "Principal navigation requires the exact latest draft to be committed first",
    );
    assert.deepEqual(
      draftEvidence.durableBeforeProviderNavigation.project.attachments,
      [],
    );
    assert.equal(transaction()[1].mode, "redirect");
    // Delay delivery of the real IndexedDB read result until the test releases
    // it. Native data/transaction semantics remain real; no fake record or
    // product delay can hide an editable form racing its asynchronous restore.
    await page.addInitScript(() => {
      const originalGet = IDBObjectStore.prototype.get;
      const releases = [];
      window.__releaseDraftRead = () =>
        releases.splice(0).forEach((release) => release());
      IDBObjectStore.prototype.get = function (...args) {
        const request = originalGet.apply(this, args);
        if (
          this.name !== "drafts" ||
          args[0] !== "account-current:v1" ||
          this.transaction.mode !== "readonly"
        )
          return request;
        IDBObjectStore.prototype.get = originalGet;
        const originalAdd = request.addEventListener;
        request.addEventListener = function (type, listener, options) {
          if (type !== "success")
            return originalAdd.call(this, type, listener, options);
          return originalAdd.call(
            this,
            type,
            (event) => {
              window.__draftReadHeld = true;
              window.__heldDraftReadName =
                request.result?.project?.name ?? null;
              releases.push(() =>
                typeof listener === "function"
                  ? listener.call(request, event)
                  : listener.handleEvent(event),
              );
            },
            options,
          );
        };
        return request;
      };
    });
    await page.goto(
      `${target}/api/fixture/google/complete?state=${transaction()[0]}`,
    );
    await page.waitForFunction(() => window.__draftReadHeld === true);
    draftEvidence.heldReadName = await page.evaluate(
      () => window.__heldDraftReadName,
    );
    assert.equal(
      draftEvidence.heldReadName,
      draftEvidence.expectedName,
      "The controlled native read contains the exact committed draft",
    );
    const hydrationView = await page.waitForFunction(() => {
      const loading = document.querySelector(
        'main[aria-busy="true"] [role="status"], main.web-signin [role="status"]',
      );
      const editor = document.querySelector("#project-name");
      if (!loading && !editor) return null;
      return {
        loading: loading?.textContent ?? null,
        editorExists: !!editor,
        editorValue: editor?.value ?? null,
      };
    });
    const pendingHydration = await hydrationView.jsonValue();
    draftEvidence.editorBlockedUntilHydration = !pendingHydration.editorExists;
    await writeFile(
      path.join(output, "google-draft-hydration-receipt.json"),
      JSON.stringify(
        { phase: "read-held", ...draftEvidence, pendingHydration },
        null,
        2,
      ),
    );
    assert.equal(
      pendingHydration.editorExists,
      false,
      "The project editor must not mount while its durable draft read is held",
    );
    assert.match(
      pendingHydration.loading,
      /^(Loading draft|Checking your secure session…)$/,
      "The account or draft loading boundary remains visible until the owned draft read completes",
    );
    await page.evaluate(() => window.__releaseDraftRead());
    await page.locator("#project-name").waitFor();
    draftEvidence.firstRenderedName = await page
      .locator("#project-name")
      .inputValue();
    // Wait for the exact observable restored state, not mere DOM presence.
    await page.waitForFunction(
      (expected) => document.querySelector("#project-name")?.value === expected,
      draftEvidence.expectedName,
    );
    draftEvidence.hydratedName = await page
      .locator("#project-name")
      .inputValue();
    draftEvidence.durableAfterCallback = await readDurableBrowserDraft(page);
    assert.equal(
      draftEvidence.hydratedName,
      draftEvidence.expectedName,
      "The restored editor must contain the exact pre-navigation project name",
    );
    assert.equal(
      draftEvidence.durableAfterCallback?.project.name,
      draftEvidence.expectedName,
      "The callback must preserve the durable record as well as the rendered input",
    );
    assert.equal(
      new URL(page.url()).searchParams.has("auth"),
      false,
      "Callback status is removed from the application URL",
    );
    await writeFile(
      path.join(output, "google-draft-hydration-receipt.json"),
      JSON.stringify({ result: "PASS", ...draftEvidence }, null, 2),
    );

    const legal = await context.newPage();
    for (const documentName of ["privacy", "terms", "cookies"]) {
      await legal.goto(`${target}/legal/${documentName}.html`);
      await legal.locator("h1").first().waitFor();
      await legal
        .getByRole("link", { name: "aekr@aekr.io", exact: true })
        .first()
        .waitFor();
      assert.equal(
        await legal.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
        true,
      );
      await legal.screenshot({
        path: path.join(output, `auth-${documentName}-390.png`),
        fullPage: true,
      });
    }
    await legal.close();
    assert.deepEqual(errors, []);
    await writeFile(
      path.join(output, "google-ui-receipt.json"),
      JSON.stringify(
        {
          result: "PASS",
          provider: "synthetic Google UI transport; no real Google login",
          cases: [
            "unavailable OTP hidden",
            "visible AEKR Terms and necessary-data notices; no checkboxes, state acceptance or writes before intentional sign-in",
            "pre-migration account gate never backfills authorization; account rights remain available",
            "fresh Google account_access without accepting updated terms preserves absent receipt, account and profile",
            "explicit policy grant records one current receipt with database time; retry does not redate",
            "later missing-receipt transition waits for explicit continue and keeps the current draft",
            "optional-cookie rejection persists locally and leaves session, account authorization, quota and attached bytes unchanged",
            "cancelled/expired Google attempts without identity proof leave no authorization receipt",
            "blocked popup before transaction",
            "failed browser flush preserves the current document in an explicitly cancelled popup without sessions or receipts; later ZIP verifies unchanged attachment bytes",
            "no opener under COOP",
            "closed popup never authenticates",
            "server cancellation",
            "network status retry and expiry",
            "active service worker",
            "main document and attachment bytes unchanged through reauthentication",
            "downloaded ZIP attachment bytes equal original",
            "minimal auth payloads",
            "encrypted display name appears in the header; full email and allowance are inside the account menu",
            "ES/EN Google login at 320/390/1280 without overflow",
            "data/deletion require fresh local authentication and preserve attached draft",
            "Google redirect without attachments follows confirmed persistence only",
            "latest draft fields survive principal OAuth navigation and callback URL is cleaned",
            "native IndexedDB result held at callback: no editable project until restore; exact durable name before navigation and after hydration",
            "public privacy, terms and cookies documents readable with owner-provided contact",
          ],
          attachmentBytes: attachmentBytes.length,
          errors,
        },
        null,
        2,
      ),
    );
    console.log(
      "PASS Google UI: popup/COOP, block/cancel/outage/expiry, active service worker and exact attachment bytes in downloaded ZIP",
    );
  } catch (error) {
    await page
      .screenshot({
        path: path.join(output, "google-ui-failure.png"),
        fullPage: true,
      })
      .catch(() => {});
    await writeFile(
      path.join(output, "google-ui-failure.txt"),
      await page
        .locator("body")
        .innerText()
        .catch(() => "Unavailable"),
    );
    throw error;
  } finally {
    await context.close();
  }
}
