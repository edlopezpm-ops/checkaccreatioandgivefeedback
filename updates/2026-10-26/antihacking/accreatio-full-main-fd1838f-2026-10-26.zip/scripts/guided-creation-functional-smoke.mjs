import assert from "node:assert/strict";
import { mkdir, readFile } from "node:fs/promises";
import { inflateRawSync } from "node:zlib";
import path from "node:path";

export const question = (page, current) =>
  page.locator(`.guided-creation__question[data-question="${current}"]`);

export async function expectQuestion(page, current) {
  await question(page, current).waitFor({ state: "visible" });
  assert.equal(await page.locator(".guided-creation__question").count(), 1);
  const help = page.locator(".project-help__link");
  assert.equal(await help.count(), 1);
  assert.match((await help.innerText()).trim(), /^(?:help|ayuda)$/);
  const [surfaceBounds, helpBounds] = await Promise.all([
    page.locator(".guided-creation__surface").boundingBox(),
    help.boundingBox(),
  ]);
  assert.ok(
    helpBounds.y >= surfaceBounds.y + surfaceBounds.height - 1 &&
      Math.abs(helpBounds.x - surfaceBounds.x) < 20,
    "Contextual help belongs below the question at its left edge",
  );
}

export async function continueQuestion(page) {
  await page.locator(".guided-creation__continue").click();
}

export async function expectReadyAttachment(page, name) {
  // Both admitted and rejected rows have Remove. Its presence is not admission.
  const result = await page.waitForFunction((label) => {
    const button = [
      ...document.querySelectorAll("#project-attachments .attachments button"),
    ].find((element) => element.getAttribute("aria-label") === label);
    const row = button?.closest("span");
    if (row?.classList.contains("attachment-rejected"))
      return { state: "rejected", detail: row.innerText };
    return row?.querySelector(".attachment-ready") ? { state: "ready" } : null;
  }, `Remove ${name}`);
  const admission = await result.jsonValue();
  assert.equal(
    admission.state,
    "ready",
    `Expected admitted ${name}; ${admission.detail ?? admission.state}`,
  );
  await page.locator('#project-attachments[aria-busy="false"]').waitFor();
  assert.equal(
    await page
      .locator("#project-attachments .attachments > span")
      .filter({
        has: page.getByRole("button", { name: `Remove ${name}`, exact: true }),
      })
      .locator(".attachment-ready")
      .count(),
    1,
  );
}

export async function backQuestion(page) {
  await page
    .locator(".guided-creation__actions")
    .getByRole("button", {
      name: /^(Pregunta anterior|Previous question|Atrás|Back)$/,
    })
    .click();
}

export async function finishGuidedQuestions(page) {
  for (let index = 0; index < 10; index += 1) {
    const current = await page
      .locator(".guided-creation__question")
      .getAttribute("data-question");
    if (current === "review") return;
    if (current === "phase")
      await page
        .getByRole("button", {
          name: /Estoy empezando con una idea|I'm starting with an idea/,
        })
        .click();
    else if (current === "route")
      await page
        .getByRole("button", {
          name: /Con herramientas locales|With local tools/,
        })
        .click();
    else await continueQuestion(page);
  }
  throw new Error("Guided creation did not reach review");
}

export async function captureGuidedPage(page, name) {
  const directory = path.resolve(".local/logs/playwright");
  await mkdir(directory, { recursive: true });
  const guided = page.locator(".guided-creation");
  if (await guided.count()) {
    // Full-page screenshots retain fixed/sticky elements at the current scroll
    // offset. Normalize the viewport so hidden skip links and the header are
    // captured in their actual top-of-page positions.
    await guided.evaluate((element) => {
      element.querySelector("h1")?.focus({ preventScroll: true });
      window.scrollTo({ top: 0, left: 0, behavior: "instant" });
    });
    await guided.evaluate(async (element) => {
      await Promise.all(
        element
          .getAnimations({ subtree: true })
          .filter((animation) =>
            Number.isFinite(animation.effect?.getComputedTiming().endTime),
          )
          .map((animation) => animation.finished.catch(() => {})),
      );
      await new Promise((resolve) => requestAnimationFrame(resolve));
    });
    if (await question(page, "review").count()) {
      const progress = await page
        .getByRole("progressbar")
        .evaluate((element) => ({
          current: element.getAttribute("aria-valuenow"),
          total: element.getAttribute("aria-valuemax"),
          fraction:
            element.firstElementChild.getBoundingClientRect().width /
            element.getBoundingClientRect().width,
        }));
      assert.equal(progress.current, progress.total);
      assert.ok(
        Math.abs(progress.fraction - 1) < 0.01,
        "The final progress bar must be visually complete",
      );
    }
  }
  await page.screenshot({
    path: path.join(directory, `${name}.png`),
    fullPage: true,
  });
}

export async function confirmReview(page) {
  await page.locator(".review-stage__confirm").getByRole("button").click();
}

export async function checkNightTheme(page) {
  await page.waitForFunction(
    () => document.documentElement.dataset.theme === "light",
  );
  assert.equal(await page.locator("html").getAttribute("data-theme"), "light");
  const themeToggle = page.getByRole("button", {
    name: /Switch to (light|dark) theme|Cambiar a tema (claro|oscuro)/,
  });
  assert.equal(await themeToggle.count(), 1);
  await themeToggle.click();
  await page.waitForFunction(
    () =>
      document.documentElement.dataset.theme === "dark" &&
      localStorage.getItem("accreatio:theme") === "dark",
  );
  assert.equal(
    await page.locator('meta[name="theme-color"]').getAttribute("content"),
    "#242726",
  );
  const darkLogo = await page.evaluate(async () => {
    const element = document.querySelector(".app-header .formation-mark img");
    const url = getComputedStyle(element).content.match(
      /url\(["']?(.*?)["']?\)/,
    )?.[1];
    if (!url) throw new Error("Dark logo URL is absent");
    const image = new Image();
    image.src = url;
    await image.decode();
    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    const context = canvas.getContext("2d");
    context.drawImage(image, 0, 0);
    const { data } = context.getImageData(0, 0, canvas.width, canvas.height);
    let red = 0;
    let light = 0;
    for (let index = 0; index < data.length; index += 4) {
      if (data[index + 3] < 200) continue;
      if (data[index] > 150 && data[index + 1] < 100 && data[index + 2] < 110)
        red++;
      if (data[index] > 200 && data[index + 1] > 200 && data[index + 2] > 200)
        light++;
    }
    const corners = [
      [0, 0],
      [canvas.width - 1, 0],
      [0, canvas.height - 1],
      [canvas.width - 1, canvas.height - 1],
    ];
    return {
      red,
      light,
      cornerAlpha: corners.map(
        ([x, y]) => data[(y * canvas.width + x) * 4 + 3],
      ),
    };
  });
  assert.deepEqual(
    darkLogo.cornerAlpha,
    [0, 0, 0, 0],
    "Dark logo must not retain an opaque background plate",
  );
  assert.ok(
    darkLogo.red > 0 && darkLogo.light > 0,
    "Dark logo must retain the red accent and readable light lettering",
  );
  await themeToggle.click();
  await page.waitForFunction(
    () =>
      document.documentElement.dataset.theme === "light" &&
      localStorage.getItem("accreatio:theme") === "light",
  );
  assert.equal(
    await page.locator('meta[name="theme-color"]').getAttribute("content"),
    "#e8eae7",
  );
}

export async function checkProjectSummary(page, expected) {
  const summary = page.locator(".summary-drawer--web");
  await summary.waitFor();
  const wasOpen = await summary.evaluate((element) => element.open);
  if (!wasOpen) await summary.locator(":scope > summary").click();
  const rows = await summary
    .locator("dl > div")
    .evaluateAll((elements) =>
      Object.fromEntries(
        elements.map((element) => [
          element.querySelector("dt").textContent.trim(),
          element.querySelector("dd").textContent.trim(),
        ]),
      ),
    );
  for (const [label, value] of Object.entries(expected)) {
    if (value === null)
      assert.equal(
        rows[label],
        undefined,
        `${label} must not appear before its answer`,
      );
    else
      assert.equal(
        rows[label],
        String(value),
        `Incorrect project summary: ${label}`,
      );
  }
  if (!wasOpen) await summary.locator(":scope > summary").click();
}

async function checkReviewDetails(page, projectName, context) {
  const overview = page.locator(".review-overview");
  await overview
    .getByRole("heading", { name: projectName, exact: true })
    .waitFor({ state: "visible" });
  assert.ok(
    (await overview.textContent()).includes(context.slice(0, 220)),
    "The review summary must show the user's answer before expanding technical details",
  );
  assert.equal(await overview.locator("dl > div").count(), 6);
  for (const id of ["review-manifest", "review-plan", "review-prompt"]) {
    const details = page.locator(`#${id}`);
    assert.equal(
      await details.evaluate((element) => element.tagName),
      "DETAILS",
    );
    assert.equal(
      await details.getAttribute("open"),
      null,
      `${id} must start collapsed`,
    );
    await details.locator(":scope > summary").click();
    assert.equal(await details.evaluate((element) => element.open), true);
    if (id === "review-manifest") {
      await details.locator(".review-manifest").waitFor({ state: "visible" });
      assert.ok(
        await details.locator(".review-manifest__grid article").count(),
      );
    } else if (id === "review-plan") {
      assert.ok(
        await details.locator("li").count(),
        "The complete deterministic plan remains available",
      );
    } else {
      await details.locator("pre").waitFor({ state: "visible" });
      const prompt = await details.locator("pre").textContent();
      assert.ok(prompt.includes(projectName));
      assert.ok(prompt.includes(context));
    }
    await details.locator(":scope > summary").click();
    assert.equal(await details.getAttribute("open"), null);
  }
}

async function checkPrimaryContrast(page) {
  for (const hovered of [false, true]) {
    const button = page.locator(".guided-creation__continue");
    if (hovered) await button.hover();
    else await page.mouse.move(0, 0);
    await button.evaluate(async (element) => {
      await Promise.all(
        element
          .getAnimations({ subtree: true })
          .filter((animation) =>
            Number.isFinite(animation.effect?.getComputedTiming().endTime),
          )
          .map((animation) => animation.finished.catch(() => {})),
      );
    });
    const colors = await page
      .locator(".guided-creation__continue")
      .evaluate((element) => {
        const style = getComputedStyle(element);
        return { foreground: style.color, background: style.backgroundColor };
      });
    const luminance = (color) => {
      const channels = color.match(/[\d.]+/g)?.map(Number);
      assert.ok(
        channels && channels.length >= 3,
        `Unrecognized button color: ${color}`,
      );
      assert.ok(
        channels.length === 3 || channels[3] === 1,
        "CTA color must be opaque",
      );
      const linear = channels
        .slice(0, 3)
        .map((channel) => channel / 255)
        .map((channel) =>
          channel <= 0.04045
            ? channel / 12.92
            : ((channel + 0.055) / 1.055) ** 2.4,
        );
      return linear[0] * 0.2126 + linear[1] * 0.7152 + linear[2] * 0.0722;
    };
    const foreground = luminance(colors.foreground);
    const background = luminance(colors.background);
    const contrast =
      (Math.max(foreground, background) + 0.05) /
      (Math.min(foreground, background) + 0.05);
    assert.ok(
      contrast >= 4.5,
      `Primary ${hovered ? "hover" : "rest"} text contrast ${contrast.toFixed(2)}:1 falls below 4.5:1 (${JSON.stringify(colors)})`,
    );
  }
  await page.mouse.move(0, 0);
}

async function checkQuestionHeading(page) {
  await page.locator(".app-content").evaluate(async (element) => {
    await Promise.all(
      element
        .getAnimations({ subtree: true })
        .filter((animation) =>
          Number.isFinite(animation.effect?.getComputedTiming().endTime),
        )
        .map((animation) => animation.finished.catch(() => {})),
    );
  });
  // Native smooth scrolling is not a Web Animation. Wait for the focused title
  // to settle in the readable viewport, then retain the placement assertions.
  await page.waitForFunction(
    async () => {
      const title = document.querySelector(".guided-creation__question h1");
      const header = document.querySelector(".app-header");
      if (!title || !header) return false;
      const before = title.getBoundingClientRect();
      await new Promise((resolve) =>
        requestAnimationFrame(() => requestAnimationFrame(resolve)),
      );
      const after = title.getBoundingClientRect();
      return (
        document.activeElement === title &&
        Math.abs(before.top - after.top) < 0.5 &&
        after.top >= header.getBoundingClientRect().bottom &&
        after.bottom <= innerHeight
      );
    },
    undefined,
    { timeout: 5_000 },
  );
  const placement = await page
    .locator(".guided-creation__question")
    .evaluate(async (element) => {
      await Promise.all(
        element
          .getAnimations({ subtree: true })
          .filter((animation) =>
            Number.isFinite(animation.effect?.getComputedTiming().endTime),
          )
          .map((animation) => animation.finished.catch(() => {})),
      );
      const title = element.querySelector("h1");
      const bounds = title.getBoundingClientRect();
      return {
        focused: document.activeElement === title,
        titleTop: bounds.top,
        titleBottom: bounds.bottom,
        headerBottom: document
          .querySelector(".app-header")
          .getBoundingClientRect().bottom,
        viewportHeight: window.innerHeight,
      };
    });
  assert.ok(placement.focused, "Each new question must receive heading focus");
  assert.ok(
    placement.titleTop >= placement.headerBottom &&
      placement.titleBottom <= placement.viewportHeight,
    `The focused question must fit below the sticky header: ${JSON.stringify(placement)}`,
  );
}

export async function checkGuidedJourney(
  page,
  { locale = "en", width = 1280, reducedMotion = false } = {},
) {
  const es = locale === "es";
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  assert.equal(await page.locator("html").getAttribute("lang"), "en");
  if (es) await page.getByRole("button", { name: "Switch to Spanish" }).click();
  await checkNightTheme(page);
  await page
    .getByRole("button", {
      name: es ? "Nuevo proyecto" : "New project",
      exact: true,
    })
    .click();
  await expectQuestion(page, "name");
  await page
    .getByRole("heading", {
      name: es ? "¿Cómo se llama tu proyecto?" : "What is your project called?",
    })
    .waitFor();
  await continueQuestion(page);
  await expectQuestion(page, "name");
  assert.equal(
    await page.locator("#project-name").getAttribute("aria-invalid"),
    "true",
  );
  await page.waitForFunction(
    () => document.activeElement?.id === "project-name",
  );
  assert.equal(
    await page.evaluate(() => document.activeElement?.id),
    "project-name",
  );
  const projectName = `Guided ${locale} ${width}`;
  assert.equal(
    await page.locator("#project-name").getAttribute("maxlength"),
    "50",
  );
  await page.locator("#project-name").fill("N".repeat(51));
  assert.equal(
    await page.locator("#project-name").inputValue(),
    "N".repeat(50),
  );
  assert.equal(
    (await page.locator(".guided-basics__count").textContent()).trim(),
    "50/50",
  );
  await page.locator("#project-name").fill(projectName);
  const workingUrl = page.url();
  const help = page.locator(".project-help__link");
  await help.click();
  const helpDialog = page.getByRole("dialog", {
    name: es ? "Ayuda paso a paso" : "Step-by-step help",
    exact: true,
  });
  await helpDialog.waitFor();
  assert.equal(
    await helpDialog.locator(".help-tips__slide img").getAttribute("src"),
    `/help/${locale}/name.jpg`,
  );
  assert.equal(page.url(), workingUrl);
  assert.equal(await page.locator("#project-name").inputValue(), projectName);
  for (const surface of [helpDialog, page.locator("html")]) {
    assert.equal(
      await surface.evaluate((element) => element.scrollWidth <= innerWidth),
      true,
    );
  }
  await page.keyboard.press("Escape");
  await helpDialog.waitFor({ state: "detached" });
  assert.equal(
    await help.evaluate((element) => element === document.activeElement),
    true,
  );
  const aboutTrigger = page.locator(".product-nav").getByRole("button", {
    name: es ? "Acerca de" : "About",
    exact: true,
  });
  // Reserve the classic desktop scrollbar gutter at narrow widths, matching
  // the in-app browser where innerWidth exceeds the actual layout viewport.
  const scrollbarStyle =
    width < 768
      ? await page.addStyleTag({
          content: "html{scrollbar-gutter:stable;overflow-y:scroll}",
        })
      : null;
  await aboutTrigger.click();
  const about = page.locator("#about-popover");
  await about.waitFor();
  const aboutInformation = await about.innerText();
  assert.match(aboutInformation, /AEKR/);
  assert.doesNotMatch(
    aboutInformation,
    /Ed Lopez|Free authorized private-use license|Licencia privada de uso autorizado gratuito/i,
  );
  await about.getByRole("button", { name: "FAQ", exact: true }).click();
  await about.locator("#about-faq-title").waitFor();
  assert.equal(
    await about.evaluate((element) => element.scrollWidth <= innerWidth),
    true,
  );
  const geometry = await about.evaluate((element) => {
    const bounds = element.getBoundingClientRect();
    return {
      left: bounds.left,
      right: bounds.right,
      clientWidth: document.documentElement.clientWidth,
      innerWidth,
    };
  });
  if (scrollbarStyle) assert.ok(geometry.clientWidth < geometry.innerWidth);
  assert.ok(
    geometry.left >= 0 && geometry.right <= geometry.clientWidth,
    `About must fit inside the actual layout viewport: ${JSON.stringify(geometry)}`,
  );
  assert.equal(page.url(), workingUrl);
  assert.equal(await page.locator("#project-name").inputValue(), projectName);
  await about
    .getByRole("button", {
      name: es ? "Cerrar About" : "Close About",
      exact: true,
    })
    .click();
  await about.waitFor({ state: "detached" });
  assert.equal(
    await aboutTrigger.evaluate(
      (element) => element === document.activeElement,
    ),
    true,
  );
  await scrollbarStyle?.evaluate((element) => element.remove());
  await expectQuestion(page, "name");
  await page
    .locator(".guided-creation__feedback")
    .waitFor({ state: "detached" });
  assert.equal(
    await page.locator("#project-name").getAttribute("aria-invalid"),
    "false",
  );
  await checkPrimaryContrast(page);
  await captureGuidedPage(page, `guided-${locale}-${width}-name`);
  await page.locator("#project-name").press("Enter");
  await expectQuestion(page, "phase");
  await backQuestion(page);
  await expectQuestion(page, "name");
  assert.equal(await page.locator("#project-name").inputValue(), projectName);
  await continueQuestion(page);
  await expectQuestion(page, "phase");
  await page
    .getByRole("button", {
      name: /Estoy empezando con una idea|I'm starting with an idea/,
    })
    .click();
  await expectQuestion(page, "context");
  // Back is always available, even before the current required answer exists.
  await backQuestion(page);
  await expectQuestion(page, "phase");
  await page
    .getByRole("button", {
      name: /Estoy empezando con una idea|I'm starting with an idea/,
    })
    .click();
  await expectQuestion(page, "context");
  await continueQuestion(page);
  await expectQuestion(page, "context");
  assert.equal(
    await page.locator("#project-context").getAttribute("aria-invalid"),
    "true",
  );
  await page.waitForFunction(
    () => document.activeElement?.id === "project-context",
  );
  assert.equal(
    await page.evaluate(() => document.activeElement?.id),
    "project-context",
  );
  const context = es
    ? "Una app local para organizar un huerto.\nDebe funcionar sin conexión."
    : "A local app to organize a garden.\nIt must work offline.";
  await page.locator("#project-context").fill(context);
  await page
    .locator(".guided-creation__feedback")
    .waitFor({ state: "detached" });
  assert.equal(
    await page.locator("#project-context").getAttribute("aria-invalid"),
    "false",
  );
  await page.locator("#project-context").press("Enter");
  await expectQuestion(page, "context");
  await continueQuestion(page);
  await expectQuestion(page, "restrictions");
  await page
    .locator(".guided-creation__continue")
    .getByText(es ? "Revisar mi proyecto" : "Review my project")
    .waitFor();
  await continueQuestion(page);
  await expectQuestion(page, "review");
  await checkQuestionHeading(page);
  assert.equal(
    await page.getByRole("progressbar").getAttribute("aria-valuemax"),
    "5",
  );
  assert.equal(
    await page
      .getByRole("checkbox", {
        name: /Comprobar el paquete sin descargar|Check the package without downloading/,
      })
      .isChecked(),
    true,
  );
  await checkReviewDetails(page, projectName, context);
  await page
    .locator(".review-stage__status")
    .getByRole("button", { name: /^(Contexto|Context) ·/ })
    .click();
  await expectQuestion(page, "context");
  assert.equal(
    (await page.locator("#project-context").inputValue()).trim(),
    context,
  );
  await page.locator("#project-context").fill(`${context}\nReviewed.`);
  await page
    .getByRole("button", {
      name: /Volver a revisión|Back to review|Return to review/,
    })
    .click();
  await expectQuestion(page, "review");
  await checkReviewDetails(page, projectName, `${context}\nReviewed.`);
  assert.equal(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    true,
    `No horizontal overflow at ${width}px`,
  );
  if (reducedMotion) {
    const durations = await page
      .locator(".guided-creation__question")
      .evaluate((element) =>
        getComputedStyle(element).animationDuration.split(",").map(parseFloat),
      );
    assert.ok(
      durations.every((duration) => duration <= 0.001),
      "Reduced motion must disable question animation",
    );
  }
  await captureGuidedPage(
    page,
    `guided-${locale}-${width}-review${reducedMotion ? "-reduced" : ""}`,
  );
  let downloads = 0;
  page.on("download", () => {
    downloads += 1;
  });
  const dryChoice = () =>
    page.getByRole("checkbox", {
      name: /Comprobar el paquete sin descargar|Check the package without downloading/,
    });
  // Choose exactly once on Review; the final dialog can only confirm/cancel.
  await dryChoice().uncheck();
  await confirmReview(page);
  await page.getByRole("dialog").waitFor();
  assert.equal(await page.getByRole("dialog").getByRole("radio").count(), 0);
  await page
    .getByRole("dialog")
    .getByRole("button", { name: /Preparar ZIP|Prepare ZIP/, exact: true })
    .waitFor();
  assert.equal(downloads, 0, "ZIP choice alone must not download");
  await page.keyboard.press("Escape");
  await page.getByRole("dialog").waitFor({ state: "detached" });
  await expectQuestion(page, "review");
  assert.equal(
    await dryChoice().isChecked(),
    false,
    "Cancel must preserve the selected action",
  );
  await dryChoice().check();
  await confirmReview(page);
  assert.equal(await page.getByRole("dialog").getByRole("radio").count(), 0);
  await page
    .getByRole("dialog")
    .getByRole("button", { name: /Ejecutar revisión seca|Run dry review/ })
    .click();
  await page
    .getByRole("heading", {
      name: es
        ? "Revisión completada. No se creó ni descargó ningún ZIP."
        : "Review completed. No ZIP was created or downloaded.",
      exact: true,
    })
    .waitFor();
  assert.equal(downloads, 0, "Package check must not request a download");
  await page
    .getByRole("button", {
      name: /Volver a revisión|Back to review|Return to review/,
    })
    .click();
  await expectQuestion(page, "review");
  await confirmReview(page);
  await page
    .getByRole("dialog")
    .getByRole("button", { name: /Ejecutar revisión seca|Run dry review/ })
    .click();
  const directZip = page.getByRole("button", {
    name: es ? "Crear y descargar ZIP" : "Create and download ZIP",
    exact: true,
  });
  await directZip.waitFor();
  await directZip.click();
  await page.getByRole("dialog").waitFor();
  assert.equal(
    downloads,
    0,
    "Direct ZIP intent must require final confirmation",
  );
  assert.equal(await page.getByRole("dialog").getByRole("radio").count(), 0);
  await page.keyboard.press("Escape");
  await page.getByRole("dialog").waitFor({ state: "detached" });
  await directZip.waitFor();
  await page.waitForFunction(
    (label) => document.activeElement?.textContent.trim() === label,
    es ? "Crear y descargar ZIP" : "Create and download ZIP",
  );
  assert.equal(
    await directZip.evaluate((element) => document.activeElement === element),
    true,
    "Canceling ZIP confirmation must restore the initiating button focus",
  );
  assert.equal(downloads, 0, "Canceled ZIP must not download");
  await directZip.click();
  const downloadPromise = page.waitForEvent("download");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: /Preparar ZIP|Prepare ZIP/, exact: true })
    .evaluate((button) => {
      button.click();
      button.click();
      button.dispatchEvent(
        new KeyboardEvent("keydown", { key: "Enter", bubbles: true }),
      );
    });
  const download = await downloadPromise;
  assert.equal(await download.failure(), null);
  const files = await inspectProjectZip(
    download,
    projectName,
    `${context}\nReviewed.`,
  );
  await page.waitForTimeout(250);
  assert.equal(downloads, 1, "Repeated final activation must yield one ZIP");
  const start = [...files]
    .find(([name]) => name.endsWith("/START.md"))[1]
    .toString("utf8");
  const startingInstruction = (
    await page.locator(".outcome-next pre").textContent()
  ).trim();
  assert.ok(
    start.includes(startingInstruction),
    "UI starting instruction must equal the generated START contract",
  );
  const operationDetails = page
    .locator(".outcome-diagnostics")
    .filter({ has: page.locator(".outcome-evidence") });
  assert.equal(
    await operationDetails.evaluate((element) => element.open),
    false,
  );
  await operationDetails.locator(":scope > summary").click();
  await operationDetails
    .locator(".outcome-evidence")
    .waitFor({ state: "visible" });
  assert.ok(
    await operationDetails.locator("li").count(),
    "Operation evidence must remain inspectable",
  );
  await operationDetails.locator(":scope > summary").click();
  const retryPromise = page.waitForEvent("download");
  await page
    .getByRole("button", {
      name: /Volver a descargar este ZIP|Download this ZIP again/,
      exact: true,
    })
    .click();
  const retry = await retryPromise;
  assert.deepEqual(
    await readFile(await retry.path()),
    await readFile(await download.path()),
    "Retry must download the same retained ZIP bytes",
  );
  assert.equal(downloads, 2);
  await page
    .getByRole("button", {
      name: /Editar y volver a exportar|Edit and export again/,
    })
    .click();
  await expectQuestion(page, "review");
  assert.equal(await page.locator(".project-help__link").count(), 1);
  assert.deepEqual(errors, []);
  console.log(
    `PASS guided creation: ${locale}, ${width}px${reducedMotion ? ", reduced motion" : ""}, validation/back/review/keyboard/direct confirmed ZIP bytes`,
  );
}

// Observe the real renderer at its WebGL boundary. This keeps test switches and
// diagnostic state out of the production UI while exercising actual mouse input.
export async function observeNebula(page) {
  await page.addInitScript(() => {
    const observation = { picks: [], bursts: 0, lastBurst: null };
    window.__nebulaObservation = observation;
    const prototype = WebGLRenderingContext.prototype;
    const locations = new WeakMap();
    const previousByContext = new WeakMap();
    const getUniformLocation = prototype.getUniformLocation;
    prototype.getUniformLocation = function (program, name) {
      const location = getUniformLocation.call(this, program, name);
      if (location) locations.set(location, name);
      return location;
    };
    const uniform4fv = prototype.uniform4fv;
    prototype.uniform4fv = function (location, value, ...rest) {
      if (locations.get(location) === "u_bursts[0]") {
        const previous = previousByContext.get(this) ?? [];
        for (let slot = 0; slot < value.length; slot += 4) {
          if (
            value[slot + 3] > 0 &&
            (!(previous[slot + 3] > 0) ||
              value[slot + 2] < previous[slot + 2] - 0.05)
          ) {
            observation.bursts += 1;
            observation.lastBurst = Array.from(value.slice(slot, slot + 4));
          }
        }
        previousByContext.set(this, Array.from(value));
      }
      return uniform4fv.call(this, location, value, ...rest);
    };
    const readPixels = prototype.readPixels;
    prototype.readPixels = function (...args) {
      const result = readPixels.apply(this, args);
      if (args[2] === 1 && args[3] === 1 && ArrayBuffer.isView(args[6]))
        observation.picks.push(Array.from(args[6]));
      return result;
    };
  });
}

export async function checkNebulaInteraction(page) {
  const snapshot = () => page.evaluate(() => window.__nebulaObservation);
  const starting = await snapshot();
  await page.mouse.move(12, 12);
  await page.mouse.move(800, 600, { steps: 12 });
  await page.waitForTimeout(120);
  assert.deepEqual(await snapshot(), starting, "Hover must not pick or burst");
  assert.equal(await page.locator(".cursor-nebula").count(), 0);
  assert.deepEqual(
    await page
      .locator(".atmosphere")
      .evaluate((element) => [
        element.style.getPropertyValue("--nebula-pointer-x"),
        element.style.getPropertyValue("--nebula-pointer-y"),
      ]),
    ["", ""],
  );

  // Select genuine uncovered layout points; never synthesize clicks through a
  // foreground panel. Both empty space and visible gas must exist and differ.
  const exposed = await page.evaluate(() => {
    const points = [];
    for (let y = 20; y < innerHeight; y += 70)
      for (let x = 12; x < innerWidth; x += 70) {
        const element = document.elementFromPoint(x, y);
        if (
          element?.matches(
            "body, #root, .app-shell, .app-content, main, .creation-workspace, .creation-layout",
          ) &&
          !element.closest(
            "button, a, input, textarea, select, label, form, header, nav, dialog, [role], [contenteditable], .panel, .modal, .onboarding-card",
          )
        )
          points.push({ x, y });
      }
    return points;
  });
  assert.ok(exposed.length > 1, "The page must expose atmospheric background");
  let hit;
  let empty;
  for (const point of exposed) {
    const before = await snapshot();
    await page.mouse.click(point.x, point.y);
    await page.evaluate(
      () =>
        new Promise((resolve) =>
          requestAnimationFrame(() => requestAnimationFrame(resolve)),
        ),
    );
    const after = await snapshot();
    assert.equal(after.picks.length, before.picks.length + 1);
    if (after.bursts > before.bursts) {
      if (!hit) await captureGuidedPage(page, "nebula-visible-click");
      hit ??= point;
    } else empty ??= point;
    if (hit && empty) break;
  }
  assert.ok(hit, "A left click on visible gas must produce a burst");
  assert.ok(empty, "A left click on empty space must not produce a burst");
  const beforeRight = await snapshot();
  await page.mouse.click(hit.x, hit.y, { button: "right" });
  await page.keyboard.press("Escape");
  await page.waitForTimeout(100);
  assert.deepEqual(await snapshot(), beforeRight, "Right click must not react");

  const control = page.getByRole("button", { name: "Switch to Spanish" });
  const beforeControl = await snapshot();
  await control.click();
  await page.waitForTimeout(100);
  assert.deepEqual(
    await snapshot(),
    beforeControl,
    "A foreground control must not produce a background burst",
  );
  await page.getByRole("button", { name: "Cambiar a inglés" }).click();
  console.log(
    "PASS nebula: motion, no hover, visible gas, empty space, right click, UI exclusion",
  );
}

// Inspect downloaded ZIP bytes via its central directory rather than trusting
// only a suggested filename or an emitted download event.
export async function inspectProjectZip(download, name, context) {
  const bytes = await readFile(await download.path());
  const end = bytes.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  assert.ok(end >= 0, "A downloaded project must be a complete ZIP archive");
  const count = bytes.readUInt16LE(end + 10);
  let offset = bytes.readUInt32LE(end + 16);
  const files = new Map();
  for (let index = 0; index < count; index += 1) {
    assert.equal(bytes.readUInt32LE(offset), 0x02014b50);
    const method = bytes.readUInt16LE(offset + 10);
    const size = bytes.readUInt32LE(offset + 20);
    const nameLength = bytes.readUInt16LE(offset + 28);
    const extraLength = bytes.readUInt16LE(offset + 30);
    const commentLength = bytes.readUInt16LE(offset + 32);
    const local = bytes.readUInt32LE(offset + 42);
    const fileName = bytes
      .subarray(offset + 46, offset + 46 + nameLength)
      .toString("utf8");
    assert.equal(bytes.readUInt32LE(local), 0x04034b50);
    const dataStart =
      local +
      30 +
      bytes.readUInt16LE(local + 26) +
      bytes.readUInt16LE(local + 28);
    const compressed = bytes.subarray(dataStart, dataStart + size);
    assert.ok(method === 0 || method === 8, "Unexpected ZIP compression");
    assert.ok(!files.has(fileName), `Duplicate ZIP path: ${fileName}`);
    assert.ok(
      !fileName.startsWith("/") &&
        !fileName.includes("..") &&
        !fileName.includes("\\"),
      `Unsafe ZIP path: ${fileName}`,
    );
    files.set(fileName, method === 8 ? inflateRawSync(compressed) : compressed);
    offset += 46 + nameLength + extraLength + commentLength;
  }
  const find = (suffix) =>
    [...files].find(
      ([file]) => file === suffix || file.endsWith(`/${suffix}`),
    )?.[1];
  for (const suffix of [
    "START.md",
    "PROJECT_PROMPT.md",
    "docs/product/discovery.md",
    "docs/master.md",
    "AGENTS.md",
    ".accreatio/project.json",
    ".accreatio/contract.json",
  ])
    assert.ok(
      find(suffix)?.length,
      `Missing nonempty generated file: ${suffix}`,
    );
  assert.ok(find("PROJECT_PROMPT.md").toString("utf8").includes(name));
  assert.ok(find("PROJECT_PROMPT.md").toString("utf8").includes(context));
  const project = JSON.parse(find(".accreatio/project.json").toString("utf8"));
  assert.equal(project.projectName, name);
  assert.equal(project.governanceProfile, "Lean");
  assert.match(find("docs/master.md").toString("utf8"), /^Status: [A-Z_]+$/m);
  const contract = JSON.parse(
    find(".accreatio/contract.json").toString("utf8"),
  );
  const root = [...files.keys()]
    .find((file) => file.endsWith("/START.md"))
    .slice(0, -"START.md".length);
  for (const required of contract.requiredPaths) {
    assert.ok(
      files.has(root + required),
      `Missing package dependency: ${required}`,
    );
    if (!required.endsWith(".md")) continue;
    const content = files.get(root + required).toString("utf8");
    for (const match of content.matchAll(/\]\(([^)]+)\)/g)) {
      const target = match[1].split("#")[0];
      if (!target || /^https?:/.test(target)) continue;
      const resolved = path.posix.normalize(
        path.posix.join(root, path.posix.dirname(required), target),
      );
      assert.ok(
        files.has(resolved),
        `Unresolved package link: ${required} -> ${target}`,
      );
    }
  }
  assert.equal(contract.orchestration.enabled, project.orchestrationEnabled);
  if (!contract.orchestration.enabled) {
    assert.ok(
      ![...files.keys()].some(
        (file) =>
          file.startsWith(root + "orchestrator/") ||
          file.endsWith("orchestration.yaml"),
      ),
      "Basic ZIP must not impose runtime preparation",
    );
  }
  return files;
}
