import { handleAnalyticsProducer } from "../../_lib/analyticsProducer";
type Context = Parameters<typeof handleAnalyticsProducer>[0] & {
  params: { action: string };
};
export const onRequest = (context: Context) =>
  handleAnalyticsProducer(context, context.params.action);
