import type { AccountBindings, AccountDatabase } from "./accounts";
import {
  ApiError,
  jsonResponse,
  methodNotAllowed,
  readBoundedJson,
} from "./http";
import {
  COLLECTION_VERSION,
  COLLECTION_RETENTION_MS,
  COLLECTION_MAX_RECORDS,
  parseCollectionRecord,
  type CollectionPurpose,
} from "../../shared/collection";
const NOW = "(unixepoch()*1000)";
const VALID = `notice_version=? AND revoked_at IS NULL AND expires_at>${NOW}`;
const hex = (bytes: Uint8Array) =>
  Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
async function hash(token: string) {
  return hex(
    new Uint8Array(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token)),
    ),
  );
}
export async function cleanCollection(db: AccountDatabase) {
  // Compatibility with installations which have not applied migration 0009.
  if (
    !(await db
      .prepare(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='collection_permissions'",
      )
      .first())
  )
    return;
  const result = await db.batch([
    db.prepare(
      `DELETE FROM collection_records WHERE id IN (SELECT id FROM collection_records WHERE expires_at<=${NOW} LIMIT 500)`,
    ),
    db.prepare(
      `DELETE FROM collection_permissions WHERE token_hash IN (SELECT token_hash FROM collection_permissions WHERE expires_at<=${NOW} LIMIT 500)`,
    ),
  ]);
  if (result.some((r) => !r.success))
    throw new Error("collection_cleanup_failed");
}
/** No account/session authority is consumed. A purpose-limited capability permits
 * access/revocation only to new contributions made through this browser choice. */
export async function handleCollection(
  { request, env }: { request: Request; env: AccountBindings },
  action: "preference" | "record" | "data",
) {
  try {
    if (request.method === "GET" && action === "preference")
      return jsonResponse({
        enabled: env.COLLECT_ENABLED === "true",
        version: COLLECTION_VERSION,
        retentionDays: 30,
      });
    if (request.method !== "POST") return methodNotAllowed(["POST"]);
    const url = new URL(request.url);
    if (
      request.headers.get("Origin") !== url.origin ||
      request.headers.get("Sec-Fetch-Site") === "cross-site"
    )
      throw new ApiError(
        403,
        "collection_origin",
        "Use the same product origin.",
      );
    const body = (await readBoundedJson(request, 8192)) as Record<
      string,
      unknown
    >;
    if (!body || typeof body !== "object" || Array.isArray(body))
      throw new ApiError(
        400,
        "collection_invalid",
        "Invalid collection request.",
      );
    const purpose = body.purpose as CollectionPurpose;
    if (!["analytics", "research"].includes(purpose))
      throw new ApiError(400, "collection_purpose", "Unknown purpose.");
    const token = request.headers
      .get("Authorization")
      ?.match(/^Bearer ([0-9a-f]{64})$/)?.[1];
    const db = env.ACCOUNT_DB;
    if (!db)
      throw new ApiError(
        503,
        "collection_unavailable",
        "Collection storage is unavailable.",
      );
    // Revocation and rights remain available even while new collection is off.
    if (action === "preference" && body.action === "revoke") {
      if (Object.keys(body).sort().join() !== "action,purpose")
        throw new ApiError(400, "collection_invalid", "Invalid choice.");
      if (!token)
        throw new ApiError(
          401,
          "collection_proof",
          "A contribution capability is required.",
        );
      const key = await hash(token);
      const result = await db.batch([
        db
          .prepare(
            `INSERT OR IGNORE INTO collection_permissions(token_hash,purpose,notice_version,granted_at,expires_at,revoked_at) SELECT ?,?,?,${NOW},${NOW}+?,${NOW} WHERE (SELECT COUNT(*) FROM collection_permissions)<2000`,
          )
          .bind(key, purpose, COLLECTION_VERSION, COLLECTION_RETENTION_MS),
        db
          .prepare(
            `UPDATE collection_permissions SET revoked_at=${NOW} WHERE token_hash=? AND purpose=?`,
          )
          .bind(key, purpose),
        db
          .prepare(
            "DELETE FROM collection_records WHERE token_hash=? AND EXISTS(SELECT 1 FROM collection_permissions WHERE token_hash=? AND purpose=? AND revoked_at IS NOT NULL)",
          )
          .bind(key, key, purpose),
      ]);
      if (result.some((r) => !r.success))
        throw new ApiError(
          503,
          "collection_unavailable",
          "Withdrawal could not be confirmed. Retry.",
        );
      if (
        !(await db
          .prepare(
            "SELECT token_hash FROM collection_permissions WHERE token_hash=? AND purpose=? AND revoked_at IS NOT NULL",
          )
          .bind(key, purpose)
          .first())
      )
        throw new ApiError(
          503,
          "collection_withdrawal_pending",
          "Withdrawal could not be confirmed. Retry.",
        );
      return jsonResponse({ revoked: true });
    }
    if (action === "data") {
      if (Object.keys(body).join() !== "purpose" || !token)
        throw new ApiError(
          401,
          "collection_proof",
          "A contribution capability is required.",
        );
      const key = await hash(token);
      const permission = await db
        .prepare(
          `SELECT purpose,notice_version AS noticeVersion,granted_at AS grantedAt,expires_at AS expiresAt,revoked_at AS revokedAt FROM collection_permissions WHERE token_hash=? AND purpose=? AND expires_at>${NOW}`,
        )
        .bind(key, purpose)
        .first();
      if (!permission)
        throw new ApiError(
          410,
          "collection_expired",
          "Contributions are unavailable or have expired.",
        );
      const rows = await db
        .prepare(
          `SELECT id,recorded_at AS recordedAt,expires_at AS expiresAt,payload_json AS payload FROM collection_records WHERE token_hash=? AND expires_at>${NOW} AND EXISTS(SELECT 1 FROM collection_permissions WHERE token_hash=? AND purpose=? AND ${VALID}) ORDER BY recorded_at LIMIT ${COLLECTION_MAX_RECORDS}`,
        )
        .bind(key, key, purpose, COLLECTION_VERSION)
        .all<{
          id: string;
          recordedAt: number;
          expiresAt: number;
          payload: string;
        }>();
      if (!rows.success)
        throw new ApiError(
          503,
          "collection_unavailable",
          "Contributions could not be read.",
        );
      return jsonResponse({
        manifest: {
          product: "accreatio",
          preparedAt: new Date().toISOString(),
          scope:
            "Only contributions made under this browser's purpose capability; no account/project link",
          format: "JSON UTF-8; strings are data, never spreadsheet formulas",
          retentionDays: 30,
        },
        permission,
        records: (rows.results ?? []).map((r) => ({
          ...r,
          payload: JSON.parse(r.payload),
        })),
      });
    }
    if (env.COLLECT_ENABLED !== "true")
      throw new ApiError(
        503,
        "collection_inactive",
        "Optional server collection is not activated; local data remains available.",
      );
    if (body.version !== COLLECTION_VERSION)
      throw new ApiError(
        409,
        "collection_version",
        "Review the current notice before sharing.",
      );
    if (action === "preference") {
      if (
        Object.keys(body).sort().join() !== "action,purpose,version" ||
        body.action !== "grant"
      )
        throw new ApiError(
          400,
          "collection_invalid",
          "A deliberate grant is required.",
        );
      // A browser pre-registers its random capability before the request, so
      // lost/concurrent responses cannot orphan a grant. Server state still
      // determines permission; a prior revocation tombstone never reactivates.
      const cap = token ?? hex(crypto.getRandomValues(new Uint8Array(32)));
      const result = await db
        .prepare(
          `INSERT OR IGNORE INTO collection_permissions(token_hash,purpose,notice_version,granted_at,expires_at) SELECT ?,?,?,${NOW},${NOW}+? WHERE (SELECT COUNT(*) FROM collection_permissions WHERE expires_at>${NOW})<1000`,
        )
        .bind(
          await hash(cap),
          purpose,
          COLLECTION_VERSION,
          COLLECTION_RETENTION_MS,
        )
        .run();
      if (!result.success)
        throw new ApiError(
          429,
          "collection_capacity",
          "Optional collection capacity is reached.",
        );
      const receipt = await db
        .prepare(
          `SELECT granted_at AS grantedAt,expires_at AS expiresAt FROM collection_permissions WHERE token_hash=? AND purpose=? AND ${VALID}`,
        )
        .bind(await hash(cap), purpose, COLLECTION_VERSION)
        .first<{ grantedAt: number; expiresAt: number }>();
      if (!receipt)
        throw new ApiError(
          429,
          "collection_capacity",
          "The choice could not be confirmed within capacity.",
        );
      return jsonResponse({
        token: cap,
        purpose,
        version: COLLECTION_VERSION,
        ...receipt,
      });
    }
    if (
      Object.keys(body).sort().join() !== "id,payload,purpose,version" ||
      typeof body.id !== "string" ||
      !/^[0-9a-f-]{36}$/.test(body.id)
    )
      throw new ApiError(
        400,
        "collection_invalid",
        "Invalid contribution envelope.",
      );
    const payload = parseCollectionRecord(body.payload, purpose);
    if (!payload)
      throw new ApiError(
        400,
        "collection_fields",
        "Only the documented structured fields are allowed.",
      );
    if (!token)
      throw new ApiError(
        401,
        "collection_proof",
        "A current server permission is required.",
      );
    const key = await hash(token);
    const result = await db
      .prepare(
        `INSERT OR IGNORE INTO collection_records(id,token_hash,recorded_at,expires_at,payload_json) SELECT ?,?,${NOW},MIN(expires_at,${NOW}+?),? FROM collection_permissions WHERE token_hash=? AND purpose=? AND ${VALID} AND (SELECT COUNT(*) FROM collection_records WHERE token_hash=?)<${COLLECTION_MAX_RECORDS} AND (SELECT COUNT(*) FROM collection_records)<50000`,
      )
      .bind(
        body.id,
        key,
        COLLECTION_RETENTION_MS,
        JSON.stringify(payload),
        key,
        purpose,
        COLLECTION_VERSION,
        key,
      )
      .run();
    if (!result.success)
      throw new ApiError(
        503,
        "collection_unavailable",
        "Contribution could not be saved.",
      );
    // A duplicate is an idempotent retry only while its permission is still current.
    const admitted = await db
      .prepare(
        `SELECT r.id FROM collection_records r JOIN collection_permissions p ON p.token_hash=r.token_hash WHERE r.id=? AND r.token_hash=? AND p.purpose=? AND ${VALID.replaceAll("notice_version", "p.notice_version").replaceAll("revoked_at", "p.revoked_at").replaceAll("expires_at", "p.expires_at")}`,
      )
      .bind(body.id, key, purpose, COLLECTION_VERSION)
      .first();
    if (!admitted)
      throw new ApiError(
        403,
        "collection_permission",
        "Permission expired, was withdrawn, or reached its record limit.",
      );
    return jsonResponse({ accepted: true, id: body.id });
  } catch (error) {
    if (error instanceof ApiError)
      return jsonResponse(
        { error: { code: error.code, message: error.publicMessage } },
        error.status,
      );
    return jsonResponse(
      {
        error: {
          code: "collection_unavailable",
          message:
            "Optional collection could not complete. Your project is unaffected.",
        },
      },
      503,
    );
  }
}
