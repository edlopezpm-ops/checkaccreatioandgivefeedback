import type { AccountBindings } from "./accounts";
import {
  ApiError,
  jsonResponse,
  methodNotAllowed,
  readBoundedJson,
} from "./http";
import {
  ANALYTICS_CATEGORIES,
  ANALYTICS_NOTICE_VERSION,
  ANALYTICS_PURPOSES,
  advertisingSharingPurpose,
  parseAnalyticsEvent,
  parseSourceConfiguration,
  parsePermissionReceipt,
  type AnalyticsPurpose,
  type SourceConfiguration,
} from "../../shared/analyticsProducer";

const CENTRAL = "https://aekr.io/api/collection/";
const UUID =
  /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
type Dependencies = { fetch: typeof fetch; now: () => number };
const fail = (status: number, code: string): never => {
  throw new ApiError(
    status,
    code,
    "Optional offers are unavailable. Your project is unaffected.",
  );
};
const keys = (value: Record<string, unknown>, allowed: string[]) =>
  Object.keys(value).every((key) => allowed.includes(key));
function source(request: Request) {
  const production = new URL(request.url).hostname === "accreatio.com";
  return {
    source_id: production
      ? "accreatio-public-production"
      : "accreatio-public-preview",
    environment: production ? "production" : "preview",
  };
}
async function central(
  path: string,
  env: AccountBindings,
  dependencies: Dependencies,
  body?: unknown,
) {
  const token = env.COLLECTION_SOURCE_TOKEN;
  if (!token || !/^[A-Za-z0-9_-]{32,200}$/.test(token))
    return fail(503, "source_not_connected");
  const response = await dependencies.fetch(`${CENTRAL}${path}`, {
    method: body === undefined ? "GET" : "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    redirect: "error",
    cache: "no-store",
    signal: AbortSignal.timeout(1500),
  });
  const value = await readBoundedJson(
    new Request("https://response.invalid", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: response.body,
      // Web Request streams use duplex in Node tests; Workers does not require it.
      ...({ duplex: "half" } as RequestInit),
    }),
    16384,
  );
  if (!response.ok)
    return fail(response.status >= 500 ? 503 : 403, "central_not_admitted");
  return value as Record<string, unknown>;
}
async function configuration(
  request: Request,
  env: AccountBindings,
  dependencies: Dependencies,
) {
  const expected = source(request);
  const result = parseSourceConfiguration(
    await central(`config?source_id=${expected.source_id}`, env, dependencies),
    dependencies.now(),
  );
  if (
    !result ||
    result.source_id !== expected.source_id ||
    result.environment !== expected.environment
  )
    return fail(503, "source_configuration_invalid");
  return result;
}
async function subject(capability: string, sourceId: string) {
  // Source-specific capability digest survives source-credential rotation.
  // The 256-bit browser capability stays private; this remains pseudonymous.
  const bytes = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(
      `accreatio.analytics.browser.v1:${sourceId}:${capability}`,
    ),
  );
  return Array.from(new Uint8Array(bytes), (v) =>
    v.toString(16).padStart(2, "0"),
  ).join("");
}
function eventAllowed(
  config: SourceConfiguration,
  purpose: string,
  event: ReturnType<typeof parseAnalyticsEvent>,
) {
  return Boolean(
    event &&
    config.enabled &&
    config.purposes.includes(purpose) &&
    config.events.includes(event.event) &&
    (!event.category || config.fields.includes("category")) &&
    (!event.offer_id || config.fields.includes("offer_id")),
  );
}
/** Same-origin producer adapter. No account/project data or caller trust labels. */
export async function handleAnalyticsProducer(
  { request, env }: { request: Request; env: AccountBindings },
  action: string,
  dependencies: Dependencies = {
    fetch: (input, init) => globalThis.fetch(input, init),
    now: Date.now,
  },
) {
  try {
    if (action === "config" && request.method === "GET") {
      const config = await configuration(request, env, dependencies);
      await central("ack", env, dependencies, {
        source_configuration_version: config.version,
      });
      return jsonResponse(config);
    }
    if (!["preference", "event"].includes(action))
      return jsonResponse({ error: { code: "not_found" } }, 404);
    if (request.method !== "POST") return methodNotAllowed(["POST"]);
    if (
      request.headers.get("Origin") !== new URL(request.url).origin ||
      request.headers.get("Sec-Fetch-Site") === "cross-site"
    )
      return fail(403, "source_origin");
    const body = await readBoundedJson(request, 4096);
    if (!body || typeof body !== "object" || Array.isArray(body))
      return fail(400, "source_fields");
    const data = body as Record<string, unknown>;
    const capability = request.headers
      .get("Authorization")
      ?.match(/^Bearer ([0-9a-f]{64})$/)?.[1];
    if (!capability) return fail(401, "source_browser_proof");
    if (!ANALYTICS_PURPOSES.includes(data.purpose as AnalyticsPurpose))
      return fail(400, "source_purpose");
    const secret = env.COLLECTION_SOURCE_TOKEN;
    if (!secret) return fail(503, "source_not_connected");
    const subject_ref = await subject(capability, source(request).source_id);
    const gpc = request.headers.get("Sec-GPC") === "1" || data.gpc === true;
    if (action === "preference") {
      if (
        !keys(data, [
          "purpose",
          "status",
          "notice_version",
          "categories",
          "recipients",
          "gpc",
        ]) ||
        !["granted", "denied", "withdrawn"].includes(String(data.status)) ||
        data.notice_version !== ANALYTICS_NOTICE_VERSION ||
        typeof data.gpc !== "boolean" ||
        !Array.isArray(data.categories) ||
        data.categories.length > 5 ||
        !data.categories.every((v) => ANALYTICS_CATEGORIES.includes(v)) ||
        !Array.isArray(data.recipients) ||
        data.recipients.length > 20 ||
        !data.recipients.every(
          (v) => typeof v === "string" && /^[a-z0-9][a-z0-9_-]{0,79}$/.test(v),
        )
      )
        return fail(400, "source_fields");
      if (data.status === "granted") {
        const config = await configuration(request, env, dependencies);
        if (
          !config.enabled ||
          !config.purposes.includes(String(data.purpose)) ||
          data.recipients.some((v) => !config.destinations.includes(v)) ||
          (advertisingSharingPurpose(String(data.purpose)) &&
            (gpc || !data.recipients.length))
        )
          return fail(403, "source_permission_unavailable");
      }
      const result = await central("preferences", env, dependencies, {
        subject_ref,
        purpose: data.purpose,
        status: data.status,
        notice_version: ANALYTICS_NOTICE_VERSION,
        categories: data.categories,
        recipients: data.recipients,
        gpc,
      });
      const receipt = parsePermissionReceipt(result, dependencies.now());
      if (!receipt) return fail(503, "source_permission_unconfirmed");
      return jsonResponse(receipt);
    }
    if (
      !keys(data, [
        "purpose",
        "permission_ref",
        "event_id",
        "schema_version",
        "occurred_at",
        "source_configuration_version",
        "event",
        "category",
        "offer_id",
      ])
    )
      return fail(400, "source_fields");
    const event = parseAnalyticsEvent({
      event: data.event,
      ...(data.category === undefined ? {} : { category: data.category }),
      ...(data.offer_id === undefined ? {} : { offer_id: data.offer_id }),
    });
    if (
      !event ||
      data.schema_version !== 1 ||
      typeof data.event_id !== "string" ||
      !UUID.test(data.event_id) ||
      typeof data.permission_ref !== "string" ||
      !/^[A-Za-z0-9_-]{1,96}$/.test(data.permission_ref) ||
      typeof data.occurred_at !== "string" ||
      !Number.isFinite(Date.parse(data.occurred_at)) ||
      Math.abs(dependencies.now() - Date.parse(data.occurred_at)) > 300000
    )
      return fail(400, "source_fields");
    if (gpc && advertisingSharingPurpose(String(data.purpose))) {
      await central("preferences", env, dependencies, {
        subject_ref,
        purpose: data.purpose,
        status: "withdrawn",
        notice_version: ANALYTICS_NOTICE_VERSION,
        categories: [],
        recipients: [],
        gpc: true,
      });
      return fail(403, "source_gpc");
    }
    const config = await configuration(request, env, dependencies);
    if (
      !eventAllowed(config, String(data.purpose), event) ||
      data.source_configuration_version !== config.version
    )
      return fail(403, "source_paused_or_changed");
    const result = await central("events", env, dependencies, {
      ...event,
      subject_ref,
      event_id: data.event_id,
      schema_version: 1,
      occurred_at: data.occurred_at,
      purpose: data.purpose,
      permission_ref: data.permission_ref,
      source_configuration_version: config.version,
    });
    return jsonResponse({
      accepted: result.accepted === true,
      duplicate: result.duplicate === true,
    });
  } catch (error) {
    const status = error instanceof ApiError ? error.status : 503;
    return jsonResponse(
      {
        error: {
          code: error instanceof ApiError ? error.code : "source_unavailable",
          message:
            "Optional offers are unavailable. Your project is unaffected.",
        },
      },
      status,
    );
  }
}
