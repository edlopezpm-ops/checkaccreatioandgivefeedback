# Change Control

## 2026-09-05 — Repair the repeated PWA update confirmation

- The owner's recording reproduces a reload-only legacy client retaining its waiting worker. Activate the replacement worker and remove blocking update dialogs and automatic reload listeners from the current web client.
- Preserve outgoing preview `a6446cfd-1356-49a2-9ffd-7e4e80295e6c`, immutable `https://a6446cfd.accreatio.pages.dev`, source `80362c391888a1bafc18c06077c2ca1996bbeecc`, before replacing the existing preview alias. Production and access policies retain their existing configuration.
- [Recovery record](docs/PWA_UPDATE_RECOVERY_2026-09-05.md) supersedes the previous close-all-tabs workaround and records the one-time legacy reload boundary. Browser regression must exercise actual old, waiting and replacement bundles at the same origin without clearing storage or closing tabs.

## Conventions — archive, never delete

Standing policy, set by Ed Lopez (HOE) on 2026-08-13: **superseded work is
archived, not removed.** It applies to deployments, design documents, generated
artifacts, and audit reports. It does not apply to secrets or credentials,
which are revoked and deleted.

**Hosted.** Cloudflare Pages already implements this: every deployment keeps a
permanent immutable URL, and the stable alias points at whichever deployment is
promoted. Promoting a replacement does not remove its predecessor — the old
deployment keeps its URL and can be re-promoted. What this file must add is the
part the platform does not do: **record the outgoing deployment ID before
promoting a replacement**, so an archived version is findable by name instead
of by dashboard archaeology.

**In-repo.** A superseded implementation moves to a clearly named legacy path
and stays buildable until its replacement passes hosted acceptance, so rollback
is a toggle rather than a git operation. Superseded design and audit documents
keep their original wording as dated evidence and are never rewritten to match
a later decision; corrections are recorded as new entries that cite what they
supersede.

## 2026-09-04 — Boxed team/export choices and rolling-quota investigation

- Owner asked for UI/UX-led improvements: a clear boxed agent-role control, purple-selected boxed confirmation options, and centered FAQ/ToS beneath the reassurance. Preserve accepted behavior and the web-only boundary.
- Owner clarified the authentication target to five ZIPs in any rolling 24 hours and requested an ultra-effort options investigation considering email, IP, security and lawful data use. This remains discovery/design; no authentication or quota implementation is activated.
- [Design v14](docs/design-v14/DESIGN.md) records scope. Retain v13 deployment `77e26090-6da5-4ef8-9627-6808760cef88`, immutable `https://77e26090.accreatio.pages.dev`, and its v13 alias before creating a separate v14 preview.
- Verified source `53343211a2176be487c17fa8f58202146f3eac7e` deployed successfully to `4dff21cf-d9cc-4ed4-94fe-4b11b5bf532e`, alias `https://design-v14-preview.accreatio.pages.dev`, with clean commit metadata. Independent review and seven anonymous Access checks passed; [results](docs/design-v14/RESULT.md) record the handoff. Production and prior preview aliases remain unchanged.

## 2026-09-04 — Confirm export and persistent FAQ/ToS; authentication discovery

- Owner scope: static middle onboarding logo; dry-review/ZIP choice inside Confirm export; expanded FAQ/ToS with persistent below-form navigation; conditional copyright correction; sign-in and five-per-day discovery only.
- Preserve accepted v12 preview `5650337d-81fd-4213-83ce-e9a91c8aac45`, source `b1d106f1f88f63fb41883c2105fa7bbdfd98d397`, immutable `https://5650337d.accreatio.pages.dev` and its v12 alias. A new v13 preview will carry this increment; production, Access, D1 and publisher configuration remain unchanged.
- [Design v13](docs/design-v13/DESIGN.md) defines the implementation/verification boundary; [sign-in roadmap](docs/archive/2026-09-05/AUTH_ROADMAP.md) is a proposal, not activation. LICENSE keeps Ed Lopez as copyright holder; no AEKR transfer is inferred.
- Verified implementation `0f7e216a42783458f81bc6854c8f320c407b3052` deployed successfully as preview `77e26090-6da5-4ef8-9627-6808760cef88` at `https://design-v13-preview.accreatio.pages.dev`, with a clean commit marker. Final checks, independent PASS and the eight anonymous Access redirects are recorded in [v13 results](docs/design-v13/RESULT.md). Production and prior previews remain unchanged.

## 2026-09-04 — Restore the original AEKR footer banner

- The owner approved the other current frontend changes and requested the original AEKR banner with its hyperlink, with Instagram/X/LinkedIn styled and sized to match. Reuse the original shared signature artwork and styling; preserve safe links, inert pending profiles and the page-flow footer. Only the web footer component/styles change.
- Preserve outgoing preview `77613898-363c-4d3a-b048-52a6985ddc15`, source `7fc8b93c1128e78670a92397bc968bf5735ac1b8`, immutable `https://77613898.accreatio.pages.dev`, before updating `https://design-v12-preview.accreatio.pages.dev`. See `docs/design-v12/FOOTER_RESTORATION.md` for scoped verification and the separately recorded desktop test limitation.
- Scoped verification and independent footer review passed. Implementation `b1d106f1f88f63fb41883c2105fa7bbdfd98d397` is pushed and deployed as preview `5650337d-81fd-4213-83ce-e9a91c8aac45`, immutable `https://5650337d.accreatio.pages.dev`, using the existing v12 alias. Six anonymous probes redirect to Access; the outgoing immutable preview remains available and production is unchanged.

## 2026-09-04 — Design v12 web polish

- Owner authorized night-only web appearance, English startup, the existing Blog wordmark typography, transparent branding without a tagline, AEKR/Instagram links in new tabs, inert X/LinkedIn icons, simpler copy, 50-character names, four unique roles, progressive summary and direct ZIP confirmation after dry review. Desktop remains frozen. Frontend completion and commit/push precede Blog roadmap review.
- The outgoing test deployment is `1afd10fa-f010-41d8-a658-3a5aa5224593`, source `95c8ea1181f4b36c6d77b0c0747aebc4c02be07d`, immutable `https://1afd10fa.accreatio.pages.dev`, alias `https://design-v11-preview.accreatio.pages.dev`. Preserve it and production `11235c8c-108f-46f3-8cce-fb88a144330b`; use a separate `design-v12-preview` alias for this increment.
- Reuse the current guided workflow, local draft, domain validation, explicit confirmation and guarded ZIP execution. Invalid restored drafts are preserved for correction. No schema, dependency, desktop asset, backend, Access or publisher change. See `docs/design-v12/DESIGN.md`; verification and deployment receipts follow in its result record.
- Verified and independently audited implementation `7fc8b93c1128e78670a92397bc968bf5735ac1b8` is pushed and deployed as preview `77613898-363c-4d3a-b048-52a6985ddc15`, immutable `https://77613898.accreatio.pages.dev`, alias `https://design-v12-preview.accreatio.pages.dev`. Six anonymous site/API/asset probes redirect to Access; production and v11 identities are unchanged. See `docs/design-v12/RESULT.md` for exact evidence and the corrected distinction between a skipped current-HEAD vendor check and passing pinned-payload parity. Owner testing remains pending.

## 2026-09-04 — Guided web creation, autonomous nebula and orbital web identity

- Owner authorization: recover Claude's frontend, simplify creation with a UX/UI specialist, increase autonomous nebula motion, remove hover response, and add a left-click smoke burst on visible exposed gas. The owner's subsequent supplied brand reference adds a surgical web identity replacement and explicitly freezes desktop development. Recorded in DEC-019 and `docs/design-v11/DESIGN.md`.
- The previous successful preview is deployment `e0a5bdf7-db12-4e67-a8f7-3b4ab7015c8e`, source `e4eb570`, immutable `https://e0a5bdf7.accreatio.pages.dev`. The merge `de35588` has the same Git tree; its idle deployment `074cd189-60e3-40a3-bbb8-d65fbd2e9970` is not credited as deployed. Existing production deployment `11235c8c-108f-46f3-8cce-fb88a144330b` and previous previews remain archived.
- Reuse existing project state, validation, drafts, deterministic output and explicit execution confirmation. Present one main question at a time, preserve Back/edit answers, and collapse full technical output on Review. Preserve the old flow in buildable legacy files until owner acceptance.
- Replace pointer-driven atmosphere movement with faster independent motion and shader-density-tested bursts. Use the supplied spherical-core orbital identity for web branding and installable-web assets; preserve prior desktop assets and installer configuration. No desktop release belongs to this increment.
- Extend the existing functional verification and patch two inherited transitive audit findings without adding a direct dependency. Exact verification, bounded source inventory, fresh independent parent audit and protected preview identity are recorded in `docs/design-v11/RESULT.md`. That record distinguishes engineering verification from the owner's pending hosted acceptance.
- Access policy, D1 bindings, publisher allowlists, privileged execution and project-data boundaries are preserved. The testing target is a protected preview; production promotion is separate.
- Testing deployment completed: audited source `95c8ea1181f4b36c6d77b0c0747aebc4c02be07d`, preview `1afd10fa-f010-41d8-a658-3a5aa5224593`, immutable `https://1afd10fa.accreatio.pages.dev`, alias `https://design-v11-preview.accreatio.pages.dev`. Final verification and the independent parent audit, including the resolved short-viewport focus finding, passed. Anonymous site/API/asset probes redirect to Access. Owner UX acceptance remains pending.

## 2026-09-01 — Owned procedural nebula and design v10 presentation pass

- Origin: the owner rejected the shipped frontend outright — too much text, and an atmosphere that did not read as a real nebula — and asked for a sober, modern, Scandinavian-restraint interface aimed at people who already know what they are doing. Scope was explicitly limited to presentation; the owner stated everything else was fine. Recorded as DEC-018.
- Replaced the third-party atmosphere renderer with a first-party GLSL shader in `src/components/nebula.ts`: value-noise fbm under two-level domain warping, dust-lane absorption carving filaments, two emission cores (one anchored in the gas, one carried by the pointer), micro star grains dimmed by the dust, and ordered dither against banding. `vanta@0.5.24` and `three@0.185.1` were removed as runtime dependencies along with `src/vendor.d.ts`, so the atmosphere now carries no third-party rendering package at all. Every existing safeguard is preserved unchanged — reduced motion, save-data, slow update, hidden page, absent/failed/lost WebGL, coarse pointer, the 30 fps cap, and the DPR ceiling. The `SPEED_BY_VARIANT` and `PARALLAX_BY_VARIANT` tables keep their exact design-v6 values, so pointer-parallax geometry is byte-identical to the accepted contract.
- Retired the display serif. Brand, headings, UI, body, and controls now share the one host-resident sans stack, separated by weight and size; mono is unchanged. This reverses the explicit "display serif for editorial headings" clause of DEC-015 and the deliberate preservation recorded in the 2026-08-13 entry below, under a new owner decision rather than silently. The no-webfont boundary is untouched: no `@font-face`, no font bytes, no remote request, and the Project Map keeps `font-src 'none'`.
- Rebuilt the palette on a near-black blue-grey ground (`#0a0c14`) and a near-white light ground (`#f5f5f7`), replacing the violet and lilac themes. Panels became translucent blurred instruments over the nebula instead of opaque cards, borders became low-contrast hairlines derived from the text colour, and navigation and pills lost their boxes. All sixteen final text and status pairs were computed at or above 4.5:1 before the values were written; the theme contrast guard carries the new pairs.
- Fixed two interface honesty defects the redesign made visible. A required field showed "Campo obligatorio" in red before the user had typed anything, so a first visit opened on an error state; field errors now surface only once the user has tried to leave the stage. The stage rail also advertised Team and Delivery as "Completa" before either had been opened, because their defaults satisfy validation; a stage the user has never reached can no longer claim completion. Redundant copy was removed where the shell already states the same fact.
- Updated the two browser smokes that had the retired serif stack and the removed web-intro sentence hardcoded, and reconciled `README.md`, `THIRD_PARTY_NOTICES.md`, `docs/SECURITY.md`, both SOPs, `docs/TROUBLESHOOTING_WHITEPAPER.md` (which documented a `.vanta-canvas` selector that no longer exists), `docs/TEST_NOTES_RESOLUTION.md`, and four now-closed `RISKS.md` rows. Historical design and audit documents keep their original wording as dated evidence.
- Verification, stated exactly: 215/215 unit and source-contract tests, all three typechecks, Prettier, deterministic Blog seed, Project Map parity, generated Cloudflare type parity, Function/web/desktop builds, surface-boundary smoke, Project Map `file://` smoke, the W1 browser functional smoke (WebGL canvas present and animating, pointer-parallax geometry, theme switch preserving the same canvas, Blog, ZIP export), and Lighthouse 95/100/100/66 with the standing private-beta noindex exemption. **`npm run verify` did not exit 0**: the Electron execute smoke could not run because this checkout's `node_modules/electron` binary is an empty OneDrive placeholder — 111 KB of zeros with a reparse point, which Electron reports as a corrupt asar header. That is a local sync artifact in an untracked directory, not a source defect, and it is reproducible only on this machine; CI's clean `npm ci` on Windows is the authority for that gate. No claim of a passing desktop smoke is made here.
- Cleared a pre-existing supply-chain block that this increment's CI run surfaced rather than caused. `npm audit --audit-level=high` failed on `nanoid@3.3.16` (GHSA-2v37-7h3g-55p8, high). That exact version was already pinned in the lockfile at `89c012c`; the advisory was simply published after the last green run on 2026-08-06, so the branch inherited it. Following the Undici precedent below, a narrow `nanoid@3.3.16` → `3.3.18` override moves only the affected release. It arrives transitively through `vite` → `postcss`, the bump is a patch inside the range `postcss` already accepts, and `npm audit` now reports zero vulnerabilities with tests and build unchanged.
- **No independent audit was performed for this increment**, and no promotion to production was made. An access-restricted preview was deployed from the exact commit for owner review at `https://design-v10-preview.accreatio.pages.dev` (immutable `https://a038a06b.accreatio.pages.dev`); the production alias still resolves to its previous deployment. Both publisher allowlists remain empty and fail closed, and no Cloudflare, Access, or D1 configuration was read or changed. Access protection was confirmed still fail-closed across the wildcard before and after the upload: the production alias, an existing preview, an immutable production deployment URL, and both new preview URLs each return a 302 to the Access login unauthenticated.

## 2026-08-13 — Frontend audit reconciliation, Project Map rename, CI and workspace repair

- Reconciled the untracked root `docs/archive/2026-09-05/CURSOR_UX_AUDIT.md` against the actual tree rather than treating it as a backlog. Ten of its fourteen findings were already implemented, three were never code defects, and one — the undelivered brand typography — was a live defect, fixed here under the owner decision recorded below. Full finding-by-finding evidence in `docs/archive/2026-09-05/FRONTEND_RECONCILIATION.md`. Apart from the typography tokens, no product behaviour, markup, or accessibility contract changed as a result of the audit.
- Fixed finding 1 under an explicit owner decision. The condition was real: no font binary, no `@font-face`, `font-src 'none'`, and a `serif` fallback under a sans display family, so `"Posterama"`, `"Inter"`, and `"JetBrains Mono"` resolved to an OS generic on every machine and inverted the intended display voice. Because the remedy contradicted two entries below — the design v6 acceptance of owner-supplied tokens with generic fallbacks, and the design v8 entry that intentionally did not adopt unlicensed font substitution — the working patch was reverted and put to the HOE as three costed options rather than applied unilaterally. **Ed Lopez (HOE) chose host-resident stacks on 2026-08-13**, explicitly superseding those two entries for the typography tokens only. The five tokens on all four surfaces (`src/styles.css` dark and light, `public/legal/legal.css`, `scripts/project-map.template.html`) now name faces a host already has, with a correct generic terminator. No font binary, `@font-face` rule, or remote request was added, so the zero-cost constraint and the Project Map's `font-src 'none'` boundary are untouched, and the serif display voice every machine already rendered is preserved deliberately — the appearance does not change for the current beta, it becomes intentional and cross-OS consistent. Brand identity beyond this remains an open, unfunded decision.
- Replaced the regression guard that was pinning the defect in place. `tests/typography.test.ts` asserted the undelivered family names as literal expected tokens; it now matches declared family lists and adds `no surface declares a font family the build never delivers`, failing on any `@font-face`, undelivered family, or webfont CDN import, with CSS comments stripped so prose explaining the decision stays legal. `scripts/project-map-functional-smoke.mjs` verifies computed font families in a real browser and was updated to the new stacks as Chromium serialises them.
- Renamed the generated Project Map viewer to `accreatio-project-map.html` at HOE direction so a downloaded copy stays identifiable beside other AEKR project maps. `project-map.json` deliberately keeps the canonical name declared by AEKR's `project-map-standard.md`, which agents read by. Generator, parity check, functional smoke, test fixture, `PROJECT_MAP.md`, `README.md`, and `W1_RELEASE_READINESS.md` follow; historical audit reports keep their original references as the dated evidence they are.
- Scoped the CI `push` trigger to `main`. The workflow previously ran on both `push` and `pull_request`, so a branch push with an open pull request executed the complete Windows gate twice, billed at the 2x Windows-runner rate against the account's included minutes. Pull requests and manual dispatch are unchanged, and a push to `main` still runs the complete gate. Note what this does *not* establish: the repository has no branch protection or ruleset, because GitHub's Free plan does not offer them for private repositories — the API answers `403 Upgrade to GitHub Pro`. CI therefore reports on `main` but cannot block a direct push to it. That is an unresolved control gap, not something this change fixes, and it matters now that the repository has a second collaborator with write access.
- Repaired two workspace defects that blocked all local verification on Windows and would have blocked any new contributor on the same checkout. `node_modules` carried a Linux esbuild binary, failing every test, typecheck, build, and Wrangler invocation; cleared by `npm ci`. Zero-byte *files* named `dist` and `dist-electron` occupied the paths the build needs as directories, failing `vite-plugin-pwa` with `EACCES: permission denied, mkdir 'dist'`; removed with four zero-byte `core.*` crash artifacts. All six were untracked and none is a source defect. `dist` and `dist-electron` are gitignored; the `core.*` artifacts are not covered by any `.gitignore` rule, so a future crash dump would show up as untracked noise again — adding a rule is deferred rather than slipped into this change.
- Prepared `docs/HOE_R0_CHECKLIST.md`, the operator-facing short form of SOP H-01 and H-03, so R0.1 and R0.2 can be executed without re-reading the full design set. Authority stays with `docs/design-v9/HOE_SOPS.md`.
- Independent audit: Codex reviewed candidate `b808928` in a fresh read-only context and returned **FAIL** with five findings against the documentation — a miscount in the reconciliation table, two inaccurate evidence citations, an unsupported claim that the display voice inverted, and two overstated claims in this file. Every finding was re-verified against the tree before being accepted; all five were correct and are corrected in this entry and in `docs/archive/2026-09-05/FRONTEND_RECONCILIATION.md`. No finding concerned product code. The audit's reading that this file's operator-run evidence is unverifiable from the tree is noted but not adopted: recording CI run IDs, deployment IDs, and Lighthouse scores that a repository cannot contain is this file's established purpose.
- Verification: `npm run verify` exited 0 with 200/200 tests — the `0.8.0` baseline of 199 plus the new undelivered-font guard, deterministic Blog seed and Project Map parity, generated Cloudflare type parity, application/Electron/Function typechecks, Prettier, Function/web/desktop builds, surface-boundary/Electron/Project Map/browser smokes, and Lighthouse 91/100/100/66 with the intentional private-beta noindex exemption.
- Release state unchanged. Both publisher allowlists remain empty and fail closed, no deployment was made, no protected value was read or written, and no Cloudflare or Access configuration was touched. Owner-authenticated acceptance remains pending.

## 2026-08-06 — Design v8 Web-only Blog and Editorial Publisher (protected deployment)

- Accepted the product definition: “accreatio is an authenticated, local-first, ephemeral-session web application for creating and exporting projects.” Project content, attachments, ZIPs, paths, and optional integration credentials remain outside the editorial backend.
- Added a web-only Blog whose single runtime source is Cloudflare D1 through three same-origin Pages Function routes: published-post read, minimum admin capability, and append-only publish. The three reviewed founding posts are versioned as a structured fixture and seeded by migration rather than bundled as a runtime fallback.
- Added server-side Access JWT verification and publisher authorization for Ed Lopez's protected human identity and separately allowlisted AEKR service identities. Sensitive identifiers resolve to safe audit labels; browser writes require same origin, JSON, a custom header, bounded input, and UUID idempotency.
- Split web and Electron renderer graphs. The web output receives the Blog/editor/PWA; the desktop output and package must exclude Blog content/styles/API paths, founding text, PWA artifacts, Functions, migrations, Wrangler configuration, and editorial fixtures.
- Reconciled the owner-approved visual review without changing the atmosphere contract: the project-building form is now the wider left column and the compact five-stage navigator is the narrower right column on large screens, with the established strip and selector fallbacks at smaller breakpoints. The same pass adopted one H1 per view, dynamic document language and theme color, a native modal, stronger focus/error feedback, and responsive Blog/About refinements; unlicensed font substitution and a global palette/motion redesign were intentionally not adopted.
- Reconciled current README, decisions, risks, web/desktop SOPs, architecture, privacy/security/terms/FAQ, release runbook, legal pages, and canonical Project Map. Historical design and audit evidence remains unchanged.
- Remote preparation: separate zero-cost production and preview D1 databases were provisioned. The reviewed migration was applied to both, and read-only production/preview queries returned exactly the three founding rows. The four required production secret names exist, but both publisher maps remain deliberately empty and fail closed until the exact owner and Service Auth identities are available; no protected value is recorded here.
- Pages source reconciliation: the project is now GitHub-connected. Automatic production and preview deployments were paused after two failed, non-promoted attempts for `44b04b4` and `ad90fee`; the source connection remains installed. The later push of `8735952` created only an idle deployment record with no stage started, confirming that branch control did not build or promote it. The governed `0.8.0` release used the manual exact-commit Wrangler path with root `functions/` included.
- Supply-chain preparation: pinned Wrangler `4.119.0` brought Miniflare's exact Undici `7.28.0`, which npm flagged for current transitive advisories. A narrow package override moves only that affected Undici release to `7.29.0`; Wrangler still reports `4.119.0`, the Pages Function bundle compiles, and `npm audit --audit-level=high` reports zero vulnerabilities.
- Local release verification: `npm run verify` passed with 199/199 tests, deterministic Blog seed and Project Map parity, generated Cloudflare type parity, application/Electron/Function typechecks, Prettier, Function/web/desktop builds, surface-boundary/Electron/Project Map/browser smokes, and Lighthouse 91/100/100/66 with the intentional private-beta noindex exemption.
- CI now installs its browser prerequisite, enforces the zero-high dependency audit, and invokes that complete `verify` contract rather than a partial hand-maintained subset.
- Candidate evidence: commit `ad90feecd048b562bebebb616cfc759af534904e` was pushed to `main`; GitHub Actions run `31126254580` passed the complete Windows release gate. Claude Code 2.1.223 then reviewed that exact tracked tree in a fresh read-only AEKR context and returned **PASS_WITH_OBSERVATIONS**, with no Blocker, Major, or Minor finding; see `docs/design-v8/CLAUDE_AUDIT_REPORT.md`. Documentation-only reconciliation commit `8735952c01560218d9dc5d95d5f298329f18d6e5` then passed the same complete Windows gate in run `31126665469`.
- Protected deployment: on `2026-08-06T19:12:59Z`, owner-authenticated Wrangler 4.119.0 deployed exact commit `8735952c01560218d9dc5d95d5f298329f18d6e5` from clean tracked source to production deployment `11235c8c-108f-46f3-8cce-fb88a144330b` (`https://11235c8c.accreatio.pages.dev`), branch `main`, with `commit_dirty: false`; Cloudflare reports `deploy: success`. Anonymous probes returned HTTP `302` for the stable origin, its Blog API, and the immutable deployment origin. A read-only production D1 query returned exactly the three reviewed founding posts with `release-seed` actor labels.
- Release state: the code, exact-commit deployment, database seed, CI, anonymous Access perimeter, and static code/documentation audit are complete. Both publisher allowlists remain deliberately empty and fail closed; owner-authenticated Blog/admin acceptance and a real narrowly allowlisted AEKR service-token exercise remain pending. Active human/agent publishing is not claimed by this entry.

## 2026-08-06 — Design v6 Semantic Typography, Expanded Motion & Protected W1 Beta

- Applied the exact owner-supplied typography tokens and roles across the application, static legal pages, and interactive Project Map: Posterama for mark/H1/H2, Inter 400/500/600 for body/UI roles, and JetBrains Mono for technical content. No font binary or remote font request was introduced; missing licensed families resolve through the documented generic fallbacks.
- Increased star autonomous drift and pointer-parallax trajectory by exactly 35%, nebula pointer trajectory by exactly 25%, and both autonomous speed systems by exactly 15%. Existing reduced-motion, constrained-renderer, frame/DPR/density, pointer, and privacy boundaries remain intact.
- Corrected the missing light-theme instrument tokens, expanded computed-style/motion/reduced-motion regression coverage, regenerated the Project Map, and kept the self-contained map at zero external requests.
- Reconciled W1 from a stale public-deploy hold to an owner-authorized, zero-cost private beta. Cloudflare Access must protect the empty Pages project and deny unauthenticated access before any asset upload; anonymous access, custom domain, broad promotion, backend services, analytics, telemetry, and paid capability remain unauthorized.
- Added noindex defense in depth and current Cloudflare Pages/Access legal/privacy disclosure. The intentional Lighthouse `is-crawlable` failure is the sole SEO exemption; every other weighted SEO audit remains subject to the normal threshold.
- Moved `actions/checkout`, `actions/setup-node`, and `actions/upload-artifact` from `v4` to the official `v7` Node 24 runtimes, removing the Node 20 deprecation warning observed in the first green implementation CI run.
- Verification: local `npm run verify` passed with 183/183 tests, Project Map parity, typecheck, format, build, Electron/Project Map/W1 smokes, and Lighthouse 92/100/100/66 with intentional private-beta noindex. `npm audit --audit-level=high` found zero vulnerabilities. GitHub Actions run `31067618206` passed on Windows for controlling commit `cedd0230857a4d9abb295cf417e2777de2ba309c`.
- Independent audit: Claude Code 2.1.222 reviewed the full pushed repository at `cedd023` and AEKR at `d872514` in a fresh read-only context. Verdict **PASS_WITH_NON_BLOCKING_OBSERVATIONS**, no Blocker/Major, one Minor for this previously missing entry, and one process Observation that dependency audit is manual. Codex reconciled documentation only after the audit.
- Post-audit test stabilization: the first documentation-only CI rerun exposed a Windows compositor/PNG screenshot hash flake in the new static-star assertion. At the owner's explicit direction, Codex replaced that evidence method with a SHA-256 fingerprint of the Canvas2D pixel buffer itself; production code and visual behavior are unchanged, and the web smoke passed three consecutive local runs.
- Protected beta deployment: GitHub Actions run `31068902888` passed for controlling commit `39ea088175e69430fa9f2539681ea978b264675d`. On `2026-08-06T15:26:20Z`, an owner-authenticated Wrangler 4.119.0 Direct Upload created production deployment `5e1ab5c8-67ca-4c4f-a574-990ad34fa973` (`https://5e1ab5c8.accreatio.pages.dev`) for project `accreatio`, branch `main`, with `commit_dirty: false`; Cloudflare reports the deployment stage as `success`. The stable protected origin is `https://accreatio.pages.dev`.
- Access evidence: one self-hosted application protects the exact production hostname `accreatio.pages.dev`, and a separate application protects preview hostnames `*.accreatio.pages.dev`. Each has one precedence-1 Allow policy whose only include rule is `edlopezpm@gmail.com`, with no Exclude or Require rules. Project creation briefly returned the prior cached site with HTTP `200` while the new exact-host policy propagated; no new asset was uploaded during that interval. The upload proceeded only after an anonymous probe returned HTTP `302` to Cloudflare Access. After deployment, anonymous probes returned `302` for both the stable production origin and immutable deployment hostname.
- Deployment boundary: this is zero-cost Pages hosting plus Access only. Direct Upload established no Git integration or deploy hook and added no Function, Worker, KV, analytics, backend, telemetry, custom domain, DNS change, application account, repository credential, or committed Cloudflare secret. The transient Wrangler install used for release was removed; the repository dependency graph again audits with zero vulnerabilities.
- Remaining hosted acceptance: exact deployment metadata, both Access applications, owner-only policy shape, and anonymous fail-closed behavior are verified. Owner-authenticated content/header inspection plus hosted browser, offline, network-egress, and Lighthouse checks remain open and must not be represented as complete.
- Post-deployment documentation reconciliation verification: `npm run verify` passed with 183/183 tests, Project Map parity, typecheck, Prettier, production PWA build, Electron/Project Map/W1 browser smokes, and Lighthouse 90/100/100/66 with the intentional private-beta noindex exemption; `npm audit --audit-level=high` found zero vulnerabilities.
- Rollback: for this first hosted beta, disable or delete the Pages project first if privacy, access integrity, or data egress is in doubt; there is no earlier known-good production deployment to restore. Source rollback returns to `c28036f0e8a6e208a4047c068798ff70a1677726`; no data migration is required. Access applications remain external configuration and must be reverified before any later upload.

## 2026-08-05 — Design v5 Dense Star Parallax & Responsive Glass

- Doubled the Vanta atmosphere speed exactly for every view: home `0.56`, creation `0.44`, review `0.28`, export `0.48`, About `0.44`, and quiet `0.20`. The nebula remains locally rendered and pointer-responsive, with its strongest visual density progressing from right to left.
- Added a deterministic 2D star canvas behind the existing Vanta/Three WebGL canvas. Three depth bands use right-weighted seeded placement, distinct size/speed/parallax ranges, and bounded organic drift inside approximate `2 mm`, `3 mm`, and `5 mm` CSS boxes; there is no straight-line or unbounded star travel.
- Kept lifecycle fallbacks explicit across both visual layers: reduced motion and constrained-update states retain a static star frame and CSS fallback rather than active animation, while the Vanta layer keeps its existing initialization/context-loss fallback boundary.
- Narrowed the About instrument responsively to a `62rem` ceiling, made About/Home and creation surfaces more translucent without sacrificing legibility, preserved the original serif-display/sans-interface/mono-technical typography roles, and applied bounded web-intro/footer presentation fixes so the atmosphere can remain subtly visible without obscuring content.
- Added the owner-supplied full “Build with AEKR” banner at the end of the root README for GitHub and beside the canonical-source note in the interactive Project Map. The source PNG and copy-along notice now live under `assets/`; the map generator embeds those exact local PNG bytes as a responsive, accessible data URI so `project-map.html` remains a single-file, zero-request artifact. The owner's broader “all AEKR projects” rule was implemented upstream in AEKR commit `d872514719520735f19fa107d87f7ba3e18f4b9d` rather than being inferred from accreatio alone.
- Dependency/cost/security/data boundary: no package, CDN, remote asset, service, telemetry, paid API, hosting, project schema, draft, attachment, bridge/IPC, filesystem, Git/GitHub, credential, AEKR runtime, or user-data behavior changed. Runtime cost remains USD zero.
- Rollback: return to controlling pre-v5 baseline `7876673`; no data migration is required. The star layer, speed table, and responsive glass changes must be reverted together to preserve the documented visual contract.
- Verification boundary: design v5 evidence is visual-only by owner direction. Representative dark/light, elapsed-motion, pointer-extreme, isolated-depth, creation, About, ultrawide, split-window, 200% zoom, 390 px, 320 px, reduced-motion, and desktop/mobile Project Map frames were captured for human inspection; no v5 automated test, smoke, Lighthouse, dependency/security-audit command, or package pass is claimed.
- Independent audit: a fresh read-only Claude session reviewed the complete pushed repository, 34/34 checksum-controlled visual artifacts, and applicable pinned AEKR guidance at controlling commit 7a7e511595a8ab820e09b46de21903170b390e1c. It returned **PASS WITH NON-BLOCKING IMPROVEMENTS**, with no Critical/High/Medium finding, one Low live-browser proximity check near 720 px, and one informational standardized-license note. No code changed after the audit; documentation reconciliation preserves both items and the visual-only release boundary.

## 2026-08-05 — Interactive Nebula, Orbital Identity & AEKR Signature

- Replaced the v3 CSS-only environment with one locally bundled, dynamically imported Vanta `FOG`/Three renderer plus bounded inverse-pointer parallax, counter-moving CSS depth, right-to-left density, sparse stars, view-aware scrims, and a static fallback. Reduced motion, save-data, slow-update, hidden-document, missing-WebGL, initialization-failure, and context-loss states do not keep an active effect.
- Replaced the UI mark with a transparent orbital lowercase-`a` SVG and reproducibly regenerated the referenced 192/512 PWA icons, social preview, and Windows packaging source. The mark contains no raster/background rectangle and is rendered unboxed; light mode now uses a cool ice/lavender/blue-violet system with a legible glyph contour.
- Added a non-interactive, low-opacity, local vector “Built with AEKR” signature near the bottom safe area, collapsing to the icon on narrow mobile. It records the owner-requested governed-build relationship without copying private AEKR handbook content or claiming certification.
- Added exact runtime dependencies `vanta@0.5.24` and `three@0.185.1`, no CDN or runtime remote asset. Both are isolated to presentation and receive no project text, bridge, filesystem, Git/GitHub, credential, persistence, or orchestration access.
- Data/security/migration: no project schema, IndexedDB draft, attachment format, bridge/IPC, filesystem/Git/GitHub behavior, AEKR runtime contract, user data, telemetry, hosting, or public-deployment authorization changed. Rollback is the pre-phase baseline `f37f91f`; no data migration is required.
- Verification: `npm run verify` passed with 176/176 tests, Project Map/type/format/build gates, Electron/project-map/W1 browser smokes, one-canvas/motion/fallback/runtime-egress coverage, and Lighthouse 92/100/100/100 initially and 91/100/100/100 on the clean post-audit rerun. `npm audit` found zero vulnerabilities; representative dark/light/mobile/ultrawide renders were inspected. The intentionally visible Three chunk warning and 1,661.92 KiB PWA precache remain tracked performance evidence.
- Packaging boundary: the icon source/configuration test passes, but `package:win` cannot complete in this Linux dev container because electron-builder does not follow the `/tmp`-backed `dist-electron` symlink into the ASAR. No successful portable artifact is claimed; the release-host follow-up is recorded in `RISKS.md`.
- Independent-audit evidence: Claude reviewed the complete pushed repository and applicable AEKR guidance at controlling commit `7da2707` and returned `PASS WITH NON-BLOCKING IMPROVEMENTS`; see `docs/archive/2026-09-05/design-v4/CLAUDE_AUDIT_REPORT.md`. Documentation reconciliation confirmed all three generated PNGs remain in `dist/sw.js`, recorded hidden-tab automation as an open coverage gap, preserved Codex attribution for quantitative validation, and left the Windows packaging gate open. No post-audit code change was made.

## 2026-08-05 — Visual Atmosphere, Responsive Experience & Logo Refinement

- Replaced the UI-facing raster mark with a clean 256×256 SVG whose upper-left satellite terminates the correct upper arm; regenerated PWA icons and added a future social-preview asset. The Windows package icon intentionally remains a tracked follow-up because `package.json` still references the prior raster.
- Added one persistent CSS-only atmosphere with state-specific home/creation/review/export/About/quiet compositions, slow deterministic transform/opacity motion, hidden-tab pause, reduced-motion static fallback, and constrained-device layer reduction. No remote image, dependency, Canvas, WebGL, service, telemetry, or cost was added.
- Added fluid content/rail/spacing tokens, ultrawide composition, creamy light-mode tokens, translucent-but-legible surfaces, unified brand-to-home navigation, and removal of onboarding Skip while preserving Continue/Back/Finish.
- Corrected the Windows CI orchestration test to compare canonical real paths, eliminating the runner's short-path/long-path false failure.
- Data/security/migration: no project definition, draft, bridge, persistence, AEKR runtime, filesystem, Git/GitHub, secret, or user-data behavior changed. Rollback is the pre-phase baseline `87ce8ea`; regenerated visual assets and CSS may be reverted without data migration.
- Verification: 174/174 tests, application/Electron typecheck, Prettier, Project Map, production PWA build, web functional smoke, representative mobile/desktop/ultrawide dark/light renders, and Lighthouse 99/100/100/100.
- Independent Claude audit of pushed commit `30b239d`: `PASS WITH NON-BLOCKING IMPROVEMENTS`. Documentation gaps were reconciled after the audit; non-blocking code debt is recorded in the v3 final/audit reports and `RISKS.md`.

## 2026-08-05 — TASK-BRAND-ABOUT

- Corrected UX-04 with a bilingual product-first closing signature: the About page now begins and ends with lowercase `accreatio`, while retaining the package-derived build version, truthful desktop/W1 document distinction, and existing legal section.
- Added semantic section labeling, decorative-mark semantics, localized About copy, and a restrained responsive closing block that uses the approved dark/light theme tokens with no remote asset or motion.
- Wording approval: Ed Lopez explicitly approved labeling himself “copyright holder and licensor” / “titular de los derechos de autor y licenciante” on 2026-08-05. `LICENSE` was verified as the controlling source and was not rewritten.
- Copyright ownership, year, private-use grant, restrictions, “all rights reserved” language, and license terms are unchanged. The new role label is a clarification only; the separately gated grant/restriction/holder/year wording branch remains unapproved and unchanged.
- Migration: none. No schema, persistence, bridge, AEKR, dependency, telemetry, remote asset, commit, or push behavior changed.

## 2026-08-05 — TASK-EXEC-EVIDENCE

- Added a host-aware confirmation preview that distinguishes Dry run from creation and accurately describes desktop Tracking/Repository/Both and W1 repository-ZIP semantics. Corrected tracking-only planning so it no longer advertises repository documents or attachments.
- Extended the guarded `ExecutionResult` additively with outcome, deterministic step ledger, exact operation-local artifact evidence, and bounded W1 delivery evidence while retaining `operationId` and all compatibility fields.
- Desktop now captures every exact versioned write/copy destination and returns partial results without deletion or rollback. W1 reuses the resolved attachment/export manifest and reports only “download requested,” never browser persistence.
- Updated focused contract/preview/failure/replay and smoke assertions plus desktop/web SOP, FAQ, troubleshooting, privacy, and W1 bridge architecture guidance. No dependency, default Dry run, persisted schema/history evidence, AEKR contract, telemetry, upload, auto-retry, rollback, commit, or push change.
- Migration: atomic internal result-envelope expansion only; persisted data is unchanged. Rollback must revert producer and consumer changes together while preserving already-created user artifacts.
- Correction: W1 download-request failures now report a partial outcome and derive completed step IDs from the step ledger when the ZIP was already built; the desktop SOP now accurately distinguishes saving Mode 1 configuration from writing its YAML during real Repository/Both execution.

## 2026-08-05 — TASK-WEB-ATTACHMENTS

- Added local-only W1 discovery attachment selection with the existing 20-file, 20 MB/file, 100 MB total allowlist limits.
- Split portable attachment metadata from desktop paths and transient browser Blob handles; W1 bytes remain outside project/draft persistence.
- Added deterministic safe archive naming and byte-preserving `docs/product/sources/` ZIP entries for real repository/both exports; dry-run builds no ZIP.
- Migrated the browser draft envelope from schema v4 to v5, stripping attachment data and retaining only an optional count-only reselection notice.
- Reconciled W1 attachment privacy, operator, architecture, FAQ, security, risk, and Project Map statements. No dependency, upload, backend, telemetry, desktop-copy semantic, commit, or push change.

Every material release records scope, data behavior, security implications, migrations, verification evidence, and rollback path. Git remains the immutable technical record.

## Unreleased — Duplicate-safe logical execution

- Added a required opaque operation ID to one shared execution envelope, including the optional transient W1 attachment sidecar shape reserved for the later attachment Task.
- Added bounded, session-only guards at the UI, W1 module, and Electron main-process boundaries. Repeated IDs replay one outcome; equivalent concurrent requests coalesce; a later fresh review remains an intentional rerun using normal versioned files or a new download.
- Fingerprints use canonical snapshots and SHA-256. Future W1 attachments contribute ordered name/size/extension identity only; Blob content, payloads, and digests are not logged or persisted. Electron rejects the W1 sidecar.
- Extended deterministic unit coverage and the Electron/W1 functional smoke harnesses. The host smoke commands remain reserved for the independent Test Engineer.
- Migration: atomic internal bridge signature change only; no draft, settings, history, project, AEKR, or persisted-data migration.
- Rollback: revert this Task atomically because old positional bridge callers are intentionally rejected by the new required envelope.

## Unreleased — Accessible Mode 1 configuration dialog

- Replaced the inline expanded Mode 1 editor with a centered, native `<dialog>`-based configuration workflow (`src/components/mode1/`): Participants, Providers, Execution limits, and Funding as four ordered groups, opened by "Prepare Mode 1 configuration" and reopened by "Edit configuration" from a compact saved summary.
- Numeric limit fields (session duration, iterations per entity, provider invocations, consecutive failures) edit strings, not numbers: empty/intermediate keyboard states are preserved, validation happens on Save with no destructive clamping, and the previously mislabeled "Max retries" field is now accurately named "Maximum consecutive failures" with explicit help text distinguishing it from automatic retries.
- Task fields auto-grow from a bounded minimum to a bounded maximum height (120-240px desktop/tablet, 112-200px narrow mobile) and only become internally scrollable once content actually exceeds that bound.
- Save/Cancel/Escape/Close all discard an in-memory draft cleanly: only a successful Save mutates the project's saved Mode 1 configuration; Cancel and Escape never touch it. Added an explicit "Disable Mode 1" action that retains the last saved configuration for re-enabling, replacing the previous toggle that silently cleared all assignments.
- Dialog width is `min(920px, calc(100vw - 32px))` with one intentional scroll container (`.mode1-dialog__body`); narrow mobile (≤600px) uses a full-viewport treatment; initial focus lands on the dialog heading and returns to the triggering button on close.
- Mode 1 topology that the current AEKR-consumed contract cannot represent (repeated canonical roles, or more than 4 participants) is visibly explained in the dialog and blocks Save with the existing `orchestrationContractUnsupported` guard; it never invents unsupported execution.
- Removed the obsolete `.orchestration-roles`/`.orchestration-role-row`/`.orchestration-budget`/`.provider-status` inline styles; dialog styling consumes only the approved `TASK-DESIGN-THEME` semantic tokens.
- Verification: focused pure-draft tests (numeric bounds, dirty comparison, compatibility gating, normalization), a structural render test (`react-dom/server`, no new dependency) covering dialog semantics/group order/localization/compatibility warning/host messaging/funding state, TypeScript, Prettier, the full unit/integration suite, production build, and Project Map check. Interactive focus-trap, keyboard, responsive, and 200%-zoom evidence remain for the authorized Test Engineer phase.
- Rollback: revert this bounded Task; no persisted schema, migration, or AEKR contract changed.

## Unreleased — Explicit funding policy

- Added a required subscription/CLI funding default (USD zero, paid API prohibited), canonical minor-unit validation, and evidence-gated provider/model-profile capability contracts. Zero production profiles qualify, so paid API is visibly unavailable.
- Removed Claude `max_budget_usd: 1.0` and the commented `budget.ceiling: 10.0`; provenance records `fundingPolicy` while runnable AEKR YAML receives no unsupported funding key.
- Migrated browser drafts to schema v4: absent funding becomes subscription, explicit invalid/API state remains visible and blocking, and future versions fail closed.
- Corrected DEC-012's draft-schema cross-reference to v5 after the later Web Attachments migration.
- Added the inline Funding group and fresh desktop preflight rejection for API profiles/legacy monetary keys. No credentials, pricing lookup, network/provider test call, payment path, fallback, dependency, telemetry, generic shell, commit, or push was added.
- Verification: focused funding/decimal/capability/migration/serialization/UI/preflight fixtures, followed by the authorized regression commands. Independent host/visual evidence remains for the Test Engineer.
- Rollback: revert the Task as one unit without downgrading v4 drafts or restoring misleading monetary YAML.

## Unreleased — Capability-driven provider registry

- Centralized the exact Claude Code and Codex production identities, capabilities, display order, fixed CLI probes, fail-closed subscription-auth classifiers, availability states, and AEKR adapter serializers in a compiled shared registry.
- Kept provider assignment attached to participant IDs using the participant model's existing `provider` field; valid mixed assignments and schema-v3 drafts remain byte/stability compatible, while unknown IDs are preserved with a review warning and block validation/generation.
- Desktop detection now iterates fixed descriptors, bounds and sanitizes untrusted diagnostic output, validates complete IPC results, and refreshes the selected adapters immediately before Mode 1 start. W1 reports `unsupported_host` without disabling deterministic export.
- Updated the current inline editor only: registry-rendered options, localized accessible status text, retry state, preserved input, and honest browser messaging. Funding, attachments, and the later Mode 1 dialog remain unchanged.
- Added a polite live-region announcement to provider status updates without moving focus.
- Security/privacy: no dependency, secret, credential storage, provider download, dynamic plug-in, network/API path, telemetry, shell, generic runner, automatic paid fallback, commit, or push was added.
- Verification: focused registry invariant/classifier/state/eligibility/serializer, draft migration, bridge host-contract, validation, mixed YAML, fail-closed, desktop/W1 parity, TypeScript, formatting, regression, and build checks. Independent host/visual evidence remains for the authorized Test Engineer phase.
- Rollback: revert the complete registry Task as one unit; do not partially restore provider switches or silently rewrite unknown draft provider IDs.

## Unreleased — Ordered participant instances

- Replaced role-keyed agent identity with one to six ordered participant instances, stable safe IDs, repeatable canonical roles, and participant-ID-keyed Mode 1 assignments.
- Updated prompt, governance, and provenance (`schemaVersion: 2`, `plannedParticipants`) to preserve participant identity and order and to state per-instance availability and independent-audit requirements.
- Migrated unversioned/v1/v2 browser drafts to envelope schema version 3 while preserving valid IDs, labels, roles, provider selections, tasks, limits, and order; corrupt ambiguity is recovered deterministically with a visible warning and unknown future versions fail closed.
- Preserved the current AEKR role-keyed YAML for one to four unique roles with participant correlation comments. Repeated-role and five/six-participant Mode 1 save/execution/export fail closed with `orchestrationContractUnsupported`; Mode 0/manual remains available.
- Security/privacy: participant IDs are constrained before serialization; labels and tasks remain inert text; no dependency, network, telemetry, secret, generic shell, commit, push, or upstream AEKR change was introduced.
- Verification: focused domain, migration, prompt/governance/provenance, YAML compatibility, fail-closed, determinism, bridge, TypeScript, formatting, regression, and production-build checks. Independent host/visual evidence remains for the authorized Test Engineer phase.
- Rollback: revert this bounded Task without downgrading saved v3 drafts; retain/export v3 data before using an older build.

## Unreleased — Semantic dark/light theme foundation

- Replaced partial dark/light overrides with one complete semantic token contract derived from the accreatio violet/lavender identity, while keeping neutral working surfaces dominant.
- Corrected light-theme contrast for header language/theme actions and Settings controls; added coherent hover, selected/current, focus-visible, disabled, and semantic status treatments with 44px critical targets and reduced-motion behavior.
- Added explicit navigation/choice semantics and non-submit button types without changing settings, domain, persistence, AEKR, Mode 1, provider/funding, attachment, or About behavior.
- Migration: none. Existing `dark` and `light` settings retain their meaning and persisted representation.
- Security/privacy: CSS and static semantic attributes only; no dependency, remote asset, telemetry, storage, secret, bridge, or execution change.
- Verification: focused theme-contract tests, static legacy-token/literal scans, TypeScript, formatting, unit/integration tests, and production build. Independent Electron/W1 visual and native-select-popup evidence remains in the later Test Engineer phase.
- Rollback: revert this bounded Task; saved settings remain compatible.

## 0.7.0 — Human-gated Orchestration Center

- Added a desktop-only center that preflights, starts, observes, pauses/decides, cancels, and resumes AEKR Mode 1 sessions through its durable schema-v2 state.
- Isolated the upstream interactive CLI behind a fixed-argument, `shell: false` adapter. Human-facing stdout is not parsed; renderer input cannot become a command; the AEKR control directory remains outside generated projects.
- Every gate decision requires explicit confirmation. There is no batch approval, automatic retry, automatic commit, or automatic push; unknown state schemas fail closed.
- Tightened default resource bounds to 30 minutes, one iteration per entity, four provider invocations, and one consecutive failure. Audit tasks require reproducible file/line/impact evidence before reporting a bug.
- Made the Docker dev container use Linux-native volumes for dependencies and build outputs, install its browser smoke dependency, and avoid Windows bind-mount permission and binary mismatches.
- Verification: focused orchestration tests, shared TypeScript checks, production build, Electron execution smoke, browser smoke, and Lighthouse. Public W1 deployment remains on hold under DEC-009.
- Rollback: return to `fc640c0`; AEKR's external durable state is intentionally preserved and can be inspected independently.

## 0.6.0 — Host-aware W1 release preparation

- Made W1 an explicit browser export experience: no desktop startup errors, dead Settings/History/GitHub surfaces, destination path, or tracking-only promise.
- Added schema-versioned draft normalization, hydration-safe autosave, visible persistence states, and confirmed new-draft deletion.
- Defined the Mode 1 preparation contract with editable deterministic tasks, canonical agent-role reconciliation, bounds validation, and no claim that accreatio runs agents.
- Added Cloudflare-compatible static security headers, public in-build Privacy/Terms/FAQ drafts, a no-deploy readiness runbook, and corrected privacy language for hosting request metadata.
- Added a real Electron IPC execution smoke test using an isolated temporary user-data directory; no Git, GitHub, IDE, or persistent user files are touched.
- Verification: 32/32 unit/integration tests, TypeScript, Prettier, production build, real W1 browser smoke (draft lifecycle + Mode 1 + ZIP + legal surface), isolated Electron IPC execution smoke, Lighthouse 94/100/100/100, zero high-severity npm audit findings, and `accreatio-0.6.0-portable.exe` packaging all passed. Cloudflare setup/publication remain on hold under DEC-009; SaaS W3 remains blocked.
- Migration: legacy raw IndexedDB drafts normalize into the v2 envelope on restore/save. Rollback to 0.5.0 may leave a v2 browser draft unreadable; export or clear site data before rollback.

## 0.5.0 — Audit remediation

- Remediated the actionable findings from Claude's full engineering audit of commit `03af351`.
- Centralized domain types, constants, validation, slugging, and UI Git-state transitions across process boundaries.
- Made attachment copying atomically exclusive and added temp-directory integration coverage for filesystem mutations.
- Added CSP, deny-by-default navigation/window/permission controls, a React recovery boundary, pinned dependencies, Prettier, and Windows CI.
- Corrected the documented attachment limit and recorded the legacy migration sunset at 1.0.0.
- Deferred paid Authenticode signing, fully independent human audit, and CSS consolidation with explicit rationale.
- Rollback: commit `03af351` is the verified 0.4.1 baseline.

## 0.4.1 — Preliminary brand assets and web foundation

- Replaced the provisional generated mark with a higher-fidelity extraction based on the owner-provided preliminary artwork.
- Added installable PWA manifest metadata and 192/512 web icons without enabling a hosted backend or data collection.
- Expanded the zero-cost web/SaaS roadmap into explicit W0–W3 delivery gates.
- Verification: 12/12 tests, TypeScript, web build, manifest/icon output, Windows packaging, and portable process smoke test passed.
- Automated visual browser inspection remained unavailable because the integrated connector failed before loading localhost.

## 0.4.0 — accreatio

- Status: Release candidate for private testing.
- Renamed the product and application identity to lowercase `accreatio`; legacy Inflaton and Periastron settings/history migrate on first use.
- Made planned roles mutually exclusive in the UI and backend; adding an agent selects the next unused canonical role.
- Set attachment limits to 20 files, 20 MB each, and 100 MB total per operation.
- Localized the remaining Spanish UI while retaining “discovery” as product terminology.
- Made each planned action expandable with a short generic explanation.
- Added Privacy Policy, Terms of Service, and FAQ drafts; public web distribution remains gated on legal review.
- Added the generated orbital identity asset and Windows icon.
- Rollback: use the prior 0.3.0 release commit; migrated user data remains readable by accreatio.

## 0.3.0 — Inflaton

- Status: Released for private testing.
- Renamed the private product from Periastron to Inflaton.
- Replaced free-form agent responsibilities with the four canonical toolkit roles and fixed responsibility descriptions.
- Moved missing `future_projects` configuration feedback out of Destination and added direct navigation to Settings.
- Selecting a toolkit auto-derives its `future_projects` path when no explicit path exists.
- Kept dry-run as a recommended default, never a prerequisite for actual execution.
- Added fluid typography, wider desktop utilization, smooth single-column reflow, and compact-layout behavior.
- Migration: settings/history from the Periastron application-data directory are read and migrated on first use.
- Rollback: commit `4fc529d` is the verified Periastron 0.2.0 state.
- Verification: 9/9 domain tests, TypeScript checks, production build, packaging, npm audit with zero vulnerabilities, and responsive-process smoke test passed. Automated visual inspection remains unavailable because the browser connector failed before loading the app.

## 0.2.0 — Periastron

- Released for private testing.
- Added attachments, 1–4 agent roles, bilingual UI, GitHub CLI integration, versioned writes, local history, project provenance, licensing, and security/web strategy documentation.
- Verification: 7/7 domain tests, TypeScript, build, packaging, npm audit, and portable smoke test passed.

## 0.1.0 — Prompt to Start

- Initial local-first MVP, dry-run, prompt/action preview, filesystem scaffold, Git init, and portable Windows build.


## 2026-09-05 - Archive, local artifacts and email-account preview

Owner authorized historical archiving, the shared `.local/logs/` and `.local/cache/` standard (also applied in AEKR), and local ZIP with managed email OTP plus five rolling 24-hour service authorizations. [Delivery and evidence](docs/ACCOUNT_RELEASE_2026-09-05.md).

Preview alias: `https://archive-email-auth-preview.accreatio.pages.dev`; accepted configuration candidate `af1f6b16-966a-4d75-a66e-322c15e1f609`, source `db5c6c8c841175d6b3db4d4236448fa542cacf54`. Outgoing initial preview `2e451918-dbdc-427a-955f-af9514c24b9f` is preserved with its configuration defect recorded. Production remains `11235c8c-108f-46f3-8cce-fb88a144330b`; desktop remains frozen. Local integration and remote D1 admission pass; actual hosted human OTP/account acceptance remains pending.


## 2026-09-05 - Mandatory central sign-in and admin-only Blog

Owner correction implemented: a mandatory sign-in card after What stays local, verified-session creator gate, no upper sign-in/retry, and administrator-only Blog navigation/read/publish. A designer-auditor compared three options, selected a third welcome step and returned PASS after visual/code review and the final runtime delta. The existing Cloudflare Access envelope remains; its OTP can precede website loading.

Outgoing alias target `af1f6b16-966a-4d75-a66e-322c15e1f609` is retained. Replacement `a3f4f09f-f24c-4a3e-abfd-d1a3fa34ce64`, source `b0bd09d13b7f7d0916b34705b8f0f7d1dc7d19a0`, was deployed at `https://archive-email-auth-preview.accreatio.pages.dev`. 240 tests and full verification plus real Workers JWKS diagnostic pass; anonymous protection and AJAX401 behavior are checked. Production and its deployment are unchanged. [Design, review, evidence and OTP boundary](docs/SIGNIN_FLOW_2026-09-05.md).

## 2026-09-05 - Public Blog reading, explicit login and fluid navigation

The latest owner clarification supersedes administrator-only Blog reading. About and published posts are public; creation and publishing remain separately protected. The central sign-in action opens the email-code authenticator, returns to the creator and reuses verified sessions. The service worker excludes authentication routes. Compact upper-right navigation replaces the large controls; the neutral Welcome badge is removed, and transitions/scrolling respect reduced motion.

The outgoing preview `a3f4f09f-f24c-4a3e-abfd-d1a3fa34ce64` is preserved. Replacement `a6446cfd-1356-49a2-9ffd-7e4e80295e6c`, source `80362c391888a1bafc18c06077c2ca1996bbeecc`, is live at `https://archive-email-auth-preview.accreatio.pages.dev`. The alias alone receives public shell access; its account/admin routes retain a more-specific Access application. Historical previews and production retain their prior protection. Full verification passes with 245 tests and Lighthouse 96/100/100; hosted Chromium confirms public posts and the actual email-code form with a controlling worker. Completing a real OTP remains pending owner participation. [Current behavior, scoped hosting configuration and validation boundaries](docs/PUBLIC_SIGNIN_2026-09-05.md).

## 2026-10-25 — Analytics public-signal producer

- Ed / HOC's two supplied briefs authorize the bounded producer and separate prospective commercial choices, with Analytics as the central control plane. [Decision and implementation](docs/ANALYTICS_PRODUCER_2026-10-25.md); [sanitized validation](docs/ANALYTICS_PRODUCER_EVIDENCE_2026-10-25.json).
- The clean isolated candidate starts at canonical `0844b08e12147ef5f791f62e471348de1b9fa8de`; the primary checkout's unrelated dirty state is preserved. There is no migration or deployment in this change. Real activation remains dependent on the exact central source connection, current notice/rights and partner agreements.
- Rollback: pause the central source first, withdraw/reconcile commercial permissions using the current rights surface, then revert this bounded candidate; do not silently reactivate old analytics notice versions or use historical data as commercial permission.
