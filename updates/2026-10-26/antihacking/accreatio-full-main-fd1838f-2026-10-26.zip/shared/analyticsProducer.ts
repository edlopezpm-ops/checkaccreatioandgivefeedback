/** Public, independently chosen signals only. Never pass a project/account here. */
export const ANALYTICS_NOTICE_VERSION = "2026-10-25";
export const ANALYTICS_PURPOSES = [
  "aekr_marketing",
  "onsite_personalized_ads",
  "external_ad_audiences",
  "partner_intro",
  "audience_licensing",
] as const;
export type AnalyticsPurpose = (typeof ANALYTICS_PURPOSES)[number];
export const ANALYTICS_EVENTS = [
  "public_product_viewed",
  "pricing_viewed",
  "public_integration_viewed",
  "commercial_interest_selected",
  "offer_viewed",
  "offer_clicked",
  "partner_intro_requested",
] as const;
export const ANALYTICS_CATEGORIES = [
  "automation",
  "marketing",
  "development",
  "time_tracking",
  "integration",
] as const;
export type AnalyticsEvent = {
  event: (typeof ANALYTICS_EVENTS)[number];
  category?: (typeof ANALYTICS_CATEGORIES)[number];
  offer_id?: "aekr-contextual-intro";
};
export interface SourceConfiguration {
  schema_version: 1;
  source_id: "accreatio-public-production" | "accreatio-public-preview";
  product: "accreatio";
  environment: "production" | "preview";
  mode: "production";
  version: number;
  issued_at: string;
  expires_at: string;
  enabled: boolean;
  events: string[];
  fields: string[];
  purposes: string[];
  retention_days: number;
  destinations: string[];
  restriction_reason: string | null;
}
const object = (value: unknown): value is Record<string, unknown> =>
  Boolean(value && typeof value === "object" && !Array.isArray(value));
const closedList = (value: unknown, allowed: readonly string[]) =>
  Array.isArray(value) &&
  value.length <= allowed.length &&
  new Set(value).size === value.length &&
  value.every((item) => typeof item === "string" && allowed.includes(item));
export function parseSourceConfiguration(
  value: unknown,
  now = Date.now(),
): SourceConfiguration | null {
  if (!object(value)) return null;
  if (
    Object.keys(value).some(
      (key) =>
        ![
          "schema_version",
          "source_id",
          "product",
          "environment",
          "mode",
          "version",
          "issued_at",
          "expires_at",
          "enabled",
          "events",
          "fields",
          "purposes",
          "retention_days",
          "destinations",
          "restriction_reason",
        ].includes(key),
    )
  )
    return null;
  const issued = Date.parse(String(value.issued_at));
  const expiry = Date.parse(String(value.expires_at));
  if (
    value.schema_version !== 1 ||
    value.product !== "accreatio" ||
    value.mode !== "production" ||
    !["production", "preview"].includes(String(value.environment)) ||
    value.source_id !== `accreatio-public-${value.environment}` ||
    typeof value.issued_at !== "string" ||
    typeof value.expires_at !== "string" ||
    !Number.isSafeInteger(value.version) ||
    Number(value.version) < 1 ||
    !Number.isFinite(issued) ||
    !Number.isFinite(expiry) ||
    issued > now + 30000 ||
    expiry <= now ||
    expiry <= issued ||
    expiry - issued > 300000 ||
    typeof value.enabled !== "boolean" ||
    !closedList(value.events, ANALYTICS_EVENTS) ||
    !closedList(value.fields, ["category", "offer_id"]) ||
    !closedList(value.purposes, [
      "optional_analytics",
      ...ANALYTICS_PURPOSES,
    ]) ||
    !Number.isInteger(value.retention_days) ||
    Number(value.retention_days) < 1 ||
    Number(value.retention_days) > 30 ||
    !Array.isArray(value.destinations) ||
    value.destinations.length > 20 ||
    !value.destinations.every(
      (v) => typeof v === "string" && /^[a-z0-9][a-z0-9_-]{0,79}$/.test(v),
    ) ||
    !(
      value.restriction_reason === null ||
      (typeof value.restriction_reason === "string" &&
        /^[a-z0-9_-]{1,80}$/.test(value.restriction_reason))
    )
  )
    return null;
  return {
    schema_version: 1,
    source_id: value.source_id as SourceConfiguration["source_id"],
    product: "accreatio",
    environment: value.environment as SourceConfiguration["environment"],
    mode: "production",
    version: Number(value.version),
    issued_at: value.issued_at,
    expires_at: value.expires_at,
    enabled: value.enabled,
    events: value.events as string[],
    fields: value.fields as string[],
    purposes: value.purposes as string[],
    retention_days: Number(value.retention_days),
    destinations: value.destinations,
    restriction_reason: value.restriction_reason as string | null,
  };
}
export function parseAnalyticsEvent(value: unknown): AnalyticsEvent | null {
  if (
    !object(value) ||
    Object.keys(value).some(
      (key) => !["event", "category", "offer_id"].includes(key),
    ) ||
    !ANALYTICS_EVENTS.includes(value.event as AnalyticsEvent["event"]) ||
    (value.category !== undefined &&
      !ANALYTICS_CATEGORIES.includes(value.category as never)) ||
    (value.offer_id !== undefined && value.offer_id !== "aekr-contextual-intro")
  )
    return null;
  return {
    event: value.event as AnalyticsEvent["event"],
    ...(value.category
      ? { category: value.category as AnalyticsEvent["category"] }
      : {}),
    ...(value.offer_id ? { offer_id: "aekr-contextual-intro" as const } : {}),
  };
}
export const advertisingSharingPurpose = (purpose: string) =>
  ["external_ad_audiences", "audience_licensing"].includes(purpose);

export interface PermissionReceipt {
  permission_ref: string;
  status: "granted" | "denied" | "withdrawn";
  expires_at: string;
  granted_at: string | null;
  withdrawn_at: string | null;
}
/** Central database time owns expiry. A retry never extends this receipt. */
export function parsePermissionReceipt(
  value: unknown,
  now = Date.now(),
): PermissionReceipt | null {
  if (
    !object(value) ||
    typeof value.permission_ref !== "string" ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(
      value.permission_ref,
    ) ||
    !["granted", "denied", "withdrawn"].includes(String(value.status)) ||
    typeof value.expires_at !== "string"
  )
    return null;
  const expires = Date.parse(value.expires_at);
  if (
    !Number.isFinite(expires) ||
    expires <= now ||
    expires > now + 30 * 86400000 + 60000
  )
    return null;
  for (const field of ["granted_at", "withdrawn_at"] as const) {
    const at = value[field];
    if (
      at !== null &&
      (typeof at !== "string" ||
        !Number.isFinite(Date.parse(at)) ||
        Date.parse(at) > now + 60000 ||
        Date.parse(at) >= expires)
    )
      return null;
  }
  if (
    value.status === "granted" &&
    (value.granted_at === null || value.withdrawn_at !== null)
  )
    return null;
  return {
    permission_ref: value.permission_ref,
    status: value.status as PermissionReceipt["status"],
    expires_at: value.expires_at,
    granted_at: value.granted_at as string | null,
    withdrawn_at: value.withdrawn_at as string | null,
  };
}
