import type { Locale } from "./types";

export const termsHref = (locale: Locale): string =>
  `/legal/terms${locale === "es" ? "-es" : ""}.html?lang=${locale}`;

export const legalHref = (
  document: "privacy" | "cookies" | "faq",
  locale: Locale,
): string => `/legal/${document}.html?lang=${locale}`;

export function policyDocument(href: string, base: string, locale: Locale) {
  const url = new URL(href, base);
  if (url.origin !== new URL(base).origin) return null;
  const match = /^\/legal\/(terms(?:-es)?|privacy|cookies)(?:\.html)?$/u.exec(
    url.pathname,
  );
  if (!match) return null;
  const requested = url.searchParams.get("lang");
  const language =
    requested === "en" || requested === "es" ? requested : locale;
  const kind =
    match[1] === "privacy"
      ? "privacy"
      : match[1] === "cookies"
        ? "cookies"
        : "terms";
  return {
    kind,
    locale: language,
    href: kind === "terms" ? termsHref(language) : legalHref(kind, language),
    hash: url.hash,
  };
}
