import {
  ANALYTICS_CATEGORIES,
  ANALYTICS_NOTICE_VERSION,
  ANALYTICS_PURPOSES,
  advertisingSharingPurpose,
  parseAnalyticsEvent,
  parseSourceConfiguration,
  parsePermissionReceipt,
  type AnalyticsEvent,
  type AnalyticsPurpose,
  type SourceConfiguration,
} from "../../shared/analyticsProducer";
import { browserStorage, restrictiveSignal } from "./collection";

const KEY = "accreatio:commercial-preferences:2026-10-25";
const CAPABILITY = "accreatio:analytics-browser-capability:v1";
type Choice = {
  status: "granted" | "denied" | "withdrawn";
  permission_ref?: string;
  recipients: string[];
  expires_at: number;
  pending?: boolean;
};
type Choices = Partial<Record<AnalyticsPurpose, Choice>>;
let configuration: SourceConfiguration | null = null;
export function commercialChoices(): Choices {
  try {
    const value = JSON.parse(browserStorage()?.getItem(KEY) ?? "{}");
    const choices: Choices = {};
    if (!value || typeof value !== "object" || Array.isArray(value)) return {};
    for (const purpose of ANALYTICS_PURPOSES) {
      const choice = value[purpose];
      if (
        choice &&
        ["granted", "denied", "withdrawn"].includes(choice.status) &&
        Array.isArray(choice.recipients) &&
        choice.recipients.length <= 20 &&
        choice.recipients.every(
          (v: unknown) =>
            typeof v === "string" && /^[a-z0-9][a-z0-9_-]{0,79}$/.test(v),
        ) &&
        Number.isSafeInteger(choice.expires_at) &&
        choice.expires_at > Date.now() &&
        (choice.status !== "granted" ||
          (typeof choice.permission_ref === "string" &&
            /^[A-Za-z0-9_-]{1,96}$/.test(choice.permission_ref)))
      )
        choices[purpose] = choice;
    }
    return choices;
  } catch {
    return {};
  }
}
function save(choices: Choices) {
  const storage = browserStorage();
  if (!storage) throw Error("commercial_storage");
  const value = JSON.stringify(choices);
  storage.setItem(KEY, value);
  if (storage.getItem(KEY) !== value) throw Error("commercial_storage");
}
function capability(create: boolean) {
  const storage = browserStorage();
  let value = storage?.getItem(CAPABILITY);
  if (value && /^[0-9a-f]{64}$/.test(value)) return value;
  if (!create || !storage) throw Error("commercial_storage");
  value = Array.from(crypto.getRandomValues(new Uint8Array(32)), (v) =>
    v.toString(16).padStart(2, "0"),
  ).join("");
  storage.setItem(CAPABILITY, value);
  if (storage.getItem(CAPABILITY) !== value) throw Error("commercial_storage");
  return value;
}
async function call(action: string, body: unknown) {
  const response = await fetch(`/api/collection/${action}`, {
    method: "POST",
    credentials: "omit",
    cache: "no-store",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${capability(action === "preference")}`,
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(4000),
  });
  if (!response.ok) throw Error("commercial_not_confirmed");
  return response.json();
}
export async function refreshSourceConfiguration() {
  configuration = null;
  try {
    const response = await fetch("/api/collection/config", {
      credentials: "omit",
      cache: "no-store",
      signal: AbortSignal.timeout(4000),
    });
    if (!response.ok) return null;
    configuration = parseSourceConfiguration(await response.json());
    return configuration;
  } catch {
    return null;
  }
}
export async function setCommercialChoice(
  purpose: AnalyticsPurpose,
  enabled: boolean,
) {
  const current = commercialChoices();
  const previous = current[purpose];
  const expires_at = Date.now() + 30 * 86400000;
  // Stop here before any request; a missing remote confirmation never grants.
  current[purpose] = {
    status: previous?.status === "granted" ? "withdrawn" : "denied",
    recipients: previous?.recipients ?? [],
    expires_at,
    pending: true,
  };
  save(current);
  if (!enabled && !browserStorage()?.getItem(CAPABILITY)) {
    current[purpose] = {
      ...current[purpose]!,
      status: "withdrawn",
      pending: false,
    };
    save(current);
    return current;
  }
  const config = enabled ? await refreshSourceConfiguration() : configuration;
  if (
    enabled &&
    (!config?.enabled ||
      !config.purposes.includes(purpose) ||
      (advertisingSharingPurpose(purpose) &&
        (restrictiveSignal() || !config.destinations.length)))
  )
    throw Error("commercial_purpose_unavailable");
  const recipients = enabled
    ? [...(config?.destinations ?? [])]
    : (previous?.recipients ?? []);
  const status = enabled ? "granted" : "withdrawn";
  const result = parsePermissionReceipt(
    await call("preference", {
      purpose,
      status,
      notice_version: ANALYTICS_NOTICE_VERSION,
      categories: enabled ? [...ANALYTICS_CATEGORIES] : [],
      recipients,
      gpc: restrictiveSignal(),
    }),
  );
  if (!result || result.status !== status)
    throw Error("commercial_unconfirmed");
  // Re-read after the await. Withdrawal in another tab takes precedence.
  const latest = commercialChoices();
  if (JSON.stringify(latest[purpose]) !== JSON.stringify(current[purpose])) {
    if (enabled)
      await call("preference", {
        purpose,
        status: "withdrawn",
        notice_version: ANALYTICS_NOTICE_VERSION,
        categories: [],
        recipients: [],
        gpc: restrictiveSignal(),
      });
    throw Error("commercial_choice_changed");
  }
  latest[purpose] = {
    status,
    permission_ref: result.permission_ref,
    recipients,
    expires_at: Math.min(expires_at, Date.parse(result.expires_at)),
  };
  save(latest);
  return latest;
}
export async function recordPublicSignal(
  purpose: AnalyticsPurpose,
  event: AnalyticsEvent,
) {
  try {
    if (!parseAnalyticsEvent(event)) return false;
    let choice = commercialChoices()[purpose];
    if (
      choice?.status !== "granted" ||
      !choice.permission_ref ||
      (restrictiveSignal() && advertisingSharingPurpose(purpose))
    )
      return false;
    const config = await refreshSourceConfiguration();
    choice = commercialChoices()[purpose];
    if (
      !config?.enabled ||
      !config.purposes.includes(purpose) ||
      !config.events.includes(event.event) ||
      choice?.status !== "granted" ||
      !choice.permission_ref ||
      (event.category && !config.fields.includes("category")) ||
      (event.offer_id && !config.fields.includes("offer_id"))
    )
      return false;
    const result = await call("event", {
      ...event,
      purpose,
      permission_ref: choice.permission_ref,
      event_id: crypto.randomUUID(),
      schema_version: 1,
      occurred_at: new Date().toISOString(),
      source_configuration_version: config.version,
    });
    return result.accepted === true;
  } catch {
    return false;
  }
}
export async function enforceCommercialGpc() {
  if (!restrictiveSignal()) return;
  for (const purpose of ANALYTICS_PURPOSES) {
    if (
      advertisingSharingPurpose(purpose) &&
      (commercialChoices()[purpose]?.status === "granted" ||
        commercialChoices()[purpose]?.pending === true)
    ) {
      try {
        await setCommercialChoice(purpose, false);
      } catch {
        /* Local withdrawal remains effective. */
      }
    }
  }
}
