import { useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { policyDocument } from "../legal";
import type { Locale } from "../types";
import "./help/HelpSurfaces.css";
import "./PolicyDocuments.css";

type PolicyRequest = NonNullable<ReturnType<typeof policyDocument>>;

// Read the published canonical document on every opening, including legal-only
// releases. No copied policy text or additional consent/collection action.
function documentContent(html: string, request: PolicyRequest) {
  const page = new DOMParser().parseFromString(html, "text/html");
  const main = page.querySelector("main.legal-prose");
  if (!main) throw new Error("Legal document unavailable");
  const title = main.querySelector("h1")?.textContent ?? "";
  main.querySelector("h1")?.remove();
  main.querySelector("nav")?.remove();
  main
    .querySelectorAll("script, style, link, iframe, object, embed, form, base")
    .forEach((element) => element.remove());
  for (const element of main.querySelectorAll("*")) {
    for (const attribute of [...element.attributes]) {
      if (attribute.name.startsWith("on"))
        element.removeAttribute(attribute.name);
    }
  }
  const base = new URL(request.href, location.origin);
  for (const link of main.querySelectorAll<HTMLAnchorElement>("a[href]")) {
    const target = new URL(link.getAttribute("href")!, base);
    if (!["https:", "http:", "mailto:"].includes(target.protocol)) {
      link.removeAttribute("href");
      continue;
    }
    const policy = policyDocument(target.href, base.href, request.locale);
    if (policy) {
      link.href = policy.href + policy.hash;
      link.setAttribute("aria-haspopup", "dialog");
    } else {
      if (
        target.origin === base.origin &&
        (target.pathname === "/" ||
          /^\/legal\/(?:cookies|faq)(?:\.html)?$/u.test(target.pathname))
      )
        target.searchParams.set("lang", request.locale);
      link.href = target.href;
      if (target.origin !== base.origin && target.protocol !== "mailto:") {
        link.target = "_blank";
        link.rel = "noopener noreferrer";
      }
    }
  }
  return { title, html: main.innerHTML, lang: page.documentElement.lang };
}

function PolicyDialog({
  request,
  onClose,
}: {
  request: PolicyRequest;
  onClose(): void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const heading = useRef<HTMLHeadingElement>(null);
  const prose = useRef<HTMLDivElement>(null);
  const [content, setContent] = useState<ReturnType<typeof documentContent>>();
  const [failed, setFailed] = useState(false);
  const es = request.locale === "es";
  const title =
    request.kind === "terms"
      ? es
        ? "Términos de uso"
        : "Terms of Service"
      : request.kind === "cookies"
        ? es
          ? "Cookies y almacenamiento del dispositivo"
          : "Cookies and device storage"
        : es
          ? "Política de privacidad"
          : "Privacy Policy";
  useEffect(() => {
    const surface = dialog.current!;
    const trigger = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    const rootOverflow = document.documentElement.style.overflow;
    surface.showModal();
    document.body.style.overflow = "hidden";
    document.documentElement.style.overflow = "hidden";
    heading.current?.focus();
    return () => {
      surface.close();
      document.body.style.overflow = overflow;
      document.documentElement.style.overflow = rootOverflow;
      if (trigger?.isConnected) trigger.focus({ preventScroll: true });
    };
  }, []);
  useEffect(() => {
    const controller = new AbortController();
    setContent(undefined);
    setFailed(false);
    heading.current?.focus();
    void fetch(request.href, {
      cache: "no-store",
      credentials: "omit",
      signal: controller.signal,
    })
      .then((response) => {
        if (!response.ok) throw new Error("Legal document unavailable");
        return response.text();
      })
      .then((html) => {
        if (!controller.signal.aborted)
          setContent(documentContent(html, request));
      })
      .catch(() => {
        if (!controller.signal.aborted) setFailed(true);
      });
    return () => controller.abort();
  }, [request.href]);
  useEffect(() => {
    if (!content || !prose.current) return;
    prose.current.scrollTop = 0;
    if (request.hash)
      [...prose.current.querySelectorAll<HTMLElement>("[id]")]
        .find((element) => `#${element.id}` === request.hash)
        ?.scrollIntoView({ block: "start" });
  }, [content, request.hash]);
  return (
    <dialog
      ref={dialog}
      className="help-dialog policy-document-dialog"
      aria-labelledby="policy-document-title"
      lang={request.locale}
      onKeyDown={(event) => {
        if (event.key !== "Tab") return;
        const controls = [
          ...event.currentTarget.querySelectorAll<HTMLElement>(
            'a[href], button:not([disabled]), [tabindex="0"]',
          ),
        ].filter((element) => element.getClientRects().length > 0);
        const first = controls[0];
        const last = controls.at(-1);
        if (
          (event.shiftKey &&
            (document.activeElement === first ||
              document.activeElement === heading.current)) ||
          (!event.shiftKey && document.activeElement === last)
        ) {
          event.preventDefault();
          (event.shiftKey ? last : first)?.focus();
        }
      }}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target !== event.currentTarget) return;
        const bounds = event.currentTarget.getBoundingClientRect();
        if (
          event.clientX < bounds.left ||
          event.clientX > bounds.right ||
          event.clientY < bounds.top ||
          event.clientY > bounds.bottom
        )
          onClose();
      }}
    >
      <header className="help-surface__header">
        <h2 id="policy-document-title" ref={heading} tabIndex={-1}>
          {title}
        </h2>
        <button
          type="button"
          onClick={onClose}
          aria-label={es ? "Cerrar documento" : "Close document"}
        >
          <X aria-hidden="true" />
        </button>
      </header>
      {failed ? (
        <p role="alert">
          {es
            ? "No se pudo cargar el documento. "
            : "The document could not load. "}
          <a href={request.href} data-policy-native>
            {es ? "Abrir documento completo" : "Open full document"}
          </a>
        </p>
      ) : content ? (
        <div
          ref={prose}
          className="policy-document-prose"
          lang={content.lang}
          aria-label={content.title}
          // Only the current same-origin canonical legal main is rendered;
          // executable elements, handlers and unsafe link schemes are removed.
          dangerouslySetInnerHTML={{ __html: content.html }}
        />
      ) : (
        <p role="status">{es ? "Cargando documento…" : "Loading document…"}</p>
      )}
    </dialog>
  );
}

export function PolicyDocuments({ locale }: { locale: Locale }) {
  const [request, setRequest] = useState<PolicyRequest | null>(null);
  useEffect(() => {
    if (
      typeof HTMLDialogElement === "undefined" ||
      typeof HTMLDialogElement.prototype.showModal !== "function"
    )
      return;
    const open = (event: MouseEvent) => {
      if (
        event.defaultPrevented ||
        event.button !== 0 ||
        event.metaKey ||
        event.ctrlKey ||
        event.shiftKey ||
        event.altKey
      )
        return;
      const link =
        event.target instanceof Element
          ? event.target.closest<HTMLAnchorElement>("a[href]")
          : null;
      if (
        !link ||
        link.hasAttribute("download") ||
        link.hasAttribute("data-policy-native")
      )
        return;
      const document = policyDocument(link.href, location.href, locale);
      if (!document) return;
      event.preventDefault();
      setRequest(document);
    };
    document.addEventListener("click", open);
    return () => document.removeEventListener("click", open);
  }, [locale]);
  return request ? (
    <PolicyDialog request={request} onClose={() => setRequest(null)} />
  ) : null;
}
