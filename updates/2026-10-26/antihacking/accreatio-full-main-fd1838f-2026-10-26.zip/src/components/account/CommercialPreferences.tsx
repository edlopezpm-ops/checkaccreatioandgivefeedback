import { useEffect, useState } from "react";
import type { Locale } from "../../types";
import {
  commercialChoices,
  enforceCommercialGpc,
  recordPublicSignal,
  refreshSourceConfiguration,
  setCommercialChoice,
} from "../../account/analyticsProducer";
import { restrictiveSignal } from "../../account/collection";
import {
  ANALYTICS_PURPOSES,
  advertisingSharingPurpose,
  type AnalyticsPurpose,
  type SourceConfiguration,
} from "../../../shared/analyticsProducer";
const labels: Record<AnalyticsPurpose, [string, string]> = {
  aekr_marketing: [
    "Intereses comerciales de AEKR",
    "AEKR commercial interests",
  ],
  onsite_personalized_ads: [
    "Personalizar ofertas dentro de AEKR",
    "Personalize offers within AEKR",
  ],
  external_ad_audiences: [
    "Audiencias publicitarias externas",
    "External advertising audiences",
  ],
  partner_intro: [
    "Solicitudes de contacto a un socio elegido",
    "Contact requests to a chosen partner",
  ],
  audience_licensing: [
    "Licencias de audiencias a destinatarios indicados",
    "Audience licensing to named recipients",
  ],
};
export function CommercialPreferences({ locale }: { locale: Locale }) {
  const es = locale === "es";
  const [config, setConfig] = useState<SourceConfiguration | null>(null);
  const [choices, setChoices] = useState(commercialChoices);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("");
  const [category, setCategory] = useState("development");
  const [opened, setOpened] = useState(false);
  async function refresh() {
    setConfig(await refreshSourceConfiguration());
    await enforceCommercialGpc();
    setChoices(commercialChoices());
  }
  useEffect(() => {
    void enforceCommercialGpc();
    const timer = opened ? setInterval(() => void refresh(), 30000) : undefined;
    const changed = () => {
      setChoices(commercialChoices());
      void enforceCommercialGpc();
    };
    window.addEventListener("storage", changed);
    return () => {
      clearInterval(timer);
      window.removeEventListener("storage", changed);
    };
  }, [opened]);
  async function choose(purpose: AnalyticsPurpose, enabled: boolean) {
    setBusy(true);
    try {
      await setCommercialChoice(purpose, enabled);
      setStatus(
        es
          ? "Elección confirmada para esta finalidad y este navegador."
          : "Choice confirmed for this purpose and browser.",
      );
      if (enabled && purpose === "aekr_marketing")
        await recordPublicSignal(purpose, {
          event: "public_product_viewed",
          category: "development",
        });
    } catch {
      setStatus(
        es
          ? "Uso opcional detenido aquí. No se confirmó la operación remota; vuelve a intentarlo con conexión."
          : "Optional use stopped here. The remote operation was not confirmed; retry when connected.",
      );
    } finally {
      setChoices(commercialChoices());
      setBusy(false);
    }
  }
  return (
    <details
      onToggle={(event) => {
        setOpened(event.currentTarget.open);
        if (event.currentTarget.open) void refresh();
      }}
    >
      <summary>
        {es
          ? "Ofertas y usos comerciales opcionales"
          : "Offers and optional commercial uses"}
      </summary>
      <p>
        {es
          ? "Cada opción es independiente de la analítica, la encuesta y el acceso al servicio. Sólo señales de páginas públicas, intereses elegidos y acciones sobre ofertas; nunca proyectos, código, archivos, conversaciones, datos de la cuenta ni datos de conectores. Alcance: accreatio y este navegador; hasta 30 días. AEKR administra los permisos desde Analytics."
          : "Each choice is independent of analytics, the survey and service access. Only public-page signals, chosen interests and offer actions; never projects, code, files, conversations, account data or connector data. Scope: accreatio and this browser; up to 30 days. AEKR manages permissions through Analytics."}
      </p>
      <button
        type="button"
        className="secondary"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          let complete = true;
          for (const purpose of ANALYTICS_PURPOSES) {
            try {
              await setCommercialChoice(purpose, false);
            } catch {
              complete = false;
            }
          }
          setChoices(commercialChoices());
          setConfig(await refreshSourceConfiguration());
          setBusy(false);
          setStatus(
            complete
              ? es
                ? "Retirada confirmada para todos los usos comerciales."
                : "Withdrawal confirmed for every commercial purpose."
              : es
                ? "Usos detenidos aquí; hay retiradas remotas pendientes. Reintenta con conexión."
                : "Uses stopped here; remote withdrawals remain pending. Retry when connected.",
          );
        }}
      >
        {es
          ? "Retirar todos los usos comerciales / reintentar"
          : "Withdraw every commercial use / retry"}
      </button>
      <p role="status">
        {config?.enabled
          ? es
            ? `Fuente conectada · configuración ${config.version}`
            : `Source connected · configuration ${config.version}`
          : es
            ? "Usos comerciales sin activar. Puedes retirar una elección anterior."
            : "Commercial uses are inactive. You can withdraw a previous choice."}
      </p>
      <p>
        {es ? "Destinatarios indicados: " : "Named recipients: "}
        {config?.destinations.length
          ? config.destinations.join(", ")
          : es
            ? "ninguno habilitado"
            : "none enabled"}
      </p>
      <p>
        {es
          ? "Categorías: automatización, marketing, desarrollo, registro de tiempo e integraciones."
          : "Categories: automation, marketing, development, time tracking and integrations."}
      </p>
      {ANALYTICS_PURPOSES.map((purpose) => {
        const checked = choices[purpose]?.status === "granted";
        const available =
          config?.enabled &&
          config.purposes.includes(purpose) &&
          (!advertisingSharingPurpose(purpose) ||
            (!restrictiveSignal() && config.destinations.length > 0));
        return (
          <label key={purpose}>
            <input
              type="checkbox"
              checked={checked}
              disabled={
                busy ||
                (!checked && (!available || purpose === "partner_intro"))
              }
              onChange={(event) => void choose(purpose, event.target.checked)}
            />
            {labels[purpose][es ? 0 : 1]}
          </label>
        );
      })}
      <p>
        {es
          ? "Las solicitudes a socios sólo se autorizan junto al formulario que identifica al destinatario y los campos. GPC bloquea venta/compartición publicitaria; no concede ni retira permisos de servicio o de analítica."
          : "Partner requests are authorized only beside a form naming the recipient and fields. GPC blocks advertising sale/sharing; it does not grant or withdraw service or analytics permissions."}
      </p>
      {choices.aekr_marketing?.status === "granted" && (
        <div>
          <label>
            {es ? "Interés comercial elegido" : "Chosen commercial interest"}
            <select
              value={category}
              onChange={(event) => setCategory(event.target.value)}
            >
              <option value="development">
                {es ? "Desarrollo" : "Development"}
              </option>
              <option value="automation">
                {es ? "Automatización" : "Automation"}
              </option>
              <option value="integration">
                {es ? "Integraciones" : "Integrations"}
              </option>
            </select>
          </label>
          <button
            type="button"
            className="secondary"
            disabled={busy || !config?.enabled}
            onClick={() =>
              void recordPublicSignal("aekr_marketing", {
                event: "commercial_interest_selected",
                category: category as
                  "development" | "automation" | "integration",
              }).then(async (ok) => {
                setConfig(await refreshSourceConfiguration());
                setStatus(
                  ok
                    ? es
                      ? "Interés confirmado."
                      : "Interest confirmed."
                    : es
                      ? "No se compartió el interés; fuente pausada o no disponible."
                      : "Interest was not shared; source paused or unavailable.",
                );
              })
            }
          >
            {es ? "Compartir este interés" : "Share this interest"}
          </button>
        </div>
      )}
      {status && <p role="status">{status}</p>}
    </details>
  );
}
