import { legalHref, termsHref } from "../../legal";
import {
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type FormEvent,
} from "react";
import { createPortal } from "react-dom";
import type { Locale } from "../../types";
import {
  COOKIE_PREFERENCE_KEY,
  readCookiePreference,
  saveOptionalChoice,
  type CookiePreference,
} from "../../account/cookiePreferences";
import {
  browserStorage,
  restrictiveSignal,
  recordUsage,
  retryWithdrawals,
  withdrawCollection,
  stopPendingCollection,
  submitResearch,
  downloadOptionalData,
} from "../../account/collection";
import {
  RESEARCH_FIELDS,
  COLLECTION_VERSION,
  type ResearchAnswers,
} from "../../../shared/collection";
import { AccountRightsAccess } from "./AccountRightsAccess";
import { loadWebAuthMethods } from "../../account/webClient";
import type { WebAuthMethods } from "../../account/contracts";
import "./cookiePreferences.css";
import { CommercialPreferences } from "./CommercialPreferences";
import { commercialChoices } from "../../account/analyticsProducer";

const fieldNames: Record<keyof typeof RESEARCH_FIELDS, [string, string]> = {
  region: ["Región general", "Broad region"],
  role: ["Rol profesional", "Professional role"],
  industry: ["Sector", "Industry"],
  experience: ["Experiencia", "Experience"],
  teamSize: ["Tamaño del equipo", "Team size"],
  tools: ["Herramienta principal", "Main tool"],
  goal: ["Objetivo", "Goal"],
  challenge: ["Dificultad principal", "Main challenge"],
  integration: ["Integración deseada", "Desired integration"],
  priority: ["Función prioritaria", "Feature priority"],
  willingnessToPay: [
    "Disposición a pagar (USD/mes)",
    "Willingness to pay (USD/month)",
  ],
  satisfaction: ["Valoración (1–5)", "Rating (1–5)"],
  frequency: ["Frecuencia de uso", "Usage frequency"],
};
function download(value: unknown) {
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(value, null, 2)], {
      type: "application/json;charset=utf-8",
    }),
  );
  const link = document.createElement("a");
  link.href = url;
  link.download = "accreatio-optional-data.json";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function pendingCapability(value: string | null) {
  if (value === null) return true;
  try {
    return JSON.parse(value)?.state === "pending";
  } catch {
    return true;
  }
}
export function CookiePreferences({ locale }: { locale: Locale }) {
  const es = locale === "es",
    dialog = useRef<HTMLDialogElement>(null);
  const [preference, setPreference] = useState<CookiePreference | null>(null);
  const [banner, setBanner] = useState(false),
    [analytics, setAnalytics] = useState(false),
    [saved, setSaved] = useState<"persistent" | "tab" | null>(null);
  const [footer, setFooter] = useState<HTMLElement | null>(null),
    [status, setStatus] = useState("");
  const [methods, setMethods] = useState<WebAuthMethods | null>(null),
    [busy, setBusy] = useState(false),
    [sharing, setSharing] = useState(false);
  const restricted = restrictiveSignal();
  const volatileChoice = useRef<CookiePreference | null>(null);
  const refresh = () => {
    const s = browserStorage(),
      value = s ? readCookiePreference(s) : null;
    if (!value && volatileChoice.current) {
      setPreference(volatileChoice.current);
      setAnalytics(false);
      setBanner(false);
      return;
    }
    if (value) volatileChoice.current = null;
    setPreference(value);
    setAnalytics(Boolean(value?.analytics));
    setBanner(!value);
  };
  useLayoutEffect(() => {
    setFooter(document.querySelector<HTMLElement>(".web-footer"));
    refresh();
    if (new URLSearchParams(location.search).get("privacy") === "data")
      queueMicrotask(open);
  }, []);
  useEffect(() => {
    const changed = (event: StorageEvent) => {
      if (event.key === COOKIE_PREFERENCE_KEY || event.key === null) {
        stopPendingCollection();
        refresh();
        const s = browserStorage();
        if (!s || !readCookiePreference(s)?.analytics)
          void withdrawCollection("analytics");
      } else if (
        event.key?.startsWith("accreatio:collection-boundary:") ||
        (event.key?.startsWith("accreatio:collect-capability:") &&
          pendingCapability(event.newValue))
      )
        stopPendingCollection();
    };
    const localResult = (event: Event) =>
      setStatus(
        (event as CustomEvent).detail?.ok
          ? es
            ? "Descarga local preparada. Comprueba el manifiesto y las limitaciones del ZIP."
            : "Local download prepared. Check the ZIP manifest and limitations."
          : es
            ? "No se pudo preparar la descarga local o cambió la cuenta; vuelve a intentarlo."
            : "Local download could not be prepared or the account changed; retry.",
      );
    const usage = (event: Event) => {
      const detail = (event as CustomEvent).detail;
      if (detail)
        void recordUsage({
          ...detail,
          locale,
          device:
            innerWidth < 600
              ? "mobile"
              : innerWidth < 1024
                ? "tablet"
                : "desktop",
        });
    };
    const retry = () => {
      void retryWithdrawals();
      refresh();
    };
    window.addEventListener("storage", changed);
    window.addEventListener("accreatio:usage", usage);
    window.addEventListener("online", retry);
    window.addEventListener("accreatio:local-data-result", localResult);
    window.addEventListener("accreatio:open-privacy", open);
    const timer = setInterval(refresh, 60000);
    void retryWithdrawals();
    return () => {
      window.removeEventListener("storage", changed);
      window.removeEventListener("accreatio:usage", usage);
      window.removeEventListener("online", retry);
      window.removeEventListener("accreatio:local-data-result", localResult);
      window.removeEventListener("accreatio:open-privacy", open);
      clearInterval(timer);
    };
  }, [locale]);
  function open() {
    refresh();
    dialog.current?.showModal();
    void recordUsage({
      kind: "usage",
      feature: "privacy",
      outcome: "opened",
      durationBand: "instant",
      locale,
      device:
        innerWidth < 600 ? "mobile" : innerWidth < 1024 ? "tablet" : "desktop",
    });
    void loadWebAuthMethods()
      .then(setMethods)
      .catch(() => setMethods(null));
  }
  async function choose(enabled: boolean) {
    const result = saveOptionalChoice(browserStorage(), enabled);
    volatileChoice.current = result.persisted ? null : result.preference;
    setPreference(result.preference);
    setAnalytics(result.preference.analytics);
    setSaved(result.persisted ? "persistent" : "tab");
    setBanner(false);
    if (!result.preference.analytics) {
      const done = await withdrawCollection("analytics");
      if (!done)
        setStatus(
          es
            ? "Recopilación detenida aquí. Retirada del servidor pendiente; vuelve a intentarlo con conexión."
            : "Collection stopped here. Server withdrawal is pending; retry when connected.",
        );
    } else
      setStatus(
        es
          ? "Analítica habilitada. Sólo campos estructurados; el envío requiere servicio opcional activo."
          : "Analytics enabled. Structured fields only; sharing requires an active optional service.",
      );
    window.dispatchEvent(new Event("accreatio:preferences-changed"));
  }
  async function research(event: FormEvent<HTMLFormElement>, share: boolean) {
    event.preventDefault();
    setSharing(true);
    const answers = Object.fromEntries(
      [...new FormData(event.currentTarget)].filter(
        ([, v]) => typeof v === "string" && v,
      ),
    ) as ResearchAnswers;
    try {
      await submitResearch(answers, share);
      setStatus(
        share
          ? es
            ? "Respuestas guardadas y compartidas con AEKR para investigación del producto."
            : "Answers saved and shared with AEKR for product research."
          : es
            ? "Respuestas guardadas sólo en este navegador."
            : "Answers saved only in this browser.",
      );
    } catch {
      setStatus(
        es
          ? "No se compartieron respuestas. El servicio está inactivo o no disponible, o faltan respuestas; revisa la copia local en la descarga."
          : "Answers were not shared. The service is inactive/unavailable, or answers are missing; check your local copy in the download.",
      );
    } finally {
      setSharing(false);
    }
  }
  const entry = (
    <nav
      className="web-footer__policies"
      aria-label={es ? "Políticas" : "Policies"}
    >
      <a href={termsHref(locale)} aria-haspopup="dialog">
        ToS
      </a>
      <a href={legalHref("privacy", locale)} aria-haspopup="dialog">
        Privacy
      </a>
      <button
        type="button"
        className="cookie-preferences-entry"
        onClick={open}
        aria-haspopup="dialog"
      >
        {es ? "Opciones de privacidad" : "Privacy choices"}
      </button>
      <a href={legalHref("cookies", locale)} aria-haspopup="dialog">
        Cookies
      </a>
    </nav>
  );
  const actions = (
    <div className="cookie-preferences-actions">
      <button
        type="button"
        className="secondary"
        onClick={() => void choose(true)}
      >
        {es ? "Aceptar todas las opcionales" : "Accept all optional"}
      </button>
      <button
        type="button"
        className="secondary"
        onClick={() => void choose(false)}
      >
        {es ? "Rechazar no esenciales" : "Reject non-essential cookies"}
      </button>
      <button type="button" className="secondary" onClick={open}>
        {es ? "Configurar" : "Configure"}
      </button>
    </div>
  );
  return (
    <>
      {footer ? createPortal(entry, footer) : entry}
      {banner && (
        <section
          className="cookie-first-layer"
          aria-label={es ? "Opciones de privacidad" : "Privacy choices"}
        >
          <p>
            {es
              ? "Opcional: medir funciones, resultados, duración por rangos, idioma y tipo general de dispositivo para mejorar accreatio. Proyectos y archivos siguen locales. Rechazar conserva el servicio y las descargas. La encuesta se decide por separado."
              : "Optional: measure features, outcomes, duration bands, language and broad device type to improve accreatio. Projects and files stay local. Rejection preserves the service and downloads. The survey is a separate choice."}
          </p>
          {actions}
        </section>
      )}
      <dialog
        ref={dialog}
        className="cookie-preferences-dialog"
        aria-labelledby="cookie-preferences-title"
        aria-describedby="cookie-preferences-description"
      >
        <h2 id="cookie-preferences-title">{es ? "Privacidad" : "Privacy"}</h2>
        <p id="cookie-preferences-description">
          {es
            ? "Las cookies necesarias permiten acceder y proteger tu sesión. Iniciar sesión no acepta opciones. La analítica y la investigación no reciben proyectos, archivos, nombres, correos ni credenciales. No se venden ni transfieren datos a terceros para fines comerciales."
            : "Necessary cookies let you sign in and protect your session. Signing in does not accept optional purposes. Analytics and research receive no projects, files, names, emails or credentials. No data is sold or transferred to third parties for commercial use."}
        </p>
        <p>
          {es
            ? "Elección local: 180 días. Datos y permisos opcionales: 30 días, máximo 200 aportes por finalidad. Cada finalidad usa una clave aleatoria propia de este navegador; no se vincula con la cuenta ni con otro producto. Se almacenan localmente y, sólo si el servicio está activo, en AEKR mediante Cloudflare D1. La retirada elimina los aportes recuperables del servidor; copias de recuperación del proveedor requieren el procedimiento de supresión."
            : "Local choice: 180 days. Optional data and permissions: 30 days, at most 200 contributions per purpose. Each purpose uses its own random browser capability, with no account or other-product link. Data is stored locally and, only when the service is active, by AEKR through Cloudflare D1. Withdrawal deletes retrievable server contributions; provider recovery copies require the suppression procedure."}
        </p>
        {restricted && (
          <p role="status">
            {es
              ? "GPC activo: bloquea venta y compartición publicitaria. La analítica y la encuesta conservan sus elecciones independientes."
              : "GPC active: advertising sale and sharing are blocked. Analytics and the survey retain their independent choices."}
          </p>
        )}
        <label>
          <input
            type="checkbox"
            checked={analytics}
            onChange={(e) => setAnalytics(e.target.checked)}
          />
          {es
            ? "Analítica opcional de uso y experiencia técnica"
            : "Optional usage and technical-experience analytics"}
        </label>
        {actions}
        <button
          type="button"
          className="secondary"
          onClick={() => void choose(analytics)}
        >
          {es ? "Guardar selección" : "Save selection"}
        </button>
        {preference && (
          <p role="status" data-preference-key={COOKIE_PREFERENCE_KEY}>
            {saved === "tab"
              ? es
                ? "Opcionales desactivadas. No se pudo guardar la elección."
                : "Optional collection is off. The choice could not be saved."
              : preference.analytics
                ? es
                  ? "Preferencia guardada: analítica opcional."
                  : "Saved preference: optional analytics."
                : es
                  ? "Preferencia guardada: solo necesarias."
                  : "Saved preference: necessary only."}
          </p>
        )}
        <CommercialPreferences locale={locale} />
        <details>
          <summary>
            {es
              ? "Encuesta voluntaria independiente"
              : "Independent voluntary survey"}
          </summary>
          <p>
            {es
              ? "Elige sólo lo que quieras compartir para priorizar funciones, herramientas y ofertas. Rechazar analítica no impide responder. Las respuestas de una entrega se analizan conjuntamente; entregas y eventos no son personas únicas ni una muestra representativa. No hay texto libre, contacto comercial ni permisos OAuth nuevos."
              : "Choose only what you want to share to prioritize features, tools and offers. Rejecting analytics does not prevent answering. Fields in one submission are analyzed together; submissions and events are not unique people or a representative sample. No free text, marketing contact or new OAuth permissions."}
          </p>
          <form onSubmit={(e) => void research(e, true)}>
            {Object.entries(RESEARCH_FIELDS).map(([name, options]) => (
              <div key={name}>
                <label htmlFor={`collect-research-${name}`}>
                  {fieldNames[name as keyof typeof RESEARCH_FIELDS][es ? 0 : 1]}
                </label>
                <select
                  id={`collect-research-${name}`}
                  name={name}
                  defaultValue=""
                >
                  <option value="">{es ? "Omitir" : "Skip"}</option>
                  {options.map((value) => (
                    <option key={value} value={value}>
                      {value.replaceAll("-", " ")}
                    </option>
                  ))}
                </select>
              </div>
            ))}
            <div className="cookie-preferences-actions">
              <button type="submit" className="secondary" disabled={sharing}>
                {es
                  ? "Compartir mis respuestas con AEKR"
                  : "Share my answers with AEKR"}
              </button>
              <button
                type="button"
                className="secondary"
                disabled={sharing}
                onClick={(e) => {
                  const form = e.currentTarget.form;
                  if (form)
                    void research(
                      {
                        preventDefault() {},
                        currentTarget: form,
                      } as FormEvent<HTMLFormElement>,
                      false,
                    );
                }}
              >
                {es
                  ? "Guardar sólo en este navegador"
                  : "Save only in this browser"}
              </button>
            </div>
          </form>
          <button
            type="button"
            className="secondary"
            onClick={() =>
              void withdrawCollection("research").then((done) =>
                setStatus(
                  done
                    ? es
                      ? "Investigación retirada; aportes disponibles eliminados."
                      : "Research withdrawn; available contributions deleted."
                    : es
                      ? "Investigación detenida aquí; retirada del servidor pendiente."
                      : "Research stopped here; server withdrawal pending.",
                ),
              )
            }
          >
            {es
              ? "Retirar investigación y borrar aportes"
              : "Withdraw research and delete contributions"}
          </button>
        </details>
        <h3>{es ? "Descargar mis datos" : "Download my data"}</h3>
        <p>
          {es
            ? "La descarga local incluye el borrador accesible de esta pestaña, configuración y adjuntos todavía disponibles. IndexedDB y el journal conservan el borrador, nunca los adjuntos. Archivos que sólo existían en una pestaña cerrada no son recuperables; tampoco otros dispositivos ni otras cuentas."
            : "Local download includes this tab's accessible draft, settings and attachments still available. IndexedDB and the journal preserve the draft, never attachment bytes. Files that existed only in a closed tab cannot be recovered; other devices and accounts are outside this download."}
        </p>
        <button
          type="button"
          className="secondary"
          onClick={() => {
            window.dispatchEvent(new Event("accreatio:download-local-data"));
            setStatus(
              es
                ? "Descarga local solicitada. Comprueba el manifiesto y las limitaciones dentro del ZIP."
                : "Local download requested. Check the manifest and limitations inside the ZIP.",
            );
          }}
        >
          {es ? "Descargar datos locales" : "Download local data"}
        </button>
        <button
          type="button"
          className="secondary"
          onClick={() =>
            void downloadOptionalData()
              .then((data) =>
                download({
                  ...data,
                  commercialChoices: commercialChoices(),
                  preference,
                  noticeVersion: COLLECTION_VERSION,
                }),
              )
              .catch(() =>
                setStatus(
                  es
                    ? "No se pudo preparar la descarga opcional; vuelve a intentarlo."
                    : "Optional download could not be prepared; retry.",
                ),
              )
          }
        >
          {es
            ? "Descargar preferencias y aportes"
            : "Download choices and contributions"}
        </button>
        <AccountRightsAccess
          locale={locale}
          methods={methods}
          disabled={busy}
          onBusyChange={setBusy}
        />
        {status && <p role="status">{status}</p>}
        <p>
          <a
            href={legalHref("cookies", locale)}
            target="_blank"
            rel="noopener noreferrer"
          >
            {es
              ? "Cookies y almacenamiento local"
              : "Cookies and local storage"}
          </a>{" "}
          ·{" "}
          <a href={legalHref("privacy", locale)}>
            {es ? "Privacidad" : "Privacy"}
          </a>
        </p>
        <button
          type="button"
          className="secondary"
          onClick={() => dialog.current?.close()}
        >
          {es ? "Cerrar" : "Close"}
        </button>
      </dialog>
    </>
  );
}
