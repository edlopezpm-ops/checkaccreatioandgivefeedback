# Estado y decisiones

Status: IDEA_RECORDED
governance-profile: Lean
phase: idea
orchestration-enabled: false

Este documento controla fase y decisiones. El objetivo y límites pertenecen a [PROJECT_PROMPT.md](../PROJECT_PROMPT.md); las fuentes y preguntas, a [discovery](product/discovery.md). Lean exige evidencia proporcionada; no inventes obligaciones de un perfil Full.

## Decisiones registradas al exportar

```json
{
  "phase": "idea",
  "route": "local",
  "preparationAction": "repository",
  "initializeGit": false,
  "createRemote": false,
  "remotePrivate": true,
  "openIde": false,
  "dryRun": true,
  "orchestrationEnabled": false
}
```

Describen la preparación seleccionada; no prueban que Git, GitHub, editor o agentes estén disponibles ni autorizan publicar o desplegar.

## Siguiente acción

Redacta una primera definición del problema y un criterio observable de éxito usando el objetivo registrado. Señala las suposiciones como pendientes; no elijas stack ni empieces a construir por defecto.

## Pendiente

- Stack y arquitectura: comprueba las decisiones aportadas en PROJECT_PROMPT.md; lo no registrado sigue pendiente. Propón alternativas cuando la fase lo requiera.
- Presupuesto: aplicar únicamente los límites de PROJECT_PROMPT.md; cualquier cifra adicional está pendiente.
- Aceptación y cambios de fase: requieren decisión humana explícita; esta exportación no registra aprobaciones.

Registra cada decisión nueva con su motivo y evidencia. Usa [el registro de decisiones](adr/0001-record-architecture-decisions.md) para decisiones duraderas. Comprueba resultados con [los criterios de terminado](delivery/definition-of-done.md); distingue verificación técnica de aceptación humana.
