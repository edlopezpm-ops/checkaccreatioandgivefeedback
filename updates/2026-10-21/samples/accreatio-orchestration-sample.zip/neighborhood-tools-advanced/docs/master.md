# State and decisions

Status: IDEA_RECORDED
governance-profile: Lean
phase: idea
orchestration-enabled: true

This document controls phase and decisions. Goal and constraints belong to [PROJECT_PROMPT.md](../PROJECT_PROMPT.md); sources and questions belong to [discovery](product/discovery.md). Lean requires proportionate evidence; do not invent Full-profile obligations.

## Decisions recorded at export

```json
{
  "phase": "idea",
  "route": "local",
  "preparationAction": "repository",
  "initializeGit": false,
  "createRemote": false,
  "remotePrivate": true,
  "openIde": false,
  "dryRun": true,
  "orchestrationEnabled": true
}
```

These describe the selected preparation; they do not establish Git, GitHub, editor or agent availability or authorize publishing or deployment.

## Next action

Draft a first problem statement and one observable success criterion from the recorded goal. Mark assumptions as unresolved; do not choose a stack or start building by default.

## Unresolved

- Stack and architecture: check decisions supplied in PROJECT_PROMPT.md; unrecorded details remain unresolved. Propose alternatives when appropriate to the phase.
- Budget: apply only the constraints in PROJECT_PROMPT.md; any additional amount is unresolved.
- Acceptance and phase transitions require an explicit human decision; this export records no approvals.

Record each new decision with rationale and evidence. Use [the decision record](adr/0001-record-architecture-decisions.md) for durable decisions. Check results against [completion criteria](delivery/definition-of-done.md); distinguish technical verification from human acceptance.
