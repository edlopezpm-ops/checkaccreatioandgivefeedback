# Optional bounded work loop

Applies only after runtime setup and human approval. Read [master](../master.md)
and [gates](../../orchestrator/GATES.md). Choose a bounded in-phase action,
verify prerequisites, check gates and budgets, execute once and record evidence.
Stop at a human gate or unresolved blocking decision. Successful commands and
review verdicts do not grant approval.
