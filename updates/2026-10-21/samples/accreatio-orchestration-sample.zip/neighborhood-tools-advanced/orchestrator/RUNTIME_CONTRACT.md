# Optional runtime preparation contract

This specification is not installed software. Read [configuration](CONFIGURATION.md)
and [gates](GATES.md). Separate validation, preflight, gates, execution, state and
evidence. Adapters expose name/version, health_check and invoke(role, task, context),
return typed outcomes and never raw authentication output. Fixed executable
names and argument arrays only; never pass user-authored text to a shell.

Load canonical YAML from the project root, validate, check gates and ceilings,
invoke one role and record outcome. Auditor needs a fresh context and cannot
write project files. Only Implementador may request workspace-write. Missing
roles require a human topology decision; self-review is not independent audit.

Create .local/orchestration state/redacted JSONL only during reviewed execution.
Persist atomically: config fingerprint, next step, budget counters. Refuse
changed-config resume; review interrupted work before retry to avoid duplicate
side effects. Never log credentials, private tasks or raw CLI output.

Preflight has no execution side effects. An optional PowerShell wrapper only
forwards typed arguments and exits with the runtime exit code. Config defaults
to .ai-engineering/orchestration.yaml from the project root. Review code and
dependencies before execution; never bypass operating-system execution policies.
