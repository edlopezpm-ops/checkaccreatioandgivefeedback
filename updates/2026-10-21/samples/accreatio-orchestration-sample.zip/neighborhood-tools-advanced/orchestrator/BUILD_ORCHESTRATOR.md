# Optional orchestration setup

Orchestration was explicitly enabled. Understand the project through START.md
first. This package contains inert configuration and specifications, not an
installed or verified runtime. A useful discovery/design action can begin in
the available assistant while setup is pending.

## Single configuration

Use [../.ai-engineering/orchestration.yaml](../.ai-engineering/orchestration.yaml)
from the project root for both preflight and execution. Do not create a second
configuration. No external AEKR checkout or private handbook is required.
Read [configuration](CONFIGURATION.md), [runtime contract](RUNTIME_CONTRACT.md)
and [gate requirements](GATES.md) before preparing a runtime.

## Prerequisites to verify

Optional runtime preparation requires Python 3, a YAML parser (PyYAML), and
the selected provider CLIs with a user-controlled authenticated session.
A PowerShell wrapper is optional; if used, require PowerShell 7. Record actual
versions/capabilities without tokens. Nothing was verified at export time.
Do not acquire a paid service or enter credentials for the user.

Compare every planned ID in [participants](../docs/delivery/participants.md)
with actual independent contexts/tools. Roles are future work, not running
agents. Warn and get a human decision before reducing topology.

- participant-01: architect
- participant-02: implementer
- participant-03: auditor

## Prepare and verify only when needed

Prepare the smallest local implementation of the runtime contract. Show the
human generated files, dependencies and the proposed invocation before running
them. Generated code is not inherently safe and has no special execution-policy
status. Do not alter or bypass PowerShell or managed-device controls.

Preflight validates the canonical config and capabilities without execution
side effects. Use a fake provider to prove missing CLI handling, config rejection,
HUMAN_ONLY gate denial, budget exhaustion, interrupted-run recovery and redacted
evidence. Neither a real provider run nor human acceptance is established here.
