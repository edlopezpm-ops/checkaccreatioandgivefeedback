# Required gates

HUMAN_ONLY: phase transitions, acceptance, destructive operations, credential
access, dependency installation, generated-runtime execution, independent audit
invocation, commits, pushes, publishing and deployment. Require an explicit
human decision for the bounded action. A provider cannot override a gate.
EXECUTE_ROLE_STEP is eligible only in an already approved phase/scope and within
all budgets. Never auto-commit or auto-push. Stop at about 3 unsuccessful passes
or a smaller configured ceiling. Deny unknown gates and missing approvals.
Follow [canonical instructions](../AGENTS.md).
