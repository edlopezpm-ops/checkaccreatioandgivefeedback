# Configuration contract

Canonical input: [../.ai-engineering/orchestration.yaml](../.ai-engineering/orchestration.yaml).
Resolve it from the project root in preflight and execution. Reject unknown
fields, malformed values, duplicate roles, missing tasks and topology changes.

- project_name: nonempty slug; mode: integer 1, human-gated deterministic execution.
- session.max_duration_seconds: positive integer wall-clock ceiling.
- role_sequence: ordered role, action_kind, task objects. Roles: Generalista,
  Arquitecto, Implementador, Auditor; one of each maximum. participant_id comments
  preserve wizard identity. action_kind is EXECUTE_ROLE_STEP, or
  EXECUTE_INDEPENDENT_AUDIT for Auditor.
- adapters: one matching role key per sequence entry; kind is codex or claude_code.
  Codex sandbox is read-only except workspace-write for Implementador.
- budget: positive integer max_iterations_per_entity, max_provider_invocations,
  max_consecutive_failures. Check every ceiling before each invocation.

Tasks are data passed through argument arrays/stdin; never interpolate them
into a shell command. No API funding, credentials or automatic approvals are configured.
